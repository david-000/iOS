//
//  DatabaseManager.m
//  CommuSoft
//
//  Created by System Administrator on 11/2/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "DatabaseManager.h"
#import "YachtModel.h"
#import "AmenitiesModel.h"

@implementation DatabaseManager

-(id)init
{
	BOOL result = [self connect];
	if(!result)
	{
		
	}
	
	pthread_mutex_init(&m_Mutex, NULL);
	
	return self;
}

- (void)dealloc
{
	[super dealloc];
	
	pthread_mutex_destroy(&m_Mutex);
}

-(BOOL)connect
{
	NSString* db_path = [DOCS_FOLDER stringByAppendingPathComponent:YACHET_DB_NAME];
	int result = sqlite3_open([db_path UTF8String], &m_Database);
	if(result != SQLITE_OK)
	{
		sqlite3_close(m_Database);
		return NO;
	}
	return YES;
}

-(void)disConnect
{
	sqlite3_close(m_Database);	
}

-(void)dbconn_lock
{
	pthread_mutex_lock(&m_Mutex);
}

-(void)dbconn_unlock
{
	pthread_mutex_unlock(&m_Mutex);
}

-(BOOL)createDBAndTables
{
	BOOL retValue = YES;
	
	char* errorMsg;
		
		NSString* strQuery = [NSString stringWithFormat:@"CREATE  TABLE IF NOT EXISTS %@ (%@ INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT , %@ INTEGER , %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(50) NOT NULL DEFAULT '', %@ VARCHAR(15) NOT NULL DEFAULT '0000-00-00' , %@ VARCHAR(15) DEFAULT '0000-00-00', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ TEXT NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '')", 
							  YACHET_FAVORITE_TABLE_NAME,
							  FAVORITE_FIELD_FAVORITEID, 
							  FAVORITE_FIELD_PRODUCTID, 
							  FAVORITE_FIELD_YACHTNAME, 
							  FAVORITE_FIELD_PRICE, 
							  FAVORITE_FIELD_STARTDATE, 
							  FAVORITE_FIELD_ENDDATE,
							  FAVORITE_FIELD_THUMB,
                              FAVORITE_FIELD_DESCRIPTION,
                              FAVORITE_FIELD_ROOMS,
                              FAVORITE_FIELD_SLEEPS,
                              FAVORITE_FIELD_BATH,
                              FAVORITE_FIELD_FACILITY,
                              FAVORITE_FIELD_RANKING,
                              FAVORITE_FIELD_GUEST,
                              FAVORITE_FIELD_DATE
							  ];
		if (sqlite3_exec(m_Database, [strQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
		{
			sqlite3_close(m_Database);
			//NSAssert1(0, @"Error createing Credit card table: %s", errorMsg);
			return NO;
		}
		
    strQuery = [NSString stringWithFormat:@"CREATE  TABLE IF NOT EXISTS %@ (%@ INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT , %@ INTEGER , %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '')", 
                AMENITIES_TABLE_NAME,
                AMENITIES_FIELD_FAVORITEID, 
                AMENITIES_FIELD_PRODUCTID, 
                AMENITIES_FIELD_IMAGENAME, 
                AMENITIES_FIELD_THUMB
                ];
		if (sqlite3_exec(m_Database, [strQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
		{
			sqlite3_close(m_Database);
			//NSAssert1(0, @"Error createing commusoft table: %s", errorMsg);
			return NO;
		}
		
    strQuery = [NSString stringWithFormat:@"CREATE  TABLE IF NOT EXISTS %@ (%@ INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT , %@ INTEGER , %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(50) NOT NULL, %@ VARCHAR(15) NOT NULL DEFAULT '0000-00-00' , %@ VARCHAR(15) DEFAULT '0000-00-00', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ TEXT NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '', %@ VARCHAR(255) NOT NULL DEFAULT '')", 
                YACHET_TABLE_NAME,
                YACHET_FIELD_ID, 
                YACHET_FIELD_PRODUCTID, 
                YACHET_FIELD_YACHTNAME, 
                YACHET_FIELD_PRICE, 
                YACHET_FIELD_STARTDATE, 
                YACHET_FIELD_ENDDATE,
                YACHET_FIELD_THUMB,
                YACHET_FIELD_DESCRIPTION,
                YACHET_FIELD_ROOMS,
                YACHET_FIELD_SLEEPS,
                YACHET_FIELD_BATH,
                YACHET_FIELD_FACILITY,
                YACHET_FIELD_RANKING,
                YACHET_FIELD_GUEST,
                YACHET_FIELD_DATE
                ];
    if (sqlite3_exec(m_Database, [strQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
    {
        sqlite3_close(m_Database);
        //NSAssert1(0, @"Error createing commusoft table: %s", errorMsg);
        return NO;
    }

	return retValue;
}

-(BOOL)InsertDataToDB:(NSString*)strQuery;
{
	BOOL retValue = YES;
//    NSString* query = [self replashQuery:strQuery];
	
	char* errorMsg;
//	NSString *query = @"";
//    query = [self replashQuery:strQuery];
//    NSLog(query);
	[self dbconn_lock];
	
	if (sqlite3_exec(m_Database, [strQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
	{
		retValue = NO;
	}	
	
	[self dbconn_unlock];
		
	return retValue;
}

-(NSMutableArray*)selectYachtListFromDB:(int)state
{
	NSMutableArray *result = [[NSMutableArray alloc] init];
	NSString *dbName = @"";
    if (state == 0) {
        dbName = YACHET_FAVORITE_TABLE_NAME;
    }
    else
    {
        dbName = YACHET_TABLE_NAME;
    }
	const char* sqlStatement = [[NSString stringWithFormat:@"SELECT * FROM %@ ", dbName] UTF8String];
		NSString* name = @"";
		
		if (name != nil)
			name = [NSString stringWithUTF8String:sqlStatement];
		
		sqlite3_stmt *stmt;
	
		[self dbconn_lock];
	
		if(sqlite3_prepare_v2(m_Database, sqlStatement, -1, &stmt, NULL) == SQLITE_OK)
		{
			while(sqlite3_step(stmt) == SQLITE_ROW)
			{
				int fid             = sqlite3_column_int(stmt, 0);
				int fproid          = sqlite3_column_int(stmt, 1);
				char *yachtname     = (char*)sqlite3_column_text(stmt, 2);
				char *price         = (char*)sqlite3_column_text(stmt, 3);
				char *startdate     = (char*)sqlite3_column_text(stmt, 4);
				char *enddate       = (char*)sqlite3_column_text(stmt, 5);
				char *thumb         = (char*)sqlite3_column_text(stmt, 6);
				char *description   = (char*)sqlite3_column_text(stmt, 7);
				char *rooms         = (char*)sqlite3_column_text(stmt, 8);
				char *sleeps        = (char*)sqlite3_column_text(stmt, 9);
				char *bath          = (char*)sqlite3_column_text(stmt, 10);
				char *facility      = (char*)sqlite3_column_text(stmt, 11);
				char *ranking       = (char*)sqlite3_column_text(stmt, 12);
                char *guest         = (char*)sqlite3_column_text(stmt, 13);
                char *fDate         = (char*)sqlite3_column_text(stmt, 14);
								
				NSString* ns_yachtname = @"";
				NSString* ns_price = @"";
				NSString* ns_startdate = @"";
				NSString* ns_enddate = @"";
				NSString* ns_thumb = @"";
				NSString* ns_description = @"";
                NSString* ns_rooms = @"";
				NSString* ns_sleeps = @"";
				NSString* ns_bath = @"";
				NSString* ns_facility = @"";
				NSString* ns_ranking = @"";
                NSString* ns_guest = @"";
                NSString* ns_fdate = @"";
				
				if (fDate != nil)
					ns_fdate = [NSString stringWithUTF8String:fDate];
                if (yachtname != nil)
					ns_yachtname = [NSString stringWithUTF8String:yachtname];
				if (price != nil)
					ns_price = [NSString stringWithUTF8String:price];
				if (startdate != nil)
					ns_startdate = [NSString stringWithUTF8String:startdate];
				if (enddate != nil)
					ns_enddate = [NSString stringWithUTF8String:enddate];
				if (thumb != nil)
					ns_thumb = [NSString stringWithUTF8String:thumb];
				if (description != nil)
					ns_description = [NSString stringWithUTF8String:description];
                if (rooms != nil)
					ns_rooms = [NSString stringWithUTF8String:rooms];
				if (sleeps != nil)
					ns_sleeps = [NSString stringWithUTF8String:sleeps];
				if (bath != nil)
					ns_bath = [NSString stringWithUTF8String:bath];
				if (facility != nil)
					ns_facility = [NSString stringWithUTF8String:facility];
				if (ranking != nil)
					ns_ranking = [NSString stringWithUTF8String:ranking];
                if (guest != nil)
					ns_ranking = [NSString stringWithUTF8String:guest];
				
				YachtModel *model = [[YachtModel alloc] init];
				[model setYachtId:fid];
                [model setFavoriteId:fproid];
                model.yachtName = ns_yachtname;
                model.price = ns_price;
                model.startdate = ns_startdate;
                model.enddate = ns_enddate;
                model.thumb = ns_thumb;
                model.description = ns_description;
                model.rooms = ns_rooms;
                model.sleeps = ns_sleeps;
                model.bath = ns_bath;
                model.facility = ns_facility;
                model.ranking = ns_ranking;
                model.guest = ns_guest;
                model.favoriteDate = ns_fdate;
				
				[result addObject:model];
				[model release];
			}
		}

		// Release the compiled statement from memory
		sqlite3_finalize(stmt);
	
		[self dbconn_unlock];

	return result;
}

-(NSMutableArray*)selectYachtListFromDB:(int)state searchString:(NSString*)sStr searchField:(NSString*)field
{
	NSMutableArray *result = [[NSMutableArray alloc] init];
	NSString *dbName = @"";
    if (state == 0) {
        dbName = YACHET_FAVORITE_TABLE_NAME;
    }
    else
    {
        dbName = YACHET_TABLE_NAME;
    }
    NSString    *query = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE %@ LIKE '", dbName, field];
    NSString    *param = [NSString stringWithFormat:@"%@%%'",sStr];
    query = [query stringByAppendingString:param];
	const char* sqlStatement = [query UTF8String];
    NSString* name = @"";
    
    if (name != nil)
        name = [NSString stringWithUTF8String:sqlStatement];
    
    sqlite3_stmt *stmt;
	
    [self dbconn_lock];
	
    if(sqlite3_prepare_v2(m_Database, sqlStatement, -1, &stmt, NULL) == SQLITE_OK)
    {
        while(sqlite3_step(stmt) == SQLITE_ROW)
        {
            int fid             = sqlite3_column_int(stmt, 0);
            int fproid          = sqlite3_column_int(stmt, 1);
            char *yachtname     = (char*)sqlite3_column_text(stmt, 2);
            char *price         = (char*)sqlite3_column_text(stmt, 3);
            char *startdate     = (char*)sqlite3_column_text(stmt, 4);
            char *enddate       = (char*)sqlite3_column_text(stmt, 5);
            char *thumb         = (char*)sqlite3_column_text(stmt, 6);
            char *description   = (char*)sqlite3_column_text(stmt, 7);
            char *rooms         = (char*)sqlite3_column_text(stmt, 8);
            char *sleeps        = (char*)sqlite3_column_text(stmt, 9);
            char *bath          = (char*)sqlite3_column_text(stmt, 10);
            char *facility      = (char*)sqlite3_column_text(stmt, 11);
            char *ranking       = (char*)sqlite3_column_text(stmt, 12);
            char *guest         = (char*)sqlite3_column_text(stmt, 13);
            char *fDate         = (char*)sqlite3_column_text(stmt, 14);
            
            NSString* ns_yachtname = @"";
            NSString* ns_price = @"";
            NSString* ns_startdate = @"";
            NSString* ns_enddate = @"";
            NSString* ns_thumb = @"";
            NSString* ns_description = @"";
            NSString* ns_rooms = @"";
            NSString* ns_sleeps = @"";
            NSString* ns_bath = @"";
            NSString* ns_facility = @"";
            NSString* ns_ranking = @"";
            NSString* ns_guest = @"";
            NSString* ns_fdate = @"";
            
            if (fDate != nil)
                ns_fdate = [NSString stringWithUTF8String:fDate];
            if (yachtname != nil)
                ns_yachtname = [NSString stringWithUTF8String:yachtname];
            if (price != nil)
                ns_price = [NSString stringWithUTF8String:price];
            if (startdate != nil)
                ns_startdate = [NSString stringWithUTF8String:startdate];
            if (enddate != nil)
                ns_enddate = [NSString stringWithUTF8String:enddate];
            if (thumb != nil)
                ns_thumb = [NSString stringWithUTF8String:thumb];
            if (description != nil)
                ns_description = [NSString stringWithUTF8String:description];
            if (rooms != nil)
                ns_rooms = [NSString stringWithUTF8String:rooms];
            if (sleeps != nil)
                ns_sleeps = [NSString stringWithUTF8String:sleeps];
            if (bath != nil)
                ns_bath = [NSString stringWithUTF8String:bath];
            if (facility != nil)
                ns_facility = [NSString stringWithUTF8String:facility];
            if (ranking != nil)
                ns_ranking = [NSString stringWithUTF8String:ranking];
            if (guest != nil)
                ns_ranking = [NSString stringWithUTF8String:guest];
            
            YachtModel *model = [[YachtModel alloc] init];
            [model setYachtId:fid];
            [model setFavoriteId:fproid];
            model.yachtName = ns_yachtname;
            model.price = ns_price;
            model.startdate = ns_startdate;
            model.enddate = ns_enddate;
            model.thumb = ns_thumb;
            model.description = ns_description;
            model.rooms = ns_rooms;
            model.sleeps = ns_sleeps;
            model.bath = ns_bath;
            model.facility = ns_facility;
            model.ranking = ns_ranking;
            model.guest = ns_guest;
            model.favoriteDate = ns_fdate;
            
            [result addObject:model];
            [model release];
        }
    }
    
    // Release the compiled statement from memory
    sqlite3_finalize(stmt);
	
    [self dbconn_unlock];
    
	return result;
}



//lhi add
-(NSString*)replashQuery:(NSString*)data
{
	NSString *result;
	result = [data stringByReplacingOccurrencesOfString:@"\'" withString:@"\'\'"];
	return result;
}

-(NSMutableArray*)selectAmenitiesListFromDB:(NSString*)sStr
{
    NSMutableArray *result = [[NSMutableArray alloc] init];
    NSString    *query = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE %@ LIKE '%%", AMENITIES_TABLE_NAME, AMENITIES_FIELD_IMAGENAME];
    NSString    *param = [NSString stringWithFormat:@"%@%%'",sStr];
    query = [query stringByAppendingString:param];
	const char* sqlStatement = [query UTF8String];
    NSString* name = @"";
    
    if (name != nil)
        name = [NSString stringWithUTF8String:sqlStatement];
    
    sqlite3_stmt *stmt;
	
    [self dbconn_lock];
	
    if(sqlite3_prepare_v2(m_Database, sqlStatement, -1, &stmt, NULL) == SQLITE_OK)
    {
        while(sqlite3_step(stmt) == SQLITE_ROW)
        {
            int aid             = sqlite3_column_int(stmt, 0);
            int aproid          = sqlite3_column_int(stmt, 1);
            char *imagename     = (char*)sqlite3_column_text(stmt, 2);
            char *thumb         = (char*)sqlite3_column_text(stmt, 3);
            
            NSString* ns_imagename = @"";
            NSString* ns_thumb = @"";
            
            if (imagename != nil)
                ns_imagename = [NSString stringWithUTF8String:imagename];
             if (thumb != nil)
                ns_thumb = [NSString stringWithUTF8String:thumb];
             
            AmenitiesModel *model = [[AmenitiesModel alloc] init];
            [model setId:aid];
            [model setProductId:aproid];
            model.imagename = ns_imagename;
            model.thumb = ns_thumb;
            
            [result addObject:model];
            [model release];
        }
    }
    
    // Release the compiled statement from memory
    sqlite3_finalize(stmt);
	
    [self dbconn_unlock];
    
	return result;

}

-(BOOL)deleteFromDB:(NSString*)strQuery{
    return YES;
}
-(BOOL)updateToDB:(NSString*)strQuery{
    return YES;
}
@end
