//
//  DatabaseManager.h
//  CommuSoft
//
//  Created by System Administrator on 11/2/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import <sys/types.h>
#import <pthread.h>
#import <CommonCrypto/CommonDigest.h>

#define DOCS_FOLDER					[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]
#define TMP_FOLDER					[NSHomeDirectory() stringByAppendingPathComponent:@"tmp"]
#define VIDEO_FOLDER				[DOCS_FOLDER stringByAppendingPathComponent:@""]
#define THUMB_FOLDER				[DOCS_FOLDER stringByAppendingPathComponent:@"thumb"]

#define YACHET_DB_NAME					@"mydb.db"

#define YACHET_FAVORITE_TABLE_NAME		@"favorite"

#define FAVORITE_FIELD_FAVORITEID		@"favoriteid"
#define FAVORITE_FIELD_PRODUCTID		@"productid"
#define FAVORITE_FIELD_YACHTNAME		@"yachtname"
#define FAVORITE_FIELD_PRICE			@"price"
#define FAVORITE_FIELD_STARTDATE		@"startdate"
#define FAVORITE_FIELD_ENDDATE			@"enddate"
#define FAVORITE_FIELD_THUMB			@"thumb"
#define FAVORITE_FIELD_DESCRIPTION		@"description"
#define FAVORITE_FIELD_ROOMS			@"Rooms"
#define FAVORITE_FIELD_SLEEPS			@"sleeps"
#define FAVORITE_FIELD_BATH				@"bath"
#define FAVORITE_FIELD_FACILITY			@"facility"
#define FAVORITE_FIELD_RANKING			@"rankingYacht"
#define FAVORITE_FIELD_GUEST			@"guest"
#define FAVORITE_FIELD_DATE             @"favoritedate"

#define YACHET_TABLE_NAME               @"yachet"

#define YACHET_FIELD_ID                 @"yachtid"
#define YACHET_FIELD_PRODUCTID          @"productid"
#define YACHET_FIELD_YACHTNAME          @"yachtname"
#define YACHET_FIELD_PRICE              @"price"
#define YACHET_FIELD_STARTDATE          @"startdate"
#define YACHET_FIELD_ENDDATE			@"enddate"
#define YACHET_FIELD_THUMB              @"thumb"
#define YACHET_FIELD_DESCRIPTION		@"description"
#define YACHET_FIELD_ROOMS              @"Rooms"
#define YACHET_FIELD_SLEEPS             @"sleeps"
#define YACHET_FIELD_BATH				@"bath"
#define YACHET_FIELD_FACILITY			@"facility"
#define YACHET_FIELD_RANKING			@"rankingYacht"
#define YACHET_FIELD_GUEST              @"guest"
#define YACHET_FIELD_DATE               @"favoritedate"

#define AMENITIES_TABLE_NAME               @"amenities"

#define AMENITIES_FIELD_FAVORITEID         @"aid"
#define AMENITIES_FIELD_PRODUCTID          @"productid"
#define AMENITIES_FIELD_IMAGENAME          @"imagename"
#define AMENITIES_FIELD_THUMB              @"thumb"

@interface DatabaseManager: NSObject {
	sqlite3 *m_Database;
	pthread_mutex_t	m_Mutex;
}

-(id)init;
-(BOOL)connect;
-(void)disConnect;
-(void)dbconn_lock;
-(void)dbconn_unlock;

-(BOOL)createDBAndTables;
-(BOOL)InsertDataToDB:(NSString*)strQuery;
-(BOOL)deleteFromDB:(NSString*)strQuery;
-(BOOL)updateToDB:(NSString*)strQuery;
- (NSInteger)insertToDB:(NSString*)strQuery;

-(NSMutableArray*)selectYachtListFromDB:(int)state;
-(NSMutableArray*)selectYachtListFromDB:(int)state searchString:(NSString*)sStr searchField:(NSString*)field;

-(NSMutableArray*)selectAmenitiesListFromDB:(NSString*)sStr;

-(NSString*)replashQuery:(NSString*)data;

@end
