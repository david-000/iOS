//
//  AmenitiesModel.h
//  Yacht
//
//  Created by admin on 12/23/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AmenitiesModel : NSObject{
    int         amenitiesid;
    int         productid;
    NSString*   imagename;
    NSString*   thumb;
}

@property(nonatomic, retain) NSString*   imagename;
@property(nonatomic, retain) NSString*   thumb;

-(int)getId;
-(void)setId:(int)aid;

-(int)getProductid;
-(void)setProductId:(int)pid;

-(id)init;


@end
