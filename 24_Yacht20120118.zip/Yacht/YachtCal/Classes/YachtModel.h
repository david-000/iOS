//
//  YachtModel.h
//  Yacht
//
//  Created by admin on 12/22/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YachtModel : NSObject{
    int    yachtId;
    int     productId;
    NSString    *yachtName;
    NSString    *price;
    NSString    *startdate;
    NSString    *enddate;
    NSString    *thumb;
    NSString    *description;
    NSString    *rooms;
    NSString    *sleeps;
    NSString    *bath;
    NSString    *facility;
    NSString    *ranking;
    NSString    *guest;
    NSString    *favoriteDate;
}

@property (nonatomic, retain) NSString    *yachtName;
@property (nonatomic, retain) NSString    *price;
@property (nonatomic, retain) NSString    *startdate;
@property (nonatomic, retain) NSString    *enddate;
@property (nonatomic, retain) NSString    *thumb;
@property (nonatomic, retain) NSString    *description;
@property (nonatomic, retain) NSString    *rooms;
@property (nonatomic, retain) NSString    *sleeps;
@property (nonatomic, retain) NSString    *bath;
@property (nonatomic, retain) NSString    *facility;
@property (nonatomic, retain) NSString    *ranking;
@property (nonatomic, retain) NSString    *guest;
@property (nonatomic, retain) NSString    *favoriteDate;

-(id)init;
-(NSInteger)getYachtId;
-(void)setYachtId:(NSInteger)yid;
-(NSInteger)getFavoriteId;
-(void)setFavoriteId:(NSInteger)fid;

@end
