//
//  YashtBookingController.m
//  TabBarAnimation
//
//  Created by Askone on 8/10/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "YashtBookingController.h"
#import "AsyncImageView.h"
#import "Constants.h"

@implementation YashtBookingController
@synthesize tableView = _tableView;
@synthesize httpResponse;
@synthesize item;
@synthesize ContentsArr;
@synthesize baseURL;
@synthesize navBar;
#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
	[super viewDidLoad];
	[self getHttpResponse:nil];
	
	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(30, 0, 400, 44)];
	label.backgroundColor = [UIColor clearColor];
	label.font = [UIFont boldSystemFontOfSize:18.0];
	label.textAlignment = UITextAlignmentCenter;
	label.textColor =[UIColor whiteColor];
	label.text= @"Charter Destination";
	self.navBar.topItem.titleView = label;		
	[label release];
	
}


-(void)getHttpResponse:(id)sender {
	
	self.httpResponse = [[NSMutableArray alloc]init];
	baseURL = [[NSURL URLWithString:@"http://www.charterdigest.com/iPhone/index.php?reg=regions"] retain];
	NSURLRequest *request = [NSURLRequest requestWithURL:baseURL];
	[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
	NSString * strNew = [[NSString alloc] initWithContentsOfURL:baseURL encoding:NSUTF8StringEncoding error:nil];
    if (strNew != nil) {

	NSArray *arr =[strNew componentsSeparatedByString:@"</br>"];
	for (int i=0;i<[arr count]-1; i++) {
		self.ContentsArr = [[arr objectAtIndex:i] componentsSeparatedByString:@"|"];
		self.item = [[NSMutableDictionary alloc] init];
		if ([self.ContentsArr count]>=1) {
			[self.item setObject:[ContentsArr objectAtIndex:0] forKey:@"id"];
			[self.item setObject:[ContentsArr objectAtIndex:1] forKey:@"title"];
			[self.httpResponse addObject:self.item];
			
		}
        [self.item release];
	}
        
    }
}


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	// Return the number of sections.
	return 1;
}




- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.httpResponse count];
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"ImageCell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	}
	else {
		AsyncImageView* oldImage = (AsyncImageView*)
		[cell.contentView viewWithTag:999];
		[oldImage removeFromSuperview];
	}
	
	self.tableView.backgroundColor = [UIColor clearColor];
	
	UILabel * subcategory =[[UILabel alloc]init];
	subcategory.backgroundColor = [UIColor clearColor];
	subcategory.textColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	subcategory.highlightedTextColor = [UIColor whiteColor];
	subcategory.frame=CGRectMake(10, 10,290,35);
	subcategory.text=[[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"title"];
	subcategory.font = [UIFont fontWithName:@"Arial" size:15];
	cell.accessoryView = subcategory;
	[subcategory release];
	
	UIImageView *selectedBackground = [[UIImageView alloc] initWithFrame:CGRectMake(0,0, 320,100)];
	selectedBackground.backgroundColor = [UIColor orangeColor];
	[cell setSelectedBackgroundView:selectedBackground];
    [selectedBackground release];
		
	self.tableView.backgroundColor = [UIColor clearColor];
	cell.backgroundColor = [UIColor clearColor];
	self.tableView.separatorColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	
	return cell;
	
}




- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 45;
	
}



#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	NSString *takeValue = [[self.httpResponse objectAtIndex:indexPath.row]objectForKey:@"title"];
	CityName = takeValue;
//	NSLog(@"city %@", CityName);
	[self dismissModalViewControllerAnimated:YES];
}



- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
}

#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
	[super didReceiveMemoryWarning];
	
	// Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	// Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
	// For example: self.myOutlet = nil;
	self.tableView = nil;
	self.httpResponse = nil;
	self.item = nil;
	self.ContentsArr = nil;
	self.baseURL = nil;
	
}

-(IBAction)DismodelController{
	
	[self dismissModalViewControllerAnimated:YES];
}

- (void)dealloc {
	[super dealloc];
	
	[self.tableView release];
	[httpResponse release];
	[item release];
	[ContentsArr release];
	[baseURL release];
}


@end

