//
//  MainViewController.m
//  TabBarAnimation
//
//  Created by Askone on 8/11/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "MainViewController.h"
#import "YashtBookingController.h"
#import "Constants.h"
#import <QuartzCore/QuartzCore.h>
#import "SHKItem.h"
#import "SHKFacebook.h"
#import "SHKTwitter.h"
#import "SHKMail.h"
#import "SHK.h"
#import "AboutUsController.h"
#import "SearchViewController.h"
#import "YachtAppDelegate.h"
#import "DetailViewController.h"
#import "PickerController.h"
#import "CalenderViewController.h"
#import "YachtModel.h"
#import "AsyncImageView.h"
#import "DetailRootViewController.h"

@interface NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding;
@end

@implementation NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding
{
	return (NSString *) CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)self,
																NULL, (CFStringRef)@";@$+{}<>,",
																CFStringConvertNSStringEncodingToEncoding(encoding));
}  
@end

#define kDatePickerTag 200
#define SelectButtonIndex 1
#define CancelButtonIndex 2

@implementation MainViewController
@synthesize DetinationTextField;
@synthesize ShareView;
@synthesize windowAlert;
@synthesize searchRegion;
@synthesize YachtTypeLabel;
@synthesize tableView;
@synthesize searchTableView;
@synthesize data, searchView;
@synthesize cellArray;
@synthesize sController;
@synthesize currentDate,NextDate;
@synthesize activityIndicator, searchString;
@synthesize dateOneCompare, dateTwoCompare, m_searchBar;
@synthesize pickingSort;
@synthesize pickerControler;
@synthesize pickerView;
@synthesize httpResponse;
@synthesize httpResponse1;
@synthesize item;
@synthesize ContentsArr;
@synthesize baseURL;
@synthesize yachtTypeArray;
@synthesize deletedfavoriteIdList;
@synthesize infoTableView;
@synthesize httpResponseSearch;
//@synthesize allAddressArray;

NSString *defaultEndDate;

-(IBAction) buttonPressed {
	
	myButton.hidden = YES;
	CheckResultForFilter = 0;
	CalenderViewController *cController = [[CalenderViewController alloc] init];
        
    [self.navigationController pushViewController:cController animated:YES];
	[cController release];
	
}


-(IBAction)checkOutAction{
	
	myButton.hidden = YES;
	CheckResultForFilter = 1;
	CalenderViewController *cController = [[CalenderViewController alloc] init];
	[self.navigationController pushViewController:cController animated:YES];
	[cController release];
	
	
}

#pragma mark -
#pragma mark SearchBar Handler methods

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar 
{ 
	[recent setEnabled:YES] ;
	[share setEnabled:YES] ;
	[setting setEnabled:YES] ;
	[information setEnabled:YES] ;
    [search setEnabled:YES] ;
    [self.m_searchBar resignFirstResponder];

} 

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar
{
    [recent setEnabled:YES] ;
	[share setEnabled:YES] ;
	[setting setEnabled:YES] ;
	[information setEnabled:YES] ;
    [search setEnabled:YES] ;
    [self.m_searchBar resignFirstResponder];
//    [appDelegate hiddenSplashView];
	[self.m_searchBar setText:@""];
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    return YES;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar
{
    return YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
   
    self.searchString = searchText;
    if ([searchText isEqualToString:@""]) {
        [self.httpResponseSearch removeAllObjects];
        [self.searchTableView reloadData];
        [recent setEnabled:NO] ;
        [share setEnabled:NO] ;
        [setting setEnabled:NO] ;
        [information setEnabled:NO] ;
        [search setEnabled:NO] ;
        [self.m_searchBar becomeFirstResponder];

        return;
    }
//    [appDelegate showSplashView:@"Searching..."];
    isSearchState = YES;
    if(searchType == nameSearch)
    {
        [self getHttpResponseSearch:nil]; 
    }
    else
    {
        [self getHttpResponseSearch:nil]; 
    }  
    if ([self.httpResponseSearch count] > 0) {
        [recent setEnabled:NO] ;
        [share setEnabled:NO] ;
        [setting setEnabled:NO] ;
        [information setEnabled:NO] ;
        [search setEnabled:NO] ;
    }
    else
    {
        [recent setEnabled:YES] ;
        [share setEnabled:YES] ;
        [setting setEnabled:YES] ;
        [information setEnabled:YES] ;
        [search setEnabled:YES] ;
    }

    [self.m_searchBar becomeFirstResponder];
    [self.searchTableView reloadData];
}

-(IBAction)decisionMaker:(id)sender{
	
	if ([sender isEqual:share]) {
		viewSelectState = shareState;
        isEditFlag = NO;
        self.navigationItem.rightBarButtonItem = nil;
        self.navigationItem.leftBarButtonItem = nil;
		if (flag) {
			
			if (ShareView !=nil) {
				self.ShareView = [[[UIView alloc] initWithFrame:CGRectMake(0, 480, 320, 272)] autorelease];
				[self.ShareView setBackgroundColor:[UIColor blackColor]];
				ShareView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
				ShareView.clipsToBounds = YES;
				ShareView.layer.cornerRadius = 10;
				[self.ShareView setAlpha:.87];
				
				[email addTarget:self action:@selector(shareApplication:) forControlEvents:UIControlEventTouchUpInside];
				[twitter addTarget:self action:@selector(shareApplication:) forControlEvents:UIControlEventTouchUpInside];
				[facebook addTarget:self action:@selector(shareApplication:) forControlEvents:UIControlEventTouchUpInside];
				[cancel addTarget:self action:@selector(shareApplication:) forControlEvents:UIControlEventTouchUpInside];
				
				[self.windowAlert addSubview:email];
				[self.windowAlert addSubview:twitter];
				[self.windowAlert addSubview:facebook];
				[self.windowAlert addSubview:cancel];
				[self.ShareView addSubview:windowAlert];
				[self.view addSubview:ShareView];
				
			}
			
			CGContextRef context = UIGraphicsGetCurrentContext();
			[UIView beginAnimations:nil context:context];
			[UIView setAnimationCurve:UIViewAnimationCurveLinear];
			[UIView setAnimationDuration:0.3];
			ShareView.frame = CGRectMake(0, 173, 320, 272);
			[UIView commitAnimations];
		}
		
		else {
			
			CGContextRef context = UIGraphicsGetCurrentContext();
			[UIView beginAnimations:nil context:context];
			[UIView setAnimationCurve:UIViewAnimationCurveLinear];
			[UIView setAnimationDuration:0.7];
			ShareView.frame = CGRectMake(0, 480, 320, 272);
			[UIView commitAnimations];
		}
		flag = (flag)?FALSE:TRUE;
	}
	else if ([sender isEqual:information]){
        self.navigationItem.rightBarButtonItem = nil;
        self.navigationItem.leftBarButtonItem = nil;
        isEditFlag = NO;
        viewSelectState = informationState;
        [recentsView removeFromSuperview];
        [self.searchView removeFromSuperview];        
		[self.view addSubview:aboutUsView];

        [self.infoTableView reloadData];

	}
	else if ([sender isEqual:recent]){
        if (appDelegate.favoriteArray) {
            [appDelegate.favoriteArray removeAllObjects];
        }
        appDelegate.favoriteArray = [appDelegate.dbManager selectYachtListFromDB:0];
        editBarItem.enabled = YES;
        if ([appDelegate.favoriteArray count] > 0) {
            self.navigationItem.rightBarButtonItem = editBarItem;
            [self.tableView setEditing:YES animated:YES];
        }
        else
        {
            self.navigationItem.rightBarButtonItem = nil;
        }
        
        self.navigationItem.leftBarButtonItem = nil;
        isEditFlag = NO;
        viewSelectState = recentState;

        [aboutUsView removeFromSuperview];
        [self.searchView removeFromSuperview];
        [self.tableView reloadData];
        
		[self.view addSubview:recentsView];  
        

	}
    else if ([sender isEqual:search]){
        self.navigationItem.rightBarButtonItem = nil;
        self.navigationItem.leftBarButtonItem = nil;
        isEditFlag = NO;
        viewSelectState = mainSearchState;
        searchType = noneSearch;
        searchViewState = YES;
        [aboutUsView removeFromSuperview];
        [recentsView removeFromSuperview];
        [self.searchTableView reloadData];
        [self.view addSubview:self.searchView]; 
        
        
	}
}
-(IBAction)search:(id)sender
{
    searchViewState = YES;
    appDelegate.yachtArray = [appDelegate.dbManager selectYachtListFromDB:1];
    [aboutUsView removeFromSuperview];
    [recentsView removeFromSuperview];
    [self.tableView reloadData];
    [self.view addSubview:self.searchView];    
    
}

-(IBAction)showHome:(id)sender
{
    viewSelectState = homeState;
    self.navigationItem.rightBarButtonItem = nil;
    self.navigationItem.leftBarButtonItem = nil;
    [aboutUsView removeFromSuperview];
    [recentsView removeFromSuperview];
    [self.searchView removeFromSuperview];
}

-(IBAction)searchCancel:(id)sender
{
    searchViewState = NO;
    [self.searchView removeFromSuperview];
    self.navigationItem.leftBarButtonItem = nil;
    
}

-(void)shareApplication:(id)sender{
	
	NSString *textString = @"This ia a great little Yacht booking app on your iPhone - you can download it for free at:-";
	if ([sender isEqual:email]) {
		SHKItem *item1 = [SHKItem text:textString];
		[SHKMail shareItem:item1];
		[self dismissModalAlertSheet];
	}
	if ([sender isEqual:facebook]) {
		SHKItem *itemFacebook = [SHKItem text:textString];
		[SHKFacebook shareItem:itemFacebook];
		[self dismissModalAlertSheet];
	}
	if ([sender isEqual:twitter]) {
		SHKItem *itemTwitter = [SHKItem text:textString];
		[SHKTwitter shareItem:itemTwitter];
		[self dismissModalAlertSheet];
	}
	if ([sender isEqual:cancel]) {
		[self dismissModalAlertSheet];
	}
}

-(void)dismissModalAlertSheet{
	
	CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveLinear];
	[UIView setAnimationDuration:0.3];
	ShareView.frame = CGRectMake(0, 480, 320, 272);
	[UIView commitAnimations];
	

}

- (void)clickEditButton
{
	isEditFlag = YES;
	[self.navigationItem setLeftBarButtonItem:cancelBarItem animated:YES];
	[self.navigationItem setRightBarButtonItem:doneBarItem animated:YES];
    if (deletedfavoriteIdList) {
        [deletedfavoriteIdList removeAllObjects];
    }
    else
    {
        deletedfavoriteIdList = [[NSMutableArray alloc] init];
    }
    [self.tableView setEditing:YES animated:YES];
    [self.tableView reloadData];
}

-(void)clickDoneButton
{
	if ([self.deletedfavoriteIdList count] > 0){
        isEditFlag = NO;
		for (int i=0;i<[self.deletedfavoriteIdList count];i++){
			NSNumber* tempId = (NSNumber*)[self.deletedfavoriteIdList objectAtIndex:i];
			NSString *query = [NSString stringWithFormat:@"DELETE FROM %@ WHERE %@ = %d", YACHET_FAVORITE_TABLE_NAME, FAVORITE_FIELD_FAVORITEID, [tempId intValue]];
			[appDelegate.dbManager InsertDataToDB:query];		
		}
		[self.navigationItem setLeftBarButtonItem:nil animated:YES];
        [self.navigationItem setRightBarButtonItem:editBarItem animated:YES];
        [self.tableView setEditing:NO animated:YES];
        if (appDelegate.favoriteArray) {
            [appDelegate.favoriteArray removeAllObjects];
        }
        appDelegate.favoriteArray = [appDelegate.dbManager selectYachtListFromDB:0];
        [self.tableView reloadData];
	}else{
		isEditFlag = NO;
		[self.navigationItem setLeftBarButtonItem:nil animated:YES];
		if ([appDelegate.favoriteArray count] <= 0)
			[self.navigationItem setRightBarButtonItem:nil animated:YES];
		else
			[self.navigationItem setRightBarButtonItem:editBarItem animated:YES];
		[self.tableView setEditing:NO animated:YES];
        if (appDelegate.favoriteArray) {
            [appDelegate.favoriteArray removeAllObjects];
        }
        appDelegate.favoriteArray = [appDelegate.dbManager selectYachtListFromDB:0];
        [self.tableView reloadData];
	}
    if ([appDelegate.favoriteArray count] > 0) {
        editBarItem.enabled = YES;
    }
    else
    {
        editBarItem.enabled = NO;
    }
}

-(void)clickCancelButton
{
    if(viewSelectState == recentState) {
        if (appDelegate.favoriteArray) {
            [appDelegate.favoriteArray removeAllObjects];
        }
	appDelegate.favoriteArray = [appDelegate.dbManager selectYachtListFromDB:0];
	isEditFlag = NO;
	[self.tableView setEditing:NO animated:YES];
	[self.tableView reloadData];	
	[self.navigationItem setLeftBarButtonItem:nil animated:YES];
	if ([appDelegate.favoriteArray count] <= 0)
		[self.navigationItem setRightBarButtonItem:nil animated:YES];
	else	
		[self.navigationItem setRightBarButtonItem:editBarItem animated:YES];	
        
        
    }
    else
    {
        searchType = noneSearch;
        self.navigationItem.leftBarButtonItem = nil;
        self.navigationItem.rightBarButtonItem = nil;
        [recent setEnabled:YES] ;
        [share setEnabled:YES] ;
        [setting setEnabled:YES] ;
        [information setEnabled:YES] ;
        [search setEnabled:YES] ;
        [self.m_searchBar resignFirstResponder];
        [self.searchTableView reloadData];
    }
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	[super viewDidLoad];
    appDelegate = [YachtAppDelegate sharedAppDelegate];
    viewSelectState = homeState;
    searchViewState = NO;
    searchType = noneSearch;
    isEditFlag = NO;
//    addressCount = 0;
    if (self.httpResponseSearch) {
        [self.httpResponseSearch removeAllObjects];
    }
    else
    {
        self.httpResponseSearch = [[NSMutableArray alloc]init];
    }
    self.navigationItem.rightBarButtonItem = nil;

//    [self getHttpResponse:nil];
//    [self getHttpResponse1:nil];
    self.yachtTypeArray = [[NSMutableArray alloc] init];
    [yachtTypeArray addObject:@"yacht by name"];
    [yachtTypeArray addObject:@"yacht by manufacturer"];

    
    [self.m_searchBar.layer setCornerRadius:7.0];
    [self.m_searchBar.layer setMasksToBounds:YES];
	
    editBarItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Edit", @"") style:UIBarButtonItemStylePlain target:self action:@selector(clickEditButton)];
	cancelBarItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(clickCancelButton)];
	doneBarItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(clickDoneButton)];
    
	
	myButton.hidden = NO;
	
	self.currentDate = [NSDate date];
	self.NextDate = [NSDate date];
	
	flag = TRUE;
	flag2 = TRUE;
	UIBarButtonItem *BarButtonItem = [[UIBarButtonItem alloc] init];
	BarButtonItem.title = @"Back";
	self.navigationItem.backBarButtonItem = BarButtonItem;
	[BarButtonItem release];
	
//	[searchRegion setImage:[UIImage imageNamed:@"button1.png"] forState:UIControlStateNormal];
	
	Nights = 1;
	Rooms = 1;
	
	NumberOfNightsLabel.text = @"1";
	GuestPerRoomLabels.text =  @"1";
	
	if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad){
		//this is iPad
	} 
	
	DetinationTextField.backgroundColor = [UIColor clearColor];
	DetinationTextField.delegate = self;
	DetinationTextField.borderStyle = UITextBorderStyleRoundedRect;
	DetinationTextField.font = [UIFont fontWithName:@"Helvetica" size:13];
	DetinationTextField.placeholder = @"Charter Destination";
	DetinationTextField.autocorrectionType = UITextAutocorrectionTypeNo; 
	DetinationTextField.keyboardType = UIKeyboardTypeAlphabet;
	DetinationTextField.returnKeyType = UIReturnKeyDone;
	DetinationTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
	[DetinationTextField release];
	
	CheckInDateLabel.font = [UIFont systemFontOfSize:14];
	NumberOfNightsLabel.font = [UIFont systemFontOfSize:14];
	GuestPerRoomLabels.font = [UIFont systemFontOfSize:14];
	dateCheckOutLabel.font =  [UIFont systemFontOfSize:14];
	
	self.navigationItem.titleView = [[UIImageView alloc] initWithImage: [UIImage imageNamed:@"logo.png"]];
	self.navigationController.navigationBar.tintColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];//[[UIColor alloc]initWithRed:0.100 green:0.280 blue:0.800 alpha:1.0];
	self.m_searchBar.tintColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	NSArray *cellTextArr = [[NSArray alloc] initWithObjects:@"About Us",@"Review App in App Store",@"Cancellations",@"Disclaimer",nil];
	self.cellArray = cellTextArr;
    
    self.searchTableView.separatorColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
    self.tableView.separatorColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
    
}

-(void)GotoWebURL:(id)sender{
	
	NSURL *url = [ [ NSURL alloc ] initWithString: @"http://www.charterdigest.com/" ];
	[[UIApplication sharedApplication] openURL:url];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[textField resignFirstResponder]; 
	return YES;
}


-(IBAction)TotalGuestInRoom:(id)sender{
	
	if ([sender isEqual:AdditionToGuestRoom]) {
		if(Rooms<=20)
			Rooms++;
		NSString *SubtractGuest =[NSString stringWithFormat:@"%d",Rooms];
		GuestPerRoomLabels.text = SubtractGuest;	
	}
	else if ([sender isEqual:SubtractFromGuestRoom]){
		if(Rooms >1)
			Rooms--;
		NSString *SubtractNights =[NSString stringWithFormat:@"%d",Rooms];
		GuestPerRoomLabels.text = SubtractNights;	
	}
}


-(IBAction)pushController:(id)sender{
	
	if ([sender isEqual:searchHotels]) {
		myButton.hidden = YES;
		YashtBookingController *YVController = [[YashtBookingController alloc] initWithNibName:@"YashtBookingController" bundle:nil];
		[self presentModalViewController:YVController animated:YES];
		[YVController release];
	}
	
}

-(void)viewWillAppear:(BOOL)animated{
	
	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter] removeObserver:self];

	myButton.hidden = NO;
	searchViewState = NO;
    
    
	DetinationTextField.text = CityName;
    
	//DetinationTextField.text = @"Virgin Islands (British)";
	
	NSString *textfieldData = DetinationTextField.text;
	NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
	[prefs setObject:textfieldData forKey:@"CityName"];
	
	YachtTypeLabel.text = yacthFromDelegate;
	if (yacthFromDelegate ==nil) {
		YachtTypeLabel.text = @"Yacht Charter Type";
		//YachtTypeLabel.text = @"All";

	}
	
	NSString *aYacht = YachtTypeLabel.text;
	NSUserDefaults *prefs1 = [NSUserDefaults standardUserDefaults];
	[prefs1 setObject:aYacht forKey:@"YachtType"];
	
	
	
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"eee, MMM dd, YYYY"];
        
	
	if (ArrivalDate==nil) 
    {
		NSDateFormatter *formatter2 = [[NSDateFormatter alloc] init];
        [formatter2 setDateFormat:@"MMM dd, YYYY"];
        CheckInDateLabel.text = [formatter stringFromDate:self.currentDate];
        [formatter2 release];
	}
    else 
    {
		
        
        NSDateFormatter *formatter2 = [[NSDateFormatter alloc] init];
        [formatter2 setDateFormat:@"eee, MMM dd, YYYY"];
        
        [formatter2 setDateFormat:@"MMM dd, YYYY"];
        CheckInDateLabel.text = ArrivalDate;
        [formatter2 release];

	}
    
    if (DeparatureDate==nil) {
        if(ArrivalDate4==nil)
        {
            self.NextDate = [NSDate dateWithTimeInterval:(24*60*60*7) sinceDate:[NSDate date]]; 
            NSDateFormatter *formatter2 = [[NSDateFormatter alloc] init];
            [formatter2 setDateFormat:@"dd-MM-yyyy HH:mm:ss"];
            defaultEndDate = [formatter2 stringFromDate:self.NextDate];
            [formatter2 setDateFormat:@"MMM dd, YYYY"];
            [formatter2 release];
            
        }
        else
        {
            NSDateFormatter *formatter2 = [[NSDateFormatter alloc] init];
            [formatter2 setDateFormat:@"dd-MM-yyyy HH:mm:ss"];
            
           NSDate *displayDate = [formatter2 dateFromString:ArrivalDate4]; 
            self.NextDate = [NSDate dateWithTimeInterval:(24*60*60*7) sinceDate:displayDate];
            defaultEndDate = [formatter2 stringFromDate:self.NextDate];
            [formatter2 setDateFormat:@"MMM dd, YYYY"];
            [formatter2 release];
        }
		dateCheckOutLabel.text = [formatter stringFromDate:self.NextDate];
	}
    else 
    {
		dateCheckOutLabel.text = DeparatureDate;
        NSDateFormatter *formatter2 = [[NSDateFormatter alloc] init];
        [formatter2 setDateFormat:@"MMM dd, YYYY"];
        [formatter2 release];
	}
    
}

-(IBAction)ConnectionWizard:(id)sender{
	
	
	if (appDelegate.hostActive == NO) {
		
		UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Error" message:@"Please Check Wi-Fi Connectivity" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
	else {
		
		[self performSearch:sender];
	}	
}

-(IBAction)performSearch:(id)sender{
	
//	[activityIndicator startAnimating];
    
	myButton.hidden = YES;
	UIAlertView *alertView = [[[UIAlertView alloc] initWithTitle:@"Field Missing" message:@"" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
	if (DetinationTextField.text==nil) {
		alertView.message = @"Please Select Charter Destination";
		[alertView show];
		
	}else if (YachtTypeLabel.text== @"Yacht Charter Type") {
		
		alertView.message = @"Please Select Type of Yacht Charter";
		[alertView show];
	}else {
        
        NSDateFormatter *formatter2 = [[NSDateFormatter alloc] init];
        [formatter2 setDateFormat:@"dd-MM-yyyy HH:mm:ss"];
        NSDate *sdate = [formatter2 dateFromString:ArrivalDate4];        
        NSDate *edate = [formatter2 dateFromString:DeparatureDate4];
        [formatter2 release];

        switch ([sdate compare:edate])
        {
			case NSOrderedAscending:
				
				[self countDates:sender];
                if (sController) {
                    sController = nil;
                }
				sController = [[SearchViewController alloc] initWithNibName:@"SearchViewController" bundle:nil];
				sController.getDetination = DetinationTextField.text;
				sController.getGuest = GuestPerRoomLabels.text;
				sController.getType = YachtTypeLabel.text;
				sController.getDateIn = CheckInDateLabel.text;
				sController.getDateOut = dateCheckOutLabel.text;
                sController.isEnter = YES;
				[self.navigationController pushViewController:sController animated:YES];
				[sController release];
				
				break;  
			case NSOrderedSame:
				
				[self countDates:sender];
                if (sController) {
                    sController = nil;
                }
				sController = [[SearchViewController alloc] initWithNibName:@"SearchViewController" bundle:nil];
				NSString *dayCount = [NSString stringWithFormat:@"%d", days];
				sController.getDetination = DetinationTextField.text;
				sController.getGuest = GuestPerRoomLabels.text;
				sController.getType = YachtTypeLabel.text;
				sController.getDateIn = CheckInDateLabel.text;
				sController.getDateOut = dateCheckOutLabel.text;
				sController.totalDay = dayCount;
                sController.isEnter = YES;
				[self.navigationController pushViewController:sController animated:YES];
				[sController release];
				
				break;  
			case NSOrderedDescending:  {
				alertView.message = @"Error While creating Dates";
				[alertView show];
			}
				break;
		} 		
	}	
}


-(IBAction)YachtTypeAction{
	myButton.hidden = YES;
    if ([httpResponse1 count] <= 0) {
        [self getHttpResponse1:nil];
    }
	PickerController *pController = [[PickerController alloc] initWithNibName:@"PickerController" bundle:nil];
	[self presentModalViewController:pController animated:YES];
	[pController release];
	
}

-(void)countDates:(id)sender{

}

- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
//	NSLog(@"viewWillDisappear");
	//activityIndicator.hidesWhenStopped = YES;
}


- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
//	[activityIndicator stopAnimating];

}

#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if(viewSelectState == mainSearchState)
    {
        return 1;
    }
    else
    {
        return 1; 
    }    
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
   
        if (viewSelectState == recentState) {
            
            return [appDelegate.favoriteArray count];
        }
        else if(viewSelectState == mainSearchState)
        {
            if (searchType == noneSearch) {
                return 2;
            }
            else
            {
                if (httpResponseSearch && [httpResponseSearch count] > 0) {
                    return [self.httpResponseSearch count]; 
                }   
                else
                {
                    return 0;
                }
                               
            }

        }
        else
        {
            return [self.cellArray count];
        }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (viewSelectState == recentState) {
        
        return 120;
    }
    else if(viewSelectState == mainSearchState)
    {
        if (searchType == noneSearch) {
            return 44;
        }
        else
        {
            return 44;
        }
        
    }
    else
    {
        return 44;
    }

	
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [table dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }


    if (viewSelectState == recentState) {
        
        cell.textLabel.text = @"";
        cell.detailTextLabel.text = @"";
        
        YachtModel  *model = (YachtModel  *)[appDelegate.favoriteArray objectAtIndex:indexPath.row];
       
        self.tableView.backgroundColor = [UIColor clearColor];
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake(0.0, 0.0, 270, 120);
        [imageView setBackgroundColor:[UIColor clearColor]];
        
        UILabel *label=[[UILabel alloc]init];
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
        label.highlightedTextColor = [UIColor whiteColor];
        label.frame=CGRectMake(20, 0,200,20);
        label.font = [UIFont systemFontOfSize:14];
        label.lineBreakMode = UILineBreakModeWordWrap;
        label.numberOfLines = 2;
        label.text=model.yachtName;
        [imageView addSubview:label];
        [label release];
        
        UILabel * price =[[UILabel alloc]init];
        price.backgroundColor = [UIColor clearColor];
        price.textColor = [UIColor orangeColor];
        price.frame=CGRectMake(210, 0,100,20);
        price.font = [UIFont boldSystemFontOfSize:14];
        price.textAlignment = UITextAlignmentLeft;
        NSString *priceString = model.price;
        price.text = [NSString stringWithFormat:@"$%@", priceString];
        [imageView addSubview:price];
        [price release];
        
        UIImageView *starImage = [[UIImageView alloc] initWithFrame:CGRectMake(15, 100, 80, 16)];
        NSString *starString = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"rating"];
        
        if ([starString isEqual:@"0"]) {
            starImage.image = [UIImage imageNamed:nil];
        }
        else if ([starString isEqual:@"1"]) {
            NSString *OneStar = [starString stringByAppendingFormat:@".png"];
            starImage.image = [UIImage imageNamed:OneStar];
        }
        else if ([starString isEqual:@"2"]) {
            NSString *TwoStar = [starString stringByAppendingFormat:@".png"];
            starImage.image = [UIImage imageNamed:TwoStar];
        }
        else if ([starString isEqual:@"3"]) {
            NSString *ThreeStar = [starString stringByAppendingFormat:@".png"];
            starImage.image = [UIImage imageNamed:ThreeStar];
        }
        else if ([starString isEqual:@"4"]) {
            NSString *fourStar = [starString stringByAppendingFormat:@".png"];
            starImage.image = [UIImage imageNamed:fourStar];
        }
        else if ([starString isEqual:@"5"]) {
            NSString *fiveStar = [starString stringByAppendingFormat:@".png"];
            starImage.image = [UIImage imageNamed:fiveStar];
        }
        
        [imageView addSubview:starImage];
        [starImage release];
        
        UIWebView * description =[[UIWebView alloc]init];
        description.backgroundColor = [UIColor clearColor];
        description.frame=CGRectMake(85, 20, 180,70);
        description.backgroundColor = [UIColor clearColor];
        [description loadHTMLString:model.description baseURL:nil];
        [imageView addSubview:description];
        [description release];
        
        UILabel * fdate =[[UILabel alloc]init];
        fdate.backgroundColor = [UIColor clearColor];
        fdate.textColor = [UIColor blueColor];
        fdate.frame=CGRectMake(90, 95, 170,20);
        fdate.font = [UIFont systemFontOfSize:14];
        fdate.textAlignment = UITextAlignmentLeft;
        fdate.lineBreakMode = UILineBreakModeWordWrap;
        fdate.numberOfLines = 3;
        NSString*fText = [NSString stringWithFormat:@"favorite date: %@",model.favoriteDate];
        fdate.text =fText;  
        [imageView addSubview:fdate];
        [fdate release];
        
        CGRect frame = CGRectMake(10, 20, 70, 70);
        
        UIImageView * imgView = [[UIImageView alloc] initWithFrame:frame];
        imgView.image = [UIImage imageWithContentsOfFile:model.thumb];
        imgView.backgroundColor = [UIColor clearColor];
        [imageView addSubview:imgView];
        [imgView release];
        [cell.contentView addSubview:imageView];
        [imageView release];
        cell.backgroundColor = [UIColor clearColor];
        cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
                        
    }
    else if(viewSelectState == mainSearchState)
    {
        cell.detailTextLabel.text = @"";
        cell.textLabel.text = @"";
        
        cell.textLabel.textColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
        if (searchType == noneSearch) {
            cell.textLabel.font = [UIFont systemFontOfSize:17];
            if (indexPath.row == 0) {
                cell.textLabel.text = [yachtTypeArray objectAtIndex:0];
            }
            else
            {
                cell.textLabel.text = [yachtTypeArray objectAtIndex:1];
            }
            cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
            cell.accessoryView = nil;
       
        }
        else
        {
            YachtModel  *model;
            if (self.httpResponseSearch && [self.httpResponseSearch count] > 0) {
 
                if (searchType == nameSearch) {
                    model = (YachtModel  *)[self.httpResponseSearch objectAtIndex:indexPath.row];
                }
                else
                {
                    model = (YachtModel  *)[self.httpResponseSearch objectAtIndex:indexPath.row];
                }
            
                cell.textLabel.text = model.yachtName;
                
            }
            else
            {
                cell.textLabel.text = @"";
            }
            
            cell.detailTextLabel.text = @"";
            
            self.searchTableView.backgroundColor = [UIColor clearColor];
           cell.textLabel.font = [UIFont systemFontOfSize:15];
            cell.backgroundColor = [UIColor clearColor];
            cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
            cell.accessoryView = nil;
            if (indexPath.row == [self.httpResponseSearch count]-1) {

                    [recent setEnabled:NO] ;
                    [share setEnabled:NO] ;
                    [setting setEnabled:NO] ;
                    [information setEnabled:NO] ;
                    [search setEnabled:NO] ;
                    [self.m_searchBar becomeFirstResponder];
            
            }
        }
    }
    else
    {
        cell.textLabel.text = [self.cellArray objectAtIndex:indexPath.row];
        cell.detailTextLabel.text = @"";
        cell.accessoryView = nil;
    }

    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if(viewSelectState == mainSearchState) {
    
        if (section == 0) {
            if (!self.m_searchBar) {
            
            self.m_searchBar = [[UISearchBar alloc] init];
            if (isSearchState) {
                self.m_searchBar.text = self.searchString;
                [recent setEnabled:NO] ;
                [share setEnabled:NO] ;
                [setting setEnabled:NO] ;
                [information setEnabled:NO] ;
                [search setEnabled:NO] ;
                [self.m_searchBar becomeFirstResponder];
            }
            else
            {
                self.m_searchBar.text = @"";
                [recent setEnabled:YES] ;
                [share setEnabled:YES] ;
                [setting setEnabled:YES] ;
                [information setEnabled:YES] ;
                [search setEnabled:YES] ;
                [self.m_searchBar resignFirstResponder];
            }
            self.m_searchBar.placeholder = [yachtTypeArray objectAtIndex:0];
            UITextField *searchBarTextField = [[self.m_searchBar subviews] objectAtIndex:1];
            searchBarTextField.returnKeyType = UIReturnKeyDone;

            self.m_searchBar.delegate = self;
            self.m_searchBar.showsCancelButton = YES;
            self.m_searchBar.backgroundColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
            self.m_searchBar.tintColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
            }
            return self.m_searchBar;
        }        
    }
    return nil;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
	if(viewSelectState == mainSearchState) {
        if (searchType == noneSearch) {
            return 0;
        }
        else if (searchType == nameSearch) 
        {
            return 60;
        }
        else
        {
            return 60;
        }
        
    }
    else
    {
        return 0;
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
	if (viewSelectState == recentState) {
        if (editingStyle == UITableViewCellEditingStyleDelete) {
            YachtModel  *model = (YachtModel  *)[appDelegate.favoriteArray objectAtIndex:indexPath.row];	
            NSInteger fid = [model getYachtId];

            [ deletedfavoriteIdList addObject:[[NSNumber alloc] initWithInt:fid] ];
            [appDelegate.favoriteArray removeObjectAtIndex:indexPath.row];
            [self.tableView reloadData];
        }
    }
	
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath 
{
    // The table view should not be re-orderable.
	return NO;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
	return isEditFlag;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return UITableViewCellEditingStyleDelete;
}


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
        if (viewSelectState == recentState) {
            if (!isEditFlag) {

                YachtModel  *model = (YachtModel  *)[appDelegate.favoriteArray objectAtIndex:indexPath.row];
                DetailRootViewController *detailViewController = [[DetailRootViewController alloc] initWithNibName:@"DetailRootViewController" bundle:nil];
                [detailViewController setBackstate:0];
                detailViewController.productID = [NSString stringWithFormat:@"%d",[model getFavoriteId]];
                
                detailViewController.price = model.price;
                NSString *date1 = [NSString stringWithFormat:@"%@",model.startdate];
                NSString *date2 = [NSString stringWithFormat:@" %@", model.enddate];
                NSString *detailDate = [date1 stringByAppendingFormat:@"--"];
                NSString *Append = [detailDate stringByAppendingString:date2];
                NSString *priceL = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"price"];
                
                detailViewController.YachtPriceStr = priceL;
                detailViewController.rankingYacht = model.ranking;
                detailViewController.YachtName1Str = model.yachtName;
                detailViewController.YachtDate1Str = Append;
                detailViewController.YachtGuest1Str = @"";
                detailViewController.YachtStay1Str = model.sleeps;
                
                [self.navigationController pushViewController:detailViewController animated:YES];
                [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
                [detailViewController release];
            }
        }
        else if(viewSelectState == mainSearchState)
        {
            YachtModel  *model ;
            if (searchType == noneSearch) {
                self.navigationItem.rightBarButtonItem = cancelBarItem;
                self.navigationItem.leftBarButtonItem = nil;
                if (indexPath.row == 0) {
                    [self.httpResponseSearch removeAllObjects];
                    searchType = nameSearch;  
                    isSearchState = NO;
                    [self.searchTableView reloadData];
                    [self.m_searchBar setText:@""];
                    return;
                }
                else
                {
                    [self.httpResponseSearch removeAllObjects];
                    searchType = manafySearch;  
                    isSearchState = NO;
                    [self.searchTableView reloadData];
                    [self.m_searchBar setText:@""];
                    return;
                }

            }
            else if (searchType == nameSearch) 
            {
                if (self.httpResponseSearch) {
                    model = (YachtModel  *)[self.httpResponseSearch objectAtIndex:indexPath.row];
                }              
            }
            else
            {
                if (self.httpResponseSearch) {
                    model = (YachtModel  *)[self.httpResponseSearch objectAtIndex:indexPath.row];
                }
            }           
            if (model) {
            DetailRootViewController *detailViewController = [[DetailRootViewController alloc] initWithNibName:@"DetailRootViewController" bundle:nil];
            [detailViewController setBackstate:0];
            detailViewController.productID = [NSString stringWithFormat:@"%d",[model getFavoriteId]];
            
            detailViewController.price = model.price;
            NSString *date1 = [NSString stringWithFormat:@"%@",model.startdate];
            NSString *date2 = [NSString stringWithFormat:@" %@", model.enddate];
            NSString *detailDate = [date1 stringByAppendingFormat:@"--"];
            NSString *Append = [detailDate stringByAppendingString:date2];
            NSString *priceL = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"price"];
            
            detailViewController.YachtPriceStr = priceL;
            detailViewController.rankingYacht = model.ranking;
            detailViewController.YachtName1Str = model.yachtName;
            detailViewController.YachtDate1Str = Append;
            detailViewController.YachtGuest1Str = @"";
            detailViewController.YachtStay1Str = model.sleeps;
            
            [self.navigationController pushViewController:detailViewController animated:YES];
            [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
            [detailViewController release];
                
            }

        }
        else
        {
            switch (indexPath.row) {
                case 0:{
                    myButton.hidden = YES;
                    AboutUsController *aController = [[AboutUsController alloc] initWithNibName:@"AboutUsController" bundle:nil];
                    [self.navigationController pushViewController:aController animated:YES];
                    [aController release];
                }break;
                case 1:{/*
                         myButton.hidden = YES;
                         path = [[NSBundle mainBundle] pathForResource:@"Disclaimer" ofType:@"txt"];
                         ecode = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
                         DetailViewController *dController = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:nil];
                         dController.textdata = ecode;
                         dController.navigationTitle = [cellArray objectAtIndex:indexPath.row];
                         [self.navigationController pushViewController:dController animated:YES];
                         [dController release];*/
                }break;
                case 2:{
                    myButton.hidden = YES;
                    path = [[NSBundle mainBundle] pathForResource:@"Cancellations" ofType:@"txt"];
                    ecode = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
                    DetailViewController *dController = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:nil];
                    dController.textdata = ecode;
                    dController.navigationTitle = [cellArray objectAtIndex:indexPath.row];
                    [self.navigationController pushViewController:dController animated:YES];
                    [dController release];
                }break;
                case 3:{
                    myButton.hidden = YES;
                    path = [[NSBundle mainBundle] pathForResource:@"Disclaimer" ofType:@"txt"];
                    ecode = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
                    DetailViewController *dController = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:nil];
                    dController.textdata = ecode;
                    dController.navigationTitle = [cellArray objectAtIndex:indexPath.row];
                    [self.navigationController pushViewController:dController animated:YES];
                    [dController release];			
                }break;
                default:
                    break;
            }
    }
}

-(IBAction)pickerViewGoDown{
	
	CGRect frame = self.pickerView.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.75];
	frame.origin.y = 480.0;
	self.pickerView.alpha = 0;
	self.pickerView.frame = frame;
	[UIView commitAnimations];
//    [appDelegate showSplashView:@"Searching..."];
    if(self.httpResponseSearch)
        [self.httpResponseSearch removeAllObjects];
    
//    [self getHttpResponseManiSearch:nil];
    self.navigationItem.rightBarButtonItem = cancelBarItem;
}

-(void)popPickerView{
	
    [self.pickerControler reloadAllComponents];
    [self.m_searchBar setText:@""];
    [recent setEnabled:YES] ;
	[share setEnabled:YES] ;
	[setting setEnabled:YES] ;
	[information setEnabled:YES] ;
    [search setEnabled:YES] ;
    [self.m_searchBar resignFirstResponder];
    [self.searchTableView reloadData];

    CGRect frame = self.pickerView.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.75];
	self.pickerView.alpha = 9;
	frame.origin.y = 180.0;
	self.pickerView.frame = frame;
	[UIView commitAnimations];
		
	
}

-(void)getHttpResponse:(id)sender {
	
	if (self.httpResponse) {
        [self.httpResponse removeAllObjects];
    }
    else
    {
        self.httpResponse = [[NSMutableArray alloc]init];
    }
	baseURL = [NSURL URLWithString:@"http://www.charterdigest.com/iPhone/index.php?reg=regions"];
    
    ASIHTTPRequest *aRequest = [ASIHTTPRequest requestWithURL:baseURL];
	[aRequest setDelegate:self];
	[aRequest startAsynchronous];
    
	NSURLRequest *request = [NSURLRequest requestWithURL:baseURL];
	[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
	NSString *strNew = [[NSString alloc] initWithContentsOfURL:baseURL encoding:NSUTF8StringEncoding error:nil];
    if (strNew != nil) {
        NSArray *arr =[strNew componentsSeparatedByString:@"</br>"];
        
        for (int i=0;i<[arr count]-1; i++) {
            self.ContentsArr = [[arr objectAtIndex:i] componentsSeparatedByString:@"|"];
            self.item = [[NSMutableDictionary alloc] init];
            if ([self.ContentsArr count]>=1) {
                [self.item setObject:[ContentsArr objectAtIndex:0] forKey:@"id"];
                [self.item setObject:[ContentsArr objectAtIndex:1] forKey:@"title"];
                [self.httpResponse addObject:self.item];			
            }
            [self.item release];
        }        
    }
    [strNew release];
}

-(void)getHttpResponse1:(id)sender{
	
	if (self.httpResponse1) {
        [self.httpResponse1 removeAllObjects];
    }
    else
    {
        self.httpResponse1 = [[NSMutableArray alloc]init];
    }

	baseURL = [NSURL URLWithString:@"http://www.charterdigest.com/iPhone/manufacturer.php?act=manufacturer"];
    
//    ASIHTTPRequest *aRequest = [ASIHTTPRequest requestWithURL:baseURL];
//	[aRequest setDelegate:self];
//	[aRequest startAsynchronous];
    
	NSURLRequest *request = [NSURLRequest requestWithURL:baseURL];
	[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
	NSString *strNew = [[NSString alloc] initWithContentsOfURL:baseURL encoding:NSUTF8StringEncoding error:nil];
    if (strNew != nil) {
        NSArray *arr =[strNew componentsSeparatedByString:@"</br>"];
        [strNew release];
        for (int i=0;i<[arr count]-1; i++) {
            self.ContentsArr = [[arr objectAtIndex:i] componentsSeparatedByString:@"|"];
            self.item = [[NSMutableDictionary alloc] init];
            if ([self.ContentsArr count]>=1) {
                if (![[ContentsArr objectAtIndex:0] isEqual:@"null"]) {
                    [self.item setObject:[ContentsArr objectAtIndex:0] forKey:@"manufacturer"];
//                    NSLog([ContentsArr objectAtIndex:0]);
                    [self.httpResponse1 addObject:self.item];
                }			
            }
            [self.item release];
        }
    }    
}

-(void)getHttpResponseSearch:(id)sender
{
    if (self.httpResponseSearch) {
        [self.httpResponseSearch removeAllObjects];
    }
    else
    {
        self.httpResponseSearch = [[NSMutableArray alloc]init];
    }
    
    if(searchType == nameSearch)
    {
        baseURL = [[NSURL URLWithString:[NSString stringWithFormat:@"http://www.charterdigest.com/iPhone/search.php?act=record&region=%@&ysearch=namesearch",self.searchString]] retain];
    }
    else
    {
        baseURL = [[NSURL URLWithString:[NSString stringWithFormat:@"http://www.charterdigest.com/iPhone/search.php?act=record&region=%@&ysearch=manufysearch",self.searchString]] retain];
    }      

	ASIHTTPRequest *aRequest = [ASIHTTPRequest requestWithURL:baseURL];
	[aRequest setDelegate:self];
	[aRequest startAsynchronous];
   
	NSURLRequest *request = [NSURLRequest requestWithURL:baseURL];
	[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
    
    NSString *strNew = [[NSString alloc] initWithContentsOfURL:baseURL encoding:NSUTF8StringEncoding error:nil];
    if (strNew != nil) {
        
        NSArray *arr =[strNew componentsSeparatedByString:@"</br>"];
        [strNew release];
        if (self.httpResponse) {
            [self.httpResponse removeAllObjects];
        }
        if (arr && [arr count] > 0) {
            NSString *m_path = @"";
            
            for (int i=0;i<[arr count]-1; i++) {
                self.ContentsArr = [[arr objectAtIndex:i] componentsSeparatedByString:@"~"];
                YachtModel *model = [[YachtModel alloc] init];
                if ([self.ContentsArr count]>=1) {
                    [model setFavoriteId:[[ContentsArr objectAtIndex:1] intValue]];
                    model.yachtName = [ContentsArr objectAtIndex:2];
                    model.price = [ContentsArr objectAtIndex:3];
                    NSData *imgData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[ContentsArr objectAtIndex:4]]];
                    m_path = [IMAGE_FOLDER stringByAppendingPathComponent:
                            [NSString stringWithFormat:@"%@.png", 
                             [ContentsArr objectAtIndex:1]]];
                    if ([[NSFileManager defaultManager] fileExistsAtPath:m_path]) {
                        [[NSFileManager defaultManager] removeItemAtPath:m_path error:nil];
                    }
                    [imgData writeToFile:m_path atomically:YES];
                    [imgData release];
                    
                    model.thumb = m_path;
                    model.description = [ContentsArr objectAtIndex:5];
                    model.ranking = [ContentsArr objectAtIndex:6];
                    model.facility = [ContentsArr objectAtIndex:7];

                    [self.httpResponseSearch addObject:model];			
                }

                [model release];
            }             
        }
    }
}

//-(void)getAddress:(NSString *)str
//{
//    NSString *contents = [[NSString alloc] initWithString:str];
//    NSRange range;
//    range = [contents rangeOfString:@"Go to page:"];
//    contents = [contents substringFromIndex:range.location + range.length];
//    range = [contents rangeOfString:@"</td>"];
//    contents = [contents substringToIndex:range.location];
//    range = [contents rangeOfString:@"<a href=\""];
//    
//    while (range.length > 0) {
//        contents = [contents substringFromIndex:range.location+range.length];
//        range = [contents rangeOfString:@"\">"];
//        
//        NSString *linkURL = [[NSString alloc] initWithFormat:@"http://www.charterdigest.com/%@",[contents substringToIndex:range.location]];
//        [self.allAddressArray addObject:linkURL];
//        [linkURL release];
//        contents = [contents substringFromIndex:range.location+range.length];
//        range = [contents rangeOfString:@"<a href=\""];
//    }  
//    [contents release];
//}
//
//-(void)againSearch:(NSString *)address
//{
////    NSLog(@"%d",[allAddressArray count]);
//    while([allAddressArray count] >= addressCount + 1) {
//        addressCount++;  
//        NSLog(@"%d",addressCount);
//        NSString *strUrl = [NSString stringWithFormat:@"http://www.charterdigest.com/index.php?user=search1&orderby=name&limit=%d",10*addressCount]; 
////        NSLog(strUrl);
//        self.baseURL = [[NSURL URLWithString:strUrl] retain];
////        NSURLRequest *request = [NSURLRequest requestWithURL:baseURL];
////        [[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
//        strNew = nil;
//        strNew = [[NSString alloc] initWithContentsOfURL:self.baseURL encoding:NSUTF8StringEncoding error:nil];
//        [self.baseURL release];
//        if (strNew != nil) {
//            [self parserSearch:strNew];
//            [strNew release];        
//        }
//        else
//        {
//            [strNew release];
//        }
//    }
//    
//}
//
//-(void)parserSearch:(NSString*)response
//{
//    NSRange range;
//    YachtModel*  model;
//    range = [response rangeOfString:@"<td style=\"font-family:tahoma;font-size:12px;border-bottom:2px solid black\">"];
//    NSString *path1=@"";
//    NSString *pid = @"";
//    
//    while (range.length > 0) {
//        response = [response substringFromIndex:range.location + range.length];
//        model = [[YachtModel alloc] init];
//        range = [response rangeOfString:@"style=\"font-family:tahoma;font-size:12px;\">"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"</b>"];
//        model.yachtName = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"Sleeps"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"</b>:"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<"];
//        model.sleeps = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"Ensuite Bathrooms"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"</b>:"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<"];
//        model.bath = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<a href='"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"/"];
//        [model setFavoriteId:[[response substringToIndex:range.location] intValue]];
//        pid = [response substringToIndex:range.location];
////        NSLog(@"%@",pid);
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<img src=temp/"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@" "];
//        NSData *imgData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://www.charterdigest.com/temp/%@",[response substringToIndex:range.location]]]];
//        path1 = [IMAGE_FOLDER stringByAppendingPathComponent:
//                 [NSString stringWithFormat:@"%@.png", 
//                  pid]];
//        if ([[NSFileManager defaultManager] fileExistsAtPath:path1]) {
//            [[NSFileManager defaultManager] removeItemAtPath:path1 error:nil];
//        }
//        [imgData writeToFile:path1 atomically:YES];
//        [imgData release];
//        
//        model.thumb = path1;
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<b>Price: "];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@" "];
//        model.price = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<td  style=\"font-family:tahoma;font-size:12px;text-align:justify\">"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"</td>"];
//        model.description = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        [self.httpResponseSearch addObject:model];
//        NSString* query = [NSString stringWithFormat:@"INSERT INTO %@ (%@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@) VALUES (%@, '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@');",YACHET_TABLE_NAME,
//                           YACHET_FIELD_PRODUCTID, 
//                           YACHET_FIELD_YACHTNAME, 
//                           YACHET_FIELD_PRICE, 
//                           YACHET_FIELD_STARTDATE, 
//                           YACHET_FIELD_ENDDATE,
//                           YACHET_FIELD_THUMB,
//                           YACHET_FIELD_DESCRIPTION,
//                           YACHET_FIELD_ROOMS,
//                           YACHET_FIELD_SLEEPS,
//                           YACHET_FIELD_BATH,
//                           YACHET_FIELD_FACILITY,
//                           YACHET_FIELD_RANKING,
//                           YACHET_FIELD_GUEST,
//                           YACHET_FIELD_DATE,
//                           pid,
//                           [appDelegate.dbManager replashQuery:model.yachtName],[appDelegate.dbManager replashQuery:model.price],[appDelegate.dbManager replashQuery:@"0000-00-00"],[appDelegate.dbManager replashQuery:@"0000-00-00"],[appDelegate.dbManager replashQuery:model.thumb],[appDelegate.dbManager replashQuery:model.description],[appDelegate.dbManager replashQuery:model.rooms],[appDelegate.dbManager replashQuery:model.sleeps],[appDelegate.dbManager replashQuery:model.bath],[appDelegate.dbManager replashQuery:model.facility],[appDelegate.dbManager replashQuery:model.ranking],@"",@""];
//        BOOL insertState = [appDelegate.dbManager InsertDataToDB:query];
//        if (insertState) {
////            NSLog(@"Insert success.");
//        }
//        else
//        {
////            NSLog(@"Insert fail.");
//        }
//        [model release];
//        
//        range = [response rangeOfString:@"<td style=\"font-family:tahoma;font-size:12px;border-bottom:2px solid black\">"];
//    }
////    NSLog(@"%d",[self.httpResponseSearch count]);
//}
//
//
//-(void)getHttpResponseNameSearch:(id)sender
//{
//    if (self.httpResponseSearch) {
//        [self.httpResponseSearch removeAllObjects];
//    }
//    else
//    {
//        self.httpResponseSearch = [[NSMutableArray alloc]init];
//    }
//    
//    self.httpResponseSearch = [appDelegate.dbManager selectYachtListFromDB:1 searchString:[appDelegate urlEncoded:self.searchString] searchField:YACHET_FIELD_YACHTNAME];
//    [self.searchTableView reloadData];
//
//}
//
//-(void)parserSearchByName:(NSString*)response
//{
//
//    NSRange range;
//    YachtModel*  model;
//
//    range = [response rangeOfString:@"<td style=\"font-family:tahoma;font-size:12px;border-bottom:2px solid black\">"];
//    NSString *path1=@"";
//    NSString *pid = @"";
//    
//    while (range.length > 0) {
//        response = [response substringFromIndex:range.location + range.length];
//        model = [[YachtModel alloc] init];
//        range = [response rangeOfString:@"style=\"font-family:tahoma;font-size:12px;\">"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"</b>"];
//        model.yachtName = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"Sleeps"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"</b>:"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<"];
//        model.sleeps = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//     
//        
//        range = [response rangeOfString:@"Ensuite Bathrooms"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"</b>:"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<"];
//        model.bath = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<a href='"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"/"];
//        [model setFavoriteId:[[response substringToIndex:range.location] intValue]];
//        pid = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<img src=temp/"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@" border=\"0\""];
//        NSData *imgData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://www.charterdigest.com/temp/%@",[response substringToIndex:range.location]]]];
//        path1 = [IMAGE_FOLDER stringByAppendingPathComponent:
//                [NSString stringWithFormat:@"%@.png", 
//                 pid]];
//        if ([[NSFileManager defaultManager] fileExistsAtPath:path1]) {
//            [[NSFileManager defaultManager] removeItemAtPath:path1 error:nil];
//        }
//        [imgData writeToFile:path1 atomically:YES];
//        [imgData release];
//
//        model.thumb = path1;
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<b>Price: "];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@" </div>"];
//        model.price = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<td  style=\"font-family:tahoma;font-size:12px;text-align:justify\">"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"</td>"];
//        model.description = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        [self.httpResponseSearch addObject:model];
//        [model release];
//        
//        range = [response rangeOfString:@"<td style=\"font-family:tahoma;font-size:12px;border-bottom:2px solid black\">"];
//    }
//        
//}
//-(void)parserSearchByManifast:(NSString*)response
//{
//    NSRange range;
//    YachtModel*  model;
//    
//    range = [response rangeOfString:@"<td style=\"font-family:tahoma;font-size:12px;border-bottom:2px solid black\">"];
//    NSString *path1=@"";
//    NSString *pid = @"";
//    
//    while (range.length > 0) {
//        response = [response substringFromIndex:range.location + range.length];
//        model = [[YachtModel alloc] init];
//        range = [response rangeOfString:@"style=\"font-family:tahoma;font-size:12px;\">"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"</b>"];
//        model.yachtName = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"Sleeps"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"</b>:"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<"];
//        model.sleeps = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        
//        range = [response rangeOfString:@"Ensuite Bathrooms"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"</b>:"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<"];
//        model.bath = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<a href='"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"/"];
//        [model setFavoriteId:[[response substringToIndex:range.location] intValue]];
//        pid = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<img src=temp/"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@" border=\"0\""];
//        NSData *imgData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://www.charterdigest.com/temp/%@",[response substringToIndex:range.location]]]];
//        path1 = [IMAGE_FOLDER stringByAppendingPathComponent:
//                 [NSString stringWithFormat:@"%@.png", 
//                  pid]];
//        if ([[NSFileManager defaultManager] fileExistsAtPath:path1]) {
//            [[NSFileManager defaultManager] removeItemAtPath:path1 error:nil];
//        }
//        [imgData writeToFile:path1 atomically:YES];
//        [imgData release];
//        
//        model.thumb = path1;
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<b>Price: "];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@" "];
//        model.price = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"<td  style=\"font-family:tahoma;font-size:12px;text-align:justify\">"];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        range = [response rangeOfString:@"</td>"];
//        model.description = [response substringToIndex:range.location];
//        response = [response substringFromIndex:range.location + range.length];
//        
//        [self.httpResponseSearch addObject:model];
//        [model release];
//        
//        range = [response rangeOfString:@"<td style=\"font-family:tahoma;font-size:12px;border-bottom:2px solid black\">"];
//    }
//}
//-(void)getHttpResponseManiSearch:(id)sender
//{
//    if (self.httpResponseSearch) {
//        [self.httpResponseSearch removeAllObjects];
//    }
//    else
//    {
//        self.httpResponseSearch = [[NSMutableArray alloc]init];
//    }
//
//    NSString *praseURL = @"http://www.charterdigest.com/index.php?ziua=&ziual=&luna=&lunal=&an=&anl=&pid=&pname=&tara=0&regiunea=&typeofproperties=0&search_property=1&search_rooms=1&camere=0&upto=upto&sleeps=&baths=&extra[17]=";
//    praseURL= [NSString stringWithFormat:@"%@%@",praseURL,[appDelegate urlEncoded:self.pickingSort]];
//    NSString *temp = @"&user=search1";
//    praseURL= [NSString stringWithFormat:@"%@%@",praseURL, temp];
//    
//    NSString *encodedStr = [praseURL encodeString:NSASCIIStringEncoding];
//   
//	NSURL *url = [NSURL URLWithString:encodedStr];
//	ASIHTTPRequest *aRequest = [ASIHTTPRequest requestWithURL:url];
//	[aRequest setDelegate:self];
//	[aRequest startAsynchronous];
//	
//	baseURL = [NSURL URLWithString:encodedStr];
//	NSURLRequest *request = [NSURLRequest requestWithURL:baseURL];
//	[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
//    strNew = nil;
//	strNew = [[NSString alloc] initWithContentsOfURL:baseURL encoding:NSUTF8StringEncoding error:nil];
//    if (strNew != nil) {
//        [self parserSearchByManifast:strNew];
//        [strNew release];
//    }
//    
//     [self.searchTableView reloadData];
//}


- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView;
{
	return 1;
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
//	SearchID = 2;
    if(self.httpResponse1 && [self.httpResponse1 count] > 0)
    {
        self.pickingSort = [[self.httpResponse1 objectAtIndex:row] objectForKey:@"manufacturer"];
    }
    else
    {
        self.pickingSort = @"";
    }
}


- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component;
{
    if (searchType == manafySearch) {
           return [self.httpResponse1 count];
    }
    else
    {
           return 0;
    } 
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component;
{
    if (self.httpResponse1 && [self.httpResponse1 count] > 0) {
        return [[self.httpResponse1 objectAtIndex:row] objectForKey:@"manufacturer"];
    }
    else
    {
        return @"";
    }
    
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
	[super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	[super viewDidUnload];
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
	
	[self.searchRegion release];
	self.searchRegion = nil;
	
	[self.windowAlert release];
	self.windowAlert = nil;
	
	[self.ShareView release];
	self.ShareView = nil;
	
	[self.DetinationTextField release];
	self.DetinationTextField = nil;
	
	[self.YachtTypeLabel release];
	self.YachtTypeLabel = nil;
	
	[CheckInDateLabel release];	
	CheckInDateLabel = nil;
	
	[NumberOfNightsLabel release];
	NumberOfNightsLabel = nil;
	
	[GuestPerRoomLabels release];
	GuestPerRoomLabels = nil;
	
	[selectedDateLabel release];
	selectedDateLabel = nil;
	
	[dateCheckOutLabel release];
	dateCheckOutLabel = nil;
	
	[self.YachtTypeLabel release];
	YachtTypeLabel = nil;
	
	[CityName release];
	CityName = nil;
	
	[dateOneCompare release];
	dateOneCompare = nil;
	
	[dateTwoCompare release];
	dateOneCompare = nil;
	
	[currentDate release];
	currentDate = nil;
	
	[NextDate release];
	NextDate = nil;
	
}


- (void)dealloc {
	[super dealloc];
	[self.searchRegion release];
	self.searchRegion = nil;
	
	[self.windowAlert release];
	self.windowAlert = nil;
	
	[self.ShareView release];
	self.ShareView = nil;
	
	[self.DetinationTextField release];
	self.DetinationTextField = nil;
	
	[self.YachtTypeLabel release];
	self.YachtTypeLabel = nil;
	
	[CheckInDateLabel release];	
	CheckInDateLabel = nil;
	
	[NumberOfNightsLabel release];
	NumberOfNightsLabel = nil;
	
	[GuestPerRoomLabels release];
	GuestPerRoomLabels = nil;
	
	[selectedDateLabel release];
	selectedDateLabel = nil;
	
	[dateCheckOutLabel release];
	dateCheckOutLabel = nil;
	
	[self.YachtTypeLabel release];
	YachtTypeLabel = nil;
	
	[CityName release];
	CityName = nil;
	
	[dateOneCompare release];
	dateOneCompare = nil;
	
	[dateTwoCompare release];
	dateOneCompare = nil;
	
	[currentDate release];
	currentDate = nil;
	
	[NextDate release];
	NextDate = nil;
	
}


@end
