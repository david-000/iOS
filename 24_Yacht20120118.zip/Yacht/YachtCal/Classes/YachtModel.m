//
//  YachtModel.m
//  Yacht
//
//  Created by admin on 12/22/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "YachtModel.h"

@implementation YachtModel
@synthesize yachtName;
@synthesize price;
@synthesize startdate;
@synthesize enddate;
@synthesize thumb;
@synthesize description;
@synthesize rooms;
@synthesize sleeps;
@synthesize bath;
@synthesize facility;
@synthesize ranking;
@synthesize guest;
@synthesize favoriteDate;

-(id)init{
    
    yachtId = 0;
    productId = 0;
    yachtName = @"";
    price = @"";
    startdate = @"0000-00-00";
    enddate = @"0000-00-00";
    thumb = @"";
    description = @"";
    rooms = @"";
    sleeps = @"";
    bath = @"";
    facility = @"";
    ranking = @"";
    guest = @"";
    favoriteDate = @"";
    return self;
}
    
-(NSInteger)getYachtId
{
    return yachtId;
}
-(void)setYachtId:(NSInteger)yid
{
    yachtId = yid;
}
-(NSInteger)getFavoriteId
{
    return productId;
}
 
-(void)setFavoriteId:(NSInteger)fid
{
    productId = fid;
}
    


@end
