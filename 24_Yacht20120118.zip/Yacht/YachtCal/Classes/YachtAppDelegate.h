//
//  YachtAppDelegate.h
//  Yacht
//
//  Created by Askone on 8/20/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequest.h"
#import <SystemConfiguration/SCNetworkReachability.h>
#include <netinet/in.h>
#import "DatabaseManager.h"

#define DOCS_FOLDER					[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]
#define	IMAGE_FOLDER				[DOCS_FOLDER stringByAppendingPathComponent:@"Images"]

@class ASIHTTPRequest;
@class Reachability;

@interface YachtAppDelegate : NSObject <UIApplicationDelegate, UIPickerViewDelegate> {
    
    UIWindow *window;
    UINavigationController *navigationController;
	
	NSMutableArray *httpResponse;
	NSMutableDictionary *item;
	NSArray *ContentsArr;
	NSURL *baseURL;
	
	ASIHTTPRequest *ASIRequest;
	NSString *responseString;
	
	Reachability* internetReachable;
    Reachability* hostReachable;
	
	BOOL internetActive;
	BOOL hostActive;
	
	
	NSMutableArray *AmentitesArray;
    DatabaseManager *dbManager;
    NSMutableArray  *favoriteArray;
    NSMutableArray  *yachtArray;
    NSMutableArray  *amenitiesArray;
//    NSMutableArray  *allDataArray;
    
    NSString    *yachtTypeId;
    
//    UIActivityIndicatorView*			m_SplashActivityView;
//    UIImageView*						m_SplashView;
//    UILabel								*waitingLavel;
//    
//    int             addressCount;
}

@property (nonatomic, retain)NSMutableArray *AmentitesArray;
@property (nonatomic) BOOL hostActive;

@property (retain, nonatomic) ASIHTTPRequest *ASIRequest;
@property (nonatomic, retain)NSString *responseString;

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@property (nonatomic, retain)NSMutableArray *httpResponse;
@property (nonatomic, retain)NSMutableDictionary *item;

@property (nonatomic, retain)NSArray *ContentsArr;
@property (nonatomic, retain)NSURL *baseURL;
@property (nonatomic, retain) DatabaseManager *dbManager;
@property (nonatomic, retain) NSMutableArray  *favoriteArray;
@property (nonatomic, retain) NSMutableArray  *yachtArray;
@property (nonatomic, retain) NSMutableArray  *amenitiesArray;
//@property (nonatomic, retain) NSMutableArray  *allDataArray;

@property (nonatomic, retain) NSString    *yachtTypeId;

//@property (nonatomic, retain) UIActivityIndicatorView*			m_SplashActivityView;


+ (YachtAppDelegate *)sharedAppDelegate;
-(void)ParseAtURL:(id)sender;
-(NSString*)urlEncoded:(NSString*)data;
-(NSString*)urlDecoded:(NSString*)data;

- (void)checkNetworkStatus:(NSNotification *)notice;
-(void)CheckConnection;

//- (void)showSplashView:(NSString*)viewText;
//-(void)hiddenSplashView;

//-(void)getHttpResponseSearch:(id)sender;
//-(void)getAddress:(NSString *)str;
//-(void)againSearch:(NSString *)address;
//-(void)parserSearch:(NSString*)response;

@end

