//
//  MainViewController.h
//  TabBarAnimation
//
//  Created by Askone on 8/11/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TapkuLibrary/TapkuLibrary.h>
#import "YachtAppDelegate.h"
@class SearchViewController;

enum {
	homeState,
	recentState,
	shareState,
	informationState,
    mainSearchState,
};
typedef int viewState;

enum {
    noneSearch,
	nameSearch,
	manafySearch,
};
typedef int SearchState;

@interface MainViewController : UIViewController <UIActionSheetDelegate, UITextFieldDelegate,UISearchBarDelegate, UITableViewDelegate, UITableViewDataSource , UIPickerViewDelegate> {


	IBOutlet UITextField        *DetinationTextField;
	
	IBOutlet UILabel            *CheckInDateLabel;
	IBOutlet UILabel            *NumberOfNightsLabel;
	IBOutlet UILabel            *GuestPerRoomLabels;
	IBOutlet UILabel            *selectedDateLabel;
	IBOutlet UILabel            *dateCheckOutLabel;
	IBOutlet UILabel            *YachtTypeLabel;
	
	IBOutlet UIButton           *SubtractFromGuestRoom;
	IBOutlet UIButton           *AdditionToGuestRoom;
		
	IBOutlet UIButton           *recent;
	IBOutlet UIButton           *share;
	IBOutlet UIButton           *setting;
	IBOutlet UIButton           *information;
    IBOutlet UIButton           *search;
	
	IBOutlet UIView             *ShareView;
	IBOutlet UIImageView        *windowAlert;
	
	IBOutlet UIButton           *email;
	IBOutlet UIButton           *facebook;
	IBOutlet UIButton           *twitter;
	IBOutlet UIButton           *cancel;
	IBOutlet UIButton           *YachtTypeBtn;
	
	IBOutlet UITableView        *tableView;
    IBOutlet UITableView        *searchTableView;
    IBOutlet UITableView        *infoTableView;
	IBOutlet UIView             *aboutUsView;
    IBOutlet UIView             *recentsView;
    IBOutlet UIView             *searchView;

	int Nights;
	int Rooms;
	int selection;
	
	bool flag;
	bool flag2;
	
	IBOutlet UIButton           *searchHotels;
	IBOutlet UIButton           *searchRegion;
    
	NSString *data;
	NSString *path;
	NSString *ecode;
	
	UIButton *myButton;
	NSArray *cellArray;
	
	NSString *dateOneCompare;
	NSString *dateTwoCompare;
	NSDate *currentDate;
	NSDate *NextDate;
    
    IBOutlet UIView *pickerView;
	UIPickerView *_pickerControler;
    NSString *pickingSort;
    NSMutableArray  *yachtTypeArray;
//    NSMutableArray  *yachtManafyArray;
    int             searchType;
	
	SearchViewController *sController;
	
	UIActivityIndicatorView *activityIndicator;
	
	NSDateFormatter *formater;
    
    int     viewSelectState;
    
    UISearchBar *m_searchBar;
    NSString *searchString;
    
    BOOL    searchViewState;
    
    NSMutableArray *httpResponse;
    NSMutableArray *httpResponse1;
    NSMutableArray *httpResponseSearch;
	NSMutableDictionary *item;
	NSArray *ContentsArr;
	NSURL *baseURL;
    
    UIBarButtonItem				*editBarItem;
	UIBarButtonItem				*cancelBarItem;
	UIBarButtonItem				*doneBarItem;
	
	NSMutableArray				*deletedfavoriteIdList;
//    NSMutableArray              *allAddressArray;
//    int                         addressCount;
    
    BOOL                        isEditFlag;
    YachtAppDelegate *appDelegate;
    
    BOOL                        isSearchState;
}

@property (nonatomic, retain)IBOutlet UIPickerView *pickerControler;
@property (nonatomic, retain)UIView *pickerView;
@property (nonatomic, retain)UIActivityIndicatorView *activityIndicator;

@property (nonatomic, retain) NSMutableArray		*deletedfavoriteIdList;

@property (nonatomic, retain)SearchViewController *sController;
@property (nonatomic, retain)NSDate *currentDate;
@property (nonatomic, retain)NSDate *NextDate;

@property (nonatomic, retain)IBOutlet UITableView *tableView;
@property (nonatomic, retain)IBOutlet UITableView *searchTableView;
@property (nonatomic, retain)IBOutlet UITableView *infoTableView;
@property (nonatomic, retain)UISearchBar *m_searchBar;
@property (nonatomic, retain)NSString *data;
@property (nonatomic, retain)UILabel *YachtTypeLabel;
@property (nonatomic, retain)UITextField* DetinationTextField;
@property (nonatomic, retain)UIView *ShareView;
@property (nonatomic, retain) IBOutlet UIView *searchView;
@property (nonatomic, retain)UIImageView *windowAlert;
@property (nonatomic, retain)UIButton *searchRegion;
@property (nonatomic, retain)NSArray *cellArray;

@property (nonatomic, retain)NSString *pickingSort;

@property (nonatomic, retain)NSString *dateOneCompare;
@property (nonatomic, retain)NSString *dateTwoCompare;
@property (nonatomic, retain)NSString *searchString;

@property (nonatomic, retain)NSMutableArray *httpResponse;
@property (nonatomic, retain)NSMutableArray *httpResponse1;
@property (nonatomic, retain)NSMutableArray *httpResponseSearch;
@property (nonatomic, retain)NSMutableArray  *yachtTypeArray;
//@property (nonatomic, retain)NSMutableArray  *allAddressArray;
@property (nonatomic, retain)NSMutableDictionary *item;
@property (nonatomic, retain)NSArray *ContentsArr;
@property (nonatomic, retain)NSURL *baseURL;

-(void)countDates:(id)sender;

-(IBAction)YachtTypeAction;
-(IBAction)checkOutAction;
-(IBAction)performSearch:(id)sender;
-(IBAction)pushController:(id)sender;
-(IBAction)TotalGuestInRoom:(id)sender;
-(IBAction) buttonPressed;
-(IBAction)decisionMaker:(id)sender;
-(void)shareApplication:(id)sender;
-(void)dismissModalAlertSheet;
-(IBAction)ConnectionWizard:(id)sender;
-(IBAction)showHome:(id)sender;
-(IBAction)search:(id)sender;
-(IBAction)searchCancel:(id)sender;

-(IBAction)pickerViewGoDown;
-(void)popPickerView;

-(void)getHttpResponse:(id)sender;
-(void)getHttpResponse1:(id)sender;

//-(void)againSearch:(NSString *)address;
-(void)getHttpResponseSearch:(id)sender;
//-(void)getHttpResponseNameSearch:(id)sender;
//-(void)getHttpResponseManiSearch:(id)sender;

//-(void)parserSearch:(NSString*)response;
//-(void)parserSearchByName:(NSString*)response;
//-(void)parserSearchByManifast:(NSString*)response;

- (void)clickEditButton;
-(void)clickDoneButton;
-(void)clickCancelButton;

//-(void)getAddress:(NSString *)str;

@end
