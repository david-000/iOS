//
//  YachtAppDelegate.m
//  Yacht
//
//  Created by Askone on 8/20/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "Reachability.h"
#import "YachtAppDelegate.h"
#import "Constants.h"
#import "YachtModel.h"

@interface NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding;
@end

@implementation NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding
{
	return (NSString *) CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)self,
																NULL, (CFStringRef)@";@$+{}<>,",
																CFStringConvertNSStringEncodingToEncoding(encoding));
} 

@end


@implementation YachtAppDelegate

@synthesize window;
@synthesize navigationController;

@synthesize httpResponse;
@synthesize item;
@synthesize ContentsArr;
@synthesize baseURL;

@synthesize ASIRequest;
@synthesize responseString;
@synthesize hostActive;
@synthesize AmentitesArray;
@synthesize dbManager;
@synthesize favoriteArray;
@synthesize yachtArray;
@synthesize amenitiesArray;
@synthesize yachtTypeId;
//@synthesize m_SplashActivityView;
//@synthesize allDataArray;

#pragma mark -
#pragma mark Application lifecycle
			
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
	AmentitesArray = [[NSMutableArray alloc] init];
    favoriteArray = [[NSMutableArray alloc] init];
    yachtArray = [[NSMutableArray alloc] init];
    amenitiesArray = [[NSMutableArray alloc] init];
	dbManager = [[DatabaseManager alloc] init];
    [dbManager createDBAndTables];
    [dbManager InsertDataToDB:[NSString stringWithFormat:@"DELETE FROM %@",YACHET_TABLE_NAME]];
    favoriteArray = [dbManager selectYachtListFromDB:0];
    amenitiesArray = [dbManager selectAmenitiesListFromDB:@""];
    yachtTypeId = @"0";
    [[NSFileManager defaultManager] createDirectoryAtPath:IMAGE_FOLDER withIntermediateDirectories:YES attributes:nil error:nil];
    
    
	[self CheckConnection];
	
    [self.window addSubview:navigationController.view];
    [self.window makeKeyAndVisible];
    return YES;
}


-(void)CheckConnection{
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkNetworkStatus:) name:kReachabilityChangedNotification object:nil];
	internetReachable = [[Reachability reachabilityForInternetConnection] retain];
	[internetReachable startNotifier];
	
	hostReachable = [[Reachability reachabilityWithHostName: @"http://www.charterdigest.com/"] retain];
	[hostReachable startNotifier];
	
}

- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}


-(void)ParseAtURL:(id)sender {
	self.httpResponse = [[NSMutableArray alloc]init];
	NSString *praseURL = [NSString stringWithFormat:@"http://www.charterdigest.com/iPhone/index.php?act=ptype"];	
	NSString *encode = [praseURL stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
	baseURL = [NSURL URLWithString:encode];
	NSURLRequest *request = [NSURLRequest requestWithURL:baseURL];
	[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
	NSString * strNew = [[NSString alloc] initWithContentsOfURL:baseURL encoding:NSUTF8StringEncoding error:nil];
    if (strNew != nil) {
 
	NSArray *arr =[strNew componentsSeparatedByString:@"</br>"];
    [strNew release];
	for (int i=0;i<[arr count]-1; i++) {
		self.ContentsArr = [[arr objectAtIndex:i] componentsSeparatedByString:@"~"];
		self.item = [[NSMutableDictionary alloc] init];
		if ([self.ContentsArr count]>=1) {
			[self.item setObject:[ContentsArr objectAtIndex:0] forKey:@"id"];
			[self.item setObject:[ContentsArr objectAtIndex:1] forKey:@"type"];
			[self.httpResponse addObject:self.item];
			
		}
        [self.item release];
	}
        
    }
}



+ (YachtAppDelegate *)sharedAppDelegate
{
    return (YachtAppDelegate *)[UIApplication sharedApplication].delegate;
}


- (void)requestFinished:(ASIHTTPRequest *)request
{
	responseString = [request responseString];
	
	if ([responseString isEqualToString:@"No Record Found."]) {
		
		UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Search Result" message:responseString delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:@"Retry", nil];
		[alertView show];
		[alertView release];
		
	}
}

-(NSString*)urlEncoded:(NSString*)data
{
    NSString *encoded = [(NSString *)CFURLCreateStringByAddingPercentEscapes(NULL,
                                                                             (CFStringRef)data,
                                                                             NULL,
                                                                             CFSTR(":/?#[]@!$&’()*+,;="),
                                                                             kCFStringEncodingUTF8) autorelease];
    return encoded;
}

-(NSString*)urlDecoded:(NSString*)data
{
    NSString *decoded = [(NSString *)CFURLCreateStringByAddingPercentEscapes(NULL,
																			 (CFStringRef)data,
																			 NULL,
																			 CFSTR(":/?#[]@!$&’()*+,;=-"),
																			 kCFStringEncodingUTF8) autorelease];
    return decoded;
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
	NSError *error = [request error];
	NSLog(@"requestFailed %@", error);
}


- (void)requestDone:(ASIHTTPRequest *)request
{
	NSString *response = [request responseString];
	NSLog(@"response %@",response);
}

- (void) checkNetworkStatus:(NSNotification *)notice
{
	NetworkStatus internetStatus = [internetReachable currentReachabilityStatus];
	
	switch (internetStatus)
	{
		case NotReachable:
		{
			NSLog(@"The internet is down.");
			self.hostActive = NO;
			
			UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Error" message:@"Please Check Wi-Fi Connectivity" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
			[alert show];
			[alert release];
			break;
			
		}
		case ReachableViaWiFi:
		{
			NSLog(@"The internet is working via WIFI.");
//            [self getHttpResponseSearch:nil];
			[self ParseAtURL:nil];
			self.hostActive = YES;
			break;
			
		}
		case ReachableViaWWAN:
		{
			NSLog(@"The internet is working via WWAN.");
//            [self getHttpResponseSearch:nil];
			[self ParseAtURL:nil];
			self.hostActive = YES;
			break;
			
		}
	}
	
	NetworkStatus hostStatus = [hostReachable currentReachabilityStatus];
	switch (hostStatus)
	
	{
		case NotReachable:
		{
			NSLog(@"A gateway to the host server is down.");
			break;
			
		}
		case ReachableViaWiFi:
		{
			NSLog(@"A gateway to the host server is working via WIFI.");
			self.hostActive = YES;
			
			break;
			
		}
		case ReachableViaWWAN:
		{
			NSLog(@"A gateway to the host server is working via WWAN.");
			self.hostActive = YES;
			break;
			
		}
	}
}

//- (void)showSplashView:(NSString*)viewText
//{
//	waitingLavel.text = viewText;
//	[m_SplashActivityView startAnimating];
//	m_SplashView.hidden = NO;
//	[window addSubview:m_SplashView];
//}

//-(void)hiddenSplashView
//{
//	[m_SplashActivityView stopAnimating];
//	m_SplashView.hidden = YES;
//	[m_SplashView removeFromSuperview];
//}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}


- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
	
	[httpResponse release];
	[ContentsArr release];
	[item release];
	[navigationController release];
	[window release];
	[yacthFromDelegate release];
	[super dealloc];
}


@end

