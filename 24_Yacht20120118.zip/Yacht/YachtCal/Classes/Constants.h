//
//  Constants.h
//  TabBarAnimation
//
//  Created by Askone on 8/18/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

NSString *CityName;
NSString *yacthFromDelegate;

int CheckResultForFilter;
int days;

NSString *ArrivalDate;
NSString *ArrivalDate4;


NSString *DeparatureDate;
NSString *DeparatureDate4;

NSString *searchSort;
NSString *hasAmentites;