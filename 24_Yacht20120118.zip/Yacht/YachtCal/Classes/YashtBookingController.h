//
//  YashtBookingController.h
//  TabBarAnimation
//
//  Created by Askone on 8/10/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AsyncImageView;

@interface YashtBookingController : UIViewController <UITableViewDelegate, UITableViewDataSource>{
	
	UITableView *_tableView;
	NSMutableArray *httpResponse;
	NSMutableDictionary *item;
	NSArray *ContentsArr;
	NSURL *baseURL;
	
	AsyncImageView*asyncImage;
	IBOutlet UINavigationBar *navBar;

}

@property (nonatomic, retain)IBOutlet UITableView *tableView;
@property (nonatomic, retain)NSMutableArray *httpResponse;
@property (nonatomic, retain)NSMutableDictionary *item;
@property (nonatomic, retain)NSArray *ContentsArr;
@property (nonatomic, retain)NSURL *baseURL;
@property (nonatomic, retain)UINavigationBar *navBar;

-(IBAction)DismodelController;
-(void)getHttpResponse:(id)sender;

@end
