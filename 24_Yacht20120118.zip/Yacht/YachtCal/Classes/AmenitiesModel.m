//
//  AmenitiesModel.m
//  Yacht
//
//  Created by admin on 12/23/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "AmenitiesModel.h"

@implementation AmenitiesModel
@synthesize imagename;
@synthesize thumb;


-(int)getId
{
    return amenitiesid;
}
-(void)setId:(int)aid
{
    amenitiesid = aid;
}

-(int)getProductid
{
    return productid;
}
-(void)setProductId:(int)pid
{
    productid = pid;
}

-(id)init
{
    amenitiesid = 0;
    productid = 0;
    self.imagename = @"";
    self.thumb = @"";
    
    return self;
}

@end
