//
//  AmmentiesController.m
//  Yacht
//
//  Created by Askone on 10/8/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "AmmentiesController.h"
#import "AsyncImageView.h"
#import <QuartzCore/QuartzCore.h>
#import "ASIHTTPRequest.h"

@interface NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding;
@end

@implementation NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding
{
	return (NSString *) CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)self,
																NULL, (CFStringRef)@";@$+{}<>,",
																CFStringConvertNSStringEncodingToEncoding(encoding));
}  
@end

@implementation AmmentiesController
@synthesize tableView = _tableView;
@synthesize httpResponse;
@synthesize item;
@synthesize ContentsArr;
@synthesize baseURL;
@synthesize AmmentiesID;
@synthesize ASIRequest;
#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];
	/*
	UILabel * Navlabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 400, 44)];
	Navlabel.backgroundColor = [UIColor clearColor];
	Navlabel.font = [UIFont boldSystemFontOfSize:18.0];
	Navlabel.textAlignment = UITextAlignmentCenter;
	Navlabel.textColor =[UIColor whiteColor];
	Navlabel.text= @"Amenities";
	self.navigationItem.titleView = Navlabel;		
	[Navlabel release];*/
	
	self.title = @"Amenities";
	
	self.httpResponse = [[NSMutableArray alloc]init];
	NSString *YachtURL= @"http://www.charterdigest.com/iPhone/singleyatch-detail.php?act=amenities&pid=";
	YachtURL = [YachtURL stringByAppendingString:AmmentiesID];
	NSString *encodedStr = [YachtURL encodeString:NSASCIIStringEncoding];
//	NSLog(@"encoded URL --> %@", encodedStr);
	NSURL *url = [NSURL URLWithString:encodedStr];
	ASIHTTPRequest *aRequest = [ASIHTTPRequest requestWithURL:url];
	[aRequest setDelegate:self];
	[aRequest startAsynchronous];
	
	baseURL = [NSURL URLWithString:encodedStr];
	NSURLRequest *request = [NSURLRequest requestWithURL:baseURL];
	[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
	NSString * strNew = [[NSString alloc] initWithContentsOfURL:baseURL encoding:NSUTF8StringEncoding error:nil];
    if (strNew != nil) {

	NSArray *arr =[strNew componentsSeparatedByString:@"</br>"];
	for (int i=0;i<[arr count]-1; i++) {
		self.ContentsArr = [[arr objectAtIndex:i] componentsSeparatedByString:@"~"];
		self.item = [[NSMutableDictionary alloc] init];
		if ([self.ContentsArr count]>=1) {
			
			[self.item setObject:[ContentsArr objectAtIndex:0] forKey:@"imageDetail"];
			[self.item setObject:[ContentsArr objectAtIndex:1] forKey:@"imageThumb"];
			[self.httpResponse addObject:self.item];
		}
        [self.item release];
	}
        
    }
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}


/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
*/
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
- (void)requestFailed:(ASIHTTPRequest *)request
{
	NSError *error = [request error];
	NSLog(@"requestFailed %@", error);
}


- (void)requestDone:(ASIHTTPRequest *)request
{
	NSString *response = [request responseString];
	NSLog(@"response %@",response);
}



- (NSURLRequest *)connection:(NSURLConnection *)connection
			 willSendRequest:(NSURLRequest *)request
			redirectResponse:(NSURLResponse *)redirectResponse
{
    [baseURL autorelease];
    baseURL = [[request URL] retain];
    return request;
}


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [self.httpResponse count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"ImageCell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	}
	else {
		AsyncImageView* oldImage = (AsyncImageView*)
		[cell.contentView viewWithTag:999];
		[oldImage removeFromSuperview];
	}
	
		
	UILabel * description =[[UILabel alloc]init];
	description.backgroundColor = [UIColor clearColor];
	description.textColor = [UIColor orangeColor];
	description.frame=CGRectMake(80, 10, 240,50);
	description.font = [UIFont systemFontOfSize:14];
	description.textAlignment = UITextAlignmentLeft;
	description.lineBreakMode = UILineBreakModeWordWrap;
	description.numberOfLines = 3;
	description.text = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"imageDetail"];
	[cell.contentView addSubview:description];
	[description release];
		
	CGRect frame = CGRectMake(10, 10, 60, 60);
	asyncImage = [[[AsyncImageView alloc]initWithFrame:frame] autorelease];
	asyncImage.tag = 999;
	NSURL*imageURL = [NSURL URLWithString:[[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"imageThumb"]];
	[asyncImage loadImageFromURL:imageURL];
	asyncImage.backgroundColor = [UIColor clearColor];

	CALayer * l = [asyncImage layer];
	[l setMasksToBounds:YES];
	[l setCornerRadius:10.0];
	
	asyncImage.clipsToBounds = YES;
	[cell.contentView addSubview:asyncImage];
	[asyncImage release];
    
	/*
	UIView * backView = [[UIView alloc]initWithFrame:CGRectMake(0,0, 320,100)];
	backView.backgroundColor = [UIColor whiteColor];
	cell.backgroundView = backView;*/
	
	cell.backgroundColor = [UIColor clearColor];
	self.tableView.separatorColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	
	return cell;
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 80;
	
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here. Create and push another view controller.
    /*
    <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
    // ...
    // Pass the selected object to the new view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
    [detailViewController release];
    */
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end

