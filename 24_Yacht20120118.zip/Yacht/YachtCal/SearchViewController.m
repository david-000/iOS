//
//  SearchViewController.m
//  Yacht
//
//  Created by Askone on 8/23/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "SearchViewController.h"
#import "AsyncImageView.h"
#import <QuartzCore/QuartzCore.h>
#import "FilterViewController.h"
#import "ASIHTTPRequest.h"
#import "Constants.h"
#import "SortController.h"
#import "DetailRootViewController.h"
#import "AmenitiesModel.h"

@interface NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding;
@end

@implementation NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding
{
	return (NSString *) CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)self,
																NULL, (CFStringRef)@"& ;@$+{}<>,",
																CFStringConvertNSStringEncodingToEncoding(encoding));
}  
@end

@implementation SearchViewController
@synthesize m_tableView;
@synthesize m_searchBar;
@synthesize praseURL;
@synthesize httpResponse;
@synthesize item;
@synthesize ContentsArr;
@synthesize disableViewOverlay;

@synthesize baseURL;
@synthesize totalDay;
@synthesize getDetination;
@synthesize getGuest;
@synthesize getType;
@synthesize starString;
@synthesize filter;
@synthesize searchResult;
@synthesize priceString;
@synthesize urlimg;
@synthesize getDateIn,getDateOut;
@synthesize pickerView;
@synthesize pickerControler;
@synthesize pickingSort;

@synthesize tempStr;
@synthesize isEnter;

#pragma mark -
#pragma mark View lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.tintColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	isFilter = NO;
	
	Navlabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 400, 44)];
	Navlabel.backgroundColor = [UIColor clearColor];
	Navlabel.font = [UIFont boldSystemFontOfSize:16.0];
	Navlabel.textAlignment = UITextAlignmentCenter;
	Navlabel.textColor =[UIColor whiteColor];
	Navlabel.text= [NSString stringWithFormat:@"(%d) Results", [searchResult count]-1];
	self.navigationItem.titleView = Navlabel;		
	[Navlabel release];
	SearchID = 0;
	
	localSortArry = [[NSMutableArray alloc] init];
	[localSortArry addObject:@"Price (High to Low)"];
	[localSortArry addObject:@"Price (Low to High)"];
	[localSortArry addObject:@"Stars (5 to 0)"];
	[localSortArry addObject:@"Yacht Name (A to Z)"];
	[localSortArry addObject:@"Yacht Name (Z to A)"];
    appDelegate = [YachtAppDelegate sharedAppDelegate];   
	
}

-(IBAction)tappFilter:(id)sender{
	
//	[appDelegate showSplashView:@"Filtering..."];
    SortController *fController = [[SortController alloc] initWithNibName:@"SortController" bundle:nil];
	
	NSString *date1 = [NSString stringWithFormat:@"%@",getDateIn];
	NSString *date2 = [NSString stringWithFormat:@" %@", getDateOut];
	NSString *detailDate = [date1 stringByAppendingFormat:@"--"];
	NSString *Append = [detailDate stringByAppendingString:date2];
	NSString *yachtName = [[self.httpResponse objectAtIndex:0] objectForKey:@"yacthName"];
    
	fController.yName = yachtName;
	fController.YachtName1Str = getDetination;
	fController.YachtDate1Str = Append;
	fController.YachtGuest1Str = self.getGuest;
	fController.YachtType1Str = getType;
	fController.getDateIn = date1;
	fController.getDateOut = date2;
//    NSLog(@"date1 = %@",date1);
//    NSLog(@"date2 = %@",date2);
    if (!isFilter) {
        isFilter = YES;
        fController.isFilter = NO;
    }
    else
    {
        fController.isFilter = YES;
    }
	
	[self presentModalViewController:fController animated:YES];
	[fController release];    
}

-(void)performSearch:(NSString*)ParseURL{
    
    if (self.httpResponse) {
        [self.httpResponse removeAllObjects];
    }
    else
    {
        self.httpResponse = [[NSMutableArray alloc]init];
    }
    NSString *indate;
    NSString *outDate;
    NSRange range;
    if (![getDateIn isEqualToString:@""]) {
        range = [getDateIn rangeOfString:@", "];
        indate = [[NSString alloc] initWithString:[getDateIn substringFromIndex:range.location+range.length]];
    }
    if (![getDateOut isEqualToString:@""]) {
        range = [getDateOut rangeOfString:@", "];
        outDate = [[NSString alloc] initWithString:[getDateOut substringFromIndex:range.location+range.length]];
    }
    NSString *parameter = @"";
    NSMutableString *result = [[[NSMutableString alloc] init] autorelease];
	switch (SearchID) {
		case 0:
			self.praseURL = [NSString stringWithFormat:@"http://www.charterdigest.com/iPhone/index.php?act=record&region=%@",[appDelegate urlEncoded:getDetination]];
            parameter = [NSString stringWithFormat:@"&numguest=%@&ytype=%@&ssdate=%@&nndate=%@&numdays=%d", self.getGuest, getType, indate, outDate, days];
			break;
		case 1:
			self.praseURL = [NSString stringWithFormat:@"http://www.charterdigest.com/iPhone/index.php?act=ysearch"];
            parameter = [NSString stringWithFormat:@"&yname=%@",ParseURL];            
			break;
		case 2:
			self.praseURL = [NSString stringWithFormat:@"http://www.charterdigest.com/iPhone/sort.php?act=record&region=%@",[appDelegate urlEncoded:getDetination]];
            parameter = [NSString stringWithFormat:@"&numguest=%@&ytype=%@&ssdate=%@&nndate=%@&numdays=%d&newsort=%@", self.getGuest, getType, indate, outDate, days,ParseURL];
			break;            
        case 3:
        {            
            for (NSObject * obj in appDelegate.amenitiesArray)
            {
                [result appendString:[NSString stringWithFormat:@"Facilities[]=%@&",[obj description]]];                
            }
           
            if ([result length]==0) {
                hasAmentites = @"False";
            }else {
                hasAmentites = @"True";
            }
      
            self.praseURL = [NSString stringWithFormat:@"http://www.charterdigest.com/iPhone/filter.php?act=record&region=%@",[appDelegate urlEncoded:getDetination]];
            parameter = [NSString stringWithFormat:@"&numguest=%@&ytype=%@&ssdate=%@&nndate=%@&numdays=%d&manufacturer=%@&yacthname=%@&amt_check=%@&minprice=%@&maxprice=%@&%@",self.getGuest, getType, indate, outDate, days, @"null",@"null", hasAmentites,@"null",@"null",result];
            break;
        }            
    }
    if (indate) {
        [indate release];
    }
    if (outDate) {
        [outDate release];
    }
	
	NSString *encodedStr = [parameter encodeString:NSASCIIStringEncoding];
    self.praseURL = [NSString stringWithFormat:@"%@%@",self.praseURL,encodedStr];

	NSURL *url = [NSURL URLWithString:self.praseURL];
	ASIHTTPRequest *aRequest = [ASIHTTPRequest requestWithURL:url];
	[aRequest setDelegate:self];
	[aRequest startAsynchronous];
	
	baseURL = [NSURL URLWithString:self.praseURL];
	NSURLRequest *request = [NSURLRequest requestWithURL:baseURL];
	[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
	NSString *strNew = [[NSString alloc] initWithContentsOfURL:baseURL encoding:NSUTF8StringEncoding error:nil];
    if (strNew != nil) {

	NSArray *arr =[strNew componentsSeparatedByString:@"</br>"];
    [strNew release];
	self.searchResult = [[NSArray alloc] initWithArray:arr]; 
    if (self.httpResponse) {
        [self.httpResponse removeAllObjects];
    }
    if (arr && [arr count] > 0) {
        NSString *path = @"";

	for (int i=0;i<[arr count]-1; i++) {
		self.ContentsArr = [[arr objectAtIndex:i] componentsSeparatedByString:@"~"];
		self.item = [[NSMutableDictionary alloc] init];
		if ([self.ContentsArr count]>=1) {
			
			[self.item setObject:[ContentsArr objectAtIndex:1] forKey:@"productID"];
			[self.item setObject:[ContentsArr objectAtIndex:2] forKey:@"yacthName"];
			[self.item setObject:[ContentsArr objectAtIndex:3] forKey:@"price"];
            NSData *imgData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[ContentsArr objectAtIndex:4]]];
            path = [IMAGE_FOLDER stringByAppendingPathComponent:
                     [NSString stringWithFormat:@"%@.png", 
                      [ContentsArr objectAtIndex:1]]];
            if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
                [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
            }
            [imgData writeToFile:path atomically:YES];
            [imgData release];

			[self.item setObject:path forKey:@"thumb"];
			[self.item setObject:[ContentsArr objectAtIndex:5] forKey:@"description"];
			[self.item setObject:[ContentsArr objectAtIndex:6] forKey:@"rating"];
			[self.item setObject:[ContentsArr objectAtIndex:7] forKey:@"EstimatedCost"];
			[self.httpResponse addObject:self.item];			
            }
        [self.item release];
        }  
        
        }
    }
}


- (void)requestFinished:(ASIHTTPRequest *)request
{
	NSString *responseString = [request responseString];
	if ([responseString isEqualToString:@"No Record Found."]) {
		UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Search Result" message:responseString delegate:self cancelButtonTitle:@"Retry" otherButtonTitles:nil];
		[alertView show];
		[alertView release];
	}
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if (buttonIndex == 0) {
		[self.navigationController popViewControllerAnimated:YES];
	}
}
- (void)requestFailed:(ASIHTTPRequest *)request
{

}


- (void)requestDone:(ASIHTTPRequest *)request
{

}



- (NSURLRequest *)connection:(NSURLConnection *)connection
			 willSendRequest:(NSURLRequest *)request
			redirectResponse:(NSURLResponse *)redirectResponse
{
//    [baseURL autorelease];
//    baseURL = [[request URL] retain];
    return request;
}


- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	
	
	
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
	
	
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
	
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
	
	
	
}



- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
	SearchID = 1;
	disableViewOverlay.frame = CGRectMake(0, 40, 320, 416);
	self.disableViewOverlay.alpha = 0;
	[searchBar setShowsCancelButton:YES animated:YES];
    self.m_tableView.allowsSelection = NO;
    self.m_tableView.scrollEnabled = NO;
	[self.view addSubview:self.disableViewOverlay];
    [UIView beginAnimations:@"FadeIn" context:nil];
    [UIView setAnimationDuration:0.5];
    self.disableViewOverlay.alpha = 0.6;
    [UIView commitAnimations];
}


- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
	
	searchBar.text=@"";
	[searchBar setShowsCancelButton:NO animated:YES];
    [searchBar resignFirstResponder];
    self.m_tableView.allowsSelection = YES;
    self.m_tableView.scrollEnabled = YES;
	[disableViewOverlay removeFromSuperview];
	
}


- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	
	[self performSearch:searchBar.text];
	
    [searchBar setShowsCancelButton:NO animated:YES];
    [searchBar resignFirstResponder];
	
    self.m_tableView.allowsSelection = YES;
    self.m_tableView.scrollEnabled = YES;
	[self.m_tableView reloadData];
	Navlabel.text= [NSString stringWithFormat:@"Search Results (%d)", [searchResult count]-1];
	self.navigationItem.titleView = Navlabel;		
    
	[disableViewOverlay removeFromSuperview];
}



#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
	
	return [self.httpResponse count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"ImageCell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
	}
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 320.0, 120.0)];
    [view setBackgroundColor:[UIColor whiteColor]];
    

	UILabel *label=[[UILabel alloc]init];
	label.backgroundColor = [UIColor clearColor];
	label.textColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	label.highlightedTextColor = [UIColor whiteColor];
	label.frame=CGRectMake(10, 0,250,35);
	label.font = [UIFont systemFontOfSize:14];
	label.lineBreakMode = UILineBreakModeWordWrap;
	label.numberOfLines = 2;
	label.text=[[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"yacthName"];
	[view addSubview:label];
    [label release];
	
	UILabel * price =[[UILabel alloc]init];
	price.backgroundColor = [UIColor clearColor];
	price.textColor = [UIColor orangeColor];
	price.frame=CGRectMake(260, 0,100,50);
	price.font = [UIFont boldSystemFontOfSize:14];
	price.textAlignment = UITextAlignmentLeft;
	self.priceString = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"price"];
	price.text = [NSString stringWithFormat:@"$%@", priceString];
	[view addSubview:price];
    [price release];
	
	UIImageView *starImage = [[UIImageView alloc] initWithFrame:CGRectMake(5, 100, 80, 16)];
	self.starString = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"rating"];
	
	if ([self.starString isEqual:@"0"]) {
		starImage.image = [UIImage imageNamed:nil];
	}
	else if ([self.starString isEqual:@"1"]) {
		NSString *OneStar = [self.starString stringByAppendingFormat:@".png"];
		starImage.image = [UIImage imageNamed:OneStar];
	}
	else if ([self.starString isEqual:@"2"]) {
		NSString *TwoStar = [self.starString stringByAppendingFormat:@".png"];
		starImage.image = [UIImage imageNamed:TwoStar];
	}
	else if ([self.starString isEqual:@"3"]) {
		NSString *ThreeStar = [self.starString stringByAppendingFormat:@".png"];
		starImage.image = [UIImage imageNamed:ThreeStar];
	}
	else if ([self.starString isEqual:@"4"]) {
		NSString *fourStar = [self.starString stringByAppendingFormat:@".png"];
		starImage.image = [UIImage imageNamed:fourStar];
	}
	else if ([self.starString isEqual:@"5"]) {
		NSString *fiveStar = [self.starString stringByAppendingFormat:@".png"];
		starImage.image = [UIImage imageNamed:fiveStar];
	}
	
	[view addSubview:starImage];
    [starImage release];
	
	UILabel * description =[[UILabel alloc]init];
	description.backgroundColor = [UIColor clearColor];
	description.textColor = [UIColor orangeColor];
	description.frame=CGRectMake(80, 40, 240,50);
	description.font = [UIFont systemFontOfSize:14];
	description.textAlignment = UITextAlignmentLeft;
	description.lineBreakMode = UILineBreakModeWordWrap;
	description.numberOfLines = 3;
	description.text = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"description"];
	[view addSubview:description];
    [description release];
	
	UILabel * eCost =[[UILabel alloc]init];
	eCost.backgroundColor = [UIColor clearColor];
	eCost.textColor = [UIColor blueColor];
	eCost.frame=CGRectMake(150, 80, 240,50);
	eCost.font = [UIFont systemFontOfSize:14];
	eCost.textAlignment = UITextAlignmentLeft;
	eCost.lineBreakMode = UILineBreakModeWordWrap;
	eCost.numberOfLines = 3;
	NSString*ecostText = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"EstimatedCost"];
	NSString *cellText = [NSString stringWithFormat:@"Estimated Price: $%@", ecostText];
	eCost.text =cellText;  
	[view addSubview:eCost];
    [eCost release];
	
	CGRect frame = CGRectMake(10, 40, 60, 60);
    UIImageView *mainimage = [[UIImageView alloc] initWithFrame:frame];

    [mainimage setImage:[UIImage imageWithContentsOfFile:[[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"thumb"]]];
	[view addSubview:mainimage];
    [mainimage release];	
    
    cell.accessoryView = view;
    [view release];
	
	cell.backgroundColor = [UIColor clearColor];
	
	return cell;
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 125;	
}

-(void)viewWillAppear:(BOOL)animated{
	
	[super viewWillAppear:animated];

//    [appDelegate showSplashView:@"Searching..."];
    self.m_tableView.backgroundColor = [UIColor clearColor];
    self.m_tableView.separatorColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	
    if (isEnter) {
       
        if (isFilter) {
            SearchID = 3;
        }
        [self performSearch:nil];            
    }
       
    Navlabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 400, 44)];
    Navlabel.backgroundColor = [UIColor clearColor];
    Navlabel.font = [UIFont boldSystemFontOfSize:16.0];
    Navlabel.textAlignment = UITextAlignmentCenter;
    Navlabel.textColor =[UIColor whiteColor];
    Navlabel.text= [NSString stringWithFormat:@"(%d) Results", [self.httpResponse count]];
    self.navigationItem.titleView = Navlabel;		
    [Navlabel release];
//    [appDelegate hiddenSplashView];
    [self.m_tableView reloadData];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	UIView* customView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 320.0, 55.0)];
	customView.backgroundColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	
	UILabel * headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(8.0, 0.0, 120.0, 25.0)];
	headerLabel.backgroundColor = [UIColor clearColor];
	headerLabel.opaque = NO;
	headerLabel.textColor = [UIColor whiteColor];
	headerLabel.highlightedTextColor = [UIColor whiteColor];
	headerLabel.font = [UIFont boldSystemFontOfSize:10];
	headerLabel.adjustsFontSizeToFitWidth=YES;
	headerLabel.text = getDetination;
	
	UILabel * headerLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(8.0, 22.0, 120.0, 25.0)];
	headerLabel1.backgroundColor = [UIColor clearColor];
	headerLabel1.opaque = NO;
	headerLabel1.textColor = [UIColor whiteColor];
	headerLabel1.highlightedTextColor = [UIColor whiteColor];
	headerLabel1.font = [UIFont boldSystemFontOfSize:10];
	headerLabel1.adjustsFontSizeToFitWidth=YES;
    
	headerLabel1.text = self.getType;
	
	UILabel * headerLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(130.0, 0.0, 180.0, 25.0)];
	headerLabel2.backgroundColor = [UIColor clearColor];
	headerLabel2.opaque = NO;
	headerLabel2.textColor = [UIColor whiteColor];
	headerLabel2.highlightedTextColor = [UIColor whiteColor];
	headerLabel2.font = [UIFont boldSystemFontOfSize:10];
	NSString *date1 = [NSString stringWithFormat:@"%@",getDateIn];
	NSString *date2 = [NSString stringWithFormat:@" %@", getDateOut];
	NSString *detailDate = [date1 stringByAppendingFormat:@"--"];
	NSString *Append = [detailDate stringByAppendingString:date2];
	headerLabel2.adjustsFontSizeToFitWidth=YES;
	headerLabel2.textAlignment = UITextAlignmentLeft;
	headerLabel2.text = Append;
	
	
	UILabel * headerLabel3 = [[UILabel alloc] initWithFrame:CGRectMake(175.0, 22.0, 135.0, 25.0)];
	headerLabel3.backgroundColor = [UIColor clearColor];
	headerLabel3.opaque = NO;
	headerLabel3.textColor = [UIColor whiteColor];
	headerLabel3.highlightedTextColor = [UIColor whiteColor];
	headerLabel3.font = [UIFont boldSystemFontOfSize:10];
	NSString *guestNo = [NSString stringWithFormat:@"Guests: %@",self.getGuest];
	headerLabel3.adjustsFontSizeToFitWidth = YES;
	headerLabel3.textAlignment = UITextAlignmentLeft;
    
	headerLabel3.text = guestNo;
	
	[customView addSubview:headerLabel3];
	[customView addSubview:headerLabel2];
	[customView addSubview:headerLabel1];
	[customView addSubview:headerLabel];
    
	return customView;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
	return 55;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
	return 0;
	
}

#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
    isEnter = NO;
	DetailRootViewController *detailViewController = [[DetailRootViewController alloc] initWithNibName:@"DetailRootViewController" bundle:nil];
	
	detailViewController.productID = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"productID"];	
	[detailViewController setBackstate:1];
	
	NSString *date1 = [NSString stringWithFormat:@"%@",getDateIn];
	NSString *date2 = [NSString stringWithFormat:@" %@", getDateOut];
	NSString *detailDate = [date1 stringByAppendingFormat:@"--"];
	NSString *Append = [detailDate stringByAppendingString:date2];
	NSString *priceL = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"price"];
	self.starString = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"rating"];
	
	detailViewController.YachtPriceStr = priceL;
	detailViewController.rankingYacht = self.starString;
	detailViewController.YachtName1Str = getDetination;
	detailViewController.YachtDate1Str = Append;
	detailViewController.YachtGuest1Str = self.getGuest;
	detailViewController.YachtStay1Str = getType;
    
	[self.navigationController pushViewController:detailViewController animated:YES];
	[self.m_tableView deselectRowAtIndexPath:indexPath animated:YES];
	[detailViewController release];
}

-(IBAction)popPickerView{
	
	CGRect frame = self.pickerView.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.75];
	self.pickerView.alpha = 9;
	frame.origin.y = 220.0;
	self.pickerView.frame = frame;
	[UIView commitAnimations];
}


-(IBAction)pickerViewGoDown{
	
	CGRect frame = self.pickerView.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.75];
	frame.origin.y = 480.0;
	self.pickerView.alpha = 0;
	self.pickerView.frame = frame;
	[UIView commitAnimations];
	
	[self performSearch:self.pickingSort];
	[self.m_tableView reloadData];    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView;
{
	return 1;
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	SearchID = 2;
	self.pickingSort = [localSortArry objectAtIndex:row];
	
}


- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component;
{
	return [localSortArry count];
}


- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component;
{
	return [localSortArry objectAtIndex:row];
}

#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
    
//    m_tableView = nil;
//    m_searchBar = nil;
//    praseURL = nil;
//    httpResponse = nil;
//    item = nil;
//    ContentsArr = nil;
//    disableViewOverlay = nil;
//    
//    baseURL = nil;
//    totalDay = nil;
//    getDetination = nil;
//    getGuest = nil;
//    getType = nil;
//    starString = nil;
//    filter = nil;
//    searchResult = nil;
//    priceString = nil;
//    urlimg = nil;
//    getDateIn = nil;
//    getDateOut = nil;
//    pickerView = nil;
//    pickerControler = nil;
//    pickingSort = nil;    
//    inDay = nil;
//    inMonth = nil;
//    inYear = nil;
//    outDay = nil;
//    outMonth = nil;
//    outYear = nil;
//    tempStr = nil;
}


- (void)dealloc {
    [super dealloc];
    
//    [m_tableView release];
//    [m_searchBar release];
//    [praseURL release];
//    [httpResponse release];
//    [item release];
//    [ContentsArr release];
//    [disableViewOverlay release];
//    
//    [baseURL release];
//    [totalDay release];
//    [getDetination release];
//    [getGuest release];
//    [getType release];
//    [starString release];
//    [filter release];
//    [searchResult release];
//    [priceString release];
//    [urlimg release];
//    [getDateIn release];
//    [getDateOut release];
//    [pickerView release];
//    [pickerControler release];
//    [pickingSort release];
//    
//    [inDay release];
//    [inMonth release];
//    [inYear release];
//    [outDay release];
//    [outMonth release];
//    [outYear release];
//    [tempStr release];
}

@end

