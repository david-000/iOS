    //
//  CalenderViewController.m
//  Yacht
//
//  Created by Askone on 9/20/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "CalenderViewController.h"
#import "Constants.h"

@implementation CalenderViewController
@synthesize dataArray, dataDictionary;

@synthesize ArrivalDate1,DeparatureDate1;
@synthesize ArrivalDate2,DeparatureDate2;

extern NSString *defaultEndDate;

- (void) viewDidLoad{
	[super viewDidLoad];
	//[self.monthView selectDate:[NSDate month]];
	
	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(30, 0, 160, 44)];
	label.backgroundColor = [UIColor clearColor];
	label.font = [UIFont boldSystemFontOfSize:16.0];
	label.textAlignment = UITextAlignmentCenter;
	label.textColor =[UIColor whiteColor];
	label.lineBreakMode = UILineBreakModeWordWrap;
	label.numberOfLines = 1;
	label.text= @"Select Dates";
	self.navigationItem.titleView = label;		
	[label release];
    
    isPoped = NO;
	
//	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init]; 
//    [dateFormatter setDateFormat:@"MMM dd, YYYY"]; 
//	NSDate *now = [[NSDate alloc] init];
//    [dateFormatter release];
//    [self.monthView selectDate:now];
    
    switch (CheckResultForFilter) {
		case 0:{			
            if(ArrivalDate4)
            {
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"dd-MM-yyyy HH:mm:ss"];    
                NSDate *displayDate = [formatter dateFromString:ArrivalDate4];
//                NSLog(@"displayDate ==%@",displayDate);
                [self.monthView selectDate:displayDate];
            }			
		}break;
            
		case 1:{
            if(DeparatureDate4)
            {
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"dd-MM-yyyy HH:mm:ss"];    
                NSDate *displayDate = [formatter dateFromString:DeparatureDate4];
//                NSLog(@"goto startDate ==%@",displayDate);
                [self.monthView selectDate:displayDate];
            }
            else
            {
                if(ArrivalDate4)
                {
                    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                    [formatter setDateFormat:@"dd-MM-yyyy HH:mm:ss"];    
                    NSDate *displayDate = [formatter dateFromString:ArrivalDate4];
                    
                    NSDate * endDate = [NSDate dateWithTimeInterval:(24*60*60*7) sinceDate:displayDate];
//                    NSLog(@"goto endDate ==%@",endDate);
                    [self.monthView selectDate:endDate];
                }
                else
                {
                    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                    [formatter setDateFormat:@"dd-MM-yyyy HH:mm:ss"];    
                    NSDate *displayDate = [formatter dateFromString:defaultEndDate];
//                    NSLog(@"displayDate ==%@",displayDate);
                    [self.monthView selectDate:displayDate];
                }
            }
        }break;
    }
    
//    self.navigationItem.hidesBackButton = YES;
}

- (void) viewDidAppear:(BOOL)animated{
	[super viewDidAppear:animated];
	
    
   
	
}

/*
- (NSArray*) calendarMonthView:(TKCalendarMonthView*)monthView marksFromDate:(NSDate*)startDate toDate:(NSDate*)lastDate{
	[self generateRandomDataForStartDate:startDate endDate:lastDate];
	return dataArray;
}*/


- (void) calendarMonthView:(TKCalendarMonthView*)monthView didSelectDate:(NSDate*)date{
	
    if(isPoped == YES)
    {
        isPoped = NO;
        return;
    }
	TKDateInformation info = [date dateInformation] ;
	NSDate *myTimeZoneDay = [NSDate dateFromDateInformation:info];
	
	NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
	[formatter setDateFormat:@"eee, MMM dd, YYYY"]; 
	
	NSDateFormatter *formatter2 = [[NSDateFormatter alloc] init];
	[formatter2 setDateFormat:@"dd-MM-yyyy HH:mm:ss"];


	
	switch (CheckResultForFilter) {
		case 0:{
			
			self.ArrivalDate1 = [formatter stringFromDate:myTimeZoneDay];
			self.ArrivalDate2 = [formatter2 stringFromDate:myTimeZoneDay];

			ArrivalDate = [[NSString alloc] initWithString:self.ArrivalDate1];
			ArrivalDate4 = [[NSString alloc] initWithString:self.ArrivalDate2];
            days = 7;
//			NSLog(@"ArrivalDate4 %@", ArrivalDate4);
           
		}break;
		case 1:{
			
			
			self.DeparatureDate1 = [formatter stringFromDate:myTimeZoneDay];
			self.DeparatureDate2 = [formatter2 stringFromDate:myTimeZoneDay];
			
			DeparatureDate = [[NSString alloc] initWithString:self.DeparatureDate1];
			
//			NSLog(@"ArrivalDate2 = %@", ArrivalDate4);
//			NSLog(@"DeparatureDate2 = %@", DeparatureDate2);

			NSDate *startdate = [formatter2 dateFromString:ArrivalDate4];
//			NSLog(@"startdate ==%@",startdate);
			
			NSDate *enddate = [formatter2 dateFromString:self.DeparatureDate2];
//			NSLog(@"enddate ==%@",enddate);
            
            
			DeparatureDate4 = [[NSString alloc] initWithString:self.DeparatureDate2];
		
			
			int i = [startdate timeIntervalSinceNow];
			int j = [enddate timeIntervalSinceNow];
			double X = j-i;
			
			days = (int)((double)X/(3600.0*24.00));
//			NSLog(@"Total Days Between::%d",days);
		
			NSString *restrictSelection = [NSString stringWithFormat:@"%d", days];
			restrictSelection = [restrictSelection substringToIndex:1];
			if ([restrictSelection isEqualToString:@"-"]) {
				
				 UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Date Selection Error" message:@"Please Select Correct Date" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
				[alertView show];
				[alertView release];
								
			}			
			
		}

			break;
	}
    
    [self.navigationController popViewControllerAnimated:YES];
    isPoped = YES;
}

	/*
	if (CheckResultForFilter==0){
	
	 
	 int i = [startdate timeIntervalSince1970];
	 int j = [toDate timeIntervalSince1970];
	 
	 double X = j-i;
	 
	 int days=(int)((double)X/(3600.0*24.00));
	 NSLog(@"Total Days Between::%d",days);
	 
	 


	}else if (CheckResultForFilter==1){
		
	}
}
*/




- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
	
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {	
	NSArray *ar = [dataDictionary objectForKey:[self.monthView dateSelected]];
	if(ar == nil) return 0;
	return [ar count];
}
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tv dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    
	
    
	NSArray *ar = [dataDictionary objectForKey:[self.monthView dateSelected]];
	cell.textLabel.text = [ar objectAtIndex:indexPath.row];
	
    return cell;
	
}

/*
- (void) generateRandomDataForStartDate:(NSDate*)start endDate:(NSDate*)end{
	// this function sets up dataArray & dataDictionary
	// dataArray: has boolean markers for each day to pass to the calendar view (via the delegate function)
	// dataDictionary: has items that are associated with date keys (for tableview)
	
	
	
	self.dataArray = [NSMutableArray array];
	self.dataDictionary = [NSMutableDictionary dictionary];
	
	NSDate *d = start;
	while(YES){
		
		int r = arc4random();
		if(r % 3==1){
			[self.dataDictionary setObject:[NSArray arrayWithObjects:@"Item one",@"Item two",nil] forKey:d];
			[self.dataArray addObject:[NSNumber numberWithBool:YES]];
			
		}else if(r%4==1){
			[self.dataDictionary setObject:[NSArray arrayWithObjects:@"Item one",nil] forKey:d];
			[self.dataArray addObject:[NSNumber numberWithBool:YES]];
			
		}else
			[self.dataArray addObject:[NSNumber numberWithBool:NO]];
		
		
		TKDateInformation info = [d dateInformationWithTimeZone:[NSTimeZone systemTimeZone]];
		info.day++;
		d = [NSDate dateFromDateInformation:info timeZone:[NSTimeZone systemTimeZone]];
		if([d compare:end]==NSOrderedDescending) break;
	}
	
}
*/


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
