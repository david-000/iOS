//
//  TableGalleryController.m
//  Yacht
//
//  Created by Askone on 10/5/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "TableGalleryController.h"


@implementation TableGalleryController
@synthesize webView = _webView;
@synthesize PIDImages;

#pragma mark -
#pragma mark View lifecycle




- (void)viewDidLoad {
    [super viewDidLoad];
	
	/*
	UILabel * Navlabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 400, 44)];
	Navlabel.backgroundColor = [UIColor clearColor];
	Navlabel.font = [UIFont boldSystemFontOfSize:18.0];
	Navlabel.textAlignment = UITextAlignmentCenter;
	Navlabel.textColor =[UIColor whiteColor];
	Navlabel.text= @"Photos";
	self.navigationItem.titleView = Navlabel;		
	[Navlabel release];*/
	
	self.title = @"Photos";
	
	NSString *GalleryURL= [NSString stringWithFormat:@"http://www.charterdigest.com/iPhone/gallery.php?act=img&pid=%@#thumbs_container",PIDImages];
	
	NSLog(@"GalleryURL %@", GalleryURL);
	NSURL *URLString = [NSURL URLWithString:GalleryURL];
	NSURLRequest *urlRequest = [NSURLRequest requestWithURL:URLString];
	
	[self.webView loadRequest:urlRequest];
	self.webView.backgroundColor = [UIColor clearColor];
	self.webView.clipsToBounds = YES;
	self.webView.opaque = NO;
	
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}


- (void)webViewDidStartLoad:(UIWebView *)webView {
	[indicator startAnimating];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
	[indicator stopAnimating];
	indicator.hidesWhenStopped=YES;
}
/*
 - (void)viewWillAppear:(BOOL)animated {
 [super viewWillAppear:animated];
 }
 */
/*
 - (void)viewDidAppear:(BOOL)animated {
 [super viewDidAppear:animated];
 }
 */
/*
 - (void)viewWillDisappear:(BOOL)animated {
 [super viewWillDisappear:animated];
 }
 */
/*
 - (void)viewDidDisappear:(BOOL)animated {
 [super viewDidDisappear:animated];
 }
 */

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return YES;//(interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	[self.webView release];
	self.webView = nil;
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
	[self.webView release];
 
}


@end

