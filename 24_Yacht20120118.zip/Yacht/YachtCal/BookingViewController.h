//
//  BookingViewController.h
//  Yacht
//
//  Created by Askone on 9/17/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BookingViewController : UIViewController <UIWebViewDelegate>{

	UIWebView *_webView;
	NSString *YachtID;
	NSString *pidNO;
	IBOutlet UIActivityIndicatorView *indicator;

}
@property (nonatomic, retain)IBOutlet UIWebView *webView;
@property (nonatomic, retain)NSString *YachtID;
@property (nonatomic, retain)NSString *pidNO;


@end
