//
//  DetailRootViewController.h
//  Yacht
//
//  Created by Askone on 9/16/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"
#import "ASIHTTPRequest.h"
@class AsyncImageView;


@interface DetailRootViewController : UIViewController <UIScrollViewDelegate, UITableViewDelegate, UITableViewDataSource, UIWebViewDelegate, UIAlertViewDelegate>{

	IBOutlet UIButton *bookNow;
	
	IBOutlet UILabel *YachtName;
	IBOutlet UILabel *YachtPrice;
	IBOutlet UILabel *YachtGuest;
	IBOutlet UILabel *YachtFacility;
	IBOutlet UILabel *YachtRooms;
	IBOutlet UILabel *YachtSleeps;
	IBOutlet UILabel *YachtBaths;
	IBOutlet UIImageView *YachtRank;
	IBOutlet UILabel *YachtDescription;
	
	IBOutlet UITextView *textView;
	IBOutlet UITextView *scrolltext;
	
	UIScrollView *_scrollView;
	UITableView *_tableView;
	
	NSString *productID;
	NSString *rankingYacht;
	
	NSURL *myURL;
	IBOutlet AsyncImageView *myImageView;
	NSString *imageFromURL;
	AsyncImageView*asyncImage;
	ASIHTTPRequest *ASIRequest;
	
	NSMutableArray *httpResponse;
	NSMutableDictionary *item;
	NSArray *ContentsArr;
	NSURL *baseURL;
	
	NSMutableArray *YachtDetails;
	
	NSString *YachtName1Str;
	NSString *YachtDate1Str;
	NSString *YachtGuest1Str;
	NSString *YachtStay1Str;

	IBOutlet UILabel *YachtName1Lab;
	IBOutlet UILabel *YachtDate1Lab;
	IBOutlet UILabel *YachtGuestLab;
	IBOutlet UILabel *YachtStay1Lab;
	NSString* YachtPriceStr;
	IBOutlet UIImageView *RatingImage;
    
	
	UIWebView *_webView;
    
    UIBarButtonItem *favoItem;
    int     backState;
    
    UIAlertView *alertView;
    
    IBOutlet UIView *disableViewOverlay;
    
    IBOutlet UIButton *m_button;
    IBOutlet UILabel *m_description;

}
@property (nonatomic, retain)NSString* YachtPriceStr;
@property (nonatomic, retain)IBOutlet UIWebView *webView;
@property (nonatomic, retain)NSString *YachtName1Str;
@property (nonatomic, retain)NSString *YachtDate1Str;
@property (nonatomic, retain)NSString *YachtGuest1Str;
@property (nonatomic, retain)NSString *YachtStay1Str;

@property (nonatomic, retain)NSMutableArray *YachtDetails;
@property (nonatomic, retain)IBOutlet UITableView *tableView;
@property (nonatomic, retain)UIButton *bookNow;

@property (nonatomic, retain)NSString *description;
@property (nonatomic, retain)NSString *price;
@property (nonatomic, retain)NSString *facility;
@property (nonatomic, retain)NSString *productID;

@property (nonatomic, retain)NSString *imageFromURL;
@property (nonatomic, retain)AsyncImageView *myImageView;
@property (nonatomic, retain)NSURL *myURL;

@property (nonatomic, retain)UILabel *YachtName;
@property (nonatomic, retain)UILabel *YachtPrice;
@property (nonatomic, retain)UILabel *YachtGuest;
@property (nonatomic, retain)UILabel *YachtFacility;
@property (nonatomic, retain)UIImageView *YachtRank;

@property (retain, nonatomic) ASIHTTPRequest *ASIRequest;

@property (nonatomic, retain)IBOutlet UIScrollView *scrollView;
@property (nonatomic, retain)NSMutableArray *httpResponse;
@property (nonatomic, retain)NSMutableDictionary *item;
@property (nonatomic, retain)NSArray *ContentsArr;
@property (nonatomic, retain)NSURL *baseURL;
@property (nonatomic, retain)NSString *rankingYacht;
@property (nonatomic, retain)UITextView *textView;
@property (nonatomic, retain)UIAlertView *alertView;
@property (nonatomic, retain)IBOutlet UIView *disableViewOverlay;
@property (nonatomic, retain)IBOutlet UIButton *m_button;
@property (nonatomic, retain)IBOutlet UILabel *m_description;

-(IBAction)bookingYacht:(id)sender;
-(IBAction)setFavorite:(id)sender;

-(void)setBackstate:(int)state;
-(int)getBackState;

-(void)viewback;
-(IBAction)hideAlert:(id)sender;
@end
