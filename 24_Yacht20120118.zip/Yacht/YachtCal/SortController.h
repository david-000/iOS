//
//  SortController.h
//  Yacht
//
//  Created by Askone on 10/10/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"
#import "ASIHTTPRequest.h"
#import "YachtAppDelegate.h"


@class AsyncImageView;

@interface SortController : UIViewController <UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate> {

	UISwitch *switchView;
	UITableView *m_tableView;
	
	UISearchBar *m_searchBar;
	
	NSString *YachtName1Str;
	NSString *YachtDate1Str;
	NSString *YachtGuest1Str;
	NSString *YachtType1Str;
	
	NSString *searchTxt;
	NSString *AmenitiesTxt;
	NSString *PriceMinTxt;
	NSString *priceMaxTxt;
	NSString *ManuFactureTxt;
	
	NSString *getDateIn;
	NSString *getDateOut;
	NSString *MinimumP1;
	NSString *MaximumP1;
	NSString *yName;
	
	NSString *URLPath;
		
	BOOL isSearch;
	BOOL isTable;
	BOOL isFilter;
	BOOL isActive;
	
	IBOutlet UIImageView *bImage;
	
	NSMutableArray *httpResponse;
	NSMutableDictionary *item;
	NSArray *ContentsArr;
	NSURL *baseURL;
	
	NSMutableArray *httpResponse1;
	NSMutableDictionary *item1;
	NSArray *ContentsArr1;
	NSURL *baseURL1;
	NSString *URLString;
	
	/////////
	NSMutableArray *httpResponse3;
	NSMutableDictionary *item3;
	NSArray *ContentsArr3;
	NSURL *baseURL3;
	NSMutableArray *myArr;
    NSMutableArray *tempArray;

    NSString *inDay;
    NSString *inMonth;
    NSString *inYear;
    NSString *outDay;
    NSString *outMonth;
    NSString *outYear;
    
    YachtAppDelegate *appDelegate;
}
@property (nonatomic, retain)NSMutableArray *myArr;
@property (nonatomic, retain)NSMutableArray *tempArray;

@property (nonatomic, retain)NSString *searchTxt;
@property (nonatomic, retain)NSString *AmenitiesTxt;
@property (nonatomic, retain)NSString *PriceMinTxt;
@property (nonatomic, retain)NSString *priceMaxTxt;
@property (nonatomic, retain)NSString *ManuFactureTxt;


@property (nonatomic, retain)NSString *YachtName1Str;
@property (nonatomic, retain)NSString *YachtDate1Str;
@property (nonatomic, retain)NSString *YachtGuest1Str;
@property (nonatomic, retain)NSString *YachtType1Str;
@property (nonatomic, retain)UIImageView *bImage;

@property (nonatomic, retain)NSString *MinimumP1;
@property (nonatomic, retain)NSString *MaximumP1;
@property (nonatomic, retain)NSString *yName;
@property (nonatomic) BOOL isSearch;
@property (nonatomic) BOOL isTable;
@property (nonatomic) BOOL isFilter;

@property (nonatomic, retain)NSMutableArray *httpResponse;
@property (nonatomic, retain)NSMutableDictionary *item;
@property (nonatomic, retain)NSArray *ContentsArr;
@property (nonatomic, retain)NSURL *baseURL;

@property (nonatomic, retain)NSMutableArray *httpResponse1;
@property (nonatomic, retain)NSMutableDictionary *item1;
@property (nonatomic, retain)NSArray *ContentsArr1;
@property (nonatomic, retain)NSURL *baseURL1;

@property (nonatomic, retain)NSString *getDateIn;
@property (nonatomic, retain)NSString *getDateOut;

////////

@property (nonatomic, retain)NSMutableArray *httpResponse3;
@property (nonatomic, retain)NSMutableDictionary *item3;
@property (nonatomic, retain)NSArray *ContentsArr3;
@property (nonatomic, retain)NSURL *baseURL3;

@property (nonatomic, retain)IBOutlet UITableView *m_tableView;

@property (nonatomic, retain)IBOutlet UISearchBar *m_searchBar;


@property (nonatomic, retain)NSString *URLString;

@property (nonatomic, retain)NSString *inDay;
@property (nonatomic, retain)NSString *inMonth;
@property (nonatomic, retain)NSString *inYear;
@property (nonatomic, retain)NSString *outDay;
@property (nonatomic, retain)NSString *outMonth;
@property (nonatomic, retain)NSString *outYear;

-(IBAction)popSearchView;
-(IBAction)popTableView;
-(IBAction)popFilterView;
-(IBAction)popPickerView;

-(void)pickerViewGoDown;
-(IBAction)dismodolSearch;
-(IBAction)dismodolTableView;
-(IBAction)dismodelFilter;

-(void)getResponse:(id)sender;
-(void)getResponse1:(id)sender;

-(IBAction)doSearch:(id)sender;
-(IBAction)ResetSearch:(id)sender;

-(BOOL)isSwitch:(NSInteger)index;

-(void)parserFilter:(NSString*)response;
-(void)parserMain:(NSString *)result Index:(int)index;

-(void)getURL;

-(void)filterSearch;

@end
