//
//  CalenderViewController.h
//  Yacht
//
//  Created by Askone on 9/20/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TapkuLibrary/TapkuLibrary.h>



@interface CalenderViewController : TKCalendarMonthTableViewController {

	NSMutableArray *dataArray; 
	NSMutableDictionary *dataDictionary;
	NSString *ArrivalDate1;
	NSString *ArrivalDate2;
	
	NSString *DeparatureDate1;
	NSString *DeparatureDate2;
    
    BOOL isPoped;

}

@property (retain,nonatomic) NSMutableArray *dataArray;
@property (retain,nonatomic) NSMutableDictionary *dataDictionary;

@property (nonatomic, retain)NSString *ArrivalDate1;
@property (nonatomic, retain)NSString *ArrivalDate2;

@property (nonatomic, retain)NSString *DeparatureDate1;
@property (nonatomic, retain)NSString *DeparatureDate2;


//- (void) generateRandomDataForStartDate:(NSDate*)start endDate:(NSDate*)end;


@end
