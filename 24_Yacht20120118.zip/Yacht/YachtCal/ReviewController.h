//
//  ReviewController.h
//  Yacht
//
//  Created by Askone on 10/10/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequest.h"


@interface ReviewController : UIViewController {

	NSString *UserReviews;
	UIWebView *_webView;
	IBOutlet UIActivityIndicatorView *indicator;
	
	
}
@property (nonatomic, retain)IBOutlet UIWebView *webView;
@property (nonatomic, retain)NSString *UserReviews;

@end
