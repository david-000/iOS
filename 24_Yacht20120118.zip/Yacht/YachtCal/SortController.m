//
//  SortController.m
//  Yacht
//
//  Created by Askone on 10/10/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "FavViewController.h"
#import "SortController.h"
#import <QuartzCore/QuartzCore.h>
#import "Constants.h"
#import "AmenitiesModel.h"

#define kOnOffToggle @"onOff"


@interface NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding;
@end

@implementation NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding
{
	return (NSString *) CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)self,
																NULL, (CFStringRef)@"& ;@$+{}<>,",
																CFStringConvertNSStringEncodingToEncoding(encoding));
}  
@end


@implementation SortController
@synthesize YachtName1Str,YachtDate1Str,YachtGuest1Str,YachtType1Str;
@synthesize httpResponse,item,ContentsArr,baseURL;
@synthesize httpResponse1, item1, ContentsArr1, baseURL1;
/////
@synthesize httpResponse3, item3, ContentsArr3, baseURL3;

@synthesize myArr, tempArray;
@synthesize m_tableView;
@synthesize m_searchBar;
@synthesize bImage;

@synthesize searchTxt,AmenitiesTxt,PriceMinTxt,priceMaxTxt,ManuFactureTxt;

@synthesize isSearch;
@synthesize isTable;
@synthesize isFilter;
@synthesize MinimumP1,MaximumP1;
@synthesize URLString;

@synthesize getDateIn;
@synthesize getDateOut;
@synthesize yName;

@synthesize inDay;
@synthesize inMonth;
@synthesize inYear;
@synthesize outDay;
@synthesize outMonth;
@synthesize outYear;
#pragma mark -
#pragma mark View lifecycle



-(void)getResponse:(id)sender{
	
    if (appDelegate.amenitiesArray) {
        [appDelegate.amenitiesArray removeAllObjects];
    }
    self.httpResponse = [[NSMutableArray alloc]init];
    
    if (self.isFilter) {
        [self filterSearch];
    }
    else{
        NSString *parseURL = [NSString stringWithFormat:@"http://www.charterdigest.com/index.php?user=search1&regiunea=%@",[appDelegate urlEncoded:YachtName1Str]];
        NSString *parameter = [NSString stringWithFormat:@"&typeofproperties=%@&sleeps=%@&ziua=%@&luna=%@&an=%@&ziual=%@&lunal=%@&anl=%@&salji=Check+Availability",appDelegate.yachtTypeId,YachtGuest1Str,self.inDay,self.inMonth,self.inYear,self.outDay,self.outMonth,self.outYear];
        NSString *encodedStr = [parameter encodeString:NSASCIIStringEncoding];
        parseURL = [NSString stringWithFormat:@"%@%@",parseURL,encodedStr];
            
        baseURL = [NSURL URLWithString:parseURL];
        ASIHTTPRequest *aRequest = [ASIHTTPRequest requestWithURL:baseURL];
        [aRequest setDelegate:self];
        [aRequest startAsynchronous];
            
        NSURLRequest *request = [NSURLRequest requestWithURL:baseURL];
        [[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
            
        NSString *strNew = [[NSString alloc] initWithContentsOfURL:baseURL encoding:NSUTF8StringEncoding error:nil];           
        if (strNew != nil) {
            [self parserMain:strNew Index:0];
        }
        
        [strNew release];            
    }        
}

-(void)getResponse1:(id)sender{
	
	self.httpResponse1 = [[NSMutableArray alloc]init];
	NSString *URLPath1 = [NSString stringWithFormat:@"http://www.charterdigest.com/iPhone/manufacturer.php?act=manufacturer"];
	NSString *encodedStr = [URLPath1 encodeString:NSASCIIStringEncoding];
//	NSLog(@"encoded URL --> %@", encodedStr);
	NSURL *url = [NSURL URLWithString:encodedStr];
	ASIHTTPRequest *aRequest = [ASIHTTPRequest requestWithURL:url];
	[aRequest setDelegate:self];
	[aRequest startAsynchronous];
	
	baseURL1 = [NSURL URLWithString:encodedStr];
	NSURLRequest *request = [NSURLRequest requestWithURL:baseURL1];
	[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
	NSString * strNew = [[NSString alloc] initWithContentsOfURL:baseURL1 encoding:NSUTF8StringEncoding error:nil];
    if (strNew != nil) {
 
	NSArray *arr =[strNew componentsSeparatedByString:@"</br>"];
	for (int i=0;i<[arr count]-1; i++) {
		self.ContentsArr1 = [[arr objectAtIndex:i] componentsSeparatedByString:@"|"];
		self.item1 = [[NSMutableDictionary alloc] init];
		if ([self.ContentsArr1 count]>=1) {
			[self.item1 setObject:[ContentsArr1 objectAtIndex:0] forKey:@"manufacturer"];
			[self.httpResponse1 addObject:self.item1];
		}
        [self.item1 release];
	}  
        
    }
}

- (void)viewDidLoad {
	[switchView setOn:NO animated:YES];  
	NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
	switchView.on = [userDefaults boolForKey:kOnOffToggle];
	if ([userDefaults boolForKey:kOnOffToggle]) {
		switchView.on = [userDefaults floatForKey:kOnOffToggle];
		
	}
	appDelegate = [YachtAppDelegate sharedAppDelegate];
	self.m_searchBar.tintColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	
	
	self.myArr = [[NSMutableArray alloc] init];
    
	
	self.ManuFactureTxt = @"null";
	self.searchTxt = @"null";
	
	self.MinimumP1 = @"null";
	self.MaximumP1 = @"null";
    
    [self getURL];
	[self getResponse:nil];
    self.m_tableView.backgroundColor = [UIColor clearColor];
    self.m_tableView.separatorColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	[self.m_tableView reloadData];
	isActive = NO;
	isSearch = NO;
	isTable = NO;
	
	[self.bImage.layer setCornerRadius: 7.0];
    [self.bImage.layer setMasksToBounds:YES];
	
	[self.m_searchBar.layer setCornerRadius:7.0];
    [self.m_searchBar.layer setMasksToBounds:YES];
//	[appDelegate hiddenSplashView];
	
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
	[super viewDidLoad];
    
	
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
	
	self.searchTxt = searchBar.text;
	
    [searchBar resignFirstResponder];
    appDelegate.amenitiesArray = [appDelegate.dbManager selectAmenitiesListFromDB:self.searchTxt];
	
    self.m_tableView.allowsSelection = YES;
    self.m_tableView.scrollEnabled = YES;
    [self.m_tableView reloadData];
	
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
	self.searchTxt = searchBar.text;
	
    appDelegate.amenitiesArray = [appDelegate.dbManager selectAmenitiesListFromDB:self.searchTxt];
	
    self.m_tableView.allowsSelection = YES;
    self.m_tableView.scrollEnabled = YES;
    [self.m_tableView reloadData];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar
{
	[self.m_searchBar resignFirstResponder];
	[self.m_searchBar setText:@""];
}

-(IBAction)popSearchView
{
    
}
-(IBAction)popTableView{
    
}
-(IBAction)popFilterView{
    
    [self dismissModalViewControllerAnimated:YES];
}
-(IBAction)popPickerView{
    
}

-(void)pickerViewGoDown{
    
}
-(IBAction)dismodolSearch{
    
}
-(IBAction)dismodolTableView{
    
}
-(IBAction)dismodelFilter{
    
}

-(IBAction)doSearch:(id)sender{
    
}
-(IBAction)ResetSearch:(id)sender{
    
}

-(void)filterSearch
{
  
    NSString *url = [NSString stringWithFormat:@"http://www.charterdigest.com/index.php?user=search1&regiunea=%@",[appDelegate urlEncoded:YachtName1Str]];
    NSString *parameter = [NSString stringWithFormat:@"&ziua=%@&luna=%@&an=%@&ziual=%@&lunal=%@&anl=%@&typeofproperties=%@",self.inDay,self.inMonth,self.inYear,self.outDay,self.outMonth,self.outYear,appDelegate.yachtTypeId];
    
    NSString *parsarUrl = [parameter encodeString:NSASCIIStringEncoding];
    
    
    for (int i = 0; i < [appDelegate.amenitiesArray count]; i++) {
        NSString *str = [appDelegate.amenitiesArray objectAtIndex:i];
        if ([str isEqualToString:@"111"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&parcare=1",parsarUrl];
        }else if ([str isEqualToString:@"222"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&animale=1",parsarUrl];
        }else if ([str isEqualToString:@"333"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&tv=1",parsarUrl];
        }else if ([str isEqualToString:@"888"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&masinaspalat=1",parsarUrl];
        }else if ([str isEqualToString:@"555"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&internet=1",parsarUrl];
        }else if ([str isEqualToString:@"666"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&telefon=1",parsarUrl];
        }else if ([str isEqualToString:@"777"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&piscina=1",parsarUrl];
        }else if ([str isEqualToString:@"444"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&handicap=1",parsarUrl];
        }else if ([str isEqualToString:@"24"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[24]=1",parsarUrl];
        }else if ([str isEqualToString:@"23"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[23]=1",parsarUrl];
        }else if ([str isEqualToString:@"22"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[22]=1",parsarUrl];
        }else if ([str isEqualToString:@"21"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[21]=1",parsarUrl];
        }else if ([str isEqualToString:@"19"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[19]=1",parsarUrl];
        }else if ([str isEqualToString:@"18"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[18]=1",parsarUrl];
        }else if ([str isEqualToString:@"16"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[16]=1",parsarUrl];
        }else if ([str isEqualToString:@"15"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[15]=1",parsarUrl];
        }else if ([str isEqualToString:@"14"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[14]=1",parsarUrl];
        }else if ([str isEqualToString:@"13"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[13]=1",parsarUrl];
        }else if ([str isEqualToString:@"12"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[12]=1",parsarUrl];
        }else if ([str isEqualToString:@"9"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[9]=1",parsarUrl];
        }else if ([str isEqualToString:@"8"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[8]=1",parsarUrl];
        }else if ([str isEqualToString:@"7"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[7]=1",parsarUrl];
        }else if ([str isEqualToString:@"6"]) {
            parsarUrl = [NSString stringWithFormat:@"%@&amd[6]=1",parsarUrl];
        }
    }
    url = [NSString stringWithFormat:@"%@%@",url,parsarUrl];
	
    baseURL = [NSURL URLWithString:url];
    NSString *strNew1 = [[NSString alloc] initWithContentsOfURL:baseURL encoding:NSASCIIStringEncoding error:nil];
    if (strNew1 != nil) {
        [self parserMain:strNew1 Index:0];
    }
    else
    {
        
    }
    [strNew1 release];  
}

-(void)parserFilter:(NSString*)response
{
    if (self.httpResponse) {
        [self.httpResponse removeAllObjects];
    }
    else
    {
        self.httpResponse = [[NSMutableArray alloc] init];
    }
    NSRange range;
    
    range = [response rangeOfString:@"<td style=\"font-family:tahoma;font-size:12px;border-bottom:2px solid black\">"];
    NSString *path=@"";
    NSString *pid = @"";
    
    while (range.length > 0) {
        response = [response substringFromIndex:range.location + range.length];
        item = [[NSMutableDictionary alloc] init];
        range = [response rangeOfString:@"style=\"font-family:tahoma;font-size:12px;\">"];
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@"</b>"];
        [item setObject:[response substringToIndex:range.location] forKey:@"yacthName"];
        
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@"Sleeps"];
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@"</b>:"];
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@"</span>"];
        response = [response substringFromIndex:range.location + range.length];
        
        
        range = [response rangeOfString:@"Ensuite Bathrooms"];
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@"</b>:"];
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@"</span>"];
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@"<a href='"];
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@"/"];
        pid = [response substringToIndex:range.location];
        [item setObject:[response substringToIndex:range.location] forKey:@"productID"];
        response = [response substringFromIndex:range.location + range.length];
        
        
        range = [response rangeOfString:@"<img src=temp/"];
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@" border=\"0\""];
        NSData *imgData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://www.charterdigest.com/temp/%@",[response substringToIndex:range.location]]]];
        path = [IMAGE_FOLDER stringByAppendingPathComponent:
                [NSString stringWithFormat:@"%@.png", 
                 pid]];
        if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
            [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
        }
        [imgData writeToFile:path atomically:YES];
        [imgData release];
        
        [item setObject:path forKey:@"thumb"];
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@"<b>Price: "];
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@" </div>"];
        [item setObject:[response substringToIndex:range.location] forKey:@"price"];
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@"<td  style=\"font-family:tahoma;font-size:12px;text-align:justify\">"];
        response = [response substringFromIndex:range.location + range.length];
        
        range = [response rangeOfString:@"</td>"];
        [item setObject:[response substringToIndex:range.location] forKey:@"description"];
        response = [response substringFromIndex:range.location + range.length];
        
        [item setObject:@"" forKey:@"rating"];
        [item setObject:@"" forKey:@"EstimatedCost"];
        
        [self.httpResponse addObject:item];
        [item release];
        
        range = [response rangeOfString:@"<td style=\"font-family:tahoma;font-size:12px;border-bottom:2px solid black\">"];
    }    
}


-(void)parserMain:(NSString *)result Index:(int)index
{
    NSString *response = result;
    
    NSRange range;
    range = [response rangeOfString:@"Go to page: "];
    response = [response substringFromIndex:range.location + range.length];

    range = [response rangeOfString:@"<b>Amenities</b>"];
    if (range.length > 0) {
        
        response = [response substringFromIndex:range.location+range.length];
        
        range = [response rangeOfString:@"</table>"];
        response = [response substringToIndex:range.location];
        if (appDelegate.AmentitesArray) {
            [appDelegate.AmentitesArray removeAllObjects];
        }
        else
        {
            appDelegate.AmentitesArray = [[NSMutableArray alloc] init];            
        }
        
        range = [response rangeOfString:@"<a href='"];
        while (range.length > 0) {
            response = [response substringFromIndex:range.location+range.length];
            range = [response rangeOfString:@"'"];
            
            NSString *path = [response substringToIndex:range.location];
            range = [response rangeOfString:@">"];        
            response = [response substringFromIndex:range.location+range.length];
            range = [response rangeOfString:@"</a>"];
            NSString *content = [response substringToIndex:range.location];
            int pId = 0;
            if ([content isEqualToString:@"Smoke Free Vessel"]) {
                pId = 111;
            }else if ([content isEqualToString:@"Honeymoon"]) {
                pId = 222;
            }else if ([content isEqualToString:@"Kayak"]) {
                pId = 333;
            }else if ([content isEqualToString:@"Flat Screen every Cabin"]) {
                pId = 444;
            }else if ([content isEqualToString:@"Internet access"]) {
                pId = 555;
            }else if ([content isEqualToString:@"Jacuzzi/Hot Tub"]) {
                pId = 666;
            }else if ([content isEqualToString:@"Waterskies"]) {
                pId = 777;
            }else if ([content isEqualToString:@"Windsurfing"]) {
                pId = 888;
            }else if ([content isEqualToString:@"Tubing"]) {
                pId = 6;
            }else if ([content isEqualToString:@"Snorkeling"]) {
                pId = 7;
            }else if ([content isEqualToString:@"Rendez-Vous Diving"]) {
                pId = 8;
            }else if ([content isEqualToString:@"Dive Instructor/Certification"]) {
                pId = 9;
            }else if ([content isEqualToString:@"Vegetarian Friendly"]) {
                pId = 12;
            }else if ([content isEqualToString:@"Lactose/Gluten Free"]) {
                pId = 13;
            }else if ([content isEqualToString:@"Spa Services"]) {
                pId = 14;
            }else if ([content isEqualToString:@"Kid Friendly"]) {
                pId = 15;
            }else if ([content isEqualToString:@"Wii"]) {
                pId = 16;
            }else if ([content isEqualToString:@"Vegan Friendly"]) {
                pId = 18;
            }else if ([content isEqualToString:@"Clothing Optional"]) {
                pId = 19;
            }else if ([content isEqualToString:@"Pet Friendly"]) {
                pId = 21;
            }else if ([content isEqualToString:@"Pet on board"]) {
                pId = 22;
            }else if ([content isEqualToString:@"Kosher"]) {
                pId = 23;
            }else if ([content isEqualToString:@"Eco-Friendly"]) {
                pId = 24;
            }else {
                pId = 0;
            }
            AmenitiesModel *model = [[AmenitiesModel alloc] init];
            [model setProductId:pId];
            model.imagename = content;
            model.thumb = path;
            
            [appDelegate.AmentitesArray addObject:model];
            [model release];       
            
            range = [response rangeOfString:@"<a href='"];
        }  
//        NSLog(@"%d",[appDelegate.AmentitesArray count]);
        
    }
}

-(void)getURL
{
    
    NSRange range = [self.getDateIn rangeOfString:@", "];
    NSString *sendInDate = [self.getDateIn substringFromIndex:range.location
                            +range.length];
    range = [self.getDateOut rangeOfString:@", "];
    NSString *sendOutDate = [self.getDateOut substringFromIndex:range.location
                             +range.length];
    
    range = [sendInDate rangeOfString:@" "];
    self.inMonth = [sendInDate substringToIndex:range.location];
    sendInDate = [sendInDate substringFromIndex:range.location+range.length];
    
    if ([self.inMonth isEqualToString:@"Jan"]) {
        self.inMonth = @"1";
    }else if ([self.inMonth isEqualToString:@"Feb"]) {
        self.inMonth = @"2";
    }else if ([self.inMonth isEqualToString:@"Mar"]) {
        self.inMonth = @"3";
    }else if ([self.inMonth isEqualToString:@"Apr"]) {
        self.inMonth = @"4";
    }else if ([self.inMonth isEqualToString:@"May"]) {
        self.inMonth = @"5";
    }else if ([self.inMonth isEqualToString:@"Jun"]) {
        self.inMonth = @"6";
    }else if ([self.inMonth isEqualToString:@"Jul"]) {
        self.inMonth = @"7";
    }else if ([self.inMonth isEqualToString:@"Aug"]) {
        self.inMonth = @"8";
    }else if ([self.inMonth isEqualToString:@"Sep"]) {
        self.inMonth = @"9";
    }else if ([self.inMonth isEqualToString:@"Oct"]) {
        self.inMonth = @"10";
    }else if ([self.inMonth isEqualToString:@"Nov"]) {
        self.inMonth = @"11";
    }else if ([self.inMonth isEqualToString:@"Dec"]) {
        self.inMonth = @"12";
    }else{
        self.inMonth = @"1";
    }
    
    range = [sendInDate rangeOfString:@", "];
    inDay = [sendInDate substringToIndex:range.location];
    inYear = [sendInDate substringFromIndex:range.location+range.length];
    
    range = [sendOutDate rangeOfString:@" "];
    self.outMonth = [sendOutDate substringToIndex:range.location];
    sendOutDate = [sendOutDate substringFromIndex:range.location+range.length];
    
    if ([self.outMonth isEqualToString:@"Jan"]) {
        self.outMonth = @"1";
    }else if ([self.outMonth isEqualToString:@"Feb"]) {
        self.outMonth = @"2";
    }else if ([self.outMonth isEqualToString:@"Mar"]) {
        self.outMonth = @"3";
    }else if ([self.outMonth isEqualToString:@"Apr"]) {
        self.outMonth = @"4";
    }else if ([self.outMonth isEqualToString:@"May"]) {
        self.outMonth = @"5";
    }else if ([self.outMonth isEqualToString:@"Jun"]) {
        self.outMonth = @"6";
    }else if ([self.outMonth isEqualToString:@"Jul"]) {
        self.outMonth = @"7";
    }else if ([self.outMonth isEqualToString:@"Aug"]) {
        self.outMonth = @"8";
    }else if ([self.outMonth isEqualToString:@"Sep"]) {
        self.outMonth = @"9";
    }else if ([self.outMonth isEqualToString:@"Oct"]) {
        self.outMonth = @"10";
    }else if ([self.outMonth isEqualToString:@"Nov"]) {
        self.outMonth = @"11";
    }else if ([self.outMonth isEqualToString:@"Dec"]) {
        self.outMonth = @"12";
    }else{
        self.outMonth = @"1";
    }
    
    
    range = [sendOutDate rangeOfString:@", "];
    self.outDay = [sendOutDate substringToIndex:range.location];
    self.outYear = [sendOutDate substringFromIndex:range.location+range.length];
}

#pragma mark -
#pragma mark Table view data source

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ([appDelegate.AmentitesArray count] >= 100) {
        return 100;
    }
    else
    {
        return [appDelegate.AmentitesArray count];
    }
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
	// Configure the cell.
    AmenitiesModel *model = (AmenitiesModel *)[appDelegate.AmentitesArray objectAtIndex:indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];		
	}
    
    switchView = [[UISwitch alloc] initWithFrame:CGRectZero];
    [switchView setOn:[self isSwitch:[model getProductid]] animated:YES];
    cell.accessoryView = switchView;
    
    [switchView addTarget:self action:@selector(switchChanged:)forControlEvents:UIControlEventValueChanged];
    [switchView setTag: indexPath.row];
    [(UISwitch *)cell.accessoryView addTarget:self action:@selector(switchChanged:) forControlEvents:UIControlEventValueChanged];
    [switchView release];
    


	cell.textLabel.text = model.imagename;
	cell.textLabel.font = [UIFont fontWithName:@"Arial" size:14];
	cell.backgroundColor = [UIColor clearColor];
	cell.textLabel.textColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];

	return cell;
	
}

-(BOOL)isSwitch:(NSInteger)index{
    
    if (appDelegate.amenitiesArray == nil || [appDelegate.amenitiesArray count] <= 0) {
        return NO;
    }
    BOOL isOn = NO;
    for (int i = 0; i < [appDelegate.amenitiesArray count]; i++) {
        NSString *number = [appDelegate.amenitiesArray objectAtIndex:i];
        if ([number integerValue] == index) {
            isOn = YES;
            break;
        }
    }
    return isOn;
}


- (void)switchChanged:(id)sender {
	[[NSUserDefaults standardUserDefaults] boolForKey:@"testSwitch"];
	
	UISwitch *theSwitch = (UISwitch *)sender;
	UITableViewCell *cell = (UITableViewCell *)theSwitch.superview;
	UITableView *tableView = (UITableView *)cell.superview;
	NSIndexPath *indexPath = [tableView indexPathForCell:cell];
	
    AmenitiesModel *model = [appDelegate.AmentitesArray objectAtIndex:indexPath.row];
    NSString *ArrObjects = [[NSString alloc] initWithString:[NSString stringWithFormat:@"%d",[model getProductid]]];
	
	if ([theSwitch isOn]) {
		[appDelegate.amenitiesArray addObject:ArrObjects];
//		NSLog(@"%d", [appDelegate.amenitiesArray count]);
		
	}else {
        NSMutableArray *tempArray1 = [[NSMutableArray alloc] init];
        for (NSString *model1 in appDelegate.amenitiesArray){
            if (![ArrObjects isEqualToString:model1]) {
                [tempArray1 addObject:model1];
            }
        }
        if ([tempArray1 count] > 0) {
            [appDelegate.amenitiesArray removeAllObjects];
            for (NSString *model1 in tempArray1){
                    [appDelegate.amenitiesArray addObject:model1];
            }
        }
        else
        {
            [appDelegate.amenitiesArray removeAllObjects];
        }
        [tempArray1 release];
//		NSLog(@"%d", [appDelegate.amenitiesArray count]);
	}
	[ArrObjects release];
	
}

- (void) viewWillDisappear:(BOOL)animated{
	
	self.ManuFactureTxt = @"null";
	self.searchTxt = @"null";
	
	self.MinimumP1 = @"null";
	self.MaximumP1 = @"null";
//	[appDelegate hiddenSplashView];

	[super viewWillDisappear:animated];
	
}

#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	[self.m_tableView deselectRowAtIndexPath:indexPath animated:YES];
	
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
	[super didReceiveMemoryWarning];
	
	
	// Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	// Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
	// For example: self.myOutlet = nil;
}


- (void)dealloc {
	[super dealloc];
//	[YachtName1Str release];
//    [YachtDate1Str release];
//    [YachtGuest1Str release];
//    [YachtType1Str release];
//    [httpResponse release];
//    [item release];
//    [ContentsArr release];
//    [baseURL release];
//    [httpResponse1 release];
//    [item1 release]; 
//    [ContentsArr1 release]; 
//    [baseURL1 release];
//
//    [httpResponse3 release]; 
//    [item3 release]; 
//    [ContentsArr3 release]; 
//    [baseURL3 release];
//    
//    [myArr release];
//    [tempArray release];
//    [_tableView release];
//    [_searchBar release];
//    [bImage release];
//    
//    [searchTxt release];
//    [AmenitiesTxt release];
//    [PriceMinTxt release];
//    [priceMaxTxt release];
//    [ManuFactureTxt release];
//    
//
//    [MinimumP1 release];
//    [MaximumP1 release];
//    [URLString release];
//    
//    [getDateIn release];
//    [getDateOut release];
//    [yName release];
//    
//    [inDay release];
//    [inMonth release];
//    [inYear release];
//    [outDay release];
//    [outMonth release];
//    [outYear release];	
}


@end

