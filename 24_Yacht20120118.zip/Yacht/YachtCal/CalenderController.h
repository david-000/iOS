//
//  CalenderController.h
//  Yacht
//
//  Created by Askone on 10/7/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CalenderController : UIViewController <UIWebViewDelegate>{

	UIWebView *_webView;
	NSString * calenderDate;
	NSString *calenderURL;
	IBOutlet UIActivityIndicatorView *indicator;
}
@property (nonatomic, retain)NSString *calenderURL;
@property (nonatomic, retain)IBOutlet UIWebView *webView;
@property (nonatomic, retain)NSString * calenderDate;
@end
