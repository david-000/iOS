//
//  DescriptionController.m
//  Yacht
//
//  Created by Askone on 10/8/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "DescriptionController.h"


@implementation DescriptionController
@synthesize webView = _webView;
@synthesize detailDescription;




// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	/*
	UILabel * Navlabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 400, 44)];
	Navlabel.backgroundColor = [UIColor clearColor];
	Navlabel.font = [UIFont boldSystemFontOfSize:18.0];
	Navlabel.textAlignment = UITextAlignmentCenter;
	Navlabel.textColor =[UIColor whiteColor];
	Navlabel.text= @"Description";
	self.navigationItem.titleView = Navlabel;		
	[Navlabel release];*/
	
	self.title = @"Description";

	NSString *calenderURL = [NSString stringWithFormat:@"http://www.charterdigest.com/iPhone/singleyatch-detail.php?act=long_detail&pid=%@",detailDescription];
	NSURL *AvaCalender = [NSURL URLWithString:calenderURL];
	NSURLRequest *requestURL = [NSURLRequest requestWithURL:AvaCalender];
	[self.webView loadRequest:requestURL];
	
	self.webView.backgroundColor = [UIColor clearColor];
	self.webView.clipsToBounds = YES;
	self.webView.opaque = NO;
	
}


- (void)webViewDidStartLoad:(UIWebView *)webView {
	[indicator startAnimating];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
	[indicator stopAnimating];
	indicator.hidesWhenStopped=YES;
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return YES;//(interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
