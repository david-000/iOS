//
//  FavViewController.m
//  Yacht
//
//  Created by Askone on 9/16/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "FavViewController.h"
#import "YachtAppDelegate.h"
#import "DetailRootViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "Constants.h"


@interface NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding;
@end

@implementation NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding
{
	return (NSString *) CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)self,
																NULL, (CFStringRef)@";@$+{}<>,",
																CFStringConvertNSStringEncodingToEncoding(encoding));
}  
@end


@implementation FavViewController
@synthesize regLabel12,yachtName12,totalGuest12,totalStar12,MinimumP12,MaximumP12;

@synthesize tableView = _tableView;
@synthesize priceString1;
@synthesize starString1;
@synthesize urlimg;
@synthesize urlString2; 
@synthesize parseURL;
@synthesize completeURL;
@synthesize URLObjects;
@synthesize result;

@synthesize item;
@synthesize ContentsArr;
@synthesize httpResponse;
@synthesize ASIRequest;
@synthesize baseURL;
@synthesize resultedArray;
@synthesize responseString;
@synthesize navBar;
@synthesize starString;
@synthesize yachtType12;
@synthesize YactName;

@synthesize ManuFactureTxt12,getDateIn12,getDateOut12;
int i;


#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
	[super viewDidLoad];
	self.httpResponse = [[NSMutableArray alloc]init];
	YachtAppDelegate *appDelegate = [YachtAppDelegate sharedAppDelegate];


	self.result = [[NSMutableString alloc] init];
	for (NSObject * obj in appDelegate.AmentitesArray)
	{
		[self.result appendString:[obj description]];
//		NSLog(@"result ==> character %@", self.result);

	}
	
//	NSLog(@"%d",[appDelegate.AmentitesArray count]);
//	NSLog(@"result ==> character %@", self.result);
//	NSLog(@"result ==> digit %@", self.result);


	if ([result length]==0) {
	hasAmentites = @"False";
	}else {
		hasAmentites = @"True";
	}
	
	self.parseURL = [NSString stringWithFormat:@"http://www.charterdigest.com/iPhone/filter.php?act=record&region=%@&numguest=%@&ytype=%@&ssdate=%@&nndate=%@&numdays=%d&manufacturer=%@&yacthname=%@&amt_check=%@&minprice=%@&maxprice=%@&",self.yachtName12,self.totalGuest12, self.yachtType12, self.getDateIn12, self.getDateOut12, days, self.ManuFactureTxt12,self.YactName, hasAmentites,self.MinimumP12,self.MaximumP12];
	self.completeURL = [parseURL stringByAppendingString:result];
//	NSLog(@"complete URL ==> %@", completeURL);
	NSString *encodedStr = [self.completeURL encodeString:NSASCIIStringEncoding];
	NSURL *url = [NSURL URLWithString:encodedStr];
	
	ASIHTTPRequest *aRequest = [ASIHTTPRequest requestWithURL:url];
	[aRequest setDelegate:self];
	[aRequest startAsynchronous];
	
	baseURL = [NSURL URLWithString:encodedStr];
	NSURLRequest *request = [NSURLRequest requestWithURL:baseURL];
	[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
	NSString * strNew = [[NSString alloc] initWithContentsOfURL:baseURL encoding:NSUTF8StringEncoding error:nil];
    if (strNew != nil) {

	NSArray *arr =[strNew componentsSeparatedByString:@"</br>"];
	self.resultedArray = [[NSArray alloc] initWithArray:arr];
	for (int i=0;i<[arr count]-1; i++) {
		self.ContentsArr = [[arr objectAtIndex:i] componentsSeparatedByString:@"~"];
		self.item = [[NSMutableDictionary alloc] init];
		if ([self.ContentsArr count]>=1) {
			
			[self.item setObject:[ContentsArr objectAtIndex:1] forKey:@"productID"];
			[self.item setObject:[ContentsArr objectAtIndex:2] forKey:@"yacthName"];
			[self.item setObject:[ContentsArr objectAtIndex:3] forKey:@"price"];
			[self.item setObject:[ContentsArr objectAtIndex:4] forKey:@"thumb"];
			[self.item setObject:[ContentsArr objectAtIndex:5] forKey:@"description"];
			[self.item setObject:[ContentsArr objectAtIndex:6] forKey:@"rating"];
			[self.item setObject:[ContentsArr objectAtIndex:7] forKey:@"EstimatedCost"];

			[self.httpResponse addObject:self.item];
			
		}
        [self.item release];
	}
        
    }
	
	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(50, 0, 320, 44)];
	label.backgroundColor = [UIColor clearColor];
	label.font = [UIFont boldSystemFontOfSize:18.0];
	label.textAlignment = UITextAlignmentCenter;
	label.textColor =[UIColor whiteColor];
	NSString *navTitle = [NSString stringWithFormat:@"Filter (%d)", [self.resultedArray count]-1];
	label.text= navTitle;
	self.navigationItem.titleView = label;		
	[label release];
}



- (void)requestFinished:(ASIHTTPRequest *)request
{
	responseString = [request responseString];
	if ([responseString isEqualToString:@"No Record Found."]) {
		
		UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Search Result" message:responseString delegate:self cancelButtonTitle:@"Retry" otherButtonTitles:nil];
		[alertView show];
		[alertView release];
		
	}
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
//	NSError *error = [request error];
//	NSLog(@"requestFailed %@", error);
}


- (void)requestDone:(ASIHTTPRequest *)request
{
//	NSString *response = [request responseString];
//	NSLog(@"response %@",response);
}


-(IBAction)Back{

	[self dismissModalViewControllerAnimated:YES];
}



/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	
    return [self.httpResponse count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *CellIdentifier = @"ImageCell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
    if (cell == nil)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
	else {
		AsyncImageView* oldImage = (AsyncImageView*)
		[cell.contentView viewWithTag:999];
		[oldImage removeFromSuperview];
	}
	
	self.tableView.backgroundColor = [UIColor clearColor];
	UILabel *label=[[UILabel alloc]init];
	label.backgroundColor = [UIColor clearColor];
	label.textColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	label.highlightedTextColor = [UIColor whiteColor];
	label.frame=CGRectMake(10, 0,250,35);
	label.font = [UIFont systemFontOfSize:14];
	label.lineBreakMode = UILineBreakModeWordWrap;
	label.numberOfLines = 2;
	label.text=[[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"yacthName"];
	[cell.contentView addSubview:label];
    [label release];
	
	UILabel * price =[[UILabel alloc]init];
	price.backgroundColor = [UIColor clearColor];
	price.textColor = [UIColor orangeColor];
	price.frame=CGRectMake(260, 0,100,50);
	price.font = [UIFont boldSystemFontOfSize:14];
	price.textAlignment = UITextAlignmentLeft;
	NSString * priceString = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"price"];
	price.text = [NSString stringWithFormat:@"$%@", priceString];
	[cell.contentView addSubview:price];
    [price release];
	
	UIImageView *starImage = [[UIImageView alloc] initWithFrame:CGRectMake(5, 100, 80, 16)];
	self.starString = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"rating"];
	
	if ([self.starString isEqual:@"0"]) {
		starImage.image = [UIImage imageNamed:nil];
	}
	else if ([self.starString isEqual:@"1"]) {
		NSString *OneStar = [self.starString stringByAppendingFormat:@".png"];
		starImage.image = [UIImage imageNamed:OneStar];
	}
	else if ([self.starString isEqual:@"2"]) {
		NSString *TwoStar = [self.starString stringByAppendingFormat:@".png"];
		starImage.image = [UIImage imageNamed:TwoStar];
	}
	else if ([self.starString isEqual:@"3"]) {
		NSString *ThreeStar = [self.starString stringByAppendingFormat:@".png"];
		starImage.image = [UIImage imageNamed:ThreeStar];
	}
	else if ([self.starString isEqual:@"4"]) {
		NSString *fourStar = [self.starString stringByAppendingFormat:@".png"];
		starImage.image = [UIImage imageNamed:fourStar];
	}
	else if ([self.starString isEqual:@"5"]) {
		NSString *fiveStar = [self.starString stringByAppendingFormat:@".png"];
		starImage.image = [UIImage imageNamed:fiveStar];
	}
	
	[cell.contentView addSubview:starImage];
    [starImage release];
	
	UILabel * description =[[UILabel alloc]init];
	description.backgroundColor = [UIColor clearColor];
	description.textColor = [UIColor orangeColor];
	description.frame=CGRectMake(80, 40, 240,50);
	description.font = [UIFont systemFontOfSize:14];
	description.textAlignment = UITextAlignmentLeft;
	description.lineBreakMode = UILineBreakModeWordWrap;
	description.numberOfLines = 3;
	description.text = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"description"];
	[cell.contentView addSubview:description];
    [description release];
	
	UILabel * eCost =[[UILabel alloc]init];
	eCost.backgroundColor = [UIColor clearColor];
	eCost.textColor = [UIColor blueColor];
	eCost.frame=CGRectMake(150, 80, 240,50);
	eCost.font = [UIFont systemFontOfSize:14];
	eCost.textAlignment = UITextAlignmentLeft;
	eCost.lineBreakMode = UILineBreakModeWordWrap;
	eCost.numberOfLines = 3;
	NSString*ecostText = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"EstimatedCost"];
	NSString *cellText = [NSString stringWithFormat:@"Estimated Price: $%@", ecostText];
	eCost.text =cellText;  //[[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"description"];
	[cell.contentView addSubview:eCost];
    [eCost release];
	
	CGRect frame = CGRectMake(10, 40, 60, 60);
	asyncImage = [[[AsyncImageView alloc]initWithFrame:frame] autorelease];
	asyncImage.tag = 999;
	self.urlimg = [NSURL URLWithString:[[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"thumb"]];
	[asyncImage loadImageFromURL:urlimg];
	asyncImage.backgroundColor = [UIColor clearColor];
	
	CALayer * l = [asyncImage layer];
	[l setMasksToBounds:YES];
	[l setCornerRadius:10.0];
	
	asyncImage.clipsToBounds = YES;
	[cell.contentView addSubview:asyncImage];
	[asyncImage release];
	
	UIView * backView = [[UIView alloc]initWithFrame:CGRectMake(0,0, 320,55)];
	backView.backgroundColor = [UIColor whiteColor];
	cell.backgroundView = backView;
    [backView release];
	
	cell.backgroundColor = [UIColor clearColor];
	self.tableView.separatorColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	
	return cell;
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	
	return 55;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	
	return 0;
	
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 120;
	
}


-(void)viewWillAppear:(BOOL)animated{
	
	[super viewWillAppear:animated];
	
	//[self.tableView reloadData];
	
	
}

-(void)viewDidDisappear:(BOOL)animated{
	YachtAppDelegate *appDelegate = [YachtAppDelegate sharedAppDelegate];

	[super viewDidDisappear:animated];
	[self.result setString:@""];
	[appDelegate.AmentitesArray removeAllObjects];
	
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	UIView* customView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 320.0, 100.0)];
	customView.backgroundColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	
	UILabel * headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(8.0, 0.0, 180.0, 25.0)];
	headerLabel.backgroundColor = [UIColor clearColor];
	headerLabel.opaque = NO;
	headerLabel.textColor = [UIColor whiteColor];
	headerLabel.highlightedTextColor = [UIColor whiteColor];
	headerLabel.font = [UIFont boldSystemFontOfSize:10];
	headerLabel.adjustsFontSizeToFitWidth=YES;
	headerLabel.text = self.YactName;
	
	UILabel * headerLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(8.0, 22.0, 180.0, 25.0)];
	headerLabel1.backgroundColor = [UIColor clearColor];
	headerLabel1.opaque = NO;
	headerLabel1.textColor = [UIColor whiteColor];
	headerLabel1.highlightedTextColor = [UIColor whiteColor];
	headerLabel1.font = [UIFont boldSystemFontOfSize:10];
	headerLabel1.adjustsFontSizeToFitWidth=YES;
	headerLabel1.text = self.yachtType12;
	
	UILabel * headerLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(175.0, 0.0, 180.0, 25.0)];
	headerLabel2.backgroundColor = [UIColor clearColor];
	headerLabel2.opaque = NO;
	headerLabel2.textColor = [UIColor whiteColor];
	headerLabel2.highlightedTextColor = [UIColor whiteColor];
	headerLabel2.font = [UIFont boldSystemFontOfSize:10];
	NSString *date1 = [NSString stringWithFormat:@"%@",self.getDateIn12];
	NSString *date2 = [NSString stringWithFormat:@" %@",self.getDateOut12];
	NSString *detailDate = [date1 stringByAppendingFormat:@"--"];
	NSString *Append = [detailDate stringByAppendingString:date2];
	headerLabel2.adjustsFontSizeToFitWidth=YES;
	headerLabel2.textAlignment = UITextAlignmentLeft;
	headerLabel2.text = Append;
	
	
	UILabel * headerLabel3 = [[UILabel alloc] initWithFrame:CGRectMake(175.0, 22.0, 180.0, 25.0)];
	headerLabel3.backgroundColor = [UIColor clearColor];
	headerLabel3.opaque = NO;
	headerLabel3.textColor = [UIColor whiteColor];
	headerLabel3.highlightedTextColor = [UIColor whiteColor];
	headerLabel3.font = [UIFont boldSystemFontOfSize:10];
	NSString *guestNo = [NSString stringWithFormat:@"Total Number Of Guests: %@",self.totalGuest12];
	headerLabel3.adjustsFontSizeToFitWidth = YES;
	headerLabel3.textAlignment = UITextAlignmentLeft;
	
	headerLabel3.text = guestNo;
	
	[customView addSubview:headerLabel3];
	[customView addSubview:headerLabel2];
	[customView addSubview:headerLabel1];
	[customView addSubview:headerLabel];
	
	return customView;
}



/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */


/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source.
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }   
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
 }   
 }
 */


/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */


/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here. Create and push another view controller.
    
	 DetailRootViewController *detailViewController = [[DetailRootViewController alloc] initWithNibName:@"DetailRootViewController" bundle:nil];
	detailViewController.productID = [[self.httpResponse objectAtIndex:indexPath.row] objectForKey:@"productID"];
	
	NSString *date1 = [NSString stringWithFormat:@"%@",self.getDateIn12];
	NSString *date2 = [NSString stringWithFormat:@" %@",self.getDateOut12];
	NSString *detailDate = [date1 stringByAppendingFormat:@"--"];
	NSString *Append = [detailDate stringByAppendingString:date2];
	
	detailViewController.YachtName1Str = self.YactName;
	detailViewController.YachtDate1Str = Append;
	detailViewController.YachtGuest1Str = self.totalGuest12;
	NSString *dayIn = [NSString stringWithFormat:@"%@",days];
	detailViewController.YachtStay1Str = dayIn;
	
	
	
	
	[self.navigationController pushViewController:detailViewController animated:YES];
	 [detailViewController release];
	 
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
	self.result =nil;

}


- (void)dealloc {
    [super dealloc];
}


@end

