//
//  CalenderController.m
//  Yacht
//
//  Created by Askone on 10/7/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "CalenderController.h"


@implementation CalenderController
@synthesize webView = _webView;
@synthesize calenderDate, calenderURL;



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	/*UILabel * Navlabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 400, 44)];
	Navlabel.backgroundColor = [UIColor clearColor];
	Navlabel.font = [UIFont boldSystemFontOfSize:18.0];
	Navlabel.textAlignment = UITextAlignmentCenter;
	Navlabel.textColor =[UIColor whiteColor];
	Navlabel.text= @"";
	self.navigationItem.titleView = Navlabel;		
	[Navlabel release];*/
	
	self.title = @"Availability Calender";
	self.calenderURL = [NSString stringWithFormat:@"http://www.charterdigest.com/index.php?custom_page=calendarportrait&pid=%@",calenderDate];
	NSURL *AvaCalender = [NSURL URLWithString:calenderURL];
	NSURLRequest *requestURL = [NSURLRequest requestWithURL:AvaCalender];
	[self.webView loadRequest:requestURL];
	
	self.webView.backgroundColor = [UIColor clearColor];
	self.webView.clipsToBounds = YES;
	self.webView.opaque = NO;
	
	
}


- (void)webViewDidStartLoad:(UIWebView *)webView {
	[indicator startAnimating];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
	[indicator stopAnimating];
	indicator.hidesWhenStopped=YES;
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
	
	if ((interfaceOrientation == UIInterfaceOrientationPortrait)||(interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown)) {
	
		self.calenderURL = [NSString stringWithFormat:@"http://www.charterdigest.com/index.php?custom_page=calendarportrait&pid=%@",calenderDate];

	}
	else {
		self.calenderURL = [NSString stringWithFormat:@"http://www.charterdigest.com/index.php?custom_page=calendarlandscape&pid=%@",calenderDate];

	}
	
	[self.webView reload];
	NSURL *AvaCalender = [NSURL URLWithString:self.calenderURL];
	NSURLRequest *requestURL = [NSURLRequest requestWithURL:AvaCalender];
	[self.webView loadRequest:requestURL];
	
    return YES;//(interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
