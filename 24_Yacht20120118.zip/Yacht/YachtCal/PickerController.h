//
//  PickerController.h
//  Yacht
//
//  Created by Askone on 9/13/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PickerController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource>{

	UIPickerView *_pickerView;
	IBOutlet UILabel *yachtName;
	IBOutlet UINavigationBar *navBar;
	
	IBOutlet UIBarButtonItem *DoneBtn;
	IBOutlet UIBarButtonItem *CancelBtn;
    NSString *typeId;
}
@property (nonatomic, retain)IBOutlet UIPickerView *pickerView;
@property (nonatomic, retain)UINavigationBar *navBar;
@property (nonatomic, retain)UILabel *yachtName;
@property (nonatomic, retain)NSString *typeId;
-(IBAction)DismodelController:(id)sender;


@end
