//
//  FavViewController.h
//  Yacht
//
//  Created by Askone on 9/16/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "AsyncImageView.h"
#import <UIKit/UIKit.h>
@class AsyncImageView;
@class ASIHTTPRequest;



@interface FavViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UIAlertViewDelegate> {

	UITableView *_tableView;
	
	AsyncImageView*asyncImage;
	
	NSString *urlString2;
	NSString *priceString1;
	NSString *starString1;
	NSURL*urlimg;
	
	NSString *regLabel12;
	NSString *yachtName12;
	NSString *totalGuest12;
	NSString *totalStar12;
	
	NSString *MinimumP12;
	NSString *MaximumP12;
	
	NSString *ManuFactureTxt12;
	NSString *getDateIn12;
	NSString *getDateOut12;
	NSString *yachtType12;
	NSString *YactName;
	
	NSMutableDictionary *item;
	NSArray *ContentsArr;
	NSMutableArray *httpResponse;
	
	ASIHTTPRequest *ASIRequest;
	NSURL *baseURL;
	NSArray *resultedArray;
	NSString *responseString;
	NSString *starString;
	IBOutlet UINavigationBar *navBar;
	NSString *parseURL;
	NSString *completeURL;
	NSMutableArray *URLObjects;
	NSMutableString *result;


}
@property (nonatomic, retain)NSMutableString *result;
@property (nonatomic, retain)NSMutableArray *URLObjects;
@property (nonatomic, retain)NSString *completeURL;
@property (nonatomic, retain)NSString *parseURL;
@property (nonatomic, retain)NSString *ManuFactureTxt12;
@property (nonatomic, retain)NSString *getDateIn12;
@property (nonatomic, retain)NSString *getDateOut12;

@property (nonatomic, retain)NSString *starString;
@property (nonatomic, retain)NSString *responseString;
@property (nonatomic, retain)NSArray *resultedArray;
@property (nonatomic, retain)NSMutableArray *httpResponse;
@property (nonatomic, retain)NSMutableDictionary *item;
@property (nonatomic, retain)NSArray *ContentsArr;
@property (retain, nonatomic) ASIHTTPRequest *ASIRequest;
@property (nonatomic, retain)NSURL *baseURL;

@property (nonatomic, retain)NSString *regLabel12;
@property (nonatomic, retain)NSString *yachtName12; 
@property (nonatomic, retain)NSString *totalGuest12;
@property (nonatomic, retain)NSString *totalStar12;
@property (nonatomic, retain)NSString *MinimumP12;
@property (nonatomic, retain)NSString *MaximumP12;
@property (nonatomic, retain)NSString *YactName;

@property (nonatomic, retain)NSString *yachtType12;

@property (nonatomic, retain)NSString *starString1;
@property (nonatomic, retain)NSURL*urlimg;
@property (nonatomic, retain)NSString *urlString2;

@property (nonatomic, retain)NSString *priceString1;
@property (nonatomic, retain)IBOutlet UITableView *tableView;
@property (nonatomic, retain)UINavigationBar *navBar;

-(IBAction)Back;
@end
