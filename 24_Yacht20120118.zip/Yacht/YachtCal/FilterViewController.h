//
//  FilterViewController.h
//  Yacht
//
//  Created by Askone on 9/9/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "ASIHTTPRequest.h"
#import <UIKit/UIKit.h>
@class AsyncImageView;
@class ASIHTTPRequest;
#import <QuartzCore/QuartzCore.h>

@interface FilterViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>{

	NSMutableArray *filterArr;
	UITableView *_table;
	
	IBOutlet UIButton *regionButton;
	IBOutlet UIButton *yachtButton;
	
	IBOutlet UILabel *regionLabel;
	IBOutlet UILabel *YachtTypeLabel;
	IBOutlet UILabel *starLabel;
	IBOutlet UILabel *price;
	
	IBOutlet UIButton *starButton1;
	IBOutlet UIButton *starButton2;
	IBOutlet UIButton *starButton3;
	IBOutlet UIButton *starButton4;
	IBOutlet UIButton *starButton5;
	
	IBOutlet UIButton *MinusBtn;
	IBOutlet UIButton *PlusBtn;
	
	int rating;
	int Rooms;
	IBOutlet UITextField *maxMum;
	IBOutlet UITextField *niniMum;
	IBOutlet UILabel *label;
	
	IBOutlet UIButton * submit;
	
	NSMutableArray *httpResponse;
	NSMutableDictionary *item;
	NSArray *ContentsArr;
	NSURL *baseURL;
	
	AsyncImageView*asyncImage;
	ASIHTTPRequest *ASIRequest;
	IBOutlet UIView *filterView;
	
	IBOutlet UIButton *filterButton1;
	NSString *filterResult;
	
	bool CheckStatus;
	
	NSString *regLabel1;
	NSString *yachtName1; 
	NSString *totalGuest1;
	NSString *totalStar1;
	NSString *MinimumP1;
	NSString *MaximumP1;
	
	NSString *DontPush;
	

	
}
@property (nonatomic, retain)NSString *regLabel1;
@property (nonatomic, retain)NSString *yachtName1; 
@property (nonatomic, retain)NSString *totalGuest1;
@property (nonatomic, retain)NSString *totalStar1;
@property (nonatomic, retain)NSString *MinimumP1;
@property (nonatomic, retain)NSString *MaximumP1;

@property (nonatomic, retain)NSString *filterResult;
@property (nonatomic, retain)UIButton *submit;
@property (nonatomic, retain)UIView *filterView;
@property (nonatomic, retain)NSMutableArray *filterArr;
@property (nonatomic, retain)IBOutlet UITableView *tableView;
@property (nonatomic, retain)UIButton *starButton1;
@property (nonatomic, retain)UIButton *starButton2;
@property (nonatomic, retain)UIButton *starButton3;
@property (nonatomic, retain)UIButton *starButton4;
@property (nonatomic, retain)UIButton *starButton5;

@property (nonatomic, retain)UIButton *MinusBtn;
@property (nonatomic, retain)UIButton *PlusBtn;

@property (nonatomic, retain)NSMutableArray *httpResponse;
@property (nonatomic, retain)NSMutableDictionary *item;
@property (nonatomic, retain)NSArray *ContentsArr;
@property (nonatomic, retain)NSURL *baseURL;
@property (retain, nonatomic) ASIHTTPRequest *ASIRequest;
@property (nonatomic, retain)NSString *DontPush;


@property (nonatomic, retain)UITextField *maxMum;
@property (nonatomic, retain)UITextField *niniMum;
-(IBAction)pushBack:(id)sender;
-(IBAction)submitAction:(id)sender;

-(IBAction)selectStar:(id)sender;
-(IBAction)TotalGuestInRoom:(id)sender;
-(IBAction)selectionDidOccour:(id)sender;
-(IBAction)ViewFilter:(id)sender;
@end
