//
//  AmmentiesController.h
//  Yacht
//
//  Created by Askone on 10/8/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AsyncImageView;
@class ASIHTTPRequest;

@interface AmmentiesController : UIViewController <UITableViewDelegate, UITableViewDataSource>{

	UITableView *_tableView;
	
	NSMutableArray *httpResponse;
	NSMutableDictionary *item;
	NSArray *ContentsArr;
	NSURL *baseURL;
	
	AsyncImageView*asyncImage;
	ASIHTTPRequest *ASIRequest;
	NSString *AmmentiesID;


}

@property (nonatomic, retain)IBOutlet UITableView *tableView;
@property (retain, nonatomic) ASIHTTPRequest *ASIRequest;
@property (nonatomic, retain)NSMutableArray *httpResponse;
@property (nonatomic, retain)NSMutableDictionary *item;
@property (nonatomic, retain)NSArray *ContentsArr;
@property (nonatomic, retain)NSURL *baseURL;
@property (nonatomic, retain)NSString *AmmentiesID;
@end
