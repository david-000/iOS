//
//  SearchViewController.h
//  Yacht
//
//  Created by Askone on 8/23/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YachtAppDelegate.h"
@class AsyncImageView;
@class ASIHTTPRequest;

@interface SearchViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UISearchDisplayDelegate, UIAlertViewDelegate, UIPickerViewDelegate> {
    
	UITableView *m_tableView;
	UISearchBar *m_searchBar;
	
	NSMutableArray *httpResponse;
	NSMutableDictionary *item;
	NSArray *ContentsArr;
	NSURL *baseURL;
	
	IBOutlet UIActivityIndicatorView *indicator;
	IBOutlet UIView *disableViewOverlay;
	
	NSString *getDetination;
	NSString *getGuest;
	NSString *getType;
	NSString *getDateIn;
	NSString *getDateOut;
	NSString *totalDay;
	NSString *pickingSort;
	
	AsyncImageView*asyncImage;
	ASIHTTPRequest *ASIRequest;
    
	NSString * starString;
	
	NSArray *searchResult;
	
	NSString *priceString;
	NSURL*urlimg;
	
	NSString *praseURL;
	int SearchID;
	
	UILabel *Navlabel;
	
	IBOutlet UIView *pickerView;
	UIPickerView *_pickerControler;
	
	NSMutableArray *localSortArry;
    
    IBOutlet UIBarButtonItem *filter;
    
    BOOL isFilter;
    
    NSString *yachtTypeId;
    
    NSString *tempStr;
    
    NSMutableArray *pageArry;
    BOOL isEnter;
    
    YachtAppDelegate *appDelegate;
}
@property (retain, nonatomic) IBOutlet UIBarButtonItem *filter;

@property (nonatomic, retain)IBOutlet UIPickerView *pickerControler;
@property (nonatomic, retain)UIView *pickerView;
@property (nonatomic, retain)NSString *praseURL;
@property (nonatomic, retain)NSURL*urlimg;
@property (nonatomic, retain)NSString *priceString;
@property (nonatomic, retain)NSArray *searchResult;
@property (nonatomic, retain) NSString * starString;
@property (nonatomic, retain)IBOutlet UITableView *m_tableView;
@property (nonatomic, retain)IBOutlet UISearchBar *m_searchBar;
@property (nonatomic, retain)IBOutlet UIView *disableViewOverlay;

@property (nonatomic, retain)NSMutableArray *httpResponse;
@property (nonatomic, retain)NSMutableDictionary *item;
@property (nonatomic, retain)NSArray *ContentsArr;
@property (nonatomic, retain)NSURL *baseURL;

@property (nonatomic, retain)NSString *getDetination;
@property (nonatomic, retain)NSString *getGuest;
@property (nonatomic, retain)NSString *getType;
@property (nonatomic, retain)NSString *getDateIn;
@property (nonatomic, retain)NSString *getDateOut;
@property (nonatomic, retain)NSString *totalDay;

@property (nonatomic, retain)NSString *pickingSort;

@property (nonatomic, retain)NSString *tempStr;
@property (nonatomic) BOOL isEnter;


-(IBAction)tappFilter:(id)sender;

-(void)performSearch:(NSString*)ParseURL;
-(IBAction)pickerViewGoDown;
-(IBAction)popPickerView;

@end
