//
//  TableGalleryController.h
//  Yacht
//
//  Created by Askone on 10/5/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TableGalleryController : UIViewController <UIWebViewDelegate>{

	UIWebView *_webView;
	NSString *PIDImages;
	IBOutlet UIActivityIndicatorView *indicator;

}


@property (nonatomic, retain)IBOutlet UIWebView *webView;
@property (nonatomic, retain)NSString *PIDImages;

@end
