//
//  CharterContract.m
//  Yacht
//
//  Created by Askone on 10/10/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "CharterContract.h"
@interface NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding;
@end

@implementation NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding
{
	return (NSString *) CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)self,
																NULL, (CFStringRef)@";@$+{}<>,",
																CFStringConvertNSStringEncodingToEncoding(encoding));
}  
@end

@implementation CharterContract

@synthesize CharaterContact;
@synthesize webView = _webView;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization.
 }
 return self;
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.title = @"Charter Contract";
	
	NSString *calenderURL = [NSString stringWithFormat:@"http://www.charterdigest.com/iPhone/singleyatch-detail.php?act=contract&pid=%@",CharaterContact];
	NSURL *AvaCalender = [NSURL URLWithString:calenderURL];
	NSURLRequest *requestURL = [NSURLRequest requestWithURL:AvaCalender];
	[self.webView loadRequest:requestURL];
	
	self.webView.backgroundColor = [UIColor clearColor];
	self.webView.clipsToBounds = YES;
	self.webView.opaque = NO;
	
}

- (void)webViewDidStartLoad:(UIWebView *)webView {
	[indicator startAnimating];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
	[indicator stopAnimating];
	indicator.hidesWhenStopped=YES;
}



 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
	 return YES;//(interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
