//
//  DetailRootViewController.m
//  Yacht
//
//  Created by Askone on 9/16/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "DetailRootViewController.h"
#import "BookingViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "TableGalleryController.h"
#import "CalenderController.h"
#import "DescriptionController.h"
#import "AmmentiesController.h"
#import "ReviewController.h"
#import "CharterContract.h"
#import "YachtAppDelegate.h"

@interface NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding;
@end

@implementation NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding
{
	return (NSString *) CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)self,
																NULL, (CFStringRef)@";@$+{}<>,",
																CFStringConvertNSStringEncodingToEncoding(encoding));
}  
@end


@implementation DetailRootViewController
@synthesize YachtName1Str,YachtDate1Str,YachtGuest1Str,YachtStay1Str;
@synthesize YachtName,YachtPrice,YachtGuest,YachtFacility,YachtRank;
@synthesize description,price,facility,productID,imageFromURL;
@synthesize httpResponse,item,ContentsArr,baseURL;
@synthesize bookNow,myImageView,myURL,ASIRequest;
@synthesize rankingYacht,textView;
@synthesize scrollView = _scrollView;
@synthesize tableView = _tableView;
@synthesize YachtDetails;
@synthesize webView =_webView;
@synthesize alertView;
@synthesize disableViewOverlay;
@synthesize YachtPriceStr;
@synthesize m_button;
@synthesize m_description;
#pragma mark -
#pragma mark View lifecycle


- (void)viewWillAppear:(BOOL)animated
{
    self.title = @"Yacht Information";  
    [disableViewOverlay setHidden:YES];
}

-(void)setBackstate:(int)state
{
    backState = state;
}
-(int)getBackState
{
    return backState;
}
- (void)viewDidLoad {
    [super viewDidLoad];

	self.webView.backgroundColor = [UIColor clearColor];
	self.webView.clipsToBounds = YES;
	self.webView.opaque = NO;
    if (backState == 1) {
        favoItem = [[UIBarButtonItem alloc] initWithTitle:@"favorite" style:UIBarButtonItemStylePlain target:self action:@selector(setFavorite:)];
        self.navigationItem.rightBarButtonItem = favoItem;
        [favoItem release];
    }
    else
    {
        self.navigationItem.rightBarButtonItem = nil;
    }
    
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:self action:@selector(viewback)];
	self.navigationItem.leftBarButtonItem = backButton;
	[backButton release];
	
	[self.webView.layer setBorderColor:[[[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0]CGColor]];
	[self.webView.layer setBorderWidth: 1.0];
    [self.webView.layer setMasksToBounds:YES];
    self.navigationController.navigationBar.tintColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	
	YachtDetails = [[NSMutableArray alloc] init];
	[YachtDetails addObject:@"Photos"];
	[YachtDetails addObject:@"Description"];
	[YachtDetails addObject:@"Amenities"];
	[YachtDetails addObject:@"Review"];
	[YachtDetails addObject:@"Availability Calendar"];
	[YachtDetails addObject:@"Charter Contract"];
	
	self.tableView.frame = CGRectMake(0, 336, 320, 150);
	self.scrollView.contentSize = CGSizeMake(320, 1200);
	
	self.scrollView.scrollEnabled = YES;
	self.scrollView.pagingEnabled = YES;
	self.scrollView.directionalLockEnabled = YES;
	self.scrollView.showsVerticalScrollIndicator = NO;
	self.scrollView.showsHorizontalScrollIndicator = NO;
	self.scrollView.delegate = self;
	self.scrollView.autoresizesSubviews = YES;
	self.scrollView.frame = CGRectMake(0, 45, 320, 900);
	

	
	self.httpResponse = [[NSMutableArray alloc]init];
	NSString *YachtURL= @"http://www.charterdigest.com/iPhone/singleyatch-detail.php?act=detail&pid=";
	YachtURL = [YachtURL stringByAppendingString:productID];
	NSString *encodedStr = [YachtURL encodeString:NSASCIIStringEncoding];
	NSURL *url = [NSURL URLWithString:encodedStr];
	ASIHTTPRequest *aRequest = [ASIHTTPRequest requestWithURL:url];
	[aRequest setDelegate:self];
	[aRequest startAsynchronous];
	
	baseURL = [NSURL URLWithString:encodedStr];
	NSURLRequest *request = [NSURLRequest requestWithURL:baseURL];
	[[[NSURLConnection alloc] initWithRequest:request delegate:self] autorelease];
	NSString * strNew = [[NSString alloc] initWithContentsOfURL:baseURL encoding:NSUTF8StringEncoding error:nil];
    if (strNew == nil || !strNew) {
        return;
    }
    else
    {
	NSArray *arr =[strNew componentsSeparatedByString:@"</br>"];
	for (int i=0;i<[arr count]-1; i++) {
		self.ContentsArr = [[arr objectAtIndex:i] componentsSeparatedByString:@"~"];
		self.item = [[NSMutableDictionary alloc] init];
		if ([self.ContentsArr count]>=1) {
			
			[self.item setObject:[ContentsArr objectAtIndex:0] forKey:@"productID"];
			[self.item setObject:[ContentsArr objectAtIndex:1] forKey:@"YachtName"];
			[self.item setObject:[ContentsArr objectAtIndex:2] forKey:@"price"];
			[self.item setObject:[ContentsArr objectAtIndex:3] forKey:@"thumb"];
			[self.item setObject:[ContentsArr objectAtIndex:4] forKey:@"description"];
			[self.item setObject:[ContentsArr objectAtIndex:5] forKey:@"Rooms"];
			[self.item setObject:[ContentsArr objectAtIndex:6] forKey:@"sleeps"];
			[self.item setObject:[ContentsArr objectAtIndex:7] forKey:@"bath"];
			[self.item setObject:[ContentsArr objectAtIndex:8] forKey:@"Facility"];
			[self.httpResponse addObject:self.item];
		}
        [self.item release];
	}
	productID = [[self.httpResponse objectAtIndex:0] objectForKey:@"productID"] ;
//    NSLog(@"%@", productID);
	YachtName.text = [[self.httpResponse objectAtIndex:0] objectForKey:@"YachtName"];
	YachtPriceStr = [[self.httpResponse objectAtIndex:0] objectForKey:@"price"];
	
	YachtPrice.text = [NSString stringWithFormat:@"Price $%@",self.YachtPriceStr];
	
	self.myURL = [NSURL URLWithString:[[self.httpResponse objectAtIndex:0] objectForKey:@"thumb"]];
	[self.myImageView loadImageFromURL:self.myURL];
    

	
	YachtRooms.text = [[self.httpResponse objectAtIndex:0] objectForKey:@"Rooms"];
	YachtSleeps.text = [[self.httpResponse objectAtIndex:0] objectForKey:@"sleeps"];
	YachtBaths.text = [[self.httpResponse objectAtIndex:0] objectForKey:@"bath"];
	scrolltext.text = [[self.httpResponse objectAtIndex:0] objectForKey:@"Facility"];
	YachtGuest.text = [NSString stringWithFormat:@"Guests %@", rankingYacht];
	
	textView.font = [UIFont fontWithName:@"Arial" size:12];
	textView.dataDetectorTypes = UIDataDetectorTypeNone;
	NSString *text = [[self.httpResponse objectAtIndex:0] objectForKey:@"description"];
	[self.webView loadHTMLString:text baseURL:nil];
	
	scrolltext.font = [UIFont fontWithName:@"Arial" size:12];
	scrolltext.dataDetectorTypes = UIDataDetectorTypeNone;
	
	myImageView.frame = CGRectMake(10, 101, 122, 100);
	YachtName1Lab.text = YachtName1Str;
	YachtDate1Lab.text = YachtDate1Str;
	YachtGuestLab.text = [NSString stringWithFormat:@"Guest: %@",self.YachtGuest1Str];
	YachtStay1Lab.text = YachtStay1Str;
	
	NSString *starPath = [NSString stringWithFormat:@"%@.png",rankingYacht];
	UIImage *rankImage = [UIImage imageNamed:starPath];
	[RatingImage setImage:rankImage];
	[bookNow addTarget:self action:@selector(bookingYacht:) forControlEvents:UIControlEventTouchUpInside];
	}
}

-(IBAction)hideAlert:(id)sender
{
    [disableViewOverlay setHidden:YES];
    self.navigationController.navigationItem.backBarButtonItem.enabled = YES;
    self.navigationItem.rightBarButtonItem.enabled = YES;
}

-(void)viewback
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)setFavorite:(id)sender
{
    YachtAppDelegate *appDelegate = [YachtAppDelegate sharedAppDelegate];
    NSDateFormatter *format = [[NSDateFormatter alloc]init];
	[format setDateFormat:@"yyyy-MM-dd"];	
	NSString *displayDate = [format stringFromDate:[NSDate date]];
	[format release];
    
    NSData *imgData = [[NSData alloc] initWithContentsOfURL:self.myURL];
    NSString *imgPath = [IMAGE_FOLDER stringByAppendingPathComponent:
               [NSString stringWithFormat:@"fevorite%@.png", 
                productID]];
    if ([[NSFileManager defaultManager] fileExistsAtPath:imgPath]) {
        [[NSFileManager defaultManager] removeItemAtPath:imgPath error:nil];
    }
    [imgData writeToFile:imgPath atomically:YES];
    [imgData release];
    
    NSString* query = [NSString stringWithFormat:@"INSERT INTO %@ (%@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@, %@) VALUES (%d , '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@');",YACHET_FAVORITE_TABLE_NAME,FAVORITE_FIELD_PRODUCTID,FAVORITE_FIELD_YACHTNAME, FAVORITE_FIELD_PRICE, FAVORITE_FIELD_STARTDATE,FAVORITE_FIELD_ENDDATE,FAVORITE_FIELD_THUMB,FAVORITE_FIELD_DESCRIPTION,FAVORITE_FIELD_ROOMS,FAVORITE_FIELD_SLEEPS,FAVORITE_FIELD_BATH,FAVORITE_FIELD_FACILITY,FAVORITE_FIELD_GUEST,FAVORITE_FIELD_DATE,[productID intValue],[appDelegate.dbManager replashQuery:YachtName1Str],[appDelegate.dbManager replashQuery:YachtPriceStr],[appDelegate.dbManager replashQuery:YachtDate1Str],[appDelegate.dbManager replashQuery:YachtDate1Str],[appDelegate.dbManager replashQuery:imgPath],[appDelegate.dbManager replashQuery:[[self.httpResponse objectAtIndex:0] objectForKey:@"description"]],[appDelegate.dbManager replashQuery:[[self.httpResponse objectAtIndex:0] objectForKey:@"Rooms"]],[appDelegate.dbManager replashQuery:[[self.httpResponse objectAtIndex:0] objectForKey:@"sleeps"]],[appDelegate.dbManager replashQuery:[[self.httpResponse objectAtIndex:0] objectForKey:@"bath"]],[appDelegate.dbManager replashQuery:[[self.httpResponse objectAtIndex:0] objectForKey:@"Facility"]],[appDelegate.dbManager replashQuery:YachtGuest1Str],displayDate];
    BOOL insertState = [appDelegate.dbManager InsertDataToDB:query];
    NSString *message = @"";
    if (insertState) {
        message = @"This listing is no added to your favorites.";
    }
    else
    {
        message = @"favorite add failed.";

    }
    self.m_description.text = message;
    disableViewOverlay.frame = CGRectMake(0, 40, 320, 416);
	self.disableViewOverlay.alpha = 0.6;
	[disableViewOverlay setHidden:NO];
    self.navigationController.navigationItem.backBarButtonItem.enabled = NO;
    self.navigationItem.rightBarButtonItem.enabled = NO;
    if (appDelegate.favoriteArray) {
        [appDelegate.favoriteArray removeAllObjects];
    }
    appDelegate.favoriteArray = [appDelegate.dbManager selectYachtListFromDB:0];    
}

-(IBAction)bookingYacht:(id)sender{
	
		BookingViewController *bController = [[BookingViewController alloc] initWithNibName:@"BookingViewController" bundle:nil];
		bController.pidNO = productID;
		[self.navigationController pushViewController:bController animated:YES];
		[bController release];
}



#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
	
	return [self.YachtDetails count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
	// Configure the cell.
	self.tableView.backgroundColor = [UIColor clearColor];
	cell.textLabel.text = [self.YachtDetails objectAtIndex:indexPath.row];
	cell.textLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:15];
	cell.textLabel.textColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	[self.tableView.layer setBorderColor:[[[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0]CGColor]];
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}




#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here. Create and push another view controller.
    switch (indexPath.row) {
		case 0:{
			TableGalleryController *detailViewController = [[TableGalleryController alloc] initWithNibName:@"TableGalleryController" bundle:nil];
			detailViewController.PIDImages = productID;
			
			[self.navigationController pushViewController:detailViewController animated:YES];
			[detailViewController release];
		}break;
		case 1:{
			DescriptionController *dController = [[DescriptionController alloc] initWithNibName:@"DescriptionController" bundle:nil];
			dController.detailDescription = productID;
			[self.navigationController pushViewController:dController animated:YES];
			[dController release];
		}break;
		case 2:{
			AmmentiesController *aController = [[AmmentiesController alloc] initWithNibName:@"AmmentiesController" bundle:nil];
			aController.AmmentiesID = productID;
			[self.navigationController pushViewController:aController animated:YES];
			[aController release];
		}break;
		case 3:{
			ReviewController *rController = [[ReviewController alloc] initWithNibName:@"ReviewController" bundle:nil];
			rController.UserReviews = productID;
			[self.navigationController pushViewController:rController animated:YES];
			[rController release];
		}break;
		case 4:{
			CalenderController *cController = [[[CalenderController alloc] initWithNibName:@"CalenderController" bundle:nil] autorelease];
			cController.calenderDate = productID;
			[self.navigationController pushViewController:cController animated:YES];
			[cController retain];
		}break;
		case 5:{
			CharterContract *oController = [[CharterContract alloc] initWithNibName:@"CharterContract" bundle:nil];
			oController.CharaterContact = productID;
			[self.navigationController pushViewController:oController animated:YES];
			[oController release];
		}break;
		default:
			break;
	}
}

#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end

