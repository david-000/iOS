//
//  AboutUsController.h
//  Yacht
//
//  Created by Askone on 8/22/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AboutUsController : UIViewController {

	IBOutlet UIWebView *webView;
	IBOutlet UIActivityIndicatorView *indicator;
}
@property (nonatomic, retain)UIWebView *webView;


@end
