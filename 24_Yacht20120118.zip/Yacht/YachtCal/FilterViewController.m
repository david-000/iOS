//
//  FilterViewController.m
//  Yacht
//
//  Created by Askone on 9/9/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "FilterViewController.h"
#import "YashtBookingController.h"
#import "Constants.h"
#import "PickerController.h"
#import "YachtAppDelegate.h"
#import "AsyncImageView.h"
#import "SearchViewController.h"
#import "FavViewController.h"

@interface NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding;
@end

@implementation NSString (encode)
- (NSString *)encodeString:(NSStringEncoding)encoding
{
	return (NSString *) CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)self,
																NULL, (CFStringRef)@";@$+{}<>,",
																CFStringConvertNSStringEncodingToEncoding(encoding));
}  
@end

@implementation FilterViewController
@synthesize filterArr;
@synthesize tableView = _tableView;
@synthesize starButton1,starButton2,starButton3,starButton4,starButton5;
@synthesize maxMum,niniMum;
@synthesize MinusBtn,PlusBtn;
@synthesize submit;
@synthesize httpResponse;
@synthesize item;
@synthesize ContentsArr;
@synthesize baseURL;
@synthesize ASIRequest;
@synthesize filterView;
@synthesize filterResult;

@synthesize regLabel1,yachtName1,totalGuest1,totalStar1,MinimumP1,MaximumP1;
@synthesize DontPush;

#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];
	CheckStatus = TRUE;
	
	rating = 0;
	Rooms = 1;
	
	label.text = @"1";
	niniMum.backgroundColor = [UIColor clearColor];
	niniMum.delegate = self;
	niniMum.returnKeyType = UIReturnKeyDefault;
	
	maxMum.backgroundColor = [UIColor clearColor];
	maxMum.delegate = self;
	maxMum.returnKeyType = UIReturnKeyDefault;
	
	self.filterView.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
	
	
	[self.submit setContentHorizontalAlignment:UIControlContentHorizontalAlignmentCenter];
	[self.submit setTitle:@"Search" forState:UIControlStateNormal];
	self.submit.titleLabel.font = [UIFont fontWithName:@"Arial Bold" size:15];
	self.title = @"Filter";
	
}



-(IBAction)pushBack:(id)sender{
	
	[self dismissModalViewControllerAnimated:YES];
}




#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	
	YachtAppDelegate *appDelegate = [YachtAppDelegate sharedAppDelegate];
    return [appDelegate.httpResponse count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier = @"ImageCell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	}
	else {
		AsyncImageView* oldImage = (AsyncImageView*)
		[cell.contentView viewWithTag:999];
		[oldImage removeFromSuperview];
	}
	
	
	YachtAppDelegate *appDelegate = [YachtAppDelegate sharedAppDelegate];
	UILabel *label1=[[UILabel alloc]init];
	label1.backgroundColor = [UIColor clearColor];
	label1.textColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	label1.highlightedTextColor = [UIColor whiteColor];
	label1.frame=CGRectMake(10, 0,250,35);
	label1.font = [UIFont systemFontOfSize:14];
	label1.lineBreakMode = UILineBreakModeWordWrap;
	label1.numberOfLines = 2;
	label1.text=[[appDelegate.httpResponse objectAtIndex:indexPath.row] objectForKey:@"yacthName"];
	[cell.contentView addSubview:label1];
    [label1 release];
	
	UILabel * price1 =[[UILabel alloc]init];
	price1.backgroundColor = [UIColor clearColor];
	price1.textColor = [UIColor orangeColor];
	price1.frame=CGRectMake(260, 0,100,50);
	price1.font = [UIFont boldSystemFontOfSize:14];
	price1.textAlignment = UITextAlignmentLeft;
	NSString *priceString = [[appDelegate.httpResponse objectAtIndex:indexPath.row] objectForKey:@"price"];
	price1.text = [NSString stringWithFormat:@"$%@", priceString];
	[cell.contentView addSubview:price1];
	[price release];
	
	UILabel * description =[[UILabel alloc]init];
	description.backgroundColor = [UIColor clearColor];
	description.textColor = [UIColor orangeColor];
	description.frame=CGRectMake(80, 40, 240,50);
	description.font = [UIFont systemFontOfSize:14];
	description.textAlignment = UITextAlignmentLeft;
	description.lineBreakMode = UILineBreakModeWordWrap;
	description.numberOfLines = 3;
	description.text = [[appDelegate.httpResponse objectAtIndex:indexPath.row] objectForKey:@"description"];
	[cell.contentView addSubview:description];
    [description release];
	
	CGRect frame = CGRectMake(10, 40, 60, 60);
	asyncImage = [[[AsyncImageView alloc]initWithFrame:frame] autorelease];
	asyncImage.tag = 999;
	NSURL*urlimg = [NSURL URLWithString:[[appDelegate.httpResponse objectAtIndex:indexPath.row] objectForKey:@"thumb"]];
	[asyncImage loadImageFromURL:urlimg];
	asyncImage.backgroundColor = [UIColor clearColor];
	
	CALayer * l = [asyncImage layer];
	[l setMasksToBounds:YES];
	[l setCornerRadius:10.0];
	
	asyncImage.clipsToBounds = YES;
	[cell.contentView addSubview:asyncImage];
    [asyncImage release];
	
	UIView * backView = [[UIView alloc]initWithFrame:CGRectMake(0,0, 320,100)];
	backView.backgroundColor = [UIColor whiteColor];
	cell.backgroundView = backView;
	
	self.tableView.backgroundColor = [UIColor clearColor];
	cell.backgroundColor = [UIColor clearColor];
	self.tableView.separatorColor = [[UIColor alloc]initWithRed:0.106 green:0.416 blue:0.776 alpha:1.0];
	return cell;
	
}




- (void)textFieldDidBeginEditing:(UITextField *)textField {	
	if ((textField == niniMum)||(textField == maxMum)) {
		[UIView beginAnimations:nil context:NULL];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDuration:0.5];
		[UIView setAnimationBeginsFromCurrentState:YES];
		self.view.frame = CGRectMake(self.view.frame.origin.x, (self.view.frame.origin.y - 130.0), self.view.frame.size.width, self.view.frame.size.height);
		[UIView commitAnimations];
	}
}

- (void)textFieldDidEndEditing:(UITextField *)textField {	
	
	if ((textField == niniMum)||(textField == maxMum)) {
		[UIView beginAnimations:nil context:NULL];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDuration:0.5];
		[UIView setAnimationBeginsFromCurrentState:YES];
		self.view.frame = CGRectMake(self.view.frame.origin.x, (self.view.frame.origin.y + 130.0), self.view.frame.size.width, self.view.frame.size.height);
		[UIView commitAnimations];
	}
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField{

	[textField resignFirstResponder];
	[self submitAction:nil];
	return YES;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 120;
	
}



-(IBAction)selectStar:(id)sender{
	
	if ([sender isEqual:starButton1]) {
		UIImage * btnImage = [UIImage imageNamed:@"Star_n.png"];
		rating = 1;
		[starButton1 setImage:btnImage forState:UIControlStateNormal];
	}else if ([sender isEqual:starButton2]) {
		UIImage * btnImage = [UIImage imageNamed:@"Star_n.png"];
		rating = 2;
		[starButton2 setImage:btnImage forState:UIControlStateNormal];
	}else if ([sender isEqual:starButton3]) {
		UIImage * btnImage = [UIImage imageNamed:@"Star_n.png"];
		rating = 3;
		[starButton3 setImage:btnImage forState:UIControlStateNormal];
	}else if ([sender isEqual:starButton4]) {
		UIImage * btnImage = [UIImage imageNamed:@"Star_n.png"];
		rating = 4;
		[starButton4 setImage:btnImage forState:UIControlStateNormal];
	}else if ([sender isEqual:starButton5]) {
		UIImage * btnImage = [UIImage imageNamed:@"Star_n.png"];
		rating = 5;
		[starButton5 setImage:btnImage forState:UIControlStateNormal];
		
	}
	
}


-(IBAction)TotalGuestInRoom:(id)sender{
	
	if ([sender isEqual:PlusBtn]) {
		
		if(Rooms<=20)
			Rooms++;
		NSString *SubtractGuest =[NSString stringWithFormat:@"%d",Rooms];
		label.text = SubtractGuest;	
	}
	
	else if ([sender isEqual:MinusBtn]){
		
		if(Rooms >1)
			Rooms--;
		NSString *SubtractNights =[NSString stringWithFormat:@"%d",Rooms];
		label.text = SubtractNights;	
	}
}



-(IBAction)submitAction:(id)sender{
	
	if ([self.submit.titleLabel.text isEqual:@"Search"]) {
		self.regLabel1 = regionLabel.text;
		self.yachtName1 = YachtTypeLabel.text;
		self.totalGuest1 = label.text;
		self.totalStar1 = [NSString stringWithFormat:@"%d", rating];
		self.MinimumP1 = niniMum.text;
		self.MaximumP1 = maxMum.text;
		
		FavViewController *fController = [[FavViewController alloc] initWithNibName:@"FavViewController" bundle:nil];
		fController.regLabel12 = regLabel1;
		fController.yachtName12 = yachtName1;
		fController.totalGuest12 = totalGuest1;
		fController.totalStar12 = totalStar1;
		fController.MinimumP12 = MinimumP1;
		fController.MaximumP12 = MaximumP1;
		[self.navigationController pushViewController:fController animated:YES];
		[fController release];

	}
}




-(IBAction)ViewFilter:(id)sender{
	
	[self.view addSubview:self.filterView];
}

-(void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:YES];
	
	regionLabel.text = CityName;
	YachtTypeLabel.text = yacthFromDelegate;
	CheckStatus = TRUE;
	[self.view setNeedsDisplay];
	
}

-(void)viewWillDisappear:(BOOL)animated{
	
	[super viewWillDisappear:YES];
	
}




- (void)requestFinished:(ASIHTTPRequest *)request
{
	// Use when fetching text data
	NSString *responseString = [request responseString];
//	NSLog(@"responseString %@", responseString);
	//DontPush = [[NSString alloc] initWithString:responseString];
	
	UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"Search Result" message:responseString delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:@"Retry", nil];
	[alertView show];
	[alertView release];
	
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if (buttonIndex == 0) {
		[self dismissModalViewControllerAnimated:YES];
	}
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
//	NSError *error = [request error];
//	NSLog(@"requestFailed %@", error);
}


- (void)requestDone:(ASIHTTPRequest *)request
{
//	NSString *response = [request responseString];
//	NSLog(@"response %@",response);
}


-(IBAction)selectionDidOccour:(id)sender{
	
	if ([sender isEqual:regionButton]) {
		
		YashtBookingController *viewController = [[YashtBookingController alloc] initWithNibName:@"YashtBookingController" bundle:nil];
		[self presentModalViewController:viewController animated:YES];
		[viewController release];
		
	}
	else if ([sender isEqual:yachtButton]){
		
		PickerController *viewController1 = [[PickerController alloc]initWithNibName:@"PickerController" bundle:nil];
		[self presentModalViewController:viewController1 animated:YES];
		[viewController1 release];
	}
}


/*
 #pragma mark -
 #pragma mark Table view delegate
 
 - (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
 
 
 switch (indexPath.row) {
 case 0:{
 YashtBookingController *viewController = [[YashtBookingController alloc] initWithNibName:@"YashtBookingController" bundle:nil];
 [self presentModalViewController:viewController animated:YES];
 [viewController release];
 }
 
 break;
 case 1:{
 PickerController *viewController1 = [[PickerController alloc]initWithNibName:@"PickerController" bundle:nil];
 [self presentModalViewController:viewController1 animated:YES];
 [viewController1 release];
 }
 break;
 default:
 break;
 }
 
 [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
 }
 
 
 
 - (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
 {
 return 50;
 
 }
 
 */
#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
	[super didReceiveMemoryWarning];
	
	// Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	// Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
	// For example: self.myOutlet = nil;
}


- (void)dealloc {
	[super dealloc];
}


@end

