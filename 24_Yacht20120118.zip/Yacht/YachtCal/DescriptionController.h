//
//  DescriptionController.h
//  Yacht
//
//  Created by Askone on 10/8/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DescriptionController : UIViewController {

	
	UIWebView *_webView;
	NSString * detailDescription;
	IBOutlet UIActivityIndicatorView *indicator;
}

@property (nonatomic, retain)IBOutlet UIWebView *webView;
@property (nonatomic, retain)NSString * detailDescription;

@end
