//
//  PickerController.m
//  Yacht
//
//  Created by Askone on 9/13/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import "PickerController.h"
#import "YachtAppDelegate.h"
#import "Constants.h"

@implementation PickerController
@synthesize pickerView = _pickerView;
@synthesize navBar;
@synthesize yachtName;
@synthesize typeId;


- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView;
{
	return 1;
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	YachtAppDelegate *appDelegate = [YachtAppDelegate sharedAppDelegate];
	self.yachtName.text = [[appDelegate.httpResponse objectAtIndex:row] objectForKey:@"type"];
	yacthFromDelegate = [[appDelegate.httpResponse objectAtIndex:row] objectForKey:@"type"];
    self.typeId = [[appDelegate.httpResponse objectAtIndex:row] objectForKey:@"id"];
}


- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component;
{
	
	YachtAppDelegate *appDelegate = [YachtAppDelegate sharedAppDelegate];
	return [appDelegate.httpResponse count];
}


- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component;
{
	
	YachtAppDelegate *appDelegate = [YachtAppDelegate sharedAppDelegate];
	return [[appDelegate.httpResponse objectAtIndex:row] objectForKey:@"type"];
	
}




// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	
	[super viewDidLoad];
	self.view.backgroundColor = [UIColor clearColor];
	
	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(30, 0, 400, 44)];
	label.backgroundColor = [UIColor clearColor];
	label.font = [UIFont boldSystemFontOfSize:15.0];
	label.textAlignment = UITextAlignmentCenter;
	label.textColor =[UIColor whiteColor];
	label.text= @"Yacht Charter Type";
	self.navBar.topItem.titleView = label;		
	[label release];
	self.typeId = @"0";
	
}


-(void)viewWillAppear:(BOOL)animated{
	
	[super viewWillAppear:animated];
	

}



-(IBAction)DismodelController:(id)sender {
	
	YachtAppDelegate *appDelegate = [YachtAppDelegate sharedAppDelegate];
    if ([sender isEqual:DoneBtn]) {
		
		if (yacthFromDelegate==NULL) {
			yacthFromDelegate = @"All";
		}
        appDelegate.yachtTypeId = self.typeId;
		[self dismissModalViewControllerAnimated:YES];
//		NSLog(@"yacht Name %@", yacthFromDelegate);

		
		
	}
	else if ([sender isEqual:CancelBtn]){
		
		yacthFromDelegate = nil;
//		NSLog(@"yacht Name %@", yacthFromDelegate);
		[self dismissModalViewControllerAnimated:YES];
	}
}


/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
	self.pickerView = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
	[self.pickerView release];
	[yachtName release];
	[yacthFromDelegate release];
}


@end
