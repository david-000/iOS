//
//  DetailViewController.h
//  Yacht
//
//  Created by Askone on 9/8/11.
//  Copyright 2011 CharterDigest.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DetailViewController : UIViewController {

	IBOutlet UITextView *textView;
	NSString *textdata;
	NSString *navigationTitle;
}
@property (nonatomic, retain)NSString *textdata;
@property (nonatomic, retain)NSString *navigationTitle;
@end
