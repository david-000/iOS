//
//  BonusLayer.m
//  Slots-O-Luck-Adventure
//
//  Created by osone on 5/15/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "BonusLayer.h"
#import "GameLayer1.h"
#import "ScaleMenu.h"
NSString* strBack[COUNT_SCREEN] = 
{
    @"bonus_background_1.png",
    @"bonus_background_2.png",
    @"bonus_background_3.png",
};

NSString* strNormalButtons[COUNT_SCREEN][COUNT_BONUS_BUTTON] =
{
    { @"camera_1.png" , @"camera_2.png" , @"camera_3.png" , @"camera_4.png" , @"camera_5.png" },
    { @"animal_1.png" , @"animal_2.png" , @"animal_3.png" , @"animal_4.png" , @"animal_5.png" },
    { @"vehicle_1.png", @"vehicle_2.png", @"vehicle_3.png", @"vehicle_4.png", @"vehicle_5.png"},
};

NSString* strActiveButtons[COUNT_SCREEN][COUNT_BONUS_BUTTON] =
{
    { @"camera_1_highlighted.png" , @"camera_2_highlighted.png" , @"camera_3_highlighted.png" , @"camera_4_highlighted.png" , @"camera_5_highlighted.png" },
    { @"animal_1_highlighted.png" , @"animal_2_highlighted.png" , @"animal_3_highlighted.png" , @"animal_4_highlighted.png" , @"animal_5_highlighted.png" },
    { @"vehicle_1_highlighted.png", @"vehicle_2_highlighted.png", @"vehicle_3_highlighted.png", @"vehicle_4_highlighted.png", @"vehicle_5_highlighted.png"},
};

CGPoint ptButtons[COUNT_SCREEN][COUNT_BONUS_BUTTON] = 
{
    { CGPointMake(244,294), CGPointMake(538,181), CGPointMake(804,298), CGPointMake(694,488), CGPointMake(393,478), },
    { CGPointMake(244,294), CGPointMake(538,181), CGPointMake(804,298), CGPointMake(694,488), CGPointMake(393,478), },
    { CGPointMake(244,294), CGPointMake(538,181), CGPointMake(804,298), CGPointMake(694,488), CGPointMake(393,478), },
};
@implementation BonusScreen

-(id) initWithParam:(BonusLayer *)pParent nScreenID:(int)nScreenID
{
    if ((self = [super init])) {
        m_pParent = pParent;
        m_nScreenID = nScreenID;
        CGSize size = [[CCDirector sharedDirector] winSize];

        m_sprBack = [CCSprite spriteWithFile:strBack[m_nScreenID]];
        m_sprBack.position = CGPointMake( size.width / 2 ,  size.height / 2);
        [self addChild:m_sprBack];
        
        ScaleMenu* menu = [ScaleMenu menuWithItems:nil];
        menu.position = CGPointZero;
        [self addChild:menu];
        for (int i = 0; i < COUNT_BONUS_BUTTON; i++) {
            m_pButton[i] = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithFile:strNormalButtons[m_nScreenID][i]]
                                                   selectedSprite:[CCSprite spriteWithFile:strActiveButtons[m_nScreenID][i]]
                                                   disabledSprite:[CCSprite spriteWithFile:strActiveButtons[m_nScreenID][i]]
                                                           target:self
                                                         selector:@selector(onButton:)];

            m_pButton[i].position = ptButtons[m_nScreenID][i];
            [menu addChild:m_pButton[i]];
        }
        
        return self;
    }
    return nil;
}

-(void) onButton:(id)idButton
{
    for (int i = 0; i < COUNT_BONUS_BUTTON; i++) {
        if(idButton == m_pButton[i])
        {
            [m_pParent onButton:i];
            break;
        }
    }
}
@end
@implementation BonusLayer

-(id) initWithParameter:(GameLayer1*)pParent nGameType:(int)nGametype nBonusScore:(int)nBonusScore
{
    if ((self=[super init])) {
        m_pParent = pParent;
        m_nCurScreenID = -1;
        m_nScore = 0;
        CGSize size = [[CCDirector sharedDirector] winSize];
        for (int i = 0 ; i < COUNT_SCREEN; i++) {
            m_pScreen[i] = [[[BonusScreen alloc] initWithParam:self nScreenID:i] autorelease];
            m_pScreen[i].position = CGPointMake(size.width, 0);
            [self addChild:m_pScreen[i]];
        }

        [self updateScreen];
        [m_pParent setEnable:false];
        return self;
    }
    return nil;
}
-(void) updateScreen
{
    for (int i = 0; i < COUNT_SCREEN; i++) {
        if( [m_pScreen[i] numberOfRunningActions] > 0 )
            return;
    }
    if (m_nCurScreenID >= 3) {
        return;
    }
    m_nCurScreenID++;
    CGSize size = [[CCDirector sharedDirector] winSize];
    if (m_nCurScreenID == COUNT_SCREEN) {
        id ani1 = [CCMoveTo actionWithDuration:0.5f position:CGPointMake( - size.width / 2,  - size.height /2)];
        id ani2 = [CCCallFunc actionWithTarget:self selector:@selector(onFinish)];
        id ani = [CCSequence actions:ani1, ani2, nil];
        [m_pScreen[m_nCurScreenID - 1] runAction:ani];
    }
    else
    {
        CCMoveTo* ani1 =[CCMoveTo actionWithDuration:0.5f position:CGPointMake( - size.width / 2, 0)];
        ani1.tag = 1;
        CCMoveTo* ani2 =[CCMoveTo actionWithDuration:0.5f position:CGPointMake(0,0)];
        ani2.tag = 2;
        if (m_nCurScreenID > 0) {
            [m_pScreen[m_nCurScreenID -1] runAction:ani1];
        }
        [m_pScreen[m_nCurScreenID] runAction:ani2];
    }
}

-(void) onFinish
{
    [m_pParent setEnable:true];
    [m_pParent removeChild:self cleanup:true];
}
-(void) onButton:(int)nButtonID
{
    m_nScore += 1;
    switch (nButtonID) {
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        {
            [self updateScreen];
        }
            break;

        default:
            break;
    }
}

@end
