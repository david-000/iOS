//
//  HelloWorldLayer.m
//  Slots-O-Luck-Adventure
//
//  Created by osone on 5/10/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//


// Import the interfaces
#import "GameLayer1.h"

// Needed to obtain the Navigation Controller
#import "AppDelegate.h"
#import "ScaleMenu.h"
#import "CCLabelFX.h"

#import "CardAniLayer.h"
#pragma mark - GameLayer1

NSString* strCardImage[CARD_COUNT] = 
{
    @"low_pay_icon_1.png",
    @"low_pay_icon_2.png",
    @"low_pay_icon_3.png",
    @"low_pay_icon_4.png",
    @"low_pay_icon_5.png",
    @"high_pay_icon_1.png",
    @"high_pay_icon_2.png",
    @"high_pay_icon_3.png",
    @"high_pay_icon_4.png",
    @"high_pay_icon_5.png",
    @"bonus_icon.png",
    @"scatter_icon.png",
    @"wild_icon.png",
};

CGPoint ptFirstPos[ROW] = {
    CGPointMake(158, 245),
    CGPointMake(341, 245),
    CGPointMake(524, 245),
    CGPointMake(690, 245),
    CGPointMake(865, 245),
};

NSString* strLineButton[MAX_LINES] = 
{
    @"line_number_5.png",//1
    @"line_number_8.png",//2
    @"line_number_2.png",//3
    @"line_number_9.png",//4
    @"line_number_1.png",//5
    @"line_number_6.png",//6
    @"line_number_4.png",//7
    @"line_number_7.png",//8
    @"line_number_3.png",//9
};

NSString* strLine[MAX_LINES] = 
{
    @"line_5.png",//1
    @"line_8.png",//2
    @"line_2.png",//3
    @"line_9.png",//4
    @"line_1.png",//5
    @"line_6.png",//6
    @"line_4.png",//7
    @"line_7.png",//8
    @"line_3.png",//9
};

CGPoint ptLine[MAX_LINES] =
{
    {510, 400},//1
    {510, 562},//2
    {510, 240},//3
    {510, 415},//4
    {510, 385},//5
    {510, 535},//6
    {510, 266},//7
    {510, 405},//8
    {510, 405},//9
};

CGPoint ptbtnLine[2][MAX_LINES] = {
    {
        CGPointMake(40, 180 + 55 * 4), CGPointMake(40, 180 + 55 * 7),CGPointMake(40, 180 + 55 * 1), CGPointMake(40, 180 + 55 * 8), CGPointMake(40, 180 + 55 * 0), CGPointMake(40, 180 + 55 * 5), CGPointMake(40, 180 + 55 * 3), CGPointMake(40, 180 + 55 * 6), CGPointMake(40, 180 + 55 * 2), 
    },
    {
        CGPointMake(980, 180 + 55 * 4), CGPointMake(980, 180 + 55 * 7),CGPointMake(980, 180 + 55 * 1), CGPointMake(980, 180 + 55 * 8), CGPointMake(980, 180 + 55 * 0), CGPointMake(980, 180 + 55 * 5), CGPointMake(980, 180 + 55 * 3), CGPointMake(980, 180 + 55 * 2), CGPointMake(980, 180 + 55 * 6),
    }
};


CGPoint sizeCard = CGPointMake(183, 158);

#define FLOW_TIME 0.1
// HelloWorldLayer implementation
@implementation GameLayer1

// Helper class method that creates a Scene with the HelloWorldLayer as the only child.
+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	GameLayer1 *layer = [GameLayer1 node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super's" return value
	if( (self=[super init]) ) {

		// ask director for the window size
		CGSize size = [[CCDirector sharedDirector] winSize];

        CCSprite* back = [CCSprite spriteWithFile:@"background_bottom.png"];
        back.position = CGPointMake(size.width / 2, size.height / 2 );
        [self addChild:back z:-1];

        CCSprite* backtop = [CCSprite spriteWithFile:@"background_top.png"];
        backtop.position = CGPointMake(size.width / 2, size.height / 2 );
        [self addChild:backtop z:2];

        [self scheduleUpdate];

        m_bAni = false;
        m_fAniTime = 0.0f;
        
        srand([[NSDate date] timeIntervalSince1970]);
        [self initVariables];

        [self initImages];
        [self initLabels];
        [self initButtons];
        for (int row = 0 ; row < ROW ; row++) {
            for (int column = 0; column < COLUMN; column++) {
                m_nCard[column][row] = [self getRandCard];
            }
        }

        m_pCardAniLayer = [[[CardAniLayer alloc] initWithParam:self ] autorelease];
        [self addChild:m_pCardAniLayer z: 10];

        //For Test
        m_pBonusLayer = [[[BonusLayer alloc] initWithParameter:self nGameType:1 nBonusScore:m_nBonusCardCount] autorelease];
        [self addChild:m_pBonusLayer z:10];

        
/*
		//
		// Leaderboards and Achievements
		//
		
		// Default font size will be 28 points.
		[CCMenuItemFont setFontSize:28];

		// Achievement Menu Item using blocks
		CCMenuItem *itemAchievement = [CCMenuItemFont itemWithString:@"Achievements" block:^(id sender) {
			
			
			GKAchievementViewController *achivementViewController = [[GKAchievementViewController alloc] init];
			achivementViewController.achievementDelegate = self;
			
			AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
			
			[[app navController] presentModalViewController:achivementViewController animated:YES];
			
			[achivementViewController release];
		}
									   ];

		// Leaderboard Menu Item using blocks
		CCMenuItem *itemLeaderboard = [CCMenuItemFont itemWithString:@"Leaderboard" block:^(id sender) {
			
			
			GKLeaderboardViewController *leaderboardViewController = [[GKLeaderboardViewController alloc] init];
			leaderboardViewController.leaderboardDelegate = self;
			
			AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
			
			[[app navController] presentModalViewController:leaderboardViewController animated:YES];
			
			[leaderboardViewController release];
		}
									   ];

        CCMenu *menu = [CCMenu menuWithItems:itemAchievement, itemLeaderboard, nil];
		
		[menu alignItemsHorizontallyWithPadding:20];
		[menu setPosition:ccp( size.width/2, size.height/2 - 50)];
		
		// Add the menu to the layer
		[self addChild:menu];
 */

	}
	return self;
}

-(void) initImages
{
    m_sprTitle = [CCSprite spriteWithFile:@"photosafari_sign.png"];
    m_sprTitle.position = CGPointMake(512, 700);
    [self addChild:m_sprTitle z:5];

    m_sprFreeSpin = [CCSprite spriteWithFile:@"free_spins.png"];
    m_sprFreeSpin.position = CGPointMake(512, 700);
    m_sprFreeSpin.visible = false;
    [self addChild:m_sprFreeSpin z:5];

    for (int nLineID = 0; nLineID < m_nLevelMaxLines; nLineID++) {
        m_sprLines[nLineID] = [CCSprite spriteWithFile:strLine[nLineID]];
        m_sprLines[nLineID].position = ptLine[nLineID];
        m_sprLines[nLineID].visible = false;
        [self addChild:m_sprLines[nLineID] z:4.5];
    }
    
    for (int i = 0 ; i < CARD_COUNT; i++) {
        m_sprCards[i] = [[CCSprite spriteWithFile:strCardImage[i]] retain];
        if ([[UIScreen mainScreen] scale] == 1) {
            m_sprCards[i].scale = 0.5;
        }
    }
}
-(void) initLabels
{
    
    m_labelFreeSpinCount = [CCLabelTTF labelWithString:@"kkk" fontName:@"Gremlins" fontSize:60 * CC_CONTENT_SCALE_FACTOR()];
    m_labelFreeSpinCount.position = CGPointMake(512, 700);
    m_labelFreeSpinCount.visible = false;
    [self addChild:m_labelFreeSpinCount z:5];

    ccColor4B colorFill = {255.0f, 255.0f, 255.0f, 255.0f};
    ccColor4B colorShadow = {0.0f, 0.0f, 0.0f, 255.0f};
    m_labelBalance = [CCLabelFX labelWithString:@""
                                      dimensions:CGSizeMake(1000, 200)
                                       alignment:kCCTextAlignmentCenter
                                        fontName:@"Gremlins"
                                        fontSize:40 * CC_CONTENT_SCALE_FACTOR()
                                    shadowOffset:CGSizeMake(3, -3)
                                      shadowBlur:3
                                     shadowColor:colorShadow
                                       fillColor:colorFill
                      ];
    m_labelBalance.position = CGPointMake(114, 76);
    [self addChild:m_labelBalance z:5];

    colorFill = ccc4(0.0f, 0.0f, 0.0f, 255.0f);
    colorShadow = ccc4(255.0f, 255.0f, 255.0f, 255.0f);
    m_labelLines = [CCLabelFX labelWithString:@"10"
                                   dimensions:CGSizeMake(1000, 200)
                                    alignment:kCCTextAlignmentCenter
                                     fontName:@"Delicious"
                                     fontSize:30 * CC_CONTENT_SCALE_FACTOR()
                                 shadowOffset:CGSizeMake(2, -2)
                                   shadowBlur:1
                                  shadowColor:colorShadow
                                    fillColor:colorFill
                      ];
    m_labelLines.position = CGPointMake(454, 126);
    [self addChild:m_labelLines z:5];
    
    
    m_labelBet = [CCLabelFX labelWithString:@"20"
                                 dimensions:CGSizeMake(1000, 200)
                                  alignment:kCCTextAlignmentCenter
                                   fontName:@"Delicious"
                                   fontSize:30 * CC_CONTENT_SCALE_FACTOR()
                               shadowOffset:CGSizeMake(2, -2)
                                 shadowBlur:1
                                shadowColor:colorShadow
                                  fillColor:colorFill
                  ];
    m_labelBet.position = CGPointMake(580, 126);
    [self addChild:m_labelBet z:5];
    
    
    m_labelTotalBet = [CCLabelFX labelWithString:@"200"
                                 dimensions:CGSizeMake(1000, 200)
                                  alignment:kCCTextAlignmentCenter
                                   fontName:@"Delicious"
                                   fontSize:30 * CC_CONTENT_SCALE_FACTOR()
                                    shadowOffset:CGSizeMake(2, -2)
                                      shadowBlur:1
                                shadowColor:colorShadow
                                  fillColor:colorFill
                  ];
    m_labelTotalBet.position = CGPointMake(709, 126);
    [self addChild:m_labelTotalBet z:5];
    
    
    m_labelWin = [CCLabelFX labelWithString:@"85"
                                 dimensions:CGSizeMake(1000, 200)
                                  alignment:kCCTextAlignmentCenter
                                   fontName:@"Delicious"
                                   fontSize:30 * CC_CONTENT_SCALE_FACTOR()
                               shadowOffset:CGSizeMake(2, -2)
                                 shadowBlur:1
                                shadowColor:colorShadow
                                  fillColor:colorFill
                  ];
    m_labelWin.position = CGPointMake(871, 126);
    [self addChild:m_labelWin z:5];

    [self checkLabels];
}

-(void) checkLabels
{
    [m_labelBalance setString:[NSString stringWithFormat:@"%.1f", m_nBalance / 10.0f ]];
    [m_labelLines setString:[NSString stringWithFormat:@"%d", m_nLines ]];
    [m_labelBet setString:[NSString stringWithFormat:@"%.1f", m_nBet / 10.0f ]];
    [m_labelTotalBet setString:[NSString stringWithFormat:@"%.1f", m_nTotalBet / 10.0f ]];
    [m_labelWin setString:[NSString stringWithFormat:@"%.1f", m_nWin / 10.0f ]];
}

-(void) initButtons
{
    m_btnSpin = [CCMenuItemImage itemWithNormalImage:@"spin.png" selectedImage:@"spin_desaturated.png" disabledImage:@"spin_desaturated.png" target:self selector:@selector(onSpin)];
    m_btnSpin.position = CGPointMake(880, 45);

    m_btnMaxLines = [CCMenuItemImage itemWithNormalImage:@"maxlines.png" selectedImage:@"maxlines_desaturated.png" disabledImage:@"maxlines_desaturated.png" target:self selector:@selector(onMaxLines)];
    m_btnMaxLines.position = CGPointMake(714, 45);

    m_btnBetPrev = [CCMenuItemImage itemWithNormalImage:@"button_triangle.png" selectedImage:@"button_triangle_desaturated.png" disabledImage:@"button_triangle_desaturated.png" target:self selector:@selector(onBetPrev)];
    m_btnBetPrev.position = CGPointMake(546, 55);
    
    m_btnBetNext = [CCMenuItemImage itemWithNormalImage:@"button_triangle.png" selectedImage:@"button_triangle_desaturated.png" disabledImage:@"button_triangle_desaturated.png" target:self selector:@selector(onBetNext)];
    m_btnBetNext.position = CGPointMake(600, 35);
    m_btnBetNext.scale = -1;
    
    m_btnLinesPrev = [CCMenuItemImage itemWithNormalImage:@"button_triangle.png" selectedImage:@"button_triangle_desaturated.png" disabledImage:@"button_triangle_desaturated.png" target:self selector:@selector(onLinesPrev)];
    m_btnLinesPrev.position = CGPointMake(421, 55);
    
    m_btnLinesNext = [CCMenuItemImage itemWithNormalImage:@"button_triangle.png" selectedImage:@"button_triangle_desaturated.png" disabledImage:@"button_triangle_desaturated.png" target:self selector:@selector(onLinesNext)];
    m_btnLinesNext.position = CGPointMake(478, 35);
    m_btnLinesNext.scale = -1;
    
    m_btnPayTable = [CCMenuItemImage itemWithNormalImage:@"pay_table.png" selectedImage:@"pay_table_desaturated.png" disabledImage:@"pay_table_desaturated.png" target:self selector:@selector(onPayTable)];
    m_btnPayTable.position = CGPointMake(305, 77);

    ScaleMenu *menu = [ScaleMenu menuWithItems: m_btnSpin, m_btnMaxLines, m_btnBetPrev, m_btnBetNext,m_btnLinesPrev, m_btnLinesNext, m_btnPayTable, nil];
    menu.position = CGPointZero;
    [self addChild: menu z:4];

    for (int j = 0; j < 2; j++) {
        for (int i = 0 ; i < m_nLevelMaxLines; i++) {
            
            m_btnLine[j][i] = [CCMenuItemImage itemWithNormalImage:strLineButton[i]
                                                     selectedImage:@"line_number_desaturated.png"
                                                     disabledImage:@"line_number_desaturated.png"
                                                            target:self
                                                          selector:@selector(onLine:)
                               ];
            m_btnLine[j][i].position = ptbtnLine[j][i];
            [menu addChild:m_btnLine[j][i] z:4 ];
            
            CCLabelTTF* spr = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"%d", i+1]
                                                                            fontName:@"Delicious"
                                                 fontSize:20 * CC_CONTENT_SCALE_FACTOR()];
            spr.position = ptbtnLine[j][i];
            [self addChild:spr z:5];
         }
    }
}

-(void) initVariables
{
    m_nBalance = 6000;
    m_nBet = 1;
    m_nWin = 0;

    m_bBonusGame = false;

    m_bEnable = true;
    //init Lines
    m_nLevelMaxLines = 9;
    m_nLines = 1;
    for (int i = 0 ; i < MAX_LINES; i++) {
        for ( int row = 0; row < ROW ; row++ ) {
            m_nLineInfo[i][row] = -1;
        }
    }
    
    m_nTotalBet = m_nLines * m_nBet;

    m_nLineInfo[0][0] = 1;
    m_nLineInfo[0][1] = 1;
    m_nLineInfo[0][2] = 1;
    m_nLineInfo[0][3] = 1;
    m_nLineInfo[0][4] = 1;
    
    m_nLineInfo[1][0] = 2;
    m_nLineInfo[1][1] = 2;
    m_nLineInfo[1][2] = 2;
    m_nLineInfo[1][3] = 2;
    m_nLineInfo[1][4] = 2;
    
    m_nLineInfo[2][0] = 0;
    m_nLineInfo[2][1] = 0;
    m_nLineInfo[2][2] = 0;
    m_nLineInfo[2][3] = 0;
    m_nLineInfo[2][4] = 0;
    
    m_nLineInfo[3][0] = 2;
    m_nLineInfo[3][1] = 1;
    m_nLineInfo[3][2] = 0;
    m_nLineInfo[3][3] = 1;
    m_nLineInfo[3][4] = 2;

    m_nLineInfo[4][0] = 0;
    m_nLineInfo[4][1] = 1;
    m_nLineInfo[4][2] = 2;
    m_nLineInfo[4][3] = 1;
    m_nLineInfo[4][4] = 0;

    m_nLineInfo[5][0] = 1;
    m_nLineInfo[5][1] = 2;
    m_nLineInfo[5][2] = 2;
    m_nLineInfo[5][3] = 2;
    m_nLineInfo[5][4] = 1;

    m_nLineInfo[6][0] = 1;
    m_nLineInfo[6][1] = 0;
    m_nLineInfo[6][2] = 0;
    m_nLineInfo[6][3] = 0;
    m_nLineInfo[6][4] = 1;

    m_nLineInfo[7][0] = 2;
    m_nLineInfo[7][1] = 2;
    m_nLineInfo[7][2] = 1;
    m_nLineInfo[7][3] = 0;
    m_nLineInfo[7][4] = 0;

    m_nLineInfo[8][0] = 0;
    m_nLineInfo[8][1] = 0;
    m_nLineInfo[8][2] = 1;
    m_nLineInfo[8][3] = 2;
    m_nLineInfo[8][4] = 2;
    
    for (int nCardID = 0; nCardID == CARD_COUNT; nCardID++) {
        for (int nSameCount = 0; nSameCount < MAX_SAME_CARD_COUNT; nSameCount++) {
            m_nScoreMulti[nCardID][nSameCount] = 0;
        }
    }

    //low_card1
    m_nScoreMulti[0][0] = 0;
    m_nScoreMulti[0][1] = 0;
    m_nScoreMulti[0][2] = 4;
    m_nScoreMulti[0][3] = 150;
    m_nScoreMulti[0][4] = 500;

    //low_card2
    m_nScoreMulti[1][0] = 0;
    m_nScoreMulti[1][1] = 0;
    m_nScoreMulti[1][2] = 5;
    m_nScoreMulti[1][3] = 200;
    m_nScoreMulti[1][4] = 600;

    //low_card3
    m_nScoreMulti[2][0] = 0;
    m_nScoreMulti[2][1] = 0;
    m_nScoreMulti[2][2] = 100;
    m_nScoreMulti[2][3] = 300;
    m_nScoreMulti[2][4] = 800;
    
    //low_card4
    m_nScoreMulti[3][0] = 0;
    m_nScoreMulti[3][1] = 0;
    m_nScoreMulti[3][2] = 150;
    m_nScoreMulti[3][3] = 500;
    m_nScoreMulti[3][4] = 1000;
    
    //low_card5
    m_nScoreMulti[4][0] = 0;
    m_nScoreMulti[4][1] = 0;
    m_nScoreMulti[4][2] = 200;
    m_nScoreMulti[4][3] = 600;
    m_nScoreMulti[4][4] = 1200;
    
    //high_card1
    m_nScoreMulti[5][0] = 0;
    m_nScoreMulti[5][1] = 0;
    m_nScoreMulti[5][2] = 200;
    m_nScoreMulti[5][3] = 750;
    m_nScoreMulti[5][4] = 1500;

    //high_card2
    m_nScoreMulti[6][0] = 0;
    m_nScoreMulti[6][1] = 0;
    m_nScoreMulti[6][2] = 250;
    m_nScoreMulti[6][3] = 1000;
    m_nScoreMulti[6][4] = 2000;
    
    //high_card3
    m_nScoreMulti[7][0] = 0;
    m_nScoreMulti[7][1] = 30;
    m_nScoreMulti[7][2] = 300;
    m_nScoreMulti[7][3] = 1500;
    m_nScoreMulti[7][4] = 3000;
    
    //high_card4
    m_nScoreMulti[8][0] = 0;
    m_nScoreMulti[8][1] = 40;
    m_nScoreMulti[8][2] = 400;
    m_nScoreMulti[8][3] = 2000;
    m_nScoreMulti[8][4] = 5000;
    
    //high_card5
    m_nScoreMulti[9][0] = 0;
    m_nScoreMulti[9][1] = 50;
    m_nScoreMulti[9][2] = 500;
    m_nScoreMulti[9][3] = 2500;
    m_nScoreMulti[9][4] = 10000;
    
    m_nCardGenerationRatio[0] = 8;
    m_nCardGenerationRatio[1] = 8;
    m_nCardGenerationRatio[2] = 8;
    m_nCardGenerationRatio[3] = 8;
    m_nCardGenerationRatio[4] = 8;

    m_nCardGenerationRatio[5] = 4;
    m_nCardGenerationRatio[6] = 4;
    m_nCardGenerationRatio[7] = 4;
    m_nCardGenerationRatio[8] = 2;
    m_nCardGenerationRatio[9] = 2;

    m_nCardGenerationRatio[10] = 1;
    m_nCardGenerationRatio[11] = 1;
    m_nCardGenerationRatio[12] = 1;
    
    m_nGenerationTotal = 0;
    for (int i = 0; i < CARD_COUNT; i++) {
        m_nGenerationTotal += m_nCardGenerationRatio[i];
    }
}
-(void) update:(ccTime)dt
{
    m_fAniTime += dt;
    if(m_bAni)
    {

        if ((FLOWCOLUMN*ROW -3) * FLOW_TIME < m_fAniTime)
        {
            m_bAni = false;
            m_fAniTime = 0;
            m_nSuccessLineInfoCount = 0;
            m_nWin = 0;
            int nScatterCount = [self countScatter];
            if (nScatterCount >= 3) {
                switch (nScatterCount) {
                    case 3:
                        m_nFreeSpinCount = 5;
                        break;
                    case 4:
                        m_nFreeSpinCount = 10;
                        break;
                    default:
                        m_nFreeSpinCount = 20;
                }
                nScatterCount = MIN(5, nScatterCount);

                //for Scatter ani
                [m_pCardAniLayer addScatter];
                int rows[5] = {-1,}, columns[5] = {-1,};
                [self getScatterCards:nScatterCount rows:rows columns:columns];

                for (int i = 0; i < nScatterCount; i++) {
                    int column = columns[i];
                    int row = rows[i];

                    int nCardID = m_nCard[column] [row];
                    CGPoint pt= CGPointMake(ptFirstPos[row].x, ptFirstPos[row].y + sizeCard.y * column);
                    [m_pCardAniLayer addCard:m_sprCards[nCardID] pos:pt nLine:Line_Scatter nCardID:nCardID nColumn:column nRow:row];
                }
                ///////////////
            }

            [self checkSuccessLines];
            if (m_nWin) {
                m_fLineAniTime = 0.0f;
                m_nAniLine = -1;
                [self playCardAnimations:m_nAniLine fAniTime:m_fAniTime];
            }
            m_nBalance += m_nWin;
            [self checkLabels];
        }
    }
    else {
        if (m_pCardAniLayer->m_bBonus) {
            int nBonus = m_pCardAniLayer->m_bBonus ? 1 :0;
            int nScatter = m_pCardAniLayer->m_bScatter ? 1 :0;
            float time = ([m_pCardAniLayer->m_arrLines count] + nBonus + nScatter) * ANI_TIME_PER_LINE;
            if (m_fAniTime > time) {
                m_pBonusLayer = [[BonusLayer alloc] initWithParameter:self nGameType:1 nBonusScore:m_nBonusCardCount];
                [self addChild:m_pBonusLayer z:10];
            }
        }
        else if ( m_nFreeSpinCount > 0 ) {
            int nBonus = m_pCardAniLayer->m_bBonus ? 1 :0;
            int nScatter = m_pCardAniLayer->m_bScatter ? 1 :0;
            float time = ([m_pCardAniLayer->m_arrLines count] + nBonus + nScatter) * ANI_TIME_PER_LINE;
            if (m_fAniTime > time)
            {
                m_sprFreeSpin.visible = true;
                m_labelFreeSpinCount.visible = true;
                [m_labelFreeSpinCount setString:[NSString stringWithFormat:@"%d", m_nFreeSpinCount]];
                m_sprTitle.visible = false;
                [self spin:m_nBet];
            }
        }
        else {
            m_sprFreeSpin.visible = false;
            m_labelFreeSpinCount.visible = false;
            m_sprTitle.visible = true;
        }
//        if (m_nWin) {
//            m_fAniTime++;
//        }
    }
}
-(void) playCardAnimations:(int)nAniLine fAniTime:(float)fAniTime
{
    [m_pCardAniLayer clear];
    bool bCards[5] = {false,};

    for (int nLine = 0; nLine < m_nSuccessLineInfoCount; nLine++) {
        int nLineID = m_nSuccessLineInfo[nLine];
        if ([m_pCardAniLayer addLine:m_sprLines[nLineID] nLineID:nLineID] == false) {
            continue;
        }
        [self getSameCard:nLineID nCards:bCards];
        for (int row = 0; row < ROW; row++) {
            if (bCards[row] == true) {
                int column =  m_nLineInfo[nLineID][row];
                int nCardID = m_nCard[column] [row];
                CGPoint pt= CGPointMake(ptFirstPos[row].x, ptFirstPos[row].y + sizeCard.y * column);
                [m_pCardAniLayer addCard:m_sprCards[nCardID] pos:pt nLine:nLineID nCardID:nCardID nColumn:column nRow:row];
            }
        }
    }
    [m_pCardAniLayer start];
}
-(void) playCardAnimation:(CCSprite*)spr fAniTime:(float)fAniTime
{
    
}
-(void) getSameCard:(int)nLineID nCards:(bool *)nCards
{
//    int nScore = 0;
//    for (int nCardID = LOW_CARD_COUNT + HIGH_CARD_COUNT-1 ; nCardID >= 0 ; nCardID-- ) {
//        int nCardCount = 0;
//        int nMaxCardCount = 0;
//        for (int row = 0; row < ROW; row++) {
//            if (m_nCard[m_nLineInfo[nLineID][row]][row] == nCardID
//                || nCards[row] == WILD_CARD)
//            {
//                nCardCount++;
//                if (nMaxCardCount < nCardCount) {
//                    nMaxCardCount = nCardCount;
//                }
//            }
//            else
//                nCardCount = 0;
//        }
//        if (nMaxCardCount > 0 && nScore < m_nScoreMulti[nCardID][nMaxCardCount - 1] * m_nBet)
//            nScore = m_nScoreMulti[nCardID][nMaxCardCount - 1] * m_nBet;
//    }
    for (int row = 0; row < ROW; row++) {
        nCards[row] = false;
    }
    int nFinalCardID = -1;
    int nFinalCardCount = 0;
    int nFinalScore = 0;
    int nNewCardID = -1;
    int nNewCardCount = 0;
    for (int row = 0; row < ROW; row++) {
        int nCardID = m_nCard[m_nLineInfo[nLineID][row]][row];
        if(nCardID == WILD_CARD && nNewCardID == -1)
        {
            nNewCardID = WILD_CARD;
            nNewCardCount++;
        }
        else if(nNewCardID == WILD_CARD)
        {
            nNewCardID = nCardID;
            nNewCardCount++;
        }
        else if (nCardID == nNewCardID || nCardID == WILD_CARD ) {
            nNewCardCount++;
        }
        else {
            nNewCardID = nCardID;
            nNewCardCount = 1;

            int nTempROW = row -1;
            while (nTempROW >= 0) {
                if (m_nCard[m_nLineInfo[nLineID][nTempROW]][nTempROW] == WILD_CARD) {
                    nNewCardCount++;
                    nTempROW--;
                }
                else
                    break;
            }
        }
        if( m_nScoreMulti[nNewCardID][nNewCardCount] * m_nTotalBet > nFinalScore )
        {
            nFinalCardID = nNewCardID;
            nFinalCardCount = nNewCardCount;
            nFinalScore = m_nScoreMulti[nNewCardID][nNewCardCount] * m_nTotalBet;
            for (int i  = 0; i < ROW; i++) {
                nCards[i] = false;
            }
            
            int nCardCount = nNewCardCount;
            int ntempRow = row;
            while (nCardCount) {
                nCards[ntempRow] = true;
                nCardCount--;
                ntempRow--;
            }
        }
    }
}
-(void) getScatterCards:(int)nCount rows:(int*)rows columns:(int*)columns
{
    int nScatterCount = 0;
    for (int column = 0; column < COLUMN; column++) {
        for (int row = 0; row < ROW; row++) {
            if (m_nCard[column][row] == SCATTER_CARD) {
                rows[nScatterCount] = row;
                columns[nScatterCount] = column;
                nScatterCount++;
                if (nScatterCount == nCount) {
                    return;
                }
            }
        }
    }
}
-(void) checkSuccessLines
{
    for (int i = 0; i < m_nLines; i++) {
        int nCards[ROW] = {0,};
        for (int row = 0; row < ROW; row++) {
            int column = m_nLineInfo[i][row];
            nCards[row] = m_nCard[column][row];
        }

        int nBonusCard = [self checkBonus:nCards];

        //BonusGame
        if (m_nBonusCardCount < nBonusCard)
            m_nBonusCardCount = nBonusCard;
        
        //
        int nScore = [self checkLine:nCards];
        if(nScore > 0)
        {
            m_nWin += nScore;
            m_nSuccessLineInfo[m_nSuccessLineInfoCount] = i;
            m_nSuccessLineInfoCount++;
        }
    }
}

-(int) checkBonus:(int *)nCards
{
    int nBonusCardCount = 0;
    for (int row = 0; row < ROW; row++) {
        if (nCards[row] == BONUS_CARD) {
            nBonusCardCount++;
        }
    }
    return nBonusCardCount;
}

-(int) countScatter
{
    int nScatterCount = 0;
    for (int column = 0; column < COLUMN; column++) {
        for (int row = 0; row < ROW; row++) {
            if (m_nCard[column][row] == SCATTER_CARD) {
                nScatterCount++;
            }
        }
    }
    return nScatterCount;
}
-(int) checkLine:(int *)nCards
{
    int nScore = 0;
    for (int nCardID = LOW_CARD_COUNT + HIGH_CARD_COUNT-1 ; nCardID >= 0 ; nCardID-- ) {
        int nCardCount = 0;
        int nMaxCardCount = 0;
        for (int row = 0; row < ROW; row++) {
            if (nCards[row] == nCardID
                || nCards[row] == WILD_CARD)
            {
                nCardCount++;
                if (nMaxCardCount < nCardCount) {
                    nMaxCardCount = nCardCount;
                }
            }
            else
                nCardCount = 0;
        }
        if (nMaxCardCount > 0 && nScore < m_nScoreMulti[nCardID][nMaxCardCount - 1] * m_nBet)
            nScore = m_nScoreMulti[nCardID][nMaxCardCount - 1] * m_nBet;
    }
    return nScore;
}

-(void) makeFlow
{
    int row = 0, column = 0;
    for (row =0 ; row < ROW; row++) {
        for (column  = 0; column < FLOWCOLUMN; column++) {
            m_nFlowCard[column][row] = -1;
        }
    }
    
    for (row = 0 ; row < ROW; row++) {
        for (column  = 0; column < FLOWCOLUMN; column++) {
            if (column < COLUMN)
                m_nFlowCard[column][row] = m_nCard[column][row];
            else
            {
                m_nFlowCard[column][row] = [self getRandCard];
            }
        }
    }

    for (row =0 ; row < ROW; row++) {
        for (column  = 0; column < COLUMN; column++) {
            int nFlowColumn = FLOWCOLUMN - COLUMN + column;
            m_nCard[column][row] = m_nFlowCard[nFlowColumn][row];
        }
    }
}

-(int) getRandCard
{
    int value = rand() % m_nGenerationTotal;
    
    int nTemp = 0;
    for (int i = 0; i < CARD_COUNT; i++) {
        nTemp += m_nCardGenerationRatio[i];
        if( value < nTemp )
            return i;
    }
    return 0;
}

-(void) setEnable:(bool)bEnable
{
    m_bEnable = bEnable;
}

-(void) draw
{
    int column = 0, row = 0;
    for (row = 0; row < ROW; row++) {
        bool bRowAni = true;
        if((FLOWCOLUMN*(row+1) -3) * FLOW_TIME < m_fAniTime)
            bRowAni = false;

        if (m_bAni && bRowAni) {
            float fAniTime = m_fAniTime;
            for (int i =0 ; i < ROW; i++) {
                if (fAniTime > FLOWCOLUMN * FLOW_TIME) {
                    fAniTime -= FLOWCOLUMN * FLOW_TIME;
                }
                else
                    break;
            }

            for (column = 0; column < FLOWCOLUMN; column++) {
                int nCardNum = m_nFlowCard[column][row];
                if (nCardNum == -1) {
                    continue;
                }
                CCSprite* spr = m_sprCards[nCardNum];
                CGPoint pt = CGPointMake(ptFirstPos[row].x,
                                         ptFirstPos[row].y + sizeCard.y * (column - fAniTime / FLOW_TIME));
                spr.position = pt;
                spr.opacity = 255;
                [spr visit];

                pt = CGPointMake(ptFirstPos[row].x + sizeCard.x * row,
                                         ptFirstPos[row].y + sizeCard.y * (FLOWCOLUMN + column - fAniTime / FLOW_TIME));
                spr.opacity = 255;
                spr.position = pt;
                [spr visit];
            }
        }
        else
        {
            for (column = 0 ; column < COLUMN; column++) {
                CCSprite* spr = m_sprCards[m_nCard[column][row]];
                CGPoint pt= CGPointMake(ptFirstPos[row].x, ptFirstPos[row].y + sizeCard.y *column);
                spr.opacity = 255;
                spr.position = pt;
                if (m_pCardAniLayer->m_bAniSprite[column][row] == false) {
                    [spr visit];
                }
            }
        }
    }
}

-(void) onSpin
{
    if (!m_bEnable) {
        return;
    }
    [self spin:m_nTotalBet];
}

-(void) spin:(int)nTotalBet
{
    if (m_bAni)
        return;
    if (m_nFreeSpinCount <= 0 && m_nBalance < m_nTotalBet){
        return;
    }
    m_bAni = true;
    m_fAniTime = 0.0f;
    m_nWin = 0;
    m_nSuccessLineInfoCount = 0;
    m_nBonusCardCount = 0;
    [m_pCardAniLayer clear];
    if (m_nFreeSpinCount > 0) {
        m_nFreeSpinCount--;
        [self makeFlow];
    }
    else if(m_nBalance >= m_nTotalBet)
    {
        m_nBalance -= m_nTotalBet;
        [self makeFlow];
    }
    
    for (int nLineID = 0; nLineID < m_nLevelMaxLines; nLineID++) {
        m_sprLines[nLineID].visible = false;
    }
}

-(void) onMaxLines
{
    if (!m_bEnable) {
        return;
    }

    [self spin:m_nLines];
}
-(void) onBetPrev
{
    if (!m_bEnable) {
        return;
    }

    int nNewBet = 1;
    switch (m_nBet) {
        case 1:
            nNewBet = 1;
            break;
            
        case 2:
            nNewBet = 1;
            break;
            
        case 5:
            nNewBet = 2;
            break;
            
        case 10:
            nNewBet = 5;
            break;
            
        case 20:
            nNewBet = 10;
            break;

        case 50:
            nNewBet = 20;
            break;
            
        default:
            break;
    }
    [self setBetValue:nNewBet];
}
-(void) onBetNext
{
    
    if (!m_bEnable) {
        return;
    }

    int nNewBet = 1;
    switch (m_nBet) {
        case 1:
            nNewBet = 2;
            break;
            
        case 2:
            nNewBet = 5;
            break;
            
        case 5:
            nNewBet = 10;
            break;
            
        case 10:
            nNewBet = 20;
            break;
            
        case 20:
            nNewBet = 50;
            break;
            
        case 50:
            nNewBet = 50;
            break;
            
        default:
            break;
    }
    [self setBetValue:nNewBet];

}
-(void) onLinesPrev
{
    if (!m_bEnable) {
        return;
    }

    [self setLineCount:m_nLines - 1];
}
-(void) onLinesNext
{
    if (!m_bEnable) {
        return;
    }

    [self setLineCount:m_nLines + 1];
    
}

-(void) onPayTable
{
    if (!m_bEnable) {
        return;
    }

}

-(void) onLine:(id)sender
{
    if (!m_bEnable) {
        return;
    }

    for (int j = 0; j < 2; j++){
    for (int i = 0 ; i < m_nLevelMaxLines; i++) {
        if(sender == m_btnLine[j][i])
        {
            [self setLineCount:i+1];
        }
    }}
}

-(void) setLineCount:(int)nLineCount
{
    if (nLineCount < 1)
        nLineCount = 1;
    
    if (nLineCount > m_nLevelMaxLines)
        nLineCount = m_nLevelMaxLines;

    m_nLines = nLineCount;

    m_nTotalBet = m_nBet * m_nLines;
    
    for (int nLineCount = 0; nLineCount < m_nLevelMaxLines; nLineCount++) {
        if (nLineCount < m_nLines)
            m_sprLines[nLineCount].visible = true;
        else
            m_sprLines[nLineCount].visible = false;
    }
    [self checkLabels];
    [self checkLineButtons:m_nLines];
}

-(void) checkLineButtons:(int)nLineCount
{
    for (int j = 0; j < 2; j++) {
        for (int i = 0; i < m_nLevelMaxLines; i++) {
            if (i < m_nLines) {
                CCNode<CCRGBAProtocol> *normalImage = [CCSprite spriteWithFile:strLineButton[i]];
                [m_btnLine[j][i] setNormalImage:normalImage];
            }
            else {
                CCNode<CCRGBAProtocol> *normalImage = [CCSprite spriteWithFile:@"line_number_desaturated.png"];
                [m_btnLine[j][i] setNormalImage:normalImage];
            }
        }
    }
}

-(void) setBetValue:(int)nBetValue
{
    m_nBet = nBetValue;
    m_nTotalBet = m_nBet * m_nLines;
    [self checkLabels];
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}

#pragma mark GameKit delegate

-(void) achievementViewControllerDidFinish:(GKAchievementViewController *)viewController
{
	AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
	[[app navController] dismissModalViewControllerAnimated:YES];
}

-(void) leaderboardViewControllerDidFinish:(GKLeaderboardViewController *)viewController
{
	AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
	[[app navController] dismissModalViewControllerAnimated:YES];
}
@end
