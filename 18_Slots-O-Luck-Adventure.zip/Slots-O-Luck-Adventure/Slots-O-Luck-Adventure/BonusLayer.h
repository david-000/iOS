//
//  BonusLayer.h
//  Slots-O-Luck-Adventure
//
//  Created by osone on 5/15/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "ScaleLayer.h"
#define COUNT_SCREEN 3
#define COUNT_BONUS_BUTTON 5
@class BonusLayer;
@interface BonusScreen : ScaleLayer
{
    int m_nScreenID;
    BonusLayer* m_pParent;
    CCSprite*   m_sprBack;
    CCMenuItem* m_pButton[COUNT_BONUS_BUTTON];
}

-(id) initWithParam:(BonusLayer*)pParent nScreenID:(int)nScreenID;

-(void) onButton:(id)idButton;

@end

@class GameLayer1;
@interface BonusLayer : CCLayer {
    GameLayer1*     m_pParent;
    BonusScreen*    m_pScreen[COUNT_SCREEN];
    int             m_nCurScreenID;
    int             m_nScore;
}

-(id) initWithParameter:(GameLayer1*)pParent nGameType:(int)nGametype nBonusScore:(int)nBonusScore;
-(void) updateScreen;
-(void) onButton:(int)nButtonID;
-(void) onFinish;
@end
