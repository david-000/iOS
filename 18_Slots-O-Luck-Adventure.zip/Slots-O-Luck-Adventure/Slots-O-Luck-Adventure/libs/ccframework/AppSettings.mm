//
//  AppSetting.m
//  fruitGame
//
//  Created by KCU on 5/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AppSettings.h"


@implementation AppSettings

+ (void) defineUserDefaults
{
	NSString* userDefaultsValuesPath;
	NSDictionary* userDefaultsValuesDict;
	
	// load the default values for the user defaults
	userDefaultsValuesPath = [[NSBundle mainBundle] pathForResource:@"setting" ofType:@"plist"];
	userDefaultsValuesDict = [NSDictionary dictionaryWithContentsOfFile: userDefaultsValuesPath];
	[[NSUserDefaults standardUserDefaults] registerDefaults: userDefaultsValuesDict];
}
+ (void) setScore:(int)nlevel nScore:(int64_t) nScore
{
    if (g_bTestMode) {
        return;
    }
    
    if ([AppSettings getScore:nlevel] >= nScore) {
        return;
    }
    
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSNumber* score  =	[NSNumber numberWithUnsignedLongLong: nScore];
    [defaults setObject:score forKey:@"MT_Score_%d"];

	[NSUserDefaults resetStandardUserDefaults];	
}

+ (int64_t) getScore:(int)nlevel
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSNumber* score;
    score = [defaults objectForKey:[NSString stringWithFormat:@"MT_Score_%d", nlevel]];
    return [score unsignedLongLongValue];
}

+ (void) setMAXScore:(int)nMaxScore {
    if (g_bTestMode) {
        return;
    }
    
    if ([AppSettings getMAXScore] >= nMaxScore) {
        return;
    }
    
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSNumber* score  =	[NSNumber numberWithUnsignedLongLong: nMaxScore];
    [defaults setObject:score forKey:@"MT_MAX_Score"];	
	[NSUserDefaults resetStandardUserDefaults];	
}

+ (int64_t) getMAXScore {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSNumber* score;
    score = [defaults objectForKey:@"MT_MAX_Score"];
    return [score unsignedLongLongValue];
}

+ (void) setBGMEnable: (BOOL) bBGMEnable {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSNumber* aFlag  =	[NSNumber numberWithFloat: bBGMEnable];	
	[defaults setObject:aFlag forKey:@"BGMEnable"];	
	[NSUserDefaults resetStandardUserDefaults];
}

+ (void) setEMEnable: (BOOL) bVolume {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSNumber* aFlag  =	[NSNumber numberWithFloat: bVolume];	
	[defaults setObject:aFlag forKey:@"EMEnable"];	
	[NSUserDefaults resetStandardUserDefaults];
}

+ (BOOL) isBGMEnable {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];	
	return [defaults boolForKey: @"BGMEnable"];
}

+ (BOOL) isEMEnable {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];	
	return [defaults boolForKey: @"EMEnable"];
}

+ (void) setCurLevel:(int)nLevel {
    if (g_bTestMode) {
        return;
    }
    
    if ([AppSettings getCurLevel] >= nLevel) {
        return;
    }
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSNumber* aFlag  =	[NSNumber numberWithFloat: nLevel];	
    [defaults setObject:aFlag forKey:[NSString stringWithFormat:@"MT_World"]];	
	[NSUserDefaults resetStandardUserDefaults];
}

+ (int)  getCurLevel {
  
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    return [defaults integerForKey:@"MT_World%d"];
}

/*
+ (void) setBackgroundVolume: (float) fVolume
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSNumber* aVolume  =	[[NSNumber alloc] initWithFloat: fVolume];	
	[defaults setObject:aVolume forKey:@"music"];	
	[NSUserDefaults resetStandardUserDefaults];	
}

+ (float) backgroundVolume
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	
	return [defaults floatForKey:@"music"];
	
}

+ (void) setEffectVolume: (float) fVolume
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSNumber* aVolume  =	[[NSNumber alloc] initWithFloat: fVolume];	
	[defaults setObject:aVolume forKey:@"effect"];	
	[NSUserDefaults resetStandardUserDefaults];	
}

+ (float) effectVolume
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	
	return [defaults floatForKey:@"effect"];
	
}

+ (void) setLevelFlag: (int) index flag: (BOOL) flag
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSNumber* aFlag  =	[NSNumber numberWithFloat: flag];	
	[defaults setObject:aFlag forKey:[NSString stringWithFormat: @"level%d", index]];	
	[NSUserDefaults resetStandardUserDefaults];		
}

+ (BOOL) getLevelFlag: (int) index
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];	
	return [defaults boolForKey: [NSString stringWithFormat: @"level%d", index]];	
}

+(void) setStartLevel: (int) index 
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSNumber* aFlag  =	[NSNumber numberWithFloat: index];	
	[defaults setObject:aFlag forKey: @"curLevel"];	
	[NSUserDefaults resetStandardUserDefaults];
}

+ (BOOL) getStartLevel
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];	
	return [defaults boolForKey: @"curLevel"];
}

+(void) setUseAccelFlag:(BOOL)bFlag
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSNumber* aFlag  =	[NSNumber numberWithFloat: bFlag];	
	[defaults setObject:aFlag forKey:@"useAccelFlag"];	
	[NSUserDefaults resetStandardUserDefaults];
}

+(BOOL) getUseAccelFlag
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];	
	return [defaults boolForKey: @"useAccelFlag"];
}
*/
@end
