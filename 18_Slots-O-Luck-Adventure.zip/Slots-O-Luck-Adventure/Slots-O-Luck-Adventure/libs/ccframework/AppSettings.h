//
//  AppSetting.h
//  fruitGame
//
//  Created by KCU on 5/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "global.h"

@interface AppSettings : NSObject 
{

}

+ (void) defineUserDefaults;

+ (void) setBGMEnable: (BOOL) bBGMEnable;
+ (void) setEMEnable: (BOOL) bVolume;
+ (BOOL) isBGMEnable;
+ (BOOL) isEMEnable;
+ (void) setCurLevel:(int)nLevel;
+ (int)  getCurLevel;
/*+ (void) setLevelFlag: (int) index flag: (BOOL) flag;
+ (BOOL) getLevelFlag: (int) index;
+ (void) setStartLevel: (int) index;
+ (BOOL) getStartLevel;
+ (void) setUseAccelFlag: (BOOL) bFlag;
+ (BOOL) getUseAccelFlag;
 */
+ (void) setScore:(int)nlevel nScore:(int64_t) nScore;
+ (int64_t) getScore:(int)nlevel;

+ (void) setMAXScore:(int)nMaxScore;
+ (int64_t) getMAXScore;
@end
