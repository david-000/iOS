//
//  ScaleMenuItemToggle.mm
//  Mahjong_cc
//
//  Created by YunCholHo on 11/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ScaleMenuItemToggle.h"


@implementation ScaleMenuItemToggle

@end
