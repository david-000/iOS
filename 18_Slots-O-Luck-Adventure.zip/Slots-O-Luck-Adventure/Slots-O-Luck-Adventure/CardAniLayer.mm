//
//  CardAniLayer.m
//  Slots-O-Luck-Adventure
//
//  Created by osone on 5/16/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "CardAniLayer.h"


NSString* strSquare[MAX_LINES] = 
{
    @"square_5.png",//1
    @"square_8.png",//2
    @"square_2.png",//3
    @"square_9.png",//4
    @"square_1.png",//5
    @"square_6.png",//6
    @"square_4.png",//7
    @"square_7.png",//8
    @"square_3.png",//9
};

#define BONUS_ANI_COUNT 10
NSString* strBonusAni[BONUS_ANI_COUNT] = 
{
    @"bonus_frame_1.png",
    @"bonus_frame_2.png",
    @"bonus_frame_3.png",
    @"bonus_frame_4.png",
    @"bonus_frame_5.png",
    @"bonus_frame_6.png",
    @"bonus_frame_7.png",
    @"bonus_frame_8.png",
    @"bonus_frame_9.png",
    @"bonus_frame_10.png",
};


#define SCATTER_ANI_COUNT 8
NSString* strScatterAni[SCATTER_ANI_COUNT] = 
{
    @"scatter_frame_1.png",
    @"scatter_frame_2.png",
    @"scatter_frame_3.png",
    @"scatter_frame_4.png",
    @"scatter_frame_5.png",
    @"scatter_frame_6.png",
    @"scatter_frame_7.png",
    @"scatter_frame_8.png",
};

#define WILD_ANI_COUNT 8
NSString* strWildAni[WILD_ANI_COUNT] = 
{
    @"wild_frame_1.png",
    @"wild_frame_2.png",
    @"wild_frame_3.png",
    @"wild_frame_4.png",
    @"wild_frame_5.png",
    @"wild_frame_6.png",
    @"wild_frame_7.png",
    @"wild_frame_8.png",
};

#define SQUARE_ANI_COUNT 2
NSString* strSquareAni[SQUARE_ANI_COUNT] = 
{
    @"light_bulbs_a.png",
    @"light_bulbs_b.png",
};

@implementation NSAniCard

@end

@implementation NSAniLine
- (id)init
{
    self = [super init];
    if (self) {
        m_arrCards = [[NSMutableArray alloc] init];
    }
    return self;
}

-(void) dealloc
{
    [m_arrCards release];
    [super dealloc];
}
@end

@implementation CardAniLayer

-(id) initWithParam :(GameLayer1*) pParent
{
    if((self = [super init]))
    {
        
        m_pParent = pParent;
        
        m_fAniTime = 0.0f;
        m_fFlashTime = 0.0f;
        m_nAniLine = -3;
        
        m_bAni = false;
        

        m_arrLines = [[NSMutableArray alloc] init];
        
        m_arrBonusSprites = [[NSMutableArray alloc] init];
        m_arrScatterSprites = [[NSMutableArray alloc] init];
        m_arrWildSprites = [[NSMutableArray alloc] init];
        m_arrSquareSprites = [[NSMutableArray alloc] init];
        
        m_bBonus = false;
        m_lineBonus = [[NSAniLine alloc] init];

        m_bScatter = false;
        m_lineScatter = [[NSAniLine alloc] init];

        CCSprite* spr;
        int i = 0;
        for (i = 0; i < BONUS_ANI_COUNT; i++) {
            spr = [CCSprite spriteWithFile:strBonusAni[i]];
            if ([[UIScreen mainScreen] scale] == 1) {
                spr.scale = 0.5;
            }
            [m_arrBonusSprites addObject:spr];
        }
        
        for (i = 0; i < SCATTER_ANI_COUNT; i++) {
            spr = [CCSprite spriteWithFile:strScatterAni[i]];
            if ([[UIScreen mainScreen] scale] == 1) {
                spr.scale = 0.5;
            }
            [m_arrScatterSprites addObject:spr];
        }
        
        for (i = 0; i < WILD_ANI_COUNT; i++) {
            spr = [CCSprite spriteWithFile:strWildAni[i]];
            if ([[UIScreen mainScreen] scale] == 1) {
                spr.scale = 0.5;
            }
            [m_arrWildSprites addObject:spr];
        }

        for (i = 0; i < SQUARE_ANI_COUNT; i++) {
            spr = [CCSprite spriteWithFile:strSquareAni[i]];
            if ([[UIScreen mainScreen] scale] == 1) {
                spr.scale = 0.5;
            }
            [m_arrSquareSprites addObject:spr];
        }

        for (int i = 0 ; i < m_pParent->m_nLevelMaxLines; i++) {
            m_sprSquare[i] = [[CCSprite spriteWithFile:strSquare[i]] retain];
            if ([[UIScreen mainScreen] scale] == 1) {
                m_sprSquare[i].scale = 0.5;
            }
        }
        
        for (int column = 0; column < COLUMN; column++) {
            for (int row = 0; row < ROW; row++) {
                m_bAniSprite[column][row] = false;
            }
        }
        [self scheduleUpdate];
        return self;
    }
    return nil;
}

-(bool) addLine :(CCSprite*)spr nLineID:(int)nLineID
{
    for (NSAniLine* aniline in m_arrLines) {
        if (aniline->spr == spr)
            return false;
    }
    NSAniLine* aniLine = [[NSAniLine alloc] init];
    aniLine->spr = spr;
    aniLine->nLineID = nLineID;
    [m_arrLines addObject:aniLine];
    return true;
}

-(void) addCard : (CCSprite*) card pos:(CGPoint)pos nLine:(int)nLine nCardID:(int)nCardID nColumn:(int)nColumn nRow:(int)nRow
{
    NSAniLine* curAniLine = nil;
    if (nLine == Line_Bouns) {
        curAniLine = m_lineBonus;
    }
    else if(nLine == Line_Scatter)
    {
        curAniLine = m_lineScatter;
    }
    else {
        for (NSAniLine* aniline in m_arrLines) {
            if(aniline->nLineID == nLine)
            {
                curAniLine = aniline;
                break;
            }
        }
    }
    
    if (curAniLine == nil) {
        return;
    }
    
    NSAniCard *aniCard = [[NSAniCard alloc] init];
    aniCard->spr = card;
    aniCard->pt = pos;
    aniCard->m_fAniTime = 0;
    aniCard->m_nCardID = nCardID;
    aniCard->m_nColumn = nColumn;
    aniCard->m_nRow = nRow;
    [curAniLine->m_arrCards addObject:aniCard];
    
    m_bAniSprite[nColumn][nRow] = true;
}

-(void) addScatter
{
    m_bScatter = true;
}

-(void) addBonus:(int)nLineID spr:(CCSprite*)spr
{
    m_bBonus = true;
    m_lineBonus->nLineID = nLineID;
    m_lineBonus->spr = spr;
}

-(void) start
{
    if (m_bAni == true) {
        return;
    }
    m_bAni = true;
    m_fTotalTime = 0.0f;
    m_fAniTime = 0.0f;
    m_fFlashTime = 0.0f;
    
//    NSAniLine* bonusLine = nil;
//    for (NSAniLine* aniline in m_arrLines) {
//        if(((NSAniCard*)[aniline->m_arrCards objectAtIndex:0])->m_nCardID == BONUS_CARD)
//        {
//            bonusLine = aniline;
//            break;
//        }
//    }
//    if (bonusLine != nil) {
//        [self addBonus:bonusLine->nLineID spr: bonusLine->spr];
//        for (NSAniCard* anicard in bonusLine->m_arrCards) {
//            [self addCard:anicard->spr 
//                      pos:anicard->pt
//                    nLine:Line_Bouns 
//                  nCardID:anicard->m_nCardID
//                  nColumn:anicard->m_nColumn
//                     nRow:anicard->m_nRow];
//        }
//        [m_arrLines removeObject:bonusLine];
//    }
}

-(void) stop
{
    m_bAni = false;
    for (int column = 0; column < COLUMN; column++) {
        for (int row = 0; row < ROW; row++) {
            m_bAniSprite[column][row] = false;
        }
    }
}

-(void) clear
{
    [self stop];
    [m_arrLines removeAllObjects];

    m_bBonus = false;
    [m_lineBonus->m_arrCards removeAllObjects];
    m_bScatter = false;
    [m_lineScatter->m_arrCards removeAllObjects];

    m_fAniTime = 0.0f;
    m_fFlashTime = 0.0f;
    m_nAniLine = -3;
}

-(void) update:(ccTime) dt
{
    if (m_bAni == false) {
        return;
    }
    m_fAniTime += dt;
    m_fFlashTime += dt;
    m_fTotalTime += dt;

    if (m_fAniTime > ANI_TIME_PER_LINE) {
        m_nAniLine ++;
        if (m_nAniLine >= [m_arrLines count]) {
            m_nAniLine = -3;
        }
        m_fAniTime -= m_fAniTime;
    }
    
    if (m_fFlashTime >= ANI_TIME_PER_FLASH) {
        m_fFlashTime -= ANI_TIME_PER_FLASH;
    }
    
    if (m_nAniLine == -3) {
        if( m_bBonus == false)
            m_nAniLine = -2;
        else
        {
            for (NSAniLine* aniline in m_arrLines) {
                if (aniline == m_lineBonus)
                    aniline->spr.visible = true;
                else
                    aniline->spr.visible = false;
            }
        }
    }
    if (m_nAniLine == -2) {
        if( m_bBonus == false)
            m_nAniLine = -1;
        else
        {
            for (NSAniLine* aniline in m_arrLines) {
                if (aniline == m_lineScatter)
                    aniline->spr.visible = true;
                else
                    aniline->spr.visible = false;
            }
        }
    }

    if (m_nAniLine == -1) {
        for (NSAniLine* aniline in m_arrLines) {
            aniline->spr.visible = true;
        }
    }
    else {
        if (m_nAniLine < 0 || m_nAniLine >= [m_arrLines count]) {
            NSLog(@"Error AniLineNumber: AnilineCount = %d AnilineID = %d ", [m_arrLines count], m_nAniLine);
        }
        NSAniLine* curAniLine = [m_arrLines objectAtIndex:m_nAniLine];
        for (NSAniLine* aniline in m_arrLines) {
            if (aniline == curAniLine)
                aniline->spr.visible = true;
            else
                aniline->spr.visible = false;
        }
    }
}

-(void) draw
{
    bool bShowed[COLUMN][ROW];
    int column,row;
    for (column = 0; column < COLUMN; column++) {
        for (row = 0; row < COLUMN; row++) {
            bShowed[column][row] = false;
        }
    }
    if (m_bAni == false) {
        return;
    }
    if (m_nAniLine == -3)
    {
        NSAniLine* aniLine = m_lineBonus;
        
        float alpha = 0;
        if ( m_fFlashTime < ANI_TIME_PER_FLASH / 2)
        {
            alpha = m_fFlashTime / (ANI_TIME_PER_FLASH / 2) * 255;
        }
        else {
            alpha = (ANI_TIME_PER_LINE - m_fFlashTime) / (ANI_TIME_PER_FLASH / 2) * 255;
        }
        [aniLine->spr setOpacity:alpha];
        
        int nSquareID = ((int)(m_fFlashTime / (ANI_TIME_PER_LINE / 8))) % SQUARE_ANI_COUNT;
        
        int nID = 0;
        CCSprite* spr = nil;
        for (NSAniCard* card in aniLine->m_arrCards) {
            switch (card->m_nCardID) {
                case BONUS_CARD:
                    nID = m_fFlashTime / (ANI_TIME_PER_FLASH / BONUS_ANI_COUNT);
                    spr = (CCSprite*)[m_arrBonusSprites objectAtIndex:nID];
                    spr.position = card->pt;
                    break;
                case SCATTER_CARD:
                    nID = m_fFlashTime / (ANI_TIME_PER_FLASH / SCATTER_ANI_COUNT);
                    spr = (CCSprite*)[m_arrScatterSprites objectAtIndex:nID];
                    spr.position = card->pt;
                    break;
                case WILD_CARD:
                    nID = m_fFlashTime / (ANI_TIME_PER_FLASH / WILD_ANI_COUNT);
                    spr = (CCSprite*)[m_arrWildSprites objectAtIndex:nID];
                    spr.position = card->pt;
                    break;
                default:
                    spr = card->spr;
                    spr.position = card->pt;
                    break;
            }
            [spr visit];
            bShowed[card->m_nColumn][card->m_nRow] = true;
            
            m_sprSquare[aniLine->nLineID].position = card->pt;
            m_sprSquare[aniLine->nLineID].opacity = 255;
            [m_sprSquare[aniLine->nLineID] visit];
            
            spr = [m_arrSquareSprites objectAtIndex:nSquareID];
            spr.position = card->pt;
            [spr visit];
        }

    }
    else if(m_nAniLine == -2)
    {
        NSAniLine* aniLine = m_lineScatter;

        int nSquareID = ((int)(m_fFlashTime / (ANI_TIME_PER_LINE / 8))) % SQUARE_ANI_COUNT;
        
        int nID = 0;
        CCSprite* spr = nil;
        for (NSAniCard* card in aniLine->m_arrCards) {
            switch (card->m_nCardID) {
                case BONUS_CARD:
                    nID = m_fFlashTime / (ANI_TIME_PER_FLASH / BONUS_ANI_COUNT);
                    spr = (CCSprite*)[m_arrBonusSprites objectAtIndex:nID];
                    spr.position = card->pt;
                    break;
                case SCATTER_CARD:
                    nID = m_fFlashTime / (ANI_TIME_PER_FLASH / SCATTER_ANI_COUNT);
                    spr = (CCSprite*)[m_arrScatterSprites objectAtIndex:nID];
                    spr.position = card->pt;
                    break;
                case WILD_CARD:
                    nID = m_fFlashTime / (ANI_TIME_PER_FLASH / WILD_ANI_COUNT);
                    spr = (CCSprite*)[m_arrWildSprites objectAtIndex:nID];
                    spr.position = card->pt;
                    break;
                default:
                    spr = card->spr;
                    spr.position = card->pt;
                    break;
            }
            [spr visit];
            bShowed[card->m_nColumn][card->m_nRow] = true;
            
            m_sprSquare[aniLine->nLineID].position = card->pt;
            m_sprSquare[aniLine->nLineID].opacity = 255;
            [m_sprSquare[aniLine->nLineID] visit];
            
            spr = [m_arrSquareSprites objectAtIndex:nSquareID];
            spr.position = card->pt;
            [spr visit];
        }
    }
    else if (m_nAniLine != -1) {
        NSAniLine* aniLine = [m_arrLines objectAtIndex:m_nAniLine];

        float alpha = 0;
        if ( m_fFlashTime < ANI_TIME_PER_FLASH / 2)
        {
            alpha = m_fFlashTime / (ANI_TIME_PER_FLASH / 2) * 255;
        }
        else {
            alpha = (ANI_TIME_PER_LINE - m_fFlashTime) / (ANI_TIME_PER_FLASH / 2) * 255;
        }
        [aniLine->spr setOpacity:alpha];
        
        int nSquareID = ((int)(m_fFlashTime / (ANI_TIME_PER_LINE / 8))) % SQUARE_ANI_COUNT;
        
        int nID = 0;
        CCSprite* spr = nil;
        for (NSAniCard* card in aniLine->m_arrCards) {
            switch (card->m_nCardID) {
                case BONUS_CARD:
                    nID = m_fFlashTime / (ANI_TIME_PER_FLASH / BONUS_ANI_COUNT);
                    spr = (CCSprite*)[m_arrBonusSprites objectAtIndex:nID];
                    spr.position = card->pt;
                    break;
                case SCATTER_CARD:
                    nID = m_fFlashTime / (ANI_TIME_PER_FLASH / SCATTER_ANI_COUNT);
                    spr = (CCSprite*)[m_arrScatterSprites objectAtIndex:nID];
                    spr.position = card->pt;
                    break;
                case WILD_CARD:
                    nID = m_fFlashTime / (ANI_TIME_PER_FLASH / WILD_ANI_COUNT);
                    spr = (CCSprite*)[m_arrWildSprites objectAtIndex:nID];
                    spr.position = card->pt;
                    break;
                default:
                    spr = card->spr;
                    spr.position = card->pt;
                    break;
            }
            [spr visit];
            bShowed[card->m_nColumn][card->m_nRow] = true;

            m_sprSquare[aniLine->nLineID].position = card->pt;
            m_sprSquare[aniLine->nLineID].opacity = 255;
            [m_sprSquare[aniLine->nLineID] visit];
            
            spr = [m_arrSquareSprites objectAtIndex:nSquareID];
            spr.position = card->pt;
            [spr visit];
        }
    }
    else {
        for (int i = 0 ; i < [m_arrLines count]; i++) {
            NSAniLine* aniLine = [m_arrLines objectAtIndex:i];

            float alpha = 0;
            if ( m_fFlashTime < ANI_TIME_PER_FLASH / 2)
            {
                alpha = m_fFlashTime / (ANI_TIME_PER_FLASH / 2) * 255;
            }
            else {
                alpha = (ANI_TIME_PER_LINE - m_fFlashTime) / (ANI_TIME_PER_FLASH / 2) * 255;
            }
            [aniLine->spr setOpacity:alpha];
        }
    }
    
    //draw remove remain cards
    for (NSAniLine* aniline in m_arrLines) {
        for (NSAniCard* anicard in aniline->m_arrCards) {
            if (bShowed[anicard->m_nColumn][anicard->m_nRow] == false) {
                bShowed[anicard->m_nColumn][anicard->m_nRow] = true;
                anicard->spr.position = anicard->pt;
                [anicard->spr visit];
            }
        }
    }
}
-(void) dealloc

{
    [m_arrLines release];

    [m_arrBonusSprites release];
    [m_arrScatterSprites release];
    [m_arrWildSprites release];
    [m_arrSquareSprites release];

    [super dealloc];
}
@end
