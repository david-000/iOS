//
//  BonusLayer.m
//  Slots-O-Luck-Adventure
//
//  Created by osone on 5/19/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "BonusLayer.h"


@implementation BonusLayer

@end
