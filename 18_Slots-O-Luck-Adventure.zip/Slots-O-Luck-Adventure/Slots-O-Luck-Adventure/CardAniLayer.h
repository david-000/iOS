//
//  CardAniLayer.h
//  Slots-O-Luck-Adventure
//
//  Created by osone on 5/16/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameLayer1.h"

#define ANI_TIME_PER_LINE  4.0f
#define ANI_TIME_PER_FLASH 1.0f

@interface NSAniCard : NSObject
{
@public
    CCSprite*   spr;
    CGPoint     pt;
    float       m_fAniTime;
    int         m_nCardID;
    
    int         m_nColumn;
    int         m_nRow;
}
@end

@interface NSAniLine : NSObject
{
@public
    int nLineID;
    CCSprite* spr;
    NSMutableArray* m_arrCards;
}

@end

enum SpecialLineID
{
    Line_Scatter = -3,
    Line_Bouns = -2,
};
@interface CardAniLayer : CCLayer {
@public
    GameLayer1*     m_pParent;
    NSMutableArray* m_arrBonusSprites;
    NSMutableArray* m_arrScatterSprites;
    NSMutableArray* m_arrWildSprites;
    NSMutableArray* m_arrSquareSprites;
    NSMutableArray* m_arrLines;
    
    CCSprite*       m_sprSquare[MAX_LINES];
    float           m_fTotalTime;
    float           m_fAniTime;
    float           m_fFlashTime;
    int             m_nAniLine;

    bool            m_bAni;
    
    bool            m_bAniSprite[COLUMN][ROW];
    
    bool            m_bBonus;
    NSAniLine*      m_lineBonus;
    
    bool            m_bScatter;
    NSAniLine*      m_lineScatter;
}

-(id) initWithParam :(GameLayer1*)pParent;
-(void) addCard : (CCSprite*) card pos:(CGPoint)pos nLine:(int)nLine nCardID:(int)nCardID nColumn:(int)nColumn nRow:(int)nRow;
-(bool) addLine :(CCSprite*)spr nLineID:(int)nLineID;

-(void) addScatter;
-(void) addBonus:(int)nLineID spr:(CCSprite*)spr;

-(void) start;
-(void) stop;
-(void) clear;
@end
