//
//  HelloWorldLayer.h
//  Slots-O-Luck-Adventure
//
//  Created by osone on 5/10/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//


#import <GameKit/GameKit.h>

// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"
#import "ScaleLayer.h"
#import "BonusLayer.h"

#define CARD_COUNT      13
#define MAX_SAME_CARD_COUNT 5

#define LOW_CARD_COUNT  5
#define HIGH_CARD_COUNT 5

#define BONUS_CARD      10
#define SCATTER_CARD    11
#define WILD_CARD       12


#define ROW        5
#define COLUMN     3
#define FLOWCOLUMN 20

#define MAX_LINES  25
// HelloWorldLayer

enum GameState {
    stateFree,
    stateLine,
    stateAni,
    };

@class CardAniLayer;
@interface GameLayer1: ScaleLayer <GKAchievementViewControllerDelegate, GKLeaderboardViewControllerDelegate>
{
@public
    CardAniLayer*   m_pCardAniLayer;
    BonusLayer*     m_pBonusLayer;
    
    CCSprite*   m_sprTitle;
    CCSprite*   m_sprFreeSpin;
    CCLabelTTF* m_labelFreeSpinCount;
    
    CCSprite*   m_sprCards[CARD_COUNT];
    CCSprite*   m_sprLines[MAX_LINES];
    
    int         m_nCard[COLUMN][ROW];
    int         m_nFlowCard[FLOWCOLUMN][ROW];
    float       m_fAniTime;
    bool        m_bAni;
    
    CCMenuItem* m_btnSpin;
    CCMenuItem* m_btnMaxLines;

    CCMenuItem* m_btnBetPrev;
    CCMenuItem* m_btnBetNext;

    CCMenuItem* m_btnLinesPrev;
    CCMenuItem* m_btnLinesNext;
    
    CCMenuItem* m_btnPayTable;
    
    CCMenuItemImage* m_btnLine[2][MAX_LINES];
    
    CCLabelTTF* m_labelBalance;
    CCLabelTTF* m_labelLines;
    CCLabelTTF* m_labelBet;
    CCLabelTTF* m_labelTotalBet;
    CCLabelTTF* m_labelWin;
    
    int         m_nLevelMaxLines;

    int         m_nBalance;
    int         m_nLines;
    int         m_nBet;
    int         m_nTotalBet;
    int         m_nWin;
    
    int         m_nLineInfo[MAX_LINES][ROW];

    int         m_nSuccessLineInfoCount;
    int         m_nSuccessLineInfo[MAX_LINES];
    
    int         m_nFreeSpinCount;
    
    int         m_nScoreMulti[CARD_COUNT][MAX_SAME_CARD_COUNT];
    
    bool        m_bBonusGame;
    bool        m_nBonusCardCount;
    
    int         m_nCardGenerationRatio[CARD_COUNT];
    int         m_nGenerationTotal;
    
    int         m_fLineAniTime;
    int         m_nAniLine;
    
    NSArray*    m_arrAniCards;
    
    int         m_bEnable;
    
}

// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;

-(void) initImages;
-(void) initButtons;
-(void) initLabels;
-(void) initVariables;

-(void) onSpin ;
-(void) onMaxLines;

-(void) spin:(int)nTotalBet;

-(void) onBetPrev;
-(void) onBetNext;
-(void) onLinesPrev;
-(void) onLinesNext;

-(void) onPayTable;

-(void) onLine:(id)sender;

-(void) setLineCount:(int)nLineCount;
-(void) setBetValue:(int)nBetValue;

-(void) makeFlow;

-(void) checkSuccessLines;
-(int) checkBonus:(int*)nCards;
-(int) checkLine:(int*)nCards;
-(void) checkLineButtons:(int)nLineCount;
-(int) countScatter;

-(void) checkLabels;
-(int) getRandCard;

-(void) setEnable:(bool)bEnable;

-(void) playCardAnimations:(int)nAniLine fAniTime:(float)fAniTime;
-(void) playCardAnimation:(CCSprite*)spr fAniTime:(float)fAniTime;
-(void) getSameCard:(int)nCount rows:(int)nLineID nCards:(bool *)nCards;
-(void) getScatterCards:(int)nCount rows:(int*)rows columns:(int*)columns;

@end
