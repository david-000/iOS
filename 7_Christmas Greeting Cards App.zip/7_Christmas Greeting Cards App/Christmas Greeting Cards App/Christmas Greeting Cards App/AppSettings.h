//
//  AppSetting.h
//  fruitGame
//
//  Created by KCU on 5/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface AppSettings : NSObject 
{

}

+ (void) defineUserDefaults;

+ (BOOL) getBuyFlag;
+ (void) setBuyFlag:(BOOL) flag;
+ (int) getSendTime;
+ (void) setSendMinusTime;

@end
