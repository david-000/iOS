//
//  TypeMessageViewController.m
//  Christmas Greeting Cards
//
//  Created by GwangHe Quan on 4/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TypeMessageViewController.h"

#import "IFNNotificationDisplay.h"
#import "Twitter/Twitter.h"
#import "AppDelegate.h"
#import "AppSettings.h"

@implementation TypeMessageViewController

@synthesize imgCard;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        //        imgCard = [[[UIImage alloc] init] autorelease];
    }
    return self;
}

- (void)dealloc
{
    [messageView release];
    [cardImageView release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
 // Implement loadView to create a view hierarchy programmatically, without using a nib.
 - (void)loadView
 {
 }
 */

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    messageView.delegate = self;
    messageView.text = @"";
    
    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Send" style:UIBarButtonItemStyleDone target:self action:@selector(send:)] autorelease];
    
    [cardImageView setImage:imgCard];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(doneEditing:)] autorelease];
}

- (void)doneEditing:(id)sender
{
    [messageView resignFirstResponder];
    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Send" style:UIBarButtonItemStylePlain target:self action:@selector(send:)] autorelease];
}

- (BOOL)textViewShouldEndEditing:(UITextView *)textView
{
    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Send" style:UIBarButtonItemStylePlain target:self action:@selector(send:)] autorelease];
    return YES;
}

- (void)send:(id)sender
{
    UIActionSheet *menu = [[UIActionSheet alloc] 
						   initWithTitle: @"File Management" 
						   delegate:self
						   cancelButtonTitle:@"Cancel"
						   destructiveButtonTitle:@"Send To Email"
						   otherButtonTitles:@"Share on Facebook", @"Tweet on Twitter", nil];
	[menu showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (![AppDelegate connectedToNetwork]) {
        NSLog(@"network failed");
        [self showMessage:@"Network Failed"];
    } else {
        //        if (![AppSettings getBuyFlag]) {
        //            if ([AppSettings getSendTime] > 0)
        //                [AppSettings setSendMinusTime];
        //            else {
        //                UIAlertView *tmp = [[[UIAlertView alloc] initWithTitle:@"Ooooooo Ooooooo !" message:@"Oh no! Santa's Free Trial Cards Already Expired. Go Pro Now." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
        //                [tmp show];
        //                [tmp release];
        //                return;
        //            }
        //        }      
        
        if (buttonIndex == 0) {
            [self emailImage:[NSArray arrayWithObjects:nil]: imgCard: messageView.text];
        } else if (buttonIndex == 1) {
            // facebook
            [self sendToFacebook];
        } else if (buttonIndex == 2) {
            // twitter
            [self sendToTwitter];
        }
    }
    
	[actionSheet release];
}

- (void)emailImage:(NSArray *)addressArray:(UIImage *)image:(NSString *)message;
{
    MFMailComposeViewController *pickerMail = [[MFMailComposeViewController alloc] init];
    pickerMail.mailComposeDelegate = self;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd MMM yyyy"];
    
    NSDateFormatter *timeFormatter = [[NSDateFormatter alloc] init];
    [timeFormatter setDateFormat:@"HH:mm:ss"];
    
    NSDate *now = [[NSDate alloc] init];
    
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [dateFormatter setLocale:usLocale];
    
    NSString* str_date = [dateFormatter stringFromDate:now];
    NSString* str_time = [timeFormatter stringFromDate:now];
    
    [dateFormatter release];
    [timeFormatter release];
    [now release];
    [usLocale release];
    
    NSString* strDate = [NSString stringWithFormat:@"Christmas Greeting Cards: %@ %@", str_date, str_time];
    
    [pickerMail setSubject:strDate];
    
    [pickerMail setToRecipients:addressArray];
    [pickerMail setMessageBody:message isHTML:NO];
    NSData *data = UIImagePNGRepresentation(image);
    [pickerMail addAttachmentData:data mimeType:@"image/gif" fileName:@"Christmas Greeting Cards image"];
    [self presentModalViewController:pickerMail animated:YES];
    [pickerMail release];
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error 
{
    if (result == MFMailComposeResultCancelled) {
        NSLog(@"email cancelled");
        [self showMessage:@"Email cancelled"];
    } else if (result == MFMailComposeResultSaved) {
        NSLog(@"email saved");
        [self showMessage:@"Email saved"];
    } else if (result == MFMailComposeResultSent) {
        NSLog(@"email sent");
        [self showMessage:@"Email sent"];
    } else if (result == MFMailComposeResultFailed) {
        NSLog(@"email failed");
        [self showMessage:@"Email failed"];
    }
    
    [self dismissModalViewControllerAnimated:YES];
}

- (void)showMessage:(NSString *)message
{
    IFNNotificationDisplay *display = [[IFNNotificationDisplay alloc] init];
	display.type = NotificationDisplayTypeText;
	[display setNotificationText:message];
	[display displayInView:self.view atCenter:CGPointMake(self.view.center.x, self.view.center.y-100.0) withInterval:1.5];
	[display release];
}



- (void) sendToFacebook
{
    UIImage *imgData = imgCard;
    NSString *message = messageView.text;
    
    //we will release this object when it is finished posting
	FBFeedPost *post = [[FBFeedPost alloc] initWithPhoto:imgData name:message];
    post.delegate = self;
	[post publishPostWithDelegate:self];
	
	IFNNotificationDisplay *display = [[IFNNotificationDisplay alloc] init];
	display.type = NotificationDisplayTypeLoading;
	display.tag = NOTIFICATION_DISPLAY_TAG;
	[display setNotificationText:@"Posting Photo..."];
	[display displayInView:self.view atCenter:CGPointMake(self.view.center.x, self.view.center.y-100.0) withInterval:0.0];
	[display release];
    
    [self startTimer];
}

- (void)startTimer
{
    timerGame = [NSTimer scheduledTimerWithTimeInterval:60.0f target:self selector:@selector(performTimer:) userInfo:nil repeats:YES];
}

- (void)performTimer: (NSTimer *)timer
{
    UIView *dv = [self.view viewWithTag:NOTIFICATION_DISPLAY_TAG];
    if (dv) {
        [dv removeFromSuperview];
        [timerGame invalidate];
        timerGame = nil;
    }
}

- (void)sendToTwitter
{
    UIImage *imgData = imgCard;
    NSString *message = messageView.text;
    
    TWTweetComposeViewController *twitter = [[TWTweetComposeViewController alloc] init];
    [twitter addImage:imgData];
    [twitter setTitle:@"Christmas Greeting Cards"];
    [twitter setInitialText:message];
    [self presentModalViewController:twitter animated:NO];
    
    twitter.completionHandler = ^(TWTweetComposeViewControllerResult result) 
    {
        [self dismissModalViewControllerAnimated:YES];
    };
    
    TWTweetComposeViewControllerCompletionHandler 
    completionHandler =
    ^(TWTweetComposeViewControllerResult result) {
        switch (result)
        {
            case TWTweetComposeViewControllerResultCancelled:
                NSLog(@"Twitter Result: canceled");
                break;
            case TWTweetComposeViewControllerResultDone:
                NSLog(@"Twitter Result: sent");
                break;
            default:
                NSLog(@"Twitter Result: default");
                break;
        }
        [self dismissModalViewControllerAnimated:YES];
    };
    [twitter setCompletionHandler:completionHandler];
}

#pragma mark -
#pragma mark FBFeedPostDelegate

- (void) failedToPublishPost:(FBFeedPost*) _post {
    
	UIView *dv = [self.view viewWithTag:NOTIFICATION_DISPLAY_TAG];
    if (dv) {
        [dv removeFromSuperview];
        [timerGame invalidate];
        timerGame = nil;
    }
	
	IFNNotificationDisplay *display = [[IFNNotificationDisplay alloc] init];
	display.type = NotificationDisplayTypeText;
	[display setNotificationText:@"Failed To Post"];
	[display displayInView:self.view atCenter:CGPointMake(self.view.center.x, self.view.center.y-100.0) withInterval:1.5];
	[display release];
	
	//release the alloc'd post
	[_post release];
}

- (void) finishedPublishingPost:(FBFeedPost*) _post {
    
	UIView *dv = [self.view viewWithTag:NOTIFICATION_DISPLAY_TAG];
    if (dv) {
        [dv removeFromSuperview];
        [timerGame invalidate];
        timerGame = nil;
    }
	
	IFNNotificationDisplay *display = [[IFNNotificationDisplay alloc] init];
	display.type = NotificationDisplayTypeText;
	[display setNotificationText:@"Finished Posting"];
	[display displayInView:self.view atCenter:CGPointMake(self.view.center.x, self.view.center.y-100.0) withInterval:1.5];
	[display release];
	
	//release the alloc'd post
	[_post release];
}

@end