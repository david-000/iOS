//
//  ViewController.m
//  Christmas Cards App Download For Free
//
//  Created by GwangHe Quan on 11/21/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

#import "TypeMessageViewController.h"
#import "AppSettings.h"
#import "AppDelegate.h"

#define kProductId  @"com.christmasgreetingcardsapp.coin"
#define AlertTag    1
#define InAppTag    2
//#define PageCount   23

@implementation ViewController

@synthesize contentView = _contentView;
@synthesize adBannerView = _adBannerView;
@synthesize adBannerViewIsVisible = _adBannerViewIsVisible;

- (void)dealloc
{
    self.contentView = nil;
    self.adBannerView = nil;
    
    [cardScrollView release];
//    [urlString release];
//    [effect release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

//- (void) effect_Play
//{
//    if (effect != nil)
//    {
//        if ([effect isPlaying])
//            [effect stop];
//        [effect release];
//        effect = nil;
//    }
//    
//    NSURL* audioUrl = [[NSBundle mainBundle] URLForResource:@"background Melody" withExtension:@"MP3"];
//    effect = [[AVAudioPlayer alloc] initWithContentsOfURL:audioUrl error:nil];
//    effect.volume = 10.0;
//    effect.delegate = self;
//    if ([effect prepareToPlay])
//        [effect play];
//}
//
//- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
//{
//    [self effect_Play];
//}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        PHOTO_WIDTH = 150;
        PHOTO_HEIGHT = 100;
        UNLOCK_WIDTH = 50;
        UNLOCK_HEIGHT = 69;
        PAGE_COUNT = 23;
        PHOTO_ROW_COUNT = 2;
        PAGE_CARD_COUNT = 6;
    } else {
        PHOTO_WIDTH = 242;
        PHOTO_HEIGHT = 160;
        UNLOCK_WIDTH = 80;
        UNLOCK_HEIGHT = 100;
        PAGE_COUNT = 9;
        PHOTO_ROW_COUNT = 3;
        PAGE_CARD_COUNT = 15;
    }
    
    cardScrollView.pagingEnabled = NO;
    cardScrollView.contentSize = CGSizeMake(cardScrollView.frame.size.width * PAGE_COUNT, cardScrollView.frame.size.height);
    cardScrollView.showsHorizontalScrollIndicator = NO;
    cardScrollView.showsVerticalScrollIndicator = NO;
    cardScrollView.scrollsToTop = NO;
    cardScrollView.delegate = self;
    cardScrollView.decelerationRate = UIScrollViewDecelerationRateNormal;
    cardScrollView.decelerationRate = UIScrollViewDecelerationRateFast;
    
    
    cardScrollView.contentSize = CGSizeMake(SCREEN_WIDTH * PAGE_COUNT, (PHOTO_HEIGHT + 10) * 3);
    cardScrollView.backgroundColor = [UIColor clearColor];
    
//    urlString = [[NSString alloc] init];
    
    BOOL isBuyCarded = [AppSettings getBuyFlag];
    if (!isBuyCarded) [self createAdBannerView];
    
    [self loadScrollViewWithPage:0];
    [self loadScrollViewWithPage:1];
    
//    btnPlay = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"mute.png"] style:UIBarButtonItemStylePlain target:self action:@selector(playMusic:)];
//    btnMute = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"speaker.png"] style:UIBarButtonItemStylePlain target:self action:@selector(stopMusic:)];
//    
//    self.navigationItem.rightBarButtonItem = btnMute;
//    [self effect_Play];
}

//- (void)playMusic:(id)sender
//{
//    [self effect_Play];
//    
//    self.navigationItem.rightBarButtonItem = btnMute;
//}
//
//- (void)stopMusic:(id)sender
//{
//    if (effect != nil)
//    {
//        if ([effect isPlaying])
//            [effect stop];
//        [effect release];
//        effect = nil;
//    }
//    
//    self.navigationItem.rightBarButtonItem = btnPlay;
//}


- (NSString *)getCardName:(int) cardNumber
{
    if (cardNumber < 0)
        return @"";
    else if (cardNumber > CARD_COUNT)
        return @"";
    else if (cardNumber < 10) 
        return [NSString stringWithFormat:@"card_00%d.gif", cardNumber];
    else if (cardNumber < 100)
        return [NSString stringWithFormat:@"card_0%d.gif", cardNumber];
    else
        return [NSString stringWithFormat:@"card_%d.gif", cardNumber];
}

- (void)loadScrollViewWithPage:(int)page 
{
    if (page < 0) return;
    if (page >= PAGE_COUNT) return;

    UIButton *thumbNailButton;
    UIImageView *imvUnlock;
    UIImage *imgUnlock = [UIImage imageNamed:@"btn_unlock.png"];
    CGRect unlockRect = CGRectMake((PHOTO_WIDTH - UNLOCK_WIDTH) / 2, (PHOTO_HEIGHT - UNLOCK_HEIGHT) / 2, UNLOCK_WIDTH, UNLOCK_HEIGHT);
    
    int cardNumber;
    BOOL isBuyCarded = [AppSettings getBuyFlag];
    
    for (int i = 0; i < PAGE_CARD_COUNT; i++) {
        cardNumber = page * PAGE_CARD_COUNT + i;
        if (cardNumber >= CARD_COUNT)
            return;
        
        thumbNailButton = [UIButton buttonWithType:UIButtonTypeCustom];
        thumbNailButton.frame = CGRectMake(SCREEN_WIDTH * page + 5 + (PHOTO_WIDTH + 10) * (i % PHOTO_ROW_COUNT), 10 + (PHOTO_HEIGHT + 10) * (i / PHOTO_ROW_COUNT), PHOTO_WIDTH, PHOTO_HEIGHT);            
        thumbNailButton.tag = cardNumber;
        [thumbNailButton addTarget:self action:@selector(imageClicked:) forControlEvents:UIControlEventTouchUpInside];
        [thumbNailButton setImage:[UIImage imageNamed:[self getCardName:cardNumber + 1]] forState:UIControlStateNormal];
        [cardScrollView addSubview:thumbNailButton];
        
        if (cardNumber >= FREE_CARD_COUNT && !isBuyCarded) {
            imvUnlock = [[UIImageView alloc] initWithImage:imgUnlock];
            [imvUnlock setFrame:CGRectMake(thumbNailButton.frame.origin.x + unlockRect.origin.x, thumbNailButton.frame.origin.y + unlockRect.origin.y, UNLOCK_WIDTH, UNLOCK_HEIGHT)];
            imvUnlock.tag = 1000 + cardNumber;
            [cardScrollView addSubview:imvUnlock];
        }
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)sender {
    // We don't want a "feedback loop" between the UIPageControl and the scroll delegate in
    // which a scroll event generated from the user hitting the page control triggers updates from
    // the delegate method. We use a boolean to disable the delegate logic when the page control is used.
    if (pageControlUsed) {
        // do nothing - the scroll was initiated from the page control, not the user dragging
        return;
    }
	
    // Switch the indicator when more than 50% of the previous/next page is visible
    CGFloat pageWidth = cardScrollView.frame.size.width;
    int page = floor((cardScrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
//    pageControl.currentPage = page;
	
    // load the visible page and the page on either side of it (to avoid flashes when the user starts scrolling)
    for (UIView *view in [cardScrollView subviews]) {
        [view removeFromSuperview];
//        [view release];
    }
    
    [self loadScrollViewWithPage:page - 1];
    [self loadScrollViewWithPage:page];
    [self loadScrollViewWithPage:page + 1];
	
    // A possible optimization would be to unload the views+controllers which are no longer visible
}

// At the begin of scroll dragging, reset the boolean used when scrolls originate from the UIPageControl
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    pageControlUsed = NO;
}

// At the end of scroll animation, reset the boolean used when scrolls originate from the UIPageControl
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    pageControlUsed = NO;
}

-(void)imageClicked:(id)sender {
    BOOL isBuyCarded = [AppSettings getBuyFlag];
    int cardNumber = ((UIButton *)sender).tag;
    
    if (!isBuyCarded &&  cardNumber> FREE_CARD_COUNT - 1) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Ho!Ho!Ho! Merry Christmas!" message:@"Do you want to unlock all cards?" delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
        alert.tag = AlertTag;
        [alert show];
    } else {
        TypeMessageViewController *viewController;
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
            viewController = [[[TypeMessageViewController alloc] initWithNibName:@"TypeMessageViewController_iPhone" bundle:nil] autorelease];
        else
            viewController = [[[TypeMessageViewController alloc] initWithNibName:@"TypeMessageViewController_iPad" bundle:nil] autorelease];
        
        viewController.title = @"Type Message";
        viewController.imgCard = ((UIButton *)sender).imageView.image;
        [self.navigationController pushViewController:viewController animated:YES];
        
//        if (effect != nil)
//        {
//            if ([effect isPlaying])
//                [effect stop];
//            [effect release];
//            effect = nil;
//        }
//        
//        self.navigationItem.rightBarButtonItem = btnPlay;
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.title = @"Christmas Cards";
    [self fixupAdView:(UIInterfaceOrientation)[UIDevice currentDevice].orientation];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
}

- (int)getBannerHeight:(UIDeviceOrientation)orientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
        return 66;
    else {
        if (UIInterfaceOrientationIsLandscape(orientation))
            return 32;
        else
            return 50;
    }
}

- (int)getBannerHeight
{
    return [self getBannerHeight:[UIDevice currentDevice].orientation];
}

- (void)createAdBannerView
{
    Class classAdBannerView = NSClassFromString(@"ADBannerView");
    if (classAdBannerView != nil) {
        self.adBannerView = [[[classAdBannerView alloc] 
                              initWithFrame:CGRectZero] autorelease];
        [_adBannerView setRequiredContentSizeIdentifiers:[NSSet setWithObjects: 
                                                          ADBannerContentSizeIdentifierLandscape, 
                                                          ADBannerContentSizeIdentifierPortrait, nil]];
        if (UIInterfaceOrientationIsLandscape([UIDevice currentDevice].orientation)) {
            [_adBannerView setCurrentContentSizeIdentifier:
             ADBannerContentSizeIdentifierLandscape];
        } else {
            [_adBannerView setCurrentContentSizeIdentifier:
             ADBannerContentSizeIdentifierPortrait];            
        }
        [_adBannerView setFrame:CGRectOffset([_adBannerView frame], 0, -[self getBannerHeight])];
        [_adBannerView setDelegate:self];
        [self.view addSubview:_adBannerView];    
    }
}

- (void)fixupAdView:(UIInterfaceOrientation)toInterfaceOrientation 
{
    if (_adBannerView != nil) {        
        if (UIInterfaceOrientationIsLandscape(toInterfaceOrientation)) {
            [_adBannerView setCurrentContentSizeIdentifier:
             ADBannerContentSizeIdentifierLandscape];
        } else {
            [_adBannerView setCurrentContentSizeIdentifier:
             ADBannerContentSizeIdentifierPortrait];
        }          
        [UIView beginAnimations:@"fixupViews" context:nil];
        if (_adBannerViewIsVisible) {
            CGRect adBannerViewFrame = [_adBannerView frame];
            adBannerViewFrame.origin.x = 0;
            adBannerViewFrame.origin.y = SCREEN_HEIGHT - TOP_BAR_HEIGHT - NAV_BAR_HEIGHT - [self getBannerHeight:(UIDeviceOrientation)toInterfaceOrientation];
            [_adBannerView setFrame:adBannerViewFrame];
            CGRect contentViewFrame = _contentView.frame;
            contentViewFrame.origin.y = SCREEN_HEIGHT - TOP_BAR_HEIGHT - NAV_BAR_HEIGHT;
            contentViewFrame.size.height = self.view.frame.size.height - 
            [self getBannerHeight:(UIDeviceOrientation)toInterfaceOrientation];
            _contentView.frame = contentViewFrame;
        } else {
            CGRect adBannerViewFrame = [_adBannerView frame];
            adBannerViewFrame.origin.x = 0;
            adBannerViewFrame.origin.y = SCREEN_HEIGHT - TOP_BAR_HEIGHT - NAV_BAR_HEIGHT;
            [_adBannerView setFrame:adBannerViewFrame];
            CGRect contentViewFrame = _contentView.frame;
            contentViewFrame.origin.y = 0;
            contentViewFrame.size.height = self.view.frame.size.height;
            _contentView.frame = contentViewFrame;          
        }
        
        NSLog(@"%f, %f, %f, %f", _adBannerView.frame.origin.x, _adBannerView.frame.origin.y, _adBannerView.frame.size.width, _adBannerView.frame.size.height);
        [UIView commitAnimations];
    }
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    [self fixupAdView:toInterfaceOrientation];
}

#pragma mark ADBannerViewDelegate

- (void)bannerViewDidLoadAd:(ADBannerView *)banner 
{
    if (!_adBannerViewIsVisible) {      
        _adBannerViewIsVisible = YES;
        [self fixupAdView:(UIInterfaceOrientation)[UIDevice currentDevice].orientation];
    }
}

- (void)bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error
{
    if (_adBannerViewIsVisible) {
        [self fixupAdView:(UIInterfaceOrientation)[UIDevice currentDevice].orientation];
        
        [UIView beginAnimations:@"animateBannerOffset" context:NULL];
        banner.frame = CGRectOffset(banner.frame, 0, -50);
        [UIView commitAnimations];
        _adBannerViewIsVisible = NO;
    }
}

#pragma mark StoreKit Delegate

-(void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions {
    for (SKPaymentTransaction *transaction in transactions) {
        switch (transaction.transactionState) {
            case SKPaymentTransactionStatePurchasing:
                
                // show wait view here
                NSLog(@"Processing...");
                break;
                
            case SKPaymentTransactionStatePurchased:
                
                [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
                // remove wait view and unlock feature 2
                NSLog(@"Done!");
                
                [AppSettings setBuyFlag:YES];
                
                [_adBannerView removeFromSuperview];
                
                for (UIView *subView in [cardScrollView subviews]) {
                    if ([subView isKindOfClass:[UIImageView class]] && subView.tag > 1000) {
                        [subView removeFromSuperview];
                    }
                }
                // do other thing to enable the features
                
                break;
                
            case SKPaymentTransactionStateRestored:
                [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
                // remove wait view here
                break;
                
            case SKPaymentTransactionStateFailed:
                
                if (transaction.error.code != SKErrorPaymentCancelled) {
                    NSLog(@"Error payment cancelled");
                }
                [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
                
                UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Error!" 
                                                                 message:transaction.error.localizedDescription 
                                                                delegate:nil 
                                                       cancelButtonTitle:nil 
                                                       otherButtonTitles:@"OK", nil] autorelease];
                
                [alert show];
                
                // remove wait view here
                NSLog(@"Purchase Error!");
                break;
                
            default:
                break;
        }
    }
}

-(void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response  
{      
    SKProduct *validProduct = nil;
    int count = [response.products count];
    
    if (count>0) {
        validProduct = [response.products objectAtIndex:0];
        
        SKPayment *payment = [SKPayment paymentWithProductIdentifier:kProductId];
        [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
        [[SKPaymentQueue defaultQueue] addPayment:payment];
        
        
    } else {
        UIAlertView *tmp = [[UIAlertView alloc] 
                            initWithTitle:@"Not Available" 
                            message:@"No products to purchase"
                            delegate:self 
                            cancelButtonTitle:nil 
                            otherButtonTitles:@"Ok", nil]; 
        [tmp show];
        [tmp release];
    }
}  

-(void)requestDidFinish:(SKRequest *)request  
{  
    [request release];  
}  

-(void)request:(SKRequest *)request didFailWithError:(NSError *)error  
{  
    NSLog(@"Failed to connect with error: %@", [error localizedDescription]);  
}  


#pragma mark AlertView Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == AlertTag) {
        [alertView release];

        if (buttonIndex == 1) {
                        
            if (![AppDelegate connectedToNetwork]) {
                NSLog(@"network failed");
                
                
                UIAlertView *tmp = [[UIAlertView alloc] initWithTitle:@"Connection Fail" message:@"Your iPhone/iPad did not connect to internet, so you can not unlock all cards." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [tmp show];

            } else {
                if ([SKPaymentQueue canMakePayments]) { 
                    
                    SKProductsRequest *request = [[SKProductsRequest alloc] initWithProductIdentifiers:[NSSet setWithObject:kProductId]];  
                    
                    request.delegate = self;  
                    [request start];  
                    
                } else {
                    UIAlertView *tmp = [[UIAlertView alloc] 
                                        initWithTitle:@"Prohibited" 
                                        message:@"Parental Control is enabled, cannot make a purchase!"
                                        delegate:self 
                                        cancelButtonTitle:nil 
                                        otherButtonTitles:@"Ok", nil]; 
                    [tmp show];
                }
            }
        }
        return;
    }
    
    [alertView release];
}


@end
