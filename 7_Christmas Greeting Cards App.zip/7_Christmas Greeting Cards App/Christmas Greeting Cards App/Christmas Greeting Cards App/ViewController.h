#import <UIKit/UIKit.h>
#import <StoreKit/StoreKit.h>
#import <AVFoundation/AVFoundation.h>
#import "iAd/ADBannerView.h"
#import "iAd/iAd.h"

@interface ViewController : UIViewController <ADBannerViewDelegate, SKProductsRequestDelegate, SKPaymentTransactionObserver, UIAlertViewDelegate, AVAudioPlayerDelegate, UIScrollViewDelegate> {
    IBOutlet UIScrollView *cardScrollView;
    
    UIView *_contentView;
    ADBannerView *_adBannerView;
    BOOL _adBannerViewIsVisible;
    
//    NSString *urlString;
//    AVAudioPlayer *effect;
    
    BOOL pageControlUsed;
    
    int PAGE_COUNT;
    int PHOTO_WIDTH;
    int PHOTO_HEIGHT;
    int UNLOCK_WIDTH;
    int UNLOCK_HEIGHT;
    int PHOTO_ROW_COUNT;
    int PAGE_CARD_COUNT;
    
    UIBarButtonItem *btnPlay;
    UIBarButtonItem *btnMute;
}

@property (nonatomic, retain) IBOutlet UIView *contentView;
@property (nonatomic, retain) id adBannerView;
@property (nonatomic) BOOL adBannerViewIsVisible;

- (NSString *)getCardName:(int) cardNumber;
- (void)createAdBannerView;
- (void)fixupAdView:(UIInterfaceOrientation)toInterfaceOrientation;
- (int)getBannerHeight;
- (int)getBannerHeight:(UIDeviceOrientation)orientation;

//- (void)effect_Play;
- (void)loadScrollViewWithPage:(int)page;

@end