//
//  FBImageView.h
//  FBP
//
//  Created by David Stanfill on 12/7/10.
//  Copyright 2010 USN. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FBImageView : UIImageView {
	BOOL loading;
	BOOL loaded;
	NSMutableData * data;
	UIImage * placeholder;
	NSString * url;
	NSURLConnection * connection;
}


@property (nonatomic, retain) NSString * url;

@end
