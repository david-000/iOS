#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>
#import "FBFeedPost.h"

@interface TypeMessageViewController : UIViewController <UITextViewDelegate, MFMailComposeViewControllerDelegate, UIActionSheetDelegate, FBFeedPostDelegate> {

    IBOutlet UITextView *messageView;
    IBOutlet UIImageView *cardImageView;
    
    
    NSTimer *timerGame;
}

@property (nonatomic, retain) UIImage *imgCard;

- (void)emailImage:(NSArray *)addressArray:(UIImage *)image:(NSString *)message;
- (void)sendToFacebook;
- (void)sendToTwitter;

- (void)showMessage:(NSString *)message;

- (void)startTimer;

@end