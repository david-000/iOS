//
//  AppSetting.m
//  fruitGame
//
//  Created by KCU on 5/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AppSettings.h"


@implementation AppSettings

+ (void) defineUserDefaults
{
	NSString* userDefaultsValuesPath;
	NSDictionary* userDefaultsValuesDict;
	
	// load the default values for the user defaults
	userDefaultsValuesPath = [[NSBundle mainBundle] pathForResource:@"option" ofType:@"plist"];
	userDefaultsValuesDict = [NSDictionary dictionaryWithContentsOfFile: userDefaultsValuesPath];
	[[NSUserDefaults standardUserDefaults] registerDefaults: userDefaultsValuesDict];
}

+ (BOOL) getBuyFlag
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];	
	return [defaults boolForKey: @"flag_card_buy"];
}

+ (void) setBuyFlag:(BOOL) flag
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSNumber* aFlag  =	[NSNumber numberWithFloat: flag];
	[defaults setObject:aFlag forKey:@"flag_card_buy"];
	[NSUserDefaults resetStandardUserDefaults];
}

+ (int) getSendTime
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];	
	return [defaults integerForKey:@"send_time"];
}

+ (void) setSendMinusTime
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSNumber* aFlag  =	[NSNumber numberWithInt:([AppSettings getSendTime] - 1)];
	[defaults setObject:aFlag forKey:@"send_time"];
	[NSUserDefaults resetStandardUserDefaults];
}

@end
