-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 26, 2011 at 04:32 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `cluiz`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_countries_lite`
-- 

CREATE TABLE `tbl_countries_lite` (
  `name` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  `score` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 
-- Table structure for table `tbl_countries_main`
-- 

CREATE TABLE `tbl_countries_main` (
  `name` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  `score` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Table structure for table `tbl_football_lite`
-- 

CREATE TABLE `tbl_football_lite` (
  `name` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  `score` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 
-- Table structure for table `tbl_football_main`
-- 

CREATE TABLE `tbl_football_main` (
  `name` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  `score` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
