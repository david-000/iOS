//
//  UIViewController_navDelegate.h
//  SlickTime
//
//  Created by Miles Alden on 6/1/11.
//  Copyright 2011 Santa Cruz Singers. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIViewController_navDelegate : UIViewController <UINavigationControllerDelegate> {

}

@end
