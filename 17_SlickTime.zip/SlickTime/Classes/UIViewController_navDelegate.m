//
//  UIViewController_navDelegate.m
//  SlickTime
//
//  Created by Miles Alden on 6/1/11.
//  Copyright 2011 Santa Cruz Singers. All rights reserved.
//

#import "UIViewController_navDelegate.h"


@implementation UIViewController_navDelegate

@end
