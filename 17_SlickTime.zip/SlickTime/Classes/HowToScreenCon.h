//
//  InfoScreenCon.h
//  SlickTime
//
//  Created by Miles Alden on 5/5/11.
//  Copyright 2011 Santa Cruz Singers. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIViewController_navDelegate.h"

@interface HowToScreenCon : UIViewController {

}

@property (nonatomic, assign) BOOL shouldClose;
@property (nonatomic, retain) IBOutlet UIScrollView *vwScroll;


@end
