//
//  BaseViewCon.m
//  SlickTime
//
//  Created by Miles Alden on 5/2/11.
//  Copyright 2011 Santa Cruz Singers. All rights reserved.
//

#import "BaseViewCon.h"



@implementation BaseViewCon




@end
