//
//  InfoScreenCon.h
//  SlickTime
//
//  Created by Optiplex790 on 7/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoScreenCon : UIViewController

- (IBAction)onTapBackButton:(id)sender;


@property (nonatomic, retain) IBOutlet UIScrollView *vwScroll;

@end
