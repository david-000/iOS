//
//  SettingsViewCon.h
//  SlickTime
//
//  Created by Miles Alden on 5/3/11.
//  Copyright 2011 Santa Cruz Singers. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SettingsViewCon : UINavigationController {

}

- (IBAction)buttonPressed;

@end
