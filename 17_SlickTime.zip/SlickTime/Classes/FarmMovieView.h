//
//  FarmMovieView.h
//  SlickTime
//
//  Created by Miles Alden on 6/20/11.
//  Copyright 2011 Santa Cruz Singers. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FarmMovieView : UIView {
    
}

@end
