//
//  ScannerOverlayView.m
//  VSBarcodeReader
//
//  Created by Benoit Maison on 23/02/12.
//  Copyright 2012 Vision Smarts SPRL. All rights reserved.
//

#import "ScannerOverlayView.h"

@implementation ScannerOverlayView

- (void)dealloc {
	if(_redPathToDraw!=NULL) CGPathRelease(_redPathToDraw);
	if(_greenPathToDraw!=NULL) CGPathRelease(_greenPathToDraw);

    [super dealloc];
}

- (void)drawRect:(CGRect)rect {
	CGContextRef context=UIGraphicsGetCurrentContext();
	if(_redPathToDraw!=NULL) {
		CGContextSetLineWidth(context, 4);
		CGContextSetStrokeColorWithColor(context, [[UIColor redColor] CGColor]);
		CGContextAddPath(context, _redPathToDraw);
		CGContextStrokePath(context);
	}
	if(_greenPathToDraw!=NULL) {
		CGContextSetLineWidth(context, 4);
		CGContextSetStrokeColorWithColor(context, [[UIColor greenColor] CGColor]);
		CGContextAddPath(context, _greenPathToDraw);
		CGContextStrokePath(context);
	}
}

-(void) setRedPathToDraw:(CGMutablePathRef) newPath {
	if(_redPathToDraw!=NULL) CGPathRelease(_redPathToDraw);
	_redPathToDraw=newPath;
	[self setNeedsDisplay];
}

-(CGMutablePathRef) redPathToDraw {
    return _redPathToDraw;
}

-(void) setGreenPathToDraw:(CGMutablePathRef) newPath {
	if(_greenPathToDraw!=NULL) CGPathRelease(_greenPathToDraw);
	_greenPathToDraw=newPath;
	[self setNeedsDisplay];
}

-(CGMutablePathRef) greenPathToDraw {
    return _greenPathToDraw;
}


@end
