//
//  VSBarcodeReader.h
//  VSBarcodeReader
//
//  Created by Benoit Maison on 08/10/09.
//  Copyright 2009-2012 Vision Smarts SPRL. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIImage.h>
#import <CoreVideo/CoreVideo.h>

enum VSSymbologies {
	kVSEAN13_UPCA = 0x01,
	kVSEAN8       = 0x02,
	kVSUPCE       = 0x04,
	kVSITF        = 0x08,
	kVSCode39     = 0x10,
	kVSCode128    = 0x20,
	kVSCodabar    = 0x40,
};

@interface VSBarcodeReader : NSObject {
}

@property (assign) BOOL decodeEAN8;
@property (assign) BOOL decodeUPCE;


// initializes the reader
-(id) init;


// reset the reader before reading new code
-(void) reset;


// ** This method is deprecated; 
// ** use -(NSString*) readFromImageBuffer or -(NSString*) readFromImageBufferOmnidirectional 
// ** in new projects
//
// Gives next image from video stream to decode from
// image is normally obtained by UIGetScreenImage function
//
// return value: (BOOL) true if code has been read, 
//                      false if more images are needed
//
// readFromImage:(CGImageRef) image from screen capture
//                            will be released by function
// readHeight: (int)  at which row of the image should the barcode be read
// from:(int*) OUTPUT VALUE : distance from left edge of barcode to 
//                            left edge of screen if found
//                            -1 otherwise
// to:(int*) OUTPUT VALUE   : distance from right edge of barcode to 
//                            left edge of screen if found
//                            -1 otherwise
// digits:(int[13]) OUTPUT VALUE  : decoded digits - IF return value is TRUE
//                                  array of 13 digits is allocated by caller
//                                  if digits[12]==-1: result is EAN8, held in first 8 digits
//                                  if digits[12]==-2: result is UPCE, held in first 8 digits (first always zero)
-(BOOL) readFromImage:(CGImageRef)img readHeight:(int)readHeight from:(int*)left to:(int*)right digits:(int*)res;


// ** This method is deprecated; 
// ** use -(NSString*) readFromImageBuffer or -(NSString*) readFromImageBufferOmnidirectional 
// ** in new projects
//
// Gives next image buffer from video stream to decode from
//
// Image buffer is normally obtained from AVCaptureSession
// Pixel Format of Image buffer MUST BE either:
// -420f (preferably - video settings kCVPixelBufferPixelFormatTypeKey = kCVPixelFormatType_420YpCbCr8BiPlanarFullRange)
// -2vuy (iPhone 3G  - video settings kCVPixelBufferPixelFormatTypeKey = kCVPixelFormatType_422YpCbCr8)
// -BGRA (deprecated - video settings kCVPixelBufferPixelFormatTypeKey = kCVPixelFormatType_32BGRA)
//
// return value: (BOOL) true if code has been read, 
//                      false if more images are needed
//
// readFromImageBuffer:(CVImageBufferRef) image buffer from video capture
// 
// readHeight: (float) at which image height should the barcode be read (relative to image height, from top)
// from:(float*) OUTPUT VALUE : distance from left edge of barcode to 
//                              left edge of screen if found, relative to image width
//                              -1.0 otherwise
// to:(float*) OUTPUT VALUE   : distance from right edge of barcode to 
//                              left edge of screen if found, relative to image width
//                              -1.0 otherwise
// digits:(int[13]) OUTPUT VALUE  : decoded digits - IF return value is TRUE
//                                  array of 13 digits is allocated by caller
//                                  if digits[12]==-1: result is EAN8, held in first 8 digits
//                                  if digits[12]==-2: result is UPCE, held in first 8 digits (first always zero)
-(BOOL) readFromImageBuffer:(CVImageBufferRef)img readHeight:(float)readHeight from:(float*)left to:(float*)right digits:(int*)res;


// Gives next image buffer of video stream to decode
//
// Image buffer is normally obtained from AVCaptureSession
// Pixel Format of Image buffer MUST BE either:
// -420v (preferably - video settings kCVPixelBufferPixelFormatTypeKey = kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange)
// -2vuy (iPhone 3G  - video settings kCVPixelBufferPixelFormatTypeKey = kCVPixelFormatType_422YpCbCr8)
// -BGRA (deprecated - video settings kCVPixelBufferPixelFormatTypeKey = kCVPixelFormatType_32BGRA)
//
// return value: (NSString*) barcode data if code has been read, 
//                           nil if more images are needed
//
// readFromImageBuffer:(CVImageBufferRef) image buffer from video capture
// 
// readHeight: (float) at which image height should the barcode be read (relative to image height, from top)
// from:(float*) OUTPUT VALUE : distance from left edge of barcode to 
//                             left edge of screen if found, relative to image width
//                             -1.0 otherwise
// to:(float*) OUTPUT VALUE   : distance from right edge of barcode to 
//                              left edge of screen if found, relative to image width
//                              -1.0 otherwise
//
// landscapeMode:(BOOL)landscape : look for a barcode in landscape mode (bars parallel to the short side of the image)
//                                 if true, the readHeight:, from: and to: parameters refer to the landscape image
//
// symbologies:(int)symbologies : OR'ed values from the VSSymbologies enum (defined above)
//                                the symbologies to attempt reading
//                                for example, pass 0x01|0x08 (0x09) to decode EAN13 and ITF
//
// foundSymbology:(int*)foundSymbology OUTPUT VALUE : 
//                                one value from the VSSymbologies enum (defined above)
//                                the symbology of the barcode that has been read
//                                0 is no barcode read
//
// ** note : the decodeEAN8 and decodeUPCE properties are ignored by this method
//
-(NSString*) readFromImageBuffer:(CVImageBufferRef)imageBuffer readHeight:(float)barpos landscapeMode:(BOOL)landscape symbologies:(int)symbologies from:(float*)fromLeft to:(float*)toRight foundSymbology:(int*)foundSymbology;


// Gives next image buffer of video stream to decode in any direction
//
// Image buffer is normally obtained from AVCaptureSession
// Pixel Format of Image buffer MUST BE either:
// -420v (preferably - video settings kCVPixelBufferPixelFormatTypeKey = kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange)
// -2vuy (iPhone 3G  - video settings kCVPixelBufferPixelFormatTypeKey = kCVPixelFormatType_422YpCbCr8)
// -BGRA (deprecated - video settings kCVPixelBufferPixelFormatTypeKey = kCVPixelFormatType_32BGRA)
//
// return value: (NSString*) barcode data if code has been read, 
//                           nil if more images are needed
//
// readFromImageBufferOmnidirectional:(CVImageBufferRef) image buffer from video capture
// 
// landscapeMode:(BOOL)landscape : look for a barcode in landscape mode (bars parallel to the short side of the image)
//                                 if true, the readHeight:, from: and to: parameters refer to the landscape image
//
// symbologies:(int)symbologies : OR'ed values from the VSSymbologies enum (defined above)
//                                the symbologies to attempt reading
//                                for example, pass 0x01|0x08 (0x09) to decode EAN13 and ITF
//
// lineStart:(CGPoint*) OUTPUT VALUE: one extremity (at edge of screen) of the line where a barcode has been detected (in image coordinates)
//
// lineEnd:(CGPoint*) OUTPUT VALUE: other extremity (at edge of screen) of the line where a barcode has been detected (in image coordinates)
//
// from:(float*) OUTPUT VALUE : distance from left edge of barcode to 
//                              start of line if detected, relative to line length
//                             -1.0 otherwise
// to:(float*) OUTPUT VALUE   : distance from right edge of barcode to 
//                              start of line if detected, relative to line length
//                              -1.0 otherwise
//
// foundSymbology:(int*)foundSymbology OUTPUT VALUE : 
//                                one value from the VSSymbologies enum (defined above)
//                                the symbology of the barcode that has been read
//                                0 is no barcode read
//
// ** note : the decodeEAN8 and decodeUPCE properties are ignored by this method
//
-(NSString*) readFromImageBufferOmnidirectional:(CVImageBufferRef)imageBuffer symbologies:(int)symbologies lineStart:(CGPoint*)start lineEnd:(CGPoint*)end from:(float*)fromLeft to:(float*)toRight foundSymbology:(int*)foundSymbology;


@end
