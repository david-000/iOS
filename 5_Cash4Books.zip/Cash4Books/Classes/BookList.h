//
//  BookList.h
//  Cash4Books
//
//  Created by Ben Harris on 2/16/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Cash4BooksAppDelegate.h"
#import "Book.h"

#define kFinishedUpdatingPricesNotification @"DidFinishUpdatingPrices"

@interface BookList : NSObject {
	NSMutableArray *books;
	int bookCount;
	int pricesCurrentlyUpdatingCount;
}

@property (nonatomic, retain) NSMutableArray *books;
@property (readonly) int bookCount;

-(id)initWithBookList:(NSArray *)bookList;

-(float)total;
-(BOOL)add:(Book *)book;
-(BOOL)removeBookAtIndex:(int)bookIndex;
-(BOOL)contains:(Book *)book;
-(void)removeAllBooks;

-(Book *)bookAtIndex:(int)bookIndex;

-(void)updateQuotes;

-(NSString *)totalAsString;

-(int)count;

@end
