//
//  Cash4BooksAppDelegate.m
//  Cash4Books
//
//  Created by Ben Harris on 2/2/11.
//  Copyright 2011 Cash4Books. All rights reserved.
//

#import "Cash4BooksAppDelegate.h"
#import "C4BSingleton.h"
#import "BarcodeScannerViewController.h"
#import "KeypadEntryViewController.h"
#import "MyListViewController.h"
#import "HelpViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "GANTracker.h"

// Dispatch period in seconds
static const NSInteger kGANDispatchPeriodSec = 10;

@implementation Cash4BooksAppDelegate

@synthesize window;
@synthesize tabBarController;


#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    application.idleTimerDisabled = YES;
    
    // Google Analytics
    [[GANTracker sharedTracker] startTrackerWithAccountID:@"UA-196719-5" dispatchPeriod:kGANDispatchPeriodSec delegate:nil];
    
	//initialize My List dictionary in NSUserDefaults if not already created
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	if ( [defaults arrayForKey:kMyListKey] != nil ) {
		NSArray *myStoredList = [defaults arrayForKey:kMyListKey];
		BookList *myList = [[BookList alloc] initWithBookList:myStoredList];
		[[C4BSingleton sharedInstance] setBookList:myList];
		[myList release];
	}
    
    //Create all main view controllers and their navigation controllers.
    UIImageView *noCameraView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 25.0, 320.0, 430.0)];
    noCameraView.image = [UIImage imageNamed:@"nocamera.png"];
    
    UIViewController *noCameraViewController = [[UIViewController alloc] init];
    noCameraViewController.view = noCameraView;
    
	BarcodeScannerViewController *scannerViewController = [[BarcodeScannerViewController alloc] init];
    
	UINavigationController *scannerNavController;
    if ( (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])) {	
        scannerNavController = [[UINavigationController alloc] initWithRootViewController:noCameraViewController];
        scannerNavController.navigationBarHidden = YES;
    } else {
        scannerNavController = [[UINavigationController alloc] initWithRootViewController:scannerViewController];
    }
	UITabBarItem *scannerTabBarItem = [[UITabBarItem alloc] initWithTitle:@"Scanner" image:[UIImage imageNamed:@"barcode.png"] tag:0];
	scannerNavController.tabBarItem = scannerTabBarItem;
	[scannerTabBarItem release];
	
	KeypadEntryViewController *keypadEntryViewController = [[KeypadEntryViewController alloc] initWithNibName:@"KeypadEntryView" bundle:nil];
	UINavigationController *keypadNavController = [[UINavigationController alloc] initWithRootViewController:keypadEntryViewController];
	UITabBarItem *keypadTabBarItem = [[UITabBarItem alloc] initWithTitle:@"Keypad" image:[UIImage imageNamed:@"dialpad.png"] tag:1];
	keypadNavController.tabBarItem = keypadTabBarItem;
	[keypadTabBarItem release];
	
	MyListViewController *myListViewController = [[MyListViewController alloc] initWithNibName:@"MyListViewController" bundle:nil];
	UINavigationController *myListNavController = [[UINavigationController alloc] initWithRootViewController:myListViewController];
	UITabBarItem *myListTabBarItem = [[UITabBarItem alloc] initWithTitle:@"My List" image:[UIImage imageNamed:@"notepad.png"] tag:2];
	myListNavController.tabBarItem = myListTabBarItem;
	[myListTabBarItem release];
    
    HelpViewController *helpViewController = [[HelpViewController alloc] initWithNibName:@"HelpViewController" bundle:nil];
	UINavigationController *helpNavController = [[UINavigationController alloc] initWithRootViewController:helpViewController];
	UITabBarItem *helpTabBarItem = [[UITabBarItem alloc] initWithTitle:@"Help" image:[UIImage imageNamed:@"info.png"] tag:2];
	helpNavController.tabBarItem = helpTabBarItem;
	[helpTabBarItem release];
	
	//Add view controllers to tab bar.
	tabBarController.viewControllers = [NSArray arrayWithObjects:scannerNavController, keypadNavController, myListNavController, helpNavController, nil];
    
    if ( (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]))
        [tabBarController setSelectedViewController:keypadNavController];
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    if ( ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]))
        [nc addObserver:scannerViewController selector:@selector(reachabilityChanged:) name:kReachabilityChangedNotification object:nil];
    [nc addObserver:keypadEntryViewController selector:@selector(reachabilityChanged:) name:kReachabilityChangedNotification object:nil];
    [nc addObserver:myListViewController selector:@selector(reachabilityChanged:) name:kReachabilityChangedNotification object:nil];
    
    reach = [[Reachability reachabilityWithHostName:@"www.cash4books.net"] retain];
    [reach startNotifier];
	
	[noCameraViewController release];
	[scannerViewController release];
	[keypadEntryViewController release];
	[myListViewController release];
    [helpViewController release];
	
	[scannerNavController release];
	[keypadNavController release];
	[myListNavController release];
    [helpNavController release];
	
	[[C4BSingleton sharedInstance] updateBookCountBadges];
	
    // Add the tab bar controller's view to the window and display.
    [self.window addSubview:tabBarController.view];
    [self.window makeKeyAndVisible];

    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    if ( ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])) {
        UINavigationController *scannerNavController = (UINavigationController *) [[tabBarController viewControllers] objectAtIndex:0];
        BarcodeScannerViewController *scannerViewController = (BarcodeScannerViewController *)[[scannerNavController viewControllers] objectAtIndex:0];
        [scannerViewController.liveScanner cancel];
    }
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    if ( ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])) {
        UINavigationController *scannerNavController = (UINavigationController *) [[tabBarController viewControllers] objectAtIndex:0];
        BarcodeScannerViewController *scannerViewController = (BarcodeScannerViewController *)[[scannerNavController viewControllers] objectAtIndex:0];
        [scannerViewController.liveScanner cancel];
    }
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    if ( ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])) {
        UINavigationController *scannerNavController = (UINavigationController *) [[tabBarController viewControllers] objectAtIndex:0];
        BarcodeScannerViewController *scannerViewController = (BarcodeScannerViewController *)[[scannerNavController viewControllers] objectAtIndex:0];
        if (tabBarController.selectedViewController == scannerNavController) {
            [scannerViewController.liveScanner startLiveDecoding];
        }
    }
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    if ( ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])) {
        UINavigationController *scannerNavController = (UINavigationController *) [[tabBarController viewControllers] objectAtIndex:0];
        BarcodeScannerViewController *scannerViewController = (BarcodeScannerViewController *)[[scannerNavController viewControllers] objectAtIndex:0];
        if (tabBarController.selectedViewController == scannerNavController) {
            if (!scannerViewController.guideOpen) {
                [scannerViewController.liveScanner startLiveDecoding];
            } else {
                [scannerViewController.liveScanner stopCapture];
            }
        }
    }
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc postNotification:[NSNotification notificationWithName:kReachabilityChangedNotification object:reach]];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
}


#pragma mark -
#pragma mark UITabBarControllerDelegate methods

/*
// Optional UITabBarControllerDelegate method.
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {

}
*/ 

/*
// Optional UITabBarControllerDelegate method.
- (void)tabBarController:(UITabBarController *)tabBarController didEndCustomizingViewControllers:(NSArray *)viewControllers changed:(BOOL)changed {
}
*/


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
    [[GANTracker sharedTracker] stopTracker];
    [tabBarController release];
    [window release];
    [super dealloc];
}

@end

