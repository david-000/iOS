//
//  MyListViewController.m
//  Cash4Books
//
//  Created by Ben Harris on 2/8/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import "MyListViewController.h"
#import "NotAcceptingTableViewCell.h"
#import "GANTracker.h"
#import "OrangeButton.h"

@implementation MyListViewController

@synthesize myListTableView, bookImages;

#pragma mark -
#pragma mark View lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    
    emptyListView = [[UIImageView alloc] initWithFrame:CGRectInset(self.view.frame, 0.0, 25.0)];
    emptyListView.backgroundColor = [UIColor whiteColor];
    emptyListView.image = [UIImage imageNamed:@"noitems.png"];
    emptyListView.contentMode = UIViewContentModeScaleAspectFill;                     
    [self.view addSubview:emptyListView];
    
	updatingPrices = NO;
	
	UIBarButtonItem *myListButton = [[UIBarButtonItem alloc] initWithTitle:@"My List" 
																	 style:UIBarButtonItemStylePlain 
																	target:nil 
																	action:nil];
	self.navigationItem.backBarButtonItem = myListButton;
	[myListButton release];
	
	self.navigationItem.leftBarButtonItem = self.editButtonItem;
	
	UIBarButtonItem *deleteAllButton = [[UIBarButtonItem alloc] initWithTitle:@"Delete All" 
																	 style:UIBarButtonItemStyleBordered 
																	target:self 
																	action:@selector(deleteAll)];
	self.navigationItem.rightBarButtonItem = deleteAllButton;
	
	[deleteAllButton release];
	
	totalLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0 , 11.0, 160.0, 25.0)];
    totalLabel.backgroundColor = [UIColor clearColor];
    totalLabel.font = [UIFont boldSystemFontOfSize:24.0];
	totalLabel.textColor = [UIColor whiteColor];
	UIBarButtonItem *totalButton = [[UIBarButtonItem alloc] initWithCustomView:totalLabel];
	
	UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
																			target:nil
																			action:nil];
	
    UIButton *checkoutButtonOrange = [[OrangeButton alloc] init];
    [checkoutButtonOrange setTitle:@"Checkout" forState:UIControlStateNormal];
    [checkoutButtonOrange addTarget:self action:@selector(submit) forControlEvents:UIControlEventTouchUpInside];
	UIBarButtonItem *checkoutButton = [[UIBarButtonItem alloc] initWithCustomView:checkoutButtonOrange];
	
    NSArray *toolbarItems = [[NSArray alloc] initWithObjects:totalButton,spacer,checkoutButton,nil];
	[self setToolbarItems:toolbarItems];
    [self updateTotal];
	
    [toolbarItems release];
	[totalButton release];
	[spacer release];
    [checkoutButtonOrange release];
	[checkoutButton release];
	
	int bookCount = [[[C4BSingleton sharedInstance] bookList] count];
	self.bookImages = [[NSMutableDictionary alloc] initWithCapacity:bookCount];
    
    // Google Analytics
    [[GANTracker sharedTracker] trackPageview:@"/app/mylist" withError:nil];
}



- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [self.navigationController setToolbarHidden:NO animated:YES];    
	
    [self updateEmptyListViewAnimated:NO];
	[self updateButtons];
	[self updateTotal];
	
	[self.myListTableView reloadData];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
	self.editing = NO;
}

-(void)updateButtons {
	int bookCount = [[[C4BSingleton sharedInstance] bookList] count];
	
	//Enable or disable checkout and delete all buttons accordingly
	if ( bookCount > 0 ) {
		self.navigationItem.leftBarButtonItem.enabled = YES;
		self.navigationItem.rightBarButtonItem.enabled = YES;
		[[self.toolbarItems objectAtIndex:2] setEnabled:YES];
	}
	else {
		self.navigationItem.leftBarButtonItem.enabled = NO;
		self.navigationItem.rightBarButtonItem.enabled = NO;
		[[self.toolbarItems objectAtIndex:2] setEnabled:NO];
	}
}

-(void)updateTotal {
	totalLabel.text = [NSString stringWithFormat:@"$%@", [[[C4BSingleton sharedInstance] bookList] totalAsString]];
}

-(void)updateEmptyListViewAnimated:(BOOL)animated {
    if (animated) {
        [UIView beginAnimations:@"UpdateEmptyListAlpha" context:nil];
    }
    int bookCount = [[[C4BSingleton sharedInstance] bookList] count];
	
	if ( bookCount > 0 ) {
        emptyListView.alpha = 0.0;
        self.navigationController.navigationBarHidden = NO;
        self.navigationController.toolbarHidden = NO;
    }
	else {
		emptyListView.alpha = 1.0;
        self.navigationController.navigationBarHidden = YES;
        self.navigationController.toolbarHidden = YES;
    }
    
    if (animated) {
        [UIView commitAnimations];
    }
}

-(void)deleteAll {
	UIAlertView *confirmDeleteAll = [[UIAlertView alloc] initWithTitle:@"Delete All?" 
															   message:@"Are you sure you want to delete all the books in your list?"
															  delegate:self 
													 cancelButtonTitle:@"No" 
													 otherButtonTitles:@"Yes",nil];
	[confirmDeleteAll show];
	[confirmDeleteAll release];
}

-(void)didFinishUpdatingPrices {
    updatingPrices = NO;
    [self.myListTableView reloadData];
    [self updateTotal];
}

-(void)submit {
	//generate list of ISBNs
	NSString *isbns = [NSString stringWithFormat:@"app_source_id=1&offer_total=%.2f&isbns=", [[[C4BSingleton sharedInstance] bookList] total], nil];
	for (Book *book in [[[C4BSingleton sharedInstance] bookList] books]) {
		isbns = [isbns stringByAppendingFormat:@"%@,", book.isbn13];
	}
	//remove last comma
	isbns = [isbns substringToIndex:[isbns length]-1];
	NSData *isbnData = [isbns dataUsingEncoding:NSUTF8StringEncoding];
	
	NSURL *checkoutURL = [[NSURL alloc] initWithString:kCheckoutURLString];
	NSMutableURLRequest *checkoutRequest = [[NSMutableURLRequest alloc] initWithURL:checkoutURL cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:30.0];
	[checkoutRequest setHTTPMethod:@"POST"];
	[checkoutRequest setHTTPBody:isbnData];
	
	CheckoutViewController *checkoutViewController = [[CheckoutViewController alloc] initWithRequest:checkoutRequest];
	UINavigationController *checkoutNavController = [[UINavigationController alloc] initWithRootViewController:checkoutViewController];
	
	checkoutNavController.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
	
	[self presentModalViewController:checkoutNavController animated:YES];
    	
	[checkoutNavController release];
	[checkoutViewController release];
	[checkoutRequest release];
	[checkoutURL release];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	if ([[[C4BSingleton sharedInstance] bookList] count] == 0) {
		return 0;
	}
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[[C4BSingleton sharedInstance] bookList] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    Book *book = [[[C4BSingleton sharedInstance] bookList] bookAtIndex:indexPath.row];
    if ([book.price floatValue] == 0.0)
        return 114.0; //add Not Accepting header height
	return 90.0;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    Book *book = [[[C4BSingleton sharedInstance] bookList] bookAtIndex:indexPath.row];
    
    UITableViewCell *cell;
    if ([book.price floatValue] == 0.0) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"Expired"];
        if (!cell) {
            cell = [[[NotAcceptingTableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Expired"] autorelease];
        }
    } 
    else {
        cell = [tableView dequeueReusableCellWithIdentifier:@"Book"];
        if (!cell) {
            cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Book"] autorelease];
        }
    }
	
	cell.textLabel.text = book.title;
	cell.textLabel.numberOfLines = 2;
	cell.detailTextLabel.text = book.author;
	cell.detailTextLabel.font = [UIFont italicSystemFontOfSize:14.0];
	
    if (book.imageURL) {
        NSString *imageURLString = [book.imageURL absoluteString];
        if ( [bookImages objectForKey:imageURLString] == nil ) {
            NSURL *imageURL = [[NSURL alloc] initWithString:imageURLString];
            DataDownloader *imageDownloader = [[DataDownloader alloc] init];
            [imageDownloader downloadURL:imageURL withDelegate:self tag:indexPath.row];
            
            [imageURL release];
            [imageDownloader release];
            
            cell.imageView.image = [UIImage imageNamed:@"blank.png"];
        } 
        else {
            cell.imageView.image = [bookImages objectForKey:imageURLString];
        }
    }
	
	if ( [book.priceExpiration compare:[NSDate date]] == NSOrderedAscending ) {
		UIActivityIndicatorView *activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
		[activity startAnimating];
		cell.accessoryView = activity;
		
		if (!updatingPrices) {
            updatingPrices = YES;
			NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
			[nc addObserver:self selector:@selector(didFinishUpdatingPrices) name:kFinishedUpdatingPricesNotification object:[[C4BSingleton sharedInstance] bookList]];
			[[[C4BSingleton sharedInstance] bookList] updateQuotes];
		}
	}
	else {
        if ([book.price floatValue] > 0.0) {
            UILabel *offerLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 58.0, 15.0)];
            offerLabel.font = [UIFont systemFontOfSize:16.0];
            offerLabel.textColor = [UIColor colorWithRed:0.29 green:0.77 blue:0.33 alpha:1.0];
            offerLabel.text = [NSString stringWithFormat:@"$%.2f", [book.price floatValue], nil];
            cell.accessoryView = offerLabel;
        }
    }
    
    return cell;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleDelete;
}

// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    BookList *bookList = [[C4BSingleton sharedInstance] bookList];
	
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        float gaFloatPrice = [[bookList bookAtIndex:indexPath.row].price integerValue];
        gaFloatPrice = gaFloatPrice * 100;
        NSNumber *gaNumPrice = [NSNumber numberWithFloat:gaFloatPrice];
        NSInteger gaPrice = [gaNumPrice integerValue];
        [[GANTracker sharedTracker] trackEvent:@"MyList" action:@"Delete" label:[bookList bookAtIndex:indexPath.row].isbn13 value:gaPrice withError:nil];
        
        [bookList removeBookAtIndex:indexPath.row];
		
		[[C4BSingleton sharedInstance] updateBookCountBadges];
		[[C4BSingleton sharedInstance] updateStoredList];
		
		//total.title = [NSString stringWithFormat:@"$%@", [[[C4BSingleton sharedInstance] bookList] totalAsString]];
		
		if ([bookList count] > 0) {
			[tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
		}
		else {
			[tableView beginUpdates];
			[tableView deleteSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationFade];
			[tableView endUpdates];
		}
		
		[self updateEmptyListViewAnimated:YES];
		[self updateButtons];
        [self updateTotal];
    }     
}

// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return NO;
}



#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	BookDetailViewController *bookDetailViewController = [[BookDetailViewController alloc] 
                                                            initWithBook:[[[C4BSingleton sharedInstance] bookList]
                                                                          bookAtIndex:indexPath.row]];
	[self.navigationController pushViewController:bookDetailViewController animated:YES];
	[bookDetailViewController release];
}

#pragma mark -
#pragma mark Data Downloader Delegate
- (void)dataLoaded:(NSData *)d tag:(int)t sender:(id)sender backgrounded:(BOOL)backgrounded {
	if (d == nil) {	//Image not found
		return;
	}
	
	if ( [[[C4BSingleton sharedInstance] bookList] count] <= t ) {
		return;
	}
	
	Book *book = [[[C4BSingleton sharedInstance] bookList] bookAtIndex:t];
	UIImage *bookImage = [[UIImage alloc] initWithData:d];
	if (bookImage != nil) {
		NSString *imageURLString = [book.imageURL absoluteString];
		[self.bookImages setObject:bookImage forKey:imageURLString];
		[bookImage release];
		[self.myListTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:t inSection:0]]
                                    withRowAnimation:UITableViewRowAnimationNone];
	}
	else {
		NSLog(@"Could not create image with data.");
	}
}

#pragma mark -
#pragma mark Alert View delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	C4BSingleton *singleton = [C4BSingleton sharedInstance];
	
	if (buttonIndex != alertView.cancelButtonIndex) {
        // Google Analytics
        [[GANTracker sharedTracker] trackEvent:@"MyList" action:@"DeleteAll" label:nil value:[[singleton bookList] bookCount] withError:nil];
		[[singleton bookList] removeAllBooks];
		[[C4BSingleton sharedInstance] updateBookCountBadges];
		[[C4BSingleton sharedInstance] updateStoredList];
		
		//total.title = [NSString stringWithFormat:@"$%@", [[[C4BSingleton sharedInstance] bookList] totalAsString]];
		
		[self.myListTableView beginUpdates];
		[self.myListTableView deleteSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationTop];
		[self.myListTableView endUpdates];
		
        [self updateEmptyListViewAnimated:YES];
		[self updateButtons];
        [self updateTotal];
	}
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
	//Remove images which are not currently being displayed
	NSArray *visibleIndexPaths = [self.myListTableView indexPathsForVisibleRows];
	NSMutableArray *visibleKeys = [NSMutableArray arrayWithCapacity:[visibleIndexPaths count]];
	for (NSIndexPath *indexPath in visibleIndexPaths) {
		Book *book = [[[C4BSingleton sharedInstance] bookList] bookAtIndex:indexPath.row];
		NSString *imageURL = [book.imageURL absoluteString];
		[visibleKeys addObject:imageURL];
	}
	
	NSArray *keys = [self.bookImages allKeys];
	for (NSString *key in keys) {
		if ( ![visibleKeys containsObject:key] ) {
			[self.bookImages removeObjectForKey:key];
		}
	}
}

#pragma mark -
#pragma mark Reachability
- (void)reachabilityChanged:(NSNotification *)notification {
    Reachability* curReach = [notification object];
	NSParameterAssert([curReach isKindOfClass: [Reachability class]]);
	
    if ([curReach currentReachabilityStatus] == NotReachable) {
        //Disable checkout button
        ((UIBarButtonItem *)[self.navigationController.toolbar.items objectAtIndex:2]).enabled = NO;
    }
    else {
        //Enable checkout button
        ((UIBarButtonItem *)[self.navigationController.toolbar.items objectAtIndex:2]).enabled = YES;
    }
}

-(void)setEditing:(BOOL)editing animated:(BOOL)animated {
    [myListTableView setEditing:editing animated:animated];
    [super setEditing:editing animated:animated];
}

- (void)viewDidUnload {
    [super viewDidUnload];
    myListTableView = nil;
}


- (void)dealloc {
    [super dealloc];
    [bookImages release];
    [totalLabel release];
    [emptyListView release];
    [myListTableView release];
}


@end

