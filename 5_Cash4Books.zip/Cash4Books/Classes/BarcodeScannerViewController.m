//
//  FirstViewController.m
//  Cash4Books
//
//  Created by Ben Harris on 2/2/11.
//  Copyright 2011 Cash4Books. All rights reserved.
//

#import "BarcodeScannerViewController.h"
#import "BookDetailViewController.h"
#import "QuickGuideViewController.h"
#import "C4BSingleton.h"
#import "SBJson.h"
#import "GANTracker.h"
#import "ScanErrorViewController.h"

@implementation BarcodeScannerViewController

@synthesize liveScanner;
@synthesize reader;
@synthesize autoAccept, autoAcceptEnabled, guideOpen, guideEnabled, quickGuide, scanError;

-(id)init
{
    if (self = [super init])
    {
        //Initialize network graphic
        noNetworkView = [[UIImageView alloc] initWithFrame:CGRectInset(self.view.frame, 0.0, 25.0)];
        noNetworkView.backgroundColor = [UIColor whiteColor];
        noNetworkView.image = [UIImage imageNamed:@"nonetwork.png"];
        noNetworkView.contentMode = UIViewContentModeScaleAspectFill; 
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	self.navigationController.navigationBarHidden = YES;
	
	//Configure title of back button on the next screen
	UIBarButtonItem *decline = [[UIBarButtonItem alloc] initWithTitle:@"Decline" 
																style:UIBarButtonItemStylePlain
															   target:nil 
															   action:nil];
	self.navigationItem.backBarButtonItem = decline;
	[decline release];
}

-(void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
    [self.liveScanner viewDidAppear:animated];
	
    if ( [[C4BSingleton sharedInstance] currentlyHasNetworkConnection] ) {
        if (!guideOpen) {
            [self.liveScanner startLiveDecoding];
        }
    }
    
    [self openQuickStart];
}

-(void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
	[self.liveScanner stopCapture];
	[[self getDataDownloader] cancel];
}

-(void)openQuickStart {
    if (guideEnabled) {
        guideOpen = TRUE;
        guideEnabled = NO;
        [self.liveScanner stopCapture];
        if (!self.quickGuide) {
            self.quickGuide = [[QuickGuideViewController alloc] init];
            self.quickGuide.delegate = self;
        }
        [self.view addSubview:quickGuide.view];
    }
}

-(void)doneButtonPressed {
    guideOpen = NO;
    [self.liveScanner startLiveDecoding];
}

-(void)configureScannerView {
    if (!liveScanner) {
        //Configure the initial Auto Accept button images and font colors
        self.autoAccept = [UIButton buttonWithType:UIButtonTypeCustom];
        self.autoAccept.frame = CGRectMake(85.0, 76.0, 140.0, 22.0);
        
        [self.autoAccept setImage:[UIImage imageNamed:@"checkbox.png"] 
                         forState:UIControlStateNormal];
        [self.autoAccept setTitleColor:[UIColor whiteColor] 
                              forState:UIControlStateNormal];
        [self.autoAccept setTitle:@"Auto Accept" 
                         forState:UIControlStateNormal];
        
        [self.autoAccept setImage:[UIImage imageNamed:@"checkedbox.png"] 
                         forState:UIControlStateSelected];
        [self.autoAccept setTitleColor:[UIColor colorWithRed:0.29 green:0.77 blue:0.33 alpha:1.0] 
                              forState:UIControlStateSelected];
        [self.autoAccept setTitle:@"Auto Accept" 
                         forState:UIControlStateSelected];
        
        [self.autoAccept setTitleEdgeInsets:UIEdgeInsetsMake(0, 15.0, 0, 0)];
        self.autoAccept.titleLabel.font = [UIFont boldSystemFontOfSize:14.0];
        
        //Check defaults to see if Auto Accept mode has been enabled
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        if ( [defaults valueForKey:kAutoAcceptKey] != nil ) {
            self.autoAcceptEnabled = [defaults boolForKey:kAutoAcceptKey];
        }
        else {
            self.autoAcceptEnabled = NO;
        }
        if ( [defaults valueForKey:kShowQuickStart] != nil ) {
            self.guideEnabled = [defaults boolForKey:kShowQuickStart];
        }
        else {
            self.guideEnabled = YES;
        }
        
        self.autoAccept.selected = autoAcceptEnabled;
        [self.autoAccept addTarget:self 
                            action:@selector(toggleAutoAccept)
                  forControlEvents:UIControlEventTouchUpInside];
        
        //Create scanner instance
        self.reader = [[[VSBarcodeReader alloc] init] autorelease];
        self.liveScanner = [[[LiveScannerViewController alloc] init] autorelease];
        self.liveScanner.delegate = self;
        self.liveScanner.reader = self.reader;
        int symbologies = 0;
        symbologies |= kVSEAN13_UPCA;
        symbologies |= kVSUPCE;
        self.liveScanner.symbologies = symbologies;
        self.liveScanner.landscape = FALSE;
        self.liveScanner.omnidirectional = FALSE;
    }
    
    //place scanner into view
    self.view = self.liveScanner.view;
	
    if (![self.view.subviews containsObject:autoAccept]) {
        [self.view addSubview:autoAccept];
    }
    
	//Check device for flash/torch capabilities
	AVCaptureDevice *device = [[self.liveScanner.captureSession.inputs objectAtIndex:0] device];
	if ( [device hasTorch] && [device hasFlash] && !guideOpen ) {
		//Create flash button and place into view
		UIButton *flashButton = [UIButton buttonWithType:UIButtonTypeCustom];
		flashButton.frame = CGRectMake(235.0, 125.0, 67.0, 32.0);
		[flashButton setImage:[UIImage imageNamed:@"flashoff.png"] forState:UIControlStateNormal];
		flashButton.adjustsImageWhenHighlighted = YES;
		flashButton.alpha = 0.55;
		[flashButton addTarget:self action:@selector(toggleTorch:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:flashButton];
	}
}
		 
-(void)toggleAutoAccept {
	self.autoAcceptEnabled = !self.autoAcceptEnabled;
	
	self.autoAccept.selected = !self.autoAccept.selected;
	
	//Store preference for future convenience
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setBool:self.autoAcceptEnabled forKey:kAutoAcceptKey];
}

-(void)toggleTorch:(id)sender {
	UIButton *flashButton = (UIButton *)sender;
	AVCaptureDevice *device = [[self.liveScanner.captureSession.inputs objectAtIndex:0] device];
	if ( [device hasTorch] && [device hasFlash] ) {
		[device lockForConfiguration:nil];
		if (device.torchMode == AVCaptureTorchModeOff) {
			[flashButton setImage:[UIImage imageNamed:@"flashon.png"] forState:UIControlStateNormal];
			[device setTorchMode:AVCaptureTorchModeOn];
			[device setFlashMode:AVCaptureFlashModeOn];
		}
		else {
			[flashButton setImage:[UIImage imageNamed:@"flashoff.png"] forState:UIControlStateNormal];
			[device setTorchMode:AVCaptureTorchModeOff];
			[device setFlashMode:AVCaptureFlashModeOff];
		}
		[device unlockForConfiguration];
	}
}

#pragma mark -
#pragma mark Live Scanner Delegate
-(void) liveScannerDidCancel {
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

-(void) barcodeFound:(NSString*)barcode withSymbology:(int)symbology {
	[self.liveScanner stopCapture];
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    
    // Google Analytics
    [[GANTracker sharedTracker] trackEvent:@"Quotes" action:@"Scanned" label:barcode value:-1 withError:nil];
	
	//Check validity of scanned EAN
	if ([[C4BSingleton sharedInstance] isValidIsbn10:barcode]) {
		//Try to retrieve book information for ISBN-10
		NSString *urlString = [NSString stringWithFormat:kIsbn10URLFormat, barcode, nil];
		NSURL *bookURL = [NSURL URLWithString:urlString];
		[[self getDataDownloader] downloadURL:bookURL withDelegate:self tag:0];
	} 
	else if ([[C4BSingleton sharedInstance] isValidIsbn13:barcode]) {
		//Try to retrieve book information for ISBN-13
		NSString *urlString = [NSString stringWithFormat:kIsbn13URLFormat, barcode, nil];
		NSLog(@"%@", urlString);
		NSURL *bookURL = [NSURL URLWithString:urlString];
		[[self getDataDownloader] downloadURL:bookURL withDelegate:self tag:0];
	}
	else {
        // Invalid ISBN modal
        if (!self.scanError) {
            self.scanError = [[ScanErrorViewController alloc] init];
            scanError.delegate = self;
        }
        
        [self.view addSubview:scanError.view];
	}
}

#pragma mark -
#pragma mark Data Downloader delegate
- (void)dataLoaded:(NSData *)d tag:(int)t sender:(id)sender backgrounded:(BOOL)backgrounded {
	//Nothing was returned
	if (d == nil) {
		UIAlertView *errorRetrievingInfo = [[UIAlertView alloc] initWithTitle:@"Error"
															  message:@"Could not retrieve information for book."
															 delegate:self 
													cancelButtonTitle:@"OK"
													otherButtonTitles:nil];
		[errorRetrievingInfo show];
		[errorRetrievingInfo release];
		return;
	}
	
	C4BSingleton *singleton = [C4BSingleton sharedInstance];
	
	//Parse returned JSON
	NSString *jsonString = [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding];
	NSDictionary *bookDictionary = [[NSDictionary alloc] initWithDictionary:[jsonString JSONValue]];
	Book *book = [[Book alloc] initWithDictionary:bookDictionary];
    
    [jsonString release];
	[bookDictionary release];
	
	if ( book == nil ) {
		UIAlertView *errorRetrievingInfo = [[UIAlertView alloc] initWithTitle:@"Error"
																	  message:@"Could not retrieve information for book."
																	 delegate:self 
															cancelButtonTitle:@"OK"
															otherButtonTitles:nil];
		[errorRetrievingInfo show];
		[errorRetrievingInfo release];
		return;
	}
    
    if ([book priceExpired]) {
        book.priceExpiration = [[NSDate date] dateByAddingTimeInterval:300];
    }
	
	//Set the back button title for the next screen if the book is already in the list or if we are not accepting book
	if ( [singleton.bookList contains:book] || ![singleton currentlyAcceptingBook:book] ) {
		UIBarButtonItem *scannerButton = [[UIBarButtonItem alloc] initWithTitle:@"Scanner" 
																	style:UIBarButtonItemStylePlain
																   target:nil 
																   action:nil];
		self.navigationItem.backBarButtonItem = scannerButton;
		[scannerButton release];
	}
	
	if (autoAcceptEnabled) {
        if (autoAcceptTimer) {
            [autoAcceptTimer invalidate];
        }
        
        UILabel *feedbackLabel = self.liveScanner.helpLabel;
		if ( ![singleton currentlyAcceptingBook:book] ) {
			feedbackLabel.text =  @"We are not currently accepting this book.";
            feedbackLabel.textColor = [UIColor yellowColor];
            autoAcceptTimer = [NSTimer scheduledTimerWithTimeInterval:4.0 target:self selector:@selector(resetFeedback) userInfo:nil repeats:NO];
            
            // Google Analytics
            [[GANTracker sharedTracker] trackEvent:@"Quotes" action:@"Auto" label:book.isbn13 value:0.00 withError:nil];
		}
        else if ( ![singleton.bookList add:book] ) {
			feedbackLabel.text =  @"This book is in your list.\nPlease add quantity upon checkout.";
            feedbackLabel.textColor = [UIColor yellowColor];
            autoAcceptTimer = [NSTimer scheduledTimerWithTimeInterval:4.0 target:self selector:@selector(resetFeedback) userInfo:nil repeats:NO];
		}
        else {
            feedbackLabel.text =  [NSString stringWithFormat:@"Book was added to your list.\nAccepted for $%.2f", [book.price floatValue]];
            feedbackLabel.textColor = [UIColor greenColor];
            autoAcceptTimer = [NSTimer scheduledTimerWithTimeInterval:4.0 target:self selector:@selector(resetFeedback) userInfo:nil repeats:NO];
            
            [singleton updateStoredList];
            
            // Google Analytics
            [[GANTracker sharedTracker] trackEvent:@"Quotes" action:@"Auto" label:book.isbn13 value:[book.price integerValue] withError:nil];
        }
        
		[self.liveScanner startLiveDecoding];
        AudioServicesPlaySystemSound (kSystemSoundID_Vibrate);
	}
	else {
		//Display book information
		BookDetailViewController *bookDetailViewController = [[BookDetailViewController alloc] initWithBook:book];
		[self.navigationController pushViewController:bookDetailViewController animated:YES];
		[bookDetailViewController release];
	}
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    [book release];
	[[self getDataDownloader] clearData];
}

- (void)resetFeedback {
    [UIView beginAnimations:@"UpdateFeedback" context:nil];
    UILabel *feedbackLabel = self.liveScanner.helpLabel;
    feedbackLabel.text =  @"Place red line across barcode\nfrom about 3\" or 8 cm\nHold steady";
    feedbackLabel.textColor = [UIColor whiteColor];
    [UIView commitAnimations];
    autoAcceptTimer = nil;
}

#pragma mark -
#pragma mark UIAlertView Delegate
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
	[self.liveScanner startLiveDecoding];
}

#pragma mark -
#pragma mark Reachability
- (void)reachabilityChanged:(NSNotification *)notification {
    Reachability* curReach = [notification object];
	NSParameterAssert([curReach isKindOfClass: [Reachability class]]);
	
    if ([curReach currentReachabilityStatus] == NotReachable) {
        [liveScanner stopCapture];
        self.view = noNetworkView;
    }
    else {
        [self configureScannerView];
        if (!liveScanner.isScanning && [self.navigationController.tabBarController selectedViewController] == self.navigationController) {
            if (!guideOpen) {
                [liveScanner startLiveDecoding];
            }
        }
    }
}

-(DataDownloader *)getDataDownloader {
    if (dd == nil) {
        //Initialize data downloader
        dd = [[DataDownloader alloc] init];
    }
    
    return dd;
}

#pragma mark -
#pragma mark Memory Management

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
}


- (void)dealloc {
    [super dealloc];
	[liveScanner release];
	[reader release];
	[autoAccept release];
	[dd release];
    [noNetworkView release];
    [quickGuide release];
    [scanError release];
}

@end
