//
//  OrangeButton.m
//  Cash4Books
//
//  Created by John Kelly on 4/25/11.
//  Copyright 2011 Cash4Books.net. All rights reserved.
//

#import "OrangeButton.h"


@implementation OrangeButton

-(id)init {
    if ((self = [super init])) {
        self.frame = CGRectMake(0, 0, 130.0, 30.0);
        
        self.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        self.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        
        UIImage *image = [UIImage imageNamed:@"orangeButton.png"];
        
        UIImage *stretchImage = [image stretchableImageWithLeftCapWidth:15.0 topCapHeight:0.0];
        
        [self setBackgroundImage:stretchImage forState:UIControlStateNormal];
        
        self.backgroundColor = [UIColor clearColor];
        
        self.titleLabel.font = [UIFont boldSystemFontOfSize:16];
        self.titleLabel.shadowColor = [UIColor blackColor];
        self.titleLabel.shadowOffset = CGSizeMake(0, -1);
    }
    
    return self;
}

@end
