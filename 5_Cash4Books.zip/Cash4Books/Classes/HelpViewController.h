//
//  HelpViewController.h
//  Cash4Books
//
//  Created by Ben Harris on 2/14/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HelpButton.h"
#import "QuickGuideViewController.h"

@interface HelpViewController : UIViewController <QuickGuideViewControllerDelegate> {
    IBOutlet UIButton *quickstartGuideButton;
    IBOutlet HelpButton *userGuideButton;
    IBOutlet HelpButton *faqButton;
    IBOutlet HelpButton *contactUsButton;
    IBOutlet HelpButton *termsAndPrivacyButton;
    IBOutlet HelpButton *conditionPolicyButton;    
}

@property (nonatomic, retain) UIButton *quickstartGuideButton;
@property (nonatomic, retain) HelpButton *userGuideButton;
@property (nonatomic, retain) HelpButton *faqButton;
@property (nonatomic, retain) HelpButton *contactUsButton;
@property (nonatomic, retain) HelpButton *termsAndPrivacyButton;
@property (nonatomic, retain) HelpButton *conditionPolicyButton;

-(IBAction)helpButtonPressed:(id)sender;
-(IBAction)quickstartPressed:(id)sender;
@end
