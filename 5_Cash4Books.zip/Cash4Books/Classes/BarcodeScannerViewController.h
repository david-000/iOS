//
//  FirstViewController.h
//  Cash4Books
//
//  Created by Ben Harris on 2/2/11.
//  Copyright 2011 Cash4Books. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>

#import "VSBarcodeReader.h"
#import "LiveScannerViewController.h"
#import "DataDownloader.h"
#import "ScanErrorViewController.h"
#import "QuickGuideViewController.h"

@interface BarcodeScannerViewController : UIViewController <LiveScannerDelegate, UIAlertViewDelegate, DataDownloaderDelegate, ScanErrorViewControllerDelegate, QuickGuideViewControllerDelegate> {
	LiveScannerViewController *liveScanner;
	VSBarcodeReader *reader;
    
	UIButton *autoAccept;
	BOOL autoAcceptEnabled;
    BOOL guideEnabled;
    BOOL guideOpen;
    NSTimer *autoAcceptTimer;
	
    UIImageView *noNetworkView;
    
	DataDownloader *dd;
    
    QuickGuideViewController *quickGuide;
    ScanErrorViewController *scanError;
}

@property (nonatomic, retain) VSBarcodeReader *reader;
@property (nonatomic, retain) LiveScannerViewController *liveScanner;
@property (nonatomic, retain) QuickGuideViewController *quickGuide;
@property (nonatomic, retain) ScanErrorViewController *scanError;

@property (nonatomic, retain) UIButton *autoAccept;
@property (nonatomic) BOOL autoAcceptEnabled;
@property (nonatomic) BOOL guideOpen;
@property (nonatomic) BOOL guideEnabled;

-(void)configureScannerView;

-(void)openQuickStart;

-(void)toggleAutoAccept;
-(void)toggleTorch:(id)sender;

-(void)liveScannerDidCancel;
-(void) barcodeFound:(NSString*)barcode withSymbology:(int)symbology;
-(DataDownloader *)getDataDownloader;

@end
