//
//  CheckoutViewController.m
//  Cash4Books
//
//  Created by Ben Harris on 2/18/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import "CheckoutViewController.h"
#import "C4BSingleton.h"

NSString *reviewURL = @"itms-apps://ax.itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?type=Purple+Software&id=429690630";

@implementation CheckoutViewController

@synthesize checkoutWebView, request, ratingAlert, doneButtonItem;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithRequest:(NSURLRequest *)r {
    self = [super initWithNibName:@"CheckoutViewController" bundle:nil];
    if (self) {
		self.request = r;
    }
    return self;
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	UIBarButtonItem *cancel = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(dismissModalViewControllerAnimated:)];
	self.navigationItem.leftBarButtonItem = cancel;
	[cancel release];
	
	[checkoutWebView loadRequest:request];
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.title = @"Loading...";
}

- (void)viewWillDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
	[checkoutWebView stopLoading];
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

#pragma mark -
#pragma mark UIWebView Delegate

- (void)webViewDidFinishLoad:(UIWebView *)webView {
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    self.title = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    
    if ( [[webView stringByEvaluatingJavaScriptFromString:@"completed"] isEqualToString:@"true"]) {
        [self switchToDone];
    }
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    if ([error code] != NSURLErrorCancelled) {
        UIAlertView *loadFailed = [[UIAlertView alloc] initWithTitle:@"Failed to Load Page" 
                                                             message:[error localizedDescription] 
                                                            delegate:nil 
                                                   cancelButtonTitle:@"OK" 
                                                   otherButtonTitles:nil];
        [loadFailed show];
        [loadFailed release];
    }
    [self dismissModalViewControllerAnimated:YES];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    self.title = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    if ( [[webView stringByEvaluatingJavaScriptFromString:@"completed"] isEqualToString:@"true"]) {
        [self switchToDone];
    }
    return YES;
}

- (void)switchToDone {
    [[[C4BSingleton sharedInstance] bookList] removeAllBooks];
    doneButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(donePressedAction:)];
    self.navigationItem.leftBarButtonItem = doneButtonItem;
}

- (void)showRatingAlert {
    UIAlertView *alertView = [[[UIAlertView alloc] initWithTitle:@"Like this app?" message:@"Please review it in the app store" delegate:self cancelButtonTitle:@"No Thanks" otherButtonTitles:@"Rate It!", nil] autorelease];
    self.ratingAlert = alertView;
    [alertView show];
}

- (void)donePressedAction:(id)sender {
    if ( [[checkoutWebView stringByEvaluatingJavaScriptFromString:@"secondOrder"] isEqualToString:@"true"]) {
        [self showRatingAlert];
    } else {
        [self.navigationController dismissModalViewControllerAnimated:true];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    switch (buttonIndex) {
        case 0:
            [self.navigationController dismissModalViewControllerAnimated:true];
            break;
        case 1:
            // They want to rate it
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:reviewURL]];
        default:
            [self.navigationController dismissModalViewControllerAnimated:true];
            break;
    }
}

#pragma mark -
#pragma mark Reachability
- (void)reachabilityChanged:(NSNotification *)notification {
    Reachability* curReach = [notification object];
	NSParameterAssert([curReach isKindOfClass: [Reachability class]]);
	
    if ([curReach currentReachabilityStatus] == NotReachable) {
        //No internet
    }
    else {
        //Internet
    }
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];

    // Release any retained subviews of the main view.
    checkoutWebView = nil;
    request = nil;
}


- (void)dealloc {
    [checkoutWebView release];
    
    self.doneButtonItem = nil;
    
    [super dealloc];
}


@end
