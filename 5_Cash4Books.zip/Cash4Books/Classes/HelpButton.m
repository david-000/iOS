//
//  HelpButton.m
//  Cash4Books
//
//  Created by Ben Harris on 3/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "HelpButton.h"


@implementation HelpButton

@synthesize url;

@end
