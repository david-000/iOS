//
//  BookList.m
//  Cash4Books
//
//  Created by Ben Harris on 2/16/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import "BookList.h"
#import "C4BSingleton.h"

@implementation BookList

@synthesize books, bookCount;

-(BookList *)init {
	self = [super init];
	
	if(self) {
		books = [[NSMutableArray alloc] init];
		bookCount = 0;        
        pricesCurrentlyUpdatingCount = 0;
	}
	
	return self;
}

-(BookList *)initWithBookList:(NSArray *)bookList {
	self = [super init];
	
	if(self) {
		books = [[NSMutableArray alloc] initWithCapacity:[bookList count]];
		for (NSDictionary *bookDictionary in bookList) {
			Book *book = [[Book alloc] initWithDictionary:bookDictionary];
			[books addObject:book];
			[book release];
		}
		bookCount = [books count];
        pricesCurrentlyUpdatingCount = 0;
	}
	
	return self;
}

-(float)total {
    float t = 0.0;
    for (Book *b in books){
        t += [[b price] floatValue];
    }
    return t;
}

-(BOOL)add:(Book *)book {
	BOOL added = NO;

	if (![self contains:book]) {
		[books addObject:book];
		bookCount++;
		added = YES;
		
		[[C4BSingleton sharedInstance] updateStoredList];
		[[C4BSingleton sharedInstance] updateBookCountBadges];
	}	
	
	return added;
}

-(BOOL)removeBookAtIndex:(int)bookIndex {
	BOOL removed = NO;
	if (bookIndex < bookCount) {
		[books removeObjectAtIndex:bookIndex];
		bookCount--;
		removed = YES;
		
		[[C4BSingleton sharedInstance] updateStoredList];
		[[C4BSingleton sharedInstance] updateBookCountBadges];
	}
	
	return removed;
}

-(BOOL)contains:(Book *)book {
	//Book can't be in empty list
	if ( bookCount == 0)
		return NO;
	
	//Check for identical titles in Book List
	for (Book *existingBook in books) {
		if ( [existingBook isEqualToBook:book] ) {
			return YES;
		}
	}
	return NO;
}

-(void)removeAllBooks {
	if (bookCount > 0) {
		[books removeAllObjects];
		bookCount = 0;
		
		[[C4BSingleton sharedInstance] updateStoredList];
		[[C4BSingleton sharedInstance] updateBookCountBadges];
	}
}

-(Book *)bookAtIndex:(int)bookIndex {
	if (bookCount < bookIndex) {
		return nil;
	}
	
	return [books objectAtIndex:bookIndex];
}

-(void)updateQuotes {
	for (Book *b in books) {
        if ([b priceExpired]) {
            [b updatePrice];
            
            NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
            [nc addObserver:self selector:@selector(quotesUpdated:) name:kPriceUpdated object:b];
            
            pricesCurrentlyUpdatingCount++;
        }
    }
}

-(void)quotesUpdated:(NSNotification *)notification {
    
    pricesCurrentlyUpdatingCount--;
    if (pricesCurrentlyUpdatingCount == 0) {
        int expired = 0;
        for (Book *b in books) {
            if ([[b price] floatValue] == 0.0)
                expired++;
        }
        
        if (expired > 0) {
            
            NSString *haveHas;
            if (expired > 1)
                haveHas = @"have";
            else
                haveHas = @"has";
            
            UIAlertView *booksExpired = [[UIAlertView alloc] initWithTitle:@"Offers Expired" 
                                                                   message:[NSString stringWithFormat:@"Due to recent offer expirations, %d of your books %@ been removed from your list.", expired, haveHas, nil]
                                                                  delegate:nil 
                                                         cancelButtonTitle:@"OK" 
                                                         otherButtonTitles:nil];
            [booksExpired show];
            [booksExpired release];
        }
        
        [[C4BSingleton sharedInstance] updateStoredList];
        
        
        
        NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
        [nc postNotificationName:kFinishedUpdatingPricesNotification object:self];
    }
}

-(NSString *)totalAsString {
	return [NSString stringWithFormat:@"%.2f", [self total], nil];
}

-(int)count {
	return bookCount;
}

- (void)dealloc {
	[super dealloc];
    [books release];
}

@end
