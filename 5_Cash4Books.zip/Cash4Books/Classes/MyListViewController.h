//
//  MyListViewController.h
//  Cash4Books
//
//  Created by Ben Harris on 2/8/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "C4BSingleton.h"
#import "DataDownloader.h"
#import "BookDetailViewController.h"
#import "CheckoutViewController.h"

#define kCheckoutURLString @"http://i.cash4books.net/checkout"


@interface MyListViewController : UIViewController <UITableViewDelegate, UITableViewDataSource,DataDownloaderDelegate, UIAlertViewDelegate> {
    IBOutlet UITableView *myListTableView;
	NSMutableDictionary *bookImages;
    UILabel *totalLabel;
	BOOL updatingPrices;
    
    UIImageView *emptyListView;
}

@property (nonatomic, retain) UITableView *myListTableView;
@property (nonatomic, retain) NSMutableDictionary *bookImages;

-(void)updateButtons;
-(void)updateTotal;
-(void)updateEmptyListViewAnimated:(BOOL)animated;
-(void)deleteAll;
-(void)submit;

@end
