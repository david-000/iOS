//
//  QuickGuideViews.m
//  Cash4Books
//
//  Created by John Kelly on 8/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "QuickGuideViews.h"
#import "SynthesizeSingleton.h"

@implementation QuickGuideViews

SYNTHESIZE_SINGLETON_FOR_CLASS(QuickGuideViews);

- (id)init
{
    self = [super init];
    if (self != nil) {
        dataViews = [[NSArray alloc] initWithObjects:
                     @"StartGuide",
                     @"UsingScanner",
                     @"Keypad",
                     @"PriceQuotes",
                     @"MyList",
                     @"ReadyToPrice", nil];
    }
    return self;
}

- (NSInteger)numQuickGuideViews
{
    return [dataViews count];
}

- (NSString *)nibForPage:(NSInteger)pageIndex
{
    return [dataViews objectAtIndex:pageIndex];
}

@end
