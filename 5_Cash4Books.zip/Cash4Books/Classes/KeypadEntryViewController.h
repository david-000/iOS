//
//  KeypadEntryViewController.h
//  Cash4Books
//
//  Created by Ben Harris on 2/2/11.
//  Copyright 2011 Cash4Books. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "C4BSingleton.h"
#import "DataDownloader.h"
#import "SBJson.h"
#import "BookDetailViewController.h"


@interface KeypadEntryViewController : UIViewController <UITextViewDelegate, DataDownloaderDelegate> {
	IBOutlet UITextField *isbnField;
	IBOutlet UITextField *shadowField; //no easy way to add drop shadow to textfield.
	
	IBOutlet UILabel *message;
	
	IBOutlet UIView *keypadView;
	IBOutlet UIButton *backspaceButton;
	IBOutlet UIButton *getOfferButton;
    
    IBOutlet UIImageView *noNetworkView;
	
	DataDownloader *dd;
}

@property(nonatomic, retain) UITextField *isbnField;
@property(nonatomic, retain) UITextField *shadowField;

@property(nonatomic, retain) UILabel *message;

@property(nonatomic, retain) UIView *keypadView;
@property(nonatomic, retain) UIButton *backspaceButton;
@property(nonatomic, retain) UIButton *getOfferButton;

-(IBAction)entryButtonPressed:(id)sender;
-(IBAction)backspace;
-(IBAction)getOffer;
-(void)formatIsbnField;
-(void)clearTextField;

@end
