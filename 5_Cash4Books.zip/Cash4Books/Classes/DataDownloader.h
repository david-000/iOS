//
//  DataDownloader.h
//  Cash4Books
//

#import <Foundation/Foundation.h>

#define kAPIUsername @"iphone"
#define kAPIPassword @"my2skjam"

@protocol DataDownloaderDelegate
- (void)dataLoaded:(NSData *)d tag:(int)t sender:(id)sender backgrounded:(BOOL)backgrounded;
@end


@interface DataDownloader : NSObject {
	NSMutableData *data;
	int tag;
	id<DataDownloaderDelegate> delegate;
	NSURLConnection *conn;
	NSMutableURLRequest *request;
	NSURL *savedURL;
}

- (void)downloadURL:(NSURL *)url withDelegate:(id<DataDownloaderDelegate>)del tag:(int)t;
- (void)downloadURL:(NSURL *)url postData:(NSDictionary *)postData withDelegate:(id<DataDownloaderDelegate>)del tag:(int)t;
- (void)cancel;
- (void)clearData;
- (void)willEnterBackground;
- (NSURL *)getURL;

@end