//
//  ScanErrorViewController.h
//  Cash4Books
//
//  Created by John Kelly on 8/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ScanErrorViewControllerDelegate
-(void) doneButtonPressed;
@end

@interface ScanErrorViewController : UIViewController {
    id<ScanErrorViewControllerDelegate> delegate;
    
    UIButton *doneButton;
}

@property (nonatomic, assign) id<ScanErrorViewControllerDelegate> delegate;

@property (nonatomic, retain) IBOutlet UIButton *doneButton;

-(IBAction)buttonPressed;

@end
