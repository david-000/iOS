//
//  DataDownloader.m
//  Cash4Books
//

#import "DataDownloader.h"

@implementation DataDownloader

- (id)init {
	if ((self = [super init])) {
		data = [NSMutableData new];
	}
	return self;
}

- (void)downloadURL:(NSURL *)url postData:(NSDictionary *)postData withDelegate:(id<DataDownloaderDelegate>)del tag:(int)t {
	[request release];
	request = nil;
	
	[savedURL release];
	savedURL = nil;
	
	savedURL = [url retain];
	tag = t;
	delegate = del;
	NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadRevalidatingCacheData timeoutInterval:60];
	//set up post headers
	NSMutableString *postStr = [@"" mutableCopy];
	for (NSString *key in postData) {
		NSString *val = [[postData objectForKey:key] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
		val = [val stringByReplacingOccurrencesOfString:@"&" withString:@"%26"];
		if (![postStr isEqualToString:@""]) {
			[postStr appendString:@"&"];
		}
		[postStr appendFormat:@"%@=%@", key, val];
	}
	
	NSData *d = [postStr dataUsingEncoding:NSUTF8StringEncoding];
	
	[req setHTTPMethod: @"POST"];
	[req setHTTPBody:d];
	
	[postStr release];
	request = [req copy];
	BOOL good = NO;
	if (req) {
		if ([NSURLConnection canHandleRequest:req]) { 
			conn = [[NSURLConnection connectionWithRequest:req delegate:self] retain];
			if (conn) {
				good = YES;
				[conn start];
			}
		}
	}
	if (!good) {
		[delegate dataLoaded:nil tag:t sender:self backgrounded:NO];
	}
	
}

- (void)downloadURL:(NSURL *)url withDelegate:(id<DataDownloaderDelegate>)del tag:(int)t {
	if (request) {
		[request release];
		request = nil;
	}
	tag = t;
	delegate = del;
	NSURLRequest *req = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:60];
	BOOL good = NO;
	request = [req copy];
	if (req) {
		if ([NSURLConnection canHandleRequest:req]) { 
			conn = [[NSURLConnection connectionWithRequest:req delegate:self] retain];
			if (conn) {
				good = YES;
				[conn start];
			}
		}
	}
	if (!good) {
		[delegate dataLoaded:nil tag:t sender:self backgrounded:NO];
	}
}

- (NSURL *)getURL {
	return savedURL;
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
	if ([challenge previousFailureCount] == 0) {
		[[challenge sender] useCredential:[NSURLCredential credentialWithUser:kAPIUsername password:kAPIPassword persistence:NSURLCredentialPersistenceNone]
			   forAuthenticationChallenge:challenge];
	}
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)_data {
	[data appendData:_data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
	[delegate dataLoaded:nil tag:tag sender:self backgrounded:NO];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
	[delegate dataLoaded:data tag:tag sender:self backgrounded:NO];
}

- (void)cancel {
	[conn cancel];
}

- (void)clearData {
	data = [NSMutableData new];
}

- (void)willEnterBackground {
	[conn cancel];
	[delegate dataLoaded:data tag:tag sender:self backgrounded:YES];
}

- (void)dealloc {
	[data release];
	data = nil;
	[conn cancel];
	[conn release];
	conn = nil;
	[savedURL release];
	savedURL = nil;
	[super dealloc];
}

@end