//
//  NotAcceptingTableViewCell.h
//  Cash4Books
//
//  Created by Ben Harris on 3/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NotAcceptingTableViewCell : UITableViewCell {
    
}

@end
