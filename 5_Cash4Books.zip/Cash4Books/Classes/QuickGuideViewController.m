//
//  QuickGuideViewController.m
//  Cash4Books
//
//  Created by John Kelly on 8/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "QuickGuideViewController.h"
#import "QuickGuidePageViewController.h"
#import "QuickGuideViews.h"

@implementation QuickGuideViewController

@synthesize delegate;

- (void)applyNewIndex:(NSInteger)newIndex pageController:(QuickGuidePageViewController *)pageController
{
    NSInteger pageCount = [[QuickGuideViews sharedQuickGuideViews] numQuickGuideViews];
    BOOL outOfBounds = newIndex >= pageCount || newIndex < 0;
    
    if (!outOfBounds) {
        CGRect pageFrame = pageController.view.frame;
        pageFrame.origin.y = 0;
        pageFrame.origin.x = scrollView.frame.size.width * newIndex;
        pageController.view.frame = pageFrame;
    } else {
        CGRect pageFrame = pageController.view.frame;
        pageFrame.origin.y = scrollView.frame.size.height;
        pageController.view.frame = pageFrame;
    }
    
    pageController.pageIndex = newIndex;
}

- (void)dealloc
{
    [currentPage release];
    [nextPage release];
    self.delegate = nil;
    
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    QuickGuidePageViewController *page;
    for (int i = 0; i < [[QuickGuideViews sharedQuickGuideViews] numQuickGuideViews]; i++) {
        page = [[QuickGuidePageViewController alloc] initWithNibName:
                [[QuickGuideViews sharedQuickGuideViews] nibForPage:i] bundle:nil];
        page.delegate = self;
        [scrollView addSubview:page.view];
        [self applyNewIndex:i pageController:page];
    }
        
    NSInteger widthCount = [[QuickGuideViews sharedQuickGuideViews] numQuickGuideViews];
    if (widthCount == 0) {
        widthCount = 1;
    }
    
    scrollView.contentSize = CGSizeMake(
                                        scrollView.frame.size.width * widthCount, 
                                        scrollView.frame.size.height);
    scrollView.contentOffset = CGPointMake(0, 0);
    pageControl.numberOfPages = [[QuickGuideViews sharedQuickGuideViews] numQuickGuideViews];
    pageControl.currentPage = 0;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)newScrollView
{
    CGFloat pageWidth = scrollView.frame.size.width;
    float fractionalPage = scrollView.contentOffset.x / pageWidth;
	NSInteger nearestNumber = lround(fractionalPage);
	pageControl.currentPage = nearestNumber;
}

- (IBAction)doneButtonPressed:(id)sender
{
    [self doneButtonPressed];
}

-(void)doneButtonPressed
{
    [self.view removeFromSuperview];
    if (delegate != nil) {
        [delegate doneButtonPressed];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
