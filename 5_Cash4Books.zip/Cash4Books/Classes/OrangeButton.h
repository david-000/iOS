//
//  OrangeButton.h
//  Cash4Books
//
//  Created by John Kelly on 4/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface OrangeButton : UIButton {
}

-(id)init;

@end
