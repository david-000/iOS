//
//  QuickGuideViewController.h
//  Cash4Books
//
//  Created by John Kelly on 8/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QuickGuidePageViewController.h"

@class QuickGuidePageViewController;

@protocol QuickGuideViewControllerDelegate
-(void)doneButtonPressed;
@end

@interface QuickGuideViewController : UIViewController <QuickGuidePageViewControllerDelegate> {
    IBOutlet UIScrollView *scrollView;
	IBOutlet UIPageControl *pageControl;
    IBOutlet UIButton *doneButton;
    
    id<QuickGuideViewControllerDelegate> delegate;
	
	QuickGuidePageViewController *currentPage;
	QuickGuidePageViewController *nextPage;
}

@property (nonatomic, assign) id<QuickGuideViewControllerDelegate> delegate;

- (IBAction)doneButtonPressed:(id)sender;

-(void)doneButtonPressed;

@end
