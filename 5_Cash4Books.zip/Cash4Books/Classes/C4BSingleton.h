//
//  C4BSingleton.h
//  Cash4Books
//
//  Created by Ben Harris on 2/6/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BookList.h"
#import "C4BSingleton.h"

#define kMyListKey @"C4BMyList"
#define kAutoAcceptKey @"C4BAutoAcceptEnabled"
#define kShowQuickStart @"C4BShowQuickStart"

#define kIsbn10URLFormat @"http://www.cash4books.net/api/v2/get_product.php?isbn=%@&app=1"
#define kIsbn13URLFormat @"http://www.cash4books.net/api/v2/get_product.php?isbn=%@&app=1"

@interface C4BSingleton : NSObject {
	BookList *bookList;
}

@property (nonatomic, retain) BookList *bookList;

+(C4BSingleton *)sharedInstance;

-(BOOL)currentlyAcceptingBook:(Book *)book;

-(NSString *)formatISBN:(NSString *)isbn;

-(int)numericTranslationForCharacter:(unichar)c;
-(BOOL)isValidIsbn10:(NSString *)isbn10;
-(BOOL)isValidIsbn13:(NSString *)isbn13;

-(void)updateBookCountBadges;
-(void)updateStoredList;

-(BOOL)currentlyHasNetworkConnection;

@end

