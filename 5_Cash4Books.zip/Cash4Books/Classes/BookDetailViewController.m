//
//  BookDetailViewController.m
//  Cash4Books
//
//  Created by Ben Harris on 2/2/11.
//  Copyright 2011 Cash4Books. All rights reserved.
//

#import "BookDetailViewController.h"
#import "MyListViewController.h"
#import "GANTracker.h"

@implementation BookDetailViewController

@synthesize bookDetailTable;
@synthesize acceptButton;
@synthesize noAcceptButton;
@synthesize book;
@synthesize bookImage;
@synthesize imageLoaded;

- (id)initWithBook:(Book *)b {
    self = [super initWithNibName:@"BookDetailViewController" bundle:nil];
    if (self) {
		self.book = b;
    }
    return self;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.title = [book title];
	
	//Start downloading book image
	imageLoaded = NO;
	dd = [[DataDownloader alloc] init];
	[dd downloadURL:[book imageURL] withDelegate:self tag:0];
    
    //Configure accept button
    noAcceptButton.titleLabel.textAlignment = UITextAlignmentCenter;
    
    if (![[C4BSingleton sharedInstance] currentlyAcceptingBook:book]){
        [noAcceptButton setTitle:@"Sorry, we are not\n currently buying this book." forState:UIControlStateNormal];
        acceptButton.hidden = YES;
        
        // Google Analytics
        [[GANTracker sharedTracker] trackEvent:@"Quotes" action:@"Quoted" label:self.book.isbn13 value:0.00 withError:nil];
    } 
    else if ( [[[C4BSingleton sharedInstance] bookList] contains:book] ) {
        [noAcceptButton setTitle:@"This book is in your list.\nPlease add quantity upon checkout." forState:UIControlStateNormal];
        acceptButton.hidden = YES;
    }
    else {
        [acceptButton setBackgroundImage:[UIImage imageNamed:@"accept_button.png"] forState:UIControlStateNormal];
        noAcceptButton.hidden = YES;
        
        // Google Analytics
        float gaFloatPrice = [self.book.price floatValue];
        gaFloatPrice = gaFloatPrice * 100;
        NSNumber *gaNumPrice = [NSNumber numberWithFloat:gaFloatPrice];
        NSInteger gaPrice = [gaNumPrice integerValue];
        [[GANTracker sharedTracker] trackEvent:@"Quotes" action:@"Quoted" label:self.book.isbn13 value:gaPrice withError:nil];
	}
	
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    
    // Google Analytics
    [[GANTracker sharedTracker] trackPageview:@"/app/book" withError:nil];
}

-(void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	self.navigationController.navigationBarHidden = NO;
    [self.navigationController setToolbarHidden:YES animated:YES];
}

-(void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
	[dd cancel];
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

-(void)dismiss {
    // Google Analytics
    float gaFloatPrice = [self.book.price floatValue];
    gaFloatPrice = gaFloatPrice * 100;
    NSNumber *gaNumPrice = [NSNumber numberWithFloat:gaFloatPrice];
    NSInteger gaPrice = [gaNumPrice integerValue];
    [[GANTracker sharedTracker] trackEvent:@"Quotes" action:@"Decline" label:self.book.isbn13 value:gaPrice withError:nil];
    
    NSLog(@"Declined");
    
	[self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)accept {
	[[[C4BSingleton sharedInstance] bookList] add:self.book];
	[[C4BSingleton sharedInstance] updateBookCountBadges];
	[[C4BSingleton sharedInstance] updateStoredList];
    
    // Google Analytics
    float gaFloatPrice = [self.book.price floatValue];
    gaFloatPrice = gaFloatPrice * 100;
    NSNumber *gaNumPrice = [NSNumber numberWithFloat:gaFloatPrice];
    NSInteger gaPrice = [gaNumPrice integerValue];
    [[GANTracker sharedTracker] trackEvent:@"Quotes" action:@"Accept" label:self.book.isbn13 value:gaPrice withError:nil];
	
    [self dismiss];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
	if (![[C4BSingleton sharedInstance] currentlyAcceptingBook:book]) {
		return 1;
	}
    return 2;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    if (section == 0) {
		if ( [self.book isbn10] != nil) {
			return 3;
		}
		return 2;
	}
	return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == 0) {
		if (indexPath.row == 0) {
			return 95.0;
		}
		return 40.0;
	}
	return 60.0;
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil] autorelease];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    // Configure the cell...
	if (indexPath.section == 0) {
		if (indexPath.row == 0) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil] autorelease];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
			
			cell.textLabel.text = self.book.title;
			cell.textLabel.font = [UIFont boldSystemFontOfSize:16.0];
			cell.textLabel.adjustsFontSizeToFitWidth = YES;
			cell.textLabel.numberOfLines = 3;
			
			cell.detailTextLabel.text = self.book.author;
			cell.detailTextLabel.font = [UIFont italicSystemFontOfSize:14.0];
			
			if(imageLoaded)
				cell.imageView.image = self.bookImage;
			else
				cell.imageView.image = [UIImage imageNamed:@"blank.png"];
			
			return cell;
		}
		
		cell.textLabel.font = [UIFont boldSystemFontOfSize:12.0];	
		if (indexPath.row == 1) {
			cell.textLabel.text = @"ISBN-13";
			cell.detailTextLabel.text = [[C4BSingleton sharedInstance] formatISBN:book.isbn13];
			return cell;
		}
		else {
			cell.textLabel.text = @"ISBN-10";
			cell.detailTextLabel.text = [[C4BSingleton sharedInstance] formatISBN:book.isbn10];
			return cell;
		}
	}
	else {
		cell.textLabel.font = [UIFont systemFontOfSize:18.0];
		cell.textLabel.text = @"We pay you:";
		cell.detailTextLabel.text = [NSString stringWithFormat:@"$%.2f", [book.price floatValue], nil];
		cell.detailTextLabel.textColor = [UIColor colorWithRed:0.29 green:0.77 blue:0.33 alpha:1.0];
		cell.detailTextLabel.font = [UIFont boldSystemFontOfSize:26.0];
		return cell;
	}
}


#pragma mark -
#pragma mark Data Downloader Delegate
- (void)dataLoaded:(NSData *)d tag:(int)t sender:(id)sender backgrounded:(BOOL)backgrounded {
	if (d == nil) {
		NSLog(@"Image not found.");
		return;
	}
	
	//Book finished loading
	self.bookImage = [[UIImage alloc] initWithData:d];
	if (self.bookImage != nil) {
		self.imageLoaded = YES;
	}
	else {
		NSLog(@"Could not create image with data.");
	}

	[bookDetailTable reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:0 inSection:0]]
                           withRowAnimation:UITableViewRowAnimationFade];
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

#pragma mark -
#pragma mark Reachability
- (void)reachabilityChanged:(NSNotification *)notification {
    Reachability* curReach = [notification object];
	NSParameterAssert([curReach isKindOfClass: [Reachability class]]);
	
    if ([curReach currentReachabilityStatus] == NotReachable) {
        //No internet
    }
    else {
        //Internet
    }
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
	
    self.bookDetailTable = nil;
	self.acceptButton = nil;
    self.noAcceptButton = nil;
}


- (void)dealloc {
    [super dealloc];
	
	[bookDetailTable release];
	[acceptButton release];
    [noAcceptButton release];
	[bookImage release];
	[book release];
}


@end
