//
//  BookDetailViewController.h
//  Cash4Books
//
//  Created by Ben Harris on 2/2/11.
//  Copyright 2011 Cash4Books. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "C4BSingleton.h"
#import "DataDownloader.h"

#define kBookAcceptedNotification @"BookAcceptedNotification"

@interface BookDetailViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, DataDownloaderDelegate> {
	IBOutlet UITableView *bookDetailTable;
	IBOutlet UIButton *acceptButton;
    IBOutlet UIButton *noAcceptButton;
	
	Book *book;
	
	UIImage *bookImage;
	BOOL imageLoaded;
	
	DataDownloader *dd;
}

@property (nonatomic, retain) UITableView *bookDetailTable;
@property (nonatomic, retain) UIButton *acceptButton;
@property (nonatomic, retain) UIButton *noAcceptButton;
@property (nonatomic, retain) Book *book;
@property (nonatomic, retain) UIImage *bookImage;
@property (assign) BOOL imageLoaded;

-(id)initWithBook:(Book *)book;

-(void)dismiss;
-(IBAction)accept;

@end
