//
//  HelpViewController.m
//  Cash4Books
//
//  Created by Ben Harris on 2/14/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import "HelpViewController.h"
#import "HelpDisplayViewController.h"
#import "GANTracker.h"
#import "QuickGuideViewController.h"

@implementation HelpViewController

@synthesize quickstartGuideButton;
@synthesize userGuideButton;
@synthesize faqButton;
@synthesize contactUsButton;
@synthesize termsAndPrivacyButton;
@synthesize conditionPolicyButton; 

#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];

    userGuideButton.url = @"http://i.cash4books.net/help/user-guide";
    faqButton.url = @"http://i.cash4books.net/help/faq";
    contactUsButton.url = @"http://i.cash4books.net/help/contact";
    termsAndPrivacyButton.url = @"http://i.cash4books.net/help/terms-privacy";
    conditionPolicyButton.url = @"http://i.cash4books.net/help/condition-policy";
    
    // Google Analytics
    [[GANTracker sharedTracker] trackPageview:@"/app/help" withError:nil];
}


-(IBAction)helpButtonPressed:(id)sender {
    HelpDisplayViewController *helpDisplay = [[HelpDisplayViewController alloc] initWithURL:[NSURL URLWithString:((HelpButton *)sender).url]];
    [self.navigationController pushViewController:helpDisplay animated:YES];
    [helpDisplay release];
}

-(IBAction)quickstartPressed:(id)sender {
    QuickGuideViewController *quickGuide = [[QuickGuideViewController alloc] init];
    quickGuide.delegate = self;
    [quickGuide.view setFrame:CGRectMake(0, 20, 320, 416)];
    [self.navigationController.view addSubview:quickGuide.view];
}

-(void)doneButtonPressed {
    // do nothing
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.title = @"Help";
}

-(void)viewDidUnload {
    userGuideButton = nil;
    faqButton = nil;
    contactUsButton = nil;
    termsAndPrivacyButton = nil;
    conditionPolicyButton = nil;
    quickstartGuideButton = nil;
}

- (void)dealloc {
    [super dealloc];
    [quickstartGuideButton release];
    [userGuideButton release];
    [faqButton release];
    [contactUsButton release];
    [termsAndPrivacyButton release];
    [conditionPolicyButton release];
}


@end

