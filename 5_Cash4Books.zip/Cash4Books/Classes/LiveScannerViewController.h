//
//  LiveScannerViewController.h
//  VSBarcodeReader
//
//  Created by Benoit Maison on 22/07/10.
//  Copyright 2010-2012 Vision Smarts SPRL. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreMedia/CoreMedia.h>
#import <AudioToolbox/AudioServices.h>

#import "ScannerOverlayView.h"
#import "VSBarcodeReader.h"

@protocol LiveScannerDelegate
-(void) liveScannerDidCancel;
-(void) barcodeFound:(NSString*)barcode withSymbology:(int)symbology;
@end

@interface LiveScannerViewController : UIViewController <AVCaptureVideoDataOutputSampleBufferDelegate> {
	int barpos;
	BOOL isScanning;
	BOOL isVisible;
    BOOL flippedImage;
	SystemSoundID soundID;	
}

@property (nonatomic, assign) id<LiveScannerDelegate> delegate;
@property (nonatomic, retain) AVCaptureSession *captureSession;
@property (nonatomic, retain) AVCaptureVideoPreviewLayer *prevLayer;
@property (nonatomic, retain) AVCaptureDevice* currentCaptureDevice;
@property (nonatomic, retain) IBOutlet UIView *previewView;
@property (nonatomic, retain) IBOutlet UILabel *helpLabel;
@property (nonatomic, retain) IBOutlet UIButton *flipButton;
@property (nonatomic, retain) UIView *greenbar;
@property (nonatomic, retain) UIView *redbar;
@property (nonatomic, retain) VSBarcodeReader* reader;
@property (nonatomic, retain) ScannerOverlayView *overlayView;
@property (assign) int symbologies;
@property (assign) BOOL beep;
@property (assign) BOOL landscape;
@property (assign) BOOL omnidirectional;
@property (assign) BOOL isScanning;

-(IBAction)cancel;
-(IBAction)flipCamera;

-(void)startLiveDecoding;
-(void)initCapture;
-(void)stopCapture;
-(void)configureOverlays;
-(void)hideGreenBar;
-(void)setGreenSpanFrom:(int)left to:(int)right;
-(void)decodeImage:(CVImageBufferRef)imgBuf;
-(void)decodeImageOmnidirectional:(CVImageBufferRef)imgBuf;


@end