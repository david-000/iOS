//
//  QuickGuideViews.h
//  Cash4Books
//
//  Created by John Kelly on 8/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface QuickGuideViews : NSObject {
    NSArray *dataViews;
}

+ (QuickGuideViews *)sharedQuickGuideViews;
- (NSInteger)numQuickGuideViews;
- (NSString *)nibForPage:(NSInteger)pageIndex;

@end
