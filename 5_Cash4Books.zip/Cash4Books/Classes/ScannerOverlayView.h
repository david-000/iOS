//
//  ScannerOverlayView.h
//  VSBarcodeReader
//
//  Created by Benoit Maison on 23/02/12.
//  Copyright 2012 Vision Smarts SPRL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScannerOverlayView : UIView {
	CGMutablePathRef _redPathToDraw;
	CGMutablePathRef _greenPathToDraw;
}

@property (nonatomic, assign) CGMutablePathRef redPathToDraw;
@property (nonatomic, assign) CGMutablePathRef greenPathToDraw;

-(void) setRedPathToDraw:(CGMutablePathRef) newPath;
-(CGMutablePathRef) redPathToDraw;

-(void) setGreenPathToDraw:(CGMutablePathRef) newPath;
-(CGMutablePathRef) greenPathToDraw;

@end

