//
//  C4BSingleton.m
//  Cash4Books
//
//  Created by Ben Harris on 2/6/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import "C4BSingleton.h"
#import "Cash4BooksAppDelegate.h"


@implementation C4BSingleton

@synthesize bookList;

static C4BSingleton *sharedInstance = nil;

+ (C4BSingleton *)sharedInstance {
	@synchronized(self)
    {
		if (sharedInstance == nil) {
			sharedInstance = [[C4BSingleton alloc] init];
			sharedInstance.bookList = [[BookList alloc] init];
		}
    }
    return sharedInstance;
}

-(BOOL)currentlyAcceptingBook:(Book *)book {
	if ( [book.price floatValue] > 0.0 ) {
		return YES;
	}
	return NO;
}

//Hyphenates partially or fully formed ISBN-10 or ISBN-13
//Returns hyphenated ISBN-10 or ISBN-13
-(NSString *)formatISBN:(NSString *)isbn {
	NSMutableString *formattedISBN = [NSMutableString stringWithString:[isbn stringByReplacingOccurrencesOfString:@"-" withString:@""]];
	
	//No hyphens under 2 characters
	if ( [formattedISBN length] < 2 ) {
		return formattedISBN;
	}
	
	NSString *prefix;
	
	if ( [formattedISBN length] >= 3 ) {
		prefix = [formattedISBN substringToIndex:3];
		
		//Check if possibly ISBN-13 and hyphenate accordingly
		if ( ([prefix isEqualToString:@"978"] || [prefix isEqualToString:@"979"]) && ![[C4BSingleton sharedInstance] isValidIsbn10:formattedISBN] ) {
			if ( [formattedISBN length] > 3 )
				[formattedISBN insertString:@"-" atIndex:3];
			
			if ( [formattedISBN length] > 5 )
				[formattedISBN insertString:@"-" atIndex:5];
			
			if ( [formattedISBN length] > 9 )
				[formattedISBN insertString:@"-" atIndex:9];
			
			
			if ( [formattedISBN length] > 15 )
				[formattedISBN insertString:@"-" atIndex:15];
			
			return formattedISBN;
		}
	}
	
	//Not ISBN-13, hyphenate according to ISBN-10 standards	
	int groupIdentifier = [[formattedISBN substringToIndex:2] intValue];
	[formattedISBN insertString:@"-" atIndex:1];
	
	if ( groupIdentifier > 0 && groupIdentifier <= 19 ) {
		if ( [formattedISBN length] > 4 )
			[formattedISBN insertString:@"-" atIndex:4];
	}
	else if ( groupIdentifier >= 20 && groupIdentifier <= 69 ) {
		if ( [formattedISBN length] > 5 )
			[formattedISBN insertString:@"-" atIndex:5];
	}
	else if ( groupIdentifier >= 70 && groupIdentifier <= 84 ) {
		if ( [formattedISBN length] > 6 )
			[formattedISBN insertString:@"-" atIndex:6];
	}
	else if ( groupIdentifier >= 85 && groupIdentifier <= 89 ) {
		if ( [formattedISBN length] > 7 )
			[formattedISBN insertString:@"-" atIndex:7];
	}
	else if ( groupIdentifier >= 90 && groupIdentifier <= 94 ) {
		if ( [formattedISBN length] > 8 )
			[formattedISBN insertString:@"-" atIndex:8];
	}
	else if ( groupIdentifier >= 95 && groupIdentifier <= 99 ) {
		if ( [formattedISBN length] > 9 )
			[formattedISBN insertString:@"-" atIndex:9];
	}
	
	if ( [formattedISBN length] > 11 )
		[formattedISBN insertString:@"-" atIndex:11];
	
	return formattedISBN;
}

#pragma mark -
#pragma mark ISBN Validation
-(int)numericTranslationForCharacter:(unichar)c {
	switch (c) {
		case '0':
			return 0;
		case '1':
			return 1;
		case '2':
			return 2;
		case '3':
			return 3;
		case '4':
			return 4;
		case '5':
			return 5;
		case '6':
			return 6;
		case '7':
			return 7;
		case '8':
			return 8;
		case '9':
			return 9;
		case 'X':
			return 10;
		case '-':
			return 11;
		default:
			return -1;
	}
}

-(BOOL)isValidIsbn10:(NSString *)isbn10 {
	int isbnLength = [isbn10 length];
	
	if (isbnLength != 10)
		return NO;
	
	isbn10 = [isbn10 uppercaseString];
	
	int checksum = 0;
	int weight = 10;
	int i;
	for (i = 0; i < isbnLength; i++) {
		if (weight <= 0) {
			i++;
		}
		else {
			int val = [self numericTranslationForCharacter:[isbn10 characterAtIndex:i]];
			if (val >= 0) {
				if (val == 10 && weight != 1) {
					return NO;
				}
				if (val < 11) {
					checksum = checksum+(weight*val);
					weight--;
				}
			}
			else {
				return NO;
			}
		}
	}
	
	if (i < isbnLength) {
		return NO;
	}
	
	return ( (checksum % 11) == 0 );
}

-(BOOL)isValidIsbn13:(NSString *)isbn13 {
	int isbnLength = [isbn13 length];
	
	if (isbnLength != 13)
		return NO;
	
	NSString *prefix = [isbn13 substringToIndex:3];
	if ( !([prefix isEqual:@"978"] || [prefix isEqual:@"979"]) )
		return NO;

	int checksum = 0;
	int weight = 1;
	
	for (int i = 0; i < 13; i++) {
		if (i % 2 == 0)
			weight = 1;
		else
			weight = 3;
		
		int digit = (int) [isbn13 characterAtIndex:i];
		checksum += digit*weight;
	}
	
	if (checksum % 10 == 0)
		return YES;
	

	return NO;
}

-(void)updateBookCountBadges {
	//Update My List tab bar item badge
	Cash4BooksAppDelegate *appDelegate = (Cash4BooksAppDelegate *) [[UIApplication sharedApplication] delegate];
	for (UITabBarItem *item in appDelegate.tabBarController.tabBar.items) {
		if (item.tag == 2) {
			if ( bookList.bookCount == 0 ) {
				item.badgeValue = nil;
				[[UIApplication sharedApplication] setApplicationIconBadgeNumber:bookList.bookCount];
				return;
			}
			
			item.badgeValue = [NSString stringWithFormat:@"%d", bookList.bookCount, nil];
			
			//Update application icon badge
			[[UIApplication sharedApplication] setApplicationIconBadgeNumber:bookList.bookCount];
			return;
		}
	}
}

//Saves list of books to NSUserDefaults
-(void)updateStoredList {
	//Format array for storage
	NSMutableArray *storedArray = [[NSMutableArray alloc] initWithCapacity:bookList.bookCount];
	for (Book *book in bookList.books)
		[storedArray addObject:[book dictionaryRepresentation]];
		
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:storedArray forKey:kMyListKey];
	[defaults synchronize];
    
    [storedArray release];
}

-(BOOL)currentlyHasNetworkConnection {
    Reachability *currentReachability = [Reachability reachabilityWithHostName:@"www.cash4books.net"];
    return ([currentReachability currentReachabilityStatus] != NotReachable);
}

- (id)retain {
    return self;
}

- (unsigned)retainCount {
    return UINT_MAX;  // denotes an object that cannot be released
}

- (void)release {
    //do nothing
}

- (id)autorelease {
    return self;
}

- (void)dealloc {
	[super dealloc];
    [bookList release];
}

@end