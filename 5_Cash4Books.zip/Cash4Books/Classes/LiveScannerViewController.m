//
//  LiveScannerViewController.m
//  VSBarcodeReader
//
//  Created by Benoit Maison on 22/07/10.
//  Copyright 2010-2012 Vision Smarts SPRL. All rights reserved.
//

#include <stdint.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/sysctl.h>

#import <AudioToolbox/AudioToolbox.h>
#import "LiveScannerViewController.h"

@implementation LiveScannerViewController

@synthesize delegate;
@synthesize captureSession;
@synthesize prevLayer;
@synthesize previewView, overlayView;
@synthesize currentCaptureDevice;
@synthesize helpLabel;
@synthesize flipButton;
@synthesize reader;
@synthesize redbar;
@synthesize greenbar;
@synthesize beep;
@synthesize landscape;
@synthesize omnidirectional;
@synthesize symbologies;
@synthesize isScanning;


- (id)init {
	self = [super init];
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];

    // start with default camera (back), image will not be flipped
    self.currentCaptureDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    flippedImage = NO;
    
	// Use audio sevices to create the beep sound
	NSString *path = [NSString stringWithFormat:@"%@%@",
					  [[NSBundle mainBundle] resourcePath],
					  @"/beep.wav"];
	NSURL *filePath = [NSURL fileURLWithPath:path isDirectory:NO];
	AudioServicesCreateSystemSoundID((CFURLRef)filePath, &soundID);
	
	/*We intialize the capture (iOS5: if there is a camera) */
	if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
		[self initCapture];
	}
	
	isVisible = NO;	
}

- (void)viewDidAppear:(BOOL)animated {
	isVisible = YES;

    int numDevices = [[AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo] count];
	if (numDevices > 1) {
		NSLog(@"multiple cameras");
		flipButton.hidden = NO;
		flipButton.selected = NO;
	}
	else {
		NSLog(@"just one camera");
		flipButton.hidden = YES;
	}	
}

- (void)viewDidDisappear:(BOOL)animated {
	isVisible = NO;
    // Stop capture in case popover was dismissed
    [self stopCapture];
}

-(IBAction)flipCamera {
	NSArray* devices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
	if (isScanning && ([devices count]>1)) {
        
		[self.captureSession beginConfiguration];
        
		[self.captureSession removeInput:[[self.captureSession inputs] objectAtIndex:0] ];
        
		if (self.currentCaptureDevice == [devices objectAtIndex:0]) {
			self.currentCaptureDevice = [devices objectAtIndex:1];
            flippedImage = YES;
		}
		else {
			self.currentCaptureDevice = [devices objectAtIndex:0];	
            flippedImage = NO;
		}
        
		AVCaptureDeviceInput *captureInput = [AVCaptureDeviceInput 
											  deviceInputWithDevice:self.currentCaptureDevice 
											  error:nil];
		
		[self.captureSession addInput:captureInput];
		
		[self.captureSession commitConfiguration];
    }
}

-(IBAction)cancel {
	[self stopCapture];
	[self.delegate liveScannerDidCancel];
}

- (void)initCapture {
	// Setup the input
	AVCaptureDeviceInput *captureInput = [AVCaptureDeviceInput 
										  deviceInputWithDevice:self.currentCaptureDevice
										  error:nil];
	// Setup the output
	AVCaptureVideoDataOutput *captureOutput = [[AVCaptureVideoDataOutput alloc] init]; 
	captureOutput.alwaysDiscardsLateVideoFrames = YES; 
	[captureOutput setSampleBufferDelegate:self queue:dispatch_get_main_queue()];
	
	NSNumber* value;

    // detect iPhone 3G as it does not support planar YUV Pixel Format
	BOOL is3G = FALSE;
	size_t size;
	sysctlbyname("hw.machine", NULL, &size, NULL, 0);
	char *machine = malloc(size);
	sysctlbyname("hw.machine", machine, &size, NULL, 0);
	if ((size==10)&&(!strncmp(machine,"iPhone1,2",10))) is3G=TRUE;
	free(machine);
	if (is3G) {
		// Set the video output to store frame in interleaved YUV (iPhone 3G)
		value = [NSNumber numberWithUnsignedInt:kCVPixelFormatType_422YpCbCr8]; 
	}
	else {
		// Set the video output to store frame in planar YUV (all other devices)
		value = [NSNumber numberWithUnsignedInt:kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange]; 
	}
	 	
	NSString* key = (NSString*)kCVPixelBufferPixelFormatTypeKey; 
	NSDictionary* videoSettings = [NSDictionary dictionaryWithObject:value forKey:key]; 
	[captureOutput setVideoSettings:videoSettings]; 

	// Create a capture session
	self.captureSession = [[AVCaptureSession alloc] init];
	
	// Recommended setting 'medium' for UPC/EAN scanning:
	self.captureSession.sessionPreset = AVCaptureSessionPresetMedium;

	// Only use the 'high' setting if necessary to read large barcodes (with many bars)
	// or small barcodes from a greater distance (in order to be sufficiently sharp)
	// because the frame rate will be lower than with the 'medium' setting
    //	self.captureSession.sessionPreset = AVCaptureSessionPresetHigh;

	[self.captureSession addInput:captureInput];
	[self.captureSession addOutput:captureOutput];

	// Setup the preview layer
	self.prevLayer = [AVCaptureVideoPreviewLayer layerWithSession: self.captureSession];
	self.prevLayer.frame = self.previewView.bounds;
	self.prevLayer.videoGravity = AVLayerVideoGravityResize; // image may be slightly distorted, but red bar position will be accurate
	[self.previewView.layer addSublayer: self.prevLayer];
    
    // Setup the overlay (red & green bars)
    self.overlayView = [[ScannerOverlayView alloc] init];
    self.overlayView.frame = self.previewView.bounds;
    self.overlayView.backgroundColor = [UIColor clearColor];
	[self.previewView addSubview:self.overlayView];
    
}

- (void)stopCapture {
	isScanning = NO;
	[self.captureSession stopRunning];
}

- (void)captureOutput:(AVCaptureOutput *)captureOutput 
didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer 
	   fromConnection:(AVCaptureConnection *)connection 
{	
	// do not attempt decoding before live image is visible to user
	// do not attempt decoding after barcode has been found (but video capture is not yet stopped)
    CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);  
    //    NSLog(@"got image w=%d h=%d bpr=%d",(int)CVPixelBufferGetWidth(imageBuffer),(int) CVPixelBufferGetHeight(imageBuffer), (int) CVPixelBufferGetBytesPerRow(imageBuffer));
	if (isScanning && isVisible) {
        if (omnidirectional) {
            [self decodeImageOmnidirectional:imageBuffer];
		}
        else {
            [self decodeImage:imageBuffer];            
        }
	}
} 


-(void)decodeImage:(CVImageBufferRef)imgBuf {
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

    // don't display any of the omnidirectional visual feedback
    self.overlayView.redPathToDraw = nil;
    self.overlayView.greenPathToDraw = nil;
    
    // but display the horizontal of vertical red bar
    self.redbar.hidden = FALSE;
    
	float left, right;
	NSString* barcode = nil;
	int symbology;

	// bar position is relative (0..1) to image height (in portrait) or width (in landscape)
	float relBarPos;
	if (landscape) {
		// left side (x==0) is bottom of image
		relBarPos= 1.0 - (float)(barpos-self.previewView.bounds.origin.x)/(float)(self.previewView.bounds.size.width);
	} else {
		relBarPos= (float)(barpos-self.previewView.bounds.origin.y )/(float)(self.previewView.bounds.size.height);				
	}
	barcode = [self.reader readFromImageBuffer:imgBuf readHeight:relBarPos landscapeMode:landscape symbologies:symbologies from:&left to:&right foundSymbology:&symbology]; 
    	
	// if a barcode has been located in the image
	// give user feedback that they can hold still
	if (left>=0.) {
		if (landscape) {
			[self setGreenSpanFrom:(int)(self.previewView.bounds.origin.x+left*self.previewView.bounds.size.height) to:(int)(self.previewView.bounds.origin.x+right*self.previewView.bounds.size.height)];
		} else {
			[self setGreenSpanFrom:(int)(self.previewView.bounds.origin.y+left*self.previewView.bounds.size.width) to:(int)(self.previewView.bounds.origin.y+right*self.previewView.bounds.size.width)];
		}
	}
	else { // otherwise, only show red bar
		[self hideGreenBar];
	}
	
	// if a barcode has been successfully read
	// stop live scan, beep, return results to main controller		
	if (barcode) { 
		isScanning = NO;
		[self stopCapture];
		AudioServicesPlaySystemSound(soundID);
		
		[self.delegate barcodeFound:barcode withSymbology:symbology];
	}	

	[pool release];
}

-(void)decodeImageOmnidirectional:(CVImageBufferRef)imgBuf {
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    // hide the fixed red and green bars
    self.greenbar.hidden = TRUE;
    self.redbar.hidden = TRUE;
    
    CGPoint lineStart, lineEnd;
	float left, right;
	NSString* barcode = nil;
	int symbology;    
     
	barcode = [self.reader readFromImageBufferOmnidirectional:imgBuf symbologies:symbologies lineStart:&lineStart lineEnd:&lineEnd from:&left to:&right foundSymbology:&symbology]; 
	
	// if a barcode has been located in the image
	// give user feedback that they can hold still    
	if (left>=0.) {
        int width = CVPixelBufferGetWidth(imgBuf);
        int height = CVPixelBufferGetHeight(imgBuf);

        if (flippedImage) {
            lineStart.y = height - lineStart.y;
            lineEnd.y   = height - lineEnd.y;
        }
        
        float scalex=(float)self.previewView.frame.size.width/height;
        float scaley=(float)self.previewView.frame.size.height/width;
        //   scalex=scaley=1.0;
        self.overlayView.frame=self.previewView.frame;
        self.overlayView.transform=CGAffineTransformMakeScale(scalex, scaley);
        
        // red line across the screen
        CGMutablePathRef redPathRef = CGPathCreateMutable();
        CGPathMoveToPoint(redPathRef, NULL, height - (lineStart.y) , (lineStart.x) );
        CGPathAddLineToPoint(redPathRef, NULL, height - (lineEnd.y) , (lineEnd.x) );
        self.overlayView.redPathToDraw = redPathRef;    
        
        // green line where barcode may be
        int dx = lineEnd.x - lineStart.x;
        int dy = lineEnd.y - lineStart.y;
        lineEnd.x = lineStart.x + right * dx;
        lineEnd.y = lineStart.y + right * dy;
        lineStart.x = lineStart.x + left * dx;
        lineStart.y = lineStart.y + left * dy;
        CGMutablePathRef greenPathRef = CGPathCreateMutable();
        CGPathMoveToPoint(greenPathRef, NULL, height - (lineStart.y) , (lineStart.x) );
        CGPathAddLineToPoint(greenPathRef, NULL, height - (lineEnd.y) , (lineEnd.x) );
        self.overlayView.greenPathToDraw = greenPathRef;    
     
    }	
    
	// if a barcode has been successfully read
	// stop live scan, beep, return results to main controller		
	if (barcode) { 
		isScanning = NO;
		[self stopCapture];
		AudioServicesPlaySystemSound(soundID);
		
		[self.delegate barcodeFound:barcode withSymbology:symbology];
	}	
    
	[pool release];	
}

-(void)startLiveDecoding {
	// this sets the position of the red/green bar on the screen
	// the scan function can look 
	// for the barcode at the right height in the screen capture
	if (landscape) 
		barpos = 160;
	else	
		barpos = 256;
	isScanning = YES;
	[self configureOverlays];	
	[self.reader reset];
	/// start the video capture
	[self.captureSession startRunning];
}

-(void) configureOverlays {

	if (self.redbar==nil) {
		self.redbar = [[[UIView alloc] init] autorelease];
		self.redbar.backgroundColor= [UIColor redColor];
		self.redbar.alpha= 1.0;
		[[self view] addSubview:self.redbar]; 
	}
	if (landscape) {
        if (flippedImage)
            self.redbar.frame = CGRectMake(320-barpos-3,55,6,310);			
        else
            self.redbar.frame = CGRectMake(barpos-3,55,6,310);			
	} else {
		self.redbar.frame = CGRectMake(55,barpos-3,210,6);
	}
	
	if (self.greenbar==nil) {
		self.greenbar = [[[UIView alloc] init] autorelease];
		self.greenbar.backgroundColor= [UIColor greenColor];
		self.greenbar.alpha= 1.0;
		[[self view] addSubview:self.greenbar]; 
	}
	self.greenbar.hidden= TRUE;
	
	if (landscape) { // here we just hide the help label in landscape
				     // real apps with landscape scanning should have a landscape overlay
		self.helpLabel.hidden = TRUE;
	} else {
		self.helpLabel.hidden = NO;
	}

}

-(void) hideGreenBar {
	self.greenbar.hidden= TRUE;
}

-(void) setGreenSpanFrom:(int)left to:(int)right {
	if (landscape) {
        if (flippedImage)
            self.greenbar.frame = CGRectMake(320-barpos-3,left,6,right-left);	
        else
            self.greenbar.frame = CGRectMake(barpos-3,left,6,right-left);		
	}
	else {
        if (flippedImage)
            self.greenbar.frame = CGRectMake(320-right,barpos-3,right-left,6);
        else
            self.greenbar.frame = CGRectMake(left,barpos-3,right-left,6);
	}
	self.greenbar.hidden= FALSE;
}

- (void)didReceiveMemoryWarning {
	NSLog(@"LiveScannerViewController - memory warning");
	// we don't want to deallocate this view
}

- (void)viewDidUnload {
	self.prevLayer = nil;
	self.greenbar = nil;
	self.redbar = nil;
}

- (void)dealloc {
	[self.captureSession release];
	[self.prevLayer release];
    [self.currentCaptureDevice release];
	[self.overlayView release];
	[self.greenbar release];
	[self.redbar release];
	[self.reader release];
    [super dealloc];
}


@end