//
//  HelpDisplayViewController.m
//  Cash4Books
//
//  Created by Ben Harris on 2/14/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import "HelpDisplayViewController.h"


@implementation HelpDisplayViewController

@synthesize helpWebView;
@synthesize url;

-(id)initWithURL:(NSURL *)helpURL {
    self = [super initWithNibName:@"HelpDisplayViewController" bundle:nil];
    if (self) {
		url = helpURL;
    }
    return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.title = @"Loading...";
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url 
												  cachePolicy:NSURLRequestReturnCacheDataElseLoad 
											  timeoutInterval:30];
	[self.helpWebView loadRequest:request];
    [request release];
}

- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
	[helpWebView stopLoading];
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

#pragma mark -
#pragma mark UIWebView delegate
- (void)webViewDidFinishLoad:(UIWebView *)webView {
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
	self.title = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    if ([error code] != NSURLErrorCancelled) {
        UIAlertView *loadFailed = [[UIAlertView alloc] initWithTitle:@"Failed to Load Page" 
                                                             message:[error localizedDescription] 
                                                            delegate:nil 
                                                   cancelButtonTitle:@"OK" 
                                                   otherButtonTitles:nil];
        [loadFailed show];
        [loadFailed release];
    }
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSURL *requestURL = [request.URL retain];
    if ((navigationType == UIWebViewNavigationTypeOther) ||
            (navigationType == UIWebViewNavigationTypeLinkClicked)) {
        if (([[requestURL absoluteString] hasPrefix:@"http://maps.google.com"]) ||
            ([[requestURL absoluteString] hasPrefix:@"itms-apps://ax.itunes.apple.com"])) {
            [[UIApplication sharedApplication] openURL:[requestURL autorelease]];
            return NO;
        }
    }
    [requestURL release];
    return YES;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    helpWebView = nil;
}


- (void)dealloc {
    [super dealloc];
    [helpWebView release];
}


@end
