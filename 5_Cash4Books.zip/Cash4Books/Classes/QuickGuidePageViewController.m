//
//  QuickGuidePageViewController.m
//  Cash4Books
//
//  Created by John Kelly on 8/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "QuickGuidePageViewController.h"
#import "QuickGuideViews.h"
#import "C4BSingleton.h"

@implementation QuickGuidePageViewController

@synthesize pageIndex, delegate;

- (void)setPageIndex:(NSInteger)newPageIndex
{
    pageIndex = newPageIndex;
    
    if (pageIndex >= 0 && pageIndex < [[QuickGuideViews sharedQuickGuideViews] numQuickGuideViews]) {
        [self initWithNibName:[[QuickGuideViews sharedQuickGuideViews] nibForPage:pageIndex] bundle:nil];
    }
}

- (void) updatePageView:(BOOL)force
{
}

-(IBAction)doneButtonPressed:(id)sender
{
    if (delegate != nil) {
        [delegate doneButtonPressed];
    }
}

- (void)dealloc
{
    self.delegate = nil;
    
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (pageIndex == 0) {
        //Store preference for future convenience
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setBool:NO forKey:kShowQuickStart];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
