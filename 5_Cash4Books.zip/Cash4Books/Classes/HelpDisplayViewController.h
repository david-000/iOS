//
//  HelpDisplayViewController.h
//  Cash4Books
//
//  Created by Ben Harris on 2/14/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface HelpDisplayViewController : UIViewController <UIWebViewDelegate> {
	IBOutlet UIWebView *helpWebView;
	
	NSURL *url;
}

@property (nonatomic, retain) UIWebView *helpWebView;
@property (nonatomic, retain) NSURL *url;

-(id)initWithURL:(NSURL *)url;

@end
