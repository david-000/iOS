//
//  CheckoutViewController.h
//  Cash4Books
//
//  Created by Ben Harris on 2/18/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckoutViewController : UIViewController <UIWebViewDelegate, UIAlertViewDelegate> {
	IBOutlet UIWebView *checkoutWebView;
	NSURLRequest *request;
    UIAlertView *ratingAlert;
    
    UIBarButtonItem *doneButtonItem;
}

@property (nonatomic, retain) IBOutlet UIWebView *checkoutWebView;
@property (nonatomic, retain) NSURLRequest *request;
@property (nonatomic, retain) UIAlertView *ratingAlert;
@property (nonatomic, retain) UIBarButtonItem *doneButtonItem;

- (id)initWithRequest:(NSURLRequest *)r;
- (void)switchToDone;
- (void)showRatingAlert;

@end
