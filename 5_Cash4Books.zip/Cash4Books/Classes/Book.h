//
//  Book.h
//  Cash4Books
//
//  Created by Ben Harris on 2/17/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DataDownloader.h"
#import "SBJson.h"

#define kPriceUpdated @"PriceDidFinishLoading"

@interface Book : NSObject <DataDownloaderDelegate> {
	NSString *title;
	NSString *author;
	NSString *isbn13;
	NSString *isbn10;
	NSNumber *price;
	NSDate *priceExpiration;
	NSURL *imageURL;
}

@property (nonatomic, retain) NSString *title;
@property (nonatomic, retain) NSString *author;
@property (nonatomic, retain) NSString *isbn13;
@property (nonatomic, retain) NSString *isbn10;
@property (nonatomic, retain) NSNumber *price;
@property (nonatomic, retain) NSDate *priceExpiration;
@property (nonatomic, retain) NSURL *imageURL;

-(id)initWithDictionary:(NSDictionary *)bookDictionary;

-(BOOL)priceExpired;
-(void)updatePrice;

-(NSDictionary *)dictionaryRepresentation;
-(BOOL)isEqualToBook:(Book *)otherBook;

- (NSString *)applyTimezoneFixForDate:(NSString *)date;

@end
