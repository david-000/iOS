//
//  NotAcceptingTableViewCell.m
//  Cash4Books
//
//  Created by Ben Harris on 3/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "NotAcceptingTableViewCell.h"


@implementation NotAcceptingTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.textLabel.backgroundColor = [UIColor clearColor];
        self.detailTextLabel.backgroundColor = [UIColor clearColor];
        
        UIView *expiredOverlay = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320.0, 114.0)];
        expiredOverlay.backgroundColor = [UIColor colorWithRed:0.396 green:0.459 blue:0.506 alpha:0.4];
        
        UIImageView *cellHeader = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tablecellheader.png"]];
        cellHeader.frame = CGRectMake(0, 0, 320.0, 24.0);
        [expiredOverlay addSubview:cellHeader];
        [cellHeader release];
        
        UILabel *expiredLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320.0, 24.0)];
        expiredLabel.text = @"Sorry, we are no longer buying this book:";
        expiredLabel.textColor = [UIColor whiteColor];
        expiredLabel.textAlignment = UITextAlignmentCenter;
        expiredLabel.font = [UIFont boldSystemFontOfSize:15.0];
        expiredLabel.shadowColor = [UIColor grayColor];
        expiredLabel.backgroundColor = [UIColor clearColor];
        [expiredOverlay addSubview:expiredLabel];
        [expiredLabel release];
        
        if ([self.contentView.subviews indexOfObjectIdenticalTo:expiredOverlay] == NSNotFound) {
            [self.contentView addSubview:expiredOverlay];
        }
        
        [expiredOverlay release];
    }
    
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGAffineTransform shiftDown = CGAffineTransformMakeTranslation(0, 10.0);
    self.imageView.frame = CGRectApplyAffineTransform(self.imageView.frame, shiftDown);
    self.textLabel.frame = CGRectApplyAffineTransform(self.textLabel.frame, shiftDown);
    self.detailTextLabel.frame = CGRectApplyAffineTransform(self.detailTextLabel.frame, shiftDown);
    
    self.accessoryView = nil;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc
{
    [super dealloc];
}

@end
