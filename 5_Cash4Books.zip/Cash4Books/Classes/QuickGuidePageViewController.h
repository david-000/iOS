//
//  QuickGuidePageViewController.h
//  Cash4Books
//
//  Created by John Kelly on 8/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol QuickGuidePageViewControllerDelegate
-(void)doneButtonPressed;
@end

@interface QuickGuidePageViewController : UIViewController
{
    NSInteger pageIndex;
	BOOL textViewNeedsUpdate;
    
    id<QuickGuidePageViewControllerDelegate> delegate;
}

@property NSInteger pageIndex;
@property (nonatomic, assign) id<QuickGuidePageViewControllerDelegate> delegate;

- (void)updatePageView:(BOOL)force;

-(IBAction)doneButtonPressed:(id)sender;

@end
