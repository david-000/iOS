//
//  Book.m
//  Cash4Books
//
//  Created by Ben Harris on 2/17/11.
//  Copyright 2011 Good Code. All rights reserved.
//

#import "Book.h"
#import "C4BSingleton.h"


@implementation Book

@synthesize title;
@synthesize author;
@synthesize isbn13;
@synthesize isbn10;
@synthesize price;
@synthesize priceExpiration;
@synthesize imageURL;

-(Book *)initWithDictionary:(NSDictionary *)bookDictionary {
	self = [super init];
	if (self) {
		
		if ([bookDictionary objectForKey:@"title"] == nil) {
			return nil;
		}
		
		title =  [[NSString alloc] initWithString:[bookDictionary objectForKey:@"title"]];
		author = [[NSString alloc] initWithString:[bookDictionary objectForKey:@"author"]];
		isbn13 = [[NSString alloc] initWithString:[bookDictionary objectForKey:@"isbn13"]];
		isbn10 = [[NSString alloc] initWithString:[bookDictionary objectForKey:@"isbn10"]];
		
		NSString *priceString = [[[bookDictionary objectForKey:@"Quote"] objectAtIndex:0] objectForKey:@"price"];
		price = [[NSNumber alloc] initWithFloat:[priceString floatValue]];
				
		// Convert string to date object
		if ([[[[bookDictionary objectForKey:@"Quote"] objectAtIndex:0] objectForKey:@"expiration"] isKindOfClass:[NSDate class]]) {
			priceExpiration = [[[[bookDictionary objectForKey:@"Quote"] objectAtIndex:0] objectForKey:@"expiration"] retain];
		}
		else {
			NSString *expirationString = [[[bookDictionary objectForKey:@"Quote"] objectAtIndex:0] objectForKey:@"expiration"];
			NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
			[dateFormat setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZZZ"];
			priceExpiration = [[dateFormat dateFromString:[self applyTimezoneFixForDate:expirationString]] retain];   
			[dateFormat release];	
		}
		
		imageURL = [[NSURL alloc] initWithString:[[[bookDictionary objectForKey:@"Image"] objectAtIndex:0] objectForKey:@"url"]];
	}
    
	return self;
}

-(BOOL)priceExpired {
	NSDate *now = [NSDate date];
	if ( [now compare:priceExpiration] == NSOrderedDescending )
		return YES;

	return NO;
}

-(void)updatePrice {
	if ( [self priceExpired] ) {
		NSString *urlString = [NSString stringWithFormat:kIsbn13URLFormat, isbn13, nil];
		NSURL *bookURL = [NSURL URLWithString:urlString];
		DataDownloader *dd = [[DataDownloader alloc] init];
		[dd downloadURL:bookURL withDelegate:self tag:0];
	}
}

-(NSDictionary *)dictionaryRepresentation {
	NSDictionary *quoteDictionary = [[NSDictionary alloc] initWithObjectsAndKeys:	[price stringValue], @"price", priceExpiration, @"expiration", nil];
	NSArray *quoteArray = [[NSArray alloc] initWithObjects:quoteDictionary, nil];
	[quoteDictionary release];
	
	NSDictionary *imageDictionary = [[NSDictionary alloc] initWithObjectsAndKeys:[imageURL absoluteString], @"url", nil];
	NSArray *imageArray = [[NSArray alloc] initWithObjects:imageDictionary, nil];
	[imageDictionary release];
	
	NSDictionary *bookDictionary = [NSDictionary dictionaryWithObjectsAndKeys:	title, @"title",
																				author, @"author",
																				isbn13, @"isbn13",
																				isbn10, @"isbn10",
																				quoteArray, @"Quote",
																				imageArray, @"Image", nil];
	[quoteArray release];
	[imageArray release];
	
	return bookDictionary;
}

-(BOOL)isEqualToBook:(Book *)otherBook {
	if ( [isbn13 isEqualToString:otherBook.isbn13] ) {
		return YES;
	}
	
	return NO;
}

- (void)dataLoaded:(NSData *)d tag:(int)t sender:(id)sender backgrounded:(BOOL)backgrounded {
	//Nothing was returned
	if (d == nil) {
		UIAlertView *errorRetrievingInfo = [[UIAlertView alloc] initWithTitle:@"Error"
																	  message:@"Could not retrieve information for book."
																	 delegate:self 
															cancelButtonTitle:@"OK"
															otherButtonTitles:nil];
		[errorRetrievingInfo show];
		[errorRetrievingInfo release];
		return;
	}
		
	//Parse returned JSON
	NSString *jsonString = [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding];
	NSDictionary *bookDictionary = [[NSDictionary alloc] initWithDictionary:[jsonString JSONValue]];
    
    [jsonString release];
	
	NSDictionary *quote = [[bookDictionary objectForKey:@"Quote"] objectAtIndex:0];
	self.price = [[NSNumber alloc] initWithFloat:[[quote objectForKey:@"price"] floatValue]];
    
    [bookDictionary release];
	
	NSString *expirationString = [quote objectForKey:@"expiration"];
	NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
	[dateFormat setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZZZ"];
	self.priceExpiration = [[dateFormat dateFromString:[self applyTimezoneFixForDate:expirationString]] retain];   
	[dateFormat release];
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc postNotificationName:kPriceUpdated object:self];
}

//Removes colon from timezone
- (NSString *)applyTimezoneFixForDate:(NSString *)date {
    NSRange colonRange = [date rangeOfCharacterFromSet:[NSCharacterSet characterSetWithCharactersInString:@":"] options:NSBackwardsSearch];
    return [date stringByReplacingCharactersInRange:colonRange withString:@""];
}

@end
