//
//  KeypadEntryViewController.m
//  Cash4Books
//
//  Created by Ben Harris on 2/2/11.
//  Copyright 2011 Cash4Books. All rights reserved.
//

#import "KeypadEntryViewController.h"
#import "GANTracker.h"

@implementation KeypadEntryViewController

@synthesize isbnField;
@synthesize shadowField;
@synthesize message;
@synthesize keypadView;
@synthesize backspaceButton, getOfferButton;

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.title = @"Keypad";
    
    [self.isbnField setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
    [self.shadowField setValue:[UIColor darkGrayColor] forKeyPath:@"_placeholderLabel.textColor"];
	
	//Enable only one button push at a time
	for (UIView *button in keypadView.subviews) {
		button.exclusiveTouch = YES;
	}
	
	isbnField.textAlignment = UITextAlignmentCenter;
    
    noNetworkView = [[UIImageView alloc] initWithFrame:self.view.frame];
    noNetworkView.backgroundColor = [UIColor whiteColor];
    noNetworkView.image = [UIImage imageNamed:@"nonetwork.png"];
    noNetworkView.contentMode = UIViewContentModeScaleAspectFill;
    noNetworkView.alpha = 0.0;
    [self.view addSubview:noNetworkView];
	
	dd = [[DataDownloader alloc] init];
    
    // Google Analytics
    [[GANTracker sharedTracker] trackPageview:@"/app/keypad" withError:nil];
}

-(void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
    
    if ([[C4BSingleton sharedInstance] currentlyHasNetworkConnection]) {
        noNetworkView.alpha = 0.0;
    }
    else {
        noNetworkView.alpha = 1.0;
    }
	
	//Configure title of back button on the next screen
	UIBarButtonItem *decline = [[UIBarButtonItem alloc] initWithTitle:@"Decline" 
																style:UIBarButtonItemStylePlain
															   target:nil 
															   action:nil];
	self.navigationItem.backBarButtonItem = decline;
	[decline release];
    
    [self clearTextField];
}

- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
	[dd cancel];
}

#pragma mark -
#pragma mark Keypad Functions

//Appends value of button pressed
-(IBAction)entryButtonPressed:(id)sender {
	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
	message.hidden = YES;
	
	if ( [isbnField.text length] > 16 )
		return;
	
	UIButton *buttonPressed = (UIButton *)sender;
	NSString *toAppend = buttonPressed.currentTitle;
	
	isbnField.text = [isbnField.text stringByAppendingString:toAppend];
	shadowField.text = isbnField.text;
	
	[self formatIsbnField];
}

-(IBAction)backspace {
	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
	message.hidden = YES;
	
	if ( [isbnField.text length] > 0 ) {
		
		//Check if the character before the last character is a hyphen
		BOOL hyphenDeleted = NO;
		if ( [isbnField.text characterAtIndex:[isbnField.text length]-2] == '-') {
			//delete letter and hyphen
			isbnField.text = [isbnField.text substringToIndex:[isbnField.text length]-2];
			shadowField.text = isbnField.text;
			hyphenDeleted = YES;
		}
		
		//delete whole prefix if ISBN-13
		if ( ([isbnField.text isEqualToString:@"978"] || [isbnField.text isEqualToString:@"979"]) && !hyphenDeleted ) {
			isbnField.text = @"";
			shadowField.text = isbnField.text;
			return;
		}
		
		//Delete last character if it wasn't already deleted with the hyphen before it
		if ( !hyphenDeleted ) {
			isbnField.text = [isbnField.text substringToIndex:[isbnField.text length]-1];
			shadowField.text = isbnField.text;
		}
	}
}

-(IBAction)getOffer {	
	NSString *strippedISBN = [isbnField.text stringByReplacingOccurrencesOfString:@"-" withString:@""];
	
	if ( [[C4BSingleton sharedInstance] isValidIsbn10:strippedISBN] ) {
        // Google Analytics
        [[GANTracker sharedTracker] trackEvent:@"Quotes" action:@"Keypad" label:isbnField.text value:-1 withError:nil];
        
		NSString *urlString = [NSString stringWithFormat:kIsbn10URLFormat, strippedISBN, nil];
		NSURL *bookURL = [NSURL URLWithString:urlString];
		[dd downloadURL:bookURL withDelegate:self tag:0];
		message.text = @"Retrieving book info...";
		message.hidden = NO;
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	}
	else if ( [[C4BSingleton sharedInstance] isValidIsbn13:strippedISBN] ) {
        // Google Analytics
        [[GANTracker sharedTracker] trackEvent:@"Quotes" action:@"Keypad" label:isbnField.text value:-1 withError:nil];
        
		NSString *urlString = [NSString stringWithFormat:kIsbn13URLFormat, strippedISBN, nil];
		NSURL *bookURL = [NSURL URLWithString:urlString];
		[dd downloadURL:bookURL withDelegate:self tag:0];
		message.text = @"Retrieving book info...";
		message.hidden = NO;
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
	}
	else {
		[UIView beginAnimations:@"Error" context:nil];
		self.view.backgroundColor = [UIColor redColor];
		message.text = @"Not a valid ISBN";
		message.hidden = NO;
		[UIView commitAnimations];
	}
}

//Hyphenates ISBN
-(void)formatIsbnField {
	isbnField.text = [[C4BSingleton sharedInstance] formatISBN:isbnField.text];
	shadowField.text = isbnField.text;
}

#pragma mark -
#pragma mark Text Field Delegate

//Prevent native keyboard from appearing
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
	return NO;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
	shadowField.text = @"";
	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
	[dd cancel];
	message.hidden = YES;
	return YES;
}

#pragma mark -
#pragma mark Data Downloader delegate
- (void)dataLoaded:(NSData *)d tag:(int)t sender:(id)sender backgrounded:(BOOL)backgrounded {
	[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
	message.hidden = YES;
	
	if (d == nil) {
		UIAlertView *errorRetrievingInfo = [[UIAlertView alloc] initWithTitle:@"Error"
																	  message:@"Could not retrieve information for book."
																	 delegate:self 
															cancelButtonTitle:@"OK"
															otherButtonTitles:nil];
		[errorRetrievingInfo show];
		[errorRetrievingInfo release];
		return;
	}
	
	NSString *jsonString = [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding];
	NSDictionary *bookDictionary = [[NSDictionary alloc] initWithDictionary:[jsonString JSONValue]];
	Book *book = [[Book alloc] initWithDictionary:bookDictionary];
	
	if ( book == nil ) {
		UIAlertView *errorRetrievingInfo = [[UIAlertView alloc] initWithTitle:@"Error"
																	  message:@"Could not retrieve information for book."
																	 delegate:self 
															cancelButtonTitle:@"OK"
															otherButtonTitles:nil];
		[errorRetrievingInfo show];
		[errorRetrievingInfo release];
		
		[[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
		
		[jsonString release];
		[bookDictionary release];
		[dd clearData];
		return;
	}
    
    if ([book priceExpired]) {
        book.priceExpiration = [[NSDate date] dateByAddingTimeInterval:300];
    }
	
	C4BSingleton *singleton = [C4BSingleton sharedInstance];
	
	//Set the back button title for the next screen if the book is already in the list or if we are not accepting book
	if ( [singleton.bookList contains:book] || ![singleton currentlyAcceptingBook:book] ) {
		UIBarButtonItem *keypadButton = [[UIBarButtonItem alloc] initWithTitle:@"Keypad" 
																		  style:UIBarButtonItemStylePlain
																		 target:nil 
																		 action:nil];
		self.navigationItem.backBarButtonItem = keypadButton;
		[keypadButton release];
	}
	
	BookDetailViewController *bookDetailViewController = [[BookDetailViewController alloc] initWithBook:book];
	[self.navigationController pushViewController:bookDetailViewController animated:YES];
		
	[jsonString release];
	[bookDictionary release];
	[book release];
	[bookDetailViewController release];
	
	[dd clearData];
}

- (void)clearTextField {
    isbnField.text = @"";
    shadowField.text = @"";
	self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
	message.hidden = YES;
}

#pragma mark -
#pragma mark Reachability
- (void)reachabilityChanged:(NSNotification *)notification {
    Reachability* curReach = [notification object];
	NSParameterAssert([curReach isKindOfClass: [Reachability class]]);
    
	[UIView beginAnimations:@"Show/HideNoNetworkView" context:nil];
    if ([curReach currentReachabilityStatus] == NotReachable) {
        self.navigationController.navigationBarHidden = YES;
        noNetworkView.alpha = 1.0;
    }
    else {
        self.navigationController.navigationBarHidden = NO;
        noNetworkView.alpha = 0.0;
    }
    [UIView commitAnimations];
}

#pragma mark -
#pragma mark Memory Management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    isbnField = nil;
	shadowField = nil;
    message = nil;
    keypadView = nil;
    backspaceButton = nil;
    getOfferButton = nil;
    noNetworkView = nil;
}


- (void)dealloc {
    [super dealloc];
    [isbnField release];
    [shadowField release];
    [message release];
    [keypadView release];
    [backspaceButton release];
    [getOfferButton release];
    [noNetworkView release];
    [dd release];
    
}


@end
