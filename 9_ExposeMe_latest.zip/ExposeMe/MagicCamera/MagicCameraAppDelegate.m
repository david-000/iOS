//
//  AppDelegate.m
//  MagicCamera
//
//  Created by i Pro on 2/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MagicCameraAppDelegate.h"

#import "MagicCameraViewController.h"
#import "MKStoreManager.h"
#import "SHKActivityIndicator.h"

static NSString* kAppId = @"244749152274325";
static NSString* kAppSecret = @"e82992712bf417c663478c68f89875a4";


@implementation MagicCameraAppDelegate

@synthesize window = _window;
@synthesize viewController = _viewController;


@synthesize m_bFavrouiteOK;
@synthesize m_imgFavourite;



- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{

    return YES;
}

+ (MagicCameraAppDelegate *)sharedDelegate
{
    return (MagicCameraAppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void)dealloc
{
    [_window release];
    [_viewController release];
    [navigationController release];

    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{

    //in app
    [MKStoreManager sharedManager];

    
    m_imgFavourite = nil;
    
    g_AppUtils = [[MagicCameraAppUtils alloc] init];
    [g_AppUtils readAppSettings];

    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];

    // Override point for customization after application launch.
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        self.viewController = [[[MagicCameraViewController alloc] initWithNibName:@"MagicCameraViewController_iPhone" bundle:nil] autorelease];
    } else {
        self.viewController = [[[MagicCameraViewController alloc] initWithNibName:@"MagicCameraViewController_iPad" bundle:nil] autorelease];
    }
	navigationController = [[UINavigationController alloc] initWithRootViewController:self.viewController];
	navigationController.navigationBarHidden = YES;
	// Override point for customization after app launch. 
    [self.window addSubview:navigationController.view];
    
    [self.window makeKeyAndVisible];

    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
    
    [self.viewController appWillResignActive];
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
    
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    /*
     Called when the application is about to terminate.
     Save data if appropriate.
     See also applicationDidEnterBackground:.
     */
}

#pragma mark - sound method
- (void)playSE:(int)type {
    
    NSString* str;
    NSString *path;
    if (type == SE_SHUTTERSTART) {
        if( ![g_AppUtils useVolumeEffect ] )
            return;
        str = @"shutterstart";
        [self stopSE];
       path = [[NSBundle mainBundle] pathForResource:str ofType:@"mp3"];        
    }
    else if( type == SE_SHUTTEREND ){
        if( ![g_AppUtils useVolumeEffect ] )
            return;
        str = @"shutterend";
        [self stopSE];
        path = [[NSBundle mainBundle] pathForResource:str ofType:@"mp3"];
    }else if( type == SE_EFFECT ){
        if( ![g_AppUtils useSoundEffect ] )
            return;
        str = @"click";
        [self stopSE];
        path = [[NSBundle mainBundle] pathForResource:str ofType:@"caf"];
    }
    

	NSURL *url = [NSURL fileURLWithPath:path];
	NSError *error = nil;
	m_audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL: url error: (NSError**)&error];
	if (error != nil)
	{
		m_audioPlayer = nil;
		return;
	}
    //	m_audioPlayer.delegate = self;
	[m_audioPlayer play];
    
}

- (BOOL)isPlayingSE {
	return (m_audioPlayer != nil) ? TRUE : FALSE;
}
- (void)stopSE
{
	if (m_audioPlayer != nil) {
		[m_audioPlayer stop];
		[m_audioPlayer release];
		m_audioPlayer = nil;
	}	
}

#pragma mark audio
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)thePlayer successfully:(BOOL)flag {
	if (thePlayer == m_audioPlayer) {
		[self stopSE];
	}
}

- (void)audioPlayerEndInterruption:(AVAudioPlayer *)thePlayer{
}

#pragma mark - inapp
- (void)checkPurchased
{
//    if ( [MKStoreManager featureBPurchased] ) // light - B
//    {
//        [dataManager.m_dicHasSwords setObject:[NSNumber numberWithBool:YES] forKey:[NSString stringWithFormat:@"%i", IT_LIGHT]];
//        [dataManager.m_dicGotAchievements setObject:[NSNumber numberWithBool:YES] forKey:[NSString stringWithFormat:@"%i", ACT_GET_WEAPON_2]];
//        [dataManager saveSetting];
//    }
//    
//    if ( [MKStoreManager featureAPurchased] ) // demon - A
//    {
//        [dataManager.m_dicHasSwords setObject:[NSNumber numberWithBool:YES] forKey:[NSString stringWithFormat:@"%i", IT_DEMON]];
//        [dataManager.m_dicGotAchievements setObject:[NSNumber numberWithBool:YES] forKey:[NSString stringWithFormat:@"%i", ACT_GET_WEAPON_3]];
//        [dataManager saveSetting];
//    }
//    
//    if (dataManager.m_bRated)
//        [self unlockItem:IT_LONG];
//    if (dataManager.m_bSharedT || dataManager.m_bSharedF)
//        [self unlockItem:IT_HOLY];
}

//- (void)unlockItem:(ITEM_TYPE)type
//{
//    if (type == IT_LONG)
//    {
//        [dataManager.m_dicHasSwords setObject:[NSNumber numberWithBool:YES] forKey:[NSString stringWithFormat:@"%i", IT_LONG]];
//        dataManager.m_bRated = YES;
//    }
//    else if (type == IT_HOLY)
//    {
//        [dataManager.m_dicHasSwords setObject:[NSNumber numberWithBool:YES] forKey:[NSString stringWithFormat:@"%i", IT_HOLY]];
//        [dataManager.m_dicGotAchievements setObject:[NSNumber numberWithBool:YES] forKey:[NSString stringWithFormat:@"%i", ACT_GET_WEAPON_1]];
//        
//        dataManager.m_bSharedT = YES;
//        dataManager.m_bSharedF = YES;
//    }
//    [dataManager saveSetting];
//}

- (void)sendToFacebook:(UIImage*) image
{
    NSString *strMsg = @"";
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
        strMsg = @"uploaded via Slow Shutter Camera for iPhone";
    else
        strMsg = @"uploaded via Slow Shutter Camera for iPad";
    
    m_postImage = [image retain];
    
	FacebookManager* myFacebook = [FacebookManager sharedInstance];
	[myFacebook setDelegate: self];
	if ( [[myFacebook facebook] isSessionValid]) {
        [[FacebookManager sharedInstance] postMessage: strMsg andCaption: strMsg andImage: image];
    }
}

- (void)sendToTwitter:(UIImage*) image
{
    NSString *strMsg = @"";
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
        strMsg = @"uploaded via Slow Shutter Camera for iPhone";
    else
        strMsg = @"uploaded via Slow Shutter Camera for iPad";
    
//    [self sendToSocial:@"SHKTwitter" message:strMsg image:image];
    
    TwitterManager *tmanager = [TwitterManager sharedTwitterManager];
    [tmanager setDelegate:nil];
    [tmanager setDelegate:self];
    
    NSString* favoriteNamesText = strMsg;
    
    
    if ([[tmanager engine] isAuthorized]) 
    {
        [self startAnimating];
        if (image) {
            [tmanager postImage:image message:favoriteNamesText];
        }
        else {
            [tmanager postMessage:favoriteNamesText];
        }
        
    }
    else 
    {
        twitterMessage = [[NSDictionary alloc] initWithObjectsAndKeys:favoriteNamesText,@"text",image,@"image", nil];
        [tmanager authorizeUserFromController:self.viewController];
    }
    //    [autoreleasePool release];
    

}

#pragma mark - social

- (void)sendToSocial:(NSString*)snsType message:(NSString*)message image:(UIImage*) image
{
/*
    [SHK flushOfflineQueue];
    
    NSString* path =[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/twitter.jpg"];
    [self saveImageToDocument:path image:image];
    
	UIImage *img = [UIImage imageWithContentsOfFile:path];
    NSData *JPEGData = UIImageJPEGRepresentation(img, 1.0);
    
    SHKItem* item = [SHKItem  file:JPEGData filename:@"ExposeMe" mimeType:@"jpg" title:@"ExposeMe"];
    
    [NSClassFromString(snsType) performSelector:@selector(shareItem:) withObject:item];
    //[SHK setRootViewController:viewController];
    
    //NSArray* favoriteSharers = [SHK favoriteSharersForType:item.shareType];
    //int number = [favoriteSharers indexOfObject:snsType];
    //if (number == NSNotFound)
    //    return;
    //[NSClassFromString([favoriteSharers objectAtIndex:number]) performSelector:@selector(shareItem:) withObject:item];
*/ 
}

- (void) saveImageToDocument:(NSString*)strPath image:(UIImage*)image
{
    NSData* writeData = UIImageJPEGRepresentation(image, 1.0);
    [writeData writeToFile:strPath atomically:YES];
}


#pragma --------- Facebook & Twitter ---------
#pragma mark -----------------------------


- (void) startAnimating {
    [[SHKActivityIndicator currentIndicator] displayActivity:@"Loading..."];  
}

- (void) stopAnimating {
    [[SHKActivityIndicator currentIndicator] hide];
}

- (void) messagePostedSuccessfully
{
    [self stopAnimating];
    
    UIAlertView* alert = [[UIAlertView alloc] initWithTitle: nil message: @"Thanks for sharing." delegate: self cancelButtonTitle: @"OK" otherButtonTitles: nil];
    [alert show];
    [alert release];
}



// ----------------------------------------------------------------------------
#pragma mark TwitterManager Delegate methods
// ----------------------------------------------------------------------------
- (void)twitterManager:(TwitterManager *)manager didAuthenticateUser:(NSString *)username {
    if (twitterMessage) {
        [self startAnimating];
        TwitterManager *tManager = [TwitterManager sharedTwitterManager];
        [tManager setDelegate:nil];
        [tManager setDelegate:self];
        
        if ([twitterMessage objectForKey:@"image"]) {
            [tManager postImage:[twitterMessage objectForKey:@"image"] message:[twitterMessage objectForKey:@"text"]];
        }
        else {
            [tManager postMessage:[twitterMessage objectForKey:@"text"]];
        }
        [twitterMessage release], twitterMessage = nil;
    }
}

- (void)twitterManager:(TwitterManager *)manager failedToAuthenticateWithError:(NSError *)error {
    [self stopAnimating];
    
    if (twitterMessage) {
        [twitterMessage release], twitterMessage = nil;
    }
    
    /*    
     UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error"
     message:@"Posting fail" 
     delegate:nil
     cancelButtonTitle:@"YES" 
     otherButtonTitles:nil, nil];
     [alert show];
     [alert release];
     */    
    
}

- (void)twitterManager:(TwitterManager *)manager didPostMessage:(NSError *)error {
    [self stopAnimating];
    if (!error) {
        [self  messagePostedSuccessfully];
    }
    else{
        NSLog(@"Error = %@", error);
        /*        
         UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error"
         message:@"Posting fail" 
         delegate:nil
         cancelButtonTitle:@"YES" 
         otherButtonTitles:nil, nil];
         [alert show];
         [alert release];
         */ 
    }
    
}


- (void)twitterManager:(TwitterManager *)manager didPostImage:(NSError *)error {
    [self stopAnimating];
    if (!error) {
        [self messagePostedSuccessfully];
    }
    else{
        NSLog(@"Error = %@", error);
        /*        
         UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error"
         message:@"Posting fail" 
         delegate:nil
         cancelButtonTitle:@"YES" 
         otherButtonTitles:nil, nil];
         [alert show];
         [alert release];
         */        
    }
}


#pragma mark FacebookManagerDelegate Methods
- (void) facebookLoginSucceeded 
{
    [self startAnimating];
    
    NSString *strMsg = @"";
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
        strMsg = @"uploaded via Slow Shutter Camera for iPhone";
    else
        strMsg = @"uploaded via Slow Shutter Camera for iPad";
    
    
	NSString * favoriteNamesText = strMsg;

    if (m_postImage != nil) {
        [[FacebookManager sharedInstance] postMessage: favoriteNamesText andCaption: favoriteNamesText andImage: m_postImage];
    } else {
        NSLog(@"m_postimage is error");
    }
	
    
}

- (void) facebookLoginFailed {
    NSLog(@"facebook login failed");
    [self stopAnimating];
    
}


- (void) messagePostingFailedWithError:(NSError *)error {
    [self stopAnimating];
    /*    
     UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Error"
     message:@"Posting Fail"
     delegate:nil
     cancelButtonTitle:@"YES"
     otherButtonTitles:nil, nil];
     [alert show];
     [alert release];
     */ 
}

#pragma mark ---------
-(void) insertVolumnView{
    CGRect frame = CGRectMake(0, -100, 10, 0);
    volumeView = [[MPVolumeView alloc] initWithFrame:frame];
    [volumeView sizeToFit];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0] addSubview:volumeView];
}

-(void) removeVolumnView{
    if (volumeView != nil) {
        [volumeView removeFromSuperview];
        [volumeView release];
        volumeView = nil;
    }
}

@end
