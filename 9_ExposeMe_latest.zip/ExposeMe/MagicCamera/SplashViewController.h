//
//  SplashViewController.h
//  MagicCamera
//
//  Created by  on 12/02/23.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SplashViewControllerDelegate <NSObject>

- (void) onExitSplash;

@end

@interface SplashViewController : UIViewController {
    id<SplashViewControllerDelegate> delegate;
}

@property(nonatomic, assign) id<SplashViewControllerDelegate> delegate;

- (void) goToAdHome;
- (IBAction) onExit:(id)sender;

@end
