//
//  InfoViewController.h
//
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MagicCameraAppDelegate.h"

@interface InfoViewController : UIViewController{
    
    IBOutlet UITextView * m_textView1;
    IBOutlet UITextView * m_textView2;    
    
}

- (IBAction)onOk:(id)sender;
- (IBAction)onCancel:(id)sender;

@end
