//
//  InfoViewController.m
//
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "InfoViewController.h"
#import "MagicCameraAppUtils.h"


@interface InfoViewController ()

@end

@implementation InfoViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void) dealloc{
    
    [ super dealloc ];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)onOk:(id)sender{
    UIAlertView *alt = [[UIAlertView alloc]initWithTitle:@"Update"
                                                 message:@"Please go to the app store for the paid version" 
                                                delegate:self 
                                       cancelButtonTitle:@"Cancel"
                                       otherButtonTitles:@"OK", nil];
    [alt show];
    [alt release];
}

- (IBAction)onCancel:(id)sender{
    
    [ self dismissModalViewControllerAnimated:YES ];

}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url_paid]];
    }

}

#pragma mark ----------- TextView delegate -----------
- (BOOL) textViewShouldBeginEditing:(UITextView*) textView
{
    return NO;
}

@end
