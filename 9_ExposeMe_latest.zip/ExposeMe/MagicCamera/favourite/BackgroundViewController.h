//
//  BackgroundViewController.h
//  KidSong
//
//  Created by  on 12-6-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MagicCameraAppDelegate.h"

#define ARRAY_KEY_IAMGE     @"_key_image_"
#define ARRAY_KEY_FILENAME  @"_key_filename_"
#define ARRAY_KEY_SELECTED  @"_key_seleted_"


@interface BackgroundViewController : UIViewController<UIGestureRecognizerDelegate>{
    
    IBOutlet    UIBarButtonItem *m_btnOK;
    IBOutlet    UIBarButtonItem *m_btnCancel;
    
    UIScrollView *m_scrollview;
    
    int         m_nSelectedIndex;
    UIImageView *m_viewCheck;
    
    NSMutableArray *m_imgViews;

    MagicCameraAppDelegate  *appDelegate;
    
    BOOL m_bEditing;
    
}


@property (nonatomic, retain )  IBOutlet    UIBarButtonItem *m_btnOK;
@property (nonatomic, retain )  IBOutlet    UIBarButtonItem *m_btnCancel;

- (IBAction)onOk:(id)sender;
- (IBAction)onCancel:(id)sender;

- (void) openImage;
- (void) setSelection:(int)nIndex button:(UIButton*)button;

- (void) deleteSelImages;


@end
