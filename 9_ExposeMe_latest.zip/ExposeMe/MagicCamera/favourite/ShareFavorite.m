//
//  ShareFavorite.m
//  ExposeMe
//
//  Created by Gold Luo on 8/7/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ShareFavorite.h"

static ShareFavorite* instance = nil;

@implementation ShareFavorite

@synthesize imgArray;

+ (ShareFavorite*) instance
{
    if (instance == nil) {
        instance = [[ShareFavorite alloc] init];
    }
    
    return instance;
}

@end
