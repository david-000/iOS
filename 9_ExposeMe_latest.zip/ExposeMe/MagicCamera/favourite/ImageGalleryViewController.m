//
//  ImageGalleryViewController.m
//
//  Created by  on 12-6-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ImageGalleryViewController.h"
#import "MagicCameraAppDelegate.h"
#import "ShareFavorite.h"
#import "BackgroundViewController.h"

@interface ImageGalleryViewController ()

@end

@implementation ImageGalleryViewController

@synthesize m_nSelected;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
//    MagicCameraAppDelegate  *appDelegate = (MagicCameraAppDelegate *)[ [ UIApplication sharedApplication ] delegate ];
//    [ m_imgViewPhoto    setImage:appDelegate.m_imgFavourite ];
    
    
    m_scrollview = [[DDScrollView alloc]
                             initWithFrame:CGRectMake(0,
							  0,
							  viewMain.frame.size.width,
							  viewMain.frame.size.height)];
	m_scrollview.delegate = self;
    m_scrollview.dataSource = self;
    
    [viewMain addSubview:m_scrollview];
    [m_scrollview release];
    
    m_scrollview.centerPageIndex = m_nSelected;
    
    [titleBar setHidden:YES];
    titleBar.topItem.title = [NSString stringWithFormat:@"%d of %d", self.m_nSelected+1, [[ShareFavorite instance].imgArray count]];
    
    
    UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapRecognized:)];
    tapGesture.delegate = self;
    tapGesture.numberOfTapsRequired = 1;
    [m_scrollview addGestureRecognizer:tapGesture];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark ---------- Gesture ------
-(void) tapRecognized : (UITapGestureRecognizer*) sender {
    
    if ([titleBar isHidden]) {
        [titleBar setHidden:NO];
    } else {
        [titleBar setHidden:YES];
    }
}

#pragma mark ------- DDLScroll delegate -------------

- (NSInteger)numberOfPagesInScrollView:(DDScrollView*)scrollView {
    return [[ShareFavorite instance].imgArray count];
}

/**
 * Gets a view to display for the page at the given index.
 *
 * You do not need to position or size the view as that is done for you later.  You should
 * call dequeueReusablePage first, and only create a new view if it returns nil.
 */
- (UIView*)scrollView:(DDScrollView*)scroll_ pageAtIndex:(NSInteger)pageIndex {
    
    int currentPage = pageIndex;
    
    // Populate scroll views
    NSMutableDictionary* pic = [[ShareFavorite instance].imgArray objectAtIndex:currentPage];
    
    UIImage *image = [pic objectForKey:ARRAY_KEY_IAMGE];
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, scroll_.frame.size.width, scroll_.frame.size.height)];
    imageView.backgroundColor = [UIColor clearColor];
    [imageView setContentMode:UIViewContentModeScaleAspectFit];
//    [imageView setClipsToBounds:YES];
    [imageView setImage:image];
    
    return [imageView autorelease];
}

/**
 * Gets the natural size of the page.
 *
 * The actual width and height are not as important as the ratio between width and height.
 *
 * If the size is not specified, then the size of the page is used.
 */
- (CGSize)scrollView:(DDScrollView*)scroll_ sizeOfPageAtIndex:(NSInteger)pageIndex {
    
    return CGSizeMake(scroll_.frame.size.width, scroll_.frame.size.height);
}

- (void)scrollView:(DDScrollView*)scrollView didMoveToPageAtIndex:(NSInteger)pageIndex {
    
    m_nSelected = pageIndex;
    
    NSMutableDictionary* pic = [[ShareFavorite instance].imgArray objectAtIndex:m_nSelected];
    
    UIImage *image = [pic objectForKey:ARRAY_KEY_IAMGE];

    
    MagicCameraAppDelegate *appDelegate = ( MagicCameraAppDelegate *)[ [ UIApplication sharedApplication ] delegate ];
    if( appDelegate.m_imgFavourite != nil )
        [ appDelegate.m_imgFavourite    release ];
    appDelegate.m_imgFavourite  =   nil;
    
    appDelegate.m_imgFavourite = [ [ UIImage imageWithCGImage:[ image CGImage ] ] retain ];

    [titleBar setHidden:YES];
    titleBar.topItem.title = [NSString stringWithFormat:@"%d of %d", self.m_nSelected+1, [[ShareFavorite instance].imgArray count]];
}







#pragma mark  --------------------------

- (IBAction)onClose:(id)sender{
    [ self dismissModalViewControllerAnimated:YES ];
    
}

- (IBAction)onAction:(id)sender
{
#ifdef FREE_VERSION    
    UIActionSheet* action = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Delete" otherButtonTitles:nil];
#else
    UIActionSheet* action = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Delete" otherButtonTitles:@"Facebook", @"Twitter", @"Email", nil];
#endif
    [action showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    MagicCameraAppDelegate *_delegate = (MagicCameraAppDelegate*)[[UIApplication sharedApplication] delegate];
    
#ifdef FREE_VERSION
    if (buttonIndex >= 1) {
        return;
    }
#endif
    
    if (buttonIndex == 0) { //delete
        [self deleteSelImages];
    }
    else if (buttonIndex == 1) {
        [_delegate sendToFacebook:_delegate.m_imgFavourite];
    } 
    else if (buttonIndex == 2) {//twitter
        [_delegate sendToTwitter:_delegate.m_imgFavourite];
    } 
    else if (buttonIndex == 3) {//Email
        [self onEmail];
    } 
}

- (void) setSelectedImageIndex:(int) _index;
{
    self.m_nSelected = _index;
}

- (void) deleteSelImages
{
    if (m_nSelected < 0 || m_nSelected >= [[ShareFavorite instance].imgArray count]) {
        NSLog(@"image size overflow========================");
        return;
    }

    NSMutableDictionary * dic = [[ShareFavorite instance].imgArray objectAtIndex:m_nSelected];
    
    NSString *filePath = [dic objectForKey:ARRAY_KEY_FILENAME];
    
    if( [ [ NSFileManager defaultManager ] fileExistsAtPath:filePath ])
        [[ NSFileManager defaultManager ] removeItemAtPath:filePath error:nil];
    
    
    [[ShareFavorite instance].imgArray removeObjectAtIndex:m_nSelected];
    [m_scrollview reloadData];
    
    if ([[ShareFavorite instance].imgArray count] == 0) {
        [self dismissModalViewControllerAnimated:YES ];        
        return;
    }
    
    if (m_nSelected >= [[ShareFavorite instance].imgArray count] ) {
        m_nSelected = [[ShareFavorite instance].imgArray count] - 1;
    }    
    [m_scrollview setCenterPageIndex:m_nSelected];
}

#pragma mark - email method
- (void) onEmail {
    
    MagicCameraAppDelegate* _delegate = (MagicCameraAppDelegate*)[[UIApplication sharedApplication] delegate];
    
	if (![MFMailComposeViewController canSendMail]) {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No Mail Accounts" message:@"Please set up a Mail account in order to send email."
													   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];	
		[alert release];
		return;
	}
	MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
	picker.mailComposeDelegate = self;
	
	NSString* content;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
        content = @"sent via ExposeMe for iPhone";
    else
        content = @"sent via ExposeMe for iPad";
    
	[picker setSubject:@"Check out this image I took with ExposeMe"];
	
//    NSMutableArray *emailAddrs = [[NSMutableArray alloc] init];
//	NSString *emailAddr = @"frozenmonkeyapps@gmail.com";
//    [emailAddrs addObject: emailAddr];
//	[picker setToRecipients: emailAddrs];

    
	NSString* path =[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/email.jpg"];
	[_delegate saveImageToDocument:path image:_delegate.m_imgFavourite];
	
//	[picker setMessageBody:content isHTML:NO]; 
	[picker addAttachmentData:[NSData dataWithContentsOfFile:path] mimeType:@"image/jpg" fileName:@"image.jpg"];
	
	picker.navigationBar.barStyle = UIBarStyleDefault; 
	
	[self presentModalViewController:picker animated:YES];
	[picker release];
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{ 
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
			break;
		case MFMailComposeResultSaved:
			break;
		case MFMailComposeResultSent:
        {
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Email" message:@"Email sent!"
														   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
			[alert show];
			[alert release];
		}
			break;
		case MFMailComposeResultFailed:
			break;
			
		default:
		{
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Email" message:@"Sending Failed - Unknown Error :-("
														   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
			[alert show];
			[alert release];
		}
			
			break;
	}
	[self dismissModalViewControllerAnimated:YES];
}

@end
