//
//  ImageViewController.m
//  MagicCamera
//
//  Created by  on 12-6-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ImageViewController.h"
#import "MagicCameraAppDelegate.h"

@interface ImageViewController ()

@end

@implementation ImageViewController
@synthesize m_imgViewPhoto;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    MagicCameraAppDelegate  *appDelegate = (MagicCameraAppDelegate *)[ [ UIApplication sharedApplication ] delegate ];
    [ m_imgViewPhoto    setImage:appDelegate.m_imgFavourite ];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)onClose:(id)sender{
    [ self dismissModalViewControllerAnimated:YES ];
    
}

- (IBAction)onAction:(id)sender
{
#ifdef FREE_VERSION    
    UIActionSheet* action = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Delete", nil];
#else
    UIActionSheet* action = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Delete", @"Facebook", @"Twitter", @"Email", nil];
#endif
    [action showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    MagicCameraAppDelegate *_delegate = (MagicCameraAppDelegate*)[[UIApplication sharedApplication] delegate];
    
#ifdef FREE_VERSION
    if (buttonIndex >= 1) {
        return;
    }
#endif
    
    if (buttonIndex == 0) { //delete
        [self deleteSelImages];
    }
    else if (buttonIndex == 1) {
        [_delegate sendToFacebook:_delegate.m_imgFavourite];
    } 
    else if (buttonIndex == 2) {//twitter
        [_delegate sendToTwitter:_delegate.m_imgFavourite];
    } 
    else if (buttonIndex == 3) {//Email
        [self onEmail];
    } 
}

- (void) setFilePath:(NSString *)sFilePath
{
    m_sFilePath = sFilePath;
}

- (void) deleteSelImages
{
    if( [ [ NSFileManager defaultManager ] fileExistsAtPath:m_sFilePath ])
        [[ NSFileManager defaultManager ] removeItemAtPath:m_sFilePath error:nil];
    
    [ self dismissModalViewControllerAnimated:YES ];
}

#pragma mark - email method
- (void) onEmail {
    
    MagicCameraAppDelegate* _delegate = (MagicCameraAppDelegate*)[[UIApplication sharedApplication] delegate];
    
	if (![MFMailComposeViewController canSendMail]) {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No Mail Accounts" message:@"Please set up a Mail account in order to send email."
													   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];	
		[alert release];
		return;
	}
	MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
	picker.mailComposeDelegate = self;
	
	NSString* content;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
        content = @"sent via ExposeMe for iPhone";
    else
        content = @"sent via ExposeMe for iPad";
    
	[picker setSubject:@"ExposeMe Feedback"];
	
    NSMutableArray *emailAddrs = [[NSMutableArray alloc] init];
    
	NSString *emailAddr = @"frozenmonkeyapps@gmail.com";
    [emailAddrs addObject: emailAddr];
	[picker setToRecipients: emailAddrs];

    
	NSString* path =[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/email.jpg"];
	[_delegate saveImageToDocument:path image:_delegate.m_imgFavourite];
	
//	[picker setMessageBody:content isHTML:NO]; 
	[picker addAttachmentData:[NSData dataWithContentsOfFile:path] mimeType:@"image/jpg" fileName:@"image.jpg"];
	
	picker.navigationBar.barStyle = UIBarStyleDefault; 
	
	[self presentModalViewController:picker animated:YES];
	[picker release];
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{ 
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
			break;
		case MFMailComposeResultSaved:
			break;
		case MFMailComposeResultSent:
        {
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Email" message:@"Email sent!"
														   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
			[alert show];
			[alert release];
		}
			break;
		case MFMailComposeResultFailed:
			break;
			
		default:
		{
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Email" message:@"Sending Failed - Unknown Error :-("
														   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
			[alert show];
			[alert release];
		}
			
			break;
	}
	[self dismissModalViewControllerAnimated:YES];
}

@end
