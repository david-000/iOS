//
//  ImageViewController.h
//  MagicCamera
//
//  Created by  on 12-6-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MessageUI/MFMailComposeViewController.h>
#import <MessageUI/MessageUI.h>

#import "MagicCameraAppUtils.h"


@interface ImageViewController : UIViewController<MFMailComposeViewControllerDelegate,UIActionSheetDelegate>
{
    IBOutlet    UIImageView *m_imgViewPhoto;
    
    NSString *m_sFilePath;
    
}

- (IBAction)onClose:(id)sender;
- (IBAction)onAction:(id)sender;

- (void) setFilePath:(NSString *)sFilePath;

- (void) deleteSelImages;

@property (nonatomic, retain )  IBOutlet UIImageView * m_imgViewPhoto;

@end
