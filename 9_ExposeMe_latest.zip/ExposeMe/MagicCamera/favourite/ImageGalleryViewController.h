//
//  ImageGalleryViewController.h
//
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MessageUI/MFMailComposeViewController.h>
#import <MessageUI/MessageUI.h>

#import "MagicCameraAppUtils.h"

#import "DDScrollView.h"


@interface ImageGalleryViewController : UIViewController<DDScrollViewDelegate, DDScrollViewDataSource, MFMailComposeViewControllerDelegate,UIActionSheetDelegate, UIGestureRecognizerDelegate>
{
    IBOutlet UINavigationBar * titleBar;
    
    IBOutlet UIView * viewMain;
    
    DDScrollView* m_scrollview;
    
}

@property(nonatomic, assign) int m_nSelected;



- (IBAction)onClose:(id)sender;
- (IBAction)onAction:(id)sender;

- (void) deleteSelImages;

@end
