//
//  BackgroundViewController.m
//  KidSong
//
//  Created by  on 12-6-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "BackgroundViewController.h"
#import "MagicCameraAppDelegate.h"
#import "MagicCameraViewController.h"
#import "ImageViewController.h"
#import "ImageGalleryViewController.h"
#import "ShareFavorite.h"


@interface BackgroundViewController ()

@end

@implementation BackgroundViewController

@synthesize m_btnOK;
@synthesize m_btnCancel;

#define TEXTURE_COUNT      10

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        appDelegate = ( MagicCameraAppDelegate *)[ [ UIApplication sharedApplication ] delegate ];
        appDelegate.m_bFavrouiteOK = false;
        if( appDelegate.m_imgFavourite != nil )
            [ appDelegate.m_imgFavourite release ];
        appDelegate.m_imgFavourite = nil;
        
        m_bEditing = NO;
        m_nSelectedIndex    =   -1;
        
//        [ self loadFavouriteImages ];
        
    }
    return self;
}


- (void)loadFavouriteImages{
    
    if ([ShareFavorite instance].imgArray != nil) {
        [[ShareFavorite instance].imgArray release];
        [ShareFavorite instance].imgArray = nil;
    }
    
    [ShareFavorite instance].imgArray = [ [ NSMutableArray alloc ] init ];
    
    NSString *extension = @"png";
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSArray *contents = [fileManager contentsOfDirectoryAtPath:DOCSFOLDER error:NULL];  
    NSString *filename;
    for (filename in contents)
    {
        if ([[filename pathExtension] isEqualToString:extension]) 
        {
//            NSLog(@"filename = %@", filename);
            
            NSString *pathFace = [DOCSFOLDER stringByAppendingPathComponent:filename]; 
            
            UIImage *img = [ UIImage imageWithContentsOfFile:pathFace ];
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                        img,        ARRAY_KEY_IAMGE ,
                                        pathFace,   ARRAY_KEY_FILENAME,
                                        [NSNumber numberWithBool:NO], ARRAY_KEY_SELECTED, nil];
            
            [ [ShareFavorite instance].imgArray    addObject:dic ];
        }
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [ self addBackViews ];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewDidAppear:(BOOL)animated
{
    [ self loadFavouriteImages ];
    
    [ self addButtonsAndImageView ];
}

- (void) dealloc{
    
    if( [ [ShareFavorite instance].imgArray count ] > 0 )
        [ [ShareFavorite instance].imgArray    removeAllObjects ];
    
    if ([ShareFavorite instance].imgArray != nil) {
        [ [ShareFavorite instance].imgArray    release ];
        [ShareFavorite instance].imgArray = nil;
    }
    
    [m_imgViews release];
    
    [m_scrollview release];

    [ m_btnCancel   release ];
    [ m_btnOK       release ];
    
    [ super dealloc ];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void) willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    
}


- (IBAction)onOk:(id)sender{
    
    if(m_bEditing)
        [self deleteSelImages];
    
    m_bEditing = !m_bEditing;
    
    NSString *sCaption = m_bEditing? @"Delete" : @"Edit";
    if (m_bEditing) {
        m_btnOK.tintColor = [UIColor redColor];
    } else {
        m_btnOK.tintColor = [UIColor blackColor];
    }
    [m_btnOK setTitle:sCaption];
}

- (void) openImage
{
    appDelegate.m_bFavrouiteOK = NO;
    
    if( m_nSelectedIndex != -1 ){
/*        
        NSMutableDictionary *dic = [m_imgArray objectAtIndex:m_nSelectedIndex];
        UIImage *image = [dic objectForKey:ARRAY_KEY_IAMGE];
        
        if( appDelegate.m_imgFavourite != nil )
            [ appDelegate.m_imgFavourite    release ];
        appDelegate.m_imgFavourite  =   nil;
        
        appDelegate.m_imgFavourite = [ [ UIImage imageWithCGImage:[ image CGImage ] ] retain ];
        
        ImageViewController *viewController;
        if( SCALE_SCREEN_WIDTH != 1 )
            viewController= [ [ ImageViewController alloc ] initWithNibName:@"ImageViewController" bundle:[ NSBundle mainBundle ] ];
        else {
            viewController= [ [ ImageViewController alloc ] initWithNibName:@"ImageViewController-iPad" bundle:[ NSBundle mainBundle ] ];
            
        }
        
        NSString* sFilePath = [dic objectForKey:ARRAY_KEY_FILENAME];
        [viewController setFilePath:sFilePath];
        [ self presentModalViewController:viewController animated:YES ];
        return;
*/  
        ImageGalleryViewController * viewController;
        if( SCALE_SCREEN_WIDTH != 1 )
            viewController= [ [ ImageGalleryViewController alloc ] initWithNibName:@"ImageGalleryViewController" bundle:[ NSBundle mainBundle ] ];
        else {
            viewController= [ [ ImageGalleryViewController alloc ] initWithNibName:@"ImageGalleryViewController-iPad" bundle:[ NSBundle mainBundle ] ];
        }        
        viewController.m_nSelected = m_nSelectedIndex;
        
        [ self presentModalViewController:viewController animated:YES ];
    }
    
    [ self dismissModalViewControllerAnimated:YES ]; 
}

- (IBAction)onCancel:(id)sender{
    
    [ self dismissModalViewControllerAnimated:YES ];

}

- (void)addBackViews{
    
    [m_scrollview release];
    
    m_scrollview = [ [ UIScrollView  alloc ] initWithFrame:CGRectMake(0,44, SCREEN_WIDTH, SCREEN_HEIGHT - 44 ) ];
    
    if( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone ){
        m_scrollview.contentSize = CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT );
    }else{
        m_scrollview.contentSize = CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT );        
    }
    
    [m_scrollview setBackgroundColor:[UIColor clearColor]];
    m_scrollview.delaysContentTouches = YES;
    [m_scrollview setCanCancelContentTouches:YES];
    m_scrollview.clipsToBounds = YES;	// default is NO, we want to restrict drawing within our scrollview
    m_scrollview.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    [ m_scrollview    setScrollEnabled:YES ];
    
    [ self.view addSubview:m_scrollview ];
    //[ m_scrollview    release ];
    
    [self addButtonsAndImageView];
    
}

- (void) addButtonsAndImageView
{
    while ([m_scrollview.subviews count] > 0) {
        [[[m_scrollview subviews] objectAtIndex:0] removeFromSuperview];}
    
    [m_imgViews release];
    
//    UIButton    *btnTexture;
    m_imgViews = [[NSMutableArray alloc] init];
    
    int nInterval   =   10;
    int nBtnWidth   =   67;
    
    if( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ){
        nBtnWidth   =   179;
    }
    int nPosX = nInterval, nPosY = nInterval;
    //    NSString    *strImgName;
    
    NSMutableDictionary *dic;
    for( int i = 0; i < [ [ShareFavorite instance].imgArray count ]; i++ ){
        
        if( i % 4 == 0 ){
            
            nPosX = nInterval;
            if( i != 0 )
                nPosY   += ( nInterval + nBtnWidth );
            
        }

/*        
        btnTexture = [ [ UIButton   alloc ] initWithFrame:CGRectMake( nPosX, nPosY, nBtnWidth, nBtnWidth ) ];
        [btnTexture setContentMode:UIViewContentModeScaleAspectFill];
        
        [ btnTexture    addTarget:self action:@selector(onBtnTexture:) forControlEvents:UIControlEventTouchUpInside ];
        dic = [[ShareFavorite instance].imgArray objectAtIndex:i];
        [ btnTexture    setBackgroundImage:[ dic objectForKey:ARRAY_KEY_IAMGE] forState:UIControlStateNormal ]; 
        btnTexture.tag  =   i;
        [ m_scrollview    addSubview: btnTexture ];
        [ btnTexture    release ];
*/
        
        UIImageView * imgTexture = [[UIImageView alloc] initWithFrame:CGRectMake( nPosX, nPosY, nBtnWidth, nBtnWidth ) ];
//        imgTexture.backgroundColor = [UIColor redColor];
        [imgTexture setContentMode:UIViewContentModeScaleAspectFill];
        [imgTexture setClipsToBounds:YES];
        dic = [[ShareFavorite instance].imgArray objectAtIndex:i];
        [ imgTexture setImage:[ dic objectForKey:ARRAY_KEY_IAMGE]]; 
        imgTexture.tag  =   i;
        imgTexture.userInteractionEnabled = YES;
        [ m_scrollview    addSubview: imgTexture ];
        [ imgTexture    release ];
        
        UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapDetected:)];
        tapGesture.delegate = self;
        tapGesture.numberOfTapsRequired = 1;
//        tapGesture.numberOfTouchesRequired = 1;
        [imgTexture addGestureRecognizer:tapGesture];
        

        
        
        UIImageView * imageView;
        if( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone ){
            imageView = [ [ UIImageView   alloc ] initWithImage:[ UIImage imageNamed:@"Overlay.png" ] ];
        }
        else {
            imageView = [ [ UIImageView   alloc ] initWithImage:[ UIImage imageNamed:@"Overlay@2x.png" ] ];
        }
        
        [ m_scrollview addSubview:imageView ];
        imageView.hidden  =   YES;
        
        [m_imgViews addObject:imageView];
        [imageView release];
        
        nPosX += ( nInterval + nBtnWidth );
    }
    
    m_scrollview.contentSize = CGSizeMake(m_scrollview.frame.size.width, nPosY + nBtnWidth);

}

- (void) tapDetected:(UITapGestureRecognizer*) gesture
{
    UIImageView * view = (UIImageView*) gesture.view;
    
    int nSelIndex = view.tag;
    
    if(!m_bEditing)
    {
        m_nSelectedIndex = nSelIndex;
        [self openImage];
    }
    else 
    {
//        [self setSelection:nSelIndex button:btnSender];
        [self setSelection:nSelIndex imageView:view];
    }

}

- (void)onBtnTexture:(id)sender{
    
    UIButton    *btnSender = ( UIButton *)sender;
    int nSelIndex    =   btnSender.tag;
    
    if(!m_bEditing)
    {
        m_nSelectedIndex = nSelIndex;
        [self openImage];
    }
    else 
    {
        [self setSelection:nSelIndex button:btnSender];
    }
}

- (void) setSelection:(int)nIndex button:(UIButton*)button
{
    NSMutableDictionary *dic = [[ShareFavorite instance].imgArray objectAtIndex:nIndex];
    BOOL bSelected = [[dic objectForKey:ARRAY_KEY_SELECTED] boolValue];
    
    UIImageView *imageView = [m_imgViews objectAtIndex:nIndex];
    
    imageView.hidden = bSelected;
    imageView.frame = button.frame;
    
    [dic setObject:[NSNumber numberWithBool:!bSelected] forKey:ARRAY_KEY_SELECTED];
    [[ShareFavorite instance].imgArray replaceObjectAtIndex:nIndex withObject:dic];
}

- (void) setSelection:(int)nIndex imageView:(UIImageView*) view
{
    NSMutableDictionary *dic = [[ShareFavorite instance].imgArray objectAtIndex:nIndex];
    BOOL bSelected = [[dic objectForKey:ARRAY_KEY_SELECTED] boolValue];
    
    UIImageView *imageView = [m_imgViews objectAtIndex:nIndex];
    
    imageView.hidden = bSelected;
    imageView.frame = view.frame;
    
    [dic setObject:[NSNumber numberWithBool:!bSelected] forKey:ARRAY_KEY_SELECTED];
    [[ShareFavorite instance].imgArray replaceObjectAtIndex:nIndex withObject:dic];
}


- (void) deleteSelImages
{
    int nCount = [[ShareFavorite instance].imgArray count];
    
    NSMutableDictionary *dic;
    BOOL bSelected = NO;
    NSString *sFilePath;
    for (int n = 0 ; n < nCount ;  n++) 
    {
        dic = [[ShareFavorite instance].imgArray objectAtIndex:n];
        bSelected = [[dic objectForKey:ARRAY_KEY_SELECTED] boolValue];
        
        if(bSelected)
        {
            sFilePath = [dic objectForKey:ARRAY_KEY_FILENAME];
            
            if( [ [ NSFileManager defaultManager ] fileExistsAtPath:sFilePath ])
                [[ NSFileManager defaultManager ] removeItemAtPath:sFilePath error:nil];
            
        }
    }
    
    [self loadFavouriteImages];
    
    [ self addButtonsAndImageView ];
}

@end
