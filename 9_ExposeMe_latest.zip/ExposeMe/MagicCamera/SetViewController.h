//
//  SetViewController.h
//  SnapANote
//
//  Created by Thomas on 9/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RCSwitchClone.h"

#import <MessageUI/MFMailComposeViewController.h>

//@class MagicCameraViewController;

@interface DataCell : UITableViewCell {
	UILabel*		title;
    UILabel*        lblcomment;
    RCSwitchClone*  switchEnable;
    id              delegate_;
	NSUInteger      index;
    BOOL            enable;
}

@property (nonatomic, retain) UILabel*      title;
@property (nonatomic) NSUInteger	index;
@property (nonatomic) BOOL          enable;

- (void) setDelegate:(id)delegate;
- (void)setInfo:(NSString*)str comment:(NSString*)comment OPTION:(BOOL)option INDEX:(int)idx;
- (id) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier INDEX:(int)idx;
@end

@interface SliderCell : UITableViewCell {
	UILabel*		title;
    UILabel*        lblcomment;
    UISlider*       slider;
    UILabel*        value;
    id              delegate_;
	int             selftimer;
    BOOL            enable;
}

@property (nonatomic, retain) UILabel*      title;
@property (nonatomic) NSUInteger	index;
@property (nonatomic) BOOL          enable;

- (void) setDelegate:(id)delegate;
- (void)setInfo:(NSString*)str comment:(NSString*)comment delytime:(int)delytime;
- (id) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier INDEX:(int)idx;
- (void) onslider:(id)sel;
@end

@interface SegmentCell : UITableViewCell {
	UILabel*		title;
    UILabel*        lblcomment;
    UISegmentedControl* segmentCtrl;
    id              delegate_;
	NSUInteger      index;
}

@property (nonatomic, retain) UILabel*      title;
@property (nonatomic, retain) UISegmentedControl* segmentCtrl;
@property (nonatomic) NSUInteger	index;
@property (nonatomic) NSUInteger	m_nTableIndex;  

- (void) setDelegate:(id)delegate;
- (void)setInfo:(NSString*)str comment:(NSString*)comment INDEX:(int)idx;
- (id) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier INDEX:(int)idx;
- (id) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier INDEX:(int)idx nKind:(int)nTableIndex;

@end

@interface SetViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate,MFMailComposeViewControllerDelegate> 
{
//    MagicCameraViewController* delegate;
    IBOutlet UIBarButtonItem*   btnSave;
    IBOutlet UIBarButtonItem*   btnCancel;
    IBOutlet UITableView*       tblSetting;

    BOOL                        fSetStoreImage;
    
    BOOL                        fExposureAdjust;
    BOOL                        fExposureLock;
    BOOL                        fScreenShutter;
    BOOL                        fAutoSave;
    BOOL                        fAutoSaveToPhotoLib;
    
    BOOL                        fSoundEffect;
    BOOL                        fVolumeShutter;
    int                         selfpicturetype;
    
    int                         selftimer;
    NSString*                   strSetRecipient;
	UITextField*                txtRecipient;
    BOOL                        ftableinit;
}

//@property(nonatomic,retain)MagicCameraViewController* delegate;
@property(nonatomic,retain)NSString* strSetRecipient;
@property(nonatomic)BOOL fExposureAdjust;
@property(nonatomic)BOOL fExposureLock;
@property(nonatomic)BOOL fScreenShutter;
@property(nonatomic)BOOL fAutoSave;
@property(nonatomic)int  selftimer;

@property(nonatomic)int  selfpicturetype;
@property(nonatomic)BOOL fVolumeShutter;
@property(nonatomic)BOOL fSoundEffect;


- (IBAction) onSave;
- (IBAction) onCancel;
- (void) setOption:(int)index OPTION:(BOOL)option;
- (void) setEmailText:(NSString*)str;
- (void) animateTextField:(BOOL) up;
- (void) checkEmailAddres:(NSString*)ea;

- (void) onExposeMeSupport;

@end
