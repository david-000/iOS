//
//  AppDelegate.h
//  MagicCamera
//
//  Created by i Pro on 2/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <AVFoundation/AVFoundation.h>

#import "TwitterManager.h"
#import "FacebookManager.h"

#import <AudioToolbox/AudioToolbox.h>
#import <MediaPlayer/MediaPlayer.h>

#define DOCSFOLDER [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]

enum SE_TYPE {
    SE_SHUTTERSTART = 0,
    SE_SHUTTEREND,
    SE_EFFECT,                  
};

@class MagicCameraViewController;
@interface MagicCameraAppDelegate : UIResponder <UIApplicationDelegate, TwitterManagerDelegate ,FacebookManagerDelegate> {
 	UINavigationController	*navigationController;

    AVAudioPlayer*		m_audioPlayer;
    
    
    UIImage         *m_imgFavourite;
    BOOL            m_bFavrouiteOK;
    
    
    NSDictionary *twitterMessage;
    UIImage * m_postImage;
    
    
    MPVolumeView *volumeView;
}


@property   (nonatomic ) UIImage    *m_imgFavourite;
@property   (nonatomic ) BOOL       m_bFavrouiteOK;


@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MagicCameraViewController *viewController;


+ (MagicCameraAppDelegate *)sharedDelegate;

//- (void)setAndStoreFlickrAuthToken:(NSString *)inAuthToken secret:(NSString *)inSecret;

- (void)playSE:(int)type;
- (void)stopSE;
- (BOOL)isPlayingSE;

- (void)sendToFacebook:(UIImage*) image;
- (void)sendToTwitter:(UIImage*) image;
- (void)sendToSocial:(NSString*)snsType message:(NSString*)message image:(UIImage*) image;
- (void) saveImageToDocument:(NSString*)strPath image:(UIImage*)image;


-(void) insertVolumnView;
-(void) removeVolumnView;

@end
