//
//  UIViewDraw.h
//  MEMO2
//
//  Created by Administrator on 09/09/26.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ImageErrorOccured

-(void) errorOccured:(NSString*)content;

@end


@interface UIView (Draw) <ImageErrorOccured>


- (CGContextRef) getCurrentContext;

- (void) setContextAlpha :(CGFloat)  fAlpha;
- (void) setFillColor    :(UIColor*) color;
- (void) setStrokeColor  :(UIColor*) color;
- (void) setLineWidth    :(int)      nLineWidth;
- (void) setClip         :(CGMutablePathRef) path;


- (void) drawLineTwoPoint:(CGPoint)  ptFrom  :(CGPoint) ptTo;
- (void) drawLineTwoPoint:(CGPoint)  ptFrom  :(CGPoint) ptTo :(CGFloat) nLineWidth :(UIColor*) clrLine :(CGFloat) fAlpha;

- (void) drawLineArrPoint:(CGPoint*) ptArray :(int) nSize    :(CGFloat) fAlpha;
- (void) drawLineArrPoint:(CGPoint*) ptArray :(int) nSize    :(CGFloat) nLineWidth :(UIColor*) clrLine :(CGFloat) fAlpha;

- (void) drawSegmentLine :(CGPoint*) ptArray :(int) nSize    :(CGFloat)nLineWidth :(UIColor*) clrLine :(CGFloat) fAlpha;

- (void) drawArc:(CGPoint) ptCenter :(CGFloat) fRadius :(CGFloat) fSAngel    :(CGFloat)  fEAngel   :(BOOL) bClock :(CGFloat) nLineWidth :(UIColor*) clrStroke :(CGFloat) fAlpha;
- (void) drawArc:(CGPoint*)ptArray  :(CGFloat) fRadius :(CGFloat) nLineWidth :(UIColor*) clrStroke :(CGFloat) fAlpha;

- (void) drawBezier:(CGPoint) ptStart :(CGPoint) ptEnd :(CGPoint) ptControl0 :(CGFloat) nLineWidth :(UIColor*) clrStroke  :(CGFloat)  fAlpha;
- (void) drawBezier:(CGPoint) ptStart :(CGPoint) ptEnd :(CGPoint) ptControl0 :(CGPoint) ptControl1 :(CGFloat)  nLineWidth :(UIColor*) clrStroke :(CGFloat) fAlpha;

- (void) setCapLineType:(CGLineCap)   lineCap;

- (void) setJoinLineType:(CGLineJoin) lineJoin;

- (void) setDashLineType:(CGFloat) fPhase :(CGFloat*) dashArray :(int) nSize;

- (void) drawStorkeRect:(CGRect) rcRect;
- (void) drawStorkeRect:(CGRect) rcRect :(UIColor*) clrStroke :(CGFloat)  nLineWidth :(CGFloat)  fAlpha;
- (void) drawFillRect  :(CGRect) rcRect :(UIColor*) clrFill   :(CGFloat)  fAlpha;
- (void) drawFillRect  :(CGRect) rcRect :(UIColor*) clrFill   :(UIColor*) clrStroke  :(CGFloat)  nLineWidth :(CGFloat) fAlpha;
- (void) drawRoundRect :(CGRect) rcRect :(CGFloat)  fRadius   :(UIColor*) clrFill    :(UIColor*) clrStroke  :(CGFloat) nLineWidth :(CGFloat) fAlpha;

- (void) drawRectWithColorPattern  :(CGRect) rcRect;
- (void) drawRectWithUnColorPattern:(CGRect) rcRect :(CGFloat*) clrFill;


- (void) drawStar   :(CGPoint) ptCenter :(CGFloat) fRadius :(UIColor*) clrStroke :(UIColor*) clrFill   :(CGFloat) nLineWidth :(CGFloat) fAlpha;
- (void) drawPolygon:(CGPoint) ptCenter :(CGFloat) fRadius :(int) nPolygons      :(UIColor*) clrStroke :(UIColor*)clrFill    :(CGFloat) nLineWidth :(CGFloat) fAlpha;

- (void) drawEllipse:(CGRect) rcEllipse :(UIColor*) clrStroke :(UIColor*)clrFill :(CGFloat) nLineWidth :(CGFloat) fAlpha;

- (void) drawLineGradient  :(CGRect) rcRect :(CGFloat*) arrColor :(int) nSize :(CGFloat) fAlpha;
- (void) drawRadialGradient:(CGRect) rcRect :(CGFloat*) arrColor :(int) nSize :(CGFloat) fAlpha;

- (UIImage*) getImageFromFile      :(NSString*) resource;
- (UIImage*) getImageCachedFromFile:(NSString*) resource;
- (UIImage*) getImageFromData      :(Byte*)     pImageData :(int) nWidth :(int) nHeight;
- (UIImage*) getClipImage          :(UIImage*)  imgSource  :(CGRect) subRect;
- (UIImage *)resizedImage          :(UIImage *)inImage inSize:(CGSize)thumbSize;
- (UIImage*) getRotateImage        :(UIImage*)  imgSource  :(UIImageOrientation) orientation;
- (UIImage*) getImageFromScreen;

- (void) drawImage:(UIImage*) image :(int)  x :(int) y;
- (void) drawImage:(UIImage*) image :(int)  x :(int) y  :(float) fAlpha;
- (void) drawBlend:(UIImage*) image :(int)  x :(int) y  :(float) fAlpha :(CGBlendMode) blendMode;
- (void) drawImage:(UIImage*) image :(int) sx :(int) sy :(int) dx :(int) dy :(int) width :(int) heigh;
- (void) drawImage:(UIImage*) image :(int) sx :(int) sy :(int) dx :(int) dy :(int) sw    :(int) sh :(int) dw :(int) dh;
- (void) drawImage:(UIImage*) image :(int) sx :(int) sy :(int) dx :(int) dy :(int) sw    :(int) sh :(int) dw :(int) dh :(float) fAlpha;
- (void) drawTitleImage:(UIImage*) image :(CGRect) rcRect :(CGFloat) fAlpha;


- (UIImage*) getMaskImage          :(UIImage*) maskImage;
- (UIImage*) getImageWithMaskImage :(UIImage*) imgSource :(UIImage*) maskImage;
- (UIImage*) getImageWithMaskColor :(UIImage*) imgSource :(CGFloat*) maskColor;
- (void)     drawImageWithMaskImage:(UIImage*) orgImage  :(UIImage*) maskImage :(CGRect) rcRect;


-(void) vir_drawString:(NSString*) fmn :(int) x :(int) y :(UIColor*) color   :(UIFont*)  font;
-(void) vir_drawString:(NSString*) fmn :(int) x :(int) y :(UIColor*) bkcolor :(UIColor*) stcolor :(UIFont*) font;

-(CGSize)    getStringSize:(NSString*)fmn :(UIFont*)font;
-(NSString*) convertBanToZenString:(NSString*) strOrigin;
-(NSString*) convertZenToBanString:(NSString*) strOrigin;


-(void) clearAllSubView;
-(void) clearSubView:(int) tag;


-(void) animationTransition:(int) nType :(int) nDir :(NSTimeInterval) fTime;


-(CGFloat) DegreesToRadians:(CGFloat) degrees;
-(CGFloat) RadiansToDegrees:(CGFloat) radians;




@end
