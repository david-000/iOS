//
//  InstructionViewController.h
//  ExposeMe
//
//  Created by Gold Luo on 8/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InstructionViewController : UIViewController
{
    IBOutlet UIScrollView * m_scrollView;
    IBOutlet UIWebView    * m_webView;
}

@end
