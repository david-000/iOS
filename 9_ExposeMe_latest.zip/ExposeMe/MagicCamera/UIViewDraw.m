//
//  UIViewDraw.m
//  MEMO2
//
//  Created by Administrator on 09/09/26.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "UIViewDraw.h"
#import <QuartzCore/QuartzCore.h>

@implementation UIView (Draw)


- (CGContextRef) getCurrentContext {
	return UIGraphicsGetCurrentContext();
}

- (void) setContextAlpha :(CGFloat) fAlpha {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSetAlpha(gid, fAlpha);
}

- (void) setFillColor:(UIColor*) color{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSetFillColorWithColor(gid, [color CGColor]);
}

- (void) setStrokeColor:(UIColor*) color{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSetStrokeColorWithColor(gid, [color CGColor]);
}

- (void) setLineWidth:(int) nLineWidth {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSetLineWidth(gid, nLineWidth);
}

/* ex:
	CGMutablePathRef path = CGPathCreateMutable();
	CGPathAddEllipseInRect(path, NULL, [self bounds]);
	[self setClip:path];
 */
- (void) setClip:(CGMutablePathRef) path {
	
	
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextAddPath(gid, path);
	CGContextClip(gid);
	CGPathRelease(path);
}

- (void) drawLineTwoPoint:(CGPoint) ptFrom :(CGPoint) ptTo {
	CGContextRef gid = UIGraphicsGetCurrentContext();

	CGContextMoveToPoint(gid, ptFrom.x, ptFrom.y);
	CGContextAddLineToPoint(gid, ptTo.x, ptTo.y);
	CGContextStrokePath(gid);
}

- (void) drawLineTwoPoint:(CGPoint) ptFrom :(CGPoint) ptTo :(CGFloat) nLineWidth :(UIColor*) clrLine :(CGFloat) fAlpha {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setStrokeColor:clrLine];
	CGContextSetAlpha(gid, fAlpha);
	CGContextSetLineWidth(gid, nLineWidth);
	
	CGContextMoveToPoint(gid, ptFrom.x, ptFrom.y);
	CGContextAddLineToPoint(gid, ptTo.x, ptTo.y);
	CGContextStrokePath(gid);
	
	CGContextRestoreGState(gid);
}

- (void) drawLineArrPoint:(CGPoint*) ptArray :(int) nSize :(CGFloat) fAlpha {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);

	CGContextSetAlpha(gid, fAlpha);
	CGContextAddLines(gid, ptArray, nSize);
	CGContextStrokePath(gid);

	CGContextRestoreGState(gid);
}

- (void) drawLineArrPoint:(CGPoint*) ptArray :(int) nSize :(CGFloat) nLineWidth :(UIColor*) clrLine :(CGFloat) fAlpha {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setStrokeColor:clrLine];
	CGContextSetAlpha(gid, fAlpha);
	CGContextSetLineWidth(gid, nLineWidth);
	CGContextAddLines(gid, ptArray, nSize);
	CGContextStrokePath(gid);
	
	CGContextRestoreGState(gid);
}

- (void) drawSegmentLine :(CGPoint*) ptArray :(int) nSize :(CGFloat) nLineWidth :(UIColor*) clrLine :(CGFloat) fAlpha{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setStrokeColor:clrLine];
	CGContextSetAlpha(gid, fAlpha);
	CGContextSetLineWidth(gid, nLineWidth);
	CGContextStrokeLineSegments(gid, ptArray, nSize);

	CGContextRestoreGState(gid);
}

- (void) drawArc:(CGPoint) ptCenter :(CGFloat) fRadius :(CGFloat) fSAngel :(CGFloat) fEAngel :(BOOL) bClock :(CGFloat) nLineWidth :(UIColor*) clrStroke :(CGFloat) fAlpha {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setStrokeColor :clrStroke];
	CGContextSetAlpha(gid, fAlpha);
	CGContextSetLineWidth(gid, nLineWidth);
	CGContextAddArc(gid, ptCenter.x, ptCenter.y, fRadius, fSAngel, fEAngel, bClock);
	CGContextStrokePath(gid);
	
	CGContextRestoreGState(gid);
}

- (void) drawArc:(CGPoint*)ptArray  :(CGFloat) fRadius :(CGFloat) nLineWidth :(UIColor*) clrStroke :(CGFloat) fAlpha {
	
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setStrokeColor :clrStroke];
	CGContextSetAlpha(gid, fAlpha);
	CGContextSetLineWidth(gid, nLineWidth);
	CGContextMoveToPoint(gid, ptArray[0].x, ptArray[0].y);
	CGContextAddArcToPoint(gid, ptArray[1].x, ptArray[1].y, ptArray[2].x, ptArray[2].y, fRadius);
	CGContextStrokePath(gid);
	
	CGContextRestoreGState(gid);
	
}

- (void) drawBezier:(CGPoint) ptStart :(CGPoint) ptEnd :(CGPoint) ptControl0 :(CGFloat) nLineWidth :(UIColor*) clrStroke  :(CGFloat)  fAlpha {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setStrokeColor :clrStroke];
	CGContextSetAlpha(gid, fAlpha);
	CGContextSetLineWidth(gid, nLineWidth);
	CGContextMoveToPoint(gid, ptStart.x, ptStart.y);
	CGContextAddQuadCurveToPoint(gid, ptControl0.x, ptControl0.y, ptEnd.x, ptEnd.y);
	CGContextStrokePath(gid);
	
	CGContextRestoreGState(gid);
}

- (void) drawBezier:(CGPoint) ptStart :(CGPoint) ptEnd :(CGPoint) ptControl0 :(CGPoint) ptControl1 :(CGFloat)  nLineWidth :(UIColor*) clrStroke :(CGFloat) fAlpha {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setStrokeColor :clrStroke];
	CGContextSetAlpha(gid, fAlpha);
	CGContextSetLineWidth(gid, nLineWidth);
	CGContextMoveToPoint(gid, ptStart.x, ptStart.y);
	CGContextAddCurveToPoint(gid, ptControl0.x, ptControl0.y, ptControl1.x, ptControl1.y, ptEnd.x, ptEnd.y);
	CGContextStrokePath(gid);
	
	CGContextRestoreGState(gid);
}

- (void) setCapLineType:(CGLineCap) lineCap {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	/*
	 kCGLineCapButt:   Line cap butt, default.
	 kCGLineCapRound:  Line cap round
	 kCGLineCapSquare: Line cap square
	 */
	CGContextSetLineCap(gid, lineCap);
}

- (void) setJoinLineType:(CGLineJoin) lineJoin {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	/*
	 kCGLineJoinMiter: Line join miter, default
	 kCGLineJoinRound: Line join round
	 kCGLineJoinBevel: Line join bevel
	 */
	CGContextSetLineJoin(gid, lineJoin);
}

- (void) setDashLineType:(CGFloat) fPhase :(CGFloat*) dashArray :(int) nSize{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSetLineDash(gid, fPhase, dashArray, nSize);	
}


- (void) drawStorkeRect:(CGRect) rcRect {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	
	CGContextAddRect(gid, rcRect);
	CGContextStrokePath(gid);
}

- (void) drawStorkeRect:(CGRect) rcRect :(UIColor*) clrStroke :(CGFloat) nLineWidth :(CGFloat) fAlpha {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setStrokeColor:clrStroke];
	CGContextSetAlpha(gid, fAlpha);
	CGContextSetLineWidth(gid, nLineWidth);
	CGContextStrokeRect(gid, rcRect);
	
	CGContextRestoreGState(gid);
}

- (void) drawFillRect:(CGRect) rcRect :(UIColor*) clrFill :(CGFloat) fAlpha {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setFillColor:clrFill];
	CGContextSetAlpha(gid, fAlpha);
	CGContextFillRect(gid, rcRect);
	
	CGContextRestoreGState(gid);
}

- (void) drawFillRect:(CGRect) rcRect :(UIColor*) clrFill :(UIColor*) clrStroke :(CGFloat) nLineWidth :(CGFloat) fAlpha {
	[self drawFillRect  :rcRect :clrFill :fAlpha];
	[self drawStorkeRect:rcRect :clrStroke :nLineWidth :fAlpha];
}

- (void) drawRoundRect:(CGRect) rcRect :(CGFloat) fRadius :(UIColor*) clrFill :(UIColor*) clrStroke :(CGFloat) nLineWidth :(CGFloat) fAlpha{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setStrokeColor:clrStroke];
	[self setFillColor:clrFill];
	CGContextSetAlpha(gid, fAlpha);
	CGContextSetLineWidth(gid, nLineWidth);
	
	CGFloat minx = CGRectGetMinX(rcRect), midx = CGRectGetMidX(rcRect), maxx = CGRectGetMaxX(rcRect);
	CGFloat miny = CGRectGetMinY(rcRect), midy = CGRectGetMidY(rcRect), maxy = CGRectGetMaxY(rcRect);
	
	// Next, we will go around the rectangle in the order given by the figure below.
	//       minx    midx    maxx
	// miny    2       3       4
	// midy   1 9              5
	// maxy    8       7       6
	// Which gives us a coincident start and end point, which is incidental to this technique, but still doesn't
	// form a closed path, so we still need to close the path to connect the ends correctly.
	// Thus we start by moving to point 1, then adding arcs through each pair of points that follows.
	// You could use a similar tecgnique to create any shape with rounded corners.
	
	// Start at 1
	CGContextMoveToPoint(gid, minx, midy);
	// Add an arc through 2 to 3
	CGContextAddArcToPoint(gid, minx, miny, midx, miny, fRadius);
	// Add an arc through 4 to 5
	CGContextAddArcToPoint(gid, maxx, miny, maxx, midy, fRadius);
	// Add an arc through 6 to 7
	CGContextAddArcToPoint(gid, maxx, maxy, midx, maxy, fRadius);
	// Add an arc through 8 to 9
	CGContextAddArcToPoint(gid, minx, maxy, minx, midy, fRadius);
	// Close the path
	CGContextClosePath(gid);
	// Fill & stroke the path
	CGContextDrawPath(gid, kCGPathFillStroke);	
	
	CGContextRestoreGState(gid);
}

void ColoredPatternCallback(void *info, CGContextRef context)
{
	// Dark Blue
	CGContextSetRGBFillColor(context, 29.0 / 255.0, 156.0 / 255.0, 215.0 / 255.0, 1.00);
	CGContextFillRect(context, CGRectMake(0.0, 0.0, 8.0, 8.0));
	CGContextFillRect(context, CGRectMake(8.0, 8.0, 8.0, 8.0));
	
	// Light Blue
	CGContextSetRGBFillColor(context, 204.0 / 255.0, 224.0 / 255.0, 244.0 / 255.0, 1.00);
	CGContextFillRect(context, CGRectMake(8.0, 0.0, 8.0, 8.0));
	CGContextFillRect(context, CGRectMake(0.0, 8.0, 8.0, 8.0));
}

// Uncolored patterns take their color from the given context
void UncoloredPatternCallback(void *info, CGContextRef context)
{
	CGContextFillRect(context, CGRectMake(0.0, 0.0, 8.0, 8.0));
	CGContextFillRect(context, CGRectMake(8.0, 8.0, 8.0, 8.0));
}

- (void) drawRectWithColorPattern:(CGRect) rcRect {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	// Colored Pattern setup
	CGPatternCallbacks coloredPatternCallbacks = {0, ColoredPatternCallback, NULL};
	// First we need to create a CGPatternRef that specifies the qualities of our pattern.
	CGPatternRef coloredPattern = CGPatternCreate(NULL,								// 'info' pointer for our callback
												  CGRectMake(0.0, 0.0, 16.0, 16.0), // the pattern coordinate space, drawing is clipped to this rectangle
												  CGAffineTransformIdentity,		// a transform on the pattern coordinate space used before it is drawn.
												  16.0, 16.0,						// the spacing (horizontal, vertical) of the pattern - how far to move after drawing each cell
												  kCGPatternTilingNoDistortion,
												  TRUE,								// this is a colored pattern, which means that you only specify an alpha value when drawing it
												  &coloredPatternCallbacks);		// the callbacks for this pattern.
	
	// To draw a pattern, you need a pattern colorspace.
	// Since this is an colored pattern, the parent colorspace is NULL, indicating that it only has an alpha value.
	CGColorSpaceRef coloredPatternColorSpace = CGColorSpaceCreatePattern(NULL);
	CGFloat fAlpha = 1.0;
	// Since this pattern is colored, we'll create a CGColorRef for it to make drawing it easier and more efficient.
	// From here on, the colored pattern is referenced entirely via the associated CGColorRef rather than the
	// originally created CGPatternRef.
	CGColorRef coloredPatternColor = CGColorCreateWithPattern(coloredPatternColorSpace, coloredPattern, &fAlpha);
	CGColorSpaceRelease(coloredPatternColorSpace);
	CGPatternRelease(coloredPattern);
	
	CGContextSetFillColorWithColor(gid, coloredPatternColor);
	CGContextFillRect(gid, rcRect);
	
	CGColorRelease(coloredPatternColor);

	CGContextRestoreGState(gid);
}

- (void) drawRectWithUnColorPattern:(CGRect) rcRect :(CGFloat*) clrFill{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	// Uncolored Pattern setup
	CGPatternCallbacks uncoloredPatternCallbacks = {0, UncoloredPatternCallback, NULL};
	// As above, we create a CGPatternRef that specifies the qualities of our pattern
	CGPatternRef uncoloredPattern = CGPatternCreate(NULL,								// 'info' pointer
													CGRectMake(0.0, 0.0, 16.0, 16.0),	// coordinate space
													CGAffineTransformIdentity,			// transform
													16.0, 16.0,							// spacing
													kCGPatternTilingNoDistortion,
													FALSE,								// this is an uncolored pattern, thus to draw it we need to specify both color and alpha
													&uncoloredPatternCallbacks);			// callbacks for this pattern
	
	// With an uncolored pattern we still need to create a pattern colorspace, but now we need a parent colorspace
	// We'll use the DeviceRGB colorspace here. We'll need this colorspace along with the CGPatternRef to draw this pattern later.
	CGColorSpaceRef deviceRGB = CGColorSpaceCreateDeviceRGB();
	CGColorSpaceRef uncoloredPatternColorSpace = CGColorSpaceCreatePattern(deviceRGB);
	CGColorSpaceRelease(deviceRGB);
	
//	CGContextSetFillColorSpace(gid, uncoloredPatternColorSpace);
//	CGContextSetFillPattern(gid, uncoloredPattern, clrFill);
//	CGContextFillRect(gid, rcRect);
	
	CGContextSetStrokeColorSpace(gid, uncoloredPatternColorSpace);
	CGContextSetStrokePattern(gid, uncoloredPattern, clrFill);
	CGContextStrokeRectWithWidth(gid, rcRect, 8.0);
	
	
	CGPatternRelease(uncoloredPattern);
	CGColorSpaceRelease(uncoloredPatternColorSpace);
	
	CGContextRestoreGState(gid);
}

- (void) drawStar:(CGPoint) ptCenter :(CGFloat) fRadius :(UIColor*) clrStroke :(UIColor*)clrFill :(CGFloat) nLineWidth :(CGFloat) fAlpha {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setStrokeColor :clrStroke];
	[self setFillColor   :clrFill];
	[self setContextAlpha:fAlpha];
	
	CGContextMoveToPoint(gid, ptCenter.x, ptCenter.y - fRadius);
	for(int i = 1; i < 5; ++i)
	{
		CGFloat x = fRadius * sinf(i * 4.0 * M_PI / 5.0);
		CGFloat y = fRadius * cosf(i * 4.0 * M_PI / 5.0);
		CGContextAddLineToPoint(gid, ptCenter.x + x, ptCenter.y - y);
	}
	CGContextClosePath(gid);
	CGContextDrawPath(gid, kCGPathFillStroke); // 닫긴선그리기 kCGPathEOFillStroke
	
	CGContextRestoreGState(gid);
}

- (void) drawPolygon:(CGPoint) ptCenter :(CGFloat) fRadius :(int) nPolygons :(UIColor*) clrStroke :(UIColor*)clrFill :(CGFloat) nLineWidth :(CGFloat) fAlpha {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setStrokeColor :clrStroke];
	[self setFillColor   :clrFill];
	[self setContextAlpha:fAlpha];
	
	CGContextMoveToPoint(gid, ptCenter.x, ptCenter.y - fRadius);
	for(int i = 1; i < nPolygons; ++i)
	{
		CGFloat x = fRadius * sinf(i * 2.0 * M_PI / 5.0);
		CGFloat y = fRadius * cosf(i * 2.0 * M_PI / 5.0);
		CGContextAddLineToPoint(gid, ptCenter.x + x, ptCenter.y - y);
	}
	CGContextClosePath(gid);
	CGContextDrawPath(gid, kCGPathFillStroke);
	
	CGContextRestoreGState(gid);
}


- (void) drawEllipse:(CGRect) rcEllipse :(UIColor*) clrStroke :(UIColor*)clrFill :(CGFloat) nLineWidth :(CGFloat) fAlpha {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	[self setStrokeColor :clrStroke];
	[self setFillColor   :clrFill];
	[self setContextAlpha:fAlpha];
	
	CGContextFillEllipseInRect(gid, rcEllipse);
	CGContextStrokeEllipseInRect(gid, rcEllipse);
	
	CGContextRestoreGState(gid);
}


- (void) drawLineGradient :(CGRect) rcRect :(CGFloat*) arrColor :(int) nSize :(CGFloat) fAlpha{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	CGContextSetAlpha(gid, fAlpha);
	
	//	CGFloat clrArray[] =
	//	{
	//		204.0 / 255.0, 224.0 / 255.0, 244.0 / 255.0, 1.00,
	//		29.0 / 255.0, 156.0 / 255.0, 215.0 / 255.0, 1.00,
	//      ........
	//	};
	CGColorSpaceRef rgb = CGColorSpaceCreateDeviceRGB();
	CGGradientRef gradient = CGGradientCreateWithColorComponents(rgb, arrColor, NULL, nSize);
	CGColorSpaceRelease(rgb);
	CGContextClipToRect(gid, rcRect);
	CGPoint start, end;
	start = CGPointMake(rcRect.origin.x, rcRect.origin.y);
	end   = CGPointMake(rcRect.origin.x, rcRect.origin.y + rcRect.size.height);
	CGContextDrawLinearGradient(gid, gradient, start, end, kCGGradientDrawsBeforeStartLocation | kCGGradientDrawsAfterEndLocation);
	CGGradientRelease(gradient);
	
	CGContextRestoreGState(gid);
}

- (void) drawRadialGradient:(CGRect) rcRect :(CGFloat*) arrColor :(int) nSize :(CGFloat) fAlpha{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);
	
	CGContextSetAlpha(gid, fAlpha);
	
	//	CGFloat clrArray[] =
	//	{
	//		204.0 / 255.0, 224.0 / 255.0, 244.0 / 255.0, 1.00,
	//		29.0 / 255.0, 156.0 / 255.0, 215.0 / 255.0, 1.00,
	//      ........
	//	};
	CGColorSpaceRef rgb = CGColorSpaceCreateDeviceRGB();
	CGGradientRef gradient = CGGradientCreateWithColorComponents(rgb, arrColor, NULL, nSize);
	CGColorSpaceRelease(rgb);
	CGContextClipToRect(gid, rcRect);
	CGPoint start, end;
	CGFloat startRadius, endRadius;
	start = end = CGPointMake(CGRectGetMidX(rcRect), CGRectGetMidY(rcRect));
	startRadius = 0;
	endRadius   = rcRect.size.width < rcRect.size.height ? rcRect.size.height : rcRect.size.width;
	CGContextDrawRadialGradient(gid, gradient, start, startRadius, end, endRadius, kCGGradientDrawsBeforeStartLocation | kCGGradientDrawsAfterEndLocation);
	CGGradientRelease(gradient);
	
	CGContextRestoreGState(gid);
}

-(UIImage*) getImageFromFile:(NSString*) resource{
	UIImage *res;
	NSString *fileName = [[NSBundle mainBundle] pathForResource:resource ofType:@"png"];
	if (fileName == nil){
		fileName = [[NSBundle mainBundle] pathForResource:resource ofType:@"jpg"];
		if (fileName == nil){
			return nil;
		}
	}
	res = [UIImage imageWithContentsOfFile:fileName];
	return res;
//	return [res retain];
}

-(UIImage*) getImageCachedFromFile:(NSString*) resource{
	UIImage *res;
	NSString *fileName = [[NSBundle mainBundle] pathForResource:resource ofType:@"png"];
	if (fileName == nil){
		fileName = [[NSBundle mainBundle] pathForResource:resource ofType:@"jpg"];
		if (fileName == nil){
			return nil;
		}
		else {
			res = [UIImage imageNamed:[NSString stringWithFormat:@"%@.jpg", resource]];
			return res;
		}
	}
	else {
		res = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png", resource]];
		return res;
	}
//	return [res retain];
}

- (UIImage*) getImageFromData:(Byte*) pImageData :(int) nWidth :(int) nHeight{
    CGColorSpaceRef RGBColor = CGColorSpaceCreateDeviceRGB();
	CGContextRef gidTarget = CGBitmapContextCreate (pImageData, nWidth, nHeight, 8, 4*nWidth, RGBColor, kCGImageAlphaNoneSkipLast);
	CGImageRef targetCG = CGBitmapContextCreateImage(gidTarget);
	UIImage *targetImage = [UIImage imageWithCGImage:targetCG];
	CGImageRelease(targetCG);
	CGContextRelease(gidTarget);
    CGColorSpaceRelease(RGBColor);
    
	return targetImage;
}

- (UIImage*) getClipImage:(UIImage*) imgSource :(CGRect) subRect{
	CGImageRef subImage   = CGImageCreateWithImageInRect([imgSource CGImage], subRect);
	UIImage    *target    = [UIImage imageWithCGImage:subImage];
	CGImageRelease(subImage);
	return target;
}

- (UIImage *)resizedImage:(UIImage *)inImage inSize:(CGSize)thumbSize
{
	CGFloat vRatio = inImage.size.height / thumbSize.height;
    CGFloat hRatio = inImage.size.width / thumbSize.width;
    CGFloat ratio = fmaxf(vRatio, hRatio);
    CGSize drawingSize = CGSizeMake(hRatio / ratio * thumbSize.width, vRatio / ratio * thumbSize.height);
    
	// Creates a bitmap-based graphics context and makes it the current context.
	UIGraphicsBeginImageContext(thumbSize);
	[inImage drawInRect:CGRectMake((thumbSize.width - drawingSize.width) / 2.0f, (thumbSize.height - drawingSize.height) / 2.0f, drawingSize.width, drawingSize.height)];
	
	return UIGraphicsGetImageFromCurrentImageContext();
}

- (UIImage*) getRotateImage :(UIImage*) imgSource :(UIImageOrientation) orientation {
	
	int kMaxResolution = 480; // Or whatever
	
	CGImageRef imgRef = imgSource.CGImage;
	
	CGFloat width  = CGImageGetWidth(imgRef);
	CGFloat height = CGImageGetHeight(imgRef);
	
	
	CGAffineTransform transform = CGAffineTransformIdentity;
	CGRect bounds = CGRectMake(0, 0, width, height);
	if (width > kMaxResolution || height > kMaxResolution) {
		CGFloat ratio = width/height;
		if (ratio > 1) {
			bounds.size.width = kMaxResolution;
			bounds.size.height = bounds.size.width / ratio;
		}
		else {
			bounds.size.height = kMaxResolution;
			bounds.size.width = bounds.size.height * ratio;
		}
	}
	
	CGFloat scaleRatio = bounds.size.width / width;
	CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
	CGFloat boundHeight;
	UIImageOrientation orient = orientation;//image.imageOrientation;
	switch(orient) {
		case UIImageOrientationUp: //EXIF = 1
			transform = CGAffineTransformIdentity;
			break;
			
		case UIImageOrientationUpMirrored: //EXIF = 2
			transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);
			transform = CGAffineTransformScale(transform, -1.0, 1.0);
			break;
			
		case UIImageOrientationDown: //EXIF = 3
			transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
			transform = CGAffineTransformRotate(transform, M_PI);
			break;
			
		case UIImageOrientationDownMirrored: //EXIF = 4
			transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
			transform = CGAffineTransformScale(transform, 1.0, -1.0);
			break;
			
		case UIImageOrientationLeftMirrored: //EXIF = 5
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width  = boundHeight;
			transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
			transform = CGAffineTransformScale(transform, -1.0, 1.0);
			transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
			break;
			
		case UIImageOrientationLeft: //EXIF = 6
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width  = boundHeight;
			transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
			transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
			break;
			
		case UIImageOrientationRightMirrored: //EXIF = 7
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width  = boundHeight;
			transform = CGAffineTransformMakeScale(-1.0, 1.0);
			transform = CGAffineTransformRotate(transform, M_PI / 2.0);
			break;
			
		case UIImageOrientationRight: //EXIF = 8
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width  = boundHeight;
			transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
			transform = CGAffineTransformRotate(transform, M_PI / 2.0);
			break;
			
	}
	
	UIGraphicsBeginImageContext(bounds.size);
	
	CGContextRef context = UIGraphicsGetCurrentContext();
	
	if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {
		CGContextScaleCTM(context, -scaleRatio, scaleRatio);
		CGContextTranslateCTM(context, -height, 0);
	}
	else {
		CGContextScaleCTM(context, scaleRatio, -scaleRatio);
		CGContextTranslateCTM(context, 0, -height);
	}
	
	CGContextConcatCTM(context, transform);
	
	CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
	UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	return imageCopy;
}

- (UIImage*) getImageFromScreen {
	CGImageRef temp = CGBitmapContextCreateImage(UIGraphicsGetCurrentContext());
	UIImage *viewImage = [UIImage imageWithCGImage:temp];
	CGImageRelease(temp);
	return viewImage;
}

- (void) drawImage: (UIImage*) image :(int) x :(int) y {
	@try{
		[image drawAtPoint:CGPointMake(x, y)];
	}
	@catch(id exception)
	{}
}

- (void) drawImage: (UIImage*) image :(int) x :(int) y :(float) fAlpha{
	@try
	{
		if (fAlpha == 0.0)
			return;
		[image drawAtPoint:CGPointMake(x, y) blendMode:kCGBlendModeSourceAtop alpha:fAlpha];
	}
	@catch(id exception)
	{}
}

/*
	 ex:
		[self drawBlend:[self getImageCachedFromFile:@"ev_029"]   :0 :0 :1.0 :kCGBlendModeCopy];
		[self drawBlend:[self getImageCachedFromFile:@"mask_030"] :0 :0 :1.0 :kCGBlendModeOverlay];
 */
- (void) drawBlend:(UIImage*) image :(int)  x :(int) y  :(float) fAlpha :(CGBlendMode) blendMode {
	@try
	{
		if (fAlpha == 0.0)
			return;
		[image drawAtPoint:CGPointMake(x, y) blendMode:blendMode alpha:fAlpha];
	}
	@catch(id exception)
	{}
}

- (void) drawImage: (UIImage*) image :(int) sx :(int) sy :(int) dx :(int) dy :(int) width :(int) height{
	@try
	{
		[self drawImage:image :sx :sy :dx :dy :width :height :width :height];
	}
	@catch(id exception)
	{}
}

- (void) drawImage: (UIImage*) image :(int) sx :(int) sy :(int) dx :(int) dy :(int) sw :(int) sh :(int) dw :(int) dh{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	@try
	{
		CGImageRef cgImage  = [image CGImage];
		CGRect     subRect  = CGRectMake(sx, sy, sw, sh);
		CGImageRef subImage = CGImageCreateWithImageInRect(cgImage, subRect);
		
		CGContextSaveGState(gid);
		CGContextTranslateCTM(gid, 0, 0);
		CGContextScaleCTM(gid, 1, -1);
		CGContextDrawImage(gid, CGRectMake(dx, -dy - dh, dw, dh), subImage);
		CGContextRestoreGState(gid);
		CGImageRelease(subImage);
	}
	@catch(id exception)
	{}
}

- (void) drawImage: (UIImage*)image :(int) sx :(int) sy :(int) dx :(int) dy :(int) sw :(int) sh :(int) dw :(int) dh :(float) fAlpha{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	@try
	{
		CGImageRef cgImage  = [image CGImage];
		CGRect     subRect  = CGRectMake(sx, sy, sw, sh);
		CGImageRef subImage = CGImageCreateWithImageInRect(cgImage, subRect);
		
		CGContextSaveGState(gid);
		CGContextTranslateCTM(gid, 0, 0);
		CGContextScaleCTM(gid, 1, -1);
		CGContextSetAlpha(gid, fAlpha);
		CGContextDrawImage(gid, CGRectMake(dx, -dy - dh, dw, dh), subImage);
		CGContextRestoreGState(gid);
		CGImageRelease(subImage);
	}
	@catch(id exception)
	{}
}

- (void) drawTitleImage: (UIImage*) image: (CGRect) rcRect :(CGFloat) fAlpha{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	@try
	{
		CGImageRef cgImage  = [image CGImage];
		
		CGContextSaveGState(gid);
		CGContextSetAlpha(gid, fAlpha);
		
		CGContextClipToRect(gid, rcRect);
		CGContextDrawTiledImage(gid, CGRectMake(0, 0, image.size.width, image.size.height), cgImage);
		
		CGContextRestoreGState(gid);
		CGImageRelease(cgImage);
	}
	@catch(id exception)
	{}
}



- (UIImage*) getMaskImage:(UIImage*) maskImage {
	
	CGImageRef maskRef = maskImage.CGImage; 
	CGImageRef mask = CGImageMaskCreate(CGImageGetWidth(maskRef),
										CGImageGetHeight(maskRef),
										CGImageGetBitsPerComponent(maskRef),
										CGImageGetBitsPerPixel(maskRef),
										CGImageGetBytesPerRow(maskRef),
										CGImageGetDataProvider(maskRef),
										NULL,
										FALSE);
	UIImage *retImage = [UIImage imageWithCGImage:mask];
	CGImageRelease(mask);
	// CGImageRelease(maskRef);
	
	return retImage;
}

- (UIImage*) getImageWithMaskImage :(UIImage*) imgSource :(UIImage*) maskImage {
	CGImageRef mask = [[self getMaskImage:maskImage] CGImage];
	CGImageRef masked = CGImageCreateWithMask([imgSource CGImage], mask);
	// CGImageRelease(mask);
	UIImage *retImage = [UIImage imageWithCGImage:masked];
	CGImageRelease(masked);
	return retImage;
}

/* ex:
		CGFloat clrMask[6] = {0,255,0,255,0,200};
		[self getImageWithMaskColor:[self getImageCachedFromFile:@"ev_029"] :clrMask];
*/
- (UIImage*) getImageWithMaskColor:(UIImage*) imgSource :(CGFloat*) maskColor{
	CGImageRef masked = CGImageCreateWithMaskingColors([imgSource CGImage], maskColor);
	UIImage *retImage = [UIImage imageWithCGImage:masked];
	CGImageRelease(masked);
	return retImage;
}

- (void) drawImageWithMaskImage:(UIImage*) orgImage :(UIImage*) maskImage :(CGRect) rcRect {
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSaveGState(gid);

	CGContextClipToMask(gid, rcRect, maskImage.CGImage);
	[self drawImage:orgImage :0 :0];

	CGContextRestoreGState(gid);
}


- (void) vir_drawString:(NSString*) fmn :(int) x :(int) y :(UIColor*) color :(UIFont*) font{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSetAlpha(gid, 1);
	CGContextSetFillColorWithColor(gid, [color CGColor]);
	[fmn drawAtPoint:CGPointMake(x, y) withFont:font];
}

-(void) vir_drawString:(NSString*) fmn :(int) x :(int) y :(UIColor*) bkcolor :(UIColor*) stcolor :(UIFont*) font{
	CGContextRef gid = UIGraphicsGetCurrentContext();
	CGContextSetAlpha(gid, 1);
	CGContextSetFillColorWithColor(gid, [stcolor CGColor]);
	[fmn drawAtPoint:CGPointMake(x+2, y+2) withFont:font];
	CGContextSetFillColorWithColor(gid, [stcolor CGColor]);
	[fmn drawAtPoint:CGPointMake(x+1, y+1) withFont:font];
	CGContextSetFillColorWithColor(gid, [bkcolor CGColor]);
	[fmn drawAtPoint:CGPointMake(x, y) withFont:font];
}

- (CGSize) getStringSize:(NSString*)fmn :(UIFont*)font{
	CGSize textSize = [fmn sizeWithFont:font];
	return textSize;
}

-(NSString*) convertBanToZenString:(NSString*) strOrigin{
	unichar chSrc;
    const int length = sizeof(unichar)*([strOrigin length]+1);
	unichar *chDest = malloc(length);
	memset(chDest, 0, length);
	
	for (int i=0; i<[strOrigin length]; i++) {
		chSrc = [strOrigin characterAtIndex:i];
		
		if (chSrc >= '0' && chSrc <= '9') { 
			chDest[i] = (unichar)(65296 + chSrc - '0'); // '０' -> 65296 '９' -> 65305
		}
		else if (chSrc >= 'A' && chSrc <= 'Z') { 
			chDest[i] = (unichar)(65313 + chSrc - 'A'); // 'Ａ' -> 65313 'Ｚ' -> 65338
		}
		else if (chSrc >= 'a' && chSrc <= 'z') { 
			chDest[i] = (unichar)(65345 + chSrc - 'a'); // 'ａ' -> 65345 'ｚ' -> 65370
		}
		else {
			chDest[i] = chSrc;
		}
		
		switch (chSrc)
		{
			case '_': chDest[i] = 65343; break; // '＿' ->
			case '!': chDest[i] = 65281; break; // '！' ->
			case '?': chDest[i] = 65311; break; // '？' ->
			case '<': chDest[i] = 65308; break; // '＜' ->
			case '>': chDest[i] = 65310; break; // '＞' ->
			case '(': chDest[i] = 65288; break; // '（' ->
			case ')': chDest[i] = 65289; break; // '）' ->
			case ' ': chDest[i] = 12288; break; // '　' ->
				//			case '-': chDest[i] = 65293; break; // '−'  ->
		}
	}
	NSString *strRet = [NSString stringWithCharacters:(const unichar*)chDest length:[strOrigin length]];
	
	free(chDest);
	return strRet;
}

-(NSString*) convertZenToBanString:(NSString*) strOrigin{
	
	unichar chSrc;
    const int length = sizeof(unichar)*([strOrigin length]+1);
	unichar *chDest = malloc(length);
	memset(chDest, 0, length);
	
	for (int i=0; i<[strOrigin length]; i++) {
		chSrc = [strOrigin characterAtIndex:i];
		
		if (chSrc >= 65296 && chSrc <= 65305) { // '０' -> 65296 '９' -> 65305
			chDest[i] = (unichar)('0' + chSrc - 65296);
		}
		else if (chSrc >= 65313 && chSrc <= 65338) { // 'Ａ' -> 65313 'Ｚ' -> 65338
			chDest[i] = (unichar)('A' + chSrc - 65313);
		}
		else if (chSrc >= 65345 && chSrc <= 65370) { // 'ａ' -> 65345 'ｚ' -> 65370
			chDest[i] = (unichar)('a' + chSrc - 65345);
		}
		else {
			chDest[i] = chSrc;
		}
		
		switch (chSrc)
		{
			case 65343: chDest[i] = '_'; break; // '＿' ->
			case 65281: chDest[i] = '!'; break; // '！' ->
			case 65311: chDest[i] = '?'; break; // '？' ->
			case 65308: chDest[i] = '<'; break; // '＜' ->
			case 65310: chDest[i] = '>'; break; // '＞' ->
			case 65288: chDest[i] = '('; break; // '（' ->
			case 65289: chDest[i] = ')'; break; // '）' ->
			case 12288: chDest[i] = ' '; break; // '　' ->
				//			case 65293: chDest[i] = '-'; break; // '−' ->
		}
	}
	NSString *strRet = [NSString stringWithCharacters:(const unichar*)chDest length:[strOrigin length]];
	
	free(chDest);
	return strRet;
}


-(void) clearAllSubView{
	NSEnumerator* enumerator = [self.subviews objectEnumerator];
	UIView* anObject;
	while (anObject = [enumerator nextObject]) {
		[anObject removeFromSuperview];
	}
}

-(void) clearSubView:(int) tag{
	NSEnumerator* enumerator = [self.subviews objectEnumerator];
	UIView* anObject;
	while (anObject = [enumerator nextObject]) {
		if (anObject.tag == tag)
			[anObject removeFromSuperview];
	}
}

-(void) animationTransition:(int) nType :(int) nDir :(NSTimeInterval) fTime{
	
	CATransition *animation = [CATransition animation];
	[animation setDelegate:self];
	
	NSString *strDirection = @"";
	
	switch (nDir) {
		case 0:
			strDirection = kCATransitionFromRight;
			break;
		case 1:
			strDirection = kCATransitionFromLeft;
			break;
		case 2:
			strDirection = kCATransitionFromTop;
			break;
		case 3:
			strDirection = kCATransitionFromBottom;
			break;
		default:
			strDirection = kCATransitionFromRight;
			break;
	}
	
	switch (nType) {
		case 0: // fade
			[animation setType:kCATransitionFade];
			break;
		case 1: // move in
			[animation setType:kCATransitionMoveIn];
			[animation setSubtype:strDirection];
			break;
		case 2: // push
			[animation setType:kCATransitionPush];
			[animation setSubtype:strDirection];
			break;
		case 3: // reveal
			[animation setType:kCATransitionReveal];
			[animation setSubtype:strDirection];
			break;
		default:
			[animation setType:kCATransitionFade];
			break;
	}
	
	[animation setDuration:fTime];
	[animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
	[[self layer] addAnimation:animation forKey:@"animiTransition"];
	
}


-(CGFloat) DegreesToRadians:(CGFloat) degrees {
	return degrees * M_PI / 180;
}

-(CGFloat) RadiansToDegrees:(CGFloat) radians {
	return radians * 180/M_PI;
}

-(void) errorOccured:(NSString*)content{
}

@end
