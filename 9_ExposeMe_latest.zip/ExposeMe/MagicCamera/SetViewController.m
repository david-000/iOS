//
//  SetViewController.m
//  SnapANote
//
//  Created by Thomas on 9/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SetViewController.h"
#import "MagicCameraAppUtils.h"
#import "MagicCameraAppDelegate.h"
#import "InstructionViewController.h"


@implementation DataCell

@synthesize title, index, enable;

- (id) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier INDEX:(int)idx{
	if (self == [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
		title = [[UILabel alloc] initWithFrame:CGRectZero];
		title.textAlignment = UITextAlignmentLeft;
		title.font = [UIFont boldSystemFontOfSize:16];
        title.textColor = [UIColor blackColor];
		title.backgroundColor = [UIColor clearColor];
        title.text = @"12:45";
        title.numberOfLines = 2;
		[self addSubview:title];
        
        lblcomment = [[UILabel alloc] initWithFrame:CGRectZero];
		lblcomment.textAlignment = UITextAlignmentLeft;
		lblcomment.font = [UIFont boldSystemFontOfSize:12];
        lblcomment.textColor = [UIColor grayColor];
		lblcomment.backgroundColor = [UIColor clearColor];
        lblcomment.text = @"comment";
        lblcomment.numberOfLines = 2;
		[self addSubview:lblcomment];
        
        index = idx;
        switchEnable = [[RCSwitchClone alloc] initWithFrame:CGRectZero];
        [switchEnable addTarget:self action:@selector(actionSwtichEnable:) forControlEvents:UIControlEventValueChanged];
		[self addSubview:switchEnable];
    }
	
	return self;
}

- (void) setDelegate:(id)delegate
{
    delegate_ = delegate;
}

- (void)setInfo:(NSString*)str comment:(NSString*)comment OPTION:(BOOL)option INDEX:(int)idx{
    if (index == idx) {
        title.text = str;
        lblcomment.text = comment;
        enable = option;
        [switchEnable setOn:enable];
    }
}

- (void)setSwitchValue:(BOOL)value
{
    enable = value;
    [switchEnable setOn:enable];
}

- (BOOL)isSwitchValue
{
    return enable;
}

- (void)actionSwtichEnable:(id)sel {
    if(enable != switchEnable.on)
    {
        enable = switchEnable.on;
        [delegate_ setOption:index OPTION:enable];
    }
}


- (void) dealloc {
    [switchEnable release];
	[title release];
    [lblcomment release];
	[super dealloc];
}

- (void) layoutSubviews {
	[super layoutSubviews];
	if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        title.frame = CGRectMake(20.0f, 5.0f, 150.0f, 50.0f);
        lblcomment.frame = CGRectMake(20.0f, 48.0f, 300.0f, 20.0f);
        switchEnable.frame = CGRectMake(210.0f, 17.0f, 94.0f, 27.0f);
	} else {
        title.frame = CGRectMake(60.0f, 15.0f, 150.0f, 30.0f);
        lblcomment.frame = CGRectMake(60.0f, 48, 500.0f, 20.0f);
        switchEnable.frame = CGRectMake(610.0f, 17.0f, 94.0f, 27.0f);
	}
}

@end

@implementation SliderCell

@synthesize title, index, enable;

- (id) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier INDEX:(int)idx{
	if (self == [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
		title = [[UILabel alloc] initWithFrame:CGRectZero];
		title.textAlignment = UITextAlignmentLeft;
		title.font = [UIFont boldSystemFontOfSize:16];
        title.textColor = [UIColor blackColor];
		title.backgroundColor = [UIColor clearColor];
        title.text = @"12:45";
        title.numberOfLines = 2;
		[self addSubview:title];
        
        lblcomment = [[UILabel alloc] initWithFrame:CGRectZero];
		lblcomment.textAlignment = UITextAlignmentLeft;
		lblcomment.font = [UIFont boldSystemFontOfSize:12];
        lblcomment.textColor = [UIColor grayColor];
		lblcomment.backgroundColor = [UIColor clearColor];
        lblcomment.text = @"comment";
        lblcomment.numberOfLines = 2;
		[self addSubview:lblcomment];
        
        index = idx;
        
        value = [[UILabel alloc] initWithFrame:CGRectZero];
        value.backgroundColor = [UIColor clearColor];
        
        slider = [[UISlider alloc] initWithFrame:CGRectZero];
        slider.minimumValue = 0;
        slider.maximumValue = 30;
        
        slider.value = 10;
        
        [slider addTarget:self action:@selector(onslider:) forControlEvents:UIControlEventValueChanged];
        
        NSString *sValue = [NSString stringWithFormat:@"%d S", (int)slider.value];
        value.text = sValue;
        
		[self addSubview:slider];
        [self addSubview:value];
    }
	
	return self;
}

- (void) setDelegate:(id)delegate
{
    delegate_ = delegate;
}

- (void)setInfo:(NSString*)str comment:(NSString*)comment delytime:(int)delytime{

    if(delytime > 30)
        delytime = 30;
    
    title.text = str;
    lblcomment.text = comment;
    selftimer = delytime;
    
    slider.value = (float)selftimer;
    
    NSString *sValue = [NSString stringWithFormat:@"%d s", (int)slider.value];
    value.text = sValue;
}

- (void) dealloc {
    [slider release];
	[title release];
    [lblcomment release];
    [value release];
	[super dealloc];
}

- (void) layoutSubviews {
	[super layoutSubviews];
	if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        title.frame = CGRectMake(20.0f, 5.0f, 150.0f, 50.0f);
        lblcomment.frame = CGRectMake(20.0f, 48.0f, 300.0f, 20.0f);
        value.frame = CGRectMake(160.0f, 17.0f, 50.0f, 27.0f);
        slider.frame = CGRectMake(210.0f, 17.0f, 94.0f, 27.0f);
	} else {
        title.frame = CGRectMake(60.0f, 15.0f, 150.0f, 30.0f);
        lblcomment.frame = CGRectMake(60.0f, 48, 500.0f, 20.0f);
        value.frame = CGRectMake(500.0f, 17.0f, 100.0f, 27.0f);
        slider.frame = CGRectMake(610.0f, 17.0f, 94.0f, 27.0f);
	}
}

- (void) onslider:(id)sel
{
    selftimer = (int)slider.value;
    
    NSString *sValue = [NSString stringWithFormat:@"%d s", selftimer];
    value.text = sValue;
    
    [delegate_ setSelftimer:selftimer];
}

@end

@implementation SegmentCell
@synthesize title, index, segmentCtrl;
@synthesize m_nTableIndex;  

- (id) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier INDEX:(int)idx nKind:(int)nTableIndex{
    m_nTableIndex   =   nTableIndex;
    if (self == [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        if( nTableIndex == 0 ){
            title = [[UILabel alloc] initWithFrame:CGRectZero];
            title.textAlignment = UITextAlignmentLeft;
            title.font = [UIFont boldSystemFontOfSize:16];
            title.textColor = [UIColor blackColor];
            title.backgroundColor = [UIColor clearColor];
            title.text = @"Self timer";
            title.numberOfLines = 2;
            [self addSubview:title];
            
            lblcomment = [[UILabel alloc] initWithFrame:CGRectZero];
            lblcomment.textAlignment = UITextAlignmentLeft;
            lblcomment.font = [UIFont boldSystemFontOfSize:12];
            lblcomment.textColor = [UIColor grayColor];
            lblcomment.backgroundColor = [UIColor clearColor];
            lblcomment.text = @"comment";
            lblcomment.numberOfLines = 2;
            [self addSubview:lblcomment];
            
            index = idx;
                    
            NSArray* array = [NSArray arrayWithObjects:@"0", @"1", @"3", @"5", @"10", nil];
//            NSArray* array = [NSArray arrayWithObjects:@"0", @"1", @"3", @"4", @"5",@"6", nil];
            
            segmentCtrl = [[UISegmentedControl alloc] initWithItems:array];
            [segmentCtrl setFrame:CGRectZero];
            [segmentCtrl addTarget:self action:@selector(actionSelected:) forControlEvents:UIControlEventValueChanged];
            [self addSubview:segmentCtrl];
            
        }else if( nTableIndex == 7 ){
            title = [[UILabel alloc] initWithFrame:CGRectZero];
            title.textAlignment = UITextAlignmentLeft;
            title.font = [UIFont boldSystemFontOfSize:16];
            title.textColor = [UIColor blackColor];
            title.backgroundColor = [UIColor clearColor];
            title.text = @"Picture Size";
            title.numberOfLines = 2;
            [self addSubview:title];
            
            lblcomment = [[UILabel alloc] initWithFrame:CGRectZero];
            lblcomment.textAlignment = UITextAlignmentLeft;
            lblcomment.font = [UIFont boldSystemFontOfSize:12];
            lblcomment.textColor = [UIColor grayColor];
            lblcomment.backgroundColor = [UIColor clearColor];
            lblcomment.text = @"comment";
            lblcomment.numberOfLines = 2;
            [self addSubview:lblcomment];
            
            index = idx;
                    
#ifdef FREE_VERSION            
            NSArray* array = [NSArray arrayWithObjects:@"Low", @"Med", nil];
#else
            NSArray* array = [NSArray arrayWithObjects:@"Low", @"Med", @"High", nil];
#endif            
            
            segmentCtrl = [[UISegmentedControl alloc] initWithItems:array];
            UIFont *font = [UIFont boldSystemFontOfSize:12.0f];
            NSDictionary *attributes = [NSDictionary dictionaryWithObject:font
                                                                   forKey:UITextAttributeFont];
            [segmentCtrl setTitleTextAttributes:attributes forState:UIControlStateNormal];
            [segmentCtrl setFrame:CGRectZero];
            [segmentCtrl addTarget:self action:@selector(actionSelected:) forControlEvents:UIControlEventValueChanged];
            [self addSubview:segmentCtrl];
            
        }
    }
	
	return self;

}

- (id) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier INDEX:(int)idx{
	if (self == [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
            title = [[UILabel alloc] initWithFrame:CGRectZero];
            title.textAlignment = UITextAlignmentLeft;
            title.font = [UIFont boldSystemFontOfSize:16];
            title.textColor = [UIColor blackColor];
            title.backgroundColor = [UIColor clearColor];
            title.text = @"Self timer";
            title.numberOfLines = 2;
            [self addSubview:title];
        
        lblcomment = [[UILabel alloc] initWithFrame:CGRectZero];
		lblcomment.textAlignment = UITextAlignmentLeft;
		lblcomment.font = [UIFont boldSystemFontOfSize:12];
        lblcomment.textColor = [UIColor grayColor];
		lblcomment.backgroundColor = [UIColor clearColor];
        lblcomment.text = @"comment";
        lblcomment.numberOfLines = 2;
		[self addSubview:lblcomment];
        
            index = idx;
                    
            NSArray* array = [NSArray arrayWithObjects:@"0", @"1", @"3", @"5", @"10", nil];
            
            segmentCtrl = [[UISegmentedControl alloc] initWithItems:array];
            [segmentCtrl setFrame:CGRectZero];
            [segmentCtrl addTarget:self action:@selector(actionSelected:) forControlEvents:UIControlEventValueChanged];
            [self addSubview:segmentCtrl];

    }
	
	return self;
}

- (void) setDelegate:(id)delegate
{
    delegate_ = delegate;
}

- (void)setInfo:(NSString*)str comment:(NSString*)comment INDEX:(int)idx{
    title.text = str;
    lblcomment.text = comment;
    [segmentCtrl setSelectedSegmentIndex:idx];
}
//
- (void)actionSelected:(id)sel {
    index = segmentCtrl.selectedSegmentIndex;
    if( m_nTableIndex == 0 )
        [delegate_ setSelftimer:index];
    else {
        //save picturesize code
        [ delegate_ setSelfpicturetype:(enum PictureSize_Type)index ];
    }
    
}


- (void) dealloc {
    [segmentCtrl release];
	[title release];
    [lblcomment release];
	[super dealloc];
}
//
- (void) layoutSubviews {
	[super layoutSubviews];
	if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        title.frame = CGRectMake(20.0f, 5.0f, 100.0f, 50.0f);
        lblcomment.frame = CGRectMake(20.0f, 48.0f, 300.0f, 20.0f);
        segmentCtrl.frame = CGRectMake(150.0f, 14.0f, 150.0f, 30.0f);
	} else {
        title.frame = CGRectMake(60.0f, 15.0f, 150.0f, 30.0f);
        lblcomment.frame = CGRectMake(60.0f, 48, 500.0f, 20.0f);
        segmentCtrl.frame = CGRectMake(464.0f, 17.0f, 240.0f, 27.0f);
	}
}

@end

@implementation SetViewController
//@synthesize delegate;
@synthesize fExposureAdjust, fExposureLock, fScreenShutter, fAutoSave, selftimer, strSetRecipient;
@synthesize selfpicturetype;
@synthesize fVolumeShutter;
@synthesize fSoundEffect;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}

- (void)dealloc
{

    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.navigationController.navigationBarHidden = YES;

}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];

    fExposureAdjust = [g_AppUtils useExposureAdjust];//g_GameUtils.bExposureAdjust;
    fExposureLock   = [g_AppUtils useExposureLock];//g_GameUtils.bExposureLock;
    fScreenShutter  = [g_AppUtils useScreenShutter];//g_GameUtils.bScreenSutter;
    fAutoSave       = [g_AppUtils useAutoSave];;//g_GameUtils.bAutoSave;
    fAutoSaveToPhotoLib = [g_AppUtils useAutoSaveToPhotoLibrary];
    selftimer       = [g_AppUtils selfTimerDelay];//g_GameUtils.nSetSelfTimer;
    fSoundEffect    = [ g_AppUtils useSoundEffect ];                
    fVolumeShutter  = [ g_AppUtils   useVolumeEffect ];             
    selfpicturetype = [ g_AppUtils  pictureSizeType ];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction) onSave
{
    [g_AppUtils setSelfTimerDelay:selftimer];
    [g_AppUtils setUseExposureAdjust:fExposureAdjust];
    [g_AppUtils setUseExposureLock:fExposureLock];
    [g_AppUtils setUseScreenShutter:fScreenShutter];
    [g_AppUtils setUseAutoSave:fAutoSave];
    [g_AppUtils setUseAutoSaveToPhotoLibrary:fAutoSaveToPhotoLib];
    [g_AppUtils setPictureSizeType:selfpicturetype ];               
    [g_AppUtils setUseVolumeEffect:fVolumeShutter ];
    [g_AppUtils setUseSoundEffect:fSoundEffect ];
    [g_AppUtils writeAppSettings];
//     ViewController* controller = (ViewController*)delegate;
//    if (selftimer != 0) {
//        [controller.recordItem setImage:[UIImage imageNamed:@"timer.png"]];
//    }
//    else{
//        [controller.recordItem setImage:[UIImage imageNamed:@"take.png"]];        
//    }
    [self dismissModalViewControllerAnimated:YES];
}

- (IBAction) onCancel
{
    [self dismissModalViewControllerAnimated:YES];
}

- (void) setOption:(int)index OPTION:(BOOL)option
{
    if (ftableinit ==NO) 
    {
        if(index == 1){
            fAutoSave = option;
            if(fAutoSave)
                fAutoSaveToPhotoLib = YES;
        }else if(index == 2){ 
            fAutoSaveToPhotoLib = option;
            if(fAutoSaveToPhotoLib == NO)
                fAutoSave = NO;
        }else if(index == 3){
            fVolumeShutter = option;
            
            if( fVolumeShutter )
            {
                [[MagicCameraAppDelegate sharedDelegate] removeVolumnView];
                [[MagicCameraAppDelegate sharedDelegate] insertVolumnView]; 
            } else {
                [[MagicCameraAppDelegate sharedDelegate] removeVolumnView];
            }

            
        }else if(index == 4){
            fScreenShutter = option;
/*            if(fScreenShutter == YES)
            {
                fExposureAdjust = NO;
                fExposureLock = NO;
            }*/
        }else if( index == 5 ){
            fSoundEffect    = option;
        }else if( index == 6 ){
            fExposureAdjust = option;
//            if(fExposureAdjust == YES)
//                fScreenShutter = NO;
        }
//        else if( index == 7 ){
//            fExposureLock   =  option;
//            if(fExposureLock == YES)
//                fScreenShutter = NO;
//        }
        
    }
    ftableinit = NO;
    
    DataCell *cell;
    for (int n = 1 ;  n < 7 ;  n++) 
    {
        NSIndexPath *index = [NSIndexPath indexPathForRow:n inSection:0];
        cell = (DataCell*)[tblSetting cellForRowAtIndexPath:index];
        
        BOOL boolvalue = YES;
        switch (n) {
            case 1:
                boolvalue = fAutoSave;
                break;
            case 2:
                boolvalue = fAutoSaveToPhotoLib;
                break;
            case 3:
                boolvalue = fVolumeShutter;
                break;
            case 4:
                boolvalue = fScreenShutter;
                break;
            case 5:
                boolvalue = fSoundEffect;
                break;
            case 6:
                boolvalue = fExposureAdjust;
                break;
//            case 7:
//                boolvalue = fExposureLock;
//                break;
        }
        
        [cell setSwitchValue:boolvalue];
    }
}

- (void) setEmailText:(NSString*)str
{
    [self setStrSetRecipient:str];
}

#pragma mark Table dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 2;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    if (section == 0)
        return 8;
    else if (section == 1)
        return 3;
    return 0;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{// fixed font style. use custom view (UILabel) if you want something different
    
    if (section == 0) {
        return @"Options";
    } else if (section == 1) {
        return @"Support";
    }

    return @"";
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ftableinit = YES;    
    NSString *CellIdentifier = @"Cell1";
    if (indexPath.section == 0) 
    {
        CellIdentifier = @"Cell1";
//        Yuan start
//        if (indexPath.row != 0) {
        
        if (indexPath.row > 0 && indexPath.row <= 6) {
                    
            DataCell *cell = (DataCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[[DataCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier INDEX:indexPath.row] autorelease];
            }
            [cell setDelegate:self];
            
//            if (indexPath.row == 1){
//                [cell setInfo:@"Screen Shutter" OPTION:fScreenShutter INDEX:1];
//            } else if (indexPath.row == 2){
//                [cell setInfo:@"Auto-save " OPTION:fAutoSave INDEX:2];
//            }
            if (indexPath.row == 1){
                [cell setInfo:@"Auto Save to Favourites " comment:@"Saves automatically to Favourites" OPTION:fAutoSave INDEX:1];
            }else if( indexPath.row == 2 ){
                [cell setInfo:@"Auto Save to Photo Library" comment:@"Saves automatically to Photo Library" OPTION:fAutoSaveToPhotoLib INDEX:2 ];
            } else if (indexPath.row == 3){
                [cell setInfo:@"Volume Shutter" comment:@"Use volume-up to fire shutter" OPTION:fVolumeShutter INDEX:3 ];
            }else if( indexPath.row == 4 ){
                [cell setInfo:@"Screen Shutter" comment:@"Use entire screen to fire shutter" OPTION:fScreenShutter INDEX:4 ];
            }else if( indexPath.row == 5 ){
                [cell setInfo:@"Sound Effects" comment:@"Enable sound effects" OPTION:fSoundEffect INDEX:5 ];
            }else if( indexPath.row == 6 ){
                [cell setInfo:@"Exposure Adjust" comment:@"Change exposure level when reviewing image" OPTION:fExposureAdjust INDEX:6 ];
            }
//            else if( indexPath.row == 7 ){
//                [cell setInfo:@"Exposure Lock" comment:@"Lock exposure for all photos, double tap to reset" OPTION:fExposureLock INDEX:7 ];
//            }
            
            ftableinit = NO;    
            return cell;            
        }
        else if( indexPath.row == 0 ){
            CellIdentifier = @"SelfTimeCell";
            SliderCell *cell = (SliderCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[[SliderCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier INDEX:indexPath.row] autorelease];
            }
            [cell setDelegate:self];
            [cell setInfo:@"Self Timer" comment:@"Delay before shutter fires(sec)" delytime:selftimer];
             ftableinit = NO;    
            
            return cell;
        }else if( indexPath.row == 7 ){
            CellIdentifier = @"ImageSizeCell";
            SegmentCell *cell = (SegmentCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[[SegmentCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier INDEX:indexPath.row nKind:indexPath.row ] autorelease];
            }
            [cell setDelegate:self];
            [cell setInfo:@"Image Quality" comment:@"Adjust the image quality of your ExposeMe Photos" INDEX:selfpicturetype];
             ftableinit = NO;    
            return cell;
        }
    } 
    else if (indexPath.section == 1) 
    {
        CellIdentifier = @"Cell2";
        if (indexPath.row == 0)
        {
            UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
            }
            
            cell.textLabel.text = @"Instructions";
            
            return cell;
        }
        else if (indexPath.row == 1)
        {
            UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
            }
            
            cell.textLabel.text = @"ExposeMe Feedback";
            
            return cell;
        }
        else if(indexPath.row == 2)
        {
            UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
            }
            
            cell.textLabel.text = @"Rate App";
            
            return cell;
        }
//        else if(indexPath.row == 2)
//        {
//            UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
//            if (cell == nil) {
//                cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
//            }
//            
//            cell.textLabel.text = @"Facebook Login";
//            
//            return cell;
//        }
//        else if(indexPath.row == 3)
//        {
//            UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
//            if (cell == nil) {
//                cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
//            }
//            
//            cell.textLabel.text = @"Twitter Login";
//            
//            return cell;
//        }
    }

    return nil;
}

#pragma mark Table View delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
    [txtRecipient resignFirstResponder];
    
    if(indexPath.section == 1)
    {
        if(indexPath.row == 0)
            [self onInstruction];
        else if(indexPath.row == 1)
            [self onExposeMeSupport];
        else if(indexPath.row == 2) {
            [self gotoRate];
        }
    }
    
	[tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat height = 0.0f;
    if (indexPath.section == 0) {
        height = 70.0f;
    } else if (indexPath.section == 1) {
        height = 44.0f;
    }
    
    return height;
}

- (void) gotoRate
{
    NSString *str = @"itms-apps://ax.itunes.apple.com/WebObjects/MZStore.woa";
    str = [NSString stringWithFormat:@"%@/wa/viewContentsUserReviews?", str]; 
    str = [NSString stringWithFormat:@"%@type=Purple+Software&id=", str];
    
    // Here is the app id from itunesconnect
    str = [NSString stringWithFormat:@"%@%@", str, APPID]; 
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
    
}


#pragma mark touch proc
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [txtRecipient resignFirstResponder];
}

#pragma mark UITextFiledDelegate

- (IBAction)textFieldFinished:(id)sender
{
    [sender resignFirstResponder]; 
//    [self checkEmailAddres:txtRecipient.text];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self checkEmailAddres:textField.text];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    txtRecipient = textField;
}

-(void) keyboardWillShow:(NSNotification *) note
{
	[self animateTextField:YES]; 
}

-(void) keyboardWillHide:(NSNotification *) note
{
	[self animateTextField:NO]; 
}

- (void) animateTextField:(BOOL) up {
	const int movementDistance = 216; // tweak as needed     352
	const float movementDuration = 0.3f; // tweak as needed      
	int movement = (up ? -movementDistance : movementDistance);      
	[UIView beginAnimations: @"anim" context: nil];     
	[UIView setAnimationBeginsFromCurrentState: YES];     
	[UIView setAnimationDuration: movementDuration];     
	self.view.frame = CGRectOffset(self.view.frame, 0, movement);     
	[UIView commitAnimations]; 
}

- (void) checkEmailAddres:(NSString*)ea
{
    // get the first character, capitalized
    NSString *capital = [[ea substringToIndex:1] capitalizedString];
    
    // then compare to your oldstring
    if ( [[ea substringToIndex:1] isEqualToString:capital] ) {
        // do stuff...
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Snap-A-Note"
                                                            message:@"The first letter of your e-mail address is in uppercase. Please make sure email address."
                                                           delegate:nil
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
    }
    [self setStrSetRecipient:ea];
}

- (void) onInstruction {
    InstructionViewController * vc = [[InstructionViewController alloc] initWithNibName:@"InstructionViewController" bundle:nil];
    
//    UINavigationController * nav = [[UINavigationController alloc] initWithRootViewController:vc];
    
    [self.navigationController pushViewController:vc animated:YES];
    
//    [nav release];
    [vc release];
    
}
- (void) onExposeMeSupport
{
    if (![MFMailComposeViewController canSendMail]) {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No Mail Accounts" message:@"Please set up a Mail account in order to send email."
													   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];	
		[alert release];
		return;
	}
	MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
	picker.mailComposeDelegate = self;
	
	NSString* content;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
        content = @"Sent via ExposeMe for iPhone";
    else
        content = @"Sent via ExposeMe for iPad";
    
	[picker setSubject:@"ExposeMe Feedback"];
	
//	[picker setMessageBody:content isHTML:NO]; 

    NSMutableArray *emailAddrs = [[NSMutableArray alloc] init];

	NSString *emailAddr = @"frozenmonkeyapps@gmail.com";
    [emailAddrs addObject: emailAddr];
	[picker setToRecipients: emailAddrs];
	
	picker.navigationBar.barStyle = UIBarStyleDefault; 
	
	[self presentModalViewController:picker animated:YES];
	//	[emailAddrs release];
	[picker release];    
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{ 
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
			break;
		case MFMailComposeResultSaved:
			break;
		case MFMailComposeResultSent:
			break;
		case MFMailComposeResultFailed:
			break;
			
		default:
		{
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Email" message:@"Sending Failed - Unknown Error :-("
														   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
			[alert show];
			[alert release];
		}
			
			break;
	}
	[self dismissModalViewControllerAnimated:YES];
}

@end
