//
//  InstructionViewController.m
//  ExposeMe
//
//  Created by Gold Luo on 8/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "InstructionViewController.h"
#import "MagicCameraAppUtils.h"


@interface InstructionViewController ()

@end

@implementation InstructionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationController.navigationBarHidden = NO;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
    self.navigationItem.title = @"Instructions";
    
    NSString *fileName = @"";
#ifdef FREE_VERSION
    fileName = @"instruction_free.html";
#else
    fileName = @"instruction_paid.html";
#endif
    
    NSString * myHTML = [self stringFromFileNamed: fileName];
    [m_webView loadHTMLString:myHTML baseURL:nil];
    m_webView.backgroundColor = [UIColor clearColor];
    [m_webView setOpaque:NO];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
}

- (NSString*) stringFromFileNamed:(NSString *) name
{
    NSString * result = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:name ofType:nil] encoding:NSUTF8StringEncoding error:nil];
    
    return result;
}

@end
