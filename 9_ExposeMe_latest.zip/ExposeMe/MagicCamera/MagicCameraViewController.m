//
//  ViewController.m
//  MagicCamera
//
//  Created by i Pro on 2/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MagicCameraViewController.h"
#import "MagicCameraAppDelegate.h"
#import "GLES2View.h"
#import "LivePreview.h"
#import "ExposureSettingView.h"
#import "EditSettingView.h"
#import "AleartWaitView.h"
#import "Imaging.h"
#import "SetViewController.h"

#import "BackgroundViewController.h"            
#import "InfoViewController.h"

#import "UIViewDraw.h"


#define REQUEST_NAME			0
#define REQUEST_ALBUM			1
#define REQUEST_ALBUM_ADD		2
#define REQUEST_UPLOAD			3
#define ACCESS_TOKEN_KEY @"fb_access_token"
#define EXPIRATION_DATE_KEY @"fb_expiration_date"

NSString *kFetchRequestTokenStep = @"kFetchRequestTokenStep";
NSString *kGetUserInfoStep = @"kGetUserInfoStep";
NSString *kSetImagePropertiesStep = @"kSetImagePropertiesStep";
NSString *kUploadImageStep = @"kUploadImageStep";


NSString*		m_strTwitterUser;
NSString*		m_strTwitterPassword;


@interface MagicCameraViewController()
-(void)initializeVolumeButtonStealer;
-(void)volumeDown;
-(void)volumeUp;
-(void)applicationCameBack;
-(void)applicationWentAway;
@end


@implementation MagicCameraViewController

@synthesize captureSession = _captureSession;
@synthesize customLayer = _customLayer;
@synthesize livePreviewLayer = _livePreviewLayer;
@synthesize adBannerView;

@synthesize launchVolume;




@synthesize m_viewMainMenu;
@synthesize m_btnTakePhoto;
@synthesize m_btnViewFavourite;


enum {
    kAlertViewNone = 0,
    kAlertViewLogin2Flickr,
    kAlertViewLogin2Twitter,
    kAlertViewLightTrail,
    kAlertViewShutterSpeedB,
    kAlertViewNagPaid,
    kAlertViewGotoPaid,
};


void volumeListenerCallback (
                             void                      *inClientData,
                             AudioSessionPropertyID    inID,
                             UInt32                    inDataSize,
                             const void                *inData
                             );
void volumeListenerCallback (
                             void                      *inClientData,
                             AudioSessionPropertyID    inID,
                             UInt32                    inDataSize,
                             const void                *inData
                             ){
    
    const float *volumePointer = inData;
    float volume = *volumePointer;
    
    
    if( volume > [(MagicCameraViewController*)inClientData launchVolume] )
    {
        [(MagicCameraViewController*)inClientData volumeUp];
    }
    else if( volume < [(MagicCameraViewController*)inClientData launchVolume] )
    {
        [(MagicCameraViewController*)inClientData volumeDown];
    }
}


- (void)dealloc {
    
    [self releaseCaptureSession];
    
    [self delTakingPictureTextures];
    [self delEditingPictureTextures];
    [self unloadShaderProgram:&drawTextureProgram];
    
    [exposure_button removeFromSuperview];
    [shutter_button removeFromSuperview];    
    [settings_button removeFromSuperview];
    [cancel_button removeFromSuperview];
//    [edit_button removeFromSuperview];                    
    [save_button removeFromSuperview];
    [main_toolbar removeFromSuperview];
    
    [exposureSettingView removeFromSuperview];
    [editSettingView removeFromSuperview];                
    [aleartWaiteView removeFromSuperview];
    
    [ m_btnBack     removeFromSuperview ];               
    [viewSlider removeFromSuperview];
    
    [livePreview_button removeFromSuperview];
    [torch_button removeFromSuperview];    
    [cameraPosition_button removeFromSuperview];        
    
    [photoPaperView removeFromSuperview];
    [livePreview removeFromSuperview];
    
    [m_imgCameraFocus release];

    
    [g_AppUtils writeAppSettings];
    [g_AppUtils release];
    
    [m_tapGestureRecognizer release];
    
    [super dealloc];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


- (void)setMainToolbarState:(BOOL)bMainMenu{

    if( bMainMenu ){
        
//        main_toolbar.frame = CGRectMake(0, 
//                                        SCREEN_HEIGHT - 53 - main_toolbar.frame.size.height,
//                                        main_toolbar.frame.size.width,
//                                        main_toolbar.frame.size.height );
//        shutter_button.hidden   =   YES;
        
    }else{
        
//        main_toolbar.frame = CGRectMake(0, 
//                                        SCREEN_HEIGHT - 53 - main_toolbar.frame.size.height,
//                                        main_toolbar.frame.size.width,
//                                        main_toolbar.frame.size.height );
//        shutter_button.hidden   =   NO;
        
    }
    
    if( bMainMenu )
        [self.view bringSubviewToFront:main_toolbar];

    main_toolbar.hidden         =   !bMainMenu;
    exposureSettingView.hidden  =   !bMainMenu;
    editSettingView.hidden      =   !bMainMenu;
   
}

- (void)hideBanner:(BOOL)bHideBanner{
    
    m_bannerView.hidden =   bHideBanner;
    if( !bHideBanner )
        [ self.view bringSubviewToFront:m_bannerView ];
    
}



- (void)viewDidLoad
{
    
    m_bShowBrightness   =   false;              
    
    [super viewDidLoad];
    
    //Insert User Interface
    CGFloat width = 48;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        width = 82;
    m_bShowingCameraFocus = NO;
    m_imgCameraFocus = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, width, width)];
    [m_imgCameraFocus setImage:[UIImage imageNamed:@"hint.png"]];
    //[self.view addSubview:m_imgCameraFocus];
    m_imgCameraFocus.hidden = YES;
    

    [ self initMainToolbar ];
    [ self initControlItemViews ];
    [ self initPhotoPaperView ];
    
    [ self initExposureSettingView ];
    [ self initEditSettingView ];                                  
    [ self initAleartWaitView ];

    
    [ self setMainToolbarState:NO ];                            
    
    [exposureSettingView updateViewFromAppSettings];
    [editSettingView updateViewFromAppSettings];                
    
    //Init OpenGL ES
    [self loadVertexShader:@"DrawTextureShader" fragmentShader:@"DrawTextureShader" forProgram:&drawTextureProgram];
    [self initGL];
    
    //Init State Flags
    bShowingExposureView = NO;
    bTakingPictures = NO;
    bShowingEditView = NO;

    bShowingLivePreview = NO; 
    bUsingLED = NO; 
    bUsingFrontCamera = NO;

    //Init Capture Session
//    [ self releaseCaptureSession ];
//    [ self setupCaptureSession ];
    
    
    [ self initMainMenu:YES ];
    

    
    [ self hideBanner:NO ];                      

    [self setVolumeButton];

    
#ifdef FREE_VERSION
    [m_btnInfo setHidden:NO];
#else
    [m_btnInfo setHidden:YES];
#endif
    
}

#pragma  mark  -------  Volumn Button
-(void) setVolumeButton
{
    AudioSessionInitialize(NULL, NULL, NULL, NULL);
    AudioSessionSetActive(YES);
    
    launchVolume = [[MPMusicPlayerController applicationMusicPlayer] volume];
    hadToLowerVolume = launchVolume == 1.0;
    hadToRaiseVolume = launchVolume == 0.0;
    justEnteredForeground = NO;
    if( hadToLowerVolume )
    {
        [[MPMusicPlayerController applicationMusicPlayer] setVolume:0.95];
        launchVolume = 0.95;
        
    }
    
    if( hadToRaiseVolume )
    {
        [[MPMusicPlayerController applicationMusicPlayer] setVolume:0.05];
        launchVolume = 0.05;
    }
    
    if( [g_AppUtils useVolumeEffect ] )
    {
        [[MagicCameraAppDelegate sharedDelegate] removeVolumnView];
        [[MagicCameraAppDelegate sharedDelegate] insertVolumnView]; 
    }
    
    
    [self initializeVolumeButtonStealer];
    
    [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationWillResignActiveNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification* notification){
        [self applicationWentAway];
    }];
    
    
    [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *notification){
        if( ! justEnteredForeground )
        {
            [self applicationCameBack];
        }
        justEnteredForeground = NO;
    }];
    
    
    [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationWillEnterForegroundNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *notification){
        AudioSessionInitialize(NULL, NULL, NULL, NULL);
        AudioSessionSetActive(YES);
        justEnteredForeground = YES;
        [self applicationCameBack];
        
        
    }];

}

-(void)applicationCameBack
{
    [self initializeVolumeButtonStealer];
    launchVolume = [[MPMusicPlayerController applicationMusicPlayer] volume];
    hadToLowerVolume = launchVolume == 1.0;
    hadToRaiseVolume = launchVolume == 0.0;
    if( hadToLowerVolume )
    {
        [[MPMusicPlayerController applicationMusicPlayer] setVolume:0.95];
        launchVolume = 0.95;
    }
    
    if( hadToRaiseVolume )
    {
        [[MPMusicPlayerController applicationMusicPlayer] setVolume:0.1];
        launchVolume = 0.1;
    }
}

-(void)applicationWentAway
{
    AudioSessionRemovePropertyListenerWithUserData(kAudioSessionProperty_CurrentHardwareOutputVolume, volumeListenerCallback, self);
    
    if( hadToLowerVolume )
    {
        [[MPMusicPlayerController applicationMusicPlayer] setVolume:1.0];
    }
    
    if( hadToRaiseVolume )
    {
        [[MPMusicPlayerController applicationMusicPlayer] setVolume:0.0];
    }
}

-(void) volumeChanged:(NSNotification*) notification{
/*    if (volumeView != nil) {
        [volumeView removeFromSuperview];
        [volumeView release];
        volumeView = nil;
    }
    
    if( ![g_AppUtils useVolumeEffect ] )
    {
        return;
    }

    CGRect frame = CGRectMake(0, -200, 10, 0);
    volumeView = [[MPVolumeView alloc] initWithFrame:frame];
    [volumeView sizeToFit];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0] addSubview:volumeView];

    [[MPMusicPlayerController applicationMusicPlayer] setVolume:0.5];
    
    if (m_nRecordStatus == RECORD_STOP) {
        if (![shutter_button isHidden]) {
            [self onShutter:nil];
        }
    }
 */
}

-(void)initializeVolumeButtonStealer
{
    AudioSessionAddPropertyListener(kAudioSessionProperty_CurrentHardwareOutputVolume, volumeListenerCallback, self);
}

-(void)volumeUp
{
    if( ![g_AppUtils useVolumeEffect ] )
    {
        return;
    }
    
    AudioSessionRemovePropertyListenerWithUserData(kAudioSessionProperty_CurrentHardwareOutputVolume, volumeListenerCallback, self);
    
    [[MPMusicPlayerController applicationMusicPlayer] setVolume:launchVolume];
    
    [self performSelector:@selector(initializeVolumeButtonStealer) withObject:self afterDelay:0.1];
    

//    if ((bTakingPictures == NO && m_nRecordStatus == RECORD_STOP) || m_nRecordStatus == RECORD_DOING) {
    if (![livePreview isHidden]){
        [self onShutter:nil];
    }
}
-(void)volumeDown
{
    if( ![g_AppUtils useVolumeEffect ] )
    {
        return;
    }
    
    AudioSessionRemovePropertyListenerWithUserData(kAudioSessionProperty_CurrentHardwareOutputVolume, volumeListenerCallback, self);
    
    [[MPMusicPlayerController applicationMusicPlayer] setVolume:launchVolume];
    
    [self performSelector:@selector(initializeVolumeButtonStealer) withObject:self afterDelay:0.1];
    
    
//    if( self.downBlock )
//    {
//        self.downBlock();
//    }
}




- (void)initMainMenu:(BOOL)bMainMenu{
    
    if( bMainMenu ){
        [ self.view addSubview:m_viewMainMenu ];        
    }else{
        [ m_viewMainMenu    retain ];
        [ m_viewMainMenu    removeFromSuperview ];
    }
    
}

- (IBAction)onInfo:(id)sender{
    [[MagicCameraAppDelegate sharedDelegate] playSE:SE_EFFECT];             
    
    InfoViewController  *viewController;
    if( SCALE_SCREEN_WIDTH != 1 )
        viewController= [ [ InfoViewController alloc ] initWithNibName:@"InfoViewController" bundle:[ NSBundle mainBundle ] ];
    else {
        viewController= [ [ InfoViewController alloc ] initWithNibName:@"InfoViewController-iPad" bundle:[ NSBundle mainBundle ] ];
        
    }

    [ self presentModalViewController:viewController animated:YES];
    
    [ viewController    release ];

}

- (IBAction)onFavourite:(id)sender{
    
    [[MagicCameraAppDelegate sharedDelegate] playSE:SE_EFFECT];             

    BackgroundViewController  *viewController;
    if( SCALE_SCREEN_WIDTH != 1 )
        viewController= [ [ BackgroundViewController alloc ] initWithNibName:@"BackgroundViewController" bundle:[ NSBundle mainBundle ] ];
    else {
        viewController= [ [ BackgroundViewController alloc ] initWithNibName:@"BackgroundViewController-iPad" bundle:[ NSBundle mainBundle ] ];
        
    }
    //                    KidSongAppDelegate  *app = ( KidSongAppDelegate *)[ [ UIApplication sharedApplication ] delegate ];
    [ self presentModalViewController:viewController animated:YES];
    
    [ viewController    release ];

//    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
//    imagePicker.delegate = self;
//    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
//    
//    if (SCALE_SCREEN_WIDTH == 1.f ) {
//        UIPopoverController* popover = [[UIPopoverController alloc] initWithContentViewController:imagePicker];
//        popover.delegate = self;
//        [popover presentPopoverFromRect:m_btnViewFavourite.frame 
//                                 inView:self.view
//               permittedArrowDirections:UIPopoverArrowDirectionDown | UIPopoverArrowDirectionRight 
//                               animated:YES];
//        m_popoverController = popover;
//        
//    }else {
//        [self presentModalViewController:imagePicker animated:YES];
//    } 
//    
//    
//    [imagePicker release];	

    
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)selectedImage editingInfo:(NSDictionary *)editingInfo {
	if ( m_popoverController) {
		[ m_popoverController dismissPopoverAnimated:YES];
		m_popoverController = nil;
	}
	else {
		[self dismissModalViewControllerAnimated:YES];
	}
}

- (IBAction)onTakePhoto:(id)sender{
    
    [[MagicCameraAppDelegate sharedDelegate] playSE:SE_EFFECT];             
    [ self initMainMenu:NO ];
    [ self setMainToolbarState:YES ];
//    [ self hideBanner:YES ];
    [self startCapturingFromCamera];

}


-(IBAction)settings:(id)sender
{
//    viewSettings.frame = CGRectMake(0, 0, 320, 480);
//    [UIView beginAnimations:@"flipping view" context:nil];
//    [UIView setAnimationDuration:1];
//    [UIView setAnimationCurve:UIViewAnimationTransitionNone];
//    [UIView setAnimationTransition: UIViewAnimationTransitionCurlDown forView:self.view cache:YES];
//    [self.view addSubview:viewSettings];
//    [UIView commitAnimations];	

}
-(IBAction)backSeetings:(id)sender
{
    [UIView beginAnimations:@"flipping view" context:nil];
    [UIView setAnimationDuration:1];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
    [UIView setAnimationTransition: UIViewAnimationTransitionCurlUp forView:self.view.superview cache:YES];
    [viewSettings removeFromSuperview];
    [UIView commitAnimations];
}

-(IBAction)leftSeting:(id)sender
{
    
    [ self onExposure: sender ];
}

- (IBAction)onShutterSegment:(id)sender{

    [g_AppUtils setShutterSpeedType:(enum ShutterSpeed_Type)m_segShutterSpeed.selectedSegmentIndex];
    
}



- (void)viewDidUnload
{  
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    [g_AppUtils writeAppSettings];
}

- (void)viewWillAppear:(BOOL)animated
{  
    [super viewWillAppear:animated];
    
    //Init Capture Session
    [ self releaseCaptureSession ];
    [ self setupCaptureSession ];

    
    m_fScale = 1.0f;
    
    
    if ([g_AppUtils selfTimerDelay] > 0) {
        [g_AppUtils loadSkin:shutter_button skinName:@"SelfTimer"];
    } else {
        [g_AppUtils loadSkin:shutter_button skinName:@"Shutter"];
    }
    
#ifndef FREE_VERSION
    [m_bannerView setHidden:YES];
#endif
}

- (void)viewDidAppear:(BOOL)animated
{        
    
    [super viewDidAppear:animated];

//      Yuan start
//    //Start Capturing
    
    MagicCameraAppDelegate *delegate = ( MagicCameraAppDelegate *)[ [ UIApplication sharedApplication ] delegate ];
    
    if( delegate.m_bFavrouiteOK ){
        
        delegate.m_bFavrouiteOK =   false;
        
        [self enableBottomBtns:YES];
        m_nRecordStatus = RECORD_STOP;
        if (stopSelfDelayTimer) {
            [stopSelfDelayTimer invalidate];
            [stopSelfDelayTimer release];
            stopSelfDelayTimer = nil;
        }
        
        if (startSelfDelayTimer) {
            [startSelfDelayTimer invalidate];
            [startSelfDelayTimer release];
            startSelfDelayTimer = nil;
        }
        
        bTakingPictures = NO;
        
        //Unuse LED
        [self unUseLED];
        
        //Hidden Control ItemViews And Translate Main Toolbar Toward Left
        if ([g_AppUtils selfTimerDelay] > 0) {
            [g_AppUtils loadSkin:shutter_button skinName:@"SelfTimer"];
        } else {
            [g_AppUtils loadSkin:shutter_button skinName:@"Shutter"];
        }
       
        if ([g_AppUtils useAutoSave] == NO) {
            [editSettingView updateViewFromAppSettings];          
            [self showControlItemViews:NO];
            [self changeEditSettings];
            [self animateMainToolbar:YES];
            if (bShowingEditView) {
                [self setEditSettingViewHidden:NO withAnimation:YES];
            } 
        }
    
        CVImageBufferRef    pixelBuffer;
        CGImageRef  imageRef = [ delegate.m_imgFavourite    CGImage ];
        [ self initMainMenu:NO ];
        [ self setMainToolbarState:YES ];
        [ self processNewCameraFrame:[ self pixelBufferFromCGImage:imageRef ] ];
        [ self  stopCapturingFromCamera ];
        
    }else
        [self startCapturingFromCamera];
    
//      Yuan end
    
}

- (CVPixelBufferRef) pixelBufferFromCGImage: (CGImageRef) image
{
    
    CGSize frameSize = CGSizeMake(CGImageGetWidth(image), CGImageGetHeight(image));
    NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSNumber numberWithBool:NO], kCVPixelBufferCGImageCompatibilityKey,
                             [NSNumber numberWithBool:NO], kCVPixelBufferCGBitmapContextCompatibilityKey,
                             nil];
    CVPixelBufferRef pxbuffer = NULL;
    CVReturn status = CVPixelBufferCreate(kCFAllocatorDefault, frameSize.width,
                                          frameSize.height,  kCVPixelFormatType_32ARGB, (CFDictionaryRef) options, 
                                          &pxbuffer);
    NSParameterAssert(status == kCVReturnSuccess && pxbuffer != NULL);
    
    CVPixelBufferLockBaseAddress(pxbuffer, 0);
    void *pxdata = CVPixelBufferGetBaseAddress(pxbuffer);
    
    
    CGColorSpaceRef rgbColorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(pxdata, frameSize.width,
                                                 frameSize.height, 8, 4*frameSize.width, rgbColorSpace, 
                                                 kCGImageAlphaNoneSkipLast);
    
    CGContextDrawImage(context, CGRectMake(0, 0, CGImageGetWidth(image), 
                                           CGImageGetHeight(image)), image);
    CGColorSpaceRelease(rgbColorSpace);
    CGContextRelease(context);
    
    CVPixelBufferUnlockBaseAddress(pxbuffer, 0);
    
    return pxbuffer;
}

- (void)viewWillDisappear:(BOOL)animated
{  
	[super viewWillDisappear:animated];
    
    //Stop Caturing
    [self stopCapturingFromCamera];
}

- (void)viewDidDisappear:(BOOL)animated
{  
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    
    if (![livePreview isHidden]){
        m_orientation = interfaceOrientation;
    }

    return (interfaceOrientation == UIDeviceOrientationPortrait);
}

#pragma mark - App ResignActive/BecomeActive
- (void)appWillResignActive {
    [self stopTakingPictures:nil];
}

- (void)appDidBecomeActive {
    
}

#pragma mark - Init User Interface
- (void)initMainToolbar {
    CGRect frameRect;
    float offsetY;
    
    //Insert Main Toolbar On Main View
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
#ifdef FREE_VERSION
        frameRect = CGRectMake(0, 480 - 53 - 48, 320 * 2, 53);
#else
        frameRect = CGRectMake(0, 480 - 53, 320 * 2, 53);
#endif
    } else {
#ifdef FREE_VERSION
        frameRect = CGRectMake(0, 1024 - 53 * 2 - 66, 768 * 2, 53 * 2);
#else
        frameRect = CGRectMake(0, 1024 - 53 * 2, 768 * 2, 53 * 2);
#endif
    }
    main_toolbar = [[UIImageView alloc] initWithFrame:frameRect];
    [main_toolbar setImage:[UIImage imageNamed:[g_AppUtils resourceNameForDevice:@"ToolbarBackground" ofType:@"png"]]];
    main_toolbar.userInteractionEnabled = YES;
    [self.view addSubview:main_toolbar];
    [main_toolbar release];
    
    offsetY = (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) ? 6 : 6 * 2;
    //Insert ExposureInactive Button On Main Toolbar
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        frameRect = CGRectMake(5, offsetY, 46, 42);
    } else {
        frameRect = CGRectMake(5 * SCALE_X, offsetY, 92, 84);
    }    
    exposure_button = [[UIButton alloc] initWithFrame:frameRect];
    [g_AppUtils loadSkin:exposure_button skinName:@"Exposure"];    
    [exposure_button addTarget:self action:@selector(onExposure:) forControlEvents:UIControlEventTouchUpInside];    
    [main_toolbar addSubview:exposure_button];
    [exposure_button release];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        frameRect = CGRectMake((320 - 94) / 2, offsetY, 94, 42);
    } else {
        frameRect = CGRectMake((768 - 188) / 2, offsetY, 188, 84);
    }    
    shutter_button = [[UIButton alloc] initWithFrame:frameRect];
    [g_AppUtils loadSkin:shutter_button skinName:@"Shutter"];    
    [shutter_button addTarget:self action:@selector(onShutter:) forControlEvents:UIControlEventTouchUpInside];    
    [main_toolbar addSubview:shutter_button];
    [shutter_button release];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        frameRect = CGRectMake(320 - (46 + 5), offsetY, 46, 42);
    } else {
        frameRect = CGRectMake(768 - (92 + 5 * SCALE_X), offsetY, 92, 84);
    }    
    settings_button = [[UIButton alloc] initWithFrame:frameRect];
    [g_AppUtils loadSkin:settings_button skinName:@"Settings"];    
    [settings_button addTarget:self action:@selector(onSettings:) forControlEvents:UIControlEventTouchUpInside];    
    [main_toolbar addSubview:settings_button];
    [settings_button release];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        frameRect = CGRectMake(5 + 320, offsetY, 46, 42);
    } else {
        frameRect = CGRectMake(5 * SCALE_X + 768, offsetY, 92, 84);
    }    
    cancel_button = [[UIButton alloc] initWithFrame:frameRect];
    [g_AppUtils loadSkin:cancel_button skinName:@"Cancel"];
    [cancel_button addTarget:self action:@selector(onCancel:) forControlEvents:UIControlEventTouchUpInside];    
    [main_toolbar addSubview:cancel_button];
    [cancel_button release];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        frameRect = CGRectMake((320 - 46) / 2 + 320, offsetY, 46, 42);
    } else {
        frameRect = CGRectMake((768 - 92) / 2 + 768, offsetY, 92, 84);
    }    
    
    
//    edit_button = [[UIButton alloc] initWithFrame:frameRect];
//    [g_AppUtils loadSkin:edit_button skinName:@"Edit"];       
//    [edit_button addTarget:self action:@selector(onEdit:) forControlEvents:UIControlEventTouchUpInside];    
//    [main_toolbar addSubview:edit_button];
//    [edit_button release];

    
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        frameRect = CGRectMake(320 - (46 + 5) + 320, offsetY, 46, 42);
    } else {
        frameRect = CGRectMake(768 - (92 + 5 * SCALE_X) + 768, offsetY, 92, 84);
    }    
    save_button = [[UIButton alloc] initWithFrame:frameRect];
    [g_AppUtils loadSkin:save_button skinName:@"Save"];    
    [save_button addTarget:self action:@selector(onSave:) forControlEvents:UIControlEventTouchUpInside];    
    [main_toolbar addSubview:save_button];
    [save_button release];
}

- (void)initControlItemViews {
    CGRect frameRect;
    
    CGFloat offsetY = 0;
    
    //Insert LivePreiView Button
    
//  Yuan start
//    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
//        frameRect = CGRectMake(15, 10+offsetY, 60, 30);
//    } else {
//        frameRect = CGRectMake(15 * SCALE_X, 10 * SCALE_Y+offsetY, 120, 60);
//    }    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        frameRect = CGRectMake(15 + 50, 10+offsetY, 60, 30);
    } else {
        frameRect = CGRectMake(15 + 120 * SCALE_X, 10 * SCALE_Y+offsetY, 120, 60);
    }    
//  Yuan end
    
    livePreview_button = [[UIButton alloc] initWithFrame:frameRect];
    [g_AppUtils loadSkinForOnlyNormalState:livePreview_button skinName:@"LivePreview"];    
    [livePreview_button addTarget:self action:@selector(onLivePreview:) forControlEvents:UIControlEventTouchUpInside];    
    [self.view addSubview:livePreview_button];
    [livePreview_button release];
    
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        frameRect = CGRectMake(5, 10+offsetY, 40, 30);
    } else {
        frameRect = CGRectMake(5, 10 * SCALE_Y+offsetY, 80, 60);
    }    
    //  Yuan end
    
    m_btnBack = [[UIButton alloc] initWithFrame:frameRect];
    [g_AppUtils loadSkinForOnlyNormalState:m_btnBack skinName:@"btn_back"];    
    [m_btnBack addTarget:self action:@selector(onBack:) forControlEvents:UIControlEventTouchUpInside];    
    [self.view addSubview:m_btnBack];
    [m_btnBack release];

    
    
    //Insert Torch Button
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        frameRect = CGRectMake( 145, 10+offsetY, 60, 30);
    } else {
        frameRect = CGRectMake( ( 768 - 120) / 2, 10 * SCALE_Y+offsetY, 120, 60);
    }    
    torch_button = [[UIButton alloc] initWithFrame:frameRect];
    [g_AppUtils loadSkinForOnlyNormalState:torch_button skinName:@"TorchOff"];    
    [torch_button addTarget:self action:@selector(onTorch:) forControlEvents:UIControlEventTouchUpInside];    
    [self.view addSubview:torch_button];
    [torch_button release];

    //Insert CameraPosition Button
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        frameRect = CGRectMake(320 - (60 + 15), 10+offsetY, 60, 30);
    } else {
        frameRect = CGRectMake(768 - (120 + 15 * SCALE_X), 10 * SCALE_Y+offsetY, 120, 60);
    }    
    cameraPosition_button = [[UIButton alloc] initWithFrame:frameRect];
    [g_AppUtils loadSkinForOnlyNormalState:cameraPosition_button skinName:@"CameraPosition"];    
    [cameraPosition_button addTarget:self action:@selector(onCameraPosition:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:cameraPosition_button];
    [cameraPosition_button release];  
    
#ifndef FREE_VERSION 
    CGRect rtSlider;
    //Insert zooming slider
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        frameRect = CGRectMake((320 - 294)/2, 380, 294, 30);
        rtSlider = CGRectMake((320-230)/2, 380, 230, 30);
    } else {
        frameRect = CGRectMake((768-600)/2, 840, 588, 60);
        rtSlider = CGRectMake(150-2, 840-1, 460, 60);
    }   
    
    viewSlider = [[UIImageView alloc] initWithFrame:frameRect];
    [viewSlider setImage:[UIImage imageNamed:[g_AppUtils resourceNameForDevice:@"zoombar" ofType:@"png"]]];
    [self.view addSubview:viewSlider];
    [viewSlider release];
    
    sliderZooming = [[UISlider alloc] initWithFrame:rtSlider];
    [sliderZooming setMaximumTrackImage:[UIImage imageNamed:@"slider_back.png"] forState:UIControlStateNormal];
    [sliderZooming setMinimumTrackImage:[UIImage imageNamed:@"slider_back.png"] forState:UIControlStateNormal];
    [sliderZooming setThumbImage:[UIImage imageNamed:[g_AppUtils resourceNameForDevice:@"zoom_handle" ofType:@"png"]] forState:UIControlStateNormal];
    
    [sliderZooming addTarget:self action:@selector(sliderMove:) forControlEvents:UIControlEventValueChanged];
    sliderZooming.minimumValue = 1.0;
    sliderZooming.maximumValue = 10.0;
    sliderZooming.value = m_fScale;
    sliderZooming.backgroundColor = [UIColor clearColor];
    [self.view addSubview:sliderZooming];
    [sliderZooming release];  
    
#endif
    
}

- (void)initPhotoPaperView {    
    CGRect frameRect;
    CGFloat border;
    
    //Insert LivePreview
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        border = 3;
        frameRect = CGRectMake(0 - border, 0 - border, PHOTO_WIDTH + border * 2, PHOTO_HEIGHT + border * 2);
    } else {
        frameRect = CGRectMake(0 - border, 0 - border, 768 + border * 2, 1024 + border * 2);
    }
    livePreview = [[LivePreview alloc] initWithFrame:frameRect];
    [self.view addSubview:livePreview];
    [livePreview release];
    [self.view sendSubviewToBack:livePreview];
    
    m_tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTapScreen:)];
    [livePreview addGestureRecognizer:m_tapGestureRecognizer];
    
    //Insert PhotoPaperView
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {    
//        frameRect = CGRectMake(0, 0, 320, 480);
        frameRect = CGRectMake(0, 0, PHOTO_WIDTH, PHOTO_HEIGHT);
    } else {
        frameRect = CGRectMake(0, 0, 768, 1024);
    }
    photoPaperView = [[GLES2View alloc] initWithFrame:frameRect];
    [self.view addSubview:photoPaperView];
    [photoPaperView release];
    [self.view sendSubviewToBack:photoPaperView];    
    [photoPaperView clearView];
}

- (void)initExposureSettingView {    
    CGRect frameRect;
    
    //Insert ExposureSettingView
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {    
        frameRect = CGRectMake(0, main_toolbar.frame.origin.y, 320, 185);
    } else {
        frameRect = CGRectMake(0, main_toolbar.frame.origin.y, 768, 185 * 2);
    }
    exposureSettingView = [[ExposureSettingView alloc] initWithFrame:frameRect];
    [self.view addSubview:exposureSettingView];
    [exposureSettingView release];
    
    [exposureSettingView setDelegateController:self];    
}

- (void)initEditSettingView {    
    CGRect frameRect;
    
    //Insert ExposureSettingView
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) { 
        
//        frameRect = CGRectMake(0, 480 - main_toolbar.frame.size.height, 320, 76);
        frameRect = CGRectMake(0, 480, 320, 76);
        

    } else {
        frameRect = CGRectMake(0, 1024 - main_toolbar.frame.size.height, 768, 76 * 2);
    }
    
    editSettingView = [[EditSettingView alloc] initWithFrame:frameRect];
    [self.view addSubview:editSettingView];
    [editSettingView release];
    
    [editSettingView setDelegateController:self];
}

- (void)initAleartWaitView {    
    CGRect frameRect;
    
    //Insert ExposureSettingView
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {    
        frameRect = CGRectMake(0, 480 - main_toolbar.frame.size.height, 320, 480);
    } else {
        frameRect = CGRectMake(0, 1024 - main_toolbar.frame.size.height, 768, 1024);
    }
    aleartWaiteView = [[AleartWaitView alloc] initWithFrame:frameRect];
    [aleartWaiteView setMessage:@"Saving image..."];
    [self.view addSubview:aleartWaiteView];
    [aleartWaiteView release];
}

#pragma mark - User Interface Action
- (void)onExposure:(id)sender {  
    
    [[MagicCameraAppDelegate sharedDelegate] playSE:SE_EFFECT];             
    bShowingExposureView = !bShowingExposureView;
    
    if (bShowingExposureView) {
        [self setExposureSettingViewHidden:NO withAnimation:YES];
    } else {
        [self setExposureSettingViewHidden:YES withAnimation:NO];
    }
}

- (void)onShutter:(id)sender {
    
//    [[MagicCameraAppDelegate sharedDelegate] playSE:SE_SHUTTEREND];
    
    [self procShutter];
//    if (bTakingPictures) {  //Stop Taking Picture Now
//        [self stopTakingPictures:nil];
//    } else {                //Make Taking Pictures  From Camera Now
//        //Hidden Control ItemViews And Translate Main Toolbar Toward Left
//        [g_AppUtils loadSkin:shutter_button skinName:@"Stop"];
//        [cameraPosition_button setHidden:YES];   
//        
//        //Start Taking Picture With SelfTimer Delay
//        int selfTimerDelay = [g_AppUtils selfTimerDelay];
//        if (selfTimerDelay > 0) {
//            startSelfDelayTimer = [[NSTimer scheduledTimerWithTimeInterval:selfTimerDelay  target:self selector:@selector(startTakingPictures:) userInfo:nil repeats:NO] retain];
//        } else {
//            [self startTakingPictures:nil];
//        }
//    }
}

- (void)onSettings:(id)sender {
    
    [[MagicCameraAppDelegate sharedDelegate] playSE:SE_EFFECT];             

	SetViewController* controller;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
        controller = [[SetViewController alloc] initWithNibName:@"SetViewController_iPhone" bundle:[NSBundle mainBundle]];
    else
        controller = [[SetViewController alloc] initWithNibName:@"SetViewController_iPad" bundle:[NSBundle mainBundle]];

//    [controller setDelegate:self];
    UINavigationController  *nav = [[[UINavigationController alloc] initWithRootViewController:controller] autorelease];
    
	[self presentModalViewController:nav animated:YES];
	[controller release];
 
}

- (void)onCancel:(id)sender {
    
    [[MagicCameraAppDelegate sharedDelegate] playSE:SE_EFFECT];             
    [self startCapturingFromCamera];                                         

    //Show Control ItemViews And Translate Main Toolbar Toward Right
    [self showControlItemViews:YES];
    [photoPaperView clearView];
    [self animateMainToolbar:NO];
    if (bShowingEditView) {
        [self setEditSettingViewHidden:YES withAnimation:NO];        
    }
    
}

- (void)onEdit:(id)sender {
    bShowingEditView = !bShowingEditView; 
    
    if (bShowingEditView) {
        [self setEditSettingViewHidden:NO withAnimation:YES];
    } else {
        [self setEditSettingViewHidden:YES withAnimation:NO];
    }
}

- (void)onSave:(id)sender {

    [[MagicCameraAppDelegate sharedDelegate] playSE:SE_EFFECT];             

//    if (bShowingEditView) {
//        [self onEdit:nil];
//    }
//    
//    [self setEditSettingViewHidden:YES withAnimation:NO];  //gold

//    Yuan end
//    Yuan start
//    UIActionSheet* action = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera Roll", @"Email", @"Facebook", @"Flickr", @"Twitter", @"More Apps!", nil];
#ifdef FREE_VERSION    
    UIActionSheet* action = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Save to Favourites", @"Photo Library", nil];
#else
    UIActionSheet* action = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Save to Favourites", @"Photo Library", @"Facebook", @"Twitter", @"Email", nil];
#endif
    

    [action showInView:self.view];
    
}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    
    MagicCameraAppDelegate *_delegate = (MagicCameraAppDelegate*)[[UIApplication sharedApplication] delegate];
#ifdef FREE_VERSION
    if (buttonIndex >= 2) {
        [actionSheet release];
        return;
    }
#endif
    
    if (buttonIndex == 0) { //Favourite
        [cancel_button setEnabled:NO];
        //        [edit_button setEnabled:NO];              
        [save_button setEnabled:NO]; 
        
        if([g_AppUtils useAutoSave])
        {
            UIAlertView *alt = [[UIAlertView alloc] initWithTitle:@"" message:@"This image already is saved to favourites" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            alt.tag = -1;
            [alt show];
            [alt release];
            
            [cancel_button setEnabled:YES];
            [save_button setEnabled:YES]; 

        }
        else
            [self savePhotoToFavourite];
        
    }
    else if (buttonIndex == 1) {                //photo libaray
        [cancel_button setEnabled:NO];
        //        [edit_button setEnabled:NO];              
        [save_button setEnabled:NO]; 
        
        if([g_AppUtils useAutoSaveToPhotoLibrary])
        {
            UIAlertView *alt = [[UIAlertView alloc]initWithTitle:@"" message:@"This image already is saved to photo library" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            alt.tag = -1;
            [alt show];
            [alt release];
            
            [cancel_button setEnabled:YES];
            [save_button setEnabled:YES]; 

        }
        else
            [self savePhotoPaperImageToPhotoAlbum];
    } 
    else if (buttonIndex == 2) {//facebook
        UIImage *snapshotImage = [self changeImage:[photoPaperView snapshot]];
        
        [_delegate sendToFacebook:snapshotImage];
    } 
    else if (buttonIndex == 3) {//twitter
        UIImage *snapshotImage = [self changeImage:[photoPaperView snapshot]];
        
        [_delegate sendToTwitter:snapshotImage];
    } 
    else if (buttonIndex == 4) {//Email
        [self onEmail];
    } 

    [actionSheet release];
}


- (void)onBack:(id)sender{
    
    [ self setMainToolbarState:NO ];
//    [ self.view     addSubview:m_viewMainMenu ];
    [ self initMainMenu:YES ];
    [ self.view bringSubviewToFront:m_bannerView ];
    [ self stopCapturingFromCamera ];

}



- (void)onLivePreview:(id)sender {
    bShowingLivePreview = !bShowingLivePreview;

    m_fScale = 1.0f;
    sliderZooming.value = m_fScale;
    livePreview.transform = CGAffineTransformMakeScale(m_fScale, m_fScale);

    
    if (bShowingLivePreview) {          //
        [livePreview_button setHidden:YES];
        
        [sliderZooming setHidden:YES];
        [viewSlider setHidden:YES];

        [self animateLivePreivew:NO];
    } else {
        [livePreview_button setHidden:NO];        

        [sliderZooming setHidden:NO];
        [viewSlider setHidden:NO];

        [self animateLivePreivew:YES];        
    }
    
}

- (void)onTorch:(id)sender {
    if (!bUsingFrontCamera && [device hasTorch]) {
        bUsingLED = !bUsingLED;
        
        if (bUsingLED) {                //Make Use LED Now
            [device lockForConfiguration:nil];
            [ device setTorchMode:AVCaptureTorchModeOn];
            [device unlockForConfiguration];          
            [g_AppUtils loadSkinForOnlyNormalState:torch_button skinName:@"TorchOn"];
        } else {                       //Make Unuse LED Now
            [device lockForConfiguration:nil];
            [device setTorchMode:AVCaptureTorchModeOff];
            [device unlockForConfiguration];                    
            [g_AppUtils loadSkinForOnlyNormalState:torch_button skinName:@"TorchOff"];
        }
    }
}

- (void)onCameraPosition:(id)sender {
    
    
    bUsingFrontCamera = !bUsingFrontCamera;

    AVCaptureDevice *new_device;
    if (bUsingFrontCamera) {
        new_device = [self frontFacingCamera];
    } else {
        new_device = [self backFacingCamera];
    }
    
    if (new_device) {
        AVCaptureDeviceInput *new_captureInput = [[AVCaptureDeviceInput alloc] initWithDevice:new_device error:nil];
        if (new_captureInput) {
            [self.captureSession stopRunning];
            [self.captureSession beginConfiguration];
            
            if (captureInput) {
                [self.captureSession removeInput:captureInput];
                [captureInput release];
                captureInput = nil;
            }
            
            if ([self.captureSession canAddInput:new_captureInput]) {
                [self.captureSession addInput:new_captureInput];
            } else {
                [new_captureInput release];
            }
            
            [self.captureSession commitConfiguration];           
            [self.captureSession startRunning];
            
            captureInput = new_captureInput;
            device = new_device;
            
            [self unUseLED];
            if ([device hasTorch] == NO) {
                [torch_button setHidden:YES];
            }
            else {
                [torch_button setHidden:bUsingFrontCamera];
            }
            
            return;
        }
    }
    
    bUsingFrontCamera = !bUsingFrontCamera;
}

- (BOOL) hasFocus
{
    return  [device isFocusModeSupported:AVCaptureFocusModeLocked] ||
    [device isFocusModeSupported:AVCaptureFocusModeAutoFocus] ||
    [device isFocusModeSupported:AVCaptureFocusModeContinuousAutoFocus];
}

- (AVCaptureFocusMode) focusMode
{
    return [device focusMode];
}

- (void) setFocusMode:(AVCaptureFocusMode)focusMode
{
    if ([device isFocusModeSupported:focusMode] && [device focusMode] != focusMode) {
        NSError *error;
        if ([device lockForConfiguration:&error]) {
            [device setFocusMode:focusMode];
            [device unlockForConfiguration];
        } else {
        }    
    }
}

- (void) focusAtPoint:(CGPoint)point
{
    if ([device isFocusPointOfInterestSupported] && [device isFocusModeSupported:AVCaptureFocusModeAutoFocus]) {
        NSError *error;
        if ([device lockForConfiguration:&error]) {
            [device setFocusPointOfInterest:point];
            [device setFocusMode:AVCaptureFocusModeAutoFocus];
            [device unlockForConfiguration];
        } else {
        }        
    }
}

- (void) autoFocusAtPoint:(CGPoint)point {
    NSArray *devices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeClosedCaption];
    for (AVCaptureDevice *tempDevice in devices) {
        [tempDevice lockForConfiguration:nil];
        if ([tempDevice isFocusModeSupported:AVCaptureFocusModeAutoFocus]) {
            NSLog(@"Here");
        }
        
        if ([tempDevice isFocusModeSupported:AVCaptureFocusModeContinuousAutoFocus]) {
            NSLog(@"Here");
        }
        
        if ([tempDevice isFocusModeSupported:AVCaptureFocusModeLocked]) {
            NSLog(@"Here");
        }
        
        if ([tempDevice isFocusPointOfInterestSupported]) {
            NSLog(@"Here");
        }
        [tempDevice unlockForConfiguration];
    }
    BOOL b1 = [self hasFocus];
    BOOL b2 = [device isAdjustingFocus];
    AVCaptureFocusMode mode = [self focusMode];
    AVCaptureDevice* device1 = [captureInput device];
    BOOL bRet = [device1 isFocusPointOfInterestSupported];
    BOOL bRet1 = [device1 isFocusModeSupported:AVCaptureFocusModeAutoFocus];
    if ([device1 isFocusPointOfInterestSupported] && [device1 isFocusModeSupported:AVCaptureFocusModeAutoFocus]) {
        NSError *error;
        if ([device1 lockForConfiguration:&error]) {
            [device1 setFocusPointOfInterest:point];
            [device1 setFocusMode:AVCaptureFocusModeAutoFocus];
            [device1 unlockForConfiguration];
        } else {
        }        
    }
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    if (livePreview.hidden == YES)
        return;
    UITouch *touch = (UITouch *)[touches anyObject];
    BOOL bTakePic = NO;
    CGPoint pointInView = [touch locationInView:self.view];
    if ([touch view] == livePreview) {
        //Get Tourched Point

        //If Tourced in LivePreview Area, Treate As LP Button Click
        if (bShowingLivePreview && CGRectContainsPoint(livePreview.frame, pointInView)) {
            [self onLivePreview:nil];
        } else {   
            bTakePic = YES;
        }
    }
    else {
        bTakePic = YES;
    }
//    if (bTakePic) {
//        if (bTakingPictures == NO && [g_AppUtils useScreenShutter] == YES) {
//            [self procShutter];
//        }
//    }

    if (bTakingPictures == NO && m_nRecordStatus == RECORD_STOP && m_bShowingCameraFocus == NO) {
        
        m_imgCameraFocus.center = pointInView;
        [self showCameraFocus:YES];
    }
}

- (void) onTapScreen:(UITapGestureRecognizer*)gestureRecognizer
{
    if (bTakingPictures == NO && [g_AppUtils useScreenShutter] == YES) 
    {
        [self onShutter:nil];
    }
}

- (void) enableUserAction:(BOOL)enable {
    self.view.userInteractionEnabled = enable;
}
- (void)enableBottomBtns:(BOOL)enable {
    [exposure_button setEnabled:enable];
    [settings_button setEnabled:enable];
}
#pragma mark - Taking Picutre

- (void) procShutter {
    
    if (m_nRecordStatus == RECORD_DOING) {  //Stop Taking Picture Now
        [ self enableBottomBtns:YES ];
        [ self stopTakingPictures:nil ];
    } 
    else if (m_nRecordStatus == RECORD_STOP) {                //Make Taking Pictures  From Camera Now
        
        m_orientation = [[UIDevice currentDevice] orientation]; //self.interfaceOrientation;

        
        //Hidden Control ItemViews And Translate Main Toolbar Toward Left
        [ self enableBottomBtns:NO ];
        [ g_AppUtils loadSkin:shutter_button skinName:@"Stop" ];
        //[ cameraPosition_button setHidden:YES ];   
        
        //Start Taking Picture With SelfTimer Delay
        int selfTimerDelay = [ g_AppUtils selfTimerDelay ];
        if (selfTimerDelay > 0) {
            m_nRecordStatus = RECORD_WAITING;
            startSelfDelayTimer = [[NSTimer scheduledTimerWithTimeInterval:selfTimerDelay  target:self selector:@selector(startTakingPictures:) userInfo:nil repeats:NO] retain];
        } else {
            [self startTakingPictures:nil];
        }
    }
    else {
        [self enableBottomBtns:YES];
        [self cancelTakingPictures:nil];
    }
    
}

- (void)startTakingPictures:(id)sender {
    if (bTakingPictures)
        return;
    
    [[MagicCameraAppDelegate sharedDelegate] playSE:SE_SHUTTERSTART];
    m_nRecordStatus = RECORD_DOING;
    if ( startSelfDelayTimer ) {
        [ startSelfDelayTimer invalidate ];
        [ startSelfDelayTimer release ];
        startSelfDelayTimer = nil;
    }
    
    //Init Taking Picture
    isFirstFrame = YES;
    [ self delTakingPictureTextures ];
    
    //Start Taking Picture
    if ( bShowingExposureView )
        [self onExposure:nil];
    
    //Set Stop Timer
    float shutter_speed = [g_AppUtils shutterSpeed];
    if (shutter_speed > 0) {
        stopSelfDelayTimer = [[NSTimer scheduledTimerWithTimeInterval:shutter_speed target:self selector:@selector(stopTakingPictures:) userInfo:nil repeats:NO] retain];
    }

    
    switch ([g_AppUtils  pictureSizeType]) {
        case SMALL_SIZE:
            photoPaperView.contentScaleFactor = 0.5f;
            break;
        case MEDIUM_SIZE:
            photoPaperView.contentScaleFactor = 0.7f;
            break;
        case LARGE_SIZE:
        default:
            photoPaperView.contentScaleFactor = 1.0f;
            break;
    }

    bTakingPictures = YES; 
    
}

- (void)stopTakingPictures:(id)sender {
    
    if (!bTakingPictures) 
        return;
    
    [[MagicCameraAppDelegate sharedDelegate] playSE:SE_SHUTTEREND];
    [self enableBottomBtns:YES];
    m_nRecordStatus = RECORD_STOP;
   if (stopSelfDelayTimer) {
        [stopSelfDelayTimer invalidate];
        [stopSelfDelayTimer release];
        stopSelfDelayTimer = nil;
    }
    
    if (startSelfDelayTimer) {
        [startSelfDelayTimer invalidate];
        [startSelfDelayTimer release];
        startSelfDelayTimer = nil;
    }
    
    bTakingPictures = NO;
    
    //Unuse LED
    [self unUseLED];
    
    //Hidden Control ItemViews And Translate Main Toolbar Toward Left
    if ([g_AppUtils selfTimerDelay] > 0) {
        [g_AppUtils loadSkin:shutter_button skinName:@"SelfTimer"];
    } else {
        [g_AppUtils loadSkin:shutter_button skinName:@"Shutter"];
    }
    
    
    if ([g_AppUtils useAutoSave] == NO) {
        [editSettingView updateViewFromAppSettings];          
        [self showControlItemViews:NO];
        [self changeEditSettings];
        [self animateMainToolbar:YES];
        if (bShowingEditView) {
            [self setEditSettingViewHidden:NO withAnimation:YES];
        } 
    }
    else if([g_AppUtils useAutoSave] == YES)
    {
        [ self savePhotoToFavourite ];
    }
    
    if([g_AppUtils useAutoSaveToPhotoLibrary] == YES){
//        [self showControlItemViews:YES];
        [self savePhotoPaperImageToPhotoAlbum];
    }
    
#ifdef FREE_VERSION
    [self nagScreen];
#endif

}
- (void)cancelTakingPictures:(id)sender {
    [self enableBottomBtns:YES];
    m_nRecordStatus = RECORD_STOP;
    if (stopSelfDelayTimer) {
        [stopSelfDelayTimer invalidate];
        [stopSelfDelayTimer release];
        stopSelfDelayTimer = nil;
    }
    
    if (startSelfDelayTimer) {
        [startSelfDelayTimer invalidate];
        [startSelfDelayTimer release];
        startSelfDelayTimer = nil;
    }
    
    bTakingPictures = NO;
    
    //Unuse LED
    [self unUseLED];
    
    //Hidden Control ItemViews And Translate Main Toolbar Toward Left
    if ([g_AppUtils selfTimerDelay] > 0) {
        [g_AppUtils loadSkin:shutter_button skinName:@"SelfTimer"];
    } else {
        [g_AppUtils loadSkin:shutter_button skinName:@"Shutter"];
    }
    [self showControlItemViews:YES];
}

#pragma mark - Save Captured Image
- (void)photoPaperImage:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo { 
    [self setAleartWaitViewHidden:YES withAnimation:NO];
    
    [cancel_button setEnabled:YES];
//    [edit_button setEnabled:YES];                 
    [save_button setEnabled:YES]; 
    if ([g_AppUtils useAutoSave] == YES) {
        [photoPaperView clearView];
        [self showControlItemViews:YES];
    }
    
    if([g_AppUtils useAutoSave] != YES){
        [self alertOkAction:@"Photo has been saved to Photo Library!"];
    }
    else {
        [self alertOkAction:@"Photo has been saved to Favourite and Library!"];
    }
}



-(UIImage *) changeImage:(UIImage*) thumbImg
{
    CGFloat width = thumbImg.size.width;
    CGFloat height =thumbImg.size.height;
    printf("THUMB : width = %f, height = %f\n", width, height);
    
    UIImage* clipImg = nil;
//    clipImg = [self.view getClipImage:thumbImg :CGRectMake(0, 0, width, 480.0*(width/320.0))];
//    clipImg = [self.view getClipImage:thumbImg :CGRectMake(0, 0, 457, 685)];
    clipImg = [self.view getClipImage:thumbImg :CGRectMake(0, 0, 320, 480)];
    printf("CLIP : width = %f, height = %f\n", clipImg.size.width, clipImg.size.height);
    
    UIImage *resizeImg = nil;
    switch ([g_AppUtils  pictureSizeType]) {
        case SMALL_SIZE:
            resizeImg = [self.view resizedImage:clipImg inSize:CGSizeMake(SMALL_WIDTH, SMALL_HEIGHT)];
            break;
        case MEDIUM_SIZE:
            resizeImg = [self.view resizedImage:clipImg inSize:CGSizeMake(MIDDLE_WIDTH, MIDDLE_HEIGHT)];
            break;
        case LARGE_SIZE:
            resizeImg = [self.view resizedImage:clipImg inSize:CGSizeMake(HIGH_WIDTH, HIGH_HEIGHT)];
            break;
        default:
            resizeImg = thumbImg;
            break;
    }
    printf("RESIZE : width = %f, height = %f\n", resizeImg.size.width, resizeImg.size.height);
    
    UIImage * rotateImg = nil;
    if (m_orientation == UIInterfaceOrientationPortraitUpsideDown) {
        rotateImg = [self.view getRotateImage:resizeImg :UIImageOrientationDown];
    } else if (m_orientation == UIInterfaceOrientationLandscapeLeft) {
        rotateImg = [self.view getRotateImage:resizeImg :UIImageOrientationRight];
    } else if (m_orientation == UIInterfaceOrientationLandscapeRight) {
        rotateImg = [self.view getRotateImage:resizeImg :UIImageOrientationLeft];
    } else {
        rotateImg = resizeImg;
    }

    return rotateImg;
}
- (void)savePhotoToFavourite{
    [self setAleartWaitViewHidden:NO withAnimation:NO];

//    [self setAleartWaitViewHidden:NO withAnimation:NO];
    UIImage *snapshotImage = [self changeImage:[photoPaperView snapshot]];
    
//    int i = 0;
//	NSString *pathFace = [DOCSFOLDER stringByAppendingPathComponent:@"faceImg.png"];
    
//	while ([[NSFileManager defaultManager] fileExistsAtPath:pathFace]) {
//		pathFace = [NSString stringWithFormat:@"%@/%@-%d.%@", DOCSFOLDER, @"faceImg", i++, @"png"]; 
//    }
    NSDate * date = [NSDate date];
    NSDateFormatter * dateFormat = [[[NSDateFormatter alloc] init] autorelease];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSString * strDate = [NSString stringWithFormat:@"%@.png", [dateFormat stringFromDate:date]];
    
    NSString *pathFace = [DOCSFOLDER stringByAppendingPathComponent:strDate];
    
//    NSLog(@"save favourite path = %@", pathFace);
//	printf("Writing selected image to Documents folder\n"); 
    
	[UIImagePNGRepresentation(snapshotImage)  writeToFile: pathFace atomically:YES];

    [cancel_button setEnabled:YES ];
    //        [edit_button setEnabled:NO];              
    [save_button setEnabled:YES ];
    
    [self setAleartWaitViewHidden:YES withAnimation:NO];
    
    if([g_AppUtils useAutoSave] != YES)
        [self alertOkAction:@"Photo has been saved to Favourites!"];
}



- (void)savePhotoPaperImageToPhotoAlbum {
    [self setAleartWaitViewHidden:NO withAnimation:NO];
    
    UIImage *snapshotImage = [self changeImage:[photoPaperView snapshot]];
        
    UIImageWriteToSavedPhotosAlbum(snapshotImage, self, @selector(photoPaperImage:didFinishSavingWithError:contextInfo:), nil);
}

#pragma mark - View Move And Animations 
- (void)showControlItemViews:(BOOL)showViews {
    BOOL hiddenViews = !showViews;
    [livePreview setHidden:hiddenViews];    
    [livePreview_button setHidden:hiddenViews || bShowingLivePreview];
    [cameraPosition_button setHidden:hiddenViews];
    [ m_btnBack setHidden:hiddenViews ];                        
    
    [viewSlider setHidden:hiddenViews || bShowingLivePreview];
    [sliderZooming setHidden:hiddenViews || bShowingLivePreview];
    
    if ([device hasTorch] == NO)
        [torch_button setHidden:YES];
    else
        [torch_button setHidden:hiddenViews || bUsingFrontCamera];
    
    [exposure_button setHidden:hiddenViews];
    [settings_button setHidden:hiddenViews];
    

    [ self setEditSettingViewHidden:showViews withAnimation:YES ];      
    
}

- (void) animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context {
    if ([animationID isEqualToString:@"animateMainToolbar"]) {
//        NSLog(@"%@", @"Finish animateMainToolbar");
    } else if ([animationID isEqualToString:@"animateLivePreivew"]) {
//        NSLog(@"%@", @"Finish animateLivePreivew");
    } else if ([animationID isEqualToString:@"animateExposureSettingView"]) {
//        [exposure_button setEnabled:YES];
    }
    else if ([animationID isEqualToString:@"animateShowingCameraFocus"]) {
        [self showCameraFocus:NO];
    }
    else if ([animationID isEqualToString:@"animateHidingCameraFocus"]) {
        m_bShowingCameraFocus = NO;
        m_imgCameraFocus.hidden = YES;
    }
}

- (void)animateMainToolbar:(BOOL)toLeft {
    [UIView beginAnimations:@"animateMainToolbar" context:NULL];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
    float offsetX = main_toolbar.frame.size.width / 2;
    if (toLeft) {
        offsetX = -offsetX; 
    }
    main_toolbar.center = CGPointMake(main_toolbar.center.x + offsetX, main_toolbar.center.y);    
    [UIView commitAnimations];
}

- (void)animateLivePreivew:(BOOL)zoomPlus {
    
    if(zoomPlus)
        [livePreview addGestureRecognizer:m_tapGestureRecognizer];
    else
        [livePreview removeGestureRecognizer:m_tapGestureRecognizer];
    
    CGRect frameRect;
    int border;
    
    CGFloat offsetY = 0;
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        if (zoomPlus){
            border = 3;
            frameRect = CGRectMake(0 - border, 0 - border, 320 + border * 2, 480 + border * 2);
        } else {
            frameRect = CGRectMake(10, 10+offsetY, 81, 106);
        }
    } else {
        if (zoomPlus) {
            border = 0;
            frameRect = CGRectMake(0 - border, 0 - border, 768 + border * 2, 1024 + border * 2);
        } else {
            frameRect = CGRectMake(10 * SCALE_X, 10 * SCALE_Y+offsetY, 81 * 2, 106 * 2);            
        }
    }
    [livePreview setFrame:frameRect hiddenBorder:zoomPlus];
    
    [UIView beginAnimations:@"animateLivePreivew" context:NULL];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];

    [livePreview resizeLivePreviewLayerToFit];
    [UIView commitAnimations];
}

- (void)setExposureSettingViewHidden:(BOOL)hidden withAnimation:(BOOL)withAnimation {
    float newOriginY;
    CGRect newFrameRect;

    
//    newOriginY = main_toolbar.frame.origin.y;
    newOriginY = SCREEN_HEIGHT;
//  Yuan end
    
    if (!hidden) {
        newOriginY = main_toolbar.frame.origin.y;
        float offsetY;
        offsetY = ([g_AppUtils captureModeType] == LIGHTTRAIL_MODE) ? 185 : 123;
        if (UI_USER_INTERFACE_IDIOM() != UIUserInterfaceIdiomPhone) {   //iPad
            offsetY *= 2;
        }
        newOriginY -= offsetY;
    }
    
    newFrameRect = exposureSettingView.frame;
    newFrameRect.origin.y = newOriginY;
    if (withAnimation) {
        [UIView beginAnimations:@"animateExposureSettingView" context:NULL];
        [UIView setAnimationDuration:0.5];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
        exposureSettingView.frame = newFrameRect;
        [UIView commitAnimations];
    } else {
        exposureSettingView.frame = newFrameRect;
    }
}

- (void)setEditSettingViewHidden:(BOOL)hidden withAnimation:(BOOL)withAnimation {
    float newOriginY;
    CGRect newFrameRect;
    
    newOriginY = main_toolbar.frame.origin.y;
    if (!hidden) {
        float offsetY;
        
        switch ([g_AppUtils captureModeType]) {
            case AUTOMATIC_MODE:
                [editSettingView modifyLayoutToFEOrder:YES];
                offsetY = [ g_AppUtils  useExposureAdjust ]? 76 : 38;         
                break;
            case MANUAL_MODE:
                [editSettingView modifyLayoutToFEOrder:NO];
                offsetY = [ g_AppUtils  useExposureAdjust ]? 38 : 0;            
                break;
            case LIGHTTRAIL_MODE:
                [editSettingView modifyLayoutToFEOrder:YES];
                offsetY = 38;
                break;                
            default:
                break;
        }
        
        if (UI_USER_INTERFACE_IDIOM() != UIUserInterfaceIdiomPhone) {   //iPad
            offsetY *= 2;
        }
        newOriginY -= offsetY;
    }
    
    newFrameRect = editSettingView.frame;
    newFrameRect.origin.y = newOriginY;
    if (withAnimation) {
        [UIView beginAnimations:@"animateEditSettingView" context:NULL];
        [UIView setAnimationDuration:0.5];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
        editSettingView.frame = newFrameRect;
        [UIView commitAnimations];
    } else {
        editSettingView.frame = newFrameRect;
    }
}

- (void)setAleartWaitViewHidden:(BOOL)hidden withAnimation:(BOOL)withAnimation {
    float newOriginY;
    CGRect newFrameRect;
    
    newOriginY = (hidden) ? main_toolbar.frame.origin.y : 0;

    newFrameRect = aleartWaiteView.frame;
    newFrameRect.origin.y = newOriginY;
    if (withAnimation) {
        [UIView beginAnimations:@"animateAleartWaitView" context:NULL];
        [UIView setAnimationDuration:0.5];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
        aleartWaiteView.frame = newFrameRect;
        [UIView commitAnimations];
    } else {
        aleartWaiteView.frame = newFrameRect;
    }
}
- (void)showCameraFocus:(BOOL)show {
    if (m_bShowingCameraFocus == show)
        return;
    m_imgCameraFocus.hidden = NO;
    CGFloat fMax = 0.9;
    if (show) {
        m_bShowingCameraFocus = YES;
        m_imgCameraFocus.alpha = 0.0;
        [UIView beginAnimations:@"animateShowingCameraFocus" context:NULL];
        [UIView setAnimationDuration:0.5];
        m_imgCameraFocus.alpha = fMax;
    }
    else {
        m_imgCameraFocus.alpha = fMax;
        [UIView beginAnimations:@"animateHidingCameraFocus" context:NULL];
        [UIView setAnimationDuration:0.4];
        m_imgCameraFocus.alpha = 0.0;
    }
    
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
    [UIView commitAnimations];
}
#pragma mark - Camera Device And Captured Data Control
- (AVCaptureDevice *)cameraWithPosition:(AVCaptureDevicePosition) position
{
    NSArray *devices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    for (AVCaptureDevice *dev in devices) {
        if ([dev position] == position) {
            return dev;
        }
    }
    return nil;
}

- (AVCaptureDevice *)frontFacingCamera
{
    return [self cameraWithPosition:AVCaptureDevicePositionFront];
}

- (AVCaptureDevice *)backFacingCamera
{
    return [self cameraWithPosition:AVCaptureDevicePositionBack];
}

- (void)unUseLED {
    if (bUsingLED) {
        [self onTorch:nil];
    }
}
- (void)setupCaptureSession {
	/*We setup the input*/
    device = [self backFacingCamera];
    
	if ([device hasTorch]) {
        [device lockForConfiguration:nil];
        [device setTorchMode:AVCaptureTorchModeOff];
        [device unlockForConfiguration];
    }
    else {
        [torch_button setHidden:YES];
    }
    captureInput = [[AVCaptureDeviceInput alloc] initWithDevice:device error:nil];

	/*We setupt the output*/
	captureOutput = [[AVCaptureVideoDataOutput alloc] init];
    
	/*While a frame is processes in -captureOutput:didOutputSampleBuffer:fromConnection: delegate methods no other frames are added in the queue.
	 If you don't want this behaviour set the property to NO */
	captureOutput.alwaysDiscardsLateVideoFrames = YES; 
    
	/*We specify a minimum duration for each frame (play with this settings to avoid having too many frames waiting
	 in the queue because it can cause memory issues). It is similar to the inverse of the maximum framerate.
	 In this example we set a min frame duration of 1/10 seconds so a maximum framerate of 10fps. We say that
	 we are not able to process more than 10 frames per second.*/
	//captureOutput.minFrameDuration = CMTimeMake(1, 10);
    
	/*We create a serial queue to handle the processing of our frames*/
	[captureOutput setSampleBufferDelegate:self queue:dispatch_get_main_queue()];

	// Set the video output to store frame in BGRA (It is supposed to be faster)
	NSString* key = (NSString*)kCVPixelBufferPixelFormatTypeKey; 
	NSNumber* value = [NSNumber numberWithUnsignedInt:kCVPixelFormatType_32BGRA]; 
	NSDictionary* videoSettings = [NSDictionary dictionaryWithObject:value forKey:key]; 
	[captureOutput setVideoSettings:videoSettings];
    
	/*And we create a capture session*/
	self.captureSession = [[AVCaptureSession alloc] init];
	[self.captureSession beginConfiguration];
    
    /*We add input and output*/
    if ([self.captureSession canAddInput:captureInput]) {
         [self.captureSession addInput:captureInput];
    } else {
        [captureInput release];
        captureInput = nil;
    }
    
    if ([self.captureSession canAddOutput:captureOutput]) {    
        [self.captureSession addOutput:captureOutput];
    } else {
        [captureOutput release];
        captureOutput = nil;
    }
    
    /*We use medium quality, ont the iPhone 4 this demo would be laging too much, the conversion in UIImage and CGImage demands too much ressources for a 720p resolution.*/
    //  AVCaptureSessionPresetPhoto:    852 * 640
    //  AVCaptureSessionPresetHigh:     1280 * 720
    //  AVCaptureSessionPresetMedium:   480 * 360
    //  AVCaptureSessionPresetLow:      192 * 144
    
    //  AVCaptureSessionPreset352x288
    //  AVCaptureSessionPreset640x480
    //  AVCaptureSessionPreset1280x720
    //  AVCaptureSessionPreset1920x1080
    //  AVCaptureSessionPresetiFrame960x540
    //  AVCaptureSessionPresetiFrame1280x720
    
/*    
    switch ([g_AppUtils  pictureSizeType]) {
        case SMALL_SIZE:
            [self.captureSession setSessionPreset:AVCaptureSessionPresetLow];
            break;
        case MEDIUM_SIZE:
            [self.captureSession setSessionPreset:AVCaptureSessionPresetMedium];
            break;
        case LARGE_SIZE:
        default:
            [self.captureSession setSessionPreset:AVCaptureSessionPresetHigh];
            break;
    }
*/  [self.captureSession setSessionPreset:AVCaptureSessionPreset640x480];

	
    /*We add the preview layer*/
    self.livePreviewLayer = [AVCaptureVideoPreviewLayer layerWithSession: self.captureSession];
//    self.livePreviewLayer.frame = self.view.bounds;
    self.livePreviewLayer.frame = CGRectMake(0, 0, 320, 400);
    [self.livePreviewLayer setAffineTransform:CGAffineTransformIdentity];
    self.livePreviewLayer.videoGravity = AVLayerVideoGravityResize;
    
  	[self.captureSession commitConfiguration];    
}

- (void)releaseCaptureSession {
    [self.captureSession stopRunning];
    
    [self.captureSession beginConfiguration];
    if (captureInput) {
        [self.captureSession removeInput:captureInput];
        [captureInput release];
        captureInput = nil;
    }

    if (captureOutput) {
        [self.captureSession removeOutput:captureOutput];
        [captureInput release];
        captureInput = nil;
    }
    [self.captureSession commitConfiguration];
    
    if (self.captureSession) {
        [self.captureSession release];
        self.captureSession = nil;
    }
}

- (void)startCapturingFromCamera {    
	/*We start the capture*/
    if (![self.captureSession isRunning]) {
        [livePreview addLivePreivewLayer:self.livePreviewLayer];
        [self.captureSession startRunning];
    }
        
}

- (void)stopCapturingFromCamera {
	/*We stop the capture*/
    [self.captureSession stopRunning];
    [livePreview removeLivePreviewLayer:self.livePreviewLayer];
}

- (void)processNewCameraFrame:(CVImageBufferRef)cameraFrame;
{
	CVPixelBufferLockBaseAddress(cameraFrame, 0);
    
    //Get Camera Frame Data Info
    int width, height;
	width = CVPixelBufferGetWidth(cameraFrame);
	height = CVPixelBufferGetHeight(cameraFrame);
    
    
    ///////////////////
    uint8_t *baseAddress = (uint8_t *)CVPixelBufferGetBaseAddress(cameraFrame);
    size_t bytesPerRow = CVPixelBufferGetBytesPerRow(cameraFrame);

    CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();
    CGContextRef newContext = CGBitmapContextCreate(baseAddress, width, height, 8, bytesPerRow, colorspace, kCGBitmapByteOrder32Big | kCGImageAlphaPremultipliedLast);
    CGImageRef   newImage = CGBitmapContextCreateImage(newContext);

    float scaleWidth = width / m_fScale;
    float scaleHeight = height / m_fScale;
   
    CGImageRef cropImage =  CGImageCreateWithImageInRect(newImage, CGRectMake((width-scaleWidth)/2, (height-scaleHeight)/2, scaleWidth, scaleHeight));
    
    [self newPixelBufferFromCGImage:cropImage width:width height:height buffer:baseAddress];
    
    CGImageRelease(cropImage);
    CGImageRelease(newImage);
    CGContextRelease(newContext);

    
    //Generate Texture From New Camera Frame
    [self genTextureFromPixelBuffer:baseAddress width:width height:height isCameraData:YES textureIDPtr:&lastFrameTextureID];
    
	[self drawFrameInPhotoPaperView];
    
    //If New Frame Is First, Generate Texture From This Frame
    if (isFirstFrame) {
        [self genTextureFromPixelBuffer:baseAddress width:width height:height isCameraData:YES textureIDPtr:&firstFrameTextureID];
        isFirstFrame = NO;
    }   
 
/*    
    //Generate Texture From New Camera Frame
    [self genTextureFromPixelBuffer:CVPixelBufferGetBaseAddress(cameraFrame) width:width height:height isCameraData:YES textureIDPtr:&lastFrameTextureID];

	[self drawFrameInPhotoPaperView];

    //If New Frame Is First, Generate Texture From This Frame
    if (isFirstFrame) {
        [self genTextureFromPixelBuffer:CVPixelBufferGetBaseAddress(cameraFrame) width:width height:height isCameraData:YES textureIDPtr:&firstFrameTextureID];
        isFirstFrame = NO;
    }
*/ 
    
	CVPixelBufferUnlockBaseAddress(cameraFrame, 0);
}

- (void) newPixelBufferFromCGImage: (CGImageRef) image width:(int) _width height:(int) _height buffer:(uint8_t*)buffer
{
	
    CGColorSpaceRef rgbColorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(buffer, _width,
												 _height, 8, 4*_width, rgbColorSpace, 
												 kCGBitmapByteOrder32Big | kCGImageAlphaPremultipliedLast);
    NSParameterAssert(context);
	//  CGContextConcatCTM(context, frameTransform);
    CGContextDrawImage(context, CGRectMake(0, 0, _width, _height), image);
    CGColorSpaceRelease(rgbColorSpace);
    CGContextRelease(context);
}


#pragma mark - AVCaptureVideoDataOutputSampleBufferDelegate

- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection
{   
    if (bTakingPictures) {
        NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
        if( CMSampleBufferDataIsReady(sampleBuffer) )
        {
            {
                CVImageBufferRef pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);
                [self processNewCameraFrame:pixelBuffer];
            }
        }
        else {
            NSLog( @"sample buffer is not ready. Skipping sample" );
        }
        [pool drain];
    }
}

#pragma mark - OpenGL ES 2.0 Setup
- (void) initGL {
    RendererInfo renderer;
	// Query renderer capabilities that affect this app's rendering paths
	renderer.extension[APPLE_texture_2D_limited_npot] =
    (0 != strstr((char *)glGetString(GL_EXTENSIONS), "GL_APPLE_texture_2D_limited_npot"));
	renderer.extension[IMG_texture_format_BGRA8888] =
    (0 != strstr((char *)glGetString(GL_EXTENSIONS), "GL_IMG_texture_format_BGRA8888"));
	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &renderer.maxTextureSize);
}

- (BOOL)loadVertexShader:(NSString *)vertexShaderName fragmentShader:(NSString *)fragmentShaderName forProgram:(GLuint *)programPointer {
    GLuint vertexShader, fragShader;
	
    NSString *vertShaderPathname, *fragShaderPathname;
    
    // Create shader program.
    *programPointer = glCreateProgram();
    
    // Create and compile vertex shader.
    vertShaderPathname = [[NSBundle mainBundle] pathForResource:vertexShaderName ofType:@"vsh"];
    if (![self compileShader:&vertexShader type:GL_VERTEX_SHADER file:vertShaderPathname])
    {
        NSLog(@"Failed to compile vertex shader");
        return FALSE;
    }
    
    // Create and compile fragment shader.
    fragShaderPathname = [[NSBundle mainBundle] pathForResource:fragmentShaderName ofType:@"fsh"];
    if (![self compileShader:&fragShader type:GL_FRAGMENT_SHADER file:fragShaderPathname])
    {
        NSLog(@"Failed to compile fragment shader");
        return FALSE;
    }
    
    // Attach vertex shader to program.
    glAttachShader(*programPointer, vertexShader);
    
    // Attach fragment shader to program.
    glAttachShader(*programPointer, fragShader);
    
    // Bind attribute locations.
    // This needs to be done prior to linking.
    glBindAttribLocation(*programPointer, ATTRIB_VERTEX, "position");
    glBindAttribLocation(*programPointer, ATTRIB_TEXTUREPOSITON, "inputTextureCoordinate");
    
    // Link program.
    if (![self linkProgram:*programPointer])
    {
        NSLog(@"Failed to link program: %d", *programPointer);
        
        if (vertexShader)
        {
            glDeleteShader(vertexShader);
            vertexShader = 0;
        }
        if (fragShader)
        {
            glDeleteShader(fragShader);
            fragShader = 0;
        }
        if (*programPointer)
        {
            glDeleteProgram(*programPointer);
            *programPointer = 0;
        }
        
        return FALSE;
    }
    
    // Get uniform locations.
    uniforms[UNIFORM_VIDEOFRAME] = glGetUniformLocation(*programPointer, "videoFrame");
    uniforms[UNIFORM_INPUTCOLOR] = glGetUniformLocation(*programPointer, "inputColor");
    uniforms[UNIFORM_SOLIDCOLOR] = glGetUniformLocation(*programPointer, "solidColor");
    uniforms[UNIFORM_INPUTCONTRAST] = glGetUniformLocation(*programPointer, "inputContrast");
    uniforms[UNIFORM_INPUTBRIGHTNESS] = glGetUniformLocation(*programPointer, "inputBrightness");
    uniforms[UNIFORM_INPUTSATURATION] = glGetUniformLocation(*programPointer, "inputSaturation");
    uniforms[UNIFORM_ENABLEBW] = glGetUniformLocation(*programPointer, "enableBW");
    uniforms[UNIFORM_ENABLESEPIA] = glGetUniformLocation(*programPointer, "enableSepia");
    uniforms[UNIFORM_SCREENMODE] = glGetUniformLocation(*programPointer, "screenMode");
    uniforms[UNIFORM_ALPHA] = glGetUniformLocation(*programPointer, "Alpha");
    uniforms[UNIFORM_LUMCOEFF] = glGetUniformLocation(*programPointer, "lumCoeff");
    
    // Release vertex and fragment shaders.
    if (vertexShader)
	{
        glDeleteShader(vertexShader);
	}
    if (fragShader)
	{
        glDeleteShader(fragShader);		
	}
    
    return TRUE;
}

- (BOOL)compileShader:(GLuint *)shader type:(GLenum)type file:(NSString *)file {
    GLint status;
    const GLchar *source;
    
    source = (GLchar *)[[NSString stringWithContentsOfFile:file encoding:NSUTF8StringEncoding error:nil] UTF8String];
    if (!source)
    {
        NSLog(@"Failed to load vertex shader");
        return FALSE;
    }
    
    *shader = glCreateShader(type);
    glShaderSource(*shader, 1, &source, NULL);
    glCompileShader(*shader);
    
#if defined(DEBUG)
    GLint logLength;
    glGetShaderiv(*shader, GL_INFO_LOG_LENGTH, &logLength);
    if (logLength > 0)
    {
        GLchar *log = (GLchar *)malloc(logLength);
        glGetShaderInfoLog(*shader, logLength, &logLength, log);
        NSLog(@"Shader compile log:\n%s", log);
        free(log);
    }
#endif
    
    glGetShaderiv(*shader, GL_COMPILE_STATUS, &status);
    if (status == 0)
    {
        glDeleteShader(*shader);
        return FALSE;
    }
    
    return TRUE;
}

- (BOOL)linkProgram:(GLuint)prog {
    GLint status;
    
    glLinkProgram(prog);
    
#if defined(DEBUG)
    GLint logLength;
    glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &logLength);
    if (logLength > 0)
    {
        GLchar *log = (GLchar *)malloc(logLength);
        glGetProgramInfoLog(prog, logLength, &logLength, log);
        NSLog(@"Program link log:\n%s", log);
        free(log);
    }
#endif
    
    glGetProgramiv(prog, GL_LINK_STATUS, &status);
    if (status == 0)
        return FALSE;
    
    return TRUE;
}

- (BOOL)validateProgram:(GLuint)prog {
    GLint logLength, status;
    
    glValidateProgram(prog);
    glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &logLength);
    if (logLength > 0)
    {
        GLchar *log = (GLchar *)malloc(logLength);
        glGetProgramInfoLog(prog, logLength, &logLength, log);
        NSLog(@"Program validate log:\n%s", log);
        free(log);
    }
    
    glGetProgramiv(prog, GL_VALIDATE_STATUS, &status);
    if (status == 0)
        return FALSE;
    
    return TRUE;
}

- (void)unloadShaderProgram:(GLuint *)programPointer {
    if (*programPointer) {
        glDeleteProgram(*programPointer);
        *programPointer = 0;
    }
}

- (void)genTextureFromPixelBuffer:(uint8_t *)pixelBuffer width:(int)width height:(int)height isCameraData:(BOOL)isCameraData textureIDPtr:(GLuint *)textureIDPtr {
    //Destroy prev texture
    if (*textureIDPtr)
        glDeleteTextures(1, textureIDPtr);
    
	// Create a new texture from the camera frame data, display that using the shaders
	glGenTextures(1, textureIDPtr);
	glBindTexture(GL_TEXTURE_2D, *textureIDPtr);
    
    
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	
    // This is necessary for non-power-of-two textures
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    // Using BGRA extension to pull in video frame data directly
    // else RGBA framebuffer data
    GLenum format = (isCameraData) ? GL_BGRA : GL_RGBA;
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, format, GL_UNSIGNED_BYTE,  pixelBuffer);
}

- (void)genTextureFromFrameBuffer:(GLuint *)textureIDPtr {
    if (*textureIDPtr)
        glDeleteTextures(1, textureIDPtr);
	glGenTextures(1, textureIDPtr);
    
    glBindTexture(GL_TEXTURE_2D, *textureIDPtr);
    
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// This is necessary for non-power-of-two textures
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    
    glCopyTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 0, 0, photoPaperView.backingWidth, photoPaperView.backingHeight, 0);    
}

- (void)delTakingPictureTextures {
    if (firstFrameTextureID) {
        glDeleteTextures(1, &firstFrameTextureID);
        firstFrameTextureID = 0;
    }
    
    if (lastFrameTextureID) {
        glDeleteTextures(1, &lastFrameTextureID);    
        lastFrameTextureID = 0;
    }
    
    if (tmpFrameTextureID) {
        glDeleteTextures(1, &tmpFrameTextureID);        
        tmpFrameTextureID = 0;
    }
}

- (void)delEditingPictureTextures {
    if (backTextureID) {
        glDeleteTextures(1, &backTextureID);
        backTextureID = 0;
    }
}

#pragma mark - OpenGL ES 2.0 Effect Drawing
- (void)drawFrameInPhotoPaperView
{
    [photoPaperView setDisplayFramebuffer];

    //Draw New Frame Texture With Previous Framebuffer By Using Blend Tech
    [self drawCapturedFrame];
    if (!isFirstFrame) {
        [self drawFrameBuffer];
    }

    //Get Framebuffer As Texture
    [self genTextureFromFrameBuffer:&tmpFrameTextureID];

    [photoPaperView presentFramebuffer];    
}

- (void)drawCapturedFrame {
    glUseProgram(drawTextureProgram);
    glBindTexture(GL_TEXTURE_2D, lastFrameTextureID);
    glUniform1f(uniforms[UNIFORM_ALPHA], 1.0);
    glUniform1i(uniforms[UNIFORM_SCREENMODE], 7);
    
    // Update attribute values.
    static const GLfloat squareVertices[] = {
        -1.0f, -1.0f,
        1.0f, -1.0f,
        -1.0f, 1.0f,
        1.0f, 1.0f,
    };
    
	glVertexAttribPointer(ATTRIB_VERTEX, 2, GL_FLOAT, 0, 0, squareVertices);
	glEnableVertexAttribArray(ATTRIB_VERTEX);

    if (!bUsingFrontCamera) {
        static const GLfloat textureVertices[] = {
            1.0f, 1.0f,
            1.0f, 0.0f,
            0.0f, 1.0f,
            0.0f, 0.0f,
        };
        glVertexAttribPointer(ATTRIB_TEXTUREPOSITON, 2, GL_FLOAT, 0, 0, textureVertices);
        glEnableVertexAttribArray(ATTRIB_TEXTUREPOSITON);        
    }
    else {
        static const GLfloat textureVertices[] = {
            1.0f, 0.0f,
            1.0f, 1.0f,
            0.0f, 0.0f,
            0.0f, 1.0f,            
        };
        glVertexAttribPointer(ATTRIB_TEXTUREPOSITON, 2, GL_FLOAT, 0, 0, textureVertices);
        glEnableVertexAttribArray(ATTRIB_TEXTUREPOSITON);
    }

    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

- (void)drawFrameBuffer {
    glUseProgram(drawTextureProgram);
    glBindTexture(GL_TEXTURE_2D, tmpFrameTextureID);
    glEnable(GL_BLEND);
    
    switch ([g_AppUtils captureModeType]) {
        case AUTOMATIC_MODE:
            glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ZERO, GL_ONE);
            glUniform1f(uniforms[UNIFORM_ALPHA], 0.975f);
            break;
        case MANUAL_MODE:
            glBlendFuncSeparate(GL_ONE, GL_ONE, GL_ZERO, GL_ONE);
            glUniform1f(uniforms[UNIFORM_ALPHA], 0.1f);
            break;
        case LIGHTTRAIL_MODE:
            glBlendFuncSeparate(GL_ONE, GL_ONE, GL_ZERO, GL_ONE);
            glBlendEquationSeparate(GL_FUNC_REVERSE_SUBTRACT, GL_FUNC_ADD);
            glUniform1f(uniforms[UNIFORM_ALPHA], 1.0f);
            break;
    }  
    glUniform1i(uniforms[UNIFORM_SCREENMODE], 7);
    
    // Update attribute values.
    static const GLfloat squareVertices[] = {
        -1.0f, -1.0f,
        1.0f, -1.0f,
        -1.0f, 1.0f,
        1.0f, 1.0f,
    };
    
	glVertexAttribPointer(ATTRIB_VERTEX, 2, GL_FLOAT, 0, 0, squareVertices);
	glEnableVertexAttribArray(ATTRIB_VERTEX);
    
    static const GLfloat textureVertices[] = {
        0.0f, 0.0f,
        1.0f, 0.0f,
        0.0f, 1.0f,
        1.0f, 1.0f,
    };
    glVertexAttribPointer(ATTRIB_TEXTUREPOSITON, 2, GL_FLOAT, 0, 0, textureVertices);
    glEnableVertexAttribArray(ATTRIB_TEXTUREPOSITON);        
    
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    
    if ([g_AppUtils captureModeType] == LIGHTTRAIL_MODE) {
        glBlendFuncSeparate(GL_ONE, GL_SRC_ALPHA, GL_ZERO, GL_ONE);
        glBlendEquationSeparate(GL_FUNC_ADD, GL_FUNC_ADD);
        glUniform1f(uniforms[UNIFORM_ALPHA], [g_AppUtils sensitivity]);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    }
    
    glDisable(GL_BLEND);    
}

- (void)drawCamFrameTexture:(GLuint)textureID withAlpha:(float)alpha useBlend:(BOOL)useBlend {
    glUseProgram(drawTextureProgram);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glUniform1f(uniforms[UNIFORM_ALPHA], alpha);
    glUniform1i(uniforms[UNIFORM_SCREENMODE], 7);

    if (useBlend) {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }
    // Update attribute values.
    static const GLfloat squareVertices[] = {
        -1.0f, -1.0f,
        1.0f, -1.0f,
        -1.0f, 1.0f,
        1.0f, 1.0f,
    };
    
	glVertexAttribPointer(ATTRIB_VERTEX, 2, GL_FLOAT, 0, 0, squareVertices);
	glEnableVertexAttribArray(ATTRIB_VERTEX);
    
    if (!bUsingFrontCamera) {
        static const GLfloat textureVertices[] = {
            1.0f, 1.0f,
            1.0f, 0.0f,
            0.0f, 1.0f,
            0.0f, 0.0f,
        };
        glVertexAttribPointer(ATTRIB_TEXTUREPOSITON, 2, GL_FLOAT, 0, 0, textureVertices);
        glEnableVertexAttribArray(ATTRIB_TEXTUREPOSITON);        
    }
    else {
        static const GLfloat textureVertices[] = {
            1.0f, 0.0f,
            1.0f, 1.0f,
            0.0f, 0.0f,
            0.0f, 1.0f,            
        };
        glVertexAttribPointer(ATTRIB_TEXTUREPOSITON, 2, GL_FLOAT, 0, 0, textureVertices);
        glEnableVertexAttribArray(ATTRIB_TEXTUREPOSITON);
    }
    
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    
    if (useBlend) {
        glDisable(GL_BLEND);
    }    
}

- (void)drawFrameBufferTexture:(GLuint)textureID withAlpha:(float)alpha useBlend:(BOOL)useBlend {
    glUseProgram(drawTextureProgram);
    glBindTexture(GL_TEXTURE_2D, textureID);
    
    glUniform1f(uniforms[UNIFORM_ALPHA], alpha);
    glUniform1i(uniforms[UNIFORM_SCREENMODE], 7);
    
    if (useBlend) {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }

    // Update attribute values.
    static const GLfloat squareVertices[] = {
        -1.0f, -1.0f,
        1.0f, -1.0f,
        -1.0f, 1.0f,
        1.0f, 1.0f,
    };
    
	glVertexAttribPointer(ATTRIB_VERTEX, 2, GL_FLOAT, 0, 0, squareVertices);
	glEnableVertexAttribArray(ATTRIB_VERTEX);
    
    static const GLfloat textureVertices[] = {
        0.0f, 0.0f,
        1.0f, 0.0f,
        0.0f, 1.0f,
        1.0f, 1.0f,
    };
    glVertexAttribPointer(ATTRIB_TEXTUREPOSITON, 2, GL_FLOAT, 0, 0, textureVertices);
    glEnableVertexAttribArray(ATTRIB_TEXTUREPOSITON);        
    
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4); 
    
    if (useBlend) {
        glDisable(GL_BLEND);
    } 
}

- (void)drawColorEffeectTexture:(GLuint)textureID withEffect:(float)k useBlend:(BOOL)useBlend {
    glUseProgram(drawTextureProgram);
    glBindTexture(GL_TEXTURE_2D, textureID);
    
    glUniform1f(uniforms[UNIFORM_ALPHA], 1.0);
//    if(![g_AppUtils useExposureLock])
        glUniform1f(uniforms[UNIFORM_INPUTCONTRAST], k);    
    glUniform1i(uniforms[UNIFORM_SCREENMODE], 8);
    
    if (useBlend) {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }
    
    // Update attribute values.
    static const GLfloat squareVertices[] = {
        -1.0f, -1.0f,
        1.0f, -1.0f,
        -1.0f, 1.0f,
        1.0f, 1.0f,
    };
    
	glVertexAttribPointer(ATTRIB_VERTEX, 2, GL_FLOAT, 0, 0, squareVertices);
	glEnableVertexAttribArray(ATTRIB_VERTEX);
    
    static const GLfloat textureVertices[] = {
        0.0f, 0.0f,
        1.0f, 0.0f,
        0.0f, 1.0f,
        1.0f, 1.0f,
    };
    glVertexAttribPointer(ATTRIB_TEXTUREPOSITON, 2, GL_FLOAT, 0, 0, textureVertices);
    glEnableVertexAttribArray(ATTRIB_TEXTUREPOSITON);        
    
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4); 
    
    if (useBlend) {
        glDisable(GL_BLEND);
    } 
}

#pragma mark - OpenGL ES 2.0 Editing
- (void)drawEditFrameInPhotoPaperView {
    [photoPaperView setDisplayFramebuffer];    
    
//    [photoPaperView clearView];
    switch ([g_AppUtils captureModeType]) {
        case AUTOMATIC_MODE:
            [self drawCamFrameTexture:targetTextureID withAlpha:1.0f useBlend:NO];
            [self drawFrameBufferTexture:tmpFrameTextureID withAlpha:1.0f - blendValueToTarget useBlend:YES];
            [self genTextureFromFrameBuffer:&backTextureID];
            [self drawColorEffeectTexture:backTextureID withEffect:blendValueToBack useBlend:NO];
            break;
        case MANUAL_MODE:
//            [self drawFrameBufferTexture:tmpFrameTextureID withAlpha:1.0f useBlend:NO];
            [self drawCamFrameTexture:firstFrameTextureID withAlpha:1.0f useBlend:NO];
            [self genTextureFromFrameBuffer:&backTextureID];
            [self drawColorEffeectTexture:backTextureID withEffect:blendValueToBack useBlend:NO];
            break;
        case LIGHTTRAIL_MODE:
            [self drawCamFrameTexture:targetTextureID withAlpha:1.0f useBlend:NO];
            [self drawFrameBufferTexture:tmpFrameTextureID withAlpha:1.0f - blendValueToTarget useBlend:YES];
            break;
        default:
            break;
    }
    
    [photoPaperView presentFramebuffer];
}

#pragma mark - App Setting Change Delegate
- (void)changeExposureSettings {
    //Capture Mode
    [self setExposureSettingViewHidden:NO withAnimation:YES];
}

- (void)changeEditSettings {
    //Calc Freeze Params
    float freezeValue = [g_AppUtils freeze];
    if (freezeValue < 0.0f) {
        targetTextureID = firstFrameTextureID;
        freezeValue = -freezeValue;
    } else {
        targetTextureID = lastFrameTextureID;
    }
    blendValueToTarget = freezeValue / 100.0f;
    
    //Calc Exposure Params    
    float exposureValue = [g_AppUtils exposure];  
    if ([g_AppUtils captureModeType] != MANUAL_MODE) {
        if (exposureValue < 0.0f) {
//            blendValueToBack = exposureValue / 2.0f * 0.5f;
            blendValueToBack = exposureValue / 2.0f * 0.8f;
        } else {
            blendValueToBack = exposureValue / 2.0f * 3.0f;
        }
    }
    else {
        blendValueToBack = (4.0+exposureValue) * 2.5f;
        if ([g_AppUtils shutterSpeed] < 0)
            blendValueToBack += 10;
        else
            blendValueToBack += ([g_AppUtils shutterSpeed]/2);
    }
    
    //Do Editing
    [self drawEditFrameInPhotoPaperView];
}

#pragma mark -
#pragma mark UIAlertView

- (void)alertSimpleAction:(NSString*) strMessage
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Photo Uploader" message:strMessage
												   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
	[alert show];	
	[alert release];
}

- (void)alertOkAction:(NSString*) strMessage {
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strMessage message:nil
												   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
	[alert show];	
	[alert release];
}


#pragma mark - email method
- (void) onEmail {
	if (![MFMailComposeViewController canSendMail]) {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No Mail Accounts" message:@"Please set up a Mail account in order to send email."
													   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
		[alert show];	
		[alert release];
		return;
	}
	MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
	picker.mailComposeDelegate = self;
	
	NSString* content;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
        content = @"sent via ExposeMe for iPhone";
    else
        content = @"sent via ExposeMe for iPad";
    
    
	[picker setSubject:@"Look at this Awesome Picture I took with ExposeMe!"];

	NSString* path =[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/email.jpg"];
	[self saveImageToDocument:path];
	
	[picker setMessageBody:content isHTML:NO]; 

	[picker addAttachmentData:[NSData dataWithContentsOfFile:path] mimeType:@"image/jpg" fileName:@"image.jpg"];
	
	picker.navigationBar.barStyle = UIBarStyleDefault; 
	
	[self presentModalViewController:picker animated:YES];
	//	[emailAddrs release];
	[picker release];
}
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{ 
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
			break;
		case MFMailComposeResultSaved:
			break;
		case MFMailComposeResultSent:
            [self alertOkAction:@"Email sent!"];
			break;
		case MFMailComposeResultFailed:
			break;
			
		default:
		{
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Email" message:@"Sending Failed - Unknown Error :-("
														   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
			[alert show];
			[alert release];
		}
			
			break;
	}
	[self dismissModalViewControllerAnimated:YES];
}

#pragma mark - UIAlertViewDelegate method
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView.tag == kAlertViewLogin2Flickr) {//n
        if( buttonIndex == 1)
        {
            [self loginToFlickr];
        }
    }
    else if(alertView.tag == kAlertViewLogin2Twitter){
    }
    else if (alertView.tag == kAlertViewLightTrail) {
        if (buttonIndex == 0) {
            [exposureSettingView setEnableLightTrail:NO];
        }
        else {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://itunes.apple.com/us/app/slow-shutter-camera-free/id503083989?ls=1&mt=8"]];
            g_AppUtils.m_bShowLightTrailMsg = NO;
            [g_AppUtils setCaptureModeType:LIGHTTRAIL_MODE];
            [self changeExposureSettings];
        }
    }
    else if (alertView.tag == kAlertViewShutterSpeedB) {
        if (buttonIndex == 0) {
            [exposureSettingView setEnableShutterSpeedB:NO];
        }
        else {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.facebook.com/FromTheTopApps"]];
            g_AppUtils.m_bShowShutterSpeedBMsg = NO;
            [g_AppUtils setShutterSpeedType:SPEED_B];
        }
    }
    else if (alertView.tag == kAlertViewNagPaid) {
        if (buttonIndex == 1) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url_paid]];
        }
    }
    
    
}

- (void) saveImageToDocument:(NSString*)strPath {
    UIImage *snapshotImage = [self changeImage:[photoPaperView snapshot]];
    
    NSData* writeData = UIImageJPEGRepresentation(snapshotImage, 1.0);
    [writeData writeToFile:strPath atomically:YES];
}



- (void) sliderMove:(id) sender {
    m_fScale = ((UISlider*) sender).value;
    
    livePreview.transform = CGAffineTransformMakeScale(m_fScale, m_fScale);
    
    
/*    
    CGAffineTransform affineTransform = CGAffineTransformScale(affineTransform, value, value);
    
//    [CATransaction begin];
//    [CATransaction setAnimationDuration:0.025];
    
    [self.livePreviewLayer setAffineTransform:affineTransform];
    
//    [CATransaction commit];
*/ 
}

-(void) nagScreen {
        
    m_nTakePhotoCount ++;
    
    if (m_nTakePhotoCount >= TAKE_PHOTO_COUNT) {
        _timerNagScreen = [NSTimer scheduledTimerWithTimeInterval:2.0 target:self
                                                         selector:@selector(showNagScreen:) userInfo:nil repeats:NO];
    }
}
- (void) showNagScreen:(NSTimer*)timer
{
    if (_timerNagScreen) {
        NSString* _message = @"Upgrade now for all the ExposeMe features";
        UIAlertView* alert=[[UIAlertView alloc] initWithTitle:@""
                                                      message:_message
                                                     delegate:self
                                            cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
        alert.tag = kAlertViewNagPaid;
        [alert show];
    }
}

@end
