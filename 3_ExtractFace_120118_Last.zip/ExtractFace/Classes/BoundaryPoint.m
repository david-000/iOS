//
//  BoundaryPoint.m
//  ExtractFace
//
//  Created by admin on 1/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BoundaryPoint.h"

@implementation BoundaryPoint

@synthesize m_xPoint;

- (void)SetPoint:(CGPoint)xPoint size:(int)nPointSize
{
    m_xPoint = xPoint;
    m_nPointSize = nPointSize;
}



@end
