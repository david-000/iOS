//
//  engine.m
//  MySlash
//
//  Created by Kim Jong Chol on 3/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "engine.h"
#import "ptData.h"

CGFloat getMaxXLine(SLine line)
{
	return (line.sp.x > line.ep.x)? line.sp.x:line.ep.x;
}

CGFloat getMinXLine(SLine line)
{
	return (line.sp.x < line.ep.x)? line.sp.x:line.ep.x;
}

CGFloat getMaxYLine(SLine line)
{
	return (line.sp.y > line.ep.y)? line.sp.y:line.ep.y;
}

CGFloat getMinYLine(SLine line)
{
	return (line.sp.y < line.ep.y)? line.sp.y:line.ep.y;
}

CGPoint	getAandB (SLine	line)
{
	CGFloat a, b;
	CGFloat dx = line.ep.x - line.sp.x;
	if (dx) 
		a = (line.ep.y - line.sp.y) / dx;
	else
		return CGPointZero;
		
	b = ((line.sp.y + line.ep.y) - a * (line.sp.x + line.ep.x))/2.0f;
	return CGPointMake(a, b);
}

CGPoint	getIntersectPos(SLine l1, SLine l2)
{
	CGFloat a, b, c, d;
	CGPoint ab =  getAandB(l1);
	CGPoint cd =  getAandB(l2);
	
	BOOL ab_valid = !CGPointEqualToPoint(ab, CGPointZero);
	BOOL cd_valid = !CGPointEqualToPoint(cd, CGPointZero);
	
	if (!ab_valid && !cd_valid) {
		return CGPointZero;
	}
	else if (!ab_valid){
		return CGPointMake(l1.sp.x, l1.sp.x * cd.x + cd.y);
	}
	else if (!cd_valid){
		return CGPointMake(l2.sp.x, l2.sp.x * ab.x + ab.y);
	}


	
	a = ab.x;
	b = ab.y;
	c = cd.x;
	d = cd.y;
	
	if (a - c == 0 ) {
		return CGPointZero;
	}
	
	CGFloat x = (d - b)/(a - c);
	if (x < getMinXLine(l1) || x > getMaxXLine(l1))
		return CGPointZero;
	if (x < getMinXLine(l2) || x > getMaxXLine(l2))
		return CGPointZero;
	
	CGFloat y = a * x + b;
	return CGPointMake(x, y);
}

CGFloat getAngleFromTwoPoint(CGPoint ptFarCenter , CGPoint ptNearCenter)
{
	CGFloat distance_x = ptFarCenter.x - ptNearCenter.x;
	CGFloat distance_y = ptFarCenter.y - ptNearCenter.y;
	CGFloat direction;
	if (distance_x == 0)
	{
		direction = M_PI_2;
		if (distance_y < 0)
			direction = - M_PI_2;
	}
	else if (distance_x > 0)
		direction = atan(distance_y/distance_x);
	else if (distance_y > 0)
		direction = M_PI - atan(-distance_y/distance_x);
	else 
		direction = M_PI + atan(distance_y/distance_x);
	return direction;
}

CGImageRef	getAlphaImageWithCGImage(CGImageRef src_img)
{
	if (!src_img) 
		return NULL;
	
	int nWidth = CGImageGetWidth(src_img);
	int nHeight = CGImageGetHeight(src_img);
	
	CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
	CGContextRef context = CGBitmapContextCreate(nil, nWidth, nHeight, 8, 0, colorSpace, kCGImageAlphaPremultipliedFirst);
	
	UIGraphicsPushContext(context);
	CGRect img_rect = CGRectMake(0, 0, nWidth, nHeight);
	CGContextClearRect(context, CGRectMake(0, 0, nWidth, nHeight));
	CGContextDrawImage(context, img_rect, src_img);
	UIGraphicsPopContext();
	
	CGImageRef image = CGBitmapContextCreateImage(context);
	
	CGContextRelease(context);
	CGColorSpaceRelease(colorSpace);
	
	return image;
}

void	randomize()
{
	time_t tv;
	time (&tv);
	srand(tv);
}

@implementation PolygonModel

@synthesize head;
@synthesize tail;

-(id) initWithIndex:(int)ix Scale:(CGPoint)sp
{
	if ((self = [super init]))
	{
		if (ix >= sizeof(pointInfo) / sizeof(SPointDataInfo)) 
			return self;
		
		int start_ix = pointInfo[ix].index;
		int	num = pointInfo[ix].count;
		
		for (int i = 0; i < num; i++)
		{
			SPointData pt_data = pointData[start_ix + i];
			CGPoint pt = CGPointMake(pt_data.x * sp.x, pt_data.y * sp.y);
			[self appendPoint:pt Flag:pt_data.f];
		}
	}
	return self;
}

-(id) initWithModel : (PolygonModel *)model
{
	if ((self = [super init]))
	{
		SPointNode *ptNode = model.head;
		for (;;)
		{	
			CGPoint pt = ptNode->point;
			[self appendPoint:pt Flag:ptNode->flag];
			if (ptNode == model.tail)
				break;
			ptNode = ptNode->next; 
		}
		
	}
	return self;
}

-(CGRect) boundRect
{
	return CGRectMake(bound[0], bound[2], bound[1] - bound[0], bound[3] - bound[2]);
}

-(void)	appendPoint:(CGPoint)pt Flag:(int)f
{
	SPointNode *ptNode = malloc(sizeof(SPointNode));
	ptNode->point = pt;
	ptNode->flag = f;
	if (!head)
	{
		head = ptNode;
		tail = ptNode;
		bound[0] = bound[1] = pt.x;
		bound[2] = bound[3] = pt.y;
	}
	else
	{
		if (CGPointEqualToPoint(pt, tail->point))
		{
			free(ptNode);
			return;
		}
		tail->next = ptNode;
		tail = ptNode;
		tail->next = head;
		
		bound[0] = MIN(bound[0], pt.x);
		bound[1] = MAX(bound[1], pt.x);
		bound[2] = MIN(bound[2], pt.y);
		bound[3] = MAX(bound[3], pt.y);
	}
}

-(void)	prependPoint:(CGPoint)pt Flag:(int)f
{
	SPointNode *ptNode = malloc(sizeof(SPointNode));
	ptNode->point = pt;
	ptNode->flag = f;
	if (!head)
	{
		head = ptNode;
		tail = ptNode;
		
		bound[0] = bound[1] = pt.x;
		bound[2] = bound[3] = pt.y;
	}
	else
	{
		if (CGPointEqualToPoint(pt, head->point))
		{
			free(ptNode);
			return;
		}
		
		ptNode->next = head;
		head = ptNode;
		
		bound[0] = MIN(bound[0], pt.x);
		bound[1] = MAX(bound[1], pt.x);
		bound[2] = MIN(bound[2], pt.y);
		bound[3] = MAX(bound[3], pt.y);
	}
}

-(BOOL)	isContainPoint:(CGPoint) pt
{
	int intersect_count = 0;
	
    CGSize s;
    if(UI_USER_INTERFACE_IDIOM()!= UIUserInterfaceIdiomPad)
        s = CGSizeMake(320, 480);
    else
        s = CGSizeMake(768, 1024); 
	CGPoint ptOther = pt;
	if (pt.x < s.width/2.0f)
		ptOther.x = 0;
	else
		ptOther.x = s.width;
	
	SLine cut_line;
	cut_line.sp = pt;
	cut_line.ep = ptOther;
	SPointNode *ptNode = head;
	for (;;)
	{
		SPointNode *ptNext = ptNode->next;
		SLine line;
		line.sp = ptNode->point;
		line.ep = ptNext->point;
		
		BOOL check_need = YES;
		if (getMaxXLine(line) < getMinXLine(cut_line) || getMinXLine(line) > getMaxXLine(cut_line))
			check_need = NO;
		if (getMaxYLine(line) < getMinYLine(cut_line) || getMinYLine(line) > getMaxYLine(cut_line))
			check_need = NO;
		
		if (check_need == YES )
		{
			if (!CGPointEqualToPoint(getIntersectPos(cut_line, line), CGPointZero))
				intersect_count++;
		}
		if (ptNode == tail)
			break;
		ptNode = ptNode->next;
	}
	
	if (intersect_count % 2 == 0)
		return NO;
	return YES;
}

-(CGPoint) getFirstIntersectPos : (SLine)cut_line intersectLine:(SLine *)i_l
{
	SPointNode *ptNode = head;
	for (;;)
	{
		SPointNode *ptNext = ptNode->next;
		SLine line;
		line.sp = ptNode->point;
		line.ep = ptNext->point;
		
		BOOL check_need = YES;
		if (getMaxXLine(line) < getMinXLine(cut_line) || getMinXLine(line) > getMaxXLine(cut_line))
			check_need = NO;
		if (getMaxYLine(line) < getMinYLine(cut_line) || getMinYLine(line) > getMaxYLine(cut_line))
			check_need = NO;
		
		if (check_need == YES )
		{
			CGPoint pt = getIntersectPos(cut_line, line);
			if (!CGPointEqualToPoint(pt, CGPointZero))
			{
				i_l->sp = line.sp;
				i_l->ep = line.ep;
				return pt; 
			}
		}
		
		if (ptNode == tail) {
			break;
		}
		ptNode = ptNode->next;
	}
	return CGPointZero;
}

-(SplitResult)	splitByLine:(SLine) cut_line Model1:(PolygonModel **)model1 Model2:(PolygonModel **)model2
{
	CGPoint			first_pos;
	CGPoint			end_pos;
	SPointNode *	first_begin;
	SPointNode *	first_end;
	SPointNode *	end_begin;
	SPointNode *	end_end;
	
	int		intersect_count = 0;
	
	BOOL nonBreakable = NO;
	SPointNode *ptNode = head;
	for (;;)
	{
		SPointNode *ptNext = ptNode->next;
		SLine line;
		line.sp = ptNode->point;
		line.ep = ptNext->point;
		
		BOOL check_need = YES;
		if (getMaxXLine(line) < getMinXLine(cut_line) || getMinXLine(line) > getMaxXLine(cut_line))
			check_need = NO;
		if (getMaxYLine(line) < getMinYLine(cut_line) || getMinYLine(line) > getMaxYLine(cut_line))
			check_need = NO;
		
		if (check_need == YES )
		{
			CGPoint pt = getIntersectPos(cut_line, line);
			if (!CGPointEqualToPoint(pt, CGPointZero))
			{
				BOOL layInLine = YES;
				if (pt.x < getMinXLine(line) || pt.x > getMaxXLine(line)) 
					layInLine = NO;
				if (pt.y < getMinYLine(line) || pt.y > getMaxYLine(line)) 
					layInLine = NO;
				
				if (layInLine) {
					if (ptNext->flag) 
						nonBreakable = YES;
					
					if (intersect_count == 0) {
						first_pos = pt;
						first_begin = ptNode;
						first_end = ptNext;
					}
					else {
						end_pos = pt;
						end_begin = ptNode;
						end_end = ptNext;
					}
					intersect_count++; 
					if (intersect_count == 2)
						break;
				}
			}
		}
		
		if (ptNode == tail) {
			break;
		}
		ptNode = ptNode->next;
	}
	
	if (intersect_count < 2) 
		return SplitFail;
	
	if (nonBreakable) 
		return SplitBreak;
	
	*model1 = [[PolygonModel alloc] init];
	ptNode = end_end;
	for (;;)
	{
		[*model1 appendPoint:ptNode->point Flag:ptNode->flag];
		if (ptNode == first_begin) {
			break;
		}
		ptNode = ptNode->next;
	}
	[*model1 prependPoint:end_pos Flag:0];
	[*model1 appendPoint:first_pos Flag:0];
	
	*model2 = [[PolygonModel alloc] init];
	ptNode = first_end;
	for (;;)
	{
		[*model2 appendPoint:ptNode->point Flag:ptNode->flag];
		if (ptNode == end_begin) {
			break;
		}
		ptNode = ptNode->next;
	}
	[*model2 prependPoint:first_pos Flag:0];
	[*model2 appendPoint:end_pos Flag:0];
	
	return SplitSuccess;
}

-(CGImageRef) getImage 
{
    CGSize s;
    if(UI_USER_INTERFACE_IDIOM()!= UIUserInterfaceIdiomPad)
        s = CGSizeMake(320, 480);
    else
        s = CGSizeMake(768, 1024); 
    
	CGRect r = CGRectMake(0.0f, 0.0f, s.width, s.height);
	
	CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceGray();
	CGContextRef context = CGBitmapContextCreate(nil, s.width, s.height, 8, 0, colorSpace, kCGImageAlphaNone);
	
	UIGraphicsPushContext(context);
	
	
	CGContextSetRGBFillColor(context, 0, 0, 0, 1);
	CGContextFillRect(context, r);
	
	CGContextSetRGBFillColor(context, 1, 1, 1, 1);
	CGContextBeginPath(context);
	SPointNode *ptNode = head;
	CGPoint pt = ptNode->point;
	CGContextMoveToPoint(context, pt.x, pt.y);
	for(;;)
	{
		SPointNode *nextNode = ptNode->next;
		CGPoint ptNext = nextNode->point;
		CGContextAddLineToPoint(context, ptNext.x, ptNext.y);
		if (ptNode == tail) {
			break;
		}
		ptNode = ptNode->next;
	}
	
	CGContextClosePath(context);
	CGContextFillPath(context); 
	
	UIGraphicsPopContext();
	
	CGImageRef maskCGImage = CGBitmapContextCreateImage(context);
	
	CGContextRelease(context);
	CGColorSpaceRelease(colorSpace);
	
	return maskCGImage;
}

-(CGImageRef) getImageWithSize : (CGSize) s
{
	CGSize winSize;
    if(UI_USER_INTERFACE_IDIOM()!= UIUserInterfaceIdiomPad)
        winSize = CGSizeMake(320, 480);
    else
        winSize = CGSizeMake(768, 1024); 
	CGFloat k_x = s.width / winSize.width;
	CGFloat k_y = s.height / winSize.height;
	CGRect r = CGRectMake(0.0f, 0.0f, s.width, s.height);
	
	CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceGray();
	CGContextRef context = CGBitmapContextCreate(nil, s.width, s.height, 8, 0, colorSpace, kCGImageAlphaNone);
	
	UIGraphicsPushContext(context);
	
	
	CGContextSetRGBFillColor(context, 0, 0, 0, 1);
	CGContextFillRect(context, r);
	
	CGContextSetRGBFillColor(context, 1, 1, 1, 1);
	CGContextBeginPath(context);
	SPointNode *ptNode = head;
	CGPoint pt = ptNode->point;
	pt.x *= k_x;
	pt.y *= k_y;
	
	CGContextMoveToPoint(context, pt.x, pt.y);
	for(;;)
	{
		SPointNode *nextNode = ptNode->next;
		CGPoint ptNext = nextNode->point;
		ptNext.x *= k_x;
		ptNext.y *= k_y;
		
		CGContextAddLineToPoint(context, ptNext.x, ptNext.y);
		if (ptNode == tail) {
			break;
		}
		ptNode = ptNode->next;
	}
	
	CGContextClosePath(context);
	CGContextFillPath(context); 
	
	UIGraphicsPopContext();
	
	CGImageRef maskCGImage = CGBitmapContextCreateImage(context);
	
	CGContextRelease(context);
	CGColorSpaceRelease(colorSpace);
	
	return maskCGImage;
	
}


-(CGImageRef) getMaskImage : (PolygonModel *)oldModel 
{
    CGSize s;
    if(UI_USER_INTERFACE_IDIOM()!= UIUserInterfaceIdiomPad)
        s = CGSizeMake(320, 480);
    else
        s = CGSizeMake(768, 1024); 

	CGRect r = CGRectMake(0.0f, 0.0f, s.width, s.height);
	
	CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceGray();
	CGContextRef context = CGBitmapContextCreate(nil, s.width, s.height, 8, 0, colorSpace, kCGImageAlphaNone);
	
	UIGraphicsPushContext(context);
	
	
	CGContextSetRGBFillColor(context, 0, 0, 0, 1);
	CGContextFillRect(context, r);
	
	CGContextSetRGBFillColor(context, 1, 1, 1, 1);
	CGContextBeginPath(context);
	SPointNode *ptNode = oldModel.head;
	CGPoint pt = ptNode->point;
	CGContextMoveToPoint(context, pt.x, pt.y);
	for(;;)
	{
		SPointNode *nextNode = ptNode->next;
		CGPoint ptNext = nextNode->point;
		CGContextAddLineToPoint(context, ptNext.x, ptNext.y);
		if (ptNode == oldModel.tail) {
			break;
		}
		ptNode = ptNode->next;
	}
	
	CGContextClosePath(context);
	CGContextFillPath(context); 
	
	CGContextSetRGBFillColor(context, 0, 0, 0, 1);
	CGContextBeginPath(context);
	ptNode = head;
	pt = ptNode->point;
	CGContextMoveToPoint(context, pt.x, pt.y);
	for(;;)
	{
		SPointNode *nextNode = ptNode->next;
		CGPoint ptNext = nextNode->point;
		CGContextAddLineToPoint(context, ptNext.x, ptNext.y);
		if (ptNode == tail) {
			break;
		}
		ptNode = ptNode->next;
	}
	
	CGContextClosePath(context);
	CGContextFillPath(context);
	
	UIGraphicsPopContext();
	
	CGImageRef maskCGImage = CGBitmapContextCreateImage(context);
	
	CGContextRelease(context);
	CGColorSpaceRelease(colorSpace);
	
	return maskCGImage;
}

-(int)		getTotalPixels
{  
    CGSize s;
    if(UI_USER_INTERFACE_IDIOM()!= UIUserInterfaceIdiomPad)
        s = CGSizeMake(320, 480);
    else
        s = CGSizeMake(768, 1024); 
	CGRect r = CGRectMake(0.0f, 0.0f, s.width, s.height);
	
	unsigned char * data = calloc(s.width * s.height, 1);
	CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceGray();
	CGContextRef context = CGBitmapContextCreate(data, s.width, s.height, 8, s.width, colorSpace, kCGImageAlphaNone);
	UIGraphicsPushContext(context);
	
	
	CGContextSetRGBFillColor(context, 0, 0, 0, 1);
	CGContextFillRect(context, r);
	
	CGContextSetRGBFillColor(context, 1, 1, 1, 1);
	
	CGContextBeginPath(context);
	SPointNode *ptNode = head;
	CGPoint pt = ptNode->point;
	CGContextMoveToPoint(context, pt.x, pt.y);
	for(;;)
	{
		SPointNode *nextNode = ptNode->next;
		CGPoint ptNext = nextNode->point;
		CGContextAddLineToPoint(context, ptNext.x, ptNext.y);
		if (ptNode == tail) {
			break;
		}
		ptNode = ptNode->next;
	}
	
	CGContextClosePath(context);
	CGContextFillPath(context);
	
	UIGraphicsPopContext();
	
	int white_pixels = 0;
	for (int i = 0; i < s.width * s.height; i++) {
		if (data[i]) 
			white_pixels++;
	}
	
	free(data);
	
	CGContextRelease(context);
	CGColorSpaceRelease(colorSpace);
	
	return white_pixels;
}

-(void) dealloc
{
	SPointNode *ptNode = head;
	for (;;)
	{
		SPointNode *next_node = ptNode->next;
		if (ptNode == tail)
		{
			free (ptNode);
			break;
		}
		free (ptNode);
		ptNode = next_node;
	}
	[super dealloc];
}

@end



