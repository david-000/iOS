//
//  ExtractFaceViewController.h
//  ExtractFace
//
//  Created by admin on 1/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

enum EditMode {
    DRAW_BOUND = 0,
    ERASER_REGION = 1
    };

@interface ExtractFaceViewController : UIViewController<UIActionSheetDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIPopoverControllerDelegate>
{
    UIPopoverController*	m_popoverController;    
    IBOutlet UIImageView*   m_pResultImageView;
    IBOutlet UILabel*       m_ctrlStatusLabel;
    NSMutableArray*         m_arrayBoundPoints;
    UIImage*                m_pOpenImage;
    UIImage*                m_pResultImage;
    UIImage*                m_pMaskImage;
    enum EditMode           m_nEditMode;
    BOOL                    m_fExtractedFace;
    CGSize                  m_xNewImageSize;
    BOOL                    mouseSwiped;
    CGPoint    lastPoint;
    int lineWidth;

}

@property (nonatomic, assign) UIImage*                m_pOpenImage;
@property (nonatomic, assign) UIImage*                m_pResultImage;
@property (nonatomic, assign) UIImage*                m_pMaskImage;

- (IBAction)onImportPhoto:(id)sender;
- (IBAction)onSaveResultImage:(id)sender;

- (IBAction)onSelectDrawMode:(id)sender;
- (UIImage*) maskImage:(UIImage *)image withMask:(UIImage *)pmaskImage; 
- (void)GoToManageUserImage:(UIImage*) pImage;
- (UIImage *)scaleAndRotateImage:(UIImage *)image;
- (void) loadFromCamera;
- (void) loadFromlibrary;

- (CGImageRef) getMaskImage;
- (CGSize) GetFrameSize:(UIImage*)pImage;

#pragma mark SavePhotAlbum Method

- (void)SaveAsImagePhotoAlbum;

@end
