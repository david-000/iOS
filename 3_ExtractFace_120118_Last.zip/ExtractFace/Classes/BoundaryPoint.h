//
//  BoundaryPoint.h
//  ExtractFace
//
//  Created by admin on 1/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BoundaryPoint : NSObject
{
    CGPoint m_xPoint;
    int m_nPointSize;
}

@property (nonatomic) CGPoint m_xPoint;
- (void) SetPoint:(CGPoint)xPoint size:(int) nPointSize;

@end
