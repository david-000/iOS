//
//  ExtractFaceViewController.m
//  ExtractFace
//
//  Created by admin on 1/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ExtractFaceViewController.h"
#import "ExtractFaceAppDelegate.h"
#import "BoundaryPoint.h"

@implementation ExtractFaceViewController

@synthesize m_pOpenImage;
@synthesize m_pResultImage;
@synthesize m_pMaskImage;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    [[self navigationController] setNavigationBarHidden:YES];
    
//  m_pResultImageView.contentMode = UIViewContentModeScaleAspectFill;
    m_fExtractedFace = NO;
    m_arrayBoundPoints = [[NSMutableArray alloc] init];
    m_pResultImage = nil;
    m_pOpenImage = nil;
    m_nEditMode = DRAW_BOUND;
    [m_ctrlStatusLabel setText:@"Please Take Photo."];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewDidAppear:(BOOL)animated
{
    [[self navigationController] setNavigationBarHidden:YES];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


-(void)dealloc
{
    [super dealloc];
    if(m_arrayBoundPoints)
    {
        [m_arrayBoundPoints removeAllObjects];
        [m_arrayBoundPoints release];
        m_arrayBoundPoints = nil;        
    }
    
    if(m_pOpenImage)
        [m_pOpenImage release];
    m_pOpenImage = nil;
    
    if(m_pResultImage)
        [m_pResultImage release];
    m_pResultImage = nil;
    
    if(m_pMaskImage)
        [m_pMaskImage release];
    m_pMaskImage = nil;
}

#pragma mark _ActionMethod_

-(IBAction)onImportPhoto:(id)sender
{
    if(m_arrayBoundPoints)
    {
        [m_arrayBoundPoints removeAllObjects];
//        [m_arrayBoundPoints release];
    }
    UIActionSheet* actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Take Snapshot",@"From the Album", nil];
    actionSheet.tag = 101;
    [actionSheet showInView:self.view];
}
-(IBAction)onSaveResultImage:(id)sender
{
   if(m_fExtractedFace == YES)    
       [self SaveAsImagePhotoAlbum];
}

- (IBAction)onSelectDrawMode:(id)sender
{
    if(m_nEditMode == DRAW_BOUND)
        m_nEditMode = ERASER_REGION;
    else
        m_nEditMode = DRAW_BOUND;
    if(m_arrayBoundPoints)
        [m_arrayBoundPoints removeAllObjects];
}

#pragma mark GetPhotoMethod
- (void) loadFromCamera
{
    UIImagePickerController* pickerController = [[[UIImagePickerController alloc] init] autorelease];
	pickerController.delegate = self;
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
		pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentModalViewController:pickerController animated:YES];
    }
    
}

- (void) loadFromlibrary
{
    UIImagePickerController* pickerController = [[[UIImagePickerController alloc] init] autorelease];
	pickerController.delegate = self;
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum]) {
		pickerController.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
		if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) 
		{
			if(m_popoverController != nil)
				[m_popoverController release];
			
			m_popoverController = [[UIPopoverController alloc] initWithContentViewController:pickerController] ;
			m_popoverController.delegate = self;
			[m_popoverController presentPopoverFromRect:CGRectMake(0, 0, 200, 800) 
												 inView:self.view
							   permittedArrowDirections:UIPopoverArrowDirectionAny 
											   animated:YES];
		}
		else {
            pickerController.wantsFullScreenLayout = YES;
			[self presentModalViewController:pickerController animated:YES];	
            
		}
		
    }
}

#pragma mark ActionSheetDelegate Method
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    NSInteger nTagIdx = actionSheet.tag;
    if(nTagIdx == 101)/*Load Photo*/
    {
        switch (buttonIndex) {
            case 0:
                [self loadFromCamera];
                break;
            case 1:
                [self loadFromlibrary];
                break;
            case 2:
                //                [self goToEditPhotoViewController:nil faceCount:0];
                break;
            case 3:
                break;
                
            default:
                break;
        }
    }
    else if(nTagIdx == 102)
    {
        
    }
    else if(nTagIdx == 103)/*Share Image file*/
    {
        switch (buttonIndex) {
            case 0:/*Save as Image*/
                [self SaveAsImagePhotoAlbum];
                break;
                
            default:
                break;
        }
    }
}

-(void)GoToManageUserImage:(UIImage *)pImage
{
    UIImage* pScaledImage = [self scaleAndRotateImage:pImage];
    if(m_pOpenImage)
        [m_pOpenImage release];
    m_pOpenImage = [[UIImage alloc] initWithCGImage:[pScaledImage CGImage]];
    [m_pResultImageView setImage:m_pOpenImage];
    [m_ctrlStatusLabel setText:@"Please Draw boundary of Face"];
    if(m_pMaskImage)
        [m_pMaskImage release];
    m_pMaskImage = nil;
    
    if(m_pResultImage)
        [m_pResultImage release];
    m_pResultImage = nil;
    m_nEditMode = DRAW_BOUND;
    m_fExtractedFace = NO;
}


- (UIImage *)scaleAndRotateImage:(UIImage *)image {
	int kMaxResolution = 480; // Or whatever
	
    CGImageRef imgRef = image.CGImage;
	
    CGFloat width = CGImageGetWidth(imgRef);
    CGFloat height = CGImageGetHeight(imgRef);
	
	
    CGAffineTransform transform = CGAffineTransformIdentity;
    CGRect bounds = CGRectMake(0, 0, width, height);
    if (width > kMaxResolution || height > kMaxResolution) {
        CGFloat ratio = width/height;
        if (ratio > 1) {
			bounds.size.width = kMaxResolution;
			bounds.size.height = bounds.size.width / ratio;
        }
        else {
			bounds.size.height = kMaxResolution;
			bounds.size.width = bounds.size.height * ratio;
        }
    }
	
    CGFloat scaleRatio = bounds.size.width / width;
    CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
    CGFloat boundHeight;
    UIImageOrientation orient = image.imageOrientation;
    switch(orient) {
			
        case UIImageOrientationUp: //EXIF = 1
			transform = CGAffineTransformIdentity;
			break;
			
        case UIImageOrientationUpMirrored: //EXIF = 2
			transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);
			transform = CGAffineTransformScale(transform, -1.0, 1.0);
			break;
			
        case UIImageOrientationDown: //EXIF = 3
			transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
			transform = CGAffineTransformRotate(transform, M_PI);
			break;
			
        case UIImageOrientationDownMirrored: //EXIF = 4
			transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
			transform = CGAffineTransformScale(transform, 1.0, -1.0);
			break;
			
        case UIImageOrientationLeftMirrored: //EXIF = 5
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width = boundHeight;
			transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
			transform = CGAffineTransformScale(transform, -1.0, 1.0);
			transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
			break;
			
        case UIImageOrientationLeft: //EXIF = 6
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width = boundHeight;
			transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
			transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
			break;
			
        case UIImageOrientationRightMirrored: //EXIF = 7
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width = boundHeight;
			transform = CGAffineTransformMakeScale(-1.0, 1.0);
			transform = CGAffineTransformRotate(transform, M_PI / 2.0);
			break;
			
        case UIImageOrientationRight: //EXIF = 8
			boundHeight = bounds.size.height;
			bounds.size.height = bounds.size.width;
			bounds.size.width = boundHeight;
			transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
			transform = CGAffineTransformRotate(transform, M_PI / 2.0);
			break;
			
        default:
			[NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];
			
    }
	
    UIGraphicsBeginImageContext(bounds.size);
	
    CGContextRef context = UIGraphicsGetCurrentContext();
	
    if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {
        CGContextScaleCTM(context, -scaleRatio, scaleRatio);
        CGContextTranslateCTM(context, -height, 0);
    }
    else {
        CGContextScaleCTM(context, scaleRatio, -scaleRatio);
        CGContextTranslateCTM(context, 0, -height);
    }
	
    CGContextConcatCTM(context, transform);
	
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
    UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
	
    return imageCopy;
}

#pragma mark -
#pragma mark UIImagePickerControllerDelegate

// this get called when an image has been chosen from the library or taken from the camera
//

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
	{
		if(m_popoverController != nil) 
        {
			[m_popoverController dismissPopoverAnimated:YES];
			m_popoverController = nil;
		}
        [self dismissModalViewControllerAnimated:YES];
	}
	else 
    {
        [self dismissModalViewControllerAnimated:YES];
    }
    
	[self GoToManageUserImage:image];
     
}
//- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
//{
//	}
//
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
	if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
	{
		if(m_popoverController != nil) {
			[m_popoverController dismissPopoverAnimated:YES];
			m_popoverController = nil;
		}
        else
            [self dismissModalViewControllerAnimated:YES];
	}
	else 
		[self dismissModalViewControllerAnimated:YES];
}

#pragma mark _SaveAsImage

- (void)SaveAsImagePhotoAlbum
{
    if(m_pResultImage)
         UIImageWriteToSavedPhotosAlbum(m_pResultImage, nil, nil, nil);
    else
        return;
}

-(CGImageRef) getMaskImage 
{
    CGSize s;
    if(UI_USER_INTERFACE_IDIOM()!= UIUserInterfaceIdiomPad)
        s = CGSizeMake(320, 480);
    else
        s = CGSizeMake(768, 1024); 
    
	CGRect r = CGRectMake(0.0f, 0.0f, s.width, s.height);
	
	CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceGray();
	CGContextRef context = CGBitmapContextCreate(nil, s.width, s.height, 8, 0, colorSpace, kCGImageAlphaNone);
	
	UIGraphicsPushContext(context);
	
	if(m_nEditMode == DRAW_BOUND)
    {
        CGContextSetRGBFillColor(context, 1, 1, 1, 1);
        CGContextFillRect(context, r);
        
        CGContextSetRGBFillColor(context, 0, 0, 0, 1);
        CGContextBeginPath(context);
        BoundaryPoint* pxFirstPos = [m_arrayBoundPoints objectAtIndex:0];
        CGPoint xFirstPos = pxFirstPos.m_xPoint;
        CGContextMoveToPoint(context, xFirstPos.x, s.height - xFirstPos.y);
        
        for (BoundaryPoint* pxPoint in m_arrayBoundPoints ) {
            CGPoint xPoint = pxPoint.m_xPoint;
            CGContextAddLineToPoint(context, xPoint.x, s.height - xPoint.y);
        }
        CGContextClosePath(context);
        CGContextFillPath(context); 

    }
	else
    {
        CGContextSetRGBFillColor(context, 0, 0, 0, 1);
        CGContextFillRect(context, r);
    
        CGContextDrawImage(context, r, [m_pMaskImage CGImage]);        
        CGContextSetRGBFillColor(context, 1, 1, 1, 1);
        CGContextBeginPath(context);
        CGContextSetLineWidth(context, 15);
        BoundaryPoint* pxFirstPos = [m_arrayBoundPoints objectAtIndex:0];
        CGPoint xFirstPos = pxFirstPos.m_xPoint;
        CGContextMoveToPoint(context, xFirstPos.x, s.height - xFirstPos.y);
        
        for (BoundaryPoint* pxPoint in m_arrayBoundPoints ) {
            CGPoint xPoint = pxPoint.m_xPoint;
            CGContextAddLineToPoint(context, xPoint.x, s.height - xPoint.y);
        }
//        CGContextClosePath(context);
        CGContextFillPath(context); 

    }

	UIGraphicsPopContext();
	
	CGImageRef maskCGImage = CGBitmapContextCreateImage(context);
	
	CGContextRelease(context);
	CGColorSpaceRelease(colorSpace);
	
	return maskCGImage;
}


-(UIImage*) maskImage:(UIImage *)image withMask:(UIImage *)pmaskImage {
    
    CGImageRef maskRef = [pmaskImage CGImage]; 
    
    CGImageRef mask = CGImageMaskCreate(CGImageGetWidth(maskRef),
                                        CGImageGetHeight(maskRef),
                                        CGImageGetBitsPerComponent(maskRef),
                                        CGImageGetBitsPerPixel(maskRef),
                                        CGImageGetBytesPerRow(maskRef),
                                        CGImageGetDataProvider(maskRef), NULL, false);
    
    CGImageRef masked = CGImageCreateWithMask([image CGImage], mask);
    CGImageRelease(mask);
    return [UIImage imageWithCGImage:masked];
    
}
  
- (CGSize) GetFrameSize:(UIImage*)pImage
{
    CGSize xNewSize;
    CGSize xCurSize = pImage.size;
    int nWidth, nHeight;
    if(UI_USER_INTERFACE_IDIOM() != UIUserInterfaceIdiomPad)
    {
        nWidth = 320;
        nHeight = 480;
    }
    else
    {
        nWidth = 768;
        nHeight = 1024;
    }
        
    if (xCurSize.width >= xCurSize.height)
    {
        xNewSize.width = nWidth;
        xNewSize.height = nHeight * xCurSize.height/(CGFloat)nWidth;        
    }
    else
    {
        xNewSize.height = nHeight;
        xNewSize.width = nWidth * xCurSize.width/(CGFloat)nHeight;
    }
    
    return xNewSize;
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    if(m_nEditMode == DRAW_BOUND && m_fExtractedFace == YES)
        return;
    if(m_arrayBoundPoints)
        [m_arrayBoundPoints removeAllObjects];
    mouseSwiped = NO;
    UITouch *touch = [touches anyObject];
    if(m_nEditMode == DRAW_BOUND)
        lineWidth = 5;
    else
        lineWidth = 15;
    
    lastPoint = [touch locationInView:self.view];
    BoundaryPoint* xTempPoint = [[BoundaryPoint alloc] init];
    [xTempPoint SetPoint:lastPoint size:lineWidth];
    if(m_arrayBoundPoints == nil)
        return;
    [m_arrayBoundPoints addObject:xTempPoint];
    [xTempPoint release];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    if(m_nEditMode == DRAW_BOUND && m_fExtractedFace == YES)
        return;
    mouseSwiped = YES;
    
    UITouch *touch = [touches anyObject];   
    CGPoint currentPoint = [touch locationInView:self.view];
    
    BoundaryPoint* pTempPos = [[BoundaryPoint alloc] init];
    [pTempPos SetPoint:currentPoint size:lineWidth];
    if(m_arrayBoundPoints == nil)
        return;
    [m_arrayBoundPoints addObject:pTempPos];
    [pTempPos release];
    
    UIGraphicsBeginImageContext(self.view.frame.size);
    [m_pResultImageView.image drawInRect:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];

    CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
    CGContextSetLineWidth(UIGraphicsGetCurrentContext(), lineWidth);
    
    CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(),1.0, 1.0, 1.0, 1.0);
    CGContextBeginPath(UIGraphicsGetCurrentContext());
    CGContextMoveToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y);
    CGContextAddLineToPoint(UIGraphicsGetCurrentContext(), currentPoint.x, currentPoint.y);
    CGContextStrokePath(UIGraphicsGetCurrentContext());
    m_pResultImageView.image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    lastPoint = currentPoint;
}



- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    if(m_nEditMode == DRAW_BOUND && m_fExtractedFace == YES)
        return;
//    UITouch *touch = [touches anyObject];
    mouseSwiped = NO;
    if(!mouseSwiped) 
    {
        if(m_nEditMode == DRAW_BOUND)
        {
            UIGraphicsBeginImageContext(self.view.frame.size);
            [m_pResultImageView.image drawInRect:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
            
            CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
            CGContextSetLineWidth(UIGraphicsGetCurrentContext(), lineWidth);
            CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), 1.0, 0.0, 0.0, 1.0);
            CGContextMoveToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y);
            CGContextAddLineToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y);
            CGContextStrokePath(UIGraphicsGetCurrentContext());
            CGContextClosePath(UIGraphicsGetCurrentContext());
            CGContextFillPath(UIGraphicsGetCurrentContext());
            CGContextFlush(UIGraphicsGetCurrentContext());
            m_pResultImageView.image = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
            CGImageRef xMaskRef = [self getMaskImage];
            if(m_pMaskImage)
                [m_pMaskImage release];
            m_pMaskImage = [[UIImage alloc] initWithCGImage:xMaskRef];
            
            UIImage* pFaceImage = [self maskImage:m_pOpenImage withMask:m_pMaskImage];
            if(m_pResultImage)
                [m_pResultImage release];
            m_pResultImage = [[UIImage alloc] initWithCGImage:[pFaceImage CGImage]];
            m_fExtractedFace = YES;
            m_nEditMode = ERASER_REGION;
            [m_pResultImageView setImage:m_pResultImage];
            [m_ctrlStatusLabel setText:@"Please Eraser Face Region"];
        }
        else
        {
            UIGraphicsBeginImageContext(self.view.frame.size);
            [m_pResultImageView.image drawInRect:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
            
            CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
            CGContextSetLineWidth(UIGraphicsGetCurrentContext(), lineWidth);
            CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), 1.0, 0.0, 0.0, 1.0);
            CGContextMoveToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y);
            CGContextAddLineToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y);
            CGContextStrokePath(UIGraphicsGetCurrentContext());
            CGContextClosePath(UIGraphicsGetCurrentContext());
            CGContextFillPath(UIGraphicsGetCurrentContext());
            CGContextFlush(UIGraphicsGetCurrentContext());
            m_pResultImageView.image = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
            CGImageRef xMaskRef = [self getMaskImage];
            if(m_pMaskImage)
                [m_pMaskImage release];
            m_pMaskImage = [[UIImage alloc] initWithCGImage:xMaskRef];
            UIImage* pFaceImage = [self maskImage:m_pOpenImage withMask:m_pMaskImage];
            if(m_pResultImage)
                [m_pResultImage release];
            m_pResultImage = [[UIImage alloc] initWithCGImage:[pFaceImage CGImage]];
            m_fExtractedFace = YES;
            [m_pResultImageView setImage:m_pResultImage];


        }
                
  
    
//        UIImageWriteToSavedPhotosAlbum(pImage, nil, nil, nil);
    }
    
}

@end
