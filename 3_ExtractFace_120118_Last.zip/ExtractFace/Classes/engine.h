//
//  engine.h
//  MySlash
//
//  Created by Kim Jong Chol on 3/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#ifndef _engine_h
#define _engine_h

#import <Foundation/Foundation.h>

typedef struct
{
	CGPoint sp;
	CGPoint ep;
}SLine;

CGFloat getMaxXLine(SLine line);
CGFloat getMinXLine(SLine line);
CGFloat getMaxYLine(SLine line);
CGFloat getMinYLine(SLine line);

CGPoint	getIntersectPos(SLine l1, SLine l2);
CGPoint	getAandB (SLine	line);

CGFloat getAngleFromTwoPoint(CGPoint ptFarCenter , CGPoint ptNearCenter);

CGPoint	ccp_dec(CGPoint pt1, CGPoint pt2);
CGImageRef	getAlphaImageWithCGImage(CGImageRef src_img);
CGImageRef getImageFormJPEGFile(const char *filename);

void	randomize();

typedef enum
{
	SplitFail,
	SplitSuccess,
	SplitBreak,
}SplitResult;

typedef struct
{
	CGPoint		point;
	int			flag;
	void		*next;
}SPointNode;

typedef struct 
{
	int		index;
	int		count;
}SPointDataInfo;

typedef struct
{
	float x;
	float y;
	int	  f;
}SPointData;


@interface PolygonModel : NSObject 
{
	SPointNode	*head;
	SPointNode	*tail;
	
	CGFloat		bound[4];
}


@property SPointNode	*head;
@property SPointNode	*tail;

-(id) initWithIndex:(int)ix Scale:(CGPoint)sp;
-(id) initWithModel : (PolygonModel *)model;

-(void)	appendPoint:(CGPoint)pt Flag:(int)f;
-(void) prependPoint:(CGPoint)pt Flag:(int)f;

-(CGRect)	boundRect;

-(BOOL)		isContainPoint:(CGPoint) pt;
-(CGPoint) getFirstIntersectPos : (SLine)cut_line intersectLine:(SLine *)i_l;

-(SplitResult)	splitByLine:(SLine) cut_line Model1:(PolygonModel **)model1 Model2:(PolygonModel **)model2;

-(CGImageRef) getImage;
-(CGImageRef) getImageWithSize : (CGSize) s;
-(CGImageRef) getMaskImage : (PolygonModel *)oldModel ;

-(int)		getTotalPixels;

@end
							 
#endif



