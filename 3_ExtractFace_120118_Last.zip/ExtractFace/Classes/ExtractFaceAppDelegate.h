//
//  ExtractFaceAppDelegate.h
//  ExtractFace
//
//  Created by admin on 1/17/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#define THUMB_SIZE 72
@class ExtractFaceViewController;

@interface ExtractFaceAppDelegate : NSObject <UIApplicationDelegate, UINavigationControllerDelegate> {
    UIWindow *window;
    IBOutlet UINavigationController* navigationController;
    IBOutlet ExtractFaceViewController* viewController;
    
    BOOL                    m_fComplatedEditing;
    
    UIImage*                m_pOrgImage;
    UIImage*                m_pResultImage;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ExtractFaceViewController *viewController;
@property (nonatomic, assign) IBOutlet UINavigationController	*navigationController;

@property (nonatomic)         BOOL  m_fComplatedEditing;


@end

