//
//  PDFCache.h
//  MyPDFReader
//
//  Created by Admin on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol PDFViewDataSource;

@interface PDFCache : NSObject {
	NSMutableDictionary *pageCache;
	id <PDFViewDataSource> dataSource;
	NSInteger pageCount;
	CGSize pageSize;
}

@property (assign) CGSize pageSize;
@property (assign) id <PDFViewDataSource> dataSource;

- (id) initWithPageSize:(CGSize)aPageSize;
- (CGImageRef) cachedImageForPageIndex:(NSUInteger)pageIndex;
- (void) precacheImageForPageIndex:(NSUInteger)pageIndex;
- (void) minimizeToPageIndex:(NSUInteger)pageIndex;
- (void) flush;

@end
