//
//  PDFView.m
//  MyPDFReader
//
//  Created by Admin on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PDFView.h"
#import "PDFCache.h"
#import "MerzAppDelegate.h"
#import "PDFViewController.h"

@implementation PDFView

@synthesize dataSource, delegate;
@synthesize leafEdge, currentPageIndex, chapterNumber;
@synthesize interactionLocked;

#pragma mark Layer initializing methods
- (void) setUpLayers {
	self.clipsToBounds = YES;

	topPage = [[CALayer alloc] init];
	topPage.masksToBounds = YES;
	topPage.contentsGravity = kCAGravityLeft;
	topPage.backgroundColor = [[UIColor whiteColor] CGColor];

	topPageRight = [[CALayer alloc] init];
	topPageRight.masksToBounds = YES;
	topPageRight.contentsGravity = kCAGravityLeft;
	topPageRight.backgroundColor = [[UIColor whiteColor] CGColor];

	topPageOverlay = [[CALayer alloc] init];
	topPageOverlay.backgroundColor = [[[UIColor blackColor] colorWithAlphaComponent:0.2] CGColor];

	topPageShadow = [[CAGradientLayer alloc] init];
	topPageShadow.colors = [NSArray arrayWithObjects:
							(id)[[[UIColor blackColor] colorWithAlphaComponent:0.6] CGColor],
							(id)[[UIColor clearColor] CGColor],
							nil];
	topPageShadow.startPoint = CGPointMake(1,0.5);
	topPageShadow.endPoint = CGPointMake(0,0.5);

	topPageReverse = [[CALayer alloc] init];
	topPageReverse.backgroundColor = [[UIColor whiteColor] CGColor];
	topPageReverse.masksToBounds = YES;

	topPageReverseImage = [[CALayer alloc] init];
	topPageReverseImage.masksToBounds = YES;
	topPageReverseImage.contentsGravity = kCAGravityRight;

	topPageReverseOverlay = [[CALayer alloc] init];
	topPageReverseOverlay.backgroundColor = [[[UIColor whiteColor] colorWithAlphaComponent:0.8] CGColor];

	topPageReverseShading = [[CAGradientLayer alloc] init];
	topPageReverseShading.colors = [NSArray arrayWithObjects:
									(id)[[[UIColor blackColor] colorWithAlphaComponent:0.6] CGColor],
									(id)[[UIColor clearColor] CGColor],
									nil];
	topPageReverseShading.startPoint = CGPointMake(1,0.5);
	topPageReverseShading.endPoint = CGPointMake(0,0.5);

	bottomPage = [[CALayer alloc] init];
	bottomPage.backgroundColor = [[UIColor whiteColor] CGColor];
	bottomPage.masksToBounds = YES;
	bottomPage.contentsGravity = kCAGravityLeft;

	bottomPageRight = [[CALayer alloc] init];
	bottomPageRight.backgroundColor = [[UIColor whiteColor] CGColor];
	bottomPageRight.masksToBounds = YES;

	bottomPageShadow = [[CAGradientLayer alloc] init];
	bottomPageShadow.colors = [NSArray arrayWithObjects:
							   (id)[[[UIColor blackColor] colorWithAlphaComponent:0.6] CGColor], 
							   (id)[[UIColor clearColor] CGColor],
							   nil];
	bottomPageShadow.startPoint = CGPointMake(0,0.5);
	bottomPageShadow.endPoint = CGPointMake(1,0.5);

	[topPage addSublayer:topPageRight];
	[bottomPage addSublayer:bottomPageRight];
	[topPage addSublayer:topPageShadow];
//	[topPage addSublayer:topPageOverlay];
	[topPageReverse addSublayer:topPageReverseImage];
	[topPageReverse addSublayer:topPageReverseOverlay];
	[topPageReverse addSublayer:topPageReverseShading];
	[bottomPage addSublayer:bottomPageShadow];
	[self.layer addSublayer:bottomPage];
	[self.layer addSublayer:topPage];
	[self.layer addSublayer:topPageReverse];
	
	self.leafEdge = 1.0;
}

- (void) initialize {
	pageCache = [[PDFCache alloc] initWithPageSize:self.bounds.size];
	currentTouchInfo = TOUCHED_NONE;
	interactionLocked = NO;
	[self orientationWillRotate:orientationIsPortrait];
}

- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
		MerzAppDelegate *appDelegate = (MerzAppDelegate*)[UIApplication sharedApplication].delegate;
		UIViewController *controller = (UIViewController*)appDelegate.viewController;
		orientationIsPortrait = UIInterfaceOrientationIsPortrait(controller.interfaceOrientation);
		[self setUpLayers];
		[self initialize];
    }
    return self;
}

- (void) reloadData {
	[pageCache flush];
	numberOfPages = [pageCache.dataSource numberOfPagesInPDF];
}

#pragma mark accessors

- (id<PDFViewDataSource>) dataSource {
	return pageCache.dataSource;
	
}

- (void) setDataSource:(id<PDFViewDataSource>)value {
	pageCache.dataSource = value;
}

- (void) setLeafEdge:(CGFloat)aLeafEdge {
	leafEdge = aLeafEdge;

//	[CATransaction begin];
//	[CATransaction setValue:(id)kCFBooleanTrue
//					 forKey:kCATransactionDisableActions];
	[self setLayerFrames];
//	[CATransaction commit];
	topPageReverse.opacity = 1.0f;
	topPageShadow.opacity = MIN(1.0, 4*(1-leafEdge));
	bottomPageShadow.opacity = MIN(1.0, 4*leafEdge);
	if (orientationIsPortrait || currentTouchInfo == TOUCHED_NEXTPAGE) {
		topPageOverlay.opacity = MIN(1.0, 4*(1-leafEdge));
	}
	else {
		topPageOverlay.opacity = MIN(1.0, 4*(0.5-leafEdge));
	}
}

- (void) setCurrentPageIndex:(NSUInteger)aCurrentPageIndex {
	currentPageIndex = aCurrentPageIndex;
	
	[CATransaction begin];
	[CATransaction setValue:(id)kCFBooleanTrue
					 forKey:kCATransactionDisableActions];
	
	[self getImages];
	
	self.leafEdge = 1.0;
	
	[CATransaction commit];
}

#pragma mark Page turning methods
- (void) willTurnToPageAtIndex:(NSUInteger)index {
	if ([delegate respondsToSelector:@selector(pdfView:willTurnToPageAtIndex:)])
		[delegate pdfView:self willTurnToPageAtIndex:index];
}

- (void) didTurnToPageAtIndex:(NSUInteger)index {
	if ([delegate respondsToSelector:@selector(pdfView:didTurnToPageAtIndex:)])
		[delegate pdfView:self didTurnToPageAtIndex:index];
}

- (void) didTurnPageBackward {
	if (!orientationIsPortrait) {
		CATransition *fadeAnimation = [CATransition animation];
		[fadeAnimation setDuration:0.25f];
		topPageReverse.opacity = 0.0f;
		topPageShadow.opacity = 0.0f;
		bottomPageShadow.opacity = 0.0f;
		topPageOverlay.opacity = 0.0f;
		[self.layer addAnimation:fadeAnimation forKey:@"fadeAnim"];
	}

	interactionLocked = NO;
	[self didTurnToPageAtIndex:currentPageIndex];
}

- (void) didTurnPageForward {
	if (!orientationIsPortrait) {
		CATransition *fadeAnimation = [CATransition animation];
		[fadeAnimation setDuration:0.25f];
		topPageReverse.opacity = 0.0f;
		topPageShadow.opacity = 0.0f;
		bottomPageShadow.opacity = 0.0f;
		topPageOverlay.opacity = 0.0f;
		[self.layer addAnimation:fadeAnimation forKey:@"fadeAnim"];
	}

	interactionLocked = NO;

	self.currentPageIndex = self.currentPageIndex + pageStep;
	[self didTurnToPageAtIndex:currentPageIndex];
}

#pragma mark Page checking methods
- (BOOL) hasPrevPage {
	return self.currentPageIndex > 0;
}

- (BOOL) hasNextPage {
	if (chapterNumber < 7) {
		if (orientationIsPortrait) {
			return self.currentPageIndex < numberOfPages - 1;
		}
		else {
			return self.currentPageIndex < numberOfPages - 2;
		}
	}
	else {
		if (orientationIsPortrait) {
			return self.currentPageIndex < numberOfPages;
		}
		else {
			return self.currentPageIndex < numberOfPages;
		}
	}
}

- (BOOL) touchedNextPage {
	return CGRectContainsPoint(nextPageRect, touchBeganPoint);
}

- (BOOL) touchedPrevPage {
	return CGRectContainsPoint(prevPageRect, touchBeganPoint);
}

- (void) updateTargetRects {
	CGFloat targetWidth = MAX(28, self.bounds.size.width / 5);
	nextPageRect = CGRectMake(self.bounds.size.width - targetWidth,
							  0,
							  targetWidth,
							  self.bounds.size.height);
	prevPageRect = CGRectMake(0,
							  0,
							  targetWidth,
							  self.bounds.size.height);
}

#pragma mark touchEvent methods

- (void)enableScroll:(BOOL)bEnable
{
	PDFViewController *controller = (PDFViewController *)delegate;
	[controller enableScroll:bEnable];
}

- (void)enableZoom:(BOOL)bEnable
{
	PDFViewController *controller = (PDFViewController *)delegate;
	[controller enableZoom:bEnable];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	currentTouchInfo = TOUCHED_NONE;
	if (interactionLocked || [touches count] > 1)
		return;

	UITouch *touch = [touches anyObject];
	touchBeganPoint = [touch locationInView:self];
	
	if ([self touchedPrevPage] && [self hasPrevPage]) {
		currentTouchInfo = TOUCHED_PREVPAGE;
		[CATransaction begin];
		[CATransaction setValue:(id)kCFBooleanTrue
						 forKey:kCATransactionDisableActions];
		if (!orientationIsPortrait) {
			topPageReverseImage.contents = (id)[pageCache cachedImageForPageIndex:currentPageIndex-1];
		}

		self.currentPageIndex = self.currentPageIndex - pageStep;

		self.leafEdge = 0.0;
		[CATransaction commit];
		[self enableZoom:NO];
		[self enableScroll:NO];
	} 
	else if ([self touchedNextPage] && [self hasNextPage]) {
		currentTouchInfo = TOUCHED_NEXTPAGE;
		if (!orientationIsPortrait) {
			topPageReverseImage.contents = (id)[pageCache cachedImageForPageIndex:currentPageIndex+2];
		}
		[CATransaction begin];
		[CATransaction setValue:(id)kCFBooleanTrue
						 forKey:kCATransactionDisableActions];
		self.leafEdge = 1.0;
		[CATransaction commit];
		[self enableZoom:NO];
		[self enableScroll:NO];
	}
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	if (currentTouchInfo == TOUCHED_NONE)
		return;
	UITouch *touch = [touches anyObject];
	CGPoint touchPoint = [touch locationInView:self];
	
	[CATransaction begin];
	[CATransaction setValue:[NSNumber numberWithFloat:0.07]
					 forKey:kCATransactionAnimationDuration];

	CGFloat temp = touchPoint.x / self.bounds.size.width;
	if (!orientationIsPortrait) {
		if (currentTouchInfo == TOUCHED_NEXTPAGE) temp = MAX(temp, 0.4999f);
		else temp = MIN(temp, 0.5001f);
	}
	
	self.leafEdge = temp;
	[CATransaction commit];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch *touch = [touches anyObject];
	if ([touch tapCount] == 2) {
		UIScrollView *parent = (UIScrollView *)[self superview];
		[parent setZoomScale:1.0f];
		self.center = parent.center;
		interactionLocked = NO;
	}
	if (currentTouchInfo == TOUCHED_NONE)
		return;
	
	[CATransaction begin];
	float duration = 0.25;
	if (self.leafEdge < 0.5) {
		[self willTurnToPageAtIndex:currentPageIndex+pageStep];
		if (orientationIsPortrait || currentTouchInfo == TOUCHED_PREVPAGE) {
			self.leafEdge = 0;
		}
		
		interactionLocked = YES;
		[self performSelector:@selector(didTurnPageForward)
				   withObject:nil 
				   afterDelay:duration + 0.1];
	}
	else {
		[self willTurnToPageAtIndex:currentPageIndex];
		if (orientationIsPortrait || currentTouchInfo == TOUCHED_NEXTPAGE) {
			self.leafEdge = 1.0;
		}
		else {
			topPage.frame = self.layer.bounds;
			bottomPage.frame = self.layer.bounds;
		}
		interactionLocked = YES;
		[self performSelector:@selector(didTurnPageBackward)
				   withObject:nil 
				   afterDelay:duration + 0.1];
	}
	[CATransaction setValue:[NSNumber numberWithFloat:duration]
					 forKey:kCATransactionAnimationDuration];
	[CATransaction commit];

	[self enableZoom:YES];
	[self enableScroll:YES];
}

#pragma mark Layer updating methods
// positioning layers
- (void) setLayerFrames {
	topPage.frame = CGRectMake(self.layer.bounds.origin.x, 
							   self.layer.bounds.origin.y, 
							   leafEdge * self.layer.bounds.size.width, 
							   self.layer.bounds.size.height);
	bottomPage.frame = self.layer.bounds;

	topPageReverseImage.contentsGravity = kCAGravityRight;

	// page flip direction
	if (orientationIsPortrait || currentTouchInfo == TOUCHED_NEXTPAGE) {
		topPageReverse.frame = CGRectMake(self.layer.bounds.origin.x + (2*leafEdge-1) * self.bounds.size.width, 
										  self.layer.bounds.origin.y, 
										  (1-leafEdge) * self.layer.bounds.size.width, 
										  self.layer.bounds.size.height);
		topPageReverseImage.frame = topPageReverse.bounds;
		topPageReverseShading.colors = [NSArray arrayWithObjects:
										(id)[[[UIColor blackColor] colorWithAlphaComponent:0.6] CGColor],
										(id)[[UIColor clearColor] CGColor],
										nil];
		topPageReverseShading.frame = CGRectMake(topPageReverse.bounds.size.width - 50, 
												 0, 
												 50 + 1, 
												 topPageReverse.bounds.size.height);
	}
	else {
		topPageReverse.frame = CGRectMake(self.layer.bounds.origin.x + (leafEdge) * self.bounds.size.width, 
										  self.layer.bounds.origin.y, 
										  (leafEdge) * self.bounds.size.width, 
										  self.layer.bounds.size.height);
		topPageReverseImage.frame = topPageReverse.bounds;
		topPageReverseShading.colors = [NSArray arrayWithObjects:
										(id)[[UIColor clearColor] CGColor],
										(id)[[[UIColor blackColor] colorWithAlphaComponent:0.6] CGColor],
										nil];
		topPageReverseShading.frame = CGRectMake(0, 
												 0, 
												 50 + 1, 
												 topPageReverse.bounds.size.height);
	}

	// single or double
	// and topPageReverse is transparent or opaque
	if (orientationIsPortrait) {
		topPageReverseOverlay.hidden = NO;
		topPageReverseOverlay.frame = topPageReverse.bounds;
		topPageReverseImage.transform = CATransform3DMakeScale(-1, 1, 1);
	}
	else {
		if (currentTouchInfo == TOUCHED_NEXTPAGE) {
			topPageReverseImage.contentsGravity = kCAGravityLeft;
		}
		topPageReverseOverlay.hidden = YES;
		topPageReverseImage.transform = CATransform3DIdentity;
		topPageRight.frame = CGRectMake(self.layer.bounds.size.width/2, 
										self.layer.bounds.origin.y, 
										self.layer.bounds.size.width/2, 
										self.layer.bounds.size.height);
		bottomPageRight.frame = topPageRight.frame;
	}

	CGFloat shadowWidth = MIN(40, topPageReverse.frame.size.width);
	topPageShadow.frame = CGRectMake(topPageReverse.frame.origin.x - shadowWidth, 
									 0, shadowWidth, 
									 bottomPage.bounds.size.height);
	bottomPageShadow.frame = CGRectMake(leafEdge * self.bounds.size.width-1,
										0,
										MIN(40, topPage.frame.size.width), 
										bottomPage.bounds.size.height);
	topPageOverlay.frame = topPage.bounds;
}

// set contents of layers
- (void) getImages {
	if (currentPageIndex < numberOfPages) {
		//		[pageCache precacheImageForPageIndex:currentPageIndex-1];
		topPage.contents = (id)[pageCache cachedImageForPageIndex:currentPageIndex];
		if (orientationIsPortrait) {
			topPageReverseImage.contents = (id)[pageCache cachedImageForPageIndex:currentPageIndex];
			bottomPage.contents = (id)[pageCache cachedImageForPageIndex:currentPageIndex + 1];
		}
		else {
			topPageRight.contents = (id)[pageCache cachedImageForPageIndex:currentPageIndex + 1];
			bottomPage.contents = (id)[pageCache cachedImageForPageIndex:currentPageIndex + 2];
			bottomPageRight.contents = (id)[pageCache cachedImageForPageIndex:currentPageIndex + 3];
		}
		[pageCache minimizeToPageIndex:currentPageIndex];
	} else {
		topPage.contents = nil;
		topPageRight.contents = nil;
		topPageReverseImage.contents = nil;
		bottomPage.contents = nil;
		bottomPageRight.contents = nil;
	}
}

- (void) layoutSubviews {
	[super layoutSubviews];

	CGSize boundSize = self.bounds.size;
	if (!orientationIsPortrait) {
		boundSize = CGSizeMake(self.bounds.size.width/2, self.bounds.size.height);
	}
	if (!CGSizeEqualToSize(pageSize, boundSize)) {
		pageSize = boundSize;
		
		[CATransaction begin];
		[CATransaction setValue:(id)kCFBooleanTrue
						 forKey:kCATransactionDisableActions];
		[self setLayerFrames];
		[CATransaction commit];
		pageCache.pageSize = boundSize;
		[self getImages];
		[self updateTargetRects];
	}
}

#pragma mark orientation methods
- (void)orientationWillRotate:(BOOL)isPortrait
{
	orientationIsPortrait = isPortrait;
	if (orientationIsPortrait) {
		self.leafEdge = 1.0f;
		topPageRight.hidden = YES;
		bottomPageRight.hidden = YES;
		pageStep = 1;
	}
	else {
		topPageRight.hidden = NO;
		bottomPageRight.hidden = NO;
		pageStep = 2;
		// current page is always odd in landscape
		if (currentPageIndex % 2) {
			[CATransaction begin];
			[CATransaction setValue:(id)kCFBooleanTrue
							 forKey:kCATransactionDisableActions];
			self.currentPageIndex = self.currentPageIndex-1;
			[CATransaction commit];
			[delegate pdfView:self willTurnToPageAtIndex:self.currentPageIndex];
		}
	}
	interactionLocked = NO;
}

#pragma mark free methods

- (void)dealloc {
	[topPage release];
	[topPageRight release];
	[topPageShadow release];
	[topPageOverlay release];
	[topPageReverse release];
	[topPageReverseImage release];
	[topPageReverseOverlay release];
	[topPageReverseShading release];
	[bottomPage release];
	[bottomPageRight release];
	[bottomPageShadow release];
	
	[pageCache release];

    [super dealloc];
}


@end
