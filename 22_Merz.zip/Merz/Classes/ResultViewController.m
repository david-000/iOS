    //
//  ResultViewController.m
//  Merz
//
//  Created by SongGumChol on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ResultViewController.h"
#import "defines.h"
#import "MerzAppDelegate.h"
#import "DocumentEntry.h"


@implementation ResultViewController

@synthesize imageView;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    	navBar = [[UINavigationBar alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 44.0f)];
		navBar.barStyle = UIBarStyleBlackOpaque;
		navBar.tintColor = [UIColor colorWithRed:191.0 / 255.0 green:144.0 / 255.0 blue:90.0 / 255.0 alpha:1.0];
		UINavigationItem *navItem = [[UINavigationItem alloc] init];
		navItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:BACKBUTTON_TITLE style:UIBarButtonItemStyleBordered target:self action:@selector(goBack)];
		[navBar pushNavigationItem:navItem animated:YES];
		[navItem release];
		[self.view addSubview:navBar];

		titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.view.frame.size.width / 2 - 250.0f, 80.0f, 500.0f, 50.0f)];
		titleLabel.font = [UIFont systemFontOfSize:32.0f];
		titleLabel.textAlignment = UITextAlignmentCenter;
		titleLabel.text = RESULT_TITLE;
		titleLabel.textColor = [UIColor whiteColor];
		titleLabel.backgroundColor = [UIColor clearColor];
		[self.view addSubview:titleLabel];
		
		MerzAppDelegate *delegate = (MerzAppDelegate *)[[UIApplication sharedApplication] delegate];
		NSArray *array = delegate.docEntryArray;

		NSArray *labelArray = [[NSArray alloc] initWithObjects:
							   [[UILabel alloc] init], [[UILabel alloc] init], [[UILabel alloc] init],
							   [[UILabel alloc] init], [[UILabel alloc] init], [[UILabel alloc] init], nil];
		
		for (int i = 0; i < [labelArray count]; i++) {
			NSDictionary *dictionary = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"evaluation" ofType:@"plist"]];
			MerzAppDelegate *delegate = (MerzAppDelegate *)[[UIApplication sharedApplication] delegate];
			
			NSDictionary *entryDictionary = (NSDictionary *)[dictionary objectForKey:(NSString *)[delegate.keyArray objectAtIndex:i]];
			
			UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(60.0f, 200.0f + i * 40.0f, 200.0f, 30.0f)];
			nameLabel.text = (NSString *)[entryDictionary objectForKey:@"title"];
			nameLabel.textColor = [UIColor whiteColor];
			nameLabel.font = [UIFont systemFontOfSize:20.0f];
			nameLabel.backgroundColor = [UIColor clearColor];
			[self.view addSubview:nameLabel];
			[nameLabel release];
			
			UILabel *label = [labelArray objectAtIndex:i];
			label.frame = CGRectMake(250.0f, 200.0f + i * 40.0f, 400.0f, 30.0f);
			label.textColor = [UIColor whiteColor];
			label.font = [UIFont systemFontOfSize:20.0f];
			label.backgroundColor = [UIColor clearColor];
			
			DocumentEntry *entry = [array objectAtIndex:i];
			if (entry.numCorrectAnswers == 0)
				label.text = [NSString stringWithFormat:RESULT_NOT_TAKEN];
			else if (entry.numCorrectAnswers >= 14)
				label.text = [NSString stringWithFormat:RESULT_EVALUATED_SUCCESS, entry.numCorrectAnswers];
			else
				label.text = [NSString stringWithFormat:RESULT_EVALUATED_FAIL, entry.numCorrectAnswers];
			
			[self.view addSubview:label];
			[label release];
//			[dictionary release];
		}
		
		[labelArray release];
	}
    return self;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	[self layoutControls];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return YES;
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
	[self layoutControls];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[titleLabel release];
	[navBar release];
	
    [super dealloc];	
}

- (void)goBack
{
	[self dismissModalViewControllerAnimated:YES];
}

- (void)layoutControls
{
	if (UIInterfaceOrientationIsPortrait(self.interfaceOrientation)) {
		navBar.frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 44.0f);

		imageView.image = [UIImage imageNamed:@"evaluationPortrait.png"];
		titleLabel.frame = CGRectMake(self.view.frame.size.width / 2 - 250.0f, 80.0f, 500.0f, 50.0f);	
	}
	else {
		navBar.frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.height, 44.0f);

		imageView.image = [UIImage imageNamed:@"evaluationLandscape.png"];
		titleLabel.frame = CGRectMake(self.view.frame.size.height / 2 - 250.0f, 80.0f, 500.0f, 50.0f);
	}
}

@end
