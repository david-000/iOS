    //
//  RegisterUserViewController.m
//  Merz
//
//  Created by SongGumChol on 12/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RegisterUserViewController.h"
#import "EvaluationViewController.h"
#import "defines.h"
#import "MysqlConnection.h"
#import "MysqlInsert.h"
#import "MysqlException.h"


@implementation RegisterUserViewController

- (id)initWithMysqlConnection:(MysqlConnection *)theConnection;
{
	if (self = [super initWithNibName:@"RegisterUserViewController" bundle:nil]) {
		self.view.backgroundColor = BACKGROUNDCOLOR;
		
		UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 20.0f, self.view.frame.size.width - 40.0f, 40.0f)];
		titleLabel.backgroundColor = [UIColor clearColor];
		titleLabel.font = [UIFont systemFontOfSize:24.0f];
		titleLabel.text = USERINFO_TITLE;
		[self.view addSubview:titleLabel];
		[titleLabel release];
		
		UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 80.0f, 120.0f, 30.0f)];
		nameLabel.backgroundColor = [UIColor clearColor];
		nameLabel.text = USERINFO_NAME;
		[self.view addSubview:nameLabel];
		[nameLabel release];
		
		UILabel *emailLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 120.0f, 120.0f, 30.0f)];
		emailLabel.backgroundColor = [UIColor clearColor];
		emailLabel.text = USERINFO_EMAIL;
		[self.view addSubview:emailLabel];
		[emailLabel release];
		
		UILabel *distritoLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 160.0f, 120.0f, 30.0f)];
		distritoLabel.backgroundColor = [UIColor clearColor];
		distritoLabel.text = USERINFO_DISTRITO;
		[self.view addSubview:distritoLabel];
		[distritoLabel release];
		
		nameField = [[UITextField alloc] initWithFrame:CGRectMake(150.0f, 80.0f, 200.0f, 30.0f)];
		nameField.borderStyle = UITextBorderStyleRoundedRect;
		nameField.keyboardType = UIKeyboardTypeAlphabet;
		nameField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
		nameField.autocorrectionType = UITextAutocorrectionTypeNo;
		nameField.autocapitalizationType = UITextAutocapitalizationTypeWords;
		[self.view addSubview:nameField];

		emailField = [[UITextField alloc] initWithFrame:CGRectMake(150.0f, 120.0f, 200.0f, 30.0f)];
		emailField.borderStyle = UITextBorderStyleRoundedRect;
		emailField.keyboardType = UIKeyboardTypeEmailAddress;
		emailField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
		emailField.autocorrectionType = UITextAutocorrectionTypeNo;
		emailField.autocapitalizationType = UITextAutocapitalizationTypeNone;
		[self.view addSubview:emailField];

		distritoField = [[UITextField alloc] initWithFrame:CGRectMake(150.0f, 160.0f, 200.0f, 30.0f)];
		distritoField.borderStyle = UITextBorderStyleRoundedRect;
		distritoField.keyboardType = UIKeyboardTypeDefault;
		distritoField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
		distritoField.autocorrectionType = UITextAutocorrectionTypeNo;
		distritoField.autocapitalizationType = UITextAutocapitalizationTypeNone;
		[self.view addSubview:distritoField];
		
		UIButton *okButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		okButton.frame = CGRectMake(180.0f, 220.0f, 80.0f, 30.0f);
		okButton.backgroundColor = [UIColor clearColor];
		[okButton setTitle:MESSAGEBOX_OKBUTTON_TITLE forState:UIControlStateNormal];
		[okButton addTarget:self action:@selector(insertUserInfo) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:okButton];

		UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		cancelButton.frame = CGRectMake(300.0f, 220.0f, 80.0f, 30.0f);
		cancelButton.backgroundColor = [UIColor clearColor];
		[cancelButton setTitle:MESSAGEBOX_CANCELBUTTON_TITLE forState:UIControlStateNormal];
		[cancelButton addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:cancelButton];
		
		connection = theConnection;
	}
	return self;
}
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return YES;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)insertUserInfo
{
	if (([nameField text] == nil) || [[nameField text] isEqualToString:@""]) {
		[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE message:MESSAGEBOX_OMITTED_NAME 
									delegate:nil cancelButtonTitle:MESSAGEBOX_OKBUTTON_TITLE otherButtonTitles:nil] autorelease] show];
		[nameField becomeFirstResponder];
		return;
	}
	
	if (([emailField text] == nil) || [[emailField text] isEqualToString:@""]) {
		[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE message:MESSAGEBOX_OMITTED_EMAIL
									delegate:nil cancelButtonTitle:MESSAGEBOX_OKBUTTON_TITLE otherButtonTitles:nil] autorelease] show];
		[emailField becomeFirstResponder];
		return;
	}

	if (([distritoField text] == nil) || [[distritoField text] isEqualToString:@""]) {
		[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE message:MESSAGEBOX_OMITTED_DISTRITO
									delegate:nil cancelButtonTitle:MESSAGEBOX_OKBUTTON_TITLE otherButtonTitles:nil] autorelease] show];
		[distritoField becomeFirstResponder];
		return;
	}
	
	if (!connection)
		return;
	
	@try {
		MysqlInsert *insert = [MysqlInsert insertWithConnection:connection];
		insert.table = DB_USERTABLE_NAME;
		insert.rowData = [NSDictionary dictionaryWithObjectsAndKeys:
						  [UIDevice currentDevice].uniqueIdentifier, @"`UDID`", 
						  nameField.text, @"`name`", 
						  emailField.text, @"`email`",
						  distritoField.text, @"`distrito`", nil];
		[insert execute];
		
		EvaluationViewController *parent = (EvaluationViewController *)[self parentViewController];
		parent.userid = [insert.rowid unsignedIntValue];
	}
	@catch (MysqlException * e) {
		[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE message:[e reason]
									delegate:nil cancelButtonTitle:MESSAGEBOX_OKBUTTON_TITLE otherButtonTitles:nil] autorelease] show];
	}
	
	[self dismissModalViewControllerAnimated:YES];
}

- (void)dismiss{
	[self dismissModalViewControllerAnimated:YES];
}

- (void)dealloc {
	[nameField release];
	[emailField release];
	[distritoField release];
	
    [super dealloc];
}


@end
