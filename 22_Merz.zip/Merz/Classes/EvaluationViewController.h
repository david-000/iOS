//
//  EvaluationViewController.h
//  Merz
//
//  Created by SongGumChol on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MysqlConnection;
@class UIProgressHUD;

@interface EvaluationViewController : UIViewController {
	UINavigationBar *navBar;
	
	IBOutlet UIImageView *imageView;
	
	UILabel *titleLabel;
	NSArray *answerLabels;
	UIButton *okButton;
	UIImageView *resultImageView;
	
	NSUInteger userid;
	
	MysqlConnection *connection;
	
	NSInteger documentIndex;
	
	NSArray *quizArray;
	
	int quizIndex;
	int selectedAnswerIndex;
	int correctAnswerIndex;
	int nCorrectedAnswers;
	
	NSOperationQueue *_queue;
}

@property (retain, nonatomic) IBOutlet UIImageView *imageView;

@property (nonatomic) NSUInteger userid;
@property (nonatomic, retain) NSOperationQueue *queue;

- (id) initWithDocumentIndex:(NSInteger)index;

- (void) layoutControls;

//- (NSInteger) fetchUserIdFromDatabase:(UIProgressHUD *)aHud;

- (void) quiz;

- (void) selectAnswerLabel:(id)aLabel;

- (void) saveResult;

- (void) goBack;

@end
