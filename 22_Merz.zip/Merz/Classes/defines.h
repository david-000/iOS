/*
 *  defines.h
 *  Merz
 *
 *  Created by SongGumChol on 12/3/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

// Program Title
#define PROGRAM_TITLE	@"Merz Application"

// Key Strings used in UserDefaults
#define KEY_UNLOCKED_INDEX		@"lastUnlockedDocIndex"
#define KEY_CORRECT_ANSWER	@"numCorrectedAnswers%d"

// Key Strings used in connection.plist
#define KEY_CONNECTION_HOST		@"Host"
#define KEY_CONNECTION_PORT		@"Port"
#define KEY_CONNECTION_USERNAME	@"User"
#define KEY_CONNECTION_PASSWORD	@"Password"
#define KEY_CONNECTION_SCHEMA	@"Schema"

// String constants used in evaluation result view.
#define RESULT_TITLE				@"Resultados de las evaluaciones"
#define RESULT_NOT_TAKEN			@"Sin contestar."
#define RESULT_EVALUATED_FAIL		@"Reprobado: %d de 15 respuestas correctas."
#define RESULT_EVALUATED_SUCCESS	@"Aprobado: %d de 15 respuestas correctas."

// String constants used in UI components
#define BACKBUTTON_TITLE		@"Regresar"
#define PDFVIEW_TITLE			@"Página %d de %d"

// String constants used in evaluation view
#define USERINFO_TITLE			@"Por favor escriba su nombre, e-mail y distrito:"
#define USERINFO_NAME			@"Nombre:"
#define USERINFO_EMAIL			@"E-mail:"
#define USERINFO_DISTRITO		@"Distrito:"

#define EVALUATION_FROM_PDFVIEW_TITLW	@"Ha terminado de leer el documento. Desea entrar a la evaluación?"
#define EVALUATION_SUCCESSED			@"Felicidades! Ha contestado %d de 15 respuestas correctamente. Ya puede acceder a la sección de %@."
#define EVALUATION_FAILED				@"Lo sentimos. No ha superado la evaluación ya que solo ha obtenido %d de 15 respuestas correctas. Le recomendamos leer nuevamente la información e intentar la evaluación una vez más"

// color constant used in RegisterUser view
#define BACKGROUNDCOLOR [UIColor colorWithRed:224.0f / 255.0f green:224.0f / 255.0f blue:224.0f / 255.0f alpha:1.0f]
// String constants to notify users via messagebox
#define MESSAGEBOX_TITLE					@""
#define MESSAGEBOX_CANNOT_CONNECT_INTERNET	@"No se ha detectado una conexión a Internet. Aseúrese de estar conectado e inténtelo de nuevo."
#define MESSAGEBOX_CANNOT_CONNECT_SERVER	@"No se ha podido establecer una conexión con la base de datos."
#define MESSAGEBOX_CANNOT_EXECUTE			@"Hubo un error al seleccionar/insert."
#define MESSAGEBOX_OKBUTTON_TITLE			@"Aceptar"
#define MESSAGEBOX_CANCELBUTTON_TITLE		@"Cancelar"

#define MESSAGEBOX_OMITTED_NAME				@"No ha escrito su nombre"
#define MESSAGEBOX_OMITTED_EMAIL			@"No ha escrito su correo electrónico"
#define MESSAGEBOX_OMITTED_DISTRITO			@"No ha escrito su distrito"

#define MESSAGEBOX_QUIZ_SELECT				@"Please select one answer"
#define MESSAGEBOX_USER_NOT_REGISTERED		@"User is not registered"

#define PROGRESS_CONNECTING					@"Connecting..."

// host name used to test Internet connection
#define INTERNET_HOSTNAME		@"www.apple.com"

// DB-relative constants
#define DB_USERTABLE_NAME		@"user"
#define DB_EVALUATIONTABLE_NAME	@"evaluation"

// Return values
#define RETURN_ERROR	-1
#define RETURN_SUCCESS	0