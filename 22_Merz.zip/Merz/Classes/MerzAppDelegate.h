//
//  MerzAppDelegate.h
//  Merz
//
//  Created by Admin on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MerzViewController;
@class DocumentEntry;

@interface MerzAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    MerzViewController *viewController;
	
	// Count of unlocked documents
	NSInteger availableDocIndex;
	
	// Array of document entry
	// Each document entry contains number of correct answers and previously saved page numbers of all chapters.
	NSArray *docEntryArray;
	
	NSArray *keyArray;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MerzViewController *viewController;

@property (nonatomic)			NSInteger availableDocIndex;
@property (nonatomic, retain)	NSArray *docEntryArray;
@property (nonatomic, readonly) NSArray *keyArray;

- (void)saveProgramState;

@end

