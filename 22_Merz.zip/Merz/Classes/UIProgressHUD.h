//
//  UIProgressHUD.h
//  Merz
//
//  Created by SongGumChol on 12/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIProgressHUD : NSObject 

- (void) show: (BOOL) yesOrNo;
- (UIProgressHUD *) initWithWindow: (UIView *) window;
- (void)setText : (NSString *)theText;

@end
