//
//  PDFViewController.h
//  MyPDFReader
//
//  Created by Admin on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PDFView.h"

@interface PDFViewController : UIViewController 
<UIScrollViewDelegate, PDFViewDataSource, PDFViewDelegate, UIAlertViewDelegate> {
	UINavigationBar *navBar;
	UINavigationItem *navItem;
	
	UIScrollView *_containerView;
	
	PDFView		*_pdfView;
	
	CGPDFDocumentRef _pdfDoc;
	NSInteger pageNumber;
	
	NSInteger documentIndex;
	NSInteger chapterNumber;
}

@property (nonatomic) NSInteger documentIndex, chapterNumber;

- (id) initWithPDFFileName:(NSString *)fileName firstPageNumber:(NSInteger)firstPageNumber;

- (void) layoutNavigationBar;

- (void) enableZoom:(BOOL)bEnable;
- (void) enableScroll:(BOOL)bEnable;

@end
