//
//  PDFView.h
//  MyPDFReader
//
//  Created by Admin on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

typedef enum {
	TOUCHED_NONE,
	TOUCHED_PREVPAGE,
	TOUCHED_NEXTPAGE
} TouchedInfo;

@class PDFCache;

@protocol PDFViewDataSource;
@protocol PDFViewDelegate;

@interface PDFView : UIView {
	CALayer *topPage;
	CALayer *topPageRight;
	CALayer *topPageOverlay;
	CAGradientLayer *topPageShadow;

	CALayer *topPageReverse;
	CALayer *topPageReverseImage;
	CALayer *topPageReverseOverlay;
	CAGradientLayer *topPageReverseShading;

	CALayer *bottomPage;
	CALayer *bottomPageRight;
	CAGradientLayer *bottomPageShadow;

	CGFloat leafEdge;
	NSUInteger currentPageIndex;
	NSUInteger numberOfPages;
	NSUInteger chapterNumber;
	id<PDFViewDelegate> delegate;

	CGSize pageSize;
	PDFCache *pageCache;

	CGPoint touchBeganPoint;
	CGRect nextPageRect, prevPageRect;
	BOOL interactionLocked;

	BOOL orientationIsPortrait;
	TouchedInfo currentTouchInfo;
	NSUInteger pageStep;
}

@property (assign) id<PDFViewDataSource> dataSource;
@property (assign) id<PDFViewDelegate> delegate;

// (0.0 - 1.0)
@property (assign) CGFloat leafEdge;

@property BOOL interactionLocked;

// the zero-based index of the page currently being displayed.
@property (assign) NSUInteger currentPageIndex;
@property (assign) NSUInteger chapterNumber;

// refreshes the contents of all pages via the data source methods, much like -[UITableView reloadData]
- (void) reloadData;

- (void)orientationWillRotate:(BOOL)isPortrait;

- (void) getImages;

- (void) setLayerFrames;

@end

@protocol PDFViewDataSource <NSObject>

- (NSUInteger) numberOfPagesInPDF;
- (void) renderPageAtIndex:(NSUInteger)index inContext:(CGContextRef)ctx;

@end


@protocol PDFViewDelegate <NSObject>

@optional

// called when the user touches up on the left or right side of the page, or finishes dragging the page
- (void) pdfView:(PDFView *)pdfView willTurnToPageAtIndex:(NSUInteger)pageIndex;

// called when the page-turn animation (following a touch-up or drag) completes 
- (void) pdfView:(PDFView *)pdfView didTurnToPageAtIndex:(NSUInteger)pageIndex;

@end

