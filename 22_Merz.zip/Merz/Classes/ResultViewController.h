//
//  ResultViewController.h
//  Merz
//
//  Created by SongGumChol on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ResultViewController : UIViewController {
	UINavigationBar *navBar;
	
	UILabel *titleLabel;
	
	IBOutlet UIImageView *imageView;
}

@property (retain, nonatomic) IBOutlet UIImageView *imageView;

- (void) layoutControls;

@end
