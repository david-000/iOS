    //
//  ChapterSelectViewController.m
//  Merz
//
//  Created by SongGumChol on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ChapterSelectViewController.h"
#import "HelpViewController.h"
#import "ResultViewController.h"
#import "EvaluationViewController.h"
#import "PDFViewController.h"
#import "MerzAppDelegate.h"
#import "DocumentEntry.h"
#import "defines.h"
#import "Reachability.h"


@implementation ChapterSelectViewController

@synthesize imageView;
@synthesize chapter1Button, chapter2Button, chapter3Button, chapter4Button, chapter5Button, chapter6Button, chapter7Button;
@synthesize evaluationResultButton, helpButton, evaluationButton;

 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil docIndex:(NSInteger)index {
    self = [super initWithNibName:nibNameOrNil bundle:nil];
    if (self) {
        // Custom initialization.
		documentIndex = index;

    	navBar = [[UINavigationBar alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 44.0f)];
		navBar.barStyle = UIBarStyleBlackOpaque;
		UINavigationItem *navItem = [[UINavigationItem alloc] init];
		navItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:BACKBUTTON_TITLE style:UIBarButtonItemStyleBordered target:self action:@selector(goBack)];
		[navBar pushNavigationItem:navItem animated:YES];
		[navItem release];
		[self.view addSubview:navBar];
	}
    return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	[self layoutControls];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return YES;
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
	[self layoutControls];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[navBar release];
	
    [super dealloc];
}

// Every time interface orientation is changed, this method is called so that User Interface is updated according to it
- (void)layoutControls
{
	if (UIInterfaceOrientationIsPortrait(self.interfaceOrientation)) {
		navBar.frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 44.0f);

		imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"chapter%dPortrait.png", documentIndex + 1]];
		chapter1Button.frame = CGRectMake(19.0f, 388.0f, chapter1Button.frame.size.width, chapter1Button.frame.size.height);
		chapter2Button.frame = CGRectMake(102.0f, 488.0f, chapter2Button.frame.size.width, chapter2Button.frame.size.height);
		chapter3Button.frame = CGRectMake(199.0f, 571.0f, chapter3Button.frame.size.width, chapter3Button.frame.size.height);
		chapter4Button.frame = CGRectMake(325.0f, 642.0f, chapter4Button.frame.size.width, chapter4Button.frame.size.height);
		chapter5Button.frame = CGRectMake(452.0f, 571.0f, chapter5Button.frame.size.width, chapter5Button.frame.size.height);
		chapter6Button.frame = CGRectMake(555.0f, 488.0f, chapter6Button.frame.size.width, chapter6Button.frame.size.height);
		chapter7Button.frame = CGRectMake(625.0f, 388.0f, chapter7Button.frame.size.width, chapter7Button.frame.size.height);
		
		evaluationResultButton.frame = CGRectMake(251.0f, 910.0f, evaluationResultButton.frame.size.width, evaluationResultButton.frame.size.height);
		helpButton.frame = CGRectMake(361.0f, 910.0f, helpButton.frame.size.width, helpButton.frame.size.height);
		evaluationButton.frame = CGRectMake(471.0f, 910.0f, evaluationButton.frame.size.width, evaluationButton.frame.size.height);
	} else {
		navBar.frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.height, 44.0f);

		imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"chapter%dLandscape.png", documentIndex + 1]];
		
		chapter1Button.frame = CGRectMake(36.0f, 376.0f, chapter1Button.frame.size.width, chapter1Button.frame.size.height);
		chapter2Button.frame = CGRectMake(169.0f, 403.0f, chapter2Button.frame.size.width, chapter2Button.frame.size.height);
		chapter3Button.frame = CGRectMake(306.0f, 408.0f, chapter3Button.frame.size.width, chapter3Button.frame.size.height);
		chapter4Button.frame = CGRectMake(447.0f, 413.0f, chapter4Button.frame.size.width, chapter4Button.frame.size.height);
		chapter5Button.frame = CGRectMake(592.0f, 408.0f, chapter5Button.frame.size.width, chapter5Button.frame.size.height);
		chapter6Button.frame = CGRectMake(732.0f, 403.0f, chapter6Button.frame.size.width, chapter6Button.frame.size.height);
		chapter7Button.frame = CGRectMake(868.0f, 376.0f, chapter7Button.frame.size.width, chapter7Button.frame.size.height);
		
		evaluationResultButton.frame = CGRectMake(335.0f, 654.0f, evaluationResultButton.frame.size.width, evaluationResultButton.frame.size.height);
		helpButton.frame = CGRectMake(484.0f, 654.0f, helpButton.frame.size.width, helpButton.frame.size.height);
		evaluationButton.frame = CGRectMake(633.0f, 654.0f, evaluationButton.frame.size.width, evaluationButton.frame.size.height);
	}
}

- (IBAction)chapterButtonTapped:(id)sender 
{
	UIButton *button = (UIButton *)sender;
	NSInteger chapterNumber = button.tag;
	
	// Get file name
	MerzAppDelegate *delegate = (MerzAppDelegate *)[[UIApplication sharedApplication] delegate];
	NSString *pdfFileName = [NSString stringWithFormat:@"%@%d.pdf", [delegate.keyArray objectAtIndex:documentIndex], chapterNumber];
	
	// Get last saved page number
	NSInteger pageNumber = 1;
	if ((delegate.docEntryArray != nil) && ([delegate.docEntryArray count] > documentIndex)) {
		DocumentEntry *entry = [delegate.docEntryArray objectAtIndex:documentIndex];
		NSNumber *objPageNumber = (NSNumber *)[entry.pageNumbers objectAtIndex:chapterNumber - 1];
		pageNumber = [objPageNumber intValue];
	}
	PDFViewController *controller = [[PDFViewController alloc] initWithPDFFileName:pdfFileName firstPageNumber:pageNumber];
	controller.documentIndex = documentIndex;
	controller.chapterNumber = chapterNumber;
//	controller.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
	[self presentModalViewController:controller animated:YES];
	
	[controller release];
}

- (IBAction)evaluationResultButtonTapped:(id)sender
{
	ResultViewController *controller = [[ResultViewController alloc] initWithNibName:@"ResultViewController" bundle:nil];
	[self presentModalViewController:controller animated:YES];
	[controller release];
}

- (IBAction)evaluationButtonTapped:(id)sender
{
	Reachability *reach = [Reachability reachabilityForInternetConnection];
	[reach startNotifier];
	NetworkStatus netStatus = [reach currentReachabilityStatus];
	if (netStatus == NotReachable) {
		// Cannot connect to Internet.
		[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE 
									 message:MESSAGEBOX_CANNOT_CONNECT_INTERNET 
									delegate:self 
						   cancelButtonTitle:MESSAGEBOX_OKBUTTON_TITLE 
						   otherButtonTitles:nil] autorelease] show];
		return;
	}
	
	EvaluationViewController *controller = [[EvaluationViewController alloc] initWithDocumentIndex:documentIndex];
	[self presentModalViewController:controller animated:YES];
	[controller release];
}

- (IBAction)helpButtonTapped:(id)sender
{
	HelpViewController *controller = [[HelpViewController alloc] initWithNibName:@"HelpViewController" bundle:nil];
	[self presentModalViewController:controller animated:YES];
	[controller release];
}

- (void)goBack
{
	[self dismissModalViewControllerAnimated:YES];
}

@end
