//
//  MerzViewController.h
//  Merz
//
//  Created by Admin on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MerzViewController : UIViewController {
	// backgound image
	IBOutlet UIImageView *imageView;
	
	// document select buttons
	IBOutlet UIButton *firstButton;
	IBOutlet UIButton *secondButton;
	IBOutlet UIButton *thirdButton;
	IBOutlet UIButton *fourthButton;
	IBOutlet UIButton *fifthButton;
	IBOutlet UIButton *sixthButton;
	
	// dock buttons
	IBOutlet UIButton *evaluationResultButton;
	IBOutlet UIButton *helpButton;
	IBOutlet UIButton *evaluationButton;
}

@property (retain, nonatomic) IBOutlet UIImageView *imageView;
@property (retain, nonatomic) IBOutlet UIButton *firstButton, *secondButton, *thirdButton, *fourthButton, *fifthButton, *sixthButton;
@property (retain, nonatomic) IBOutlet UIButton *evaluationResultButton, *helpButton, *evaluationButton;

// Document select button's handler
// When each button is tapped, this method is called.  To determine which button is tapped, test parameter sender.
- (IBAction) documentButtonTapped:(id)sender;

// Dock buttons' handlers
- (IBAction) evaluationResultButtonTapped:(id)sender;
- (IBAction) helpButtonTapped:(id)sender;
- (IBAction) evaluationButtonTapped:(id)sender;

// Private method
- (void) layoutControls;

@end

