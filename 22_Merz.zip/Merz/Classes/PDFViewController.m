    //
//  PDFViewController.m
//  MyPDFReader
//
//  Created by Admin on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <CoreGraphics/CoreGraphics.h>
#import "PDFViewController.h"
#import "MerzAppDelegate.h"
#import "DocumentEntry.h"
#import "EvaluationViewController.h"
#import "defines.h"
#import "Reachability.h"


CGAffineTransform aspectFit(CGRect innerRect, CGRect outerRect) {
	CGFloat scaleFactor;
	scaleFactor = MIN(outerRect.size.width/innerRect.size.width, outerRect.size.height/innerRect.size.height);
	CGAffineTransform scale = CGAffineTransformMakeScale(scaleFactor, scaleFactor);
	CGRect scaledInnerRect = CGRectApplyAffineTransform(innerRect, scale);
	CGAffineTransform translation = 
	CGAffineTransformMakeTranslation((outerRect.size.width - scaledInnerRect.size.width) / 2 - scaledInnerRect.origin.x, 
									 (outerRect.size.height - scaledInnerRect.size.height) / 2 - scaledInnerRect.origin.y);
	return CGAffineTransformConcat(scale, translation);
}

@implementation PDFViewController

@synthesize documentIndex, chapterNumber;

- (void) initialize {
	_containerView = [[UIScrollView alloc] initWithFrame:CGRectZero];
	_containerView.showsVerticalScrollIndicator = NO;
	_containerView.showsHorizontalScrollIndicator = NO;
	_containerView.bouncesZoom = YES;
	_containerView.delegate = self;
	_containerView.maximumZoomScale = 5.0;
	_containerView.minimumZoomScale = .25;
	_containerView.delaysContentTouches = NO;
	_containerView.scrollEnabled = YES;
	_containerView.decelerationRate = UIScrollViewDecelerationRateNormal / 2;
	[_containerView setBackgroundColor:[UIColor grayColor]];
	
	_pdfView = [[PDFView alloc] initWithFrame:CGRectZero];
	_pdfView.currentPageIndex = pageNumber - 1; // Goto last saved page
	[_pdfView setBackgroundColor:[UIColor whiteColor]];
	[_containerView addSubview:_pdfView];
}

- (id) initWithPDFFileName:(NSString *)fileName firstPageNumber:(NSInteger)firstPageNumber
{
	if (self = [super initWithNibName:nil bundle:nil]) {
		CFURLRef pdfURL = CFBundleCopyResourceURL(CFBundleGetMainBundle(), (CFStringRef)fileName, NULL, NULL);
		_pdfDoc = CGPDFDocumentCreateWithURL(pdfURL);
		CFRelease(pdfURL);
		
		pageNumber = firstPageNumber;

		[self initialize];
	}
	return self;
}

- (void)enableScroll:(BOOL)bEnable
{
	_containerView.scrollEnabled = bEnable;
}

- (void)enableZoom:(BOOL)bEnable
{
	if (bEnable) {
		_containerView.maximumZoomScale = 5.0;
		_containerView.minimumZoomScale = .25;
	}
	else {
		_containerView.maximumZoomScale = 1.0;
		_containerView.minimumZoomScale = 1.0;
	}
}

- (void)dealloc {
	CGPDFDocumentRelease(_pdfDoc);
	[_containerView release];
	[_pdfView release];
	
	[navItem release];
	[navBar release];
	
    [super dealloc];
}

#pragma mark  UIViewController methods

- (void)loadView {
	[super loadView];
	_containerView.frame = self.view.bounds;
	_containerView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	
	[self.view addSubview:_containerView];
	_pdfView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	_pdfView.frame = _containerView.bounds;
	
	navBar = [[UINavigationBar alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 44.0f)];
	navBar.barStyle = UIBarStyleBlackOpaque;
	navItem = [[UINavigationItem alloc] init];
	navItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:BACKBUTTON_TITLE style:UIBarButtonItemStyleBordered target:self action:@selector(goBack)];
	navItem.title = [NSString stringWithFormat:PDFVIEW_TITLE, pageNumber, CGPDFDocumentGetNumberOfPages(_pdfDoc)];
	[navBar pushNavigationItem:navItem animated:YES];
	[self.view addSubview:navBar];
}

- (void) viewDidLoad {
	[super viewDidLoad];
	_pdfView.dataSource = self;
	_pdfView.delegate = self;
	[_pdfView reloadData];
	_pdfView.chapterNumber = chapterNumber;
	
	[self layoutNavigationBar];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return YES;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

#pragma mark  PDFViewDelegate methods

- (void) pdfView:(PDFView *)pdfView willTurnToPageAtIndex:(NSUInteger)pageIndex {
	int numberOfPages = CGPDFDocumentGetNumberOfPages(_pdfDoc);
	
	if (pageIndex < numberOfPages) {
		navItem.title = [NSString stringWithFormat:PDFVIEW_TITLE, pageIndex + 1, CGPDFDocumentGetNumberOfPages(_pdfDoc)];
		pageNumber = pageIndex + 1;
	} else if (chapterNumber == 7) {
		[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE
									 message:EVALUATION_FROM_PDFVIEW_TITLW
									delegate:self
						   cancelButtonTitle:MESSAGEBOX_CANCELBUTTON_TITLE
						   otherButtonTitles:MESSAGEBOX_OKBUTTON_TITLE, nil] autorelease] show];
	}
}

#pragma mark PDFViewDataSource methods

- (NSUInteger) numberOfPagesInPDF {
	return CGPDFDocumentGetNumberOfPages(_pdfDoc);
}

- (void) renderPageAtIndex:(NSUInteger)index inContext:(CGContextRef)ctx {
	CGPDFPageRef page = CGPDFDocumentGetPage(_pdfDoc, index + 1);
	CGContextSaveGState(ctx);
	CGAffineTransform transform = aspectFit(CGPDFPageGetBoxRect(page, kCGPDFMediaBox),
											CGContextGetClipBoundingBox(ctx));
	CGContextConcatCTM(ctx, transform);
	CGContextDrawPDFPage(ctx, page);
	CGContextRestoreGState(ctx);
}

#pragma mark UIScrollViewDelegate methods

- (id)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
	return _pdfView;
}

- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(float)scale {
	if (scale > 1.0) {
		_pdfView.interactionLocked = YES;
	}
	else {
		_pdfView.interactionLocked = NO;
	}

	CGSize boundsSize = _containerView.bounds.size;
	CGSize frameSize = _pdfView.frame.size;
    if (frameSize.width < boundsSize.width
		|| frameSize.height < boundsSize.height) {
		_pdfView.center = _containerView.center;
	}
	else {
		CGRect rtFrame = _pdfView.frame;
		rtFrame.origin = CGPointMake(0, 0);
		_pdfView.frame = rtFrame;
	}
}

#pragma mark orientation methods
- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
	[_containerView setZoomScale:1.0f];
	[_pdfView setCenter:_containerView.center];
	[_pdfView orientationWillRotate:UIInterfaceOrientationIsPortrait(toInterfaceOrientation)];
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
	CGSize size = _containerView.frame.size;
	[_containerView setContentSize:size];
	
	[self layoutNavigationBar];
}

- (void)goBack
{
	MerzAppDelegate *delegate = (MerzAppDelegate *)[[UIApplication sharedApplication] delegate];
	DocumentEntry *docEntry = [delegate.docEntryArray objectAtIndex:documentIndex];
	[docEntry.pageNumbers replaceObjectAtIndex:chapterNumber - 1 withObject:[NSNumber numberWithInt:pageNumber]];
//	[delegate saveProgramState];
	
	[self dismissModalViewControllerAnimated:YES];
}

- (void)layoutNavigationBar
{
	if (UIInterfaceOrientationIsPortrait(self.interfaceOrientation))
		navBar.frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 44.0f);
	else
		navBar.frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.height, 44.0f);
}

#pragma mark UIAlertViewDelegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)index
{
	int numberOfPages = CGPDFDocumentGetNumberOfPages(_pdfDoc);
	pageNumber = numberOfPages;
	if (numberOfPages % 2 == 0 && UIInterfaceOrientationIsLandscape(self.interfaceOrientation)) {
		pageNumber = numberOfPages - 1;
	}
	_pdfView.currentPageIndex = pageNumber - 1;
	navItem.title = [NSString stringWithFormat:@"Page %u of %u", pageNumber, numberOfPages];
	if (index == 0) { // Cancel button clicked
//		pageNumber --;
	} else {		  // Accept button clicked	
		Reachability *reach = [Reachability reachabilityForInternetConnection];
		[reach startNotifier];
		NetworkStatus netStatus = [reach currentReachabilityStatus];
		if (netStatus == NotReachable) {
			// Cannot connect to Internet.
			[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE 
										 message:MESSAGEBOX_CANNOT_CONNECT_INTERNET 
										delegate:self 
							   cancelButtonTitle:MESSAGEBOX_OKBUTTON_TITLE 
							   otherButtonTitles:nil] autorelease] show];
			//		free(addr);
			return;
		}

		EvaluationViewController *controller = [[EvaluationViewController alloc] initWithDocumentIndex:documentIndex];
		[self presentModalViewController:controller animated:YES];
		[controller release];
	}
}

@end
