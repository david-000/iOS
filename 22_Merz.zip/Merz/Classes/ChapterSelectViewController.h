//
//  ChapterSelectViewController.h
//  Merz
//
//  Created by SongGumChol on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ChapterSelectViewController : UIViewController {
	// Selected PDF file's index
	NSInteger documentIndex;
	
	// Background Image
	IBOutlet UIImageView *imageView;
	
	// Chapter select buttons
	IBOutlet UIButton *chapter1Button, *chapter2Button, *chapter3Button, *chapter4Button, *chapter5Button, *chapter6Button, *chapter7Button;
	
	// Dock buttons
	IBOutlet UIButton *evaluationResultButton, *helpButton, *evaluationButton;
	
	UINavigationBar *navBar;
}

@property (retain, nonatomic) IBOutlet UIImageView *imageView;
@property (retain, nonatomic) IBOutlet UIButton *chapter1Button, *chapter2Button, *chapter3Button, *chapter4Button, *chapter5Button, *chapter6Button, *chapter7Button;
@property (retain, nonatomic) IBOutlet UIButton *evaluationResultButton, *helpButton, *evaluationButton;

// Initialize method
- (id) initWithNibName:(NSString*)nibNameOrNil docIndex:(NSInteger)inedx;

// Chapter select button's handler
- (IBAction) chapterButtonTapped:(id)sender;

// Dock buttons' handlers
- (IBAction) evaluationResultButtonTapped:(id)sender;
- (IBAction) helpButtonTapped:(id)sender;
- (IBAction) evaluationButtonTapped:(id)sender;

// Private method
- (void)layoutControls;

@end
