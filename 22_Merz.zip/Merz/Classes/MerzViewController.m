//
//  MerzViewController.m
//  Merz
//
//  Created by Admin on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MerzViewController.h"
#import "HelpViewController.h"
#import "ChapterSelectViewController.h"
#import "MerzAppDelegate.h"
#import "ResultViewController.h"
#import "EvaluationViewController.h"
#import "Reachability.h"
#import "defines.h"


@implementation MerzViewController

@synthesize imageView;
@synthesize firstButton, secondButton, thirdButton, fourthButton, fifthButton, sixthButton;
@synthesize evaluationResultButton, helpButton, evaluationButton;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	// Determine buttons' state according to unlocked document's index 
	MerzAppDelegate *delegate = (MerzAppDelegate*)[[UIApplication sharedApplication] delegate];
	
	NSInteger docIndex = delegate.availableDocIndex;
	switch (docIndex) {
		case 5:
			sixthButton.enabled = YES;
		case 4:
			fifthButton.enabled = YES;
		case 3:
			fourthButton.enabled = YES;
		case 2:
			thirdButton.enabled = YES;
		case 1:
			secondButton.enabled = YES;
		default:
			firstButton.enabled = YES;
	}
	[self layoutControls];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}


#pragma mark private method

// Every time interface orientation is changed, this method is called so that User Interface is updated according to it
- (void)layoutControls
{
	if (UIInterfaceOrientationIsPortrait(self.interfaceOrientation)) {
		imageView.image = [UIImage imageNamed:@"backgroundPortrait.png"];

		firstButton.frame = CGRectMake(237.0f, 285.0f, firstButton.frame.size.width, firstButton.frame.size.height);
		secondButton.frame = CGRectMake(237.0f, 383.0f, secondButton.frame.size.width, secondButton.frame.size.height);
		thirdButton.frame = CGRectMake(237.0f, 480.0f, thirdButton.frame.size.width, thirdButton.frame.size.height);
		fourthButton.frame = CGRectMake(237.0f, 578.0f, fourthButton.frame.size.width, fourthButton.frame.size.height);
		fifthButton.frame = CGRectMake(237.0f, 676.0f, fifthButton.frame.size.width, fifthButton.frame.size.height);
		sixthButton.frame = CGRectMake(237.0f, 773.0f, sixthButton.frame.size.width, sixthButton.frame.size.height);
		
		evaluationResultButton.frame = CGRectMake(220.0f, 911.0f, evaluationResultButton.frame.size.width, evaluationResultButton.frame.size.height);
		helpButton.frame = CGRectMake(369.0f, 911.0f, helpButton.frame.size.width, helpButton.frame.size.height);
		evaluationButton.frame = CGRectMake(519.0f, 911.0f, evaluationButton.frame.size.width, evaluationButton.frame.size.height);
	} else {
		imageView.image = [UIImage imageNamed:@"backgroundLandscape.png"];
		
		firstButton.frame = CGRectMake(129.0f, 276.0f, firstButton.frame.size.width, firstButton.frame.size.height);
		secondButton.frame = CGRectMake(589.0f, 276.0f, secondButton.frame.size.width, secondButton.frame.size.height);
		thirdButton.frame = CGRectMake(129.0f, 383.0f, thirdButton.frame.size.width, thirdButton.frame.size.height);
		fourthButton.frame = CGRectMake(589.0f, 383.0f, fourthButton.frame.size.width, fourthButton.frame.size.height);
		fifthButton.frame = CGRectMake(129.0f, 497.0f, fifthButton.frame.size.width, fifthButton.frame.size.height);
		sixthButton.frame = CGRectMake(589.0f, 497.0f, sixthButton.frame.size.width, sixthButton.frame.size.height);
		
		evaluationResultButton.frame = CGRectMake(335.0f, 655.0f, evaluationResultButton.frame.size.width, evaluationResultButton.frame.size.height);
		helpButton.frame = CGRectMake(483.0f, 655.0f, helpButton.frame.size.width, helpButton.frame.size.height);
		evaluationButton.frame = CGRectMake(633.0f, 655.0f, evaluationButton.frame.size.width, evaluationButton.frame.size.height);
	}
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
	[self layoutControls];
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

#pragma mark Button handlers

- (IBAction)documentButtonTapped:(id)sender
{
	UIButton *button = (UIButton *)sender;
	ChapterSelectViewController *controller = [[ChapterSelectViewController alloc] initWithNibName:@"ChapterSelectViewController" docIndex:button.tag];
//	controller.modalTransitionStyle = UIModalTransitionStylePartialCurl;
	[self presentModalViewController:controller animated:YES];
	[controller release];
}

- (IBAction)helpButtonTapped:(id)sender
{
	HelpViewController *controller = [[HelpViewController alloc] initWithNibName:@"HelpViewController" bundle:nil];
	[self presentModalViewController:controller animated:YES];
	[controller release];
}

- (IBAction)evaluationResultButtonTapped:(id)sender
{
	ResultViewController *controller = [[ResultViewController alloc] initWithNibName:@"ResultViewController" bundle:nil];
	[self presentModalViewController:controller animated:YES];
	[controller release];
}

- (IBAction)evaluationButtonTapped:(id)sender
{
	Reachability *reach = [Reachability reachabilityForInternetConnection];
	[reach startNotifier];
	NetworkStatus netStatus = [reach currentReachabilityStatus];
	if (netStatus == NotReachable) {
		// Cannot connect to Internet.
		[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE message:MESSAGEBOX_CANNOT_CONNECT_INTERNET 
									delegate:self cancelButtonTitle:MESSAGEBOX_OKBUTTON_TITLE otherButtonTitles:nil] autorelease] show];
//		free(addr);
		return;
	}
//	free(addr);
	
	MerzAppDelegate *delegate = (MerzAppDelegate*)[[UIApplication sharedApplication] delegate];
	
	NSInteger docIndex = delegate.availableDocIndex;

	EvaluationViewController *controller = [[EvaluationViewController alloc] initWithDocumentIndex:docIndex];
	[self presentModalViewController:controller animated:YES];
	[controller release];
}

@end
