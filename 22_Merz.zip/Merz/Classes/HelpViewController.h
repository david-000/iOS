//
//  HelpViewController.h
//  Merz
//
//  Created by SongGumChol on 12/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface HelpViewController : UIViewController {
	IBOutlet UIImageView *imageView;

	UINavigationBar *navBar;
}

@property (nonatomic, retain) IBOutlet UIImageView *imageView;

- (void)layoutControls;

@end
