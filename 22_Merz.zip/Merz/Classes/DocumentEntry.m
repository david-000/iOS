//
//  DocumentEntry.m
//  Merz
//
//  Created by Admin on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DocumentEntry.h"


@implementation DocumentEntry

@synthesize documentIndex;
@synthesize numCorrectAnswers;
@synthesize pageNumbers;

- (id) init
{
	if (self = [super init]) {
		documentIndex = 0;
		numCorrectAnswers = -1;
		pageNumbers = [[NSMutableArray alloc] initWithObjects:
					   [NSNumber numberWithInt:1],
					   [NSNumber numberWithInt:1],
					   [NSNumber numberWithInt:1],
					   [NSNumber numberWithInt:1],
					   [NSNumber numberWithInt:1],
					   [NSNumber numberWithInt:1],
					   [NSNumber numberWithInt:1], nil];
	}
	
	return self;
}

- (void) dealloc
{
	[pageNumbers release];
	
	[super dealloc];
}

@end
