//
//  RegisterUserViewController.h
//  Merz
//
//  Created by SongGumChol on 12/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@class MysqlConnection;

@interface RegisterUserViewController : UIViewController {
	UITextField *nameField;
	UITextField *emailField;
	UITextField *distritoField;
	
	MysqlConnection *connection;
}

- (id) initWithMysqlConnection : (MysqlConnection *)theConnection;

@end
