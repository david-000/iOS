//
//  DocumentEntry.h
//  Merz
//
//  Created by Admin on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface DocumentEntry : NSObject {
	NSInteger documentIndex;
	NSInteger numCorrectAnswers;
	
	// Saved page number of each chapter
	NSMutableArray *pageNumbers;
}

@property (nonatomic)	NSInteger documentIndex;
@property (nonatomic)	NSInteger numCorrectAnswers;
@property (nonatomic, retain)	NSMutableArray *pageNumbers;

@end