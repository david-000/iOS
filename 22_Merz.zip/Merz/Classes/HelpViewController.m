    //
//  HelpViewController.m
//  Merz
//
//  Created by SongGumChol on 12/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "HelpViewController.h"
#import "ResultViewController.h"
#import "EvaluationViewController.h"
#import "defines.h"


@implementation HelpViewController

@synthesize imageView;

 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
		navBar = [[UINavigationBar alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 44.0f)];
		navBar.barStyle = UIBarStyleBlackOpaque;
		UINavigationItem *navItem = [[UINavigationItem alloc] init];
		navItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:BACKBUTTON_TITLE style:UIBarButtonItemStyleBordered target:self action:@selector(goBack)];
		[navBar pushNavigationItem:navItem animated:YES];
		[navItem release];
		[self.view addSubview:navBar];
    }
    return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	[self layoutControls];
}


- (void)layoutControls
{
	if (UIInterfaceOrientationIsPortrait(self.interfaceOrientation)) {
		navBar.frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 44.0f);
		
		imageView.image = [UIImage imageNamed:@"helpPortrait.png"];
	} else {
		navBar.frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.height, 44.0f);
		
		imageView.image = [UIImage imageNamed:@"helpLandscape.png"];
	}
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
	return YES;
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
	[self layoutControls];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[navBar release];
	
    [super dealloc];
}

- (IBAction)evaluationResultButtonTapped:(id)sender
{
	ResultViewController *controller = [[ResultViewController alloc] initWithNibName:@"ResultViewController" bundle:nil];
	[self presentModalViewController:controller animated:YES];
	[controller release];
}

- (IBAction)evaluationButtonTapped:(id)sender
{
	EvaluationViewController *controller = [[EvaluationViewController alloc] initWithNibName:@"EvaluationViewController" bundle:nil];
	[self presentModalViewController:controller animated:YES];
	[controller release];
}

- (IBAction) goBack
{
	[self dismissModalViewControllerAnimated:YES];
}

@end
