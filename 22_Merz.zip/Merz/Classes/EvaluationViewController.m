    //
//  EvaluationViewController.m
//  Merz
//
//  Created by SongGumChol on 12/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "EvaluationViewController.h"
#import "MerzAppDelegate.h"
#import "defines.h"
#import "MysqlConnection.h"
#import "MysqlFetch.h"
#import "MysqlServer.h"
#import "MysqlInsert.h"
#import "MysqlUpdate.h"
#import "RegisterUserViewController.h"
#import "UIProgressHUD.h"
#import "DocumentEntry.h"
#import "MysqlException.h"
#import "DSActivityView.h"


@implementation EvaluationViewController

@synthesize userid;
@synthesize queue = _queue;
@synthesize imageView;

 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id) initWithDocumentIndex:(NSInteger)index 
{
	if (self = [super initWithNibName:@"EvaluationViewController" bundle:nil]) {
    	navBar = [[UINavigationBar alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 44.0f)];
		navBar.barStyle = UIBarStyleBlackOpaque;
		navBar.tintColor = [UIColor colorWithRed:191.0 / 255.0 green:144.0 / 255.0 blue:90.0 / 255.0 alpha:1.0];
		UINavigationItem *navItem = [[UINavigationItem alloc] init];
		navItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:BACKBUTTON_TITLE style:UIBarButtonItemStyleBordered target:self action:@selector(goBack)];
		[navBar pushNavigationItem:navItem animated:YES];
		[navItem release];
		[self.view addSubview:navBar];
		
		titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(50.0f, 100.0f, self.view.frame.size.width - 100.0f, 180.0f)];
		titleLabel.lineBreakMode = UILineBreakModeWordWrap;
		
		titleLabel.numberOfLines = 7;
		titleLabel.textColor = [UIColor whiteColor];
		titleLabel.font = [UIFont systemFontOfSize:22.0f];
		titleLabel.backgroundColor = [UIColor clearColor];
		[self.view addSubview:titleLabel];
		[titleLabel release];
		
		answerLabels = [[NSArray alloc] initWithObjects:
						[[UILabel alloc] initWithFrame:CGRectMake(50.0f, 300.0f, self.view.frame.size.width - 100.0f, 40.0f)], 
						[[UILabel alloc] initWithFrame:CGRectMake(50.0f, 340.0f, self.view.frame.size.width - 100.0f, 40.0f)], 
						[[UILabel alloc] initWithFrame:CGRectMake(50.0f, 380.0f, self.view.frame.size.width - 100.0f, 40.0f)], 
						[[UILabel alloc] initWithFrame:CGRectMake(50.0f, 420.0f, self.view.frame.size.width - 100.0f, 40.0f)], 
						[[UILabel alloc] initWithFrame:CGRectMake(50.0f, 460.0f, self.view.frame.size.width - 100.0f, 40.0f)], 
						[[UILabel alloc] initWithFrame:CGRectMake(50.0f, 500.0f, self.view.frame.size.width - 100.0f, 40.0f)], 
						[[UILabel alloc] initWithFrame:CGRectMake(50.0f, 540.0f, self.view.frame.size.width - 100.0f, 40.0f)], 
						nil];
		for (int i = 0; i < [answerLabels count]; i++) {
			UILabel *label = [answerLabels objectAtIndex:i];
			label.lineBreakMode = UILineBreakModeWordWrap;
			label.numberOfLines = 2;
			label.textColor = [UIColor whiteColor];
			label.backgroundColor = [UIColor clearColor];
			label.userInteractionEnabled = YES;
			[self.view addSubview:label];
			[label release];
		}
		
		okButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		okButton.frame = CGRectMake(self.view.frame.size.width / 2 - 40.0f, 600.0f, 80.0f, 30.0f);
		[okButton setTitle:MESSAGEBOX_OKBUTTON_TITLE forState:UIControlStateNormal];
		[okButton addTarget:self action:@selector(evaluate) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:okButton];
		okButton.hidden = YES;
		
		resultImageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.view.frame.size.width / 2 - 100.0f, self.view.frame.size.height / 2 - 100.0f, 200.0f, 200.0f)];
		[self.view addSubview:resultImageView];
		[resultImageView release];
		
		documentIndex = index;
		
		NSDictionary *dictionary = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"evaluation" ofType:@"plist"]];
		if (dictionary) {
			MerzAppDelegate *delegate = (MerzAppDelegate *)[[UIApplication sharedApplication] delegate];
			NSDictionary *entry = (NSDictionary *)[dictionary objectForKey:[delegate.keyArray objectAtIndex:index]];
			quizArray = (NSArray *)[[entry objectForKey:@"questions"] retain];
		}
		
		quizIndex = 0;
		selectedAnswerIndex = -1;
		nCorrectedAnswers = 0;
	}
	return self;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return YES;
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation 
{
	[self layoutControls];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewDidLoad {
	[super viewDidLoad];
	
	[self layoutControls];
	
	_queue = [[NSOperationQueue alloc] init];
}

- (void)viewDidAppear:(BOOL)animated
{
	UIProgressHUD *hud = [[UIProgressHUD alloc] initWithWindow:self.view];
	[hud setText:@"Connecting..."];
	[hud show:YES];

	[self performSelector:@selector(fetchUserIdFromDatabase:) withObject:hud afterDelay:0.1f];
}

- (void)dealloc {
	[navBar release];
	[quizArray release];
	
	[answerLabels release];
	
	[_queue release];
	_queue = nil;
	
	[connection release];
	
    [super dealloc];
}

- (void)goBack
{
	[self dismissModalViewControllerAnimated:YES];
}

- (void)layoutControls
{
	if (UIInterfaceOrientationIsPortrait(self.interfaceOrientation)) {
		navBar.frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, 44.0f);
		
		imageView.image = [UIImage imageNamed:@"evaluationPortrait.png"];

		titleLabel.frame = CGRectMake(50.0f, 100.0f, self.view.frame.size.width - 100.0f, 200.0f);	
		for (int i = 0; i < [answerLabels count]; i++) {
			UILabel *label = [answerLabels objectAtIndex:i];
			label.frame = CGRectMake(50.0f, 300.0f + i * 40.0f, self.view.frame.size.width - 100.0f, 40.0f);
		}
		okButton.frame = CGRectMake(self.view.frame.size.width / 2 - 40.0f, 600.0f, 80.0f, 30.0f);
		resultImageView.frame = CGRectMake(self.view.frame.size.width / 2 - 100.0f, self.view.frame.size.height / 2 - 100.0f, 200.0f, 200.0f);
	}
	else {
		navBar.frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.height, 44.0f);
		
		imageView.image = [UIImage imageNamed:@"evaluationLandscape.png"];
		
		titleLabel.frame = CGRectMake(50.0f, 100.0f, self.view.frame.size.height - 100.0f, 200.0f);	
		for (int i = 0; i < [answerLabels count]; i++) {
			UILabel *label = [answerLabels objectAtIndex:i];
			label.frame = CGRectMake(50.0f, 300.0f + i * 40.0f, self.view.frame.size.height - 100.0f, 40.0f);
		}
		okButton.frame = CGRectMake(self.view.frame.size.height / 2 - 40.0f, 600.0f, 80.0f, 30.0f);
		resultImageView.frame = CGRectMake(self.view.frame.size.height / 2 - 100.0f, self.view.frame.size.width / 2 - 100.0f, 200.0f, 200.0f);
	}
}

- (void)fetchUserIdFromDatabase:(UIProgressHUD *)aHud
{
	NSString *udid = [[UIDevice currentDevice] uniqueIdentifier];
	
	MysqlServer *server = [[MysqlServer alloc] init];
	NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"connection" ofType:@"plist"]];
	server.host = [dict objectForKey:KEY_CONNECTION_HOST];
	server.port = [[dict objectForKey:KEY_CONNECTION_PORT] unsignedIntValue];
	server.user = [dict objectForKey:KEY_CONNECTION_USERNAME];
	server.password = [dict objectForKey:KEY_CONNECTION_PASSWORD];
	server.schema = [dict objectForKey:KEY_CONNECTION_SCHEMA];

	connection = [[MysqlConnection connectToServer:server] retain];
	if (!connection) {
		[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE message:MESSAGEBOX_CANNOT_CONNECT_SERVER
									delegate:nil cancelButtonTitle:MESSAGEBOX_OKBUTTON_TITLE otherButtonTitles:nil] autorelease] show];
		[aHud show:NO];
		[server release];
		return;
	}
		
	MysqlFetch *result;
	@try {
		NSString *sql = [NSString stringWithFormat:@"select * from user where UDID='%@'", udid];
		result = [MysqlFetch fetchWithCommand:sql onConnection:connection];
	}
	@catch (MysqlException *e) {
		[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE message:MESSAGEBOX_CANNOT_EXECUTE
									delegate:nil cancelButtonTitle:MESSAGEBOX_OKBUTTON_TITLE otherButtonTitles:nil] autorelease] show];
		[aHud show:NO];
		[server release];
		return;
	}
		
	// If a user is not registered in database.
	if ([result.results count] == 0) {
		RegisterUserViewController *controller = [[RegisterUserViewController alloc] initWithMysqlConnection:connection];
		controller.modalPresentationStyle = UIModalPresentationFormSheet;
		[self presentModalViewController:controller animated:YES];
		[controller release];
	}
	else {
		NSDictionary *row = [result.results objectAtIndex:0];
		userid = [[row objectForKey:@"id"] unsignedIntValue];
	}
	[aHud show:NO];
	[server release];
	[self quiz];
}

- (void)evaluate
{
	if (selectedAnswerIndex == -1) {
		[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE message:MESSAGEBOX_QUIZ_SELECT 
									delegate:self cancelButtonTitle:MESSAGEBOX_OKBUTTON_TITLE 
						   otherButtonTitles:nil] autorelease] show];
		return;
	}
	
	if (userid == 0) {
		[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE message:MESSAGEBOX_USER_NOT_REGISTERED 
									delegate:self cancelButtonTitle:MESSAGEBOX_OKBUTTON_TITLE 
						   otherButtonTitles:nil] autorelease] show];
		titleLabel.hidden = YES;
		for (int i = 0; i < [answerLabels count]; i++) {
			UILabel *label = [answerLabels objectAtIndex:i];
			label.hidden = YES;
		}
		
		return;
	}
	
	// Check if the answer is correct, and select corresponding image.
	if (selectedAnswerIndex == correctAnswerIndex) {
		resultImageView.image = [UIImage imageNamed:@"correct.png"];
		nCorrectedAnswers ++;
	}
	else
		resultImageView.image = [UIImage imageNamed:@"incorrect.png"];
	
	resultImageView.hidden = NO;
	okButton.hidden = YES;
	
	// After delayed 1 second, dismiss result image.
	[self performSelector:@selector(hideResultView) withObject:nil afterDelay:1.0f];
	
	selectedAnswerIndex = -1;
}

- (void)quiz
{
	if (!connection)
		return;
	
	if (quizArray == nil)
		return;
	
	if (quizIndex >= [quizArray count]) {
		[self saveResult];
		return;
	}
	
	okButton.hidden = NO;
	// Get one quiz
	NSDictionary *quizEntry = (NSDictionary *)[quizArray objectAtIndex:quizIndex];
	
	// Quiz question
	titleLabel.text = [NSString stringWithFormat:@"%d. %@", quizIndex + 1, [quizEntry objectForKey:@"question"]];

	// Optional answers
	NSArray *answerArray = [quizEntry objectForKey:@"answers"];
	for (int i = 0; i < [answerLabels count]; i++) {
		UILabel *label = [answerLabels objectAtIndex:i];
		if (i < [answerArray count]) {
			label.font = [UIFont systemFontOfSize:17.0f];
			label.text = [NSString stringWithFormat:@"%c) %@", 'a' + i, [answerArray objectAtIndex:i]];
			label.hidden = NO;
		} else {
			label.hidden = YES;
		}
	}
	
	// Correct answer's index
	correctAnswerIndex = [[quizEntry objectForKey:@"correct"] intValue];

	// Increase index to get next quiz
	quizIndex++;
}

- (void)hideResultView
{
	resultImageView.hidden = YES;
	okButton.hidden = NO;
	
	// take next quiz
	[self quiz];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	// Select a answer
	UITouch *touch = [touches anyObject];
	CGPoint point = [touch locationInView:self.view];
	UIView *aView = [self.view hitTest:point withEvent:event];
	if ([aView isKindOfClass:[UILabel class]]) {
		[self selectAnswerLabel:aView];
	}
}

- (void)selectAnswerLabel:(id)aLabel
{
	// When a answer is selected, bold it, and restore others
	for (int i = 0; i < [answerLabels count]; i++) {
		UILabel *label = (UILabel *)[answerLabels objectAtIndex:i];
		if (label.hidden == YES)
			break;
		
		if ([label isEqual:aLabel]) {
			label.font = [UIFont boldSystemFontOfSize:18.0f];
			selectedAnswerIndex = i;
		} else {
			label.font = [UIFont systemFontOfSize:17.0f];
		}
	}
}

- (void)saveResult
{
	// hide all answer labels
	for (int i = 0; i < [answerLabels count]; i++) {
		UILabel *label = [answerLabels objectAtIndex:i];
		label.hidden = YES;
	}
	
	MerzAppDelegate *delegate = (MerzAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	// If passed quiz, unlock next document.		
	if (nCorrectedAnswers >= 14) {
		if (documentIndex < [delegate.keyArray count] - 1) {
			NSDictionary *dictionary = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"evaluation" ofType:@"plist"]];
			NSDictionary *entryDictionary = (NSDictionary *)[dictionary objectForKey:(NSString *)[delegate.keyArray objectAtIndex:documentIndex + 1]];		
			titleLabel.text = [NSString stringWithFormat:EVALUATION_SUCCESSED, nCorrectedAnswers, [entryDictionary objectForKey:@"title"]];
		}
		else
			titleLabel.text = [NSString stringWithFormat:EVALUATION_SUCCESSED, nCorrectedAnswers, [delegate.keyArray objectAtIndex:documentIndex]];

		if (delegate.availableDocIndex < [delegate.keyArray count] - 1)
			delegate.availableDocIndex ++;
	} else {
		titleLabel.text = [NSString stringWithFormat:EVALUATION_FAILED, nCorrectedAnswers];
	}
	okButton.hidden = YES;
	
	// Save in database
	@try {
		NSDate *date = [NSDate date];
		NSString *timeStamp = [date description];
		MysqlInsert *insert = [MysqlInsert insertWithConnection:connection];
		insert.table = DB_EVALUATIONTABLE_NAME;
		insert.rowData = [NSDictionary dictionaryWithObjectsAndKeys:
						  [NSNumber numberWithInt:userid], @"`user_id`", 
						  [NSNumber numberWithInt:documentIndex + 1], @"`PDFnum`", 
						  [NSNumber numberWithInt:nCorrectedAnswers], @"`numCorrectAnswers`", 
						  timeStamp, @"`timestamp`", nil];
		[insert execute];
	}
	@catch (MysqlException * e) {
		[[[[UIAlertView alloc] initWithTitle:MESSAGEBOX_TITLE message:MESSAGEBOX_CANNOT_EXECUTE
									delegate:nil cancelButtonTitle:MESSAGEBOX_OKBUTTON_TITLE otherButtonTitles:nil] autorelease] show];
	}
	
	// Save in local storage
	DocumentEntry *entry = (DocumentEntry *)[delegate.docEntryArray objectAtIndex:documentIndex];
	entry.numCorrectAnswers = nCorrectedAnswers;
	
	[delegate saveProgramState];
	
	nCorrectedAnswers = 0;
}

@end
