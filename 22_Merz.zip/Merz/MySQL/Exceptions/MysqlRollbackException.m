//
//  MysqlRollbackException.m
//  mysql_connector
//
//  Created by Karl Kraft on 2/23/10.
//  Copyright 2010 Karl Kraft. All rights reserved.
//

#import "MysqlRollbackException.h"


@implementation MysqlRollbackException

@end
