//
//  ViewController.h
//  AudioMixer
//
//  Created by Venus on 6/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>
#import <AudioToolbox/AudioToolbox.h>

@interface ViewController : UIViewController<MFMailComposeViewControllerDelegate>

@property (nonatomic, retain) IBOutlet UILabel *lblNote;
@property (nonatomic, retain) IBOutlet UIButton *btnPlay;
@property (nonatomic, retain) IBOutlet UIButton *btnSendEmail;

@property (nonatomic, retain) NSArray *arryAudios;

-(IBAction)clickBtnPlay:(id)sender;
-(IBAction)clickBtnSendEmail:(id)sender;

@end
