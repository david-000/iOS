//
//  ViewController.m
//  AudioMixer
//
//  Created by Venus on 6/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController
@synthesize btnPlay, btnSendEmail, lblNote, arryAudios;
#pragma mark - User Interaction Method

-(void)playAudio:(NSArray*)playlist{
    for (int i = 0; i < [playlist count]; i++) {
        NSURL *url = [NSURL fileURLWithPath:[playlist objectAtIndex:i]];
        AVAudioPlayer *player = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
        NSLog(@"asdf : %f", player.duration);
        [player prepareToPlay];
        [player play];
    }
}
-(IBAction)clickBtnPlay:(id)sender{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDirectory = [paths objectAtIndex:0];
    
    NSString *outputFilePath = [documentDirectory stringByAppendingPathComponent:@"output.wav"];
    if(![[NSFileManager defaultManager] fileExistsAtPath:outputFilePath]){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"Output file doesn't exist." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        [alert release];
        
        return;
    }
    
    NSArray *playlistArray = [NSArray arrayWithObjects:outputFilePath, nil];
    [self playAudio:playlistArray];
}
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    [self dismissModalViewControllerAnimated:YES];
}
-(IBAction)clickBtnSendEmail:(id)sender{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDirectory = [paths objectAtIndex:0];
    
    NSString *outputFilePath = [documentDirectory stringByAppendingPathComponent:@"output.wav"];
    if(![[NSFileManager defaultManager] fileExistsAtPath:outputFilePath]){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"Output file doesn't exist." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        [alert release];
        
        return;
    }
    
    
        
    NSURL *fileRecordURL = [[NSURL alloc] initFileURLWithPath:outputFilePath];
    NSData *dataToSend = [[NSData alloc] initWithContentsOfURL:fileRecordURL];
    
    [fileRecordURL release];
    
    
    
    // here you can access the object which triggered the method
    // for example you can check the tag value
    
    MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
    picker.mailComposeDelegate = self;
    
    [picker setSubject:@"Mixed Audio"];
    [picker setMessageBody:@"" isHTML:YES];
    
    [picker addAttachmentData:dataToSend mimeType:@"audio/x-wav" fileName:@"output.wav"];
    
    
    
    picker.navigationBar.barStyle = UIBarStyleBlack; // choose your style, unfortunately, Translucent colors behave quirky.
    
    [self presentModalViewController:picker animated:YES];
    
    [picker release];
}

-(void)composeAudios:(NSArray*)audioNames{
    AVMutableComposition* composition = [AVMutableComposition composition];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDirectory = [paths objectAtIndex:0];
    
    NSString *outputFilePath = [documentDirectory stringByAppendingPathComponent:@"output.wav"];
    NSURL *outputFileUrl = [[NSURL alloc] initFileURLWithPath:outputFilePath];
    
    if([[NSFileManager defaultManager] fileExistsAtPath:outputFilePath])
        [[NSFileManager defaultManager] removeItemAtPath:outputFilePath error:nil];
    
    int nCount = [audioNames count];
    for (int i = 0; i < nCount; i++) {
        NSString *songName = [[[audioNames objectAtIndex:i] componentsSeparatedByString:@"."] objectAtIndex:0];
        NSString *songExtension = [[[audioNames objectAtIndex:i] componentsSeparatedByString:@"."] objectAtIndex:1];
        
        NSURL *urlSong   = [[NSBundle mainBundle] URLForResource: songName
                                                    withExtension: songExtension];
        AVURLAsset* audioAsset = [[AVURLAsset alloc]initWithURL:urlSong options:nil];
        AVMutableCompositionTrack *audioTrack = [composition addMutableTrackWithMediaType:AVMediaTypeAudio 
                                                                          preferredTrackID:kCMPersistentTrackID_Invalid];
        [audioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, audioAsset.duration)
                             ofTrack:[[audioAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]
                              atTime:kCMTimeZero
                               error:nil];
    }
    
    AVAssetExportSession * ex = [[AVAssetExportSession alloc] initWithAsset:composition presetName:AVAssetExportPresetAppleM4A];
    
    ex.outputFileType = AVFileTypeAppleM4A;//@"com.apple.quicktime-audio";
    ex.outputURL = outputFileUrl;
	
    [ex exportAsynchronouslyWithCompletionHandler:
     ^(void ) {
         NSLog(@"export finished");
         
         btnPlay.hidden = NO;
         btnSendEmail.hidden = NO;
         lblNote.hidden = YES;
     }       
     ];
}
#pragma mark - Memory management
-(void)dealloc{
    [btnPlay release];
    [btnSendEmail release];
    [lblNote release];
    
    [arryAudios release];
    
    [super dealloc];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
//    
//    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
//    NSError *err = nil;
//    [audioSession setCategory :AVAudioSessionCategoryPlayback error:&err];
//    if(err){
//        NSLog(@"audioSession: %@ %d %@", [err domain], [err code], [[err userInfo] description]);
//        //return YES;
//    }
//    UInt32 doChangeDefaultRoute = 1;
//	AudioSessionSetProperty(kAudioSessionProperty_OverrideCategoryDefaultToSpeaker, sizeof(doChangeDefaultRoute), &doChangeDefaultRoute);
//    AudioSessionSetActive(true);
//    
//    [audioSession setActive:YES error:&err];
//    if(err){
//        NSLog(@"audioSession: %@ %d %@", [err domain], [err code], [[err userInfo] description]);
//        //return YES;
//    }

    self.arryAudios = [NSArray arrayWithObjects:@"song.mp3", @"C3.mp3", @"A2.mp3", @"B1.mp3", @"B2.mp3", @"C2.mp3", @"a-min.mp3", nil];
    
    [self composeAudios:arryAudios];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
