//
//  MusicTests.m
//  MusicTests
//
//  Created by Jeroen van Rijn on 09-06-11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MusicTests.h"


@implementation MusicTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in MusicTests");
}

@end
