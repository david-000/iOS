//
//  MusicTests.h
//  MusicTests
//
//  Created by Jeroen van Rijn on 09-06-11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface MusicTests : SenTestCase {
@private
    
}

@end
