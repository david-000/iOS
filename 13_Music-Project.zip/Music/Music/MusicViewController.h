//
//  MusicViewController.h
//  Music
//
//  Created by Jeroen van Rijn on 09-06-11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

@interface MusicViewController : UIViewController <MPMediaPickerControllerDelegate> {
    
    MPMusicPlayerController *musicPlayer;
        
    IBOutlet UIImageView *artworkImageView;
    IBOutlet UILabel *titleLabel;
    IBOutlet UILabel *artistLabel;
    IBOutlet UILabel *albumLabel;
    
    IBOutlet UISlider *volumeSlider;
    
    IBOutlet UIButton *playPauseButton;
    
    
}
@property (nonatomic, retain) MPMusicPlayerController *musicPlayer;

- (IBAction)showMediaPicker:(id)sender;

- (IBAction)volumeChanged:(id)sender;

- (IBAction)previousSong:(id)sender;
- (IBAction)playPause:(id)sender;
- (IBAction)nextSong:(id)sender;

- (void) registerMediaPlayerNotifications;


@end
