//
//  AppDelegate.h
//  FramePlayer
//
//  Created by lixing on 11/28/12.
//  Copyright (c) 2012 prosellersworlddev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"

extern float g_fScaleX;
extern float g_fScaleY;
extern BOOL g_isIPhone5;

@class MainViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MainViewController *mainViewController;
@property (nonatomic,retain) MBProgressHUD* loadingView;

+ (AppDelegate*) sharedAppDelegate;
+ (void) showWaitView :(NSString *) caption;
+ (void) hideWaitView;
@end
