//
//  MainViewController.m
//  FramePlayer
//
//  Created by lixing on 11/28/12.
//  Copyright (c) 2012 prosellersworlddev. All rights reserved.
//

#import "MainViewController.h"
#import "AppDelegate.h"

@interface MainViewController ()

@end

@implementation MainViewController
@synthesize m_btnFast, m_btnNextFrame, m_btnPlayStop, m_btnPrevFrame, m_btnSlow, m_previewimage, m_previewVideo;
@synthesize mAssetReader, mPlayer, mPlayerItem, mPlayerLayer, assetReaderOutput;
@synthesize m_currFileName, m_ptsLabel;

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.mPlayerItem = nil;
	self.mPlayer = nil;
	self.mPlayerLayer = nil;
    
    self.mAssetReader = nil;
	
    m_playState = PLAY_STATE_NONE;
    m_bPlaying = NO;

    m_currenttrack = 0;

    m_framesPerSecond = 30;
    m_currentPTS = 0;
    self.m_ptsLabel.text = @"";
    
    self.m_btnPlayStop.enabled = NO;
    self.m_btnFast.enabled = NO;
    self.m_btnNextFrame.enabled = NO;
    self.m_btnPrevFrame.enabled = NO;
    self.m_btnSlow.enabled = NO;
}

- (void)viewDidUnload {
    self.m_btnFast = nil;
    self.m_btnNextFrame = nil;
    self.m_btnPlayStop = nil;
    self.m_btnPrevFrame = nil;
    self.m_btnSlow = nil;
    self.m_previewimage = nil;
    self.m_previewVideo = nil;
    self.m_currFileName = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - video play
- (void) setPlayFile:(NSString *)filepath {
    self.m_btnPlayStop.enabled = YES;
    self.m_btnFast.enabled = YES;
    self.m_btnSlow.enabled = YES;
    self.m_btnNextFrame.enabled = YES;
    self.m_btnPrevFrame.enabled = YES;


    NSURL *outputURL = [[NSURL alloc] initFileURLWithPath:filepath];
    
    self.mPlayerItem = [AVPlayerItem playerItemWithURL:outputURL];
    if (self.mPlayer) {
        [self RemovePlayer];
    }
    
    AVAsset *asset = self.mPlayerItem.asset;
    NSArray *audioTracks = [asset tracksWithMediaType:AVMediaTypeAudio];
    
    // Mute all the audio tracks
    NSMutableArray *allAudioParams = [NSMutableArray array];
    for (AVAssetTrack *track in audioTracks) {
        AVMutableAudioMixInputParameters *audioInputParams =    [AVMutableAudioMixInputParameters audioMixInputParameters];
        [audioInputParams setVolume:0.0 atTime:kCMTimeZero];
        [audioInputParams setTrackID:[track trackID]];
        [allAudioParams addObject:audioInputParams];
    }
    AVMutableAudioMix *audioZeroMix = [AVMutableAudioMix audioMix];
    [audioZeroMix setInputParameters:allAudioParams];
    
    [self.mPlayerItem setAudioMix:audioZeroMix];
    
    self.mPlayer = [[AVPlayer playerWithPlayerItem:self.mPlayerItem] retain];
    
    self.mPlayerLayer = [AVPlayerLayer playerLayerWithPlayer:self.mPlayer];
    
    self.mPlayerLayer.videoGravity = AVLayerVideoGravityResizeAspect;
    
    [self.m_previewVideo.layer addSublayer:self.mPlayerLayer];
    
    [self SetPlayerFrame];
    
//    float duration = CMTimeGetSeconds([self.mPlayerItem duration]);
    CMTime duration = [self.mPlayerItem duration];
    m_totalframe = duration.value / 20 + 1;
    NSLog(@"total value is %d", duration.value);

}


- (UIImageOrientation) getVideoDirection :(AVAsset *)asset{
    UIImageOrientation orientation_  = UIImageOrientationUp;
	BOOL isPortrait_ = NO;
    
	NSArray *tracks = [asset tracksWithMediaType:AVMediaTypeVideo];
	if([tracks	count] != 0) {
		AVAssetTrack *videoTrack = [tracks objectAtIndex:0];
		CGAffineTransform t = videoTrack.preferredTransform;
		// Portrait
		if(t.a == 0 && t.b == 1.0 && t.c == -1.0 && t.d == 0)  {orientation_ = UIImageOrientationRight; isPortrait_ = YES;}
		// PortraitUpsideDown
		if(t.a == 0 && t.b == -1.0 && t.c == 1.0 && t.d == 0)  {orientation_ =  UIImageOrientationLeft; isPortrait_ = YES;}
		// LandscapeRight
		if(t.a == 1.0 && t.b == 0 && t.c == 0 && t.d == 1.0)   {orientation_ =  UIImageOrientationUp;}
		// LandscapeLeft
		if(t.a == -1.0 && t.b == 0 && t.c == 0 && t.d == -1.0) {orientation_ = UIImageOrientationDown;}
	}
    

    
    return orientation_;
}

- (CGRect) getVideoContentRectFitToScreen :(CGSize)naturalsize :(CGRect)playrect :(UIImageOrientation)direction {
    CGSize orgsize = naturalsize;
    CGSize screensize = playrect.size;
    CGSize newsize = CGSizeZero;
    
    if (direction == UIImageOrientationLeft || direction == UIImageOrientationRight) {
        orgsize = CGSizeMake(naturalsize.height, naturalsize.width);
    }
    
    if (orgsize.height == 0.0f || screensize.height == 0.0f)
        return CGRectZero;
    
    float rate1 = orgsize.width / orgsize.height;
    float rate2 = screensize.width / screensize.height;
    
    if (rate1 > rate2) {
        newsize = CGSizeMake(screensize.width, screensize.width / rate1);
    }
    else {
        newsize = CGSizeMake(screensize.height * rate1, screensize.height);
    }
    
    CGRect newRect = CGRectMake(playrect.origin.x + (screensize.width - newsize.width) / 2, playrect.origin.y + (screensize.height - newsize.height) / 2, newsize.width, newsize.height);
    
    return newRect;
}

- (CGSize)GetVideoSize:(AVAsset*)asset {
    NSArray * tracks = [asset tracksWithMediaType:AVMediaTypeVideo];
    
    for (int i = 0; i < tracks.count; i ++) {
        AVAssetTrack * track = [tracks objectAtIndex:i];
        return track.naturalSize;
    }
}


- (void) InitScale {
    CGRect screenrect = CGRectMake(0, 0, PLAY_SCREEN_WIDTH * g_fScaleX, PLAY_SCREEN_HEIGHT * g_fScaleY);
    
    UIImageOrientation orient = [self getVideoDirection:self.mPlayerItem.asset];
    
    UIImageOrientation orientSec = orient;
    float angle1 = 0;
    
    if (m_bRotated) {
        angle1 = M_PI / 2;
        switch (orientSec) {
            case UIImageOrientationUp:
                orientSec = UIImageOrientationRight;
                break;
            case UIImageOrientationRight:
                orientSec = UIImageOrientationDown;
                break;
            case UIImageOrientationDown:
                orientSec = UIImageOrientationLeft;
                break;
            case UIImageOrientationLeft:
                orientSec = UIImageOrientationUp;
                break;
                
            default:
                break;
        }
    }
    
    CGSize size = [self GetVideoSize:mPlayerItem.asset];//mPlayerItem.asset.naturalSize;
    
    CGRect videorect = [self getVideoContentRectFitToScreen:size :screenrect :orientSec];

    CGRect rotatedrect = videorect;
    rotatedrect = CGRectMake(PLAY_SCREEN_WIDTH * g_fScaleX / 2 - rotatedrect.size.width / 2, PLAY_SCREEN_HEIGHT * g_fScaleY / 2 - rotatedrect.size.height / 2, rotatedrect.size.width, rotatedrect.size.height);

    self.m_previewVideo.transform = CGAffineTransformMakeRotation(angle1);
    self.m_previewVideo.frame = rotatedrect;
    
    float angle = 0.0;
    
    switch (orient) {
        case UIImageOrientationLeft:
            angle = -M_PI/2;
            size = CGSizeMake(size.height, size.width);
            break;
            
        case UIImageOrientationRight:
            angle = M_PI/2;
            size = CGSizeMake(size.height, size.width);
            break;
            
        case UIImageOrientationDown:
            angle = M_PI;
        default:
            break;
    }

    NSLog(@"video %f %f %f %f", self.m_previewVideo.frame.origin.x, self.m_previewVideo.frame.origin.y, self.m_previewVideo.frame.size.width, self.m_previewVideo.frame.size.height);

    
    CGRect imagerect = rotatedrect;
    [self.m_previewimage setTransform: CGAffineTransformMakeRotation(angle + angle1)];
    self.m_previewimage.frame = imagerect;
}

- (void)SetPlayerFrame {
    if (self.mPlayerLayer == nil)
        return;

    [self InitScale];
    
    [self.mPlayerLayer setFrame:[self.m_previewVideo.layer bounds]];
    
    NSLog(@"layer %f %f %f %f", self.mPlayerLayer.frame.origin.x, self.mPlayerLayer.frame.origin.y, self.mPlayerLayer.frame.size.width, self.mPlayerLayer.frame.size.height);
}

- (void) continueBackground:(NSNotification*)notification {
    AVPlayerItem *p = notification.object;
    [p seekToTime:kCMTimeZero];
    
}

//- (void) PlayTimer :(NSTimer*)timer{
//}

- (void) StartPlayer{
    NSLog(@"Start player");
    [self StopFrameImageState];
    
    self.m_btnNextFrame.enabled = YES;
    self.m_btnPrevFrame.enabled = YES;

    self.m_ptsLabel.text = @"";
    [self.mPlayer seekToTime:CMTimeMakeWithSeconds(m_currenttrack, 600)];
    
    self.m_previewimage.image = nil;

    [self.mPlayer play];
    
//    m_playtimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector (PlayTimer:) userInfo:nil repeats:YES];

    self.mPlayer.actionAtItemEnd = AVPlayerActionAtItemEndNone;

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(continueBackground:) name:AVPlayerItemDidPlayToEndTimeNotification object:self.mPlayerItem];
    
    [self.m_btnPlayStop setTitle:@"Stop" forState:UIControlStateNormal];
    
}

- (void) StopPlayer {
    [self StopFrameImageState];
    self.m_btnNextFrame.enabled = YES;
    self.m_btnPrevFrame.enabled = YES;

  
    float curtime = CMTimeGetSeconds([self.mPlayer currentTime]);
    m_currenttrack = curtime;
    self.m_ptsLabel.text = [NSString stringWithFormat:@"%d/%d", (int)(m_currenttrack * 30 + 1), m_totalframe];

//    if (self.mPlayerLayer){
//        [self.mPlayerLayer removeFromSuperlayer];
//    }
    
    if (self.mPlayer) {
        [[NSNotificationCenter defaultCenter] removeObserver: self name:AVPlayerItemDidPlayToEndTimeNotification object:self.mPlayer.currentItem];
        [self.mPlayer pause];
    }
    
//    if (m_playtimer) {
//        [m_playtimer invalidate];
//        m_playtimer = nil;
//    }
    
    [self.m_btnPlayStop setTitle:@"Play" forState:UIControlStateNormal];
}

- (void) RemovePlayer {
    if (self.mPlayer) {
        [[NSNotificationCenter defaultCenter] removeObserver: self name:AVPlayerItemDidPlayToEndTimeNotification object:self.mPlayer.currentItem];
        [self.mPlayer pause];
        self.mPlayer = nil;
    }
    
    if (self.mPlayerLayer) {
        [self.mPlayerLayer removeFromSuperlayer];
        self.mPlayerLayer = nil;
    }
    
    if (m_playtimer) {
        [m_playtimer invalidate];
        m_playtimer = nil;
    }
    
    [self.m_btnPlayStop setTitle:@"Play" forState:UIControlStateNormal];
}

#pragma mark - frame action
- (CGImageRef) getSampleBuffer:(CMSampleBufferRef)samplebuffer {
    
    CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(samplebuffer);
    CVPixelBufferLockBaseAddress(imageBuffer,0);        // Lock the image buffer
    
    uint8_t *baseAddress = (uint8_t *)CVPixelBufferGetBaseAddressOfPlane(imageBuffer, 0);   // Get information of the image
    size_t bytesPerRow = CVPixelBufferGetBytesPerRow(imageBuffer);
    size_t width = CVPixelBufferGetWidth(imageBuffer);
    size_t height = CVPixelBufferGetHeight(imageBuffer);
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    
    //create context for capture original video frame
    CGContextRef Context1 = CGBitmapContextCreate(baseAddress, width, height, 8, bytesPerRow, colorSpace, kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedFirst);
    
    CGImageRef newImage1 = CGBitmapContextCreateImage(Context1);
    CGContextRelease(Context1);
    
    CGColorSpaceRelease(colorSpace);
    CVPixelBufferUnlockBaseAddress(imageBuffer,0);
    return newImage1;
}


#pragma mark - video frame play
- (void) SetFrameImage : (float*) gettime {
    
    
    NSString * filepath = self.m_currFileName;
    
    NSError *movieError = nil;
    NSURL *outputURL = [NSURL fileURLWithPath: filepath];
    
    AVPlayerItem * moviePlayerItem = [AVPlayerItem playerItemWithURL:outputURL];
    CMTime cmDuration = [moviePlayerItem duration];
    NSLog(@"cmduration = %d", cmDuration.value);
    float duration = CMTimeGetSeconds(cmDuration);
    
    
    if (*gettime > duration) {
        *gettime = duration;
        [self StopFrameImageState];
        return;
    }
    
    
    if (self.mAssetReader == nil) {
        NSLog(@"Create Assetreader");
        self.mAssetReader = [AVAssetReader assetReaderWithAsset:moviePlayerItem.asset error:&movieError];
        NSArray* videoTracks = [moviePlayerItem.asset tracksWithMediaType:AVMediaTypeVideo];
        AVAssetTrack* videoTrack = [videoTracks objectAtIndex:0];
        NSDictionary *videoOptions = [NSDictionary dictionaryWithObject:[NSNumber numberWithInt:kCVPixelFormatType_32BGRA] forKey:(id)kCVPixelBufferPixelFormatTypeKey];
        
        assetReaderOutput = [AVAssetReaderTrackOutput assetReaderTrackOutputWithTrack:videoTrack outputSettings:videoOptions];
        [self.mAssetReader addOutput:assetReaderOutput];
        
        float duration = CMTimeGetSeconds([moviePlayerItem duration]);
        CMTimeRange range = CMTimeRangeMake(CMTimeMakeWithSeconds(*gettime, 600), CMTimeMakeWithSeconds(duration - *gettime == 0 ? 0.03 : duration - *gettime, 600));
        [self.mAssetReader setTimeRange:range];
        
        [self.mAssetReader startReading];
    }
    CMSampleBufferRef nextBuffer;
    
    NSLog(@"reading buffer %f", *gettime);
    
    if ([self.mAssetReader status] == AVAssetReaderStatusReading) {
        if((nextBuffer = [assetReaderOutput copyNextSampleBuffer])) {
            
            CMTime pts = CMSampleBufferGetPresentationTimeStamp(nextBuffer);
            float time = CMTimeGetSeconds(pts);
            NSLog(@"time %f", time);
            *gettime = time;
            CGImageRef imageref = [self getSampleBuffer:nextBuffer];
            // if (time >= m_currenttime + 1.0 / 10.0) {
            UIImage * image = [UIImage imageWithCGImage:imageref];
            
            self.m_previewimage.image = image;
            CFRelease(nextBuffer);
            CGImageRelease(imageref);
            // }
        }
    }
    
}

- (void)refreshFrameThread {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [self StopFrameImageState];
    
    [self SetFrameImage:&m_currenttrack];
    
    self.m_ptsLabel.text = [NSString stringWithFormat:@"%d/%d", (int)(m_currenttrack * 30 + 1), m_totalframe];

    [AppDelegate hideWaitView];
    [pool release];
}

- (void) StopFrameImageState {
    if (self.mAssetReader) {
        [self.mAssetReader cancelReading];
        self.mAssetReader = nil;
    }
    self.m_ptsLabel.text = [NSString stringWithFormat:@"%d/%d", (int)(m_currenttrack * 30 + 1), m_totalframe];

    self.m_previewimage.image = nil;
}

- (void) CreateVideoExtractor {
    if (m_playState != PLAY_STATE_FRAME)
        return;
    
//    self.m_previewimage.hidden = NO;
}


- (void) GetNextScene {
    m_bImageProcessing = YES;
    
    m_currenttrack += 1 / m_framesPerSecond;
    if (m_currenttrack * 30 >= m_totalframe) {
        m_currenttrack = (m_totalframe - 1) / 30.0;
    }
    else {
        [self SetFrameImage:&m_currenttrack];

        self.m_ptsLabel.text = [NSString stringWithFormat:@"%d/%d", (int)(m_currenttrack * 30 + 1), m_totalframe];
    }
    m_bImageProcessing = NO;
    
    return;
}

- (void) GetPrevScene {
    
    m_bImageProcessing = YES;
    m_currenttrack -= 1/ m_framesPerSecond;

    if (m_currenttrack < 0)
    {
        m_currenttrack = 0;
    }
    [AppDelegate showWaitView:@""];
    
    [NSThread detachNewThreadSelector:@selector(refreshFrameThread) toTarget:self withObject:nil];
    
    return ;
}



#pragma mark - actions

- (IBAction) OnPlayStop :(UIButton *)sender {

    if (m_playState == PLAY_STATE_FRAME){
        self.m_previewimage.image = nil;
        
        [self StopFrameImageState];
        
//        self.m_previewimage.hidden = YES;
    }
    
    m_playState = PLAY_STATE_NORMAL;
    
    if (m_bPlaying == NO) {
        m_bPlaying = YES;
//        [self InitScale];
        [self SetPlayerFrame];
        
        [self StartPlayer];
        
    }
    else
    {
        m_bPlaying = NO;
        
        [self StopPlayer];
    }

}

- (IBAction) OnPrevFrame:(UIButton *)sender {
    if (m_bPlaying)
        return;
    [self GetPrevScene];
}

- (IBAction) OnNextFrame:(UIButton *)ssender {
    if (m_bPlaying)
        return;
    [self GetNextScene];
}

- (IBAction) OnFastPlay:(UIButton *)sender {
    self.mPlayer.rate = 2;
}

- (IBAction) OnSlowPlay:(UIButton *)sender {
    self.mPlayer.rate = 0.5;
}

- (IBAction) OnRotate:(UIButton *)sender {
    if (m_bRotated) {
        m_bRotated = NO;
    }
    else {
        m_bRotated = YES;
    }
  
    [self SetPlayerFrame];
//    [self InitScale];
}

- (IBAction) OnLoadVideo:(UIButton *)sender {
    [self RemovePlayer];
    [self StopFrameImageState];
    
    m_bRotated = NO;
    
    self.m_btnPlayStop.enabled = NO;
    self.m_btnFast.enabled = NO;
    self.m_btnNextFrame.enabled = NO;
    self.m_btnPrevFrame.enabled = NO;
    self.m_btnSlow.enabled = NO;

    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum])
    {
        UIImagePickerController *videoRecorder = [[UIImagePickerController alloc] init];
        videoRecorder.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;//UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        NSArray *mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeCamera];
        NSArray *videoMediaTypesOnly = [mediaTypes filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"(SELF contains %@)", @"movie"]];

        videoRecorder.delegate = self;
        videoRecorder.mediaTypes = videoMediaTypesOnly;
        videoRecorder.videoQuality = UIImagePickerControllerQualityTypeMedium;
        videoRecorder.videoMaximumDuration = 180;			//Specify in seconds (600 is default)

        
        
        if ([videoMediaTypesOnly count] == 0)		//Is movie output possible?
        {
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Sorry but your device does not support video recording"
                                                                     delegate:nil
                                                            cancelButtonTitle:@"OK"
                                                       destructiveButtonTitle:nil
                                                            otherButtonTitles:nil];
            [actionSheet showInView:self.view];
            [actionSheet autorelease];
        }
        else
        {
            
            if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
            {
                popoverController = [[UIPopoverController alloc] initWithContentViewController:videoRecorder];
                
                if ([popoverController isPopoverVisible]) {
                    //[popoverController dismissPopoverAnimated:YES];
                    [popoverController release];
                }
                else {
                    [popoverController presentPopoverFromRect:CGRectMake(334.0f, 150, 100.0f, 2.0f)
                                                       inView:self.view
                                     permittedArrowDirections:UIPopoverArrowDirectionAny
                                                     animated:YES];
                }
            }
            else
            {
                [self presentModalViewController:videoRecorder animated:YES];
                //        [controller.view addSubview:imagepicker.view];
                //        [controller presentModalViewController:imagepicker animated:YES];

            }
        }
    }
    else
    {
        //No camera is availble
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"No Camera Roll"
                                                            message:@"No camera Roll"
                                                           delegate:nil
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];
    }

}

#pragma mark - UIImagePickerController delegate

//***************************************
//***************************************
//********** RECORD VIDEO DONE **********
//***************************************
//***************************************
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    NSString *tempFilePath = [[info objectForKey:UIImagePickerControllerMediaURL] path];
    self.m_currFileName = tempFilePath;
    NSLog(@"temp path %@",tempFilePath);
    
    [self setPlayFile:tempFilePath];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        [popoverController dismissPopoverAnimated:YES];
        [popoverController release];
    }
    else
    {
        [picker dismissModalViewControllerAnimated:YES];
    }

}

//*****************************************
//*****************************************
//********** RECORD VIDEO CANCEL **********
//*****************************************
//*****************************************
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        [popoverController dismissPopoverAnimated:YES];
        [popoverController release];
    }
    else
        [self dismissModalViewControllerAnimated:YES];
}

@end
