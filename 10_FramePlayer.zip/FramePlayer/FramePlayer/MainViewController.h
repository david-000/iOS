//
//  MainViewController.h
//  FramePlayer
//
//  Created by lixing on 11/28/12.
//  Copyright (c) 2012 prosellersworlddev. All rights reserved.
//
#import <AVFoundation/AVFoundation.h>

#define NUMBER_MOVE_SPACE_LT 20
#define ACCEL_RATE 15
#define GEAR_SHOW_TIME 0.3
#define GEAR_HIDE_TIME 4

#define TIME_SCALE 600

//play frame
#define PLAY_SCREEN_WIDTH 320.0
#define PLAY_SCREEN_HEIGHT 425.0


enum {
    PLAY_STATE_NONE,
    PLAY_STATE_NORMAL,
    PLAY_STATE_FRAME,   //frame by frame
};

@interface MainViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate> {
    //slow motion
    float m_currenttrack;       //current show scene time
    int64_t m_currentPTS;         //last getframe using stepFrame
    float m_framesPerSecond;      //frame count per second
    NSMutableArray *m_frameCache;   //frame cache for back action
    BOOL m_bImageProcessing;
    
    UIPopoverController * popoverController;
    
    //check values
	BOOL m_bRecording;				//is recording started.
	BOOL m_bPlaying;				//is play started.
    
	//preview
	UIView * m_subview;     //preview on m_preview
	NSTimer *m_playtimer;
    
    int m_playState;    //PLAY_STATE
	
	NSString *m_currFileName;
    int m_totalframe;
    
    BOOL m_bRotated;//NO is portrait
}

@property (nonatomic, retain) IBOutlet  UIImageView *m_previewVideo;    //video play view
@property (nonatomic, retain) IBOutlet  UIImageView *m_previewimage;    //Slow motion view

@property (nonatomic, retain) IBOutlet UIButton * m_btnPrevFrame;
@property (nonatomic, retain) IBOutlet UIButton * m_btnPlayStop;
@property (nonatomic, retain) IBOutlet UIButton * m_btnFast;
@property (nonatomic, retain) IBOutlet UIButton * m_btnSlow;
@property (nonatomic, retain) IBOutlet UIButton * m_btnNextFrame;

@property (nonatomic, retain) AVPlayerItem *mPlayerItem;
@property (nonatomic, retain) AVPlayerLayer *mPlayerLayer;
@property (nonatomic, retain) AVPlayer *mPlayer;

@property (nonatomic, retain) AVAssetReader *mAssetReader;
@property (nonatomic, retain) AVAssetReaderTrackOutput *assetReaderOutput;
@property (nonatomic, retain)	NSString *m_currFileName;

@property (nonatomic, retain) IBOutlet UILabel * m_ptsLabel;

- (IBAction) OnPlayStop :(UIButton *)sender;
- (IBAction) OnPrevFrame:(UIButton *)sender;
- (IBAction) OnNextFrame:(UIButton *)ssender;
- (IBAction) OnFastPlay:(UIButton *)sender;
- (IBAction) OnSlowPlay:(UIButton *)sender;
- (IBAction) OnLoadVideo:(UIButton *)sender;

- (IBAction) OnRotate:(UIButton *)sender;

@end
