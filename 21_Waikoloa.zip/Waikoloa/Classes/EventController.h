//
//  EventController.h
//  Vacation
//
//  Created by Free on 11/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomCalView.h"

@interface EventController : UIViewController<CustomCalDelegate, UITextViewDelegate> {
	NSString*	szCurrentDate;
}
@property (nonatomic, retain) IBOutlet UITextView* itvDescription;
@property (nonatomic, retain) IBOutlet UIToolbar* itbBar;
@property (nonatomic, retain) NSString* szCurrentDate;

- (IBAction) goBack;
- (IBAction) editDone;

//- (void) requestText:(NSString*)szDay;

@end
