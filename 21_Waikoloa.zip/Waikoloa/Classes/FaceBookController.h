//
//  FaceBookController.h
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FBConnect.h"
#import "FBLoginButton.h"


@interface FaceBookController : UIViewController
<FBRequestDelegate,
FBDialogDelegate,
FBSessionDelegate,
UINavigationControllerDelegate,
UITextViewDelegate>
{
	Facebook* _facebook;
	NSArray* _permissions;
	
	UITextField*	m_tfName;
	UITextField*	m_tfPassword;
	
	BOOL m_bScrollUp;	
}
@property (readonly) Facebook *facebook;
@property (nonatomic, retain ) IBOutlet FBLoginButton* _fbButton;

@property (nonatomic, retain) IBOutlet UITextField* m_tfName;
@property (nonatomic, retain) IBOutlet UITextField* m_tfPassword;

- (IBAction) facebookLogin;
- (IBAction) goBack;
@end
