//
//  VacationRentalPage.h
//  Vacation
//
//  Created by Free on 11/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface VacationRentalPage : UIView {
	UILabel*	lblNights;
	UILabel*	lblBedrooms;
	UILabel*	lblLocation;	
	
	int nights;
	int bedroom;
	int locat;
}

- (void) resetLayout;
- (NSString*) getRentalInfo;
@end
