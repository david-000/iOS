//
//  WaikoloaController.m
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "WaikoloaController.h"
#import "MainInfo.h"

@implementation WaikoloaController

@synthesize m_tfName, m_tfPassword, m_waikoloDelegate;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
/*
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}*/
/*
- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}*/


- (void)viewDidLoad {
	
	m_bScrollUp = FALSE;
	
    [super viewDidLoad];
}


- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	self.m_waikoloDelegate = nil;
	[m_tfName release];
	[m_tfPassword release];
    [super dealloc];
}

#pragma mark ===
#pragma mark Login Button function
- (IBAction) waikoloaLogin {
	[[MainInfo getInstance] Login:[m_tfName text] :[m_tfPassword text]];
	[m_waikoloDelegate loginSuccess];//:[m_tfName text] :[m_tfPassword text]];
}

#pragma mark ===
#pragma mark UITextField Delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
	
	if ( !m_bScrollUp ){
		m_bScrollUp = TRUE;
			
		NSNotificationCenter* nc = [NSNotificationCenter defaultCenter];
		[nc addObserver:self 
			   selector:@selector(keyboardWillShow:) 
				   name:UIKeyboardWillShowNotification 
				 object:nil];
		[nc addObserver:self 
			   selector:@selector(keyboardWillHide:) 
				   name:UIKeyboardWillHideNotification 
				 object:nil];
		
	}
	
	return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	
	if ( textField == m_tfName ){
		[m_tfPassword becomeFirstResponder];
	}else {
		m_bScrollUp = FALSE;
		[textField resignFirstResponder];
	}
	
	return YES;
}

#pragma mark ===
#pragma mark UIWindow Keyboard Notifications
- (void) keyboardWillShow:(NSNotification*) notification {
	UIViewAnimationCurve animationCurve = [[[notification userInfo] valueForKey:UIKeyboardAnimationCurveUserInfoKey] intValue];
	NSTimeInterval animationDuration = [[[notification userInfo] valueForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
	
	CGRect keyboardBounds = [(NSValue*)[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
	
	[UIView beginAnimations:@"showKeyboardAnimation" context:nil];
	[UIView setAnimationCurve:animationCurve];
	[UIView setAnimationDuration:animationDuration];
	
	self.view.center = CGPointMake(160, 240 - keyboardBounds.size.height / 2);
	
	[UIView commitAnimations];
}

- (void) keyboardWillHide:(NSNotification*) notification {
	UIViewAnimationCurve animationCurve = [[[notification userInfo] valueForKey:UIKeyboardAnimationCurveUserInfoKey] intValue];
	NSTimeInterval animationDuration = [[[notification userInfo] valueForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
	CGRect keyboardBounds = [(NSValue*)[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];

	self.view.center = CGPointMake(160, 240 - keyboardBounds.size.height / 2);
	
	[UIView beginAnimations:@"hideKeyboardAnimation" context:nil];
	[UIView setAnimationCurve:animationCurve];
	[UIView setAnimationDuration:animationDuration];
	
	self.view.center = CGPointMake(160, 250);
	
	[UIView commitAnimations];
}

@end
