//
//  HomeController.h
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface HomeController : UIViewController {

}

- (void) setTopBarStyle:(int)style;

- (IBAction) searchVacation;
- (IBAction) searchRestaurant;
- (IBAction) facebookUs;
- (IBAction) flightsStatus;
- (IBAction) sitesToSee;
- (IBAction) scheduledEvent;
- (IBAction) directory;
- (IBAction) contactUs;

@end
