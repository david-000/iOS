//
//  SitesSeeController.h
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "CustomLoadingView.h"

@interface SitesSeeController : UIViewController<UITableViewDelegate, UITableViewDataSource, CLLocationManagerDelegate> {
	UITableView*	siteListView;
	
	UIImage*	_imgNormal;
	UIImage*	_imgHighlight;
	
	UIButton*	_btnSites;
	UIButton*	_btnBeaches;
	
	NSMutableArray* arrayList;
	CLLocationManager* localManager;
	
	NSString*	_szSearchKey;
	BOOL		_bLoading;
	BOOL		_bSites;
}

@property (nonatomic, retain) IBOutlet UITableView* siteListView;
@property (nonatomic, retain) IBOutlet UIButton*	_btnSites;
@property (nonatomic, retain) IBOutlet UIButton*	_btnBeaches;
@property (nonatomic, retain) IBOutlet UIImage*	_imgNormal;
@property (nonatomic, retain) IBOutlet UIImage*	_imgHighlight;
@property (nonatomic, retain) NSMutableArray* arrayList;
@property (nonatomic, retain) IBOutlet CustomLoadingView* loadingView;

- (void) requestData:(NSString*)lat :(NSString*)lng;
- (IBAction) goBack;
- (IBAction) sitesAction;
- (IBAction) beachesAction;

@end
