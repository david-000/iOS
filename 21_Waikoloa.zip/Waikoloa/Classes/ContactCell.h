//
//  ContactCell.h
//  Vacation
//
//  Created by Free on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ContactCell : UITableViewCell {

}

@property (nonatomic, retain) IBOutlet UILabel* lblPersonName;
@property (nonatomic, retain) IBOutlet UILabel* mobilePhoneNumber;
@property (nonatomic, retain) IBOutlet UILabel* iphonePhoneNumber;
@property (nonatomic, retain) IBOutlet UILabel* homePhoneNumber;

@end
