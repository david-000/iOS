//
//  VacationAppDelegate.h
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WaikoloaController.h"
#import "FBViewController.h"
@interface VacationAppDelegate : NSObject <UIApplicationDelegate, WaikoloaDelegate> {
    
    UIWindow *window;
	WaikoloaController*	waikoloaViewController;
	UINavigationController* homeViewController;
	FBViewController* facebookControllerk;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet WaikoloaController*	waikoloaViewController;
@property (nonatomic, retain) IBOutlet UINavigationController* homeViewController;
@property (nonatomic, assign) FBViewController* facebookController;

- (void) animationTransition:(int) nType :(int) nDir :(NSTimeInterval) fTime;

@end

