//
//  RestaurantInfo.m
//  Vacation
//
//  Created by Free on 11/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RestaurantInfo.h"


@implementation RestaurantInfo
@synthesize _szRestaurantName, _szAddress, _szImage, _szInformation, _szRating, _szRecommend, _szDistance, _szLatitude, _szLongitude, _szWeatherState, _szWeatherTemper;

- (void) dealloc {
	[_szRestaurantName release];
	[_szImage release];
	[_szAddress release];
	[_szInformation release];
	[_szRating release];
	[_szRecommend release];
	[_szDistance release];
	[_szLatitude release];
	[_szLongitude release];
	[_szWeatherState release];
	[_szWeatherTemper release];
	[super dealloc];
}
@end
