//
//  XMLSitesReader.m
//  Vacation
//
//  Created by Free on 11/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "XMLSitesReader.h"


@implementation XMLSitesReader

@synthesize currentContents, results, _siteInfomation;

- (void)parserXMLWithData:(NSData*)data parseError:(NSError**)error {
	self.results = [NSMutableArray arrayWithCapacity:50];
	parsedRSSItemsCounter = 0;

	NSXMLParser *parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
    [parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
	[parser parse];
	[parser release];
}

- (void)parseXMLFileAtURL:(NSURL *)URL parseError:(NSError **)error {
	NSXMLParser *parser = [[NSXMLParser alloc] initWithContentsOfURL:URL];
	parsedRSSItemsCounter = 0;
	
	self.results = [NSMutableArray arrayWithCapacity:50];
	
    // Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
    [parser setDelegate:self];	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    
    [parser parse];
    
    NSError *parseError = [parser parserError];
    if (parseError && error) {
        *error = parseError;
    }
    
    [parser release]; 	
}

- (void)parserDidStartDocument:(NSXMLParser *)parser
{
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName) {
        elementName = qName;
    }
	
	if ([elementName isEqualToString:@"item"]) {
		
        parsedRSSItemsCounter++;
		self._siteInfomation = [[SiteInfo alloc] init];
		[self._siteInfomation release];	
    }else if ([elementName isEqualToString: @"sites_name"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"beache_name"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"image"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"description"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"distance"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"reviews"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"latitude"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"longitude"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"weather_state"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"weather_temper"]) {
		self.currentContents = [NSMutableString string];
    }else {
		self.currentContents = nil;
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{ 
	if (qName) {
		elementName = qName;
	}
	
	self.currentContents = (NSMutableString*)[self.currentContents stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];

	if(([self.currentContents compare:@""] == NSOrderedSame)){
		self.currentContents = [NSMutableString stringWithString:@""];
	}
	
	if ([elementName isEqualToString: @"sites_name"]) {
		self._siteInfomation._szTitle = self.currentContents;
	}else if ([elementName isEqualToString: @"beache_name"]) {
		self._siteInfomation._szTitle = self.currentContents;
	}else if ([elementName isEqualToString: @"image"]) {
		self._siteInfomation._szImgThumb = self.currentContents;
	}else if ([elementName isEqualToString: @"description"]) {
		self._siteInfomation._szDescription = self.currentContents;
	}else if ([elementName isEqualToString: @"reviews"]) {
		self._siteInfomation._szReview = self.currentContents;
	}else if ([elementName isEqualToString: @"distance"]) {
		self._siteInfomation._szDistance = self.currentContents;
	}else if ([elementName isEqualToString: @"latitude"]) {		
		self._siteInfomation._szLatitude = self.currentContents;
	}else if ([elementName isEqualToString: @"longitude"]) {
		self._siteInfomation._szLongitude = self.currentContents;
	}else if ([elementName isEqualToString: @"weather_state"]) {
		self._siteInfomation._szWeather_state = self.currentContents;
	}else if ([elementName isEqualToString: @"weather_temper"]) {		
		self._siteInfomation._szWeather_temper = self.currentContents;
    }else if ([elementName isEqualToString:@"item"]) {
		[self addToSiteItemsList:self._siteInfomation];
	}
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	string = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];

	if([string length] == 0)
		return;	
	
    if (self.currentContents) {
		[self.currentContents appendString:string];	
    }
	
}

- (void)addToSiteItemsList:(SiteInfo *)newRSSItem {
	[self.results addObject:newRSSItem];
}

- (void) dealloc {
	[_siteInfomation release];
	[currentContents release];
	[results release];
	[super dealloc];
}
@end
