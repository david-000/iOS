//
//  MainInfo.m
//  Vacation
//
//  Created by Free on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MainInfo.h"


static MainInfo* g_instance = nil;

@implementation MainInfo

+(MainInfo*) getInstance {
	if ( g_instance == nil )
		g_instance = [[self alloc] init];
	
	return g_instance;
}

- (void) Login:(NSString*)uid :(NSString*)pwd {
	if ( [uid isEqualToString:@"admin"] && [pwd isEqualToString:@"admin"] )
		bIsAdmin = TRUE;
	else 
		bIsAdmin = FALSE;
}

- (BOOL) IsAdminAccount {
	return bIsAdmin;
}

- (NSString*) getTodayDate {
	NSCalendar* myCal = [NSCalendar currentCalendar];
	NSDate* today = [NSDate date];
	NSDateComponents* todayInfo = [myCal components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:today];
	
	return [NSString stringWithFormat:@"%d-%d-%d", [todayInfo year], [todayInfo month], [todayInfo day]];
}

- (void) dealloc {
	[super dealloc];
}

@end
