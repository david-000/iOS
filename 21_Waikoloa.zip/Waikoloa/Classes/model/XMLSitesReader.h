//
//  XMLSitesReader.h
//  Vacation
//
//  Created by Free on 11/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SiteInfo.h"

@interface XMLSitesReader : NSObject<NSXMLParserDelegate> {
	BOOL bIsEmpty;
	
	SiteInfo*	_siteInfomation;
	
	NSMutableString*	currentContents;
	NSMutableArray*		results;
	
    int totalRecords;
	int parsedRSSItemsCounter;
}

@property (nonatomic, retain) SiteInfo*	_siteInfomation;
@property (nonatomic, retain) NSMutableString* currentContents;
@property (nonatomic, retain) NSMutableArray* results;

- (void)parserXMLWithData:(NSData*)data parseError:(NSError**)error;
- (void)parseXMLFileAtURL:(NSURL *)URL parseError:(NSError **)error;
- (void)addToSiteItemsList:(SiteInfo *)newRSSItem;

@end
