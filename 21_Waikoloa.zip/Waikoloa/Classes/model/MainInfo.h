//
//  MainInfo.h
//  Vacation
//
//  Created by Free on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VarTable.h"

@interface MainInfo : NSObject {
	BOOL	bIsAdmin;
}

+(MainInfo*) getInstance;

- (void) Login:(NSString*)uid :(NSString*)pwd;
- (BOOL) IsAdminAccount;
- (NSString*) getTodayDate;
@end
