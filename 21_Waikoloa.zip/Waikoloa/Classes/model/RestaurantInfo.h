//
//  RestaurantInfo.h
//  Vacation
//
//  Created by Free on 11/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface RestaurantInfo : NSObject {
	NSString*	_szRestaurantName;
	NSString*	_szAddress;
	NSString*	_szImage;
	NSString*	_szInformation;
	NSString*	_szRating;
	NSString*	_szRecommend;
	NSString*	_szDistance;
	NSString*	_szLatitude;
	NSString*	_szLongitude;
	NSString*	_szWeatherState;
	NSString*	_szWeatherTemper;	
}

@property (nonatomic, retain) NSString* _szRestaurantName;
@property (nonatomic, retain) NSString*	_szAddress;
@property (nonatomic, retain) NSString* _szImage;
@property (nonatomic, retain) NSString* _szInformation;
@property (nonatomic, retain) NSString* _szRating;
@property (nonatomic, retain) NSString* _szRecommend;
@property (nonatomic, retain) NSString* _szDistance;
@property (nonatomic, retain) NSString* _szLatitude;
@property (nonatomic, retain) NSString* _szLongitude;
@property (nonatomic, retain) NSString* _szWeatherState;
@property (nonatomic, retain) NSString* _szWeatherTemper;

@end
