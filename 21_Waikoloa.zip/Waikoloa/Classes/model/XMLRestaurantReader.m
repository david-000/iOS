//
//  XMLRestaurantReader.m
//  Vacation
//
//  Created by Free on 11/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "XMLRestaurantReader.h"


@implementation XMLRestaurantReader
@synthesize currentContents, results, _restaurantInfomation;
- (void)parserXMLWithData:(NSData*)data parseError:(NSError**)error {
	self.results = [NSMutableArray arrayWithCapacity:50];
	parsedRSSItemsCounter = 0;
	
	NSXMLParser *parser = [[NSXMLParser alloc] initWithData:data];
    [parser setDelegate:self];
    [parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
	[parser parse];
	[parser release];
}

- (void)parseXMLFileAtURL:(NSURL *)URL parseError:(NSError **)error {
	NSXMLParser *parser = [[NSXMLParser alloc] initWithContentsOfURL:URL];
	parsedRSSItemsCounter = 0;
	
	self.results = [NSMutableArray arrayWithCapacity:50];
	
    // Set self as the delegate of the parser so that it will receive the parser delegate methods callbacks.
    [parser setDelegate:self];	
    // Depending on the XML document you're parsing, you may want to enable these features of NSXMLParser.
    [parser setShouldProcessNamespaces:NO];
    [parser setShouldReportNamespacePrefixes:NO];
    [parser setShouldResolveExternalEntities:NO];
    
    [parser parse];
    
    NSError *parseError = [parser parserError];
    if (parseError && error) {
        *error = parseError;
    }
    
    [parser release]; 	
}

- (void)parserDidStartDocument:(NSXMLParser *)parser
{
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
	if (qName) {
        elementName = qName;
    }
	
	if ([elementName isEqualToString:@"item"]) {
		
        parsedRSSItemsCounter++;
		self._restaurantInfomation = [[RestaurantInfo alloc] init];
		[self._restaurantInfomation release];	
    }else if ([elementName isEqualToString: @"restaurant_name"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"image"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"address"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"information"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"rating"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"recommend"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"distance"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"latitude"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"longitude"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"weather_state"]) {
		self.currentContents = [NSMutableString string];
	}else if ([elementName isEqualToString: @"weather_temper"]) {
		self.currentContents = [NSMutableString string];
    }else {
		self.currentContents = nil;
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{ 
	if (qName) {
		elementName = qName;
	}
	
	self.currentContents = (NSMutableString*)[self.currentContents stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	if(([self.currentContents compare:@""] == NSOrderedSame)){
		self.currentContents = [NSMutableString stringWithString:@""];
	}
	
	if ([elementName isEqualToString: @"restaurant_name"]) {
		self._restaurantInfomation._szRestaurantName = self.currentContents;
	}else if ([elementName isEqualToString: @"image"]) {
		self._restaurantInfomation._szImage = self.currentContents;
	}else if ([elementName isEqualToString: @"address"]) {
		self._restaurantInfomation._szAddress = self.currentContents;		
	}else if ([elementName isEqualToString: @"information"]) {
		self._restaurantInfomation._szInformation = self.currentContents;
	}else if ([elementName isEqualToString: @"rating"]) {
		self._restaurantInfomation._szRating = self.currentContents;
	}else if ([elementName isEqualToString: @"recommend"]) {
		self._restaurantInfomation._szRecommend = self.currentContents;
	}else if ([elementName isEqualToString: @"distance"]) {
		self._restaurantInfomation._szDistance = self.currentContents;		
	}else if ([elementName isEqualToString: @"latitude"]) {		
		self._restaurantInfomation._szLatitude = self.currentContents;
	}else if ([elementName isEqualToString: @"longitude"]) {
		self._restaurantInfomation._szLongitude = self.currentContents;
	}else if ([elementName isEqualToString: @"weather_state"]) {
		self._restaurantInfomation._szWeatherState = self.currentContents;
	}else if ([elementName isEqualToString: @"weather_temper"]) {		
		self._restaurantInfomation._szWeatherTemper = self.currentContents;
    }else if ([elementName isEqualToString:@"item"]) {
		[self addToRestaurantItemsList:self._restaurantInfomation];
	}
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	string = [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	if([string length] == 0)
		return;	
	
    if (self.currentContents) {
		[self.currentContents appendString:string];	
    }
	
}

- (void)addToRestaurantItemsList:(RestaurantInfo *)newRSSItem {
	[self.results addObject:newRSSItem];
}

- (void) dealloc {
	[_restaurantInfomation release];
	[currentContents release];
	[results release];
	[super dealloc];
}

@end
