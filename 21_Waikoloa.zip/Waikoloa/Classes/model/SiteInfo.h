//
//  SiteInfo.h
//  Vacation
//
//  Created by Free on 11/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SiteInfo : NSObject {
	NSString*	_szTitle;
	NSString*	_szDescription;
	NSString*	_szReview;
	NSString*	_szDistance;
	NSString*	_szImgThumb;
	NSString*	_szLatitude;
	NSString*	_szLongitude;
	NSString*	_szWeather_state;
	NSString*	_szWeather_temper;
}

@property (nonatomic, retain) NSString* _szTitle;
@property (nonatomic, retain) NSString* _szDescription;
@property (nonatomic, retain) NSString* _szReview;
@property (nonatomic, retain) NSString* _szDistance;
@property (nonatomic, retain) NSString* _szLatitude;
@property (nonatomic, retain) NSString* _szLongitude;
@property (nonatomic, retain) NSString* _szWeather_state;
@property (nonatomic, retain) NSString* _szWeather_temper;
@property (nonatomic, retain) NSString*	_szImgThumb;

@end
