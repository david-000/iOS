//
//  XMLRestaurantReader.h
//  Vacation
//
//  Created by Free on 11/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RestaurantInfo.h"

@interface XMLRestaurantReader : NSObject<NSXMLParserDelegate>  {
	RestaurantInfo*	_restaurantInfomation;
	
	NSMutableString*	currentContents;
	NSMutableArray*		results;
	
    int totalRecords;
	int parsedRSSItemsCounter;
}
@property (nonatomic, retain) RestaurantInfo*	_restaurantInfomation;
@property (nonatomic, retain) NSMutableString* currentContents;
@property (nonatomic, retain) NSMutableArray* results;

- (void)parserXMLWithData:(NSData*)data parseError:(NSError**)error;
- (void)parseXMLFileAtURL:(NSURL *)URL parseError:(NSError **)error;
- (void)addToRestaurantItemsList:(RestaurantInfo *)newRSSItem;
@end
