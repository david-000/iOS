//
//  SiteInfo.m
//  Vacation
//
//  Created by Free on 11/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SiteInfo.h"


@implementation SiteInfo
@synthesize _szTitle, _szDescription, _szReview, _szDistance, _szImgThumb,
			_szLatitude, _szLongitude, _szWeather_state, _szWeather_temper;

- (void) dealloc {
	[_szTitle release];
	[_szDescription release];
	[_szReview release];
	[_szDistance release];
	[_szImgThumb release];
	[_szLatitude release];
	[_szLongitude release];
	[_szWeather_state release];
	[_szWeather_temper release];
	[super dealloc];
}

@end
