//
//  RestaurantsController.m
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RestaurantsController.h"
#import "RestaurantCell.h"
#import "XMLRestaurantReader.h"
#import "RestaurantInfo.h"
#import "ResDetailController.h"
#import "common.h"
#import "ASIFormDataRequest.h"

@implementation RestaurantsController
@synthesize searchListView, arrayList, loadingView;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	recommendList = [[NSMutableArray alloc] init];
	
	self.loadingView.hidden = NO;
	[loadingView launchAnimation];
	
	localManager = [[CLLocationManager alloc] init];
	localManager.delegate = self;
	localManager.distanceFilter = kCLDistanceFilterNone;
	localManager.desiredAccuracy = kCLLocationAccuracyBest;
	[localManager startUpdatingLocation];
	
	//TableView setting
	self.searchListView.backgroundColor = [UIColor clearColor];
	self.searchListView.separatorColor = [UIColor clearColor];
	self.searchListView.rowHeight = 90;
	
	self.view.userInteractionEnabled = FALSE;
}

#pragma mark -
#pragma mark Button Actions
- (IBAction) goBack {
	[self.navigationController popViewControllerAnimated:YES];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillDisappear:(BOOL)animated {	
	
//	[localManager stopUpdatingLocation];
//	[localManager setDelegate:nil];
}

- (void)dealloc {
	[loadingView terminateAnimation];
	[loadingView release];
	[recommendList release];
	[localManager release];
	[arrayList release];
	[searchListView release];
    [super dealloc];
}

#pragma mark ===
#pragma mark UITextField Delegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	
	[textField resignFirstResponder];
	
	return YES;
}

- (IBAction) searchTextChange:(UITextField*)textField {
	if ( [textField.text isEqualToString:@""] ){
		bRecommend = FALSE;
	}else {
		bRecommend = TRUE;

		NSString* key = [textField.text lowercaseString];
		
		[recommendList removeAllObjects];
		for ( RestaurantInfo *ri in arrayList ){
//			NSComparisonResult result = [ri._szRestaurantName compare:textField.text 
//															  options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch) 
//																range:NSMakeRange(0, textField.text)];
			
			//NSRange rsResultRange = [ri._szRestaurantName rangeOfString:textField.text
//																options:NSCaseInsensitiveSearch];			
		
			if ( [[ri._szRestaurantName lowercaseString] hasPrefix:key] )
				[recommendList addObject:ri];
			
		}
	}
	
	[searchListView reloadData];
}

#pragma mark -
#pragma mark UITableView Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {	
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {	
	return (!bRecommend) ? [arrayList count]: [recommendList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *CellIdentifier = @"RestaurantCell";    

	RestaurantCell* cell = (RestaurantCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {		
		UIViewController* myCell = [[UIViewController alloc] initWithNibName:@"RestaurantCell" bundle:nil];
		cell = (RestaurantCell*)myCell.view;
		[myCell release];
		
		UIImageView* cell_bg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"cell.png"]];
		cell.backgroundView = cell_bg;
		[cell_bg release];
    }

	RestaurantInfo* ri = nil;

	if ( !bRecommend )
		ri = (RestaurantInfo*)[arrayList objectAtIndex:indexPath.row];
	else 
		ri = (RestaurantInfo*)[recommendList objectAtIndex:indexPath.row];
	
	cell._lbTitle.text = ri._szRestaurantName;
	cell._lbDescript.text = ri._szInformation;
	cell._lbDistance.text = [NSString stringWithFormat:@"%d", [ri._szDistance intValue]];
	[cell._rating setRating:20*[ri._szRating intValue]];
    
    return cell;	
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
	cell.backgroundColor = [UIColor clearColor];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	
	RestaurantInfo* ri = nil;
	if ( !bRecommend )
		ri = (RestaurantInfo*)[arrayList objectAtIndex:indexPath.row];
	else 
		ri = (RestaurantInfo*)[recommendList objectAtIndex:indexPath.row];
	
	ResDetailController* rdc = [[ResDetailController alloc] initWithRestaurantInfo:ri];
	[self.navigationController pushViewController:rdc animated:YES];
	[rdc release];
}

#pragma mark -
#pragma mark CLLocationManager delegate
- (void)locationManager:(CLLocationManager *)manager
	didUpdateToLocation:(CLLocation *)newLocation
		   fromLocation:(CLLocation *)oldLocation{
	
	[manager stopUpdatingLocation];	
	
	NSString* lat = [NSString stringWithFormat:@"%g", newLocation.coordinate.latitude];
	NSString* lng = [NSString stringWithFormat:@"%g", newLocation.coordinate.longitude];
	[self requestData:lat :lng];
}

- (void)locationManager:(CLLocationManager *)manager
	   didFailWithError:(NSError *)error {
	[manager stopUpdatingLocation];
	
	[self requestData:@"0" :@"0"];
}

- (void) requestData:(NSString*)lat :(NSString*)lng {
	
	[localManager stopUpdatingLocation];
	
	NSString* szRequest = [NSString stringWithFormat:@"%@%@", SERVER_URL, RESTAURANT_URL];
	
	ASIFormDataRequest* request1 = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:szRequest]];	
	[request1 setRequestMethod:@"POST"];
	[request1 setPostValue:lat forKey:@"lat"];
	[request1 setPostValue:lng forKey:@"lng"];
	[request1 setDelegate:self];
	[request1 setDidFinishSelector:@selector(requestDone:)];
	[request1 setDidFailSelector:@selector(requestFailed:)];
	[request1 startAsynchronous];
}

#pragma mark -
#pragma mark ASIHTTPRequest delegate

- (void)requestDone:(ASIFormDataRequest*)sender {

	self.view.userInteractionEnabled = TRUE;
	
	[loadingView terminateAnimation];
	self.loadingView.hidden = YES;
	
	NSData* responseData = [sender responseData];
	XMLRestaurantReader* xmlParser = [[XMLRestaurantReader alloc] init];
	[xmlParser parserXMLWithData:responseData parseError:nil];
	self.arrayList = xmlParser.results;
	[xmlParser release];	
	
	[searchListView reloadData];
}

- (void)requestFailed:(ASIFormDataRequest*)sender {
	self.view.userInteractionEnabled = TRUE;	
	
	[loadingView terminateAnimation];
	self.loadingView.hidden = YES;
	
	[searchListView reloadData];
}
@end
