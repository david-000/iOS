//
//  VarTable.h
//  KIMINOZO
//
//  Created by Venus on 8/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface VarTable : NSObject {
	NSMutableDictionary *m_dict;
	int value_type;
	
}
-(id)initWithType:(int )nType;
-(void)clear;
-(NSString*)getStringValue:(NSString*)key;
-(int)getIntValue:(NSString*)key;
-(BOOL)getBooleanValue:(NSString*)key;

-(BOOL)save:(NSString*)fileName;
-(BOOL)load:(NSString*)fileName;

-(void)putString:(NSString *) strValue key:(NSString*)key;
-(void)putInt:(int)nValue key:(NSString*)key;
-(void)putBool:(BOOL)bValue key:(NSString*)key;
@end
