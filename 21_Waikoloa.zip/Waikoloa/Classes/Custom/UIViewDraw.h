//
//  UIViewDraw.h
//  MEMO2
//
//  Created by Administrator on 09/09/26.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ImageErrorOccured

-(void) errorOccured:(NSString*)content;

@end

#define DEGREES_TO_RADIANS(__ANGLE__) ((__ANGLE__) * 0.01745329252f) // PI / 180

/** @def RADIANS_TO_DEGREES
 converts radians to degrees
 */
#define RADIANS_TO_DEGREES(__ANGLE__) ((__ANGLE__) * 57.29577951f) // PI * 180


@interface UIView (Draw) <ImageErrorOccured>


#pragma mark ================================
#pragma mark       Context속성설정관련함수
#pragma mark ================================

- (CGContextRef) getCurrentContext;

- (void) setContextAlpha :(CGFloat)  fAlpha;
- (void) setFillColor    :(UIColor*) color;
- (void) setStrokeColor  :(UIColor*) color;
- (void) setLineWidth    :(int)      nLineWidth;
- (void) setClip         :(CGMutablePathRef) path;


#pragma mark ================================
#pragma mark		선그리기관련함수
#pragma mark ================================

// 두점으로 선그리기
- (void) drawLineTwoPoint:(CGPoint)  ptFrom  :(CGPoint) ptTo;
- (void) drawLineTwoPoint:(CGPoint)  ptFrom  :(CGPoint) ptTo :(CGFloat) nLineWidth :(UIColor*) clrLine :(CGFloat) fAlpha;

// 점배렬로 선그리기
- (void) drawLineArrPoint:(CGPoint*) ptArray :(int) nSize    :(CGFloat) fAlpha;
- (void) drawLineArrPoint:(CGPoint*) ptArray :(int) nSize    :(CGFloat) nLineWidth :(UIColor*) clrLine :(CGFloat) fAlpha;

// 토막선그리기
- (void) drawSegmentLine :(CGPoint*) ptArray :(int) nSize    :(CGFloat)nLineWidth :(UIColor*) clrLine :(CGFloat) fAlpha;

// 원호그리기
- (void) drawArc:(CGPoint) ptCenter :(CGFloat) fRadius :(CGFloat) fSAngel    :(CGFloat)  fEAngel   :(BOOL) bClock :(CGFloat) nLineWidth :(UIColor*) clrStroke :(CGFloat) fAlpha;
- (void) drawArc:(CGPoint*)ptArray  :(CGFloat) fRadius :(CGFloat) nLineWidth :(UIColor*) clrStroke :(CGFloat) fAlpha;

// 베제곡선그리기
- (void) drawBezier:(CGPoint) ptStart :(CGPoint) ptEnd :(CGPoint) ptControl0 :(CGFloat) nLineWidth :(UIColor*) clrStroke  :(CGFloat)  fAlpha;
- (void) drawBezier:(CGPoint) ptStart :(CGPoint) ptEnd :(CGPoint) ptControl0 :(CGPoint) ptControl1 :(CGFloat)  nLineWidth :(UIColor*) clrStroke :(CGFloat) fAlpha;

// 선끝점형태설정
- (void) setCapLineType:(CGLineCap)   lineCap;

// 선련결부분형태설정
- (void) setJoinLineType:(CGLineJoin) lineJoin;

// 점선형태설정
- (void) setDashLineType:(CGFloat) fPhase :(CGFloat*) dashArray :(int) nSize;

#pragma mark ================================
#pragma mark		다각형그리기관련함수
#pragma mark ================================

// 사각형그리기
- (void) drawStorkeRect:(CGRect) rcRect;
- (void) drawStorkeRect:(CGRect) rcRect :(UIColor*) clrStroke :(CGFloat)  nLineWidth :(CGFloat)  fAlpha;
- (void) drawFillRect  :(CGRect) rcRect :(UIColor*) clrFill   :(CGFloat)  fAlpha;
- (void) drawFillRect  :(CGRect) rcRect :(UIColor*) clrFill   :(UIColor*) clrStroke  :(CGFloat)  nLineWidth :(CGFloat) fAlpha;
- (void) drawRoundRect :(CGRect) rcRect :(CGFloat)  fRadius   :(UIColor*) clrFill    :(UIColor*) clrStroke  :(CGFloat) nLineWidth :(CGFloat) fAlpha;

// 선패턴설정
- (void) drawRectWithColorPattern  :(CGRect) rcRect;
- (void) drawRectWithUnColorPattern:(CGRect) rcRect :(CGFloat*) clrFill;


// 다각형그리기
- (void) drawStar   :(CGPoint) ptCenter :(CGFloat) fRadius :(UIColor*) clrStroke :(UIColor*) clrFill   :(CGFloat) nLineWidth :(CGFloat) fAlpha;
- (void) drawPolygon:(CGPoint) ptCenter :(CGFloat) fRadius :(int) nPolygons      :(UIColor*) clrStroke :(UIColor*)clrFill    :(CGFloat) nLineWidth :(CGFloat) fAlpha;

#pragma mark ================================
#pragma mark		원그리기관련함수
#pragma mark ================================

// 원그리기
- (void) drawEllipse:(CGRect) rcEllipse :(UIColor*) clrStroke :(UIColor*)clrFill :(CGFloat) nLineWidth :(CGFloat) fAlpha;

#pragma mark ================================
#pragma mark		그라디엔트그리기관련함수
#pragma mark ================================

// Gradient그리기
- (void) drawLineGradient  :(CGRect) rcRect :(CGFloat*) arrColor :(int) nSize :(CGFloat) fAlpha;
- (void) drawRadialGradient:(CGRect) rcRect :(CGFloat*) arrColor :(int) nSize :(CGFloat) fAlpha;

#pragma mark ================================
#pragma mark		 이메지그리기관련함수
#pragma mark ================================

// 이메지읽기
- (UIImage*) getImageFromFile      :(NSString*) resource;
- (UIImage*) getImageCachedFromFile:(NSString*) resource;
- (UIImage*) getImageFromData      :(Byte*)     pImageData :(int) nWidth :(int) nHeight;
- (UIImage*) getClipImage          :(UIImage*)  imgSource  :(CGRect) subRect;
- (UIImage*) getRotateImage        :(UIImage*)  imgSource  :(UIImageOrientation) orientation;
- (UIImage*) getImageFromScreen;
- (UIImage*) resizeImage:(UIImage*) imgSource :(int)nWidth :(int)nHeight;

// 이메지그리기
- (void) drawImage:(UIImage*) image :(int)  x :(int) y;
- (void) drawImage:(UIImage*) image :(int)  x :(int) y  :(float) fAlpha;
- (void) drawBlend:(UIImage*) image :(int)  x :(int) y  :(float) fAlpha :(CGBlendMode) blendMode;
- (void) drawImage:(UIImage*) image :(int) sx :(int) sy :(int) dx :(int) dy :(int) width :(int) heigh;
- (void) drawImage:(UIImage*) image :(int) sx :(int) sy :(int) dx :(int) dy :(int) sw    :(int) sh :(int) dw :(int) dh;
- (void) drawImage:(UIImage*) image :(int) sx :(int) sy :(int) dx :(int) dy :(int) sw    :(int) sh :(int) dw :(int) dh :(float) fAlpha;
- (void) drawTitleImage:(UIImage*) image :(CGRect) rcRect :(CGFloat) fAlpha;


#pragma mark ================================
#pragma mark		 마스크그리기관련함수
#pragma mark ================================

// 마스크이메지 창조
- (UIImage*) getMaskImage          :(UIImage*) maskImage;
- (UIImage*) getImageWithMaskImage :(UIImage*) imgSource :(UIImage*) maskImage;
- (UIImage*) getImageWithMaskColor :(UIImage*) imgSource :(CGFloat*) maskColor;
- (UIImage*) drawImageWithMaskImage:(UIImage*) orgImage  :(UIImage*) maskImage :(CGRect) rcRect;
- (UIImage*) getImageMaskForBrightness:(UIImage*) imgSource :(int) nValue;
- (UIImage*) getImageFromContextWithImage:(UIImage*) imgSource;
- (UIImage*) getImageFromContextWithColor:(UIColor*) clrSource;
- (UIImage*) convertImageToGrayscale:(UIImage*)i;
- (UIImage*) zoomPixelImage:(UIImage*)i :(float)zf;
-(CGImageRef) CreateCGImageByZoomingImage:(CGImageRef)inImage :(CGFloat) zoomFactor;
- (UIImage*) convertImageToRGB:(UIImage*)i :(int)type :(float)r :(float)g :(float)b :(float)a;
- (UIImage*) procBlendEffect:(UIImage*)i :(int)type :(float)r :(float)g :(float)b  :(float)a;
- (UIImage*) nagativeImage:(UIImage*)i;
- (UIImage*) grirryImage:(UIImage*)i;
- (UIImage*) grirryChrImage:(UIImage*)i;
- (CGContextRef) CreateARGBBitmapContext:(CGImageRef) inImage;
- (CGImageRef) CreateCGImageByBlurringImage:(CGImageRef)inImage :(NSUInteger)pixelRadius :(NSUInteger)gaussFactor;
- (UIImage *)blurredCopyUsingGuassFactor:(UIImage*)i :(int)gaussFactor andPixelRadius:(int)pixelRadius;
#pragma mark ================================
#pragma mark		 본문그리기관련함수
#pragma mark ================================

// 문자렬그리기
-(void) vir_drawString:(NSString*) fmn :(int) x :(int) y :(UIColor*) color   :(UIFont*)  font;
-(void) vir_drawString:(NSString*) fmn :(int) x :(int) y :(UIColor*) bkcolor :(UIColor*) stcolor :(UIFont*) font;

-(CGSize)    getStringSize:(NSString*)fmn :(UIFont*)font;
-(NSString*) convertBanToZenString:(NSString*) strOrigin;
-(NSString*) convertZenToBanString:(NSString*) strOrigin;

#pragma mark ================================
#pragma mark		 창문관련함수
#pragma mark ================================

-(void) clearAllSubView;
- (void) clearAllSubView:(int) tag;
-(void) clearSubView:(int) tag;

#pragma mark ================================
#pragma mark		 애니메션관련함수
#pragma mark ================================

-(void) animationTransition:(int) nType :(int) nDir :(NSTimeInterval) fTime;

#pragma mark ================================
#pragma mark		 기타관련함수
#pragma mark ================================

-(CGFloat) DegreesToRadians:(CGFloat) degrees;
-(CGFloat) RadiansToDegrees:(CGFloat) radians;




@end
