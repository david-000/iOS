//
//  CustomRatingBar.h
//  Vacation
//
//  Created by Free on 11/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomRatingBar : UIView {
	UIImage*	m_imgEmptyRating;
	UIImage*	m_imgFullRating;
	
	int	m_nTotalRating;
}

@property (nonatomic, retain) UIImage* m_imgEmptyRating;
@property (nonatomic, retain) UIImage* m_imgFullRating;

- (void) setRating:(int)rating_value;

@end
