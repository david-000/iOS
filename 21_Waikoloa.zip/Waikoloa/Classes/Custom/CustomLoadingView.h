//
//  CustomLoadingView.h
//  Vacation
//
//  Created by Free on 11/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomLoadingView : UIView {
	UIActivityIndicatorView*	mLoadActivity;
}

- (void) launchAnimation;
- (void) restartAnimation;
- (void) terminateAnimation;

@end
