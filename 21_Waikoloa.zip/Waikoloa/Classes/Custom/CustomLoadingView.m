//
//  CustomLoadingView.m
//  Vacation
//
//  Created by Free on 11/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CustomLoadingView.h"
#import <QuartzCore/QuartzCore.h>

#define STATUS_HEIGHT	60

@implementation CustomLoadingView


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];		
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void) launchAnimation {
	self.hidden = NO;
	
	self.backgroundColor = [UIColor clearColor];
	
	UIView* mVwBackground = [[UIView alloc] initWithFrame:self.bounds];
	mVwBackground.alpha = 0.6;
	mVwBackground.backgroundColor = [UIColor blackColor];
	mVwBackground.layer.cornerRadius = 6.0;
	[self addSubview:mVwBackground];
	[mVwBackground release];
	
	CGRect rtFrm = self.bounds;
	
	mLoadActivity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
	mLoadActivity.center = CGPointMake(rtFrm.size.width / 2, rtFrm.size.height / 3);
	[self addSubview:mLoadActivity];
	[mLoadActivity startAnimating];
	
	UILabel* lblStatus = [[UILabel alloc] initWithFrame:CGRectMake(0, rtFrm.size.height - STATUS_HEIGHT, rtFrm.size.width, STATUS_HEIGHT)];
	[lblStatus setFont:[UIFont fontWithName:@"Helvetica-Bold" size:16]];
	lblStatus.backgroundColor = [UIColor clearColor];
	lblStatus.textAlignment = UITextAlignmentCenter;
	lblStatus.textColor = [UIColor whiteColor];
	[lblStatus setText:@"Loading"];
	[self addSubview:lblStatus];
	[lblStatus release];
}

- (void) restartAnimation {
	[mLoadActivity startAnimating];
	self.hidden = NO;
}

- (void) terminateAnimation {
	[mLoadActivity stopAnimating];
	self.hidden = YES;
}

- (void)dealloc {
    [super dealloc];
}


@end
