//
//  VarTable.m
//  KIMINOZO
//
//  Created by Venus on 8/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "VarTable.h"



@implementation VarTable

-(id)initWithType:(int )nType{
	self = [super init];
	m_dict = [[NSMutableDictionary alloc] init];
	value_type = nType;
	return self;
}

-(void)clear{
	if(m_dict!=nil)
		[m_dict removeAllObjects];
}
///use global
-(BOOL)save:(NSString*)fileName{
	NSString *strPath = [NSString stringWithFormat:@"%@.dat", fileName ] ;
	
	NSArray* paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString* documentsDirectory = [paths objectAtIndex:0];
	if (!documentsDirectory) {
		NSLog(@"Documents directory not found!");
		return FALSE;
	}
	NSString *strFilePath = [[NSString alloc] initWithFormat:@"%@/%@",documentsDirectory,strPath];
	
	[m_dict writeToFile:strFilePath atomically:YES];
	[strFilePath release];
	return TRUE;
}

-(BOOL)load:(NSString*)fileName{
	//[m_dict removeAllObjects];
	[m_dict release];
	NSString *strPath = [NSString stringWithFormat:@"%@.dat", fileName ] ;
	
	NSArray* paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString* documentsDirectory = [paths objectAtIndex:0];
	if (!documentsDirectory) {
		NSLog(@"Documents directory not found!");
		return FALSE;
	}
	NSString *strFilePath = [[NSString alloc] initWithFormat:@"%@/%@",documentsDirectory,strPath];
	
	if (![[NSFileManager defaultManager] fileExistsAtPath:strFilePath]) {
		m_dict = [[NSMutableDictionary alloc] init];
		[strFilePath release];
		return FALSE;
	}

	m_dict = [[NSMutableDictionary alloc] initWithContentsOfFile:strFilePath];
	[strFilePath release];
	return TRUE;
}
///use local
//-(BOOL)save:(NSString*)fileName{
//	return FALSE;
//}
//
//-(BOOL)load:(NSString*)fileName{
//	return FALSE;
//}

-(NSString*)getStringValue:(NSString*)key{
	
	@try
    {
		return (NSString*)[m_dict objectForKey:key] ;
    }
    @catch(NSException* ex)
    {
		return @"";
    }

	return @"";
}


-(int)getIntValue:(NSString*)key{
	@try
    {
       return [[m_dict objectForKey:key] intValue];
    }
    @catch(NSException* ex)
    {
		return 0;
    }
	return 0;
}


-(BOOL)getBooleanValue:(NSString*)key{
	
	@try
    {
		return [[m_dict objectForKey:key] boolValue];
    }
    @catch(NSException* ex)
    {
		return FALSE;
    }
	return FALSE;
}


-(void)putString:(NSString *) strValue key:(NSString*)key{
	[m_dict setObject:strValue forKey:key];
}

-(void)putInt:(int)nValue key:(NSString*)key{
	[m_dict setObject:[NSString stringWithFormat:@"%d", nValue] forKey:key];
}

-(void)putBool:(BOOL)bValue key:(NSString*)key{
	if(bValue)
		[m_dict setObject:[NSString stringWithFormat:@"1"] forKey:key];
	else
		[m_dict setObject:[NSString stringWithFormat:@"0"] forKey:key];
}

-(void)dealloc{
	if(m_dict!=nil)
		[m_dict release];
	m_dict = nil;
	[super dealloc];
}
@end
