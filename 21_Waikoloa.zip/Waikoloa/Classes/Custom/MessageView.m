//
//  MessageView.m
//  ApplicationLoader
//
//  Created by Wang Xue on 8/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MessageView.h"
#import <QuartzCore/QuartzCore.h>

@implementation MessageView


- (id)initWithFrame:(CGRect)frame withMessage:(NSString*)message {
    
    self = [super initWithFrame:frame];
    if (self) {
		
        self.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.7];
		
		animationView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle: UIActivityIndicatorViewStyleWhiteLarge];
		animationView.center = CGPointMake(frame.size.width / 2,frame.size.height / 2 - 10);
		[self addSubview:animationView];
		[animationView release];
		
		messageView = [[UILabel alloc] initWithFrame:CGRectMake(20, frame.size.height / 2 + 45, frame.size.width - 20, frame.size.height / 2 - 80)];
		messageView.lineBreakMode = UILineBreakModeCharacterWrap;
		messageView.numberOfLines  = 3;
		messageView.text = message;
		messageView.textAlignment = UITextAlignmentCenter;
		messageView.backgroundColor  = [UIColor clearColor];
		messageView.textColor = [UIColor whiteColor];
//		messageView.shadowColor = [UIColor blackColor];
//		messageView.shadowOffset = CGSizeMake(0, 1);
		[self addSubview:messageView];
		[messageView release];
		
		self.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
		UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin;
		
		self.layer.cornerRadius = 7.0;
		self.layer.borderColor = [[UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:1.0] CGColor];
		self.layer.borderWidth = 1;
		
//		self.layer.shadowColor = [[UIColor blackColor] CGColor];
//		self.layer.shadowOffset = CGSizeMake(3, 3);
//		self.layer.shadowOpacity = 0.8;
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)showInView:(UIView*)belowView {

	[animationView startAnimating];
	[belowView addSubview:self];
	[belowView bringSubviewToFront:self];
	
	self.transform = CGAffineTransformMakeScale(0.1, 0.1);
	[UIView beginAnimations:@"scale" context:NULL];
	self.transform = CGAffineTransformMakeScale(1.2, 1.2);
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDuration:0.2];
	[UIView commitAnimations];
}

- (void)close {
	
	[animationView stopAnimating];
	[self removeFromSuperview];
}

- (void)dealloc {
	
   [super dealloc];
}

- (void)animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context {
	
	if ([animationID isEqualToString:@"scale"]) {
		
		[UIView beginAnimations:nil context:NULL];
		self.transform = CGAffineTransformMakeScale(1.0, 1.0);
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDuration:0.2];
		[UIView commitAnimations];
		
		return;
	}
	
	self.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.7];
}

@end
