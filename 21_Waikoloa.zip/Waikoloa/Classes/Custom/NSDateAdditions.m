/* 
 * Copyright (c) 2009 Keith Lazuka
 * License: http://www.opensource.org/licenses/mit-license.html
 */

#import "NSDateAdditions.h"

@implementation NSDate (KalAdditions)

- (NSDate *)cc_dateByMovingToBeginningOfDay
{
  unsigned int flags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
  NSDateComponents* parts = [[NSCalendar currentCalendar] components:flags fromDate:self];
  [parts setHour:0];
  [parts setMinute:0];
  [parts setSecond:0];
  return [[NSCalendar currentCalendar] dateFromComponents:parts];
}

- (NSDate *)cc_dateByMovingToEndOfDay
{
  unsigned int flags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
  NSDateComponents* parts = [[NSCalendar currentCalendar] components:flags fromDate:self];

  [parts setHour:23];
  [parts setMinute:59];
  [parts setSecond:59];
  return [[NSCalendar currentCalendar] dateFromComponents:parts];
}

- (NSDate *)cc_dateByMovingToFirstDayOfTheMonth
{
  NSDate *d = nil;
  BOOL ok = [[NSCalendar currentCalendar] rangeOfUnit:NSMonthCalendarUnit startDate:&d interval:NULL forDate:self];
  NSAssert1(ok, @"Failed to calculate the first day the month based on %@", self);
  return d;
}

- (NSDate*) cc_dateByMovingToThePreviousYear
{
	NSDateComponents *c = [[[NSDateComponents alloc] init] autorelease];
	c.year = -1;
	return [[NSCalendar currentCalendar] dateByAddingComponents:c toDate:self options:0]; 	
}

- (NSDate*) cc_dateByMovingToTheFollowYear
{
	NSDateComponents *c = [[[NSDateComponents alloc] init] autorelease];
	c.year = 1;
	return [[NSCalendar currentCalendar] dateByAddingComponents:c toDate:self options:0]; 	
}

- (NSDate *)cc_dateByMovingToFirstDayOfThePreviousMonth
{
  NSDateComponents *c = [[[NSDateComponents alloc] init] autorelease];
  c.month = -1;
  return [[[NSCalendar currentCalendar] dateByAddingComponents:c toDate:self options:0] cc_dateByMovingToFirstDayOfTheMonth];  
}

- (NSDate *)cc_dateByMovingToFirstDayOfTheFollowingMonth
{
  NSDateComponents *c = [[[NSDateComponents alloc] init] autorelease];
  c.month = 1;
  return [[[NSCalendar currentCalendar] dateByAddingComponents:c toDate:self options:0] cc_dateByMovingToFirstDayOfTheMonth];
}

- (NSDate*)cc_dateByMovingToJumps:(int)_year :(int)_month {
	NSDateComponents *c = [[[NSDateComponents alloc] init] autorelease];
	c.year = _year;
	c.month = _month;	
	return [[[NSCalendar currentCalendar] dateByAddingComponents:c toDate:self options:0] cc_dateByMovingToFirstDayOfTheMonth];
}

- (NSDateComponents *)cc_componentsForMonthDayAndYear
{
  return [[NSCalendar currentCalendar] components:NSYearCalendarUnit|NSMonthCalendarUnit|NSDayCalendarUnit fromDate:self];
}

- (NSUInteger)cc_weekday
{
  return [[NSCalendar currentCalendar] ordinalityOfUnit:NSDayCalendarUnit inUnit:NSWeekCalendarUnit forDate:self];
}

- (NSUInteger)cc_numberOfDaysInMonth
{
  return [[NSCalendar currentCalendar] rangeOfUnit:NSDayCalendarUnit inUnit:NSMonthCalendarUnit forDate:self].length;
}

- (NSString*) today {
	NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
	[dateFormat setFormatterBehavior:NSDateFormatterBehavior10_4];
//	[dateFormat setDateFormat:@"yyyy-MM-dd"];
	[dateFormat setDateFormat:@"dd"];
	
	NSString* strDate = [dateFormat stringFromDate:[NSDate date]];
	
	[dateFormat release];
	
	
	return strDate;	
}

- (int) getNowDate:(int) type :(NSDate*)today{
	int ret = 0;
	
	@try{
		NSCalendar* myCal = [NSCalendar currentCalendar];
		
		NSDateComponents* todayInfo = [myCal components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit 
									   | NSHourCalendarUnit | NSMinuteCalendarUnit
									   | NSSecondCalendarUnit | NSWeekdayCalendarUnit fromDate:today];

		if (type == 0) ret = [todayInfo year];
		if (type == 1) ret = [todayInfo month];
		if (type == 2) ret = [todayInfo day];
		if (type == 3) ret = [todayInfo hour];
		if (type == 4) ret = [todayInfo minute];
		if (type == 5) ret = [todayInfo second];
		if (type == 6) ret = [todayInfo weekday];
	}
	@catch (id exception){
	}
	
	return ret;
}

@end