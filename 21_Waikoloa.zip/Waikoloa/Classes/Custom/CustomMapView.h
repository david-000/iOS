//
//  CustomMapView.h
//  Vacation
//
//  Created by Free on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface PinAnnotation : NSObject <MKAnnotation> {
	CLLocationCoordinate2D	m_locCoordinate;
}
- (id)initWithCoordinate:(CLLocationCoordinate2D)coordinate;
@end

@interface CustomMapView : UIView {
	MKMapView	*m_viwMap;
}

- (void) loadMapInfo:(NSString*)szLatitude :(NSString*)szLongitude;

@end
