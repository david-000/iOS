//
//  MessageView.h
//  ApplicationLoader
//
//  Created by Wang Xue on 8/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MessageView : UIView {

	UIActivityIndicatorView* animationView;
	UILabel*  messageView;
}

- (id)initWithFrame:(CGRect)frame withMessage:(NSString*)message;
- (void)showInView:(UIView*)belowView;
- (void)close;
	
@end
