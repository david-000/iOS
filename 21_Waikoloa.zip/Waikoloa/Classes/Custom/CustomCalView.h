//
//  CustomCalView.h
//  Vacation
//
//  Created by Free on 11/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CustomCalDelegate

- (void) didSelectedDay:(NSString*)selectDay;

@end


@interface CustomCalView : UIView {
	int	mYear;
	int mMonth;
	int mDay;
	int mToday;
	
	int daysInSelectedMonth;
	int daysInFinalWeekOfPreviousMonth;
	int daysInFirstWeekOfFollowingMonth;

	NSDate *baseDate;	
	UILabel* lblCurrentDate;
	NSDateFormatter *monthAndYearFormatter;
	UIImage*	img_sel_bg;
	
	id<CustomCalDelegate> myDelegate;
}
@property (nonatomic, retain) NSDate *baseDate;    // The first day of the currently selected month
@property (nonatomic, assign) id<CustomCalDelegate> myDelegate;
@property (nonatomic, retain) UIImage* img_sel_bg;

- (id) initWithDate:(NSDate*)date :(BOOL)bInit;

- (void) addControlBar;
- (void) clearOldDays;
- (void) updateCalendar;
- (NSString*) getToday;

- (void) recalculateVisibleDays;
- (NSUInteger)numberOfDaysInPreviousPartialWeek;
- (NSUInteger)numberOfDaysInFollowingPartialWeek;
- (int)calculateDaysInFinalWeekOfPreviousMonth;
//- (int)calculateDaysInSelectedMonth;
- (int)calculateDaysInFirstWeekOfFollowingMonth;
@end
