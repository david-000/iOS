//
//  CustomCalView.m
//  Vacation
//
//  Created by Free on 11/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CustomCalView.h"
#import "NSDateAdditions.h"
#import "UIViewDraw.h"

#define TILE_W	35
#define TILE_H	30

#define TILE_INDENT		22
#define TILE_SPACE_H	5

#define CONTROL_BAR_H	65

#define MAX_DAYS	35

@implementation CustomCalView
@synthesize baseDate, myDelegate, img_sel_bg;

- (id) initWithDate:(NSDate*)date :(BOOL)bInit {
	self = [super init];
	if ( self != nil ){
		self.frame = CGRectMake(0, 0, 320, 220);
		self.backgroundColor = [UIColor clearColor];
		
		UIImageView* ivwBG = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"rental_cal.png"]];
		[ivwBG setFrame:self.frame];
		[self addSubview:ivwBG];
		[ivwBG release];
		
		self.img_sel_bg = [UIImage imageNamed:@"sel_day.png"];
		
		self.baseDate = [[NSDate date] cc_dateByMovingToFirstDayOfTheMonth];

		monthAndYearFormatter = [[NSDateFormatter alloc] init];
		[monthAndYearFormatter setDateFormat:@"LLLL yyyy"];
		
		mToday = [[baseDate today] intValue];
		
		[self addControlBar];
		
		if ( !bInit )
			mDay = [baseDate getNowDate:2 :date];
		else 
			mDay = 0;
		
		if ( !bInit ){
			
			//selected year and month
			int s_y = [baseDate getNowDate:0 :date];
			int s_m = [baseDate getNowDate:1 :date];
			
			//current year and month
			int c_y = [baseDate getNowDate:0 :[NSDate date]];
			int c_m = [baseDate getNowDate:1 :[NSDate date]];
			
			int d_y = abs(s_y-c_y);
			int d_m = s_m-c_m;
			
			int offset_y = (s_y == c_y) ? 0: ((s_y<c_y) ? -1: 1);
			int tm = d_y * (offset_y*12) + d_m;
			
			self.baseDate = [baseDate cc_dateByMovingToJumps:0 :tm];
		}
		
		[self recalculateVisibleDays];
	}
	
	return self;
}

- (NSString*) getToday {
	return [NSString stringWithFormat:@"%d-%d-%d", mYear, mMonth, mDay];
}

- (NSUInteger)numberOfDaysInPreviousPartialWeek
{
	return [self.baseDate cc_weekday] - 1;
}

- (NSUInteger)numberOfDaysInFollowingPartialWeek
{
	NSDateComponents *c = [self.baseDate cc_componentsForMonthDayAndYear];
	c.day = [self.baseDate cc_numberOfDaysInMonth];
	NSDate *lastDayOfTheMonth = [[NSCalendar currentCalendar] dateFromComponents:c];
	return 7 - [lastDayOfTheMonth cc_weekday];
}


- (int)calculateDaysInFinalWeekOfPreviousMonth
{
	NSDate *beginningOfPreviousMonth = [self.baseDate cc_dateByMovingToFirstDayOfThePreviousMonth];
	int n = [beginningOfPreviousMonth cc_numberOfDaysInMonth];
	int numPartialDays = [self numberOfDaysInPreviousPartialWeek];
	
	return (n+1) - (n -(numPartialDays - 1));
}

- (int)calculateDaysInFirstWeekOfFollowingMonth
{
	NSUInteger numPartialDays = [self numberOfDaysInFollowingPartialWeek];
	return numPartialDays;
}

- (void) recalculateVisibleDays {
	mYear = [baseDate getNowDate:0 :baseDate];
	mMonth = [baseDate getNowDate:1 :baseDate];

	
	daysInSelectedMonth = [self.baseDate cc_numberOfDaysInMonth];	
	daysInFinalWeekOfPreviousMonth = [self calculateDaysInFinalWeekOfPreviousMonth];

	lblCurrentDate.text = [monthAndYearFormatter stringFromDate:self.baseDate];
	
	[self updateCalendar];
}

- (void) updateCalendar {	
	int mStartWeekDay = daysInFinalWeekOfPreviousMonth;
	[self clearOldDays];

	
	for ( int i = 0; i < daysInSelectedMonth; i++){
		int s = ((mStartWeekDay+i)%7 < 7) ? (mStartWeekDay+i): i;
		
		UIButton* btnDay = (UIButton*)[self viewWithTag:100+s];//[[UIButton alloc] initWithFrame:rtDay];
		if ( mToday != (i+1))
			[btnDay setTitleColor:[UIColor colorWithRed:49/255.f green:112/255.f blue:112/255.f alpha:1.0]
						 forState:UIControlStateNormal];
		else 
			[btnDay setTitleColor:[UIColor redColor] 
						 forState:UIControlStateNormal];
		
		if ( s%7 == 0 || s%7 == 6 ) //sunday
			[btnDay setTitleColor:[UIColor colorWithRed:255/255.f green:108/255.f blue:0 alpha:1.0]
						 forState:UIControlStateNormal];
		
		[btnDay setTitle:[NSString stringWithFormat:@"%d", i+1] forState:UIControlStateNormal];
		[btnDay addTarget:self action:@selector(selDay:) forControlEvents:UIControlEventTouchUpInside];
		
		if ( mDay == (i+1) )
			[btnDay setBackgroundImage:self.img_sel_bg forState:UIControlStateNormal];
		else 
			[btnDay setBackgroundImage:nil forState:UIControlStateNormal];
	}
}

- (void) selDay:(id)sender {
	UIButton* btnDay = (UIButton*)sender;
	
	if ( [btnDay.titleLabel.text isEqualToString:@""] )
		return;
	
	mDay = [btnDay.titleLabel.text intValue];
	[self updateCalendar];
	
	[myDelegate didSelectedDay:[NSString stringWithFormat:@"%d-%d-%@", mYear, mMonth, btnDay.titleLabel.text]];
}

- (void) clearOldDays {
	for ( int i = 0; i < MAX_DAYS; i++ ){
		UIButton* btnDay = (UIButton*)[self viewWithTag:100+i];
		[btnDay setTitle:@"" forState:UIControlStateNormal];
	}
}

- (void) addControlBar {
	UIButton* btnPrevYear = [[UIButton buttonWithType:UIButtonTypeCustom] retain];;
	[btnPrevYear setFrame:CGRectMake(10, 5, TILE_W, TILE_H)];
	[btnPrevYear setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
	[btnPrevYear setImage:[UIImage imageNamed:@"btnPrevY.png"]
				 forState:UIControlStateNormal];
	[btnPrevYear addTarget:self action:@selector(prevYear) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:btnPrevYear];
	[btnPrevYear release];
	
	UIButton* btnPrevMonth = [[UIButton alloc] initWithFrame:CGRectMake(40, 5, TILE_W, TILE_H)];
	[btnPrevMonth setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
	[btnPrevMonth setImage:[UIImage imageNamed:@"btnPrevM.png"]
				 forState:UIControlStateNormal];
	[btnPrevMonth addTarget:self action:@selector(prevMonth) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:btnPrevMonth];
	[btnPrevMonth release];
		
	lblCurrentDate = [[UILabel alloc] initWithFrame:CGRectMake(80, 0, 150, 40)];
	lblCurrentDate.backgroundColor = [UIColor clearColor];
	[lblCurrentDate setTextColor:[UIColor whiteColor]];		
	[lblCurrentDate setTextAlignment:UITextAlignmentCenter];
	[lblCurrentDate setFont:[UIFont fontWithName:@"Helvetica-Bold" size:18]];
	[self addSubview:lblCurrentDate];
	
	UIButton* btnNextMonth = [[UIButton alloc] initWithFrame:CGRectMake(240, 5, TILE_W, TILE_H)];
	[btnNextMonth setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
	[btnNextMonth setImage:[UIImage imageNamed:@"btnNextM.png"]
				  forState:UIControlStateNormal];

	[btnNextMonth addTarget:self action:@selector(nextMonth) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:btnNextMonth];
	[btnNextMonth release];
	
	UIButton* btnNextYear = [[UIButton alloc] initWithFrame:CGRectMake(270, 5, TILE_W, TILE_H)];
	[btnNextYear setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
	[btnNextYear setImage:[UIImage imageNamed:@"btnNextY.png"]
				  forState:UIControlStateNormal];
	[btnNextYear addTarget:self action:@selector(nextYear) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:btnNextYear];
	[btnNextYear release];	

	//init day items
	for ( int i = 0; i < MAX_DAYS; i++){
		CGRect rtDay = CGRectMake(i%7*TILE_W + ((i%7)==0?0:TILE_SPACE_H*(i%7))+TILE_INDENT, i/7*TILE_H+CONTROL_BAR_H, TILE_W, TILE_H);
		UIButton* btnDay = [[UIButton alloc] initWithFrame:rtDay];
		btnDay.tag = 100+i;
		[btnDay setTitle:@"" forState:UIControlStateNormal];
		[self addSubview:btnDay];
		[btnDay release];
	}	
}

- (void) prevYear {
	self.baseDate = [self.baseDate cc_dateByMovingToThePreviousYear];
	[self recalculateVisibleDays];
}

- (void) nextYear {
	self.baseDate = [self.baseDate cc_dateByMovingToTheFollowYear];
	[self recalculateVisibleDays];
}

- (void) prevMonth {
	self.baseDate = [self.baseDate cc_dateByMovingToFirstDayOfThePreviousMonth];
	[self recalculateVisibleDays];
}

- (void) nextMonth {
	self.baseDate = [self.baseDate cc_dateByMovingToFirstDayOfTheFollowingMonth];
	[self recalculateVisibleDays];
}

- (void)dealloc {
	[baseDate release];
	[lblCurrentDate release];
	[monthAndYearFormatter release];
	[img_sel_bg release];
    [super dealloc];
}


@end
