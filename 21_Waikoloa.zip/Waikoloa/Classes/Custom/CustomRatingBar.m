//
//  CustomRatingBar.m
//  Vacation
//
//  Created by Free on 11/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CustomRatingBar.h"
#import "UIViewDraw.h"

#define CELL_SIZE	24

@implementation CustomRatingBar
@synthesize m_imgEmptyRating, m_imgFullRating;

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
		
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
	if ( self.m_imgEmptyRating == nil )
		self.m_imgEmptyRating = [UIImage imageNamed:@"empty_rating.png"];
	
	if ( self.m_imgFullRating == nil )
		self.m_imgFullRating = [UIImage imageNamed:@"full_rating.png"];
	
	
	int full_cnt = m_nTotalRating / 20;
	int other = m_nTotalRating - full_cnt * 20;
	int total_cnt = full_cnt + ((m_nTotalRating%20) != 0 ? 1: 0);
	
	for ( int i = 0; i < 5; i ++ ){
		[self drawImage:self.m_imgEmptyRating :CELL_SIZE * i :0];
		
		if ( i >= total_cnt )
			continue;
		
		if ( i < full_cnt )	{
			[self drawImage:self.m_imgFullRating 
						   :CELL_SIZE * i 
						   :0];
		}else {
			if ( other != 0 )
				[self drawImage:[self getClipImage:self.m_imgFullRating :CGRectMake(0, CELL_SIZE-other, CELL_SIZE, other)]
							   :CELL_SIZE * i 
							   :CELL_SIZE-other];
		}
	}
	
}

- (void) setRating:(int)rating_value {
	m_nTotalRating = rating_value;
	
	[self setNeedsDisplay];
}


- (void)dealloc {
	[m_imgFullRating release];
	[m_imgEmptyRating release];

    [super dealloc];
}


@end
