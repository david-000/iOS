//
//  CustomMapView.m
//  Vacation
//
//  Created by Free on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CustomMapView.h"

@implementation PinAnnotation
@synthesize coordinate = m_locCoordinate;

- (id)initWithCoordinate:(CLLocationCoordinate2D)coordinate {
	if ((self = [super init])) {
		m_locCoordinate = coordinate;
	}
	
	return self;
}

- (NSString *)title {
	return @" ";
}

- (NSString *)subtitle {
	return @" ";
}

@end


@implementation CustomMapView

- (void) loadMapInfo:(NSString*)szLatitude :(NSString*)szLongitude {
	
	if ( m_viwMap == nil ){
		m_viwMap = [[MKMapView alloc] initWithFrame:self.bounds];
		[self addSubview:m_viwMap];
	}

	CLLocationCoordinate2D locCoordnate;
	locCoordnate.latitude = [szLatitude doubleValue];
	locCoordnate.longitude = [szLongitude doubleValue];
	
	PinAnnotation *annotPin = [[[PinAnnotation alloc] initWithCoordinate:locCoordnate] autorelease];

	[m_viwMap performSelectorOnMainThread:@selector(addAnnotation:) withObject:annotPin waitUntilDone:YES];	
	[self performSelectorOnMainThread:@selector(fitToPinsRegion) withObject:nil waitUntilDone:YES];
}

- (void)fitToPinsRegion {
	
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	if ( [m_viwMap.annotations count] == 0 )
		return;
	
	PinAnnotation *firstMark = [m_viwMap.annotations objectAtIndex:0];
	CLLocationCoordinate2D topLeftCoord = firstMark.coordinate;
	CLLocationCoordinate2D bottomRightCoord = firstMark.coordinate;
	
	for (PinAnnotation *item in m_viwMap.annotations) {
		if (item.coordinate.latitude < topLeftCoord.latitude) {
			topLeftCoord.latitude = item.coordinate.latitude;
		}
		
		if (item.coordinate.longitude > topLeftCoord.longitude)	{
			topLeftCoord.longitude = item.coordinate.longitude;
		}
		
		if (item.coordinate.latitude > bottomRightCoord.latitude) {
			bottomRightCoord.latitude = item.coordinate.latitude;
		}
		
		if (item.coordinate.longitude < bottomRightCoord.longitude) {
			bottomRightCoord.longitude = item.coordinate.longitude;
		}
	}
	
	MKCoordinateRegion region;
	region.center.latitude = (topLeftCoord.latitude + bottomRightCoord.latitude) / 2.0f;
	region.center.longitude = (topLeftCoord.longitude + bottomRightCoord.longitude) / 2.0f;
	region.span.latitudeDelta = fabs(topLeftCoord.latitude - bottomRightCoord.latitude) * 1.1; // Add a little extra space on the sides
	region.span.longitudeDelta = fabs(bottomRightCoord.longitude - topLeftCoord.longitude) * 1.1; // Add a little extra space on the sides
	
	if (region.span.latitudeDelta < 0.01) {
		region.span.latitudeDelta = 0.01;
	}
	if (region.span.longitudeDelta < 0.01) {
		region.span.longitudeDelta = 0.01;
	}
	
	region = [m_viwMap regionThatFits:region];
	[m_viwMap setRegion:region animated:YES];
	
	[pool release];
	
}

- (void)dealloc {
	[m_viwMap release];
    [super dealloc];
}


@end
