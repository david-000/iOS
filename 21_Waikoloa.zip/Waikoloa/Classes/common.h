/*
 *  common.h
 *  Vacation
 *
 *  Created by Free on 11/13/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#define SERVER_URL			@"http://app.waikoloamobile.com/admin/"
#define RESTAURANT_URL		@"index.php?/xmldata/restaurants"
#define SITES_URL			@"index.php?/xmldata/"
#define REQUEST_SERVER_URL 	@"index.php?/xmldata/get_events"
#define RESPONSE_SERVER_URL	@"index.php?/xmldata/create_events"
#define SOAP_SERVER_URL		@"http://secure.instantsoftwareonline.com/StayUSA/ChannelParTners/wsWeblinkPlusAPI.asmx"
#define RENTAL_URL			@"http://www.waikoloavacationrentals.com/reservations/search.php?"