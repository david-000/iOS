//
//  RestaurantsController.h
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <CoreLocation/CoreLocation.h>
#import "CustomLoadingView.h"

@interface RestaurantsController : UIViewController<UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource, CLLocationManagerDelegate> {
	UITableView*	searchListView;
	
	BOOL	bRecommend;
	
	NSMutableArray* arrayList;
	NSMutableArray* recommendList;
	CLLocationManager* localManager;
}

@property (nonatomic, retain) IBOutlet UITableView* searchListView;
@property (nonatomic, retain) NSMutableArray* arrayList;
@property (nonatomic, retain) IBOutlet CustomLoadingView* loadingView;


- (IBAction) goBack;
- (void) requestData:(NSString*)lat :(NSString*)lng;

- (IBAction) searchTextChange:(UITextField*)textField;

@end
