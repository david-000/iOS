//
//  ContactCell.m
//  Vacation
//
//  Created by Free on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ContactCell.h"

@implementation ContactCell

@synthesize lblPersonName, mobilePhoneNumber, iphonePhoneNumber, homePhoneNumber;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code.
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}

- (void)dealloc {
	[lblPersonName release];
	[mobilePhoneNumber release];
	[iphonePhoneNumber release];
	[homePhoneNumber release];
	[super dealloc];
}

@end
