//
//  FlightsController.h
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FlightsController : UIViewController {

}

- (IBAction) goBack;

- (IBAction) flightStatusAction;
- (IBAction) CheckinAction;

@end
