//
//  SitesSeeController.m
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SitesSeeController.h"
#import "SitesCell.h"
#import "SiteInfo.h"
#import "BeachesController.h"
#import "XMLSitesReader.h"
#import "common.h"
#import "ASIFormDataRequest.h"

@implementation SitesSeeController
@synthesize siteListView, _btnSites, _btnBeaches, _imgNormal, _imgHighlight, arrayList;
@synthesize loadingView;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	_szSearchKey = @"sites";
	_bLoading = TRUE;
	_bSites = TRUE;
	
	self.loadingView.hidden = NO;
	[loadingView launchAnimation];
	
	localManager = [[CLLocationManager alloc] init];
	localManager.delegate = self;
	localManager.distanceFilter = kCLDistanceFilterNone;
	localManager.desiredAccuracy = kCLLocationAccuracyBest;
	[localManager startUpdatingLocation];
	
	//TableView setting
	self.siteListView.backgroundColor = [UIColor clearColor];
	self.siteListView.separatorColor = [UIColor clearColor];
	self.siteListView.rowHeight = 70;
	
	self._imgNormal = [UIImage imageNamed:@"btn_normal0.png"];
	self._imgHighlight = [UIImage imageNamed:@"btn_highlight0.png"];
	
	[self._btnSites setBackgroundImage:self._imgHighlight forState:UIControlStateNormal];
	[self._btnBeaches setBackgroundImage:self._imgNormal forState:UIControlStateNormal];
	
	self.view.userInteractionEnabled = NO;
	
}

- (IBAction) goBack {
	[self.navigationController popViewControllerAnimated:YES];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[loadingView terminateAnimation];
	[loadingView release];
	[siteListView release];
	[_btnSites release];
	[_btnBeaches release];
	[_imgNormal release];
	[_imgHighlight release];
	[arrayList release];
    [super dealloc];
}

#pragma mark -
#pragma mark willAppear & willDisapper proc
- (void)viewWillAppear:(BOOL)animated {
	
}

- (void) viewWillDisappear:(BOOL)animated {
//	[localManager stopUpdatingLocation];
//	[localManager setDelegate:nil];	
}

#pragma mark -
#pragma mark CLLocationManager delegate
- (void)locationManager:(CLLocationManager *)manager
	didUpdateToLocation:(CLLocation *)newLocation
		   fromLocation:(CLLocation *)oldLocation{
	
	[manager stopUpdatingLocation];	
	
	NSString* lat = [NSString stringWithFormat:@"%g", newLocation.coordinate.latitude];
	NSString* lng = [NSString stringWithFormat:@"%g", newLocation.coordinate.longitude];
	[self requestData:lat :lng];
}

- (void)locationManager:(CLLocationManager *)manager
	   didFailWithError:(NSError *)error {
	[manager stopUpdatingLocation];
	
	[self requestData:@"0" :@"0"];
}

- (void) requestData:(NSString*)lat :(NSString*)lng {
	
	_bLoading = FALSE;
	[localManager stopUpdatingLocation];
	
	NSString* szRequest = [NSString stringWithFormat:@"%@%@%@", SERVER_URL, SITES_URL, _szSearchKey];

	ASIFormDataRequest* request1 = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:szRequest]];	
	[request1 setRequestMethod:@"POST"];
	[request1 setPostValue:lat forKey:@"lat"];
	[request1 setPostValue:lng forKey:@"lng"];
	[request1 setDelegate:self];
	[request1 setDidFinishSelector:@selector(requestDone:)];
	[request1 setDidFailSelector:@selector(requestFailed:)];
	[request1 startAsynchronous];
	
}

#pragma mark -
#pragma mark xxxxxxxxxxxxxxxxxxxx
- (IBAction) sitesAction {
	
	//if ( _bLoading )
//		return;
//	
	if ( _bSites )
		return;
//	
	_bSites = TRUE;
	self.view.userInteractionEnabled = NO;
	_szSearchKey = @"sites";
//	[localManager stopUpdatingLocation];
	[localManager startUpdatingLocation];
	[loadingView restartAnimation];
	
	[self._btnSites setBackgroundImage:self._imgHighlight forState:UIControlStateNormal];
	[self._btnBeaches setBackgroundImage:self._imgNormal forState:UIControlStateNormal];
}

- (IBAction) beachesAction {
	
	//if ( _bLoading )
//		return;
//	
	if ( !_bSites )
		return;
//	
	_bSites = FALSE;
	self.view.userInteractionEnabled = NO;
	_szSearchKey = @"beaches";
//	[localManager stopUpdatingLocation];
	[localManager startUpdatingLocation];
	[loadingView restartAnimation];
	
	[self._btnSites setBackgroundImage:self._imgNormal forState:UIControlStateNormal];
	[self._btnBeaches setBackgroundImage:self._imgHighlight forState:UIControlStateNormal];
}

#pragma mark -
#pragma mark UITableView Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {	
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {	
	return [arrayList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *CellIdentifier = @"SitesCell";
    
	
	SitesCell* cell = (SitesCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
		UIViewController* myCell = [[UIViewController alloc] initWithNibName:@"SitesCell" bundle:nil];
		cell = (SitesCell*)myCell.view;
		[myCell release];
		
		UIImageView* cell_bg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"cell.png"]];
		cell.backgroundView = cell_bg;
		[cell_bg release];
    }
	

	SiteInfo* si = (SiteInfo*)[arrayList objectAtIndex:indexPath.row];	
	cell._lbTitle.text = si._szTitle;
	cell._lbDistance.text = [NSString stringWithFormat:@"%d", [si._szDistance intValue]];
	cell._lbTemperate.text = [NSString stringWithFormat:@"current %@⁰", si._szWeather_temper];
	[cell._mapView loadMapInfo:si._szLatitude :si._szLongitude];
	
    return cell;	
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
	cell.backgroundColor = [UIColor clearColor];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	
	SiteInfo* si = (SiteInfo*)[arrayList objectAtIndex:indexPath.row];		
	BeachesController* bc = [[BeachesController alloc] initWithSiteInfo:si];
	[self.navigationController pushViewController:bc animated:YES];
	[bc release];	
}

#pragma mark -
#pragma mark DDHttpClientDelegate

- (void)requestDone:(ASIFormDataRequest*)sender {
	self.view.userInteractionEnabled = YES;
	
	[loadingView terminateAnimation];
	self.loadingView.hidden = YES;
	
	NSData* responseData = [sender responseData];
	XMLSitesReader* xmlParser = [[XMLSitesReader alloc] init];
	[xmlParser parserXMLWithData:responseData parseError:nil];
	self.arrayList = xmlParser.results;
	[xmlParser release];	
	
	[sender clearDelegatesAndCancel];
	sender = nil;
	
	[siteListView reloadData];
}

- (void)requestFailed:(ASIFormDataRequest*)sender {
	self.view.userInteractionEnabled = YES;
	
	[loadingView terminateAnimation];
	self.loadingView.hidden = YES;	
	
	[sender clearDelegatesAndCancel];
	sender = nil;

	[siteListView reloadData];
}
@end
