//
//  BeachesController.m
//  Vacation
//
//  Created by Free on 11/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "BeachesController.h"
#import "ASIHTTPRequest.h"
#import "ASIImageDataRequest.h"

@implementation BeachesController
@synthesize ivwThumb, ivwWeather, lblTitle, lblTemper, lblDistance, itvDescript, itvReview, mSiteInfo, iaiLoading, cmvCurMap;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
		
	self.lblTitle.text = mSiteInfo._szTitle;
	self.lblTemper.text = [NSString stringWithFormat:@"current %@⁰", mSiteInfo._szWeather_temper];	
	self.lblDistance.text = [NSString stringWithFormat:@"%d", [mSiteInfo._szDistance intValue]];
	[self.cmvCurMap loadMapInfo:mSiteInfo._szLatitude :mSiteInfo._szLongitude];
	
	self.itvDescript.font = [UIFont fontWithName:@"Helvetica" size:12];
	self.itvDescript.text = mSiteInfo._szDescription;
	self.itvReview.font = [UIFont fontWithName:@"Helvetica" size:12];
	self.itvReview.text = mSiteInfo._szReview;
	
	if ( [mSiteInfo._szWeather_state isEqualToString:@"fine"] )
		self.ivwWeather.image = [UIImage imageNamed:@"sun.png"];
	else 
		self.ivwWeather.image = [UIImage imageNamed:@"clody.png"];
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[ivwThumb release];
	[ivwWeather release];
	[lblTitle release];
	[lblTemper release];
	[lblDistance release];
	[itvDescript release];
	[itvReview release];
	[mSiteInfo release];
	[iaiLoading release];
	[cmvCurMap release];
    [super dealloc];
}

#pragma mark -
#pragma mark xxxxxxxxxxxxxxxxxxxxx

- (id) initWithSiteInfo:(SiteInfo*)info {
	if ((self = [super init])) {
		self.mSiteInfo = info;
		
	}
	
	return self;
}

- (void)viewWillAppear:(BOOL)animated {	

	//DDIconContainer* container = [[DDIconRepository instance] downloadForURL:mSiteInfo._szImgThumb withTarget:self];
//	if ( container.iconImage ){
//		[iaiLoading setHidden:YES];
//		self.ivwThumb.image = container.iconImage;
//	}
		
	
	[[ASIImageDataRequest sharedInstance] downloadImageWithURL:mSiteInfo._szImgThumb 
														target:self
											 didFinishSelector:@"doneDownloadImage:" 
												 withImageView:self.ivwThumb];
}

- (void) doneDownloadImage:(UIImage*)img {
	[iaiLoading stopAnimating];
}

#pragma mark -
#pragma mark NavigationBarButton Action
- (IBAction) goBack {
	[self.navigationController popViewControllerAnimated:YES];
}

@end
