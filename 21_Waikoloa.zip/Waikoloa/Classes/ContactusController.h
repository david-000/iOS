//
//  ContactusController.h
//  Vacation
//
//  Created by Free on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ContactusController : UIViewController {

}

- (IBAction) callAction;
- (IBAction) textAction;
- (IBAction) mailAction;
- (IBAction) websiteAction;
- (IBAction) goBack;
@end
