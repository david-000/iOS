//
//  DirectoryController.m
//  Vacation
//
//  Created by Free on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "DirectoryController.h"
#import <AddressBook/AddressBook.h>
#import <AddressBookUI/AddressBookUI.h>
#import "ContactCell.h"

@implementation DirectoryController
@synthesize tblContactList;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.tblContactList.separatorColor = [UIColor purpleColor];
	
	mContactList = [[NSMutableArray alloc] init];
	
	ABAddressBookRef addressBook = ABAddressBookCreate();
	CFArrayRef allPeople = ABAddressBookCopyArrayOfAllPeople(addressBook);
	CFIndex nPeople = ABAddressBookGetPersonCount(addressBook);
	
	for ( int i = 0; i < nPeople; i++){
		ABRecordRef ref = CFArrayGetValueAtIndex(allPeople, i);
		NSString* firstName = (NSString*)ABRecordCopyValue(ref, kABPersonFirstNameProperty);
		if ( firstName == nil )
			firstName = @"";
		NSString* lastName = (NSString*)ABRecordCopyValue(ref, kABPersonLastNameProperty);
		if ( lastName == nil )
			lastName = @"";
		NSString* szPersonName = [NSString stringWithFormat:@"%@ %@", firstName, lastName];
		
		ABMultiValueRef multi = ABRecordCopyValue(ref, kABPersonPhoneProperty);	
		CFIndex nPhoneNumberCnt = ABMultiValueGetCount(multi);
		
		NSString* phoneNumber1 = @"";
		NSString* phoneNumber2 = @"";
		NSString* phoneNumber3 = @"";
		
		if ( nPhoneNumberCnt != 0 )
			phoneNumber1 = (NSString*)ABMultiValueCopyValueAtIndex(multi, 0);
		if ( nPhoneNumberCnt > 1 )
			phoneNumber2 = (NSString*)ABMultiValueCopyValueAtIndex(multi, 1);
		if ( nPhoneNumberCnt > 2 )
			phoneNumber2 = (NSString*)ABMultiValueCopyValueAtIndex(multi, 2);
		
		NSString* szContactItem = [NSString stringWithFormat:@"%@,%@,%@,%@", szPersonName, phoneNumber1, phoneNumber2, phoneNumber3];
		[mContactList addObject:szContactItem];
	}
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[mContactList release];
	[tblContactList release];
    [super dealloc];
}

- (IBAction) goBack {
	[self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark UITableView Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {	
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {	
	return [mContactList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *CellIdentifier = @"ContactCell";
    
	
	ContactCell* cell = (ContactCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
		UIViewController* myCell = [[UIViewController alloc] initWithNibName:@"ContactCell" bundle:nil];
		cell = (ContactCell*)myCell.view;
		[myCell release];		
    }
	
	NSString* szInfo = (NSString*)[mContactList objectAtIndex:indexPath.row];
	NSArray* infoArray = [szInfo componentsSeparatedByString:@","];
	
	cell.lblPersonName.text = (NSString*)[infoArray objectAtIndex:0];
	cell.mobilePhoneNumber.text = (NSString*)[infoArray objectAtIndex:1];
	cell.iphonePhoneNumber.text = (NSString*)[infoArray objectAtIndex:2];
	cell.homePhoneNumber.text = (NSString*)[infoArray objectAtIndex:3];
	
    return cell;	
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
	cell.backgroundColor = [UIColor clearColor];
}

- (CGFloat) tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath {
	return 83;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
