//
//  BeachesController.h
//  Vacation
//
//  Created by Free on 11/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RestaurantInfo.h"
#import "CustomMapView.h"

@interface ResDetailController : UIViewController {
	RestaurantInfo* mResInfo;
		
	BOOL	bZoom;
}

@property (nonatomic, retain) RestaurantInfo* mResInfo;
@property (nonatomic, retain) IBOutlet UIImageView* ivwThumb;
@property (nonatomic, retain) IBOutlet UIImageView*	ivwWeather;
@property (nonatomic, retain) IBOutlet UILabel*		lblTitle;
@property (nonatomic, retain) IBOutlet UILabel*		lblTemper;
@property (nonatomic, retain) IBOutlet UILabel*		lblDistance;
@property (nonatomic, retain) IBOutlet UITextView*	itvDescript;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView* iaiLoading;
@property (nonatomic, retain) IBOutlet CustomMapView*	cmvCurMap;

- (id) initWithRestaurantInfo:(RestaurantInfo*)info;
- (IBAction) goBack;

@end
