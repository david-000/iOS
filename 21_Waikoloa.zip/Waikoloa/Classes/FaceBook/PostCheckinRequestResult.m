//
//  PostCheckinRequestResult.m
//  DemoApp
//
//  Created by Manoj Patidar on 03/09/11.
//  Copyright 2011 abc. All rights reserved.
//

#import "PostCheckinRequestResult.h"

@implementation PostCheckinRequestResult

- (id) initializeWithDelegate:(id )delegate {
    if ((self = [super init])) {
         NSLog(@"PostCheckinRequestResult created");
        _postCheckinRequestDelegate = delegate;
    }
	return self;
}

/**
 * FBRequestDelegate
 */
- (void)request:(FBRequest *)request didLoad:(id)result {
    NSLog(@"post check in succeed");
    NSLog(@"check in result = %@", [result objectForKey:@"data"]);
	[_postCheckinRequestDelegate postCheckinRequestCompleted];
}

- (void)request:(FBRequest*)request didFailWithError:(NSError*)error {
    
	NSLog(@"Post Checkin Failed:%@", [error localizedDescription]);
    
	[_postCheckinRequestDelegate postCheckinRequestFailed];
}

@end