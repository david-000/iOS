//
//  PostLikeRequestResult.h
//  DemoApp
//
//  Created by Manoj Patidar on 03/09/11.
//  Copyright 2011 abc. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "FBConnect.h"

@protocol PostLikeRequestDelegate;

@interface PostLikeRequestResult : NSObject<FBRequestDelegate> {
    
	id _postLikeRequestDelegate;
}

- (id) initializeWithDelegate: (id)delegate;

@end

@protocol PostLikeRequestDelegate <NSObject>

- (void) postLikeRequestCompleted;
- (void) postLikeRequestFailed;

@end
