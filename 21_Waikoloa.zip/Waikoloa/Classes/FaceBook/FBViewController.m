/*
 * Copyright 2010 Facebook
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#import "FBViewController.h"
#import "FBConnect.h"
#import <QuartzCore/QuartzCore.h>
#import "VacationAppDelegate.h"

// Your Facebook APP Id must be set before running this example
// See http://www.facebook.com/developers/createapp.php
// Also, your application must bind to the fb[app_id]:// URL
// scheme (substitute [app_id] for your real Facebook app id).
static NSString* kAppId = @"272542819436580";

@implementation FBViewController

@synthesize label = _label, facebook = _facebook;
@synthesize _imgPhoto;
//@synthesize locationManager;
//////////////////////////////////////////////////////////////////////////////////////////////////
// UIViewController

/**
 * initialization
 */
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
  if (!kAppId) {
    NSLog(@"missing app id!");
    exit(1);
    return nil;
  }


  if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
    _permissions =  [[NSArray arrayWithObjects:
                      @"read_stream", @"publish_stream", @"offline_access",@"user_checkins", @"friends_checkins", @"publish_checkins",nil] retain];
    _facebook = [[Facebook alloc] initWithAppId:kAppId
                                    andDelegate:self];
//      self.locationManager = [[[CLLocationManager alloc] init] autorelease];
//      self.locationManager.delegate = self; // send loc updates to myself
//      [self.locationManager startUpdatingLocation];
  }
	
	VacationAppDelegate* appDelegate = (VacationAppDelegate*) [[UIApplication sharedApplication] delegate];
	appDelegate.facebookController = self;

  return self;
}


//- (void)locationManager:(CLLocationManager *)manager
//    didUpdateToLocation:(CLLocation *)newLocation
//           fromLocation:(CLLocation *)oldLocation
//{
//    NSLog(@"Location: %@", [newLocation description]);
//    if(nil!= newLocation){
//		
//		if(newLocation.horizontalAccuracy < 0)return;
//		
//        //		BOOL fistTimeUpdated = NO;
//        //		if ((myLocation_.latitude == 0)&&(myLocation_.longitude == 0)){ // first location fetch.
//        //			// making new location at the center of map, previousely using 		
//        //			fistTimeUpdated = YES;
//        //		}
//		
//		int oldlat = myLocation_.latitude * 100 ;
//		int oldlong = myLocation_.longitude * 100 ;
//		
//		CLLocationCoordinate2D temploc = [newLocation coordinate];	
//		
//		int newlat = temploc.latitude * 100;
//		int newlong = temploc.longitude * 100;	
//		
//		if(oldlat != newlat || oldlong != newlong){ // check for major change in location
//			myLocation_ = temploc;	
//           
//		}
//	}	
//}
//
//- (void)locationManager:(CLLocationManager *)manager
//       didFailWithError:(NSError *)error
//{
//	NSLog(@"Error: %@", [error description]);
//}


/**
 * Set initial view
 */
- (void)viewDidLoad {
//    localArray =[[NSMutableArray alloc] init];
  [self.label setText:@"Please log in"];
//  _getUserInfoButton.hidden = YES;
//  _getPublicInfoButton.hidden = YES;
//	_publishButton.hidden = YES;
  _uploadPhotoButton.hidden = YES;
	_uploadTextButton.hidden = YES;
  _fbButton.isLoggedIn = NO;
  [_fbButton updateImage];    
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// NSObject

- (void)dealloc {
  [_label release];
	[_imgPhoto release];
	
  [_fbButton release];
//  [_getUserInfoButton release];
//  [_getPublicInfoButton release];
  [_publishButton release];
  [_uploadPhotoButton release];
  [_facebook release];
  [_permissions release];
  [super dealloc];
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// private

/**
 * Show the authorization dialog.
 */
- (void)login {
  [_facebook authorize:_permissions];
}

/**
 * Invalidate the access token and clear the cookie.
 */
- (void)logout {
  [_facebook logout:self];
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// IBAction

/**
 * Called on a login/logout button click.
 */
- (IBAction)fbButtonClick:(id)sender {
  if (_fbButton.isLoggedIn) {
    [self logout];
  } else {
    [self login];
  }
}

/**
 * Make a Graph API Call to get information about the current logged in user.
 */
- (IBAction)getUserInfo:(id)sender {
  [_facebook requestWithGraphPath:@"me" andDelegate:self];
}


/**
 * Make a REST API call to get a user's name using FQL.
 */
- (IBAction)getPublicInfo:(id)sender {
  NSMutableDictionary * params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                  @"SELECT uid,name FROM user WHERE uid=4", @"query",
                                  nil];
  [_facebook requestWithMethodName:@"fql.query"
                         andParams:params
                     andHttpMethod:@"POST"
                       andDelegate:self];
}

/**
 * Open an inline dialog that allows the logged in user to publish a story to his or
 * her wall.
 */
- (IBAction)publishStream:(id)sender {

  SBJSON *jsonWriter = [[SBJSON new] autorelease];

  NSDictionary* actionLinks = [NSArray arrayWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:
                               @"Always Running",@"text",@"http://itsti.me/",@"href", nil], nil];

  NSString *actionLinksStr = [jsonWriter stringWithObject:actionLinks];
  NSDictionary* attachment = [NSDictionary dictionaryWithObjectsAndKeys:
                               @"a long run", @"name",
                               @"The Facebook Running app", @"caption",
                               @"it is fun", @"description",
                               @"http://itsti.me/", @"href", nil];
  NSString *attachmentStr = [jsonWriter stringWithObject:attachment];
  NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                 @"Share on Facebook",  @"user_message_prompt",
                                 actionLinksStr, @"action_links",
                                 attachmentStr, @"attachment",
                                 nil];


  [_facebook dialog:@"feed"
          andParams:params
        andDelegate:self];
}

/**
 * Upload a photo.
 */
- (IBAction)uploadPhoto:(id)sender {
	
	self._imgPhoto = [UIImage imageNamed:@"other_btn.png"];
	NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
								   self._imgPhoto, @"picture",
								   @"my test photo", @"caption", nil];	
	[_facebook requestWithGraphPath:@"me/photos"
						  andParams:params
					  andHttpMethod:@"POST"
                        andDelegate:self];

//	UIImagePickerController* cameraPicker = [[UIImagePickerController alloc] init];
//	cameraPicker.delegate = self;
//	cameraPicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
//	cameraPicker.allowsEditing = NO;
//	
//	[self presentModalViewController:cameraPicker animated:YES];
//	[cameraPicker release];
    
}

-(IBAction)uploadText {
	UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Please text input to upload"
													message:@"\n\n\n\n\n\n" 
												   delegate:self 
										  cancelButtonTitle:@"close"
										  otherButtonTitles:@"upload", nil];
	
	
	
	[alert show];
	
	CGRect rtTxt = alert.frame;
	
	rtTxt.origin.x = 10;
	rtTxt.origin.y -= 65;
	rtTxt.size.width = 260;
	rtTxt.size.height = 120;
	
	UITextView* itvMsg = [[UITextView alloc] initWithFrame:rtTxt];
	itvMsg.tag = 159;
	itvMsg.alpha = 0.7;
	itvMsg.font = [UIFont fontWithName:@"Helvetica-Bold" size:14];
	itvMsg.layer.cornerRadius = 6.0;
	[alert addSubview:itvMsg];
	[itvMsg release];
	
	[alert release];
}

-(IBAction) goBack {
	[self.navigationController popViewControllerAnimated:YES];
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  return YES;
}
*/

/**
 * Called when the user has logged in successfully.
 */
- (void)fbDidLogin {
  [self.label setText:@"logged in"];
 // _getUserInfoButton.hidden = NO;
//  _getPublicInfoButton.hidden = NO;
//  _publishButton.hidden = NO;
  _uploadPhotoButton.hidden = NO;
	_uploadTextButton.hidden = NO;
  _fbButton.isLoggedIn = YES;
  [_fbButton updateImage];
}

/**
 * Called when the user canceled the authorization dialog.
 */
-(void)fbDidNotLogin:(BOOL)cancelled {
  //NSLog(@"did not login");
}

/**
 * Called when the request logout has succeeded.
 */
- (void)fbDidLogout {
  [self.label setText:@"Please log in"];
  //_getUserInfoButton.hidden    = YES;
//  _getPublicInfoButton.hidden   = YES;
//  _publishButton.hidden        = YES;
  _uploadPhotoButton.hidden = YES;
	_uploadTextButton.hidden = YES;
  _fbButton.isLoggedIn         = NO;
  [_fbButton updateImage];
}


////////////////////////////////////////////////////////////////////////////////
// FBRequestDelegate

/**
 * Called when the Facebook API request has returned a response. This callback
 * gives you access to the raw response. It's called before
 * (void)request:(FBRequest *)request didLoad:(id)result,
 * which is passed the parsed response object.
 */
- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response {
  NSLog(@"received response");
}

/**
 * Called when a request returns and its response has been parsed into
 * an object. The resulting object may be a dictionary, an array, a string,
 * or a number, depending on the format of the API response. If you need access
 * to the raw response, use:
 *
 * (void)request:(FBRequest *)request
 *      didReceiveResponse:(NSURLResponse *)response
 */
- (void)request:(FBRequest *)request didLoad:(id)result {
  if ([result isKindOfClass:[NSArray class]]) {
    result = [result objectAtIndex:0];
  }
  if ([result objectForKey:@"owner"]) {
    [self.label setText:@"Photo upload Success"];
  } else {
    [self.label setText:[result objectForKey:@"name"]];
  }
 //   dataTypeInTable_ = 0;
//    placesArray = [[result objectForKey:@"data"] retain]; 

};

/**
 * Called when an error prevents the Facebook API request from completing
 * successfully.
 */
- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
  [self.label setText:[error localizedDescription]];
};


////////////////////////////////////////////////////////////////////////////////
// FBDialogDelegate

/**
 * Called when a UIServer Dialog successfully return.
 */
- (void)dialogDidComplete:(FBDialog *)dialog {
  [self.label setText:@"publish successfully"];
}

-(IBAction)checkin:(id)sender {
	
}

-(IBAction)like:(id)sender {
//    dataTypeInTable_ = 1;
//    getCheckInResult_ = [[GetCheckInResult alloc] initializeWithDelegate:self];
//    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
//								   @"checkin",@"type",
//								   nil];
//    
//    [_facebook requestWithGraphPath:@"search" andParams:params andDelegate:getCheckInResult_];
}


#pragma mark delegate methods
- (void) getCheckinRequestCompletedWithCheckins:(NSArray *)checkins {
//    [checkInsArray_ release], checkInsArray_ = nil;
//    checkInsArray_ = [checkins retain];
//    dataTypeInTable_ = 1;
    //[self.myTableView performSelectorInBackground:@selector(reloadData) withObject:nil];
}

- (void) getCheckinRequestFailed {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Unable to load checkins data" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    [alert release];
}

- (void) postLikeWithDictionary:(NSDictionary *)dictionary {
    //CHECKIN_ID/likes
//    postLikeRequestResult = [[PostLikeRequestResult alloc] initializeWithDelegate:self];
//    NSString *graphPath = [NSString stringWithFormat:@"%@/checkins",[dictionary objectForKey:@"id"]];
//    [_facebook requestWithGraphPath:graphPath andParams:nil andHttpMethod:@"POST" andDelegate: postLikeRequestResult];
}

#pragma mark delegate methods
- (void) postLikeRequestCompleted {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Like request succeeded" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    [alert release];
}

- (void) postLikeRequestFailed {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Unable to complete like request" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    [alert release];
}


- (void) postCheckinWithDictionary:(NSDictionary *)dictionary {
    
    //NSLog(@"Dictionary is = %@", dictionary);
//    
//	postCheckinRequestResult_ = [[PostCheckinRequestResult alloc] initializeWithDelegate:self];
//	
//	SBJSON *jsonWriter = [[SBJSON new] autorelease];
//    
//	NSMutableDictionary *coordinatesDictionary = [NSMutableDictionary dictionaryWithObjectsAndKeys:
//                                                  [NSString stringWithFormat: @"%f", myLocation_.latitude], @"latitude",
//                                                  [NSString stringWithFormat: @"%f", myLocation_.longitude], @"longitude",
//                                                  nil];
//    
//	NSString *coordinates = [jsonWriter stringWithObject:coordinatesDictionary];
//    
//    NSLog(@"location string = %@", coordinates);
//    
//	NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
//								   [dictionary objectForKey:@"id"], @"place", //The PlaceID
//								   coordinates, @"coordinates", // The latitude and longitude in string format (JSON)
//								   @"some message", @"message", // The status message
//								   nil];
//    
//	[_facebook requestWithGraphPath:@"me/checkins" andParams:params andHttpMethod:@"POST" andDelegate: postCheckinRequestResult_];
}

#pragma mark PostCheckin delegate
- (void) postCheckinRequestCompleted {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Check in posted successfully" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    [alert release];
}

- (void) postCheckinRequestFailed {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Check in Failed" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
    [alert release];
}



#pragma mark -
#pragma mark Table view data source
//
//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
//	
//    return 1;
//}
//
//- (NSInteger)tableView:(UITableView *)tableView
// numberOfRowsInSection:(NSInteger)section
//{
//    if (dataTypeInTable_ == 0) {
//        return [placesArray count];
//    }
//    else {
//        return [checkInsArray_ count];
//    }
//	
//}
//
//- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
//    
//    static NSString *CellIdentifier = @"Cell";
//    
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
//    if (cell == nil) {
//        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
//    }
//    if (dataTypeInTable_ == 0) {
//        NSDictionary *placeDict = [placesArray objectAtIndex:indexPath.row];
//        cell.textLabel.text = [placeDict objectForKey:@"name"];
//    }
//    else {
//        NSDictionary *placeDict = [checkInsArray_ objectAtIndex:indexPath.row];
//        cell.textLabel.text = [placeDict objectForKey:@"id"];
//    }
//	return cell;
//}
//
//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//    
//    if (dataTypeInTable_ == 0) {
//        selectedLocation_ = [placesArray objectAtIndex:indexPath.row];
//        [self postCheckinWithDictionary:selectedLocation_];
//    }
//    else {
//        selectedLocation_ = [checkInsArray_ objectAtIndex:indexPath.row];
//        [self postLikeWithDictionary:selectedLocation_]; 
//    }
//}
//

#pragma mark -
#pragma mark UIImagePickerController
- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
	//UIImage* image = [info objectForKey:UIImagePickerControllerOriginalImage];	
	[self dismissModalViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark UIAlertView delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if ( buttonIndex == 1 ){
		UITextView* itvMsg = (UITextView*)[alertView viewWithTag:159];
		if ( itvMsg != nil ){
			
		}
	}
}

@end
