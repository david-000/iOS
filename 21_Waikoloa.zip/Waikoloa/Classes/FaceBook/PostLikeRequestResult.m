//
//  PostLikeRequestResult.m
//  DemoApp
//
//  Created by Manoj Patidar on 03/09/11.
//  Copyright 2011 abc. All rights reserved.
//

#import "PostLikeRequestResult.h"


@implementation PostLikeRequestResult

- (id) initializeWithDelegate:(id )delegate {
    if ((self = [super init])) {
        _postLikeRequestDelegate = delegate;
    }
	return self;
}

/**
 * FBRequestDelegate
 */
- (void)request:(FBRequest *)request didLoad:(id)result {
	[_postLikeRequestDelegate postLikeRequestCompleted];
}

- (void)request:(FBRequest*)request didFailWithError:(NSError*)error {
    
	//NSLog(@"Post Checkin Failed:%@", [error localizedDescription]);
    [_postLikeRequestDelegate postLikeRequestFailed];
}


@end
