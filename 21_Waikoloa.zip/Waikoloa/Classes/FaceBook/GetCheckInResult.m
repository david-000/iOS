//
//  GetCheckInResult.m
//  DemoApp
//
//  Created by Manoj Patidar on 03/09/11.
//  Copyright 2011 abc. All rights reserved.
//

#import "GetCheckInResult.h"


@implementation GetCheckInResult

- (id) initializeWithDelegate:(id )delegate {
    if ((self = [super init])) {
        _getCheckInDelegate = delegate;
    }
	return self;
}

/**
 * FBRequestDelegate
 */
- (void)request:(FBRequest *)request didLoad:(id)result {
    NSLog(@"check in result = %@", [result objectForKey:@"data"]);
	[_getCheckInDelegate getCheckinRequestCompletedWithCheckins:[result objectForKey:@"data"]];
}

- (void)request:(FBRequest*)request didFailWithError:(NSError*)error {
    
	NSLog(@"Post Checkin Failed:%@", [error localizedDescription]);
    [_getCheckInDelegate getCheckinRequestFailed];
}


@end
