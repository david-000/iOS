//
//  GetCheckInResult.h
//  DemoApp
//
//  Created by Manoj Patidar on 03/09/11.
//  Copyright 2011 abc. All rights reserved.
//

#import <Foundation/Foundation.h>


#import "FBConnect.h"

@protocol GetCheckInDelegate;

@interface GetCheckInResult : NSObject<FBRequestDelegate> {
    
	id _getCheckInDelegate;
}

- (id) initializeWithDelegate: (id)delegate;

@end

@protocol GetCheckInDelegate <NSObject>

- (void) getCheckinRequestCompletedWithCheckins:(NSArray *)checkins;
- (void) getCheckinRequestFailed;

@end