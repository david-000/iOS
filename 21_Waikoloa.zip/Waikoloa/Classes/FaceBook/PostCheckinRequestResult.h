//
//  PostCheckinRequestResult.h
//  DemoApp
//
//  Created by Manoj Patidar on 03/09/11.
//  Copyright 2011 abc. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "FBConnect.h"

@protocol PostCheckinRequestDelegate;

@interface PostCheckinRequestResult : NSObject<FBRequestDelegate> {
    
	id _postCheckinRequestDelegate;
}

- (id) initializeWithDelegate: (id)delegate;

@end

@protocol PostCheckinRequestDelegate <NSObject>

- (void) postCheckinRequestCompleted;
- (void) postCheckinRequestFailed;

@end
