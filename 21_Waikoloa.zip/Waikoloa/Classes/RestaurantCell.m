//
//  RestaurantCell.m
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RestaurantCell.h"


@implementation RestaurantCell
@synthesize _lbTitle, _lbDescript, _lbDistance, _lbMoney, _rating;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code.
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}


- (void)dealloc {
	[_lbTitle release];	
	[_lbDescript release];
	[_lbDistance release];
	[_lbMoney release];
	[_rating release];
    [super dealloc];
}


@end
