//
//  RestaurantCell.h
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomRatingBar.h"

@interface RestaurantCell : UITableViewCell {
	UILabel*	_lbTitle;
	UILabel*	_lbDescript;
	UILabel*	_lbDistance;
	UILabel*	_lbMoney;
	CustomRatingBar*	_rating;
}

@property (nonatomic, retain) IBOutlet UILabel*	_lbTitle;
@property (nonatomic, retain) IBOutlet UILabel*	_lbDescript;
@property (nonatomic, retain) IBOutlet UILabel*	_lbDistance;
@property (nonatomic, retain) IBOutlet UILabel*	_lbMoney;
@property (nonatomic, retain) IBOutlet CustomRatingBar*	_rating;

@end
