//
//  VacationRentalPage.m
//  Vacation
//
//  Created by Free on 11/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "VacationRentalPage.h"

#define LABEL_X			241
#define LABEL_Y			28
#define LABEL_W			37
#define LABEL_H			27
#define LABEL_V_SPACE	70

#define LOCATION_X		115
#define LOCATION_Y		165
#define LOCATION_W		123


#define BUTTON_W		36

NSString* szLocations[] = {@"All", @"Kolea", @"Mauna Lani Terrace", @"Vista Waikoloa", @"Hali'i kai"};
NSString* szLocationsKeys[] = {@"all", @"kolea", @"mauna", @"vista", @"hali"};

@implementation VacationRentalPage


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
		self.backgroundColor = [UIColor clearColor];
		
		[self resetLayout];
    }
    return self;
}

- (void) resetLayout {
	UIImageView* ivwBG = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"rental_page.png"]];
	[ivwBG setFrame:self.bounds];
	[self addSubview:ivwBG];
	[ivwBG release];
	
	//label
	
	nights = 5;
	
	lblNights = [[UILabel alloc] initWithFrame:CGRectMake(LABEL_X, LABEL_Y, LABEL_W, LABEL_H)];
	lblNights.backgroundColor = [UIColor clearColor];
	lblNights.text = @"5";
	[lblNights setFont:[UIFont fontWithName:@"Helvetica-Bold" size:30]];
	lblNights.textAlignment = UITextAlignmentCenter;
	lblNights.textColor = [UIColor colorWithRed:53/255.f green:112/255.f blue:110/255.f alpha:1.0];
	[self addSubview:lblNights];
	
	UIButton* btnBackNights = [[UIButton alloc] initWithFrame:CGRectMake(LABEL_X - LABEL_W/2, LABEL_Y, BUTTON_W/2, BUTTON_W)];
	btnBackNights.backgroundColor = [UIColor clearColor];
	[btnBackNights addTarget:self action:@selector(prevNight)	forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:btnBackNights];
	[btnBackNights release];
	
	UIButton* btnNextNights = [[UIButton alloc] initWithFrame:CGRectMake(LABEL_X + LABEL_W, LABEL_Y, BUTTON_W/2, BUTTON_W)];
	btnNextNights.backgroundColor = [UIColor clearColor];
	[btnNextNights addTarget:self action:@selector(nextNight)	forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:btnNextNights];
	[btnNextNights release];
	
	bedroom = 2;
	lblBedrooms = [[UILabel alloc] initWithFrame:CGRectMake(LABEL_X, LABEL_Y+LABEL_V_SPACE, LABEL_W, LABEL_H)];
	lblBedrooms.backgroundColor = [UIColor clearColor];
	lblBedrooms.text = @"2";
	[lblBedrooms setFont:[UIFont fontWithName:@"Helvetica-Bold" size:30]];
	lblBedrooms.textAlignment = UITextAlignmentCenter;
	lblBedrooms.textColor = [UIColor colorWithRed:53/255.f green:112/255.f blue:110/255.f alpha:1.0];
	[self addSubview:lblBedrooms];
	
	UIButton* btnBackBedroom = [[UIButton alloc] initWithFrame:CGRectMake(LABEL_X - LABEL_W/2, LABEL_Y+LABEL_V_SPACE, BUTTON_W/2, BUTTON_W)];
	btnBackBedroom.backgroundColor = [UIColor clearColor];
	[btnBackBedroom addTarget:self action:@selector(prevBedroom)	forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:btnBackBedroom];
	[btnBackBedroom release];
	
	UIButton* btnNextBedroom = [[UIButton alloc] initWithFrame:CGRectMake(LABEL_X + LABEL_W, LABEL_Y+LABEL_V_SPACE, BUTTON_W/2, BUTTON_W)];
	btnNextBedroom.backgroundColor = [UIColor clearColor];
	[btnNextBedroom addTarget:self action:@selector(nextBedroom)	forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:btnNextBedroom];	
	[btnNextBedroom release];
	
	locat = 0;
	lblLocation = [[UILabel alloc] initWithFrame:CGRectMake(LOCATION_X+5, LOCATION_Y+3, LOCATION_W, LABEL_H)];
	lblLocation.backgroundColor = [UIColor clearColor];
	lblLocation.text = @"All";
	[lblLocation setFont:[UIFont fontWithName:@"Helvetica-Bold" size:12]];
	lblLocation.textColor = [UIColor colorWithRed:255/255.f green:116/255.f blue:35/255.f alpha:1.0];
	[self addSubview:lblLocation];
	
	UIButton* btnUp = [[UIButton alloc] initWithFrame:CGRectMake(LOCATION_X+LOCATION_W, LOCATION_Y, BUTTON_W, BUTTON_W)];
	[btnUp setBackgroundImage:[UIImage imageNamed:@"btn_normal0.png"] forState:UIControlStateNormal];
	[btnUp setBackgroundImage:[UIImage imageNamed:@"btn_highlight0.png"] forState:UIControlStateHighlighted];
	[btnUp setTitle:@"△" forState:UIControlStateNormal];
	[btnUp addTarget:self action:@selector(Decrease)	forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:btnUp];
	[btnUp release];
	
	UIButton* btnDown = [[UIButton alloc] initWithFrame:CGRectMake(LOCATION_X+LOCATION_W+BUTTON_W, LOCATION_Y, BUTTON_W, BUTTON_W)];
	[btnDown setBackgroundImage:[UIImage imageNamed:@"btn_normal0.png"] forState:UIControlStateNormal];
	[btnDown setBackgroundImage:[UIImage imageNamed:@"btn_highlight0.png"] forState:UIControlStateHighlighted];
	[btnDown setTitle:@"▽" forState:UIControlStateNormal];
	[btnDown addTarget:self action:@selector(Increase)	forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:btnDown];
	[btnDown release];
}

- (void) prevNight {
	nights--;
	if ( nights < 5 )
		nights = 5;
	lblNights.text = [NSString stringWithFormat:@"%d", nights];
}

- (void) nextNight {
	nights++;
	if ( nights > 28 )
		nights = 28;
	lblNights.text = [NSString stringWithFormat:@"%d", nights];
	
}

- (void) prevBedroom {
	bedroom--;
	if ( bedroom < 2 )
		bedroom = 2;
	lblBedrooms.text = [NSString stringWithFormat:@"%d", bedroom];
}

- (void) nextBedroom {
	bedroom++;
	if ( bedroom > 3 )
		bedroom = 3;
	lblBedrooms.text = [NSString stringWithFormat:@"%d", bedroom];
	
}

- (void) Increase {
	locat++;
	if ( locat > 4 )
		locat = 4;
	lblLocation.text = szLocations[locat];
}

- (void) Decrease {
	locat--;
	if ( locat < 0 )
		locat = 0;
	lblLocation.text = szLocations[locat];
}

- (NSString*) getRentalInfo {
	return [NSString stringWithFormat:@"nights=%@&bedrooms=%@&location=%@", lblNights.text, lblBedrooms.text, szLocationsKeys[locat]];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
	[lblNights release];
	[lblBedrooms release];
	[lblLocation release];
	
    [super dealloc];
}


@end
