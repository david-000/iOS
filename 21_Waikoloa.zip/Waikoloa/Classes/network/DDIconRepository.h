#import <UIKit/UIKit.h>

@class DDIconContainer;

@protocol DDIconContainerDelegate

- (void)didStartDownloading:(DDIconContainer*)container;
- (void)didFinishDownloading:(DDIconContainer*)container;
@end


@interface DDIconContainer : NSObject
{
	UIImage *iconImage;
	NSString *url;
	BOOL downloading;
	int tag;
	
	UIImageView* imageViwe;
	NSObject<DDIconContainerDelegate> *target;
}

@property (assign) int tag;
@property (copy) NSString *url;
@property (retain) UIImage *iconImage;
@property (nonatomic, retain) NSObject<DDIconContainerDelegate> *target;

- (id)initWithIconURL:(NSString*)theUrl withTarget:(NSObject<DDIconContainerDelegate>*)_target;

@end

@interface DDIconRepository : NSObject  {
	NSOperationQueue* operationQueue;
}

+ (DDIconRepository*) instance;
+ (UIImage*) defaultIcon;
+ (UIImage*) defaultPhoto;

- (DDIconContainer*) downloadForURL:(NSString*)url withTarget:(NSObject<DDIconContainerDelegate>*)_target;
- (void) removeAllIconRequest;

@end