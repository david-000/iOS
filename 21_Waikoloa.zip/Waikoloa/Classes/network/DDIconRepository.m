#import "DDIconRepository.h"
#import "DDCache.h"

static UIImage *default_icon = nil;
static UIImage* default_photo = nil;

static DDIconRepository *_instance = nil;

#define ICON_FETCH_NOTIFICATION	@"ICON_FETCH_NOTIFICATION"

@implementation DDIconContainer

@synthesize url;
@synthesize tag;
@synthesize target;
@synthesize iconImage;

- (id)initWithIconURL:(NSString*)theUrl withTarget:(NSObject<DDIconContainerDelegate>*)_target {
	if (self = [super init]) {
		self.url = theUrl;
		self.target = _target;
		tag = -1;

		[target didStartDownloading:self];
		NSData* imgData = [DDCache readFileWithURL:url lastModifyDate:nil];
		if (imgData) {			
			self.iconImage = [UIImage imageWithData:imgData];
			[target didFinishDownloading:self];
			self.target = nil;
		}
	}
	return self;
}

- (void)dealloc {
	
	[url release];
	[target release];
	[iconImage release];
	[super dealloc];
}

@end


@implementation DDIconRepository

+ (DDIconRepository*) instance {
    @synchronized (self) {
		
        if (!_instance) {
            _instance = [[self alloc] init];
        }
    }
    return _instance;
}

+ (UIImage*)defaultIcon {
	if (default_icon == nil) {
		default_icon = [[UIImage imageNamed:@"default_icon.png"] retain];
	}
	return default_icon;
}

+ (UIImage*)defaultPhoto {
	if (default_photo == nil) {
		default_photo = [[UIImage imageNamed:@"default_photo.png"] retain];
	}
	return default_photo;
}

- (id)init {
	if (self = [super init]) {
		operationQueue = [[NSOperationQueue alloc] init];
//		[[DDHttpClientPool sharedInstance] addIdleClientObserver:self selector:@selector(processDownloadQueue)];
	}
    return self;
}

- (void)dealloc {
	
	[operationQueue release];
//	[downloadQueue release];
//	[[DDHttpClientPool sharedInstance] removeIdleClientObserver:self];
	[super dealloc];
	
}

- (void)processDownloadQueue:(DDIconContainer*) container {
	
	@synchronized (self) {

		NSInvocationOperation *newOperation = [[NSInvocationOperation alloc] initWithTarget:self
																				   selector:@selector(requestDownload:)
																					  object:container];
		[operationQueue addOperation:newOperation];
		[newOperation release];
	}
}

- (void)requestDownload:(DDIconContainer*)container {
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];	
	NSData* data = [NSData dataWithContentsOfURL:[NSURL URLWithString:container.url]];
	
	[DDCache saveFileWithURL:container.url data:data modifyDate:nil];
	
	container.iconImage = [UIImage imageWithData:data];
	[container.target performSelectorOnMainThread:@selector(didFinishDownloading:) withObject:container waitUntilDone:YES];
	container.target = nil;
	[pool release];
}


- (DDIconContainer*) downloadForURL:(NSString*)url withTarget:(NSObject<DDIconContainerDelegate>*)_target {
	
	DDIconContainer* container = [[DDIconContainer alloc] initWithIconURL:url withTarget:_target];
	if (container.iconImage)
		return [container autorelease];
	
	[_target didStartDownloading:container];
	[self processDownloadQueue:container];
	return [container autorelease];
}

- (void) removeAllIconRequest {

}

@end
