#import <UIKit/UIKit.h>

#define TIMEOUT_SEC		20.0

typedef enum _tagDDHTTPClientRequestType {
	
	CT_MASTER_CATEGORY_INFO_REQUEST,
	CT_PROMOTION_INFO_REQUEST,
	CT_CATEGORY_INFO_REQUEST,
	CT_CATEGORY_SEARCH_INFO_REQUEST,
	CT_CATEGORY_DETAIL_INFO_REQUEST,
	CT_LOCATION_INFO_REQUEST,
	CT_RECOMMEND_INFO_REQUEST,
	
} DDHTTPClientRequestType;


@class DDHttpClient;

@protocol DDHttpClientDelegate
- (void)ddHttpClientSucceeded:(DDHttpClient*)sender;
- (void)ddHttpClientFailed:(DDHttpClient*)sender;
@end


@interface DDHttpClient : NSObject {
	
    NSURLConnection *connection;
    NSMutableData *recievedData;
	int statusCode;	
	BOOL contentTypeIsXml;
	
	NSDate *updateDate;
	
	DDHTTPClientRequestType		requestType;
	id <DDHttpClientDelegate> delegate;

	NSDictionary* result;
	int totalCount;
	int request_page;
	NSString*	identifier;
	NSString*   requestURL;
}

@property (retain) NSMutableData *recievedData;
@property (retain) NSURLConnection *connection;
@property (readonly) int statusCode;
@property (assign) id<DDHttpClientDelegate> delegate;
@property (retain) 	NSDictionary* result;
@property (assign) 	int totalCount;
@property (copy) 	NSString*	identifier;
@property (assign) DDHTTPClientRequestType		requestType;
@property (retain) NSDate* updateDate;
@property (copy) 	NSString*   requestURL;

- (BOOL)loadCache:(NSString*)url;
- (BOOL)requestGET:(NSString*)url;
- (BOOL)requestPOST:(NSString*)url body:(NSString*)body;
- (BOOL)requestGET:(NSString*)url username:(NSString*)username password:(NSString*)password;
- (BOOL)requestPOST:(NSString*)url body:(NSString*)body username:(NSString*)username password:(NSString*)password;

- (void)cancel;
- (void)reset;

- (void) getRSSInfoWithURL:(NSString*)url;

@end
