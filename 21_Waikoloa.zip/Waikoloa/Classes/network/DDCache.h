//
//  DDCache.h
//  ApplicationLoader
//
//  Created by Wang Xue on 8/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>


@interface DDCache : NSObject {

}

+ (BOOL) IsAlreadyCahedData;
+ (NSString*)createCacheDirectoryWithName:(NSString*)name;
+ (void)saveFileWithURL:(NSString*)url data:(NSData*)data modifyDate:(NSDate*)modifiedDate;
+ (NSData*)readFileWithURL:(NSString*)url lastModifyDate:(NSDate**)modifiedDate;

+ (void)removeAllCachedData;
+ (NSDate*) getModiftyDateIfUpdated:(NSString*)urlString error:(NSError**)error;
+ (NSDate*) getModiftyDateIfUpdatedWithRequest:(NSMutableURLRequest*)request url:(NSString*)urlString error:(NSError**)error ;

@end
