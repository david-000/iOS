
#import "DDHttpClient.h"
#import "DDCache.h"
//#import "Global.h"
//#import "JSON.h"

@implementation DDHttpClient

@synthesize recievedData, statusCode, delegate, result, totalCount, identifier, requestType, updateDate, requestURL, connection;

- (id)init {
	if (self = [super init]) {
		//LOG(@"reset-init = %p", self);
		[self reset];
	}
	return self;
}

- (void)dealloc {
	
	[connection cancel];

	[requestURL release];
	[updateDate release];
	[identifier release];
	[result release];
	[connection release];
	[recievedData release];
	[super dealloc];
}

+ (NSString*)stringEncodedWithBase64:(NSString*)str
{
	static const char *tbl = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

	const char *s = [str UTF8String];
	int length = [str length];
	char *tmp = malloc(length * 4 / 3 + 4);

	int i = 0;
	int n = 0;
	char *p = tmp;
	
	while (i < length) {
		n = s[i++];
		n *= 256;
		if (i < length) n += s[i];
		i++;
		n *= 256;
		if (i < length) n += s[i];
		i++;
		
		p[0] = tbl[((n & 0x00fc0000) >> 18)];
		p[1] = tbl[((n & 0x0003f000) >> 12)];
		p[2] = tbl[((n & 0x00000fc0) >>  6)];
		p[3] = tbl[((n & 0x0000003f) >>  0)];
		
		if (i > length) p[3] = '=';
		if (i > length + 1) p[2] = '=';

		p += 4;
	}
	
	*p = '\0';
	
	NSString *ret = [NSString stringWithCString:tmp encoding:NSUTF8StringEncoding];
	free(tmp);

	return ret;
}

+ (NSString*) stringOfAuthorizationHeaderWithUsername:(NSString*)username password:(NSString*)password {
    return [@"Basic " stringByAppendingString:[DDHttpClient stringEncodedWithBase64:
											   [NSString stringWithFormat:@"%@:%@", username, password]]];
}

- (NSMutableURLRequest*)makeRequest:(NSString*)url {
	NSString *encodedUrl = (NSString*)CFURLCreateStringByAddingPercentEscapes(
										NULL, (CFStringRef)url, NULL, NULL, kCFStringEncodingUTF8);

	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];
	[request setURL:[NSURL URLWithString:encodedUrl]];
	[request setCachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData];
	[request setTimeoutInterval:TIMEOUT_SEC];
	[request setHTTPShouldHandleCookies:FALSE];
	[encodedUrl release];
	return request;
}

- (NSMutableURLRequest*)makeRequest:(NSString*)url username:(NSString*)username password:(NSString*)password {
	NSMutableURLRequest *request = [self makeRequest:url];
	[request setValue:[DDHttpClient stringOfAuthorizationHeaderWithUsername:username password:password]
   forHTTPHeaderField:@"Authorization"];
	return request;
}

- (void)reset {
	

	self.recievedData = [NSMutableData data];
	self.connection = nil;

	self.updateDate = nil;
	self.requestURL = nil;
	
	statusCode = 0;	
	contentTypeIsXml = NO;
	
	self.result = nil;
}

- (void)prepareWithRequest:(NSMutableURLRequest*)request {
	// do nothing (for OAuthHttpClient)
}

- (BOOL)loadCache:(NSString*)url {
	
	self.updateDate = nil;
	self.recievedData = nil;
	recievedData = [[DDCache readFileWithURL:url lastModifyDate:nil] mutableCopy];
	if (recievedData) {
		statusCode = 200;
		[self connectionDidFinishLoading:nil];
		return TRUE;
	}
	
	return FALSE;
}

- (BOOL)requestGET:(NSString*)url {

	[self reset];
	
//	NSError* error = nil;
//	self.updateDate = [DDCache getModiftyDateIfUpdated:url error:&error];
//	if (error)
//		return FALSE;
//	
//	if (updateDate == nil) {
//
//		LOG(@"cache = %p", self);
//		self.recievedData = nil;
//		recievedData = [[DDCache readFileWithURL:url lastModifyDate:nil] mutableCopy];
//		statusCode = 200;
//		[self performSelector:@selector(connectionDidFinishLoading:) withObject:nil afterDelay:0.01];
//		return TRUE;
//	}
	

	self.requestURL = url;
	NSMutableURLRequest *request = [self makeRequest:url];
	[self prepareWithRequest:request];
	connection = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES];
	return TRUE;
}

- (BOOL)requestPOST:(NSString*)url body:(NSString*)body {
	
	[self reset];

	NSMutableURLRequest *request = [self makeRequest:url];
	NSError* error = nil;
 	self.updateDate = [DDCache getModiftyDateIfUpdatedWithRequest:[request copy] url:url error:&error];
	if (error)
		return FALSE;		
	
	if (updateDate == nil) {
		self.recievedData = nil;
		recievedData = [[DDCache readFileWithURL:url lastModifyDate:nil] mutableCopy];
		[self connectionDidFinishLoading:nil];
		return TRUE;
	}

	self.requestURL = url;
	[request setHTTPMethod:@"POST"];
	if (body) {
		[request setHTTPBody:[body dataUsingEncoding:NSUTF8StringEncoding]];
	}
	[self prepareWithRequest:request];
	connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	return TRUE;
}

- (BOOL)requestGET:(NSString*)url username:(NSString*)username password:(NSString*)password {
	[self reset];
	
	NSMutableURLRequest *request = [self makeRequest:url username:username password:password];
	NSError* error = nil;
 	self.updateDate = [DDCache getModiftyDateIfUpdatedWithRequest:[request copy] url:url error:&error];
	if (error)
		return FALSE;		

	if (updateDate == nil) {
		self.recievedData = nil;
		recievedData = [[DDCache readFileWithURL:url lastModifyDate:nil] mutableCopy];
		[self connectionDidFinishLoading:nil];
		return TRUE;
	}
	
	self.requestURL = url;
	connection = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES];
	return TRUE;
}

- (BOOL)requestPOST:(NSString*)url body:(NSString*)body username:(NSString*)username password:(NSString*)password {
	[self reset];
	NSMutableURLRequest *request = [self makeRequest:url username:username password:password];
	NSError* error = nil;
 	self.updateDate = [DDCache getModiftyDateIfUpdatedWithRequest:[request copy] url:url error:&error];
	if (error)
		return FALSE;		

	if (updateDate == nil) {
		self.recievedData = nil;
		recievedData = [[DDCache readFileWithURL:url lastModifyDate:nil] mutableCopy];
		[self connectionDidFinishLoading:nil];
		return TRUE;
	}
	
 	self.requestURL = url;
	[request setHTTPMethod:@"POST"];
	if (body) {
		[request setHTTPBody:[body dataUsingEncoding:NSUTF8StringEncoding]];
	}
	connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	return TRUE;
}

- (void)cancel {

	[connection cancel];
	[self reset];
	[delegate ddHttpClientFailed:self];
}


-(void)connection:(NSURLConnection*)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge*)challenge { 
	[[challenge sender] cancelAuthenticationChallenge:challenge];
}


- (NSCachedURLResponse *)connection:(NSURLConnection *)connection willCacheResponse:(NSCachedURLResponse *)cachedResponse {
	return nil;
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	
	statusCode = [(NSHTTPURLResponse*)response statusCode];
	NSDictionary *header = [(NSHTTPURLResponse*)response allHeaderFields];

	contentTypeIsXml = NO;
	NSString *content_type = [header objectForKey:@"Content-Type"];
	if (content_type) {
		NSRange r = [content_type rangeOfString:@"xml"];
		if (r.location != NSNotFound) {
			contentTypeIsXml = YES;
		}
	}
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [recievedData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)_connection {
	

	if (_connection) {
		[DDCache saveFileWithURL:self.requestURL data:self.recievedData modifyDate:self.updateDate];
	}
	[delegate ddHttpClientSucceeded:self];
	//[self requestSucceeded];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError*) error {

	[delegate ddHttpClientFailed:self];
	//[self requestFailed:error];
}

#pragma mark -
#pragma mark fetch data method
- (void) getRSSInfoWithURL:(NSString*)url {

	requestType = CT_MASTER_CATEGORY_INFO_REQUEST;
	[self requestGET:url];
}

@end

