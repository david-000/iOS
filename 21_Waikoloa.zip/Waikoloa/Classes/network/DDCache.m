//
//  DDCache.m
//  ApplicationLoader
//
//  Created by Wang Xue on 8/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
//
#import <CommonCrypto/CommonDigest.h>
#import "DDCache.h"
//#import "Global.h"

@implementation DDCache

+ (NSString*)md5:(NSString*) str {
	
	const char *cStr = [str UTF8String];
	unsigned char result[CC_MD5_DIGEST_LENGTH];
	CC_MD5( cStr, strlen(cStr), result );
	return [NSString stringWithFormat: 
			@"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
			result[0], result[1],
			result[2], result[3],
			result[4], result[5],
			result[6], result[7],
			result[8], result[9],
			result[10], result[11],
			result[12], result[13],
			result[14], result[15]];
}

+ (NSString*)createCacheDirectoryWithName:(NSString*)name {
	NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES) objectAtIndex:0];
	[[NSFileManager defaultManager] createDirectoryAtPath:documentPath withIntermediateDirectories:YES attributes:nil error:nil];
	
	NSString* newDirPath = [documentPath stringByAppendingPathComponent:name];
	[[NSFileManager defaultManager] createDirectoryAtPath:newDirPath withIntermediateDirectories:YES attributes:nil error:nil];
	[[NSFileManager defaultManager] changeCurrentDirectoryPath:newDirPath];

	return newDirPath;
}

+ (void)saveFileWithURL:(NSString*)url data:(NSData*)data modifyDate:(NSDate*)modifiedDate{
	
	if (data == nil)
		return;
	
	NSString* fileName = [self md5:url];
	if ([[NSFileManager defaultManager] fileExistsAtPath:fileName])
		return;
	
//	NSDictionary *fileAttributes = [NSDictionary dictionaryWithObject:modifiedDate forKey:NSFileModificationDate];  
	
	if (![[NSFileManager defaultManager] createFileAtPath:fileName contents:data attributes:nil]) {  
		//LOG(@"Error setting file attributes for: %@ - %@", url);
	}
	else {
		[[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithInt:YES] forKey:@"Cache"];
		[[NSUserDefaults standardUserDefaults] synchronize];
	}
}

+ (BOOL) IsAlreadyCahedData {
	
	if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"Cache"] intValue]) {
		return YES;
	}
	return NO;
}

+ (NSData*)readFileWithURL:(NSString*)url lastModifyDate:(NSDate**)modifiedDate {
	
	NSData *ret = nil;
	NSError *error = nil; 
	
	NSString* fileName = [self md5:url];
	NSFileHandle *fh = [NSFileHandle fileHandleForReadingAtPath:fileName];
	if (modifiedDate)
		*modifiedDate = nil;
	
	if (fh) {
		ret = [fh readDataToEndOfFile];
		[fh closeFile];
		
		NSDictionary *fileAttributes = [[NSFileManager defaultManager] attributesOfItemAtPath:fileName error:&error];  
		if (error) {

		}
		
		if (modifiedDate) {
			*modifiedDate = [fileAttributes fileModificationDate];
		}
	}
	
	return ret;
}

+ (void)removeAllCachedData {
	[[NSFileManager defaultManager] removeItemAtPath:[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES) objectAtIndex:0] error:nil];
}

+ (NSDate*) getModiftyDateIfUpdatedWithRequest:(NSMutableURLRequest*)request url:(NSString*)urlString error:(NSError**)error {

    NSFileManager *fileManager = [NSFileManager defaultManager];  
    NSString *lastModifiedString = nil;
	
	[request setHTTPMethod:@"HEAD"];
	
    NSHTTPURLResponse *response = nil;  
    [NSURLConnection sendSynchronousRequest:request returningResponse:&response error: nil];  
    if ([response respondsToSelector:@selector(allHeaderFields)]) {  
        lastModifiedString = [[response allHeaderFields] objectForKey:@"Last-Modified"];  
    }
	else if (response == nil) {
		
		if (error != nil)
			*error = [NSError errorWithDomain:@"connection" code:0 userInfo:nil];
		return nil;
	}

	
    NSDate *lastModifiedServerDate = nil;
    @try {  
        NSDateFormatter *df = [[NSDateFormatter alloc] init];  
        df.dateFormat = @"EEE',' dd MMM yyyy HH':'mm':'ss 'GMT'";  
        df.locale = [[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"] autorelease];  
        df.timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];  
        lastModifiedServerDate = [df dateFromString:lastModifiedString];  
		[df release];
    }  
    @catch (NSException * e) {  
        NSLog(@"Error parsing last modified date: %@ - %@", lastModifiedString, [e description]);  
    }  

	
	NSString* fileName = [self md5:urlString];
    NSDate *lastModifiedLocalDate = nil;  
    if ([fileManager fileExistsAtPath:fileName]) {  
        NSError *error = nil;
        NSDictionary *fileAttributes = [fileManager attributesOfItemAtPath:fileName error:&error];  
        if (error) {
            NSLog(@"Error reading file attributes for: %@ - %@", urlString, [error localizedDescription]);  
        }
		
        lastModifiedLocalDate = [fileAttributes fileModificationDate];  

    }
	
    if (!lastModifiedLocalDate) {  
        return lastModifiedServerDate;
    }  

    if ([lastModifiedLocalDate laterDate:lastModifiedServerDate] == lastModifiedServerDate) {  
        return lastModifiedServerDate; 
    }
	
	return nil;
}


+ (NSDate*) getModiftyDateIfUpdated:(NSString*)urlString error:(NSError**)error{
	

    NSURL *url = [NSURL URLWithString:urlString];  
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];  
	
	return [self getModiftyDateIfUpdatedWithRequest:request url:urlString error:error];

}  

@end
