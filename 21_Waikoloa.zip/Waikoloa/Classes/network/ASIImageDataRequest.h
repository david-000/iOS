//
//  ASIImageDataRequest.h
//  MobileMovs
//
//  Created by Wang Xue on 11/11/11.
//  Copyright 2011 MobileMovs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"

@interface ASIImageDataRequest : NSObject {
	
}

+ (ASIImageDataRequest*) sharedInstance;
- (void) downloadImageWithURL:(NSString*) imageURL target:(id)delegate didFinishSelector:(NSString*)didFinishSelector withImageView:(UIImageView*)container;

@end
