//
//  ASIImageDataRequest.m
//  MobileMovs
//
//  Created by Wang Xue on 11/11/11.
//  Copyright 2011 MobileMovs. All rights reserved.
//

#import "ASIImageDataRequest.h"
#import "DDCache.h"

static ASIImageDataRequest* sharedInstance = nil;

@implementation ASIImageDataRequest

+ (ASIImageDataRequest*) sharedInstance {
	
	if (sharedInstance == nil) {
		sharedInstance = [[ASIImageDataRequest alloc] init];
	}
	
	return sharedInstance;
}

- (void) downloadImageWithURL:(NSString*) imageURL target:(id)delegate didFinishSelector:(NSString*)didFinishSelector withImageView:(UIImageView*)container {
	
	if (imageURL == nil) {
		return;
	}
	
	NSData* data = [DDCache readFileWithURL:imageURL lastModifyDate:nil];

	if (data) {
		container.image = [UIImage imageWithData:data];
		SEL finishSelector = NSSelectorFromString(didFinishSelector);
		if ([delegate respondsToSelector:finishSelector]) {
			[delegate performSelector:finishSelector withObject:container.image];
		}
		return;
	}
	
	NSMutableDictionary* dictionary = [NSMutableDictionary dictionaryWithObjectsAndKeys:container, @"container", 
									   imageURL, @"imageURL", 
									   didFinishSelector, @"finishSelector", 
									   delegate, @"delegate", nil];
	
	ASIHTTPRequest* imageDownloader = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:imageURL]];
	[imageDownloader setDelegate:self];
	[imageDownloader setUserInfo:dictionary];
	[imageDownloader setDidFinishSelector:@selector(requestDone:)];
	[imageDownloader startAsynchronous];
}

- (void) dealloc {

	[super dealloc];
}

- (void) requestDone:(ASIHTTPRequest*)request {
	
	NSData* data = [request responseData];
	UIImage* download_image = [UIImage imageWithData:data];
	
	if (download_image) {

		NSMutableDictionary* userInfo = (NSMutableDictionary*) [request userInfo];
		UIImageView* imageView = [userInfo objectForKey:@"container"];
		imageView.image = download_image;

		NSString* selectorName = [userInfo objectForKey:@"finishSelector"];
		SEL  selector = NSSelectorFromString(selectorName);
		
		id delegate = [userInfo objectForKey:@"delegate"];
		
		[DDCache saveFileWithURL:[userInfo objectForKey:@"imageURL"] data:data modifyDate:nil];
		
		if ([delegate respondsToSelector:selector]) {
			[delegate performSelector:selector withObject:download_image];
		}
	}
}

- (void) requestFailed:(ASIHTTPRequest*)request {
	
}

@end
