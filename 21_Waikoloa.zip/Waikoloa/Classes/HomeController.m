//
//  HomeController.m
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "HomeController.h"
#import "FlightsController.h"
#import "RestaurantsController.h"
#import "SitesSeeController.h"
#import "VacationController.h"
#import "DirectoryController.h"
#import "EventController.h"
#import "ContactusController.h"
#import "FBViewController.h"

@implementation HomeController

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
	//self.navigationController.navigationBar.hidden = YES;
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

#pragma mark ===
#pragma mark UI Item Actions

- (void) setTopBarStyle:(int)style {
	
	//self.navigationController.navigationBar.hidden = NO;
	//CustomNavigationBar* cnb = (CustomNavigationBar*)self.navigationController.navigationBar;
//	
//	cnb.hidden = YES;
//	[cnb setBarStyle:style];
}


- (IBAction) searchVacation {
	VacationController* vc = [[VacationController alloc] init];
	[self.navigationController pushViewController:vc animated:YES];
	[vc release];
}

- (IBAction) searchRestaurant {
	
	[self setTopBarStyle:0];
	
	RestaurantsController* rc = [[RestaurantsController alloc] init];
	[self.navigationController pushViewController:rc animated:YES];
	[rc release];
}

- (IBAction) facebookUs {

	FBViewController* fbc = [[FBViewController alloc] init];
	[self.navigationController pushViewController:fbc animated:YES];
	[fbc release];
}

- (IBAction) flightsStatus {	
	[self setTopBarStyle:0];
	
	FlightsController* fc = [[FlightsController alloc] init];
	[self.navigationController pushViewController:fc animated:YES];
	[fc release];
}

- (IBAction) sitesToSee {
	[self setTopBarStyle:0];
	
	SitesSeeController* ssc = [[SitesSeeController alloc] init];
	[self.navigationController pushViewController:ssc animated:YES];
	[ssc release];
}

- (IBAction) scheduledEvent {
	EventController* ec = [[EventController alloc] init];
	[self.navigationController pushViewController:ec animated:YES];
	[ec release];
}

- (IBAction) directory {
	
	DirectoryController* dc = [[DirectoryController alloc] init];
	[self.navigationController pushViewController:dc animated:YES];
	[dc release];
	
}

- (IBAction) contactUs {
	ContactusController* cc = [[ContactusController alloc] init];
	[self.navigationController pushViewController:cc animated:YES];
	[cc release];	
}

@end
