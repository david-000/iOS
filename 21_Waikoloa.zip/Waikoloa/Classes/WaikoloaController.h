//
//  WaikoloaController.h
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol WaikoloaDelegate

- (void) loginSuccess;

@end


@interface WaikoloaController : UIViewController <UITextFieldDelegate> {
	UITextField*	m_tfName;
	UITextField*	m_tfPassword;
	
	BOOL	m_bScrollUp;
	
	id<WaikoloaDelegate>	m_waikoloDelegate;
}

@property (nonatomic, retain) IBOutlet UITextField* m_tfName;
@property (nonatomic, retain) IBOutlet UITextField* m_tfPassword;
@property (nonatomic, assign) id<WaikoloaDelegate>	m_waikoloDelegate;


- (IBAction) waikoloaLogin;

@end
