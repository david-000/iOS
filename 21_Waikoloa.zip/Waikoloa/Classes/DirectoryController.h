//
//  DirectoryController.h
//  Vacation
//
//  Created by Free on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DirectoryController : UIViewController<UITableViewDelegate, UITableViewDataSource> {
	NSMutableArray*	mContactList;
}

@property (nonatomic, retain) IBOutlet UITableView* tblContactList;

- (IBAction) goBack;

@end
