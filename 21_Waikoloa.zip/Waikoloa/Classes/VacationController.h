//
//  VacationController.h
//  Vacation
//
//  Created by Free on 11/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomCalView.h"
#import "VacationRentalPage.h"

@interface VacationController : UIViewController<CustomCalDelegate> {
	BOOL	bShowCalendar;
	
	VacationRentalPage*	vrPage;
}

@property (nonatomic, retain) IBOutlet UITextField* tfArrivalDate;
@property (nonatomic, retain) IBOutlet UIView*	swapView;


-(IBAction) setArrivalDate;
-(IBAction) goBack;
-(IBAction) searchRant;
- (NSDate*) getDateFromString:(NSString*)_fmStr;
@end
