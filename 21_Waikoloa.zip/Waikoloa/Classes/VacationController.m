//
//  VacationController.m
//  Vacation
//
//  Created by Free on 11/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "VacationController.h"
#import "CustomCalView.h"
#import "common.h"
#import "MainInfo.h"

@implementation VacationController

@synthesize tfArrivalDate, swapView;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];		
	
	tfArrivalDate.text = [[MainInfo getInstance] getTodayDate];
	
	vrPage = [[VacationRentalPage alloc] initWithFrame:[self.swapView bounds]];
	[swapView addSubview:vrPage];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return ([self.navigationController popViewControllerAnimated:YES]; == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[tfArrivalDate release];
	[swapView release];
	[vrPage release];
    [super dealloc];
}

- (NSDate*) getDateFromString:(NSString*)_fmStr {
	NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
	[dateFormat setFormatterBehavior:NSDateFormatterBehavior10_4];
	[dateFormat setDateFormat:@"yyyy-MM-dd"];
	
	NSDate* date = [dateFormat dateFromString:_fmStr];
	
	[dateFormat release];
	
	return date;
}

-(IBAction) setArrivalDate {
	
	if ( bShowCalendar )
		return;
	
	[vrPage setHidden:YES];
	bShowCalendar = TRUE;
	
	NSDate* initDate = nil;
	
	if ( [tfArrivalDate.text isEqualToString:@""] ){
		initDate = [NSDate date];
	}else {
		initDate = [self getDateFromString:tfArrivalDate.text];
	}
	
	CustomCalView* ccv = [[CustomCalView alloc] initWithDate:initDate :FALSE];	
	ccv.tag = 200;
	ccv.myDelegate = self;
	[swapView addSubview:ccv];
	[ccv release];
}

-(IBAction) goBack {
	[self.navigationController popViewControllerAnimated:YES];
}

-(IBAction) searchRant {
	
	NSString* szInfo = [vrPage getRentalInfo];
	NSString* szJumpURL = [NSString stringWithFormat:@"%@arrival_date=%@&%@", RENTAL_URL, tfArrivalDate.text, szInfo];
	
	NSLog(@"%@", szJumpURL);
	
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:szJumpURL]];
}

#pragma mark -
#pragma mark CustomCalDelegate
- (void) didSelectedDay:(NSString*)selectDay {
	bShowCalendar = FALSE;	
	tfArrivalDate.text = selectDay;
	
	CustomCalView* ccv = (CustomCalView*)[swapView viewWithTag:200];
	if ( ccv != nil )
		[ccv removeFromSuperview];

	[vrPage setHidden:NO];
}
@end
