//
//  EventController.m
//  Vacation
//
//  Created by Free on 11/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "EventController.h"
#import <QuartzCore/QuartzCore.h>
#import "MainInfo.h"
#import "common.h"
#import "ASIFormDataRequest.h"


@implementation EventController
@synthesize itvDescription, itbBar, szCurrentDate;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

	CustomCalView* ccv = [[CustomCalView alloc] initWithDate:[NSDate date] :NO];
	ccv.myDelegate = self;
	self.szCurrentDate = [ccv getToday];
	[ccv setCenter:CGPointMake(160, 160)];
	[self.view addSubview:ccv];
	[ccv release];
	
	self.itvDescription.font = [UIFont fontWithName:@"Helvetica Neue" size:14];
	self.itvDescription.layer.cornerRadius = 5.0;
	self.itvDescription.alpha = 0.8;
	self.itvDescription.layer.borderColor = [[UIColor grayColor] CGColor];	
	[self.itvDescription.layer setBackgroundColor:[[UIColor whiteColor] CGColor]];
	self.itvDescription.layer.borderWidth = 1;
	
	self.itbBar.center = CGPointMake(160, 540);

	if ( [[MainInfo getInstance] IsAdminAccount] )
		self.itvDescription.editable = YES;
	else 
		self.itvDescription.editable = NO;

	[self performSelectorOnMainThread:@selector(requestText:) withObject:szCurrentDate waitUntilDone:NO];
}

- (IBAction) goBack {
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction) editDone {
	[self performSelectorOnMainThread:@selector(sendText:) withObject:itvDescription.text waitUntilDone:NO];	
	[itvDescription resignFirstResponder];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;	
}


- (void)dealloc {
	[itvDescription release];
	[itbBar release];
	[szCurrentDate release];
    [super dealloc];
}

#pragma mark -
#pragma mark UITextViewDelegate
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
	NSNotificationCenter* nc = [NSNotificationCenter defaultCenter];
	[nc addObserver:self 
		   selector:@selector(keyboardWillShow:) 
			   name:UIKeyboardWillShowNotification 
			 object:nil];
	[nc addObserver:self 
		   selector:@selector(keyboardWillHide:) 
			   name:UIKeyboardWillHideNotification 
			 object:nil];
	
	return YES;
}

#pragma mark ===
#pragma mark UIWindow Keyboard Notifications
- (void) keyboardWillShow:(NSNotification*) notification {
	UIViewAnimationCurve animationCurve = [[[notification userInfo] valueForKey:UIKeyboardAnimationCurveUserInfoKey] intValue];
	NSTimeInterval animationDuration = [[[notification userInfo] valueForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
	
	CGRect keyboardBounds = [(NSValue*)[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
	
	[UIView beginAnimations:@"showKeyboardAnimation" context:nil];
	[UIView setAnimationCurve:animationCurve];
	[UIView setAnimationDuration:animationDuration];
	
	self.itbBar.center = CGPointMake(160, 462);
	self.view.center = CGPointMake(160, 100 - keyboardBounds.size.height / 2);
	
	[UIView commitAnimations];
}

- (void) keyboardWillHide:(NSNotification*) notification {
	UIViewAnimationCurve animationCurve = [[[notification userInfo] valueForKey:UIKeyboardAnimationCurveUserInfoKey] intValue];
	NSTimeInterval animationDuration = [[[notification userInfo] valueForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
	CGRect keyboardBounds = [(NSValue*)[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
	
	self.view.center = CGPointMake(160, 240 - keyboardBounds.size.height / 2);
	
	[UIView beginAnimations:@"hideKeyboardAnimation" context:nil];
	[UIView setAnimationCurve:animationCurve];
	[UIView setAnimationDuration:animationDuration];
	
	self.view.center = CGPointMake(160, 232);
	self.itbBar.center = CGPointMake(160, 540);	
	
	[UIView commitAnimations];
}

#pragma mark -
#pragma mark CustomCalView Delegate
- (void) didSelectedDay:(NSString*)selectDay {
	[self performSelectorOnMainThread:@selector(requestText:) withObject:selectDay waitUntilDone:NO];
}

#pragma mark -
#pragma mark MemoList request & download
- (void) requestText:(NSString*)szDay {
	
	self.szCurrentDate = szDay;
	
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
//	ASIHTTPRequest* request = [ASIHTTPRequest requestWithURL:
//										[NSURL URLWithString:[NSString stringWithFormat:@"%@%@", SERVER_URL, REQUEST_SERVER_URL]]];
//	
//	NSString* szPostData = [NSString stringWithFormat:@"event_date=%@", szDay];	
//	[request setDelegate:self];
//	[request setRequestMethod:@"POST"];	
//	[request setPostBody:[NSMutableData dataWithData:[szPostData dataUsingEncoding:NSUTF8StringEncoding]]];
//	[request setDidFinishSelector:@selector(requestDone:)];
//	[request setDidFailSelector:@selector(requestFailed:)];
//	[request startAsynchronous];
	
	NSString* szRequest = [NSString stringWithFormat:@"%@%@", SERVER_URL, REQUEST_SERVER_URL];
	
	ASIFormDataRequest* request1 = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:szRequest]];	
	[request1 setRequestMethod:@"POST"];
	[request1 setPostValue:szDay forKey:@"event_date"];	
	[request1 setDelegate:self];
	[request1 setDidFinishSelector:@selector(requestDone:)];
	[request1 setDidFailSelector:@selector(requestFailed:)];
	[request1 startAsynchronous];	
	
	[pool release];
}

- (void) requestDone:(ASIFormDataRequest*)request {
	NSData* response = [request responseData];
	NSString* theString = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
		
	self.itvDescription.text = theString;	
}

- (void) requestFailed:(ASIFormDataRequest*)request {

	self.itvDescription.text = @"";
}

- (void) sendText:(NSString*)szMsg {
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	NSString* szRequest = [NSString stringWithFormat:@"%@%@", SERVER_URL, RESPONSE_SERVER_URL];
	
	ASIFormDataRequest* request1 = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:szRequest]];	
	[request1 setRequestMethod:@"POST"];
	[request1 setPostValue:szCurrentDate forKey:@"event_date"];
	[request1 setPostValue:szMsg forKey:@"event_content"];	
	[request1 setDelegate:self];
	[request1 setDidFailSelector:@selector(requestFailed1:)];
	[request1 startAsynchronous];
	
	[pool release];		
}

- (void) requestFailed1:(ASIFormDataRequest*)request {

	UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Alert"
													message:@"upload text error!!!" 
												   delegate:nil
										  cancelButtonTitle:@"close"
										  otherButtonTitles:nil];
	[alert show];
	[alert release];
	
}

@end
