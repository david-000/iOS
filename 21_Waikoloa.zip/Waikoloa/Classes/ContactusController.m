//
//  ContactusController.m
//  Vacation
//
//  Created by Free on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ContactusController.h"


@implementation ContactusController

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

- (IBAction) goBack {
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction) callAction {
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tel://808-987-4519"]];
}

- (IBAction) textAction {
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"sms:55555"]];
}

- (IBAction) mailAction {
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"mailto://WaikoloaVRM@aol.com"]];
}

- (IBAction) websiteAction {
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.WaikoloaVacationRentals.com"]];
}

@end
