//
//  FaceBookController.m
//  Vacation
//
//  Created by Free on 11/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FaceBookController.h"

#define kFACE_BOOK_APPID @"272542819436580"

@implementation FaceBookController

@synthesize m_tfName, m_tfPassword, facebook = _facebook;
@synthesize _fbButton;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (!kFACE_BOOK_APPID) {
		NSLog(@"missing app id!");
		exit(1);
		return nil;
	}
	
	if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
		_permissions =  [[NSArray arrayWithObjects:
						  @"read_stream", @"publish_stream", @"offline_access",nil] retain];
		_facebook = [[Facebook alloc] initWithAppId:kFACE_BOOK_APPID
										andDelegate:self];
		
		NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
		if ([defaults objectForKey:@"FBAccessTokenKey"] 
			&& [defaults objectForKey:@"FBExpirationDateKey"]) {
			_facebook.accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
			_facebook.expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
		}
	}
	
    return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

	m_bScrollUp = FALSE;
	
	if ([_facebook isSessionValid]) {
//		caption.hidden = NO;
//		_uploadPhotoButton.hidden = NO;
//		_description.hidden = NO;
//		
//		_fbButton.isLoggedIn = YES;
//		[_fbButton updateImage];
	}
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[m_tfName release];
	[m_tfPassword release];
	[_fbButton release];
	[_facebook release];
	[_permissions release];
    [super dealloc];
}

- (IBAction) goBack {
	[self.navigationController popViewControllerAnimated:YES];
}

- (IBAction) facebookLogin {
	if (![_facebook isSessionValid]) {
		[_facebook authorize:_permissions];
		return;
	}
}

#pragma mark ===
#pragma mark UITextField Delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
	
	if ( !m_bScrollUp ){
		m_bScrollUp = TRUE;
		
		NSNotificationCenter* nc = [NSNotificationCenter defaultCenter];
		[nc addObserver:self 
			   selector:@selector(keyboardWillShow:) 
				   name:UIKeyboardWillShowNotification 
				 object:nil];
		[nc addObserver:self 
			   selector:@selector(keyboardWillHide:) 
				   name:UIKeyboardWillHideNotification 
				 object:nil];
		
	}
	
	return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	
	if ( textField == m_tfName ){
		[m_tfPassword becomeFirstResponder];
	}else {
		m_bScrollUp = FALSE;
		[textField resignFirstResponder];
	}
	
	return YES;
}

#pragma mark ===
#pragma mark UIWindow Keyboard Notifications
- (void) keyboardWillShow:(NSNotification*) notification {
	UIViewAnimationCurve animationCurve = [[[notification userInfo] valueForKey:UIKeyboardAnimationCurveUserInfoKey] intValue];
	NSTimeInterval animationDuration = [[[notification userInfo] valueForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
	
	CGRect keyboardBounds = [(NSValue*)[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
	
	[UIView beginAnimations:@"showKeyboardAnimation" context:nil];
	[UIView setAnimationCurve:animationCurve];
	[UIView setAnimationDuration:animationDuration];
	
	self.view.center = CGPointMake(160, 240 - keyboardBounds.size.height / 2);
	
	[UIView commitAnimations];
}

- (void) keyboardWillHide:(NSNotification*) notification {
	UIViewAnimationCurve animationCurve = [[[notification userInfo] valueForKey:UIKeyboardAnimationCurveUserInfoKey] intValue];
	NSTimeInterval animationDuration = [[[notification userInfo] valueForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
	CGRect keyboardBounds = [(NSValue*)[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
	
	self.view.center = CGPointMake(160, 240 - keyboardBounds.size.height / 2);
	[UIView beginAnimations:@"hideKeyboardAnimation" context:nil];
	[UIView setAnimationCurve:animationCurve];
	[UIView setAnimationDuration:animationDuration];

	self.view.center = CGPointMake(160, 230);
	
	[UIView commitAnimations];
}

#pragma mark -
#pragma mark FBRequestDelegate
/**
 * Called when the Facebook API request has returned a response. This callback
 * gives you access to the raw response. It's called before
 * (void)request:(FBRequest *)request didLoad:(id)result,
 * which is passed the parsed response object.
 */
- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response {
	NSLog(@"received response");
}

/**
 * Called when a request returns and its response has been parsed into
 * an object. The resulting object may be a dictionary, an array, a string,
 * or a number, depending on the format of the API response. If you need access
 * to the raw response, use:
 *
 * (void)request:(FBRequest *)request
 *      didReceiveResponse:(NSURLResponse *)response
 */
- (void)request:(FBRequest *)request didLoad:(id)result {
	
	[[UIApplication sharedApplication] endIgnoringInteractionEvents];
	
	if ([result isKindOfClass:[NSArray class]]) {
		result = [result objectAtIndex:0];
	}
	
	if ([result objectForKey:@"owner"]) {
		
	}
	else {
		//		[self.label setText:[result objectForKey:@"name"]];
	}
	
	UIAlertView * alerView = [[UIAlertView alloc] initWithTitle:@"Information" message:@"Publish Successfully." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alerView show];
	[alerView release];
};

/**
 * Called when an error prevents the Facebook API request from completing
 * successfully.
 */
- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
	//  [self.label setText:[error localizedDescription]];
	
	[[UIApplication sharedApplication] endIgnoringInteractionEvents];
	
	UIAlertView * alerView = [[UIAlertView alloc] initWithTitle:@"Information" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alerView show];
	[alerView release];
	
};

#pragma mark -
#pragma mark FBDialogDelegate

/**
 * Called when a UIServer Dialog successfully return.
 */
- (void)dialogDidComplete:(FBDialog *)dialog {
	
	UIAlertView * alerView = [[UIAlertView alloc] initWithTitle:@"Information" message:@"Publish Successfully." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alerView show];
	[alerView release];
}
@end
