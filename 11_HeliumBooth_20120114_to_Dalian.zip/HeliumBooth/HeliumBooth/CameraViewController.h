//
//  CameraViewController.h
//  HeliumBooth
//
//  Created by RiSongIl on 11/13/11.
//  Copyright 2011 snow. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "ExpandyButton.h"
#include "AQRecorder.h"

@class CaptureManager, CameraPreview;

enum EnumVoiceType {
    	BearVoice = 0,
        MouseVoice = 1
    };

@interface CameraViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    @private
    CaptureManager *_captureManager;
    CameraPreview *_videoPreviewView;
    AVCaptureVideoPreviewLayer *_captureVideoPreviewLayer;
    
    IBOutlet UIButton* m_btnRecord;
    IBOutlet UIButton* m_btnVoiceControl;
    IBOutlet UIButton* m_btnCameraSwitch;
    IBOutlet UIButton* m_btnFlash;
    IBOutlet UILabel*  m_pTimeLabel;
    
    ExpandyButton *_flash;
    NSString*   m_szMovieBasePath;
    enum EnumVoiceType m_nVoiceType;
    NSMutableArray*    m_arrayAnimationImg;
    IBOutlet UIImageView*   m_viewAnimation;
    NSTimer*            m_ClockTimer;
    int m_nCurTime;
//    NSTimer*                m_pRecordTimer;

    // Add by RSI 2011/11/14
    AQRecorder* m_pRecorder;
}

@property (nonatomic,retain) CaptureManager *captureManager;
@property (nonatomic,retain) IBOutlet CameraPreview *videoPreviewView;
@property (nonatomic,retain) AVCaptureVideoPreviewLayer *captureVideoPreviewLayer;
@property (nonatomic,retain) ExpandyButton *flash;

- (IBAction)record:(id)sender;
- (IBAction)flashChange:(id)sender;
- (IBAction)cameraToggle:(id)sender;
- (IBAction)actionCancel:(id)sender;
- (IBAction)actionVoiceControl:(id)sender;

#pragma mark Make Video
- (NSString*)MakeFilePath;

- (void) ShowResultView;

// Add by RSI 2011/11/14
- (void) InitAudio;
- (void) UninitAudio;
- (void) CreateAnimation;
- (void) StopAllRecording;

- (void) startRecord;
- (void) stopRecord;
- (void) StartAnimation;
- (void) StopAnimation;

@end
