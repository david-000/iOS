//
//  CameraViewController.m
//  HeliumBooth
//
//  Created by RiSongIl on 11/13/11.
//  Copyright 2011 snow. All rights reserved.
//

#import "CameraViewController.h"
#import "CameraPreview.h"
#import "CaptureManager.h"
#import "ResultViewController.h"
#import "HeliumBoothAppDelegate.h"

// KVO contexts
static void *AVCamDemoFocusModeObserverContext = &AVCamDemoFocusModeObserverContext;
static void *AVCamDemoTorchModeObserverContext = &AVCamDemoTorchModeObserverContext;
static void *AVCamDemoFlashModeObserverContext = &AVCamDemoFlashModeObserverContext;
static void *AVCamDemoAdjustingObserverContext = &AVCamDemoAdjustingObserverContext;

//@interface CameraViewController()
//
//
//@end

@interface CameraViewController (CaptureManagerDelegate) <CaptureManagerDelegate>
@end

@interface CameraViewController (CameraPreviewDelegate) <CameraPreviewDelegate>
@end

@implementation CameraViewController

@synthesize captureManager = _captureManager;
@synthesize videoPreviewView = _videoPreviewView;
@synthesize captureVideoPreviewLayer = _captureVideoPreviewLayer;
@synthesize flash = _flash;

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:(NSCoder *)aDecoder];
    if (self != nil) {
//        [self addObserver:self forKeyPath:@"captureManager.videoInput.device.flashMode" options:NSKeyValueObservingOptionNew context:AVCamDemoFlashModeObserverContext];
//        [self addObserver:self forKeyPath:@"captureManager.videoInput.device.torchMode" options:NSKeyValueObservingOptionNew context:AVCamDemoTorchModeObserverContext];
//        [self addObserver:self forKeyPath:@"captureManager.videoInput.device.focusMode" options:NSKeyValueObservingOptionNew context:AVCamDemoFocusModeObserverContext];
//        [self addObserver:self forKeyPath:@"captureManager.videoInput.device.adjustingFocus" options:NSKeyValueObservingOptionNew context:AVCamDemoAdjustingObserverContext];
//        [self addObserver:self forKeyPath:@"captureManager.videoInput.device.adjustingExposure" options:NSKeyValueObservingOptionNew context:AVCamDemoAdjustingObserverContext];
//        [self addObserver:self forKeyPath:@"captureManager.videoInput.device.adjustingWhiteBalance" options:NSKeyValueObservingOptionNew context:AVCamDemoAdjustingObserverContext];
    }
    return self;
 
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    NSString* szNibName;
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        szNibName = [NSString stringWithFormat:@"%@-iPad", nibNameOrNil];
    }
    else
    {
        szNibName = nibNameOrNil;
    }
    self = [super initWithNibName:szNibName bundle:nibBundleOrNil];
    
    
    return self;
}

- (void) dealloc
{
    [self setCaptureManager:nil];
    [super dealloc];    
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    self.wantsFullScreenLayout = YES;
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    m_nVoiceType = BearVoice;    
    NSError *error;    
    m_arrayAnimationImg = [[NSMutableArray alloc] init];
//    CALayer *adjustingInfolayer = [[self adjustingInfoView] layer];
//    [adjustingInfolayer setCornerRadius:hudCornerRadius];
//    [adjustingInfolayer setBorderColor:[[UIColor colorWithWhite:hudBorderWhite alpha:hudBorderAlpha] CGColor]];
//    [adjustingInfolayer setBorderWidth:hudBorderWidth];
//    [adjustingInfolayer setBackgroundColor:[[UIColor colorWithWhite:hudLayerWhite alpha:hudLayerAlpha] CGColor]];
//    [adjustingInfolayer setPosition:CGPointMake([adjustingInfolayer position].x, [adjustingInfolayer position].y + 12.f)];
    
    CaptureManager *captureManager = [[CaptureManager alloc] init];
    if ([captureManager setupSessionWithPreset:AVCaptureSessionPresetHigh error:&error]) {
        [self setCaptureManager:captureManager];
//        [capure:pCaptureManager];
        
        AVCaptureVideoPreviewLayer *captureVideoPreviewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:[captureManager session]];
        UIView *view = [self videoPreviewView];
        CALayer *viewLayer = [view layer];
        [viewLayer setMasksToBounds:YES];
        
        CGRect bounds = [view bounds];
        
        [captureVideoPreviewLayer setFrame:bounds];
        
        if ([captureVideoPreviewLayer isOrientationSupported]) {
            [captureVideoPreviewLayer setOrientation:AVCaptureVideoOrientationPortrait];
        }
        
        [captureVideoPreviewLayer setVideoGravity:AVLayerVideoGravityResizeAspectFill];
        [self setCaptureVideoPreviewLayer:captureVideoPreviewLayer];
        
//        NSDictionary *unanimatedActions = [[NSDictionary alloc] initWithObjectsAndKeys:[NSNull null], @"bounds",[NSNull null], @"frame",[NSNull null], @"position", nil];
//        CALayer *focusBox = [[CALayer alloc] init];
//        [focusBox setActions:unanimatedActions];
//        [focusBox setBorderWidth:3.f];
//        [focusBox setBorderColor:[[UIColor colorWithRed:0.f green:0.f blue:1.f alpha:.8f] CGColor]];
//        [focusBox setOpacity:0.f];
//        [viewLayer addSublayer:focusBox];
//        [self setFocusBox:focusBox];
//        [focusBox release];
//        
//        CALayer *exposeBox = [[CALayer alloc] init];
//        [exposeBox setActions:unanimatedActions];
//        [exposeBox setBorderWidth:3.f];
//        [exposeBox setBorderColor:[[UIColor colorWithRed:1.f green:0.f blue:0.f alpha:.8f] CGColor]];
//        [exposeBox setOpacity:0.f];
//        [viewLayer addSublayer:exposeBox];
//        [self setExposeBox:exposeBox];
//        [exposeBox release];
//        [unanimatedActions release];
//        
//        CGPoint screenCenter = CGPointMake(bounds.size.width / 2.f, bounds.size.height / 2.f);
//        
//        [self drawFocusBoxAtPointOfInterest:screenCenter];
//        [self drawExposeBoxAtPointOfInterest:screenCenter];        
        
        if ([[captureManager session] isRunning]) {
//            [self setConfigHidden:YES];
            NSInteger count = 0;
            if ([captureManager hasFlash]) 
            {
                m_btnFlash.selected = YES;
                count++;
            }
            else
                [m_btnFlash removeFromSuperview];
            
           [captureManager setDelegate:self];
            /**Need to add code by me **/
            
            NSUInteger cameraCount = [captureManager cameraCount];
            if (cameraCount < 2) {
                [m_btnCameraSwitch removeFromSuperview];
             } 
//            
//            if (cameraCount < 1 && [captureManager micCount] < 1) {
//                [[self recordButton] setEnabled:NO];
//            }
//            
            [viewLayer insertSublayer:captureVideoPreviewLayer below:[[viewLayer sublayers] objectAtIndex:0]];
            
            [captureVideoPreviewLayer release];
            
        } else {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Failure"
                                                                message:@"Failed to start session."
                                                               delegate:nil
                                                      cancelButtonTitle:@"Okay"
                                                      otherButtonTitles:nil];
            [alertView show];
            [alertView release];
        }
    } else {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Input Device Init Failed"
                                                            message:[error localizedDescription]
                                                           delegate:nil
                                                  cancelButtonTitle:@"Okay"
                                                  otherButtonTitles:nil];
        [alertView show];
        [alertView release];        
    }
    
    [captureManager release];
    
    // Add by RSI 2011/11/14
    [self InitAudio];
    [self CreateAnimation];
    
    [super viewDidLoad];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
//    [self removeObserver:self forKeyPath:@"captureManager.videoInput.device.flashMode"];
//    [self removeObserver:self forKeyPath:@"captureManager.videoInput.device.torchMode"];
//    [self removeObserver:self forKeyPath:@"captureManager.videoInput.device.focusMode"];
//    [self removeObserver:self forKeyPath:@"captureManager.videoInput.device.adjustingFocus"];
//    [self removeObserver:self forKeyPath:@"captureManager.videoInput.device.adjustingExposure"];
//    [self removeObserver:self forKeyPath:@"captureManager.videoInput.device.adjustingWhiteBalance"];
    
    [self setVideoPreviewView:nil];
    [self setCaptureVideoPreviewLayer:nil];
//    [self setAdjustingInfoView:nil];
//    [self setHudButton:nil];
//    [self setCameraToggleButton:nil];
//    [self setRecordButton:nil];
//    [self setGravityButton:nil];
    [self setFlash:nil];
//    [self setTorch:nil];
//    [self setFocus:nil];
//    [self setExposure:nil];
//    [self setWhiteBalance:nil];
//    [self setAdjustingFocus:nil];
//    [self setAdjustingExposure:nil];
//    [self setAdjustingWhiteBalance:nil];
//    [self setFocusBox:nil];
//    [self setExposeBox:nil];
    [m_arrayAnimationImg removeAllObjects];
    [m_arrayAnimationImg release];
    // Add by RSI 2011/11/14
    [self UninitAudio];
}

- (void) CreateAnimation
{
    UIImage* pImage;
    for (int i = 0; i < 21; i ++)
    {
        NSString* szImgName = [NSString stringWithFormat:@"smoke_%d.png",i];
        NSLog(@"File Namec=====%@", szImgName);
        pImage = [UIImage imageNamed:szImgName];
        [m_arrayAnimationImg addObject:pImage];
    }
    [m_viewAnimation setAnimationImages:m_arrayAnimationImg];
    m_viewAnimation.animationRepeatCount = 300;
    m_viewAnimation.animationDuration = 1.5;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void) StartAnimation
{
    [m_viewAnimation startAnimating];
}
- (void) StopAnimation
{
    [m_viewAnimation stopAnimating];
}

#pragma mark __
#pragma mark _Action Method__


- (IBAction)record:(id)sender
{
//    if (![[self captureManager] isRecording]) 
    if( !m_pRecorder->IsRunning() ) 
    {
        [self MakeFilePath];
        [[self captureManager] SetMovieBasePath:m_szMovieBasePath];
        [m_btnRecord setSelected:YES];
        m_nCurTime = 60;
        NSTimeInterval mainTimerInterval;
        mainTimerInterval = 1;
        m_ClockTimer = [NSTimer scheduledTimerWithTimeInterval:mainTimerInterval target:self selector:@selector(doneStep:) userInfo: nil repeats:YES];

        [[self captureManager] startRecording];
        /*start audio recording*/
        [self startRecord];
        [self StartAnimation];        
    } 
    else 
    {
        
        [self StopAllRecording];
        /*stop audio recording*/
        [m_btnRecord setSelected:NO];
        [self StopAnimation];
        /*stop video recording*/
        [[self captureManager] stopRecording];
        [self stopRecord];
        [self ShowResultView];

    }    
}

- (IBAction)flashChange:(id)sender
{
    switch ([(ExpandyButton *)sender selectedItem]) {
        case 0:
            [[self captureManager] setFlashMode:AVCaptureFlashModeOff];
            break;
        case 1:
            [[self captureManager] setFlashMode:AVCaptureFlashModeOn];
            break;
        case 2:
            [[self captureManager] setFlashMode:AVCaptureFlashModeAuto];
            break;
    }
   
}

- (IBAction)cameraToggle:(id)sender
{
    [[self captureManager] cameraToggle];
//    [[self focusBox] removeAllAnimations];
//    [[self exposeBox] removeAllAnimations];
//    [self resetFocusAndExpose];
    
    // Update displaying of expandy buttons (don't display buttons for unsupported features)
//    BOOL isConfigHidden = [self isConfigHidden];
    int count = 0;
    CaptureManager *captureManager = [self captureManager];
    ExpandyButton *expandyButton = [self flash];
    if ([captureManager hasFlash]) {
        CGRect frame = [expandyButton frame];
        [expandyButton setFrame:CGRectMake(8.f, 8.f + (40.f * count), frame.size.width, frame.size.height)];
        count++;
//        if (!isConfigHidden) [expandyButton setHidden:NO];
    } else {
        [expandyButton setHidden:YES];
    }
    
//    expandyButton = [self torch];
//    if ([captureManager hasTorch]) {
//        CGRect frame = [expandyButton frame];
//        [expandyButton setFrame:CGRectMake(8.f, 8.f + (40.f * count), frame.size.width, frame.size.height)];
//        count++;
//        if (!isConfigHidden) [expandyButton setHidden:NO];
//    } else {
//        [expandyButton setHidden:YES];
//    }
//    
//    expandyButton = [self focus];
//    if ([captureManager hasFocus]) {
//        CGRect frame = [expandyButton frame];
//        [expandyButton setFrame:CGRectMake(8.f, 8.f + (40.f * count), frame.size.width, frame.size.height)];
//        count++;
//        if (!isConfigHidden) [expandyButton setHidden:NO];
//    } else {
//        [expandyButton setHidden:YES];
//    }
//    
//    expandyButton = [self exposure];
//    if ([captureManager hasExposure]) {
//        CGRect frame = [expandyButton frame];
//        [expandyButton setFrame:CGRectMake(8.f, 8.f + (40.f * count), frame.size.width, frame.size.height)];
//        count++;
//        if (!isConfigHidden) [expandyButton setHidden:NO];
//    } else {
//        [expandyButton setHidden:YES];
//    }
//    
//    expandyButton = [self whiteBalance];
//    if ([captureManager hasWhiteBalance]) {
//        CGRect frame = [expandyButton frame];
//        [expandyButton setFrame:CGRectMake(8.f, 8.f + (40.f * count), frame.size.width, frame.size.height)];
//        if (!isConfigHidden) [expandyButton setHidden:NO];
//    } else {
//        [expandyButton setHidden:YES];
//    }     
}

- (IBAction)actionCancel:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES]; 
}

- (IBAction)actionVoiceControl:(id)sender
{
    if(m_pRecorder == nil)
        return;
    CGRect xFrame = m_btnVoiceControl.frame;
    int nDeviceType = 0;
    if(UI_USER_INTERFACE_IDIOM() == !UIUserInterfaceIdiomPad)
        nDeviceType = 1;
    else
        nDeviceType = 0;
    if(m_nVoiceType == BearVoice)
    {
        m_nVoiceType = MouseVoice;
        m_pRecorder->setPitch(9);
        if(nDeviceType == 1)/*iPhone Device*/
            xFrame.origin.x = 278.0f;
        else
            xFrame.origin.x = 650.0f;
    }
    else
    {
        m_nVoiceType = BearVoice;
        m_pRecorder->setPitch(-10);
        if(nDeviceType == 1)/*iPhone Device*/
            xFrame.origin.x = 255.0f;
        else if(nDeviceType == 0)
            xFrame.origin.x = 605.0f;
    }
    [m_btnVoiceControl setFrame:xFrame];    
}

- (void) doneStep:(id)sender 
{
    m_nCurTime --;
    NSString* szTime = [NSString stringWithFormat:@"%d", m_nCurTime];
    [m_pTimeLabel setText:szTime];
    if(m_nCurTime == 0)
    {
        [self StopAllRecording];
        
    }
}

- (void) ShowResultView
{
    HeliumBoothAppDelegate* appDelegate = (HeliumBoothAppDelegate*)[UIApplication sharedApplication].delegate;
    ResultViewController* controller = [[ResultViewController alloc] initWithNibName:@"ResultViewController" bundle:nil];
    NSString* szPreviewPath = [appDelegate GetFilePath:m_szMovieBasePath extension:@"jpg"];
    NSLog(@"XXX1_Name%@", szPreviewPath);
    [controller SetMovieFilePath:szPreviewPath];
    [self.navigationController pushViewController:controller animated:YES];
    

    [controller release];

}

- (NSString*)MakeFilePath
{
    if(m_szMovieBasePath != nil)
        [m_szMovieBasePath release];
    /*Get Current Time*/
    NSDate *today = [NSDate date];
    NSCalendar* gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *weekdayComponents = [gregorian components:(NSDayCalendarUnit | NSYearCalendarUnit | NSMonthCalendarUnit | NSHourCalendarUnit | NSSecondCalendarUnit | NSMinuteCalendarUnit) fromDate:today];
//    int year = [weekdayComponents year];
    int month = [weekdayComponents month];    
    int day = [weekdayComponents day];
    NSInteger nTime = [weekdayComponents hour];
    NSInteger nMins = [weekdayComponents minute];
    NSInteger nSec = [weekdayComponents second];    
    
    NSString* szFileName = [NSString stringWithFormat:@"/%d%d%d%d%d",month, day, nTime, nMins, nSec];
    [gregorian release];
    /*Get Document Path*/
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *DocumentsDirectory = [paths objectAtIndex:0];
    /*Get BasePath*/
    const char* SaveFile = [[DocumentsDirectory stringByAppendingString:szFileName]UTF8String];
    m_szMovieBasePath = [[NSString alloc] initWithUTF8String:SaveFile];
    
    return m_szMovieBasePath;
}

 
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if ([[change objectForKey:NSKeyValueChangeNewKey] isEqual:[NSNull null]]) {
        return;
    }
//    if (AVCamDemoFocusModeObserverContext == context) {
//        if ([[change objectForKey:NSKeyValueChangeNewKey] integerValue] != [[self focus] selectedItem]) {
//            [[self focus] setSelectedItem:[[change objectForKey:NSKeyValueChangeNewKey] integerValue]];
//        }
//    } else
    if (AVCamDemoFlashModeObserverContext == context) {
        if ([[change objectForKey:NSKeyValueChangeNewKey] integerValue] != [[self flash] selectedItem]) {
            [[self flash] setSelectedItem:[[change objectForKey:NSKeyValueChangeNewKey] integerValue]];
        }
    } 
//    else if (AVCamDemoTorchModeObserverContext == context) {
//        if ([[change objectForKey:NSKeyValueChangeNewKey] integerValue] != [[self torch] selectedItem]) {
//            [[self torch] setSelectedItem:[[change objectForKey:NSKeyValueChangeNewKey] integerValue]];
//        }
//    } else if (AVCamDemoAdjustingObserverContext == context) {
//        UIView *view = nil;
//        if ([keyPath isEqualToString:@"captureManager.videoInput.device.adjustingFocus"]) {
//            view = [self adjustingFocus];
//            [AVCamDemoViewController addAdjustingAnimationToLayer:[self focusBox] removeAnimation:NO];
//        } else if ([keyPath isEqualToString:@"captureManager.videoInput.device.adjustingExposure"]) {
//            view = [self adjustingExposure];
//            [AVCamDemoViewController addAdjustingAnimationToLayer:[self exposeBox] removeAnimation:NO];
//        } else if ([keyPath isEqualToString:@"captureManager.videoInput.device.adjustingWhiteBalance"]) {
//            view = [self adjustingWhiteBalance];
//        }
//        
//        if (view != nil) {
//            CALayer *layer = [view layer];
//            [layer setBorderWidth:1.f];
//            [layer setBorderColor:[[UIColor colorWithWhite:0.f alpha:.7f] CGColor]];
//            [layer setCornerRadius:8.f];
//            
//            if ([[change objectForKey:NSKeyValueChangeNewKey] boolValue] == YES) {
//                [layer setBackgroundColor:[[UIColor colorWithRed:1.f green:0.f blue:0.f alpha:.7f] CGColor]];
//            } else {
//                [layer setBackgroundColor:[[UIColor colorWithWhite:1.f alpha:.2f] CGColor]];
//            }
//        }
//    } 
    else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

// Add by RSI 2011/11/14
void interruptionListener(void *	inClientData,
                          UInt32	inInterruptionState)
{
	CameraViewController *THIS = (CameraViewController*)inClientData;
	if (inInterruptionState == kAudioSessionBeginInterruption)
	{
		if (THIS->m_pRecorder->IsRunning()) {
			[THIS stopRecord];
		}
	}
}

void propListener(void *                  inClientData,
                  AudioSessionPropertyID	inID,
                  UInt32                  inDataSize,
                  const void *            inData)
{
	CameraViewController *THIS = (CameraViewController*)inClientData;
	if (inID == kAudioSessionProperty_AudioRouteChange)
	{
		CFDictionaryRef routeDictionary = (CFDictionaryRef)inData;			
		CFNumberRef reason = (CFNumberRef)CFDictionaryGetValue(routeDictionary, CFSTR(kAudioSession_AudioRouteChangeKey_Reason));
		SInt32 reasonVal;
		CFNumberGetValue(reason, kCFNumberSInt32Type, &reasonVal);
		if (reasonVal != kAudioSessionRouteChangeReason_CategoryChange)
		{
			if (THIS->m_pRecorder->IsRunning()) {
				[THIS stopRecord];
			}
		}	
	}
	else if (inID == kAudioSessionProperty_AudioInputAvailable)
	{
		if (inDataSize == sizeof(UInt32)) {
			UInt32 isAvailable = *(UInt32*)inData;
			// disable recording if input is not available
			THIS->m_btnRecord.enabled = (isAvailable > 0) ? YES : NO;
		}
	}
}

- (void) InitAudio
{
    [self UninitAudio];
    m_pRecorder = new AQRecorder();
    
	OSStatus error = AudioSessionInitialize( NULL, NULL, interruptionListener, self );
	if( error )
    {
        printf( "ERROR INITIALIZING AUDIO SESSION! %d\n", (int)error );
    }
	else 
	{
		UInt32 category = kAudioSessionCategory_PlayAndRecord;	
		error = AudioSessionSetProperty(kAudioSessionProperty_AudioCategory, sizeof(category), &category);
		if( error ) printf( "couldn't set audio category!");
        
        UInt32 doChangeDefaultRoute = 1;
        AudioSessionSetProperty (kAudioSessionProperty_OverrideCategoryDefaultToSpeaker, sizeof (doChangeDefaultRoute), &doChangeDefaultRoute);
        
		error = AudioSessionAddPropertyListener(kAudioSessionProperty_AudioRouteChange, propListener, self);
		if (error) printf("ERROR ADDING AUDIO SESSION PROP LISTENER! %d\n", (int)error);
		
		error = AudioSessionSetActive(true); 
		if (error) printf("AudioSessionSetActive (true) failed");
	}
}

- (void) StopAllRecording
{
    /*stop audio recording*/
    [m_btnRecord setSelected:NO];
    [self StopAnimation];
    /*stop video recording*/
    [[self captureManager] stopRecording];
    [self stopRecord];
    if (m_ClockTimer != nil)
    {
        [m_ClockTimer invalidate];
        m_ClockTimer = nil;		
    }
    [self ShowResultView];    

}

- (void) UninitAudio
{
    AudioSessionSetActive( false );
    AudioSessionInitialize( NULL, NULL, NULL, NULL );
    
    if( m_pRecorder != nil )
    {
        delete m_pRecorder;
        m_pRecorder = nil;
    }
}


- (void) startRecord
{
    if( m_pRecorder->IsRunning() )
        return;
    HeliumBoothAppDelegate* appDelegate = (HeliumBoothAppDelegate*)[UIApplication sharedApplication].delegate;
    
    NSString* szAudioPath = [appDelegate GetFilePath:m_szMovieBasePath extension:@"caf"]; 
    m_pRecorder->StartRecord((CFStringRef)szAudioPath);
   
    if(m_nVoiceType == BearVoice)
        m_pRecorder->setPitch(-8);
    else if(m_nVoiceType == MouseVoice)
        m_pRecorder->setPitch(9);
}

- (void) stopRecord
{
    if( m_pRecorder->IsRunning() )
        m_pRecorder->StopRecord();
}




@end

@implementation CameraViewController (CaptureManagerDelegate)

- (void) captureStillImageFailedWithError:(NSError *)error
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Still Image Capture Failure"
                                                        message:[error localizedDescription]
                                                       delegate:nil
                                              cancelButtonTitle:@"Okay"
                                              otherButtonTitles:nil];
    [alertView show];
    [alertView release];
}

- (void) acquiringDeviceLockFailedWithError:(NSError *)error
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Device Configuration Lock Failure"
                                                        message:[error localizedDescription]
                                                       delegate:nil
                                              cancelButtonTitle:@"Okay"
                                              otherButtonTitles:nil];
    [alertView show];
    [alertView release];    
}

- (void) cannotWriteToAssetLibrary
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Incompatible with Asset Library"
                                                        message:@"The captured file cannot be written to the asset library. It is likely an audio-only file."
                                                       delegate:nil
                                              cancelButtonTitle:@"Okay"
                                              otherButtonTitles:nil];
    [alertView show];
    [alertView release];        
}

- (void) assetLibraryError:(NSError *)error forURL:(NSURL *)assetURL
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Asset Library Error"
                                                        message:[error localizedDescription]
                                                       delegate:nil
                                              cancelButtonTitle:@"Okay"
                                              otherButtonTitles:nil];
    [alertView show];
    [alertView release];    
}

- (void) someOtherError:(NSError *)error
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"                                                         message:[error localizedDescription]                                                     delegate:nil cancelButtonTitle:@"Okay"                                              otherButtonTitles:nil];
    [alertView show];
    [alertView release];    
}

- (void) recordingBegan
{
//    [[self recordButton] setTitle:@"Stop"];
//    [[self recordButton] setEnabled:YES];
}

- (void) recordingFinished
{
//    [[self recordButton] setTitle:@"Record"];
//    [[self recordButton] setEnabled:YES];
}

- (void) deviceCountChanged
{
//    AVCamDemoCaptureManager *captureManager = [self captureManager];
//    if ([captureManager cameraCount] >= 1 || [captureManager micCount] >= 1) {
//        [[self recordButton] setEnabled:YES];
//    } else {
//        [[self recordButton] setEnabled:NO];
//    }
    
}


@end



