//
//  CameraPreview.h
//  HeliumBooth
//
//  Created by RiSongIl on 11/13/11.
//  Copyright 2011 snow. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CameraPreviewDelegate <NSObject>
@optional



@end
@interface CameraPreview : UIView
{
    id<CameraPreviewDelegate> _delegate;
    
}
@property (nonatomic,retain) IBOutlet id <CameraPreviewDelegate> delegate;
@end
