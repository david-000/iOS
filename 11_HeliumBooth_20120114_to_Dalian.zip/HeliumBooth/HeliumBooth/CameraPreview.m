//
//  CameraPreview.m
//  HeliumBooth
//
//  Created by RiSongIl on 11/13/11.
//  Copyright 2011 snow. All rights reserved.
//

#import "CameraPreview.h"

@implementation CameraPreview

@synthesize delegate = _delegate;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
