//
//  CaptureManager.h
//  HeliumBooth
//
//  Created by RiSongIl on 11/13/11.
//  Copyright 2011 snow. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@protocol CaptureManagerDelegate
@optional
- (void) captureStillImageFailedWithError:(NSError *)error;
- (void) acquiringDeviceLockFailedWithError:(NSError *)error;
- (void) cannotWriteToAssetLibrary;
- (void) assetLibraryError:(NSError *)error forURL:(NSURL *)assetURL;
- (void) someOtherError:(NSError *)error;
- (void) recordingBegan;
- (void) recordingFinished;
- (void) deviceCountChanged;
@end

@interface CaptureManager : NSObject
{
    NSString* m_szMovieBasePath;
    @private
    AVCaptureSession *_session;
    AVCaptureDeviceInput *_videoInput;
    id <CaptureManagerDelegate> _delegate;
    
//    AVCaptureDeviceInput *_audioInput;
    AVCaptureMovieFileOutput *_movieFileOutput;
    AVCaptureStillImageOutput *_stillImageOutput;
    AVCaptureVideoDataOutput *_videoDataOutput;
//    AVCaptureAudioDataOutput *_audioDataOutput;
    id _deviceConnectedObserver;
    id _deviceDisconnectedObserver;
    UIBackgroundTaskIdentifier _backgroundRecordingID;  
}

@property (nonatomic,readonly,retain) AVCaptureSession *session;
@property (nonatomic,readonly,retain) AVCaptureDeviceInput *videoInput;
@property (nonatomic,assign) AVCaptureFlashMode flashMode;
@property (nonatomic,assign) AVCaptureTorchMode torchMode;
@property (nonatomic,assign) AVCaptureFocusMode focusMode;
@property (nonatomic,assign) AVCaptureExposureMode exposureMode;
@property (nonatomic,assign) AVCaptureWhiteBalanceMode whiteBalanceMode;
@property (nonatomic,readonly,getter=isRecording) BOOL recording;
@property (nonatomic,assign) id <CaptureManagerDelegate> delegate;
@property (nonatomic, assign) NSString* m_szMovieBasePath;

- (BOOL) setupSessionWithPreset:(NSString *)sessionPreset error:(NSError **)error;
- (NSUInteger) cameraCount;
- (NSUInteger) micCount;
- (void) startRecording;
- (void) stopRecording;
- (void) captureStillImage;
- (void) SavePreviewImage:(NSString*)szImgFilePath;
- (BOOL) cameraToggle;
- (BOOL) hasMultipleCameras;
- (BOOL) hasFlash;
- (BOOL) hasTorch;
- (BOOL) hasFocus;
- (BOOL) hasExposure;
- (BOOL) hasWhiteBalance;
- (void) focusAtPoint:(CGPoint)point;
- (void) exposureAtPoint:(CGPoint)point;
- (void) setConnectionWithMediaType:(NSString *)mediaType enabled:(BOOL)enabled;
- (void) SetMovieBasePath:(NSString*)szBasePath;
+ (AVCaptureConnection *)connectionWithMediaType:(NSString *)mediaType fromConnections:(NSArray *)connections;
@end
