//
//  CustomImageButton.h
//  Image
//
//  Created by System Administrator on 11/27/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductModel.h"

@interface CustomImageButton : UIButton {
	ProductModel *product;
}

@property (nonatomic, retain) ProductModel *product;

@end
