//
//  OrderModel.m
//  DynamicsNAV
//
//  Created by DEV on 1/15/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "OrderModel.h"


@implementation OrderModel

@synthesize productNo;
@synthesize orderDatetime;
@synthesize customerNo;
@synthesize quantity;

-(id)initialize
{
	[self reset];
	return self;
}

-(void)reset
{
	self.productNo = @"";
	self.orderDatetime = @"";
	self.customerNo = @"";
	self.quantity = 0;
}

@end
