//
//  Category.m
//  DynamicsNAV
//
//  Created by DEV on 1/12/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "Category.h"

@implementation Category

@synthesize productCategory;
@synthesize subProductCategory;

-(id)initialize
{
	[self reset];
	return self;
}

-(void)reset
{
	self.productCategory = @"";
	self.subProductCategory = @"";
}

@end
