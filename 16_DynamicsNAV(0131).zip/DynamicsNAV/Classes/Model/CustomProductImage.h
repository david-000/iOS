//
//  CustomProductImage.h
//  DynamicsNAV
//
//  Created by DEV on 1/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CustomImageButton.h"

@interface CustomProductImage : UIImageView {
	ProductModel *product;
	CustomImageButton *btnProduct;
}

@property (nonatomic, retain) ProductModel *product;
@property (nonatomic, retain) CustomImageButton *btnProduct;

- (void) drawWithProductInfo: (ProductModel *)productInfo;

@end
