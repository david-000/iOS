//
//  ProductModel.h
//  Image
//
//  Created by System Administrator on 11/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Category.h"

@interface ProductModel : NSObject {
	NSString *strNO;
	NSString *strDesc;
	int intUnitListPrice;
	int intUnitPrice;
	NSString *strSalesUnitMeasure;
	int intNyhed;
	int intWebForSide;
	NSString *strWebText;
	Category *category;
}

@property (nonatomic, retain) NSString *strNO;
@property (nonatomic, retain) NSString *strDesc;
@property (nonatomic) int intUnitListPrice;
@property (nonatomic) int intUnitPrice;
@property (nonatomic, retain) NSString *strSalesUnitMeasure;
@property (nonatomic) int intNyhed;
@property (nonatomic) int intWebForSide;
@property (nonatomic, retain) NSString *strWebText;
@property (nonatomic, retain) Category *category;

-(id)initialize;
-(void)reset;

@end
