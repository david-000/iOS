//
//  CustomerModel.m
//  DynamicsNAV
//
//  Created by DEV on 1/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "CustomerModel.h"


@implementation CustomerModel

@synthesize no;
@synthesize name1;
@synthesize name2;
@synthesize address1;
@synthesize address2;
@synthesize postCode;
@synthesize city;
@synthesize contact;
@synthesize contactPhoneNo;
@synthesize contactEmail;
@synthesize currencyCode;
@synthesize countryRegionCode;
@synthesize customerPriceGroup;
@synthesize paymentTermsCode;

-(id)initialize
{
	[self reset];
	return self;
}

-(void)reset
{
	self.no = @"";
	self.name1 = @"";
	self.name2 = @"";
	self.address1 = @"";
	self.address2 = @"";
	self.postCode = @"";
	self.city = @"";
	self.contact = @"";
	self.contactPhoneNo = @"";
	self.contactEmail = @"";
	self.currencyCode = @"";
	self.countryRegionCode = @"";
	self.customerPriceGroup = @"";
	self.paymentTermsCode = @"";
}

@end
