//
//  Category.h
//  DynamicsNAV
//
//  Created by DEV on 1/12/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Category : NSObject {
	NSString *productCategory;
	NSString *subProductCategory;
}

@property (nonatomic, retain) NSString *productCategory;
@property (nonatomic, retain) NSString *subProductCategory;

-(id)initialize;
-(void)reset;

@end
