//
//  CustomImageButton.m
//  Image
//
//  Created by System Administrator on 11/27/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CustomImageButton.h"


@implementation CustomImageButton

@synthesize product;

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
    }
    return self;
}

- (void)dealloc {
	[product release];
    [super dealloc];
}


@end
