//
//  CustomProductImage.m
//  DynamicsNAV
//
//  Created by DEV on 1/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "CustomProductImage.h"
#import "ImageAppDelegate.h"

@implementation CustomProductImage

@synthesize product;
@synthesize btnProduct;

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
    }
    return self;
}

- (void) drawWithProductInfo: (ProductModel *)productInfo
{
	if (productInfo == nil)
		return;
	
	[self setProduct:productInfo];
	
	[self setUserInteractionEnabled:YES];
	[self setImage:[UIImage imageNamed:@"orange_window.png"]];
	
	CGRect rect = [self bounds];
	
	CGPoint pt = rect.origin;
	CGSize size = rect.size;
	
	CGFloat x, y, width, height;
	
	x = pt.x + BORDER_SIZE;
	y = pt.y + BORDER_SIZE;
	width = size.width - (BORDER_SIZE * 2);
	height = size.height - (BORDER_SIZE * 2);
	
	btnProduct = [CustomImageButton buttonWithType:UIButtonTypeCustom];
	[btnProduct setFrame:CGRectMake(x, y, width, height)];
	[btnProduct setUserInteractionEnabled:YES];
	[btnProduct setProduct:productInfo];

	UILabel *lblTop = [[[UILabel alloc] initWithFrame:CGRectMake(x + BORDER_SIZE, y, width - BORDER_SIZE, LABEL_HEIGHT)] autorelease];
	[lblTop setBackgroundColor:[UIColor clearColor]];
	
	y = pt.y + size.height - BORDER_SIZE - LABEL_HEIGHT;
	UILabel *lblMiddle = [[[UILabel alloc] initWithFrame:CGRectMake(x, y, width * 2 / 3, LABEL_HEIGHT)] autorelease];
	[lblMiddle setBackgroundColor:[UIColor clearColor]];
	[lblMiddle setTextAlignment:UITextAlignmentRight];

	UILabel *lblBottom = [[[UILabel alloc] initWithFrame:CGRectMake(x + width * 2 / 3, y, width / 4, LABEL_HEIGHT)] autorelease];
	[lblBottom setTextAlignment:UITextAlignmentRight];
	[lblBottom setTextColor:[UIColor redColor]];
	[lblBottom setBackgroundColor:[UIColor clearColor]];

	NSString *path = [DOCUMENTS_FOLDER stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.jpg", [product strNO]]];

	if ([[NSFileManager defaultManager] fileExistsAtPath:path])
	{
		//			[imgBtn setBackgroundImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:url]] forState:UIControlStateNormal];
		[btnProduct setBackgroundImage:[UIImage imageWithContentsOfFile:path] forState:UIControlStateNormal];
	}
	else
	{
		[btnProduct setBackgroundImage:[UIImage imageNamed:@"NoImage.png"] forState:UIControlStateNormal];
	}
	
	[btnProduct setBackgroundColor:UIColor.clearColor];

	[lblTop setFont:[UIFont fontWithName:@"Helvetica Bold" size:20.0f]];
	[lblTop setText:[product strNO]];
	
	[lblBottom setFont:[UIFont fontWithName:@"American Typewriter" size:18.0f]];
	[lblBottom setText:[NSString stringWithFormat:@"$ %d", [product intUnitPrice]]];
	
	Category *cate = [product category];
	NSString *temp = nil;
	if (cate)
		temp = [NSString stringWithFormat:@"%@ %@", [[product category] productCategory], [product strSalesUnitMeasure]];
	else
		temp = [NSString stringWithFormat:@"%@", [product strSalesUnitMeasure]];
	
	[lblMiddle setFont:[UIFont fontWithName:@"Helvetica Bold" size:16.0f]];
	[lblMiddle setText:temp];	
	
	[self addSubview:btnProduct];
	[self addSubview:lblTop];
	[self addSubview:lblMiddle];
	[self addSubview:lblBottom];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
	[product release];
	[btnProduct release];
    [super dealloc];
}


@end
