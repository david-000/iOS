//
//  CustomerModel.h
//  DynamicsNAV
//
//  Created by DEV on 1/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CustomerModel : NSObject {
	NSString *no;
	NSString *name1;
	NSString *name2;
	NSString *address1;
	NSString *address2;
	NSString *postCode;
	NSString *city;
	NSString *contact;
	NSString *contactPhoneNo;
	NSString *contactEmail;
	NSString *currencyCode;
	NSString *countryRegionCode;
	NSString *customerPriceGroup;
	NSString *paymentTermsCode;
}

@property (nonatomic, retain) NSString *no;
@property (nonatomic, retain) NSString *name1;
@property (nonatomic, retain) NSString *name2;
@property (nonatomic, retain) NSString *address1;
@property (nonatomic, retain) NSString *address2;
@property (nonatomic, retain) NSString *postCode;
@property (nonatomic, retain) NSString *city;
@property (nonatomic, retain) NSString *contact;
@property (nonatomic, retain) NSString *contactPhoneNo;
@property (nonatomic, retain) NSString *contactEmail;
@property (nonatomic, retain) NSString *currencyCode;
@property (nonatomic, retain) NSString *countryRegionCode;
@property (nonatomic, retain) NSString *customerPriceGroup;
@property (nonatomic, retain) NSString *paymentTermsCode;

-(void)reset;

@end
