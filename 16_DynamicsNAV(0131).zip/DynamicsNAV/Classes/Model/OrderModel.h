//
//  OrderModel.h
//  DynamicsNAV
//
//  Created by DEV on 1/15/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface OrderModel : NSObject {
	NSString *productNo;
	NSString *orderDatetime;
	NSString *customerNo;
	int quantity;
}

@property (nonatomic, retain) NSString *productNo;
@property (nonatomic, retain) NSString *orderDatetime;
@property (nonatomic, retain) NSString *customerNo;
@property (nonatomic) int quantity;

-(void)reset;

@end
