//
//  ProductModel.m
//  Image
//
//  Created by System Administrator on 11/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ProductModel.h"


@implementation ProductModel

@synthesize strNO;
@synthesize strDesc;
@synthesize intUnitListPrice;
@synthesize intUnitPrice;
@synthesize strSalesUnitMeasure;
@synthesize intNyhed;
@synthesize intWebForSide;
@synthesize strWebText;
@synthesize category;

-(id)initialize
{
	[self reset];
	return self;
}

-(void)reset
{
	self.strNO = @"";
	self.strDesc = @"";
	self.intUnitListPrice = 0;
	self.intUnitPrice = 0;
	self.strSalesUnitMeasure = @"";
	self.intNyhed = 0;
	self.intWebForSide = 0;
	self.strWebText = @"";
	self.category = nil;
}

@end
