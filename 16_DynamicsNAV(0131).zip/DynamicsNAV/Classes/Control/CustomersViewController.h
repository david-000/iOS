//
//  CustomersViewController.h
//  DynamicsNAV
//
//  Created by DEV on 1/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomerModel.h"

@interface CustomersViewController : UIViewController <UISearchBarDelegate, NSStreamDelegate, UITableViewDelegate, UITableViewDataSource> {
	UIBarButtonItem *	gotoMainButton;
	UISearchBar *		search;
	
	UITableView *		tblCustomers;
				
	NSMutableArray *	realCustomerList;
				
	UIImage *			barBlue;
	UIImage *			barWhite;
				
	UIBarButtonItem *	pageNumber;
	int					pageNum;
	int					pageCount;
}

@property (nonatomic, retain) IBOutlet UIBarButtonItem *	gotoMainButton;
@property (nonatomic, retain) IBOutlet UISearchBar *		search;

@property (nonatomic, retain) IBOutlet UITableView *		tblCustomers;

@property (nonatomic, retain) NSMutableArray *	realCustomerList;
@property (nonatomic, retain) UIImage *			barBlue;
@property (nonatomic, retain) UIImage *			barWhite;

@property (nonatomic, retain) IBOutlet UIBarButtonItem *	pageNumber;
@property (nonatomic) int pageNum;
@property (nonatomic) int pageCount;

- (void) buildSearchArrayFrom: (NSString *) matchString;
- (IBAction)gotoMain:(id)sender;
- (IBAction)addCustomer:(id)sender;
- (void) refresh;
- (void) _parseCustomerXML;
- (void) reloadCustomers;
- (void) showCustomers;

- (void) modCell:(UITableViewCell *)aCell withCustomer:(CustomerModel *)customer;

- (IBAction) gotoFirst;
- (IBAction) gotoPrev;
- (IBAction) gotoNext;
- (IBAction) gotoLast;

@end
