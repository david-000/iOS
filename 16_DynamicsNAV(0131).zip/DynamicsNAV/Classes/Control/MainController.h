//
//  MainController.h
//  Image
//
//  Created by System Administrator on 11/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>

@interface MainController : UIViewController <MFMailComposeViewControllerDelegate> {
	IBOutlet UIImageView * imgBackground;
	IBOutlet UIButton	 * btnProduct;
	IBOutlet UIButton	 * btnContactUs;
	IBOutlet UIButton	 * btnOrders;
}

@property (nonatomic, retain) IBOutlet UIImageView * imgBackground;
@property (nonatomic, retain) IBOutlet UIButton	 * btnProduct;
@property (nonatomic, retain) IBOutlet UIButton	 * btnContactUs;
@property (nonatomic, retain) IBOutlet UIButton	 * btnOrders;

- (IBAction) syncBtnClicked: (id) sender;
- (IBAction) contactBtnClicked:(id) sender;
- (IBAction) ordersBtnClicked:(id) sender;

@end
