//
//  ImageAppDelegate.h
//  Image
//
//  Created by System Administrator on 11/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DetailViewController.h"
#import "MainController.h"
#import "ProductTrayController.h"
#import "CustomersViewController.h"
#import "AddCustomerController.h"
#import "ShoppingViewController.h"
#import "SynchronizeController.h"

#import "ProductModel.h"
#import "CustomerModel.h"

#define PRODUCTS_XML_FILE_NAME		@"Items"
#define ORDERS_XML_FILE_NAME		@"Orders"
#define ORDERS_TEMP_XML_FILE_NAME	@"OrdersTemp"
#define CUSTOMERS_XML_FILE_NAME		@"Customers"
#define NEW_CUSTOMER_XML_FILE_NAME	@"NewCustomer"
#define XML_FILE_EXTENSION			@"xml"

#define DOCUMENTS_FOLDER			[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]

#pragma mark PAGE IDs

#define PAGE_MENU						0
#define PAGE_SYNCHRONIZE				1
#define PAGE_DETAIL						2
#define PAGE_CUSTOMERS					3
#define PAGE_ADD_CUSTOMER				4

#define SPLASH_VIEW_WIDTH						120
#define SPLASH_VIEW_HEIGHT						100
#define SPLASH_VIEW_LABEL_TOP					25
#define SPLASH_VIEW_LABEL_HEIGHT				20
#define SPLASH_VIEW_ACTIVITY_WIDTH				40
#define SPLASH_VIEW_ACTIVITY_HEIGHT				40
#define SPLASH_VIEW_ACTIVITY_TOP				20
#define SPLASH_VIEW_BUTTON_OFFSET				10

#define IMAGE_WIDTH					250.0
#define IMAGE_HEIGHT				250.0
#define IMAGE_EXT_WIDTH				400.0
#define IMAGE_EXT_HEIGHT			400.0
#define PER_LINE_IMAGE_COUNT		3
#define	PADDING_WIDTH				3.0
#define PADDING_HEIGHT				3.0
#define SCREEN_WIDTH				768.0
#define SCREEN_HEIGHT				1024.0
#define LABEL_HEIGHT				50.0
#define BORDER_SIZE					18.0
#define TOOLBAR_HEIGHT				44.0

#pragma mark Product Info

#define IMAGE_BUTTON_WIDTH			90.0
#define IMAGE_BUTTON_HEIGHT			90.0
#define IMAGE_COVER_WIDTH			110.0
#define IMAGE_COVER_HEIGHT			110.0
#define	MARGIN_WIDTH				10.0
#define MARGIN_HEIGHT				10.0

#define PER_PAGE_ITEM_COUNT			15

#pragma mark Messages

#define MSG_NO_PRODUCTS				@"There is no any products. Please synchronize and retry again."
#define MSG_NO_CUSTOMERS			@"There is no any customers. Please synchronize and retry again."
#define MSG_NEW_CUSTOMER_SUCCESS	@"New customer are created successfully."
#define MSG_NEW_CUSTOMER_FAIL		@"Sorry, creating of new customer are failed."
#define MSG_ORDER_SUCCESS			@"Ordering successed."
#define MSG_ORDER_FAIL				@"Ordering failed."
#define MSG_NO_XML					@"The XML file does not exist."
#define MSG_INVALID_URL				@"Invalid URL"
#define MSG_NO_QUANTITY				@"Specify quantity to order."

#pragma mark Strings

#define STR_MSG_FAILED				@"Message Failed!"
#define STR_EMAIL_SEND_FAIL			@"Your email has failed to send."
#define STR_DISMISS					@"Dismiss"
#define STR_ALERT_TITLE				@"Alert"

@interface ImageAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	IBOutlet UINavigationController *navController;
	
	// For Splash View
	UIImageView					*m_splashView;
	UIActivityIndicatorView		*m_splashActivity;
	UILabel						*m_splashLabel;
	
	// For View Controllers
	DetailViewController		*detailViewController;
	MainController				*mainController;
	ProductTrayController		*productTrayController;
	CustomersViewController		*customersViewController;
	AddCustomerController		*addCustomerController;
	ShoppingViewController		*shoppingViewController;
	SynchronizeController		*synchronizeController;
	
	ProductModel				*product;
	ProductModel				*productTray;
	NSMutableArray				*productList;
	NSMutableArray				*orderList;
	NSMutableArray				*customerList;
	
	CustomerModel				*customer;
	
	BOOL						shouldRefresh;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navController;
@property (nonatomic, retain) IBOutlet DetailViewController	*detailViewController;
@property (nonatomic, retain) IBOutlet MainController	*mainController;
@property (nonatomic, retain) IBOutlet ProductTrayController		*productTrayController;
@property (nonatomic, retain) IBOutlet CustomersViewController		*customersViewController;
@property (nonatomic, retain) IBOutlet AddCustomerController		*addCustomerController;
@property (nonatomic, retain) IBOutlet ShoppingViewController		*shoppingViewController;
@property (nonatomic, retain) IBOutlet SynchronizeController		*synchronizeController;

@property (nonatomic, retain) ProductModel *product;
@property (nonatomic, retain) ProductModel *productTray;
@property (nonatomic, retain) NSMutableArray *productList;
@property (nonatomic, retain) NSMutableArray *orderList;
@property (nonatomic, retain) NSMutableArray *customerList;

@property (nonatomic, retain) CustomerModel *customer;

@property (nonatomic) BOOL						shouldRefresh;

#pragma mark FTP

+ (ImageAppDelegate *)sharedAppDelegate;

#pragma mark APP

-(void)initControllers;
-(void)setRootView:(id)newRootViewController;

#pragma mark Splash View

-(void)createSplashView;
-(void)showSplashView:(NSString*)viewText;
- (void)updateSplashView:(NSString*)viewText;
-(void)hiddenSplashView;
-(void) showMainPage;

#pragma mark Alert View

- (void)showAlert: (NSString *)message;

@end

