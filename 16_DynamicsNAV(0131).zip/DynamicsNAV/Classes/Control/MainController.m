    //
//  MainController.m
//  Image
//
//  Created by System Administrator on 11/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MainController.h"
#import "ImageAppDelegate.h"

@implementation MainController

@synthesize imgBackground;
@synthesize btnProduct;
@synthesize btnContactUs;
@synthesize btnOrders;

 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void) viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	self.navigationController.navigationBarHidden = YES;
	
	[[ImageAppDelegate sharedAppDelegate] setShouldRefresh:YES];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return NO;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (IBAction) syncBtnClicked: (id) sender
{
	[self.navigationController pushViewController:[[ImageAppDelegate sharedAppDelegate] synchronizeController] animated:YES];	
}

- (IBAction) ordersBtnClicked:(id) sender
{
	[self.navigationController pushViewController:[[ImageAppDelegate sharedAppDelegate] customersViewController] animated:YES];	
}

- (IBAction) contactBtnClicked:(id) sender
{
	// create an MFMailComposeViewController for sending an e-mail
	MFMailComposeViewController *controller = [[MFMailComposeViewController alloc] init];
	
	// set controller's delegate to this object
	controller.mailComposeDelegate = self;
	[controller setMessageBody:@"" isHTML:YES];
		
	// show the MFMailComposeViewController
	[self presentModalViewController:controller animated:YES];
	[controller release];
}

- (void)mailComposeController:(MFMailComposeViewController*)controller
		  didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
	if (result == MFMailComposeResultFailed) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:STR_MSG_FAILED message :STR_EMAIL_SEND_FAIL
													   delegate:self cancelButtonTitle:STR_DISMISS otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
	
	[controller dismissModalViewControllerAnimated:YES];
}

- (void)dealloc {
	[imgBackground release];
	[btnProduct release];
	[btnContactUs release];
	[btnOrders release];
	
    [super dealloc];
}


@end
