    //
//  ShoppingViewController.m
//  DynamicsNAV
//
//  Created by DEV on 1/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "ShoppingViewController.h"
#import "ImageAppDelegate.h"

#import "CustomProductImage.h"

@implementation ShoppingViewController

#pragma mark * View controller boilerplate

@synthesize search;
@synthesize shopView;
@synthesize content;

@synthesize gotoMainButton;
@synthesize realProductList;

@synthesize noImage;

@synthesize pageNum;
@synthesize pageCount;

@synthesize pageNumber;

#pragma mark XML parser and download

- (void) _parseProductXML
{
	NSString *path = [NSString stringWithFormat:@"%@/%@.%@", DOCUMENTS_FOLDER, PRODUCTS_XML_FILE_NAME, XML_FILE_EXTENSION];
	NSString *data = [[NSString alloc] initWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
	
	ImageAppDelegate* appDelegate = (ImageAppDelegate*)[[UIApplication sharedApplication] delegate];
	
	if (appDelegate.productList != nil) {
		[appDelegate.productList release];
		appDelegate.productList = nil;
	}
	
	appDelegate.productList = [[NSMutableArray alloc] init];
	
	if (self.realProductList != nil) {
		[self.realProductList removeAllObjects];
	} else {
		self.realProductList = [[NSMutableArray alloc] init];
	}
	
	NSMutableArray * _list = [XMLParser GetTagValuesByToken:data
												   TagValue:@"Items"];
	for (NSString * temp in _list)
	{
		// Parse the product's detail information.
		ProductModel *product = [[ProductModel alloc] initialize];
		product.strNO = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"No"];
		product.strDesc = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Description"];
		product.intUnitListPrice = [[XMLParser GetFirstTagValueByToken:temp TagValue:@"Unit_List_Price"] intValue];
		product.intUnitPrice = [[XMLParser GetFirstTagValueByToken:temp TagValue:@"Unit_Price"] intValue];
		product.strSalesUnitMeasure = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Sales_Unit_of_Measure"];
		product.intNyhed = [[XMLParser GetFirstTagValueByToken:temp TagValue:@"Nyhed"] intValue];
		product.intWebForSide = [[XMLParser GetFirstTagValueByToken:temp TagValue:@"Web_Forside"] intValue];
		product.strWebText = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Web_text"];
		
		// Parse the product's category.
		NSMutableArray *_category = [XMLParser GetTagValuesByToken:temp TagValue:@"Category"];
		if (_category) {
			product.category = [[[Category alloc] initialize] autorelease];
			
			for (NSString *cate in _category) {
				NSString *productCategory = (NSString *)[XMLParser GetFirstTagValueByToken:cate TagValue:@"Product_Category"];
				NSString *subProductCategory = (NSString *)[XMLParser GetFirstTagValueByToken:cate TagValue:@"Sub_Product_Category"];
				
				product.category.productCategory = productCategory;
				product.category.subProductCategory = subProductCategory;
			}
		}
		
		[appDelegate.productList addObject:product];
		[self.realProductList addObject:product];
		
		[product release];
	}
	
	[data release];
}

- (void) reloadProducts
{
	int total = (int)round([self.realProductList count] / PER_PAGE_ITEM_COUNT) + 1;
	
	[self setPageNum:1];
	[self setPageCount:total];
	
	[self.pageNumber setTitle:[NSString stringWithFormat:@"%d / %d", self.pageNum, self.pageCount]];
	
	[self showProducts];
}

#pragma mark Show products

- (void) showProductDetailView: (CustomImageButton *) productBtn
{
	if (productBtn == nil)
		return;
	
	[self.search resignFirstResponder];
	
	[[ImageAppDelegate sharedAppDelegate] setProduct:[productBtn product]];
	
	[self.navigationController pushViewController:[[ImageAppDelegate sharedAppDelegate] detailViewController] animated:YES];
}

- (void) clearContent
{
	//	int intSubViewCount = [[self.content subviews] count];
	//	
	//	if (intSubViewCount != 0) {
	//		[[self.content subviews] release];
	//	}
	
	[self.content removeFromSuperview];
	self.content = nil;
	
	self.content = [[UIImageView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[self.content setUserInteractionEnabled:YES];
	
	float flContentWidth = SCREEN_WIDTH;
	float flContentHeight = SCREEN_HEIGHT - TOOLBAR_HEIGHT;
	
	[self.content setFrame:CGRectMake(0, 0, flContentWidth, flContentHeight)];
	[self.shopView setContentSize:CGSizeMake(flContentWidth, flContentHeight)];
	[self.shopView setMaximumZoomScale:2.0f];
	[self.shopView setMinimumZoomScale:0.5f];
	[self.shopView addSubview:self.content];
}

- (void)showProducts
{
	[self clearContent];
	
	if (self.realProductList == nil || [self.realProductList count] == 0)
		return;
	
	// Set up the main scroller
	//shopView = [[UIScrollView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	[self.shopView setScrollEnabled:YES];
	
	// First, if exists sub views of content, release it.
	if (self.content != nil) {
		[self clearContent];
	}
		
	float flX;
	float flY;
	
	ProductModel *product = nil;
	int index;
	
	for (int j = 0; j < PER_PAGE_ITEM_COUNT; j ++)
	{
		index = (self.pageNum - 1) * PER_PAGE_ITEM_COUNT + j;
		
		if (index >= [self.realProductList count])
			break;
		
		product = [self.realProductList objectAtIndex:index];
		
		flX = (j % PER_LINE_IMAGE_COUNT) * (IMAGE_WIDTH + PADDING_WIDTH) + PADDING_WIDTH;
		flY = (j / PER_LINE_IMAGE_COUNT) * (IMAGE_HEIGHT + PADDING_HEIGHT) + PADDING_HEIGHT;
		
		CGRect dragRect = CGRectMake(flX, flY, IMAGE_WIDTH, IMAGE_HEIGHT);
		
		CustomProductImage *imgProduct = [[CustomProductImage alloc] initWithFrame:dragRect];
		[imgProduct drawWithProductInfo:product];
		[[imgProduct btnProduct] addTarget:self action:@selector(showProductDetailView:) forControlEvents:UIControlEventTouchUpInside];
		
		[content addSubview:imgProduct];
		
		[imgProduct release];
	}
	
	// Set scroll, also consider scale.
	float flContentWidth = SCREEN_WIDTH;
	float flContentHeight = ((PER_PAGE_ITEM_COUNT / PER_LINE_IMAGE_COUNT) + 1) * (IMAGE_HEIGHT + PADDING_HEIGHT) + PADDING_HEIGHT - TOOLBAR_HEIGHT;
	
	//	[self.content setFrame:CGRectMake(0, 0, flContentWidth, flContentHeight)];
	[self.shopView setContentSize:CGSizeMake(flContentWidth, flContentHeight)];
	[self.shopView setMaximumZoomScale:2.0f];
	[self.shopView setMinimumZoomScale:0.5f];
	[self.shopView setDelegate:self];
	[self.shopView addSubview:self.content];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return NO;
}

#pragma mark Navigation functions

- (IBAction) gotoFirst
{
	[self setPageNum:1];
	[self showProducts];
	
	[self.pageNumber setTitle:[NSString stringWithFormat:@"%d / %d", self.pageNum, self.pageCount]];
}

- (IBAction) gotoPrev
{
	if (self.pageNum == 1)
		return;
	
	[self setPageNum:(self.pageNum - 1)];
	[self showProducts];
	
	[self.pageNumber setTitle:[NSString stringWithFormat:@"%d / %d", self.pageNum, self.pageCount]];
}

- (IBAction) gotoNext
{
	if (self.pageNum == self.pageCount)
		return;
	
	[self setPageNum:(self.pageNum + 1)];
	[self showProducts];
	
	[self.pageNumber setTitle:[NSString stringWithFormat:@"%d / %d", self.pageNum, self.pageCount]];
}

- (IBAction) gotoLast
{
	[self setPageNum:self.pageCount];
	[self showProducts];
	
	[self.pageNumber setTitle:[NSString stringWithFormat:@"%d / %d", self.pageNum, self.pageCount]];
}

#pragma mark Search Bar delegate functions

- (void) buildSearchArrayFrom: (NSString *) matchString
{
	NSString *upString = [matchString uppercaseString];
	
	ImageAppDelegate* appDelegate = (ImageAppDelegate*)[[UIApplication sharedApplication] delegate];
	
	if (appDelegate.productList == nil) {
		return;
	}
	
	if (self.realProductList != nil) {
		[self.realProductList release];
		self.realProductList = nil;
	}
	
	self.realProductList = [[NSMutableArray alloc] init];
	
	for (ProductModel *listEntry in appDelegate.productList) 
	{
		if ([matchString length] == 0) {
			[self.realProductList addObject:listEntry];
			continue;
		}
		
		NSString *word = [listEntry strNO];
		
		NSRange range = [[[[word componentsSeparatedByString:@" #"] objectAtIndex:0] uppercaseString] rangeOfString:upString];
		
		if (range.location != NSNotFound)
			[self.realProductList addObject:listEntry];
	}
	
	[self reloadProducts];
}

// When the search text changes, update the array 
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
	assert(searchBar == self.search);
	
	[self buildSearchArrayFrom:searchText];
}

// When the search ("done") button is clicked, hide the keyboard
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
	assert(searchBar == self.search);
	
	[self.search resignFirstResponder];
}

- (IBAction)gotoBack:(id)sender
{
	[self.search resignFirstResponder];
	
	[self.navigationController popViewControllerAnimated:YES];
}

- (void) loadProducts
{
	[self _parseProductXML];
	[self reloadProducts];
	
	[[ImageAppDelegate sharedAppDelegate] hiddenSplashView];
	
	if ([self.realProductList count] == 0) {
		[[ImageAppDelegate sharedAppDelegate] hiddenSplashView];
		[[ImageAppDelegate sharedAppDelegate] showAlert:MSG_NO_PRODUCTS];
		return;
	}
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	self.shopView.backgroundColor = [UIColor lightGrayColor];
	
	noImage = [UIImage imageNamed:@"NoImage.png"];
	
	[[ImageAppDelegate sharedAppDelegate] showSplashView:@"Loading..."];

	[NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(loadProducts) userInfo:nil repeats:NO];
}

- (void) viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	self.navigationController.navigationBarHidden = YES;

	[[ImageAppDelegate sharedAppDelegate] setShouldRefresh:NO];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)dealloc
{
	[self.shopView release];
	[self.content release];
	[self.search release];
	[self.realProductList release];
	[self.gotoMainButton release];
	
    [super dealloc];
}

@end
