    //
//  SynchronizeController.m
//  DynamicsNAV
//
//  Created by DEV on 1/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "SynchronizeController.h"

#import "CkoFtp2.h"

#import "ImageAppDelegate.h"

@implementation SynchronizeController

@synthesize console;
@synthesize synchronize;

 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	[self setTitle:@"Synchronize"];
	
	[self.console setFont:[UIFont systemFontOfSize:20]];
	
	synchronize = [[[UIBarButtonItem alloc]
									  initWithTitle:@"Start"
									  style:UIBarButtonItemStyleBordered
									  target:self
									  action:@selector(syncAction)] autorelease];
	self.navigationItem.rightBarButtonItem = synchronize;
}

- (void) viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	self.navigationController.navigationBarHidden = NO;
	self.navigationController.navigationBar.barStyle = UIBarStyleBlackTranslucent;
}

- (IBAction) syncAction
{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	
	[[ImageAppDelegate sharedAppDelegate] showSplashView:@"Connecting..."];
	
	[NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(syncLocalTree) userInfo:nil repeats:NO];
		
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

- (BOOL) syncLocalTree
{
	NSMutableString *strOutput = [NSMutableString stringWithCapacity:1000];
	
	CkoFtp2 *ftp = [[[CkoFtp2 alloc] init] autorelease];
	
	BOOL success;
	
	//  Any string unlocks the component for the 1st 30-days.
	success = [ftp UnlockComponent: @"Anything for 30-day trial"];
	if (success != YES) {
		[[ImageAppDelegate sharedAppDelegate] hiddenSplashView];
		[strOutput appendString: ftp.LastErrorText];
		[strOutput appendString: @"\n"];
		self.console.text = strOutput;
		return success;
	}
	
	//  Note: This is a valid FTP account that you may use for testing.
	ftp.Hostname = FTP_HOST_NAME;
	ftp.Username = FTP_USER_NAME;
	ftp.Password = FTP_USER_PASSWORD;
	
	ftp.KeepSessionLog = YES;
	
	//  Connect and login to the FTP server.
	success = [ftp Connect];
	if (success != YES) {
		[[ImageAppDelegate sharedAppDelegate] hiddenSplashView];
		[[ImageAppDelegate sharedAppDelegate] showAlert:@"No connection to server."];
		
		[strOutput appendString: ftp.LastErrorText];
		[strOutput appendString: @"\n"];
		self.console.text = strOutput;
		return success;
	}
	
	//  Set the current remote directory to the root of
	//  the tree to be downloaded.
//	success = [ftp ChangeRemoteDir: @"/billeder"];
//	if (success != YES) {
//		[strOutput appendString: ftp.LastErrorText];
//		[strOutput appendString: @"\n"];
//		self.console.text = strOutput;
//		return;
//	}
	
	//  Recursively download all non-existant and newer files.
	int mode;
	mode = 2;
	
	[[ImageAppDelegate sharedAppDelegate] updateSplashView:@"Downloading..."];
	
	success = [ftp SyncLocalTree:DOCUMENTS_FOLDER mode: [NSNumber numberWithInt: mode]];
	if (success != YES) {		
		[[ImageAppDelegate sharedAppDelegate] hiddenSplashView];
		[[ImageAppDelegate sharedAppDelegate] showAlert:@"Downloading failed."];
		[[ImageAppDelegate sharedAppDelegate] setShouldRefresh:NO];

		[strOutput appendString: ftp.LastErrorText];
		[strOutput appendString: @"\n"];
		self.console.text = strOutput;
		return success;
	}
	
	[self appendOrders];
	
	//  Upload a order file.
	[[ImageAppDelegate sharedAppDelegate] updateSplashView:@"Uploading..."];

	mode = 2;
	success = [ftp SyncRemoteTree:DOCUMENTS_FOLDER mode: [NSNumber numberWithInt: mode]];
	if (success != YES) {
		[[ImageAppDelegate sharedAppDelegate] hiddenSplashView];
		[[ImageAppDelegate sharedAppDelegate] showAlert:@"Uploading failed."];
		[[ImageAppDelegate sharedAppDelegate] setShouldRefresh:NO];

		[strOutput appendString: ftp.LastErrorText];
		[strOutput appendString: @"\n"];
		self.console.text = strOutput;
		return success;
	}
	
	[ftp Disconnect];
	
	//  Display the session log.
	[strOutput appendString: ftp.SessionLog];
	[strOutput appendString: @"\n"];
	
	self.console.text = strOutput;
	
	[[ImageAppDelegate sharedAppDelegate] hiddenSplashView];
	[[ImageAppDelegate sharedAppDelegate] showAlert:@"Synchronized successfully."];
	[[ImageAppDelegate sharedAppDelegate] setShouldRefresh:YES];

	return success;
}

- (BOOL) appendOrders
{
	// Append order temp to order.
	NSString *path;
	BOOL success;
	
	NSMutableArray *temp = nil;
	
	path = [DOCUMENTS_FOLDER stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@", ORDERS_TEMP_XML_FILE_NAME, XML_FILE_EXTENSION]];
	if ([[NSFileManager defaultManager] fileExistsAtPath:path])
	{
		[[[ImageAppDelegate sharedAppDelegate] detailViewController] _parseOrderXML:ORDERS_TEMP_XML_FILE_NAME];
		temp = [[NSMutableArray alloc] initWithArray:[[ImageAppDelegate sharedAppDelegate] orderList]];
	}
	else
		temp = [[[NSMutableArray alloc] init] autorelease];

	if ([temp count] == 0)
		return YES;
	
	NSMutableArray *merge = nil;
	
	path = [DOCUMENTS_FOLDER stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@", ORDERS_XML_FILE_NAME, XML_FILE_EXTENSION]];
	if ([[NSFileManager defaultManager] fileExistsAtPath:path])
	{
		[[[ImageAppDelegate sharedAppDelegate] detailViewController] _parseOrderXML:ORDERS_XML_FILE_NAME];
		merge = [[NSMutableArray alloc] initWithArray:[[ImageAppDelegate sharedAppDelegate] orderList]];
	}
	else
		merge = [[[NSMutableArray alloc] init] autorelease];
	
	[merge addObjectsFromArray:temp];
	
	// Sort
	NSMutableString *strFileData = [[NSMutableString alloc] init];
	NSString *customerNo = nil;
	NSMutableArray *customerGroup = nil;
	NSMutableArray *noGroup = [[NSMutableArray alloc] init];
	NSMutableArray *sortedGroup = [[NSMutableArray alloc] init];
	
	for (OrderModel *sortItem in merge)
	{
		customerNo = sortItem.customerNo;
		
		if ([noGroup containsObject:customerNo])
			continue;
		
		customerGroup = [[NSMutableArray alloc] init];
		
		for (OrderModel *tempItem in merge)
		{
			if ([customerNo isEqual:tempItem.customerNo])
				[customerGroup addObject:tempItem];
		}
		
		[sortedGroup addObject:customerGroup];
		[customerGroup release];
		customerGroup = nil;
		
		[noGroup addObject:customerNo];
	}
	
	// Generate xml
	[strFileData appendString:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"];
	[strFileData appendString:@"<Root>\n"];
	
	for (NSMutableArray *sortedOrders in sortedGroup)
	{
		if (!sortedOrders || [sortedOrders count] == 0)
			break;
		
		OrderModel *firstItem = (OrderModel *)[sortedOrders objectAtIndex:0];
		
		[strFileData appendFormat:@"\t<Products>\n"];
		[strFileData appendFormat:@"\t\t<Customer_No>%@</Customer_No>\n", firstItem.customerNo];
		
		for (OrderModel *item in sortedOrders)
		{
			[strFileData appendFormat:@"\t\t<Orders>\n"];
			[strFileData appendFormat:@"\t\t\t<DateTime>%@</DateTime>\n", item.orderDatetime];
			[strFileData appendFormat:@"\t\t\t<Product_No>%@</Product_No>\n", item.productNo];
			[strFileData appendFormat:@"\t\t\t<Quantity>%d</Quantity>\n", item.quantity];
			[strFileData appendFormat:@"\t\t</Orders>\n"];
		}
		
		[strFileData appendFormat:@"\t</Products>\n"];
	}
	
	[strFileData appendString:@"</Root>"];
	
	path = [DOCUMENTS_FOLDER stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@", ORDERS_XML_FILE_NAME, XML_FILE_EXTENSION]];
	success = [strFileData writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];

	[strFileData release];
	[noGroup release];
	[sortedGroup release];
	
	if (!success)
		return NO;
	
	// Clear order temp file.
	path = [DOCUMENTS_FOLDER stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@", ORDERS_TEMP_XML_FILE_NAME, XML_FILE_EXTENSION]];
	success = [@"" writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];

	return success;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return YES;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[console release];
	[synchronize release];
	
    [super dealloc];
}


@end
