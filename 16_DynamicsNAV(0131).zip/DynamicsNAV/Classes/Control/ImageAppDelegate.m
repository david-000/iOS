//
//  ImageAppDelegate.m
//  Image
//
//  Created by System Administrator on 11/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ImageAppDelegate.h"

@interface ImageAppDelegate ()
@property (nonatomic, assign) NSInteger             networkingCount;
@end

@implementation ImageAppDelegate

@synthesize window;
@synthesize navController;

@synthesize detailViewController;
@synthesize mainController;
@synthesize productTrayController;
@synthesize customersViewController;
@synthesize addCustomerController;
@synthesize shoppingViewController;
@synthesize synchronizeController;

@synthesize networkingCount = _networkingCount;

@synthesize product;
@synthesize productList;

@synthesize orderList;
@synthesize customerList;

@synthesize customer;

@synthesize productTray;

@synthesize shouldRefresh;

#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
    // Override point for customization after application launch.
	[self createSplashView];
	[self initControllers];		// Make UI Controllers
	[self setRootView:mainController];
	
	return YES;
}

-(void)setRootView:(id)newRootViewController
{
	navController = [[UINavigationController alloc] initWithRootViewController:newRootViewController];
	
	[window addSubview:navController.view];
	[window makeKeyAndVisible];
}

-(void) showMainPage{
	navController = [[UINavigationController alloc] initWithRootViewController:mainController];
	
	[window addSubview:navController.view];
	[window makeKeyAndVisible];
}

-(void) showThingDetailPage{
	
	navController = [[UINavigationController alloc] initWithRootViewController:detailViewController];
	
	[window addSubview:navController.view];
	[window makeKeyAndVisible];
}

- (void)showAlert: (NSString *)message
{
	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:STR_ALERT_TITLE message:message delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
	
	[alert show];
}

- (void)initControllers
{
	productList = nil;
	orderList = nil;
	
	mainController = [[MainController alloc] initWithNibName:@"MainController" bundle:nil];
	detailViewController = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:nil];
	productTrayController = [[ProductTrayController alloc] initWithNibName:@"ProductTrayController" bundle:nil];
	customersViewController = [[CustomersViewController alloc] initWithNibName:@"CustomersViewController" bundle:nil];
	addCustomerController = [[AddCustomerController alloc] initWithNibName:@"AddCustomerController" bundle:nil];
	shoppingViewController = [[ShoppingViewController alloc] initWithNibName:@"ShoppingViewController" bundle:nil];
	synchronizeController = [[SynchronizeController alloc] initWithNibName:@"SynchronizeController" bundle:nil];
}

#pragma mark Splash View

-(void)createSplashView
{
	m_splashView = [[UIImageView alloc] initWithFrame:CGRectMake(384, 512, mainController.view.frame.size.width, mainController.view.frame.size.height + 22)];
	m_splashView.backgroundColor = [UIColor colorWithWhite:1 alpha:0.5];
	
	UIImageView *view = [[UIImageView alloc] initWithFrame:
						 CGRectMake((mainController.view.frame.size.width - SPLASH_VIEW_WIDTH) / 2,
									(mainController.view.frame.size.height - SPLASH_VIEW_HEIGHT) / 2,
									SPLASH_VIEW_WIDTH,
									SPLASH_VIEW_HEIGHT)];
	view.backgroundColor = [UIColor grayColor];
	
	UIButton *btn = [[UIButton alloc] initWithFrame:
					 CGRectMake(SPLASH_VIEW_BUTTON_OFFSET,
								SPLASH_VIEW_BUTTON_OFFSET,
								SPLASH_VIEW_WIDTH - SPLASH_VIEW_BUTTON_OFFSET * 2,
								SPLASH_VIEW_HEIGHT - SPLASH_VIEW_BUTTON_OFFSET * 2)];
	btn.backgroundColor = [UIColor darkGrayColor];
	[view addSubview:btn];
	[btn release];
	
	m_splashLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0, SPLASH_VIEW_LABEL_TOP, SPLASH_VIEW_WIDTH, SPLASH_VIEW_HEIGHT)];
	m_splashLabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
	m_splashLabel.textColor = [UIColor whiteColor];
	m_splashLabel.backgroundColor = [UIColor clearColor];
	m_splashLabel.font = [UIFont systemFontOfSize:14.0f];
	m_splashLabel.textAlignment = UITextAlignmentCenter;
	m_splashLabel.text = NSLocalizedString(@"Waiting",@"");
	[view addSubview:m_splashLabel];
	[m_splashLabel release];
	
	m_splashActivity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
	m_splashActivity.frame = CGRectMake((SPLASH_VIEW_WIDTH - SPLASH_VIEW_ACTIVITY_WIDTH) / 2, SPLASH_VIEW_ACTIVITY_TOP, SPLASH_VIEW_ACTIVITY_WIDTH, SPLASH_VIEW_ACTIVITY_HEIGHT);
	[view addSubview:m_splashActivity];
	[m_splashActivity release];
	
	[m_splashView addSubview:view];
	[view release];
}

- (void)showSplashView:(NSString*)viewText
{
	m_splashLabel.text = viewText;
	[m_splashActivity startAnimating];
	m_splashView.hidden = NO;
	
	[window addSubview:m_splashView];
	[window setUserInteractionEnabled:NO];
}

- (void)updateSplashView:(NSString*)viewText
{
	m_splashLabel.text = viewText;
}

- (void)hiddenSplashView
{
	[m_splashActivity stopAnimating];
	m_splashView.hidden = YES;
	
	[m_splashView removeFromSuperview];
	[window setUserInteractionEnabled:YES];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive.
     */
}


- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     */
}

#pragma mark FTP

+ (ImageAppDelegate *)sharedAppDelegate
{
    return (ImageAppDelegate *) [UIApplication sharedApplication].delegate;
}

- (void)setRefreshFlag: (BOOL) flag
{
	self.shouldRefresh = flag;
}

#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
    [window release];
	[navController release];
	
	[detailViewController release];
	[mainController release];
	[productTrayController release];
	[customersViewController release];
	[addCustomerController release];
	[shoppingViewController release];
	[synchronizeController release];
	
	[product release];
	[productList release];
	[orderList release];
	[customerList release];
	
	[customer release];
	
	[productTray release];
	
    [super dealloc];
}


@end
