//
//  AddCustomerController.h
//  DynamicsNAV
//
//  Created by DEV on 1/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AddCustomerController : UIViewController <UITextFieldDelegate> {
	UITextField *no;
	UITextField *name1;
	UITextField *name2;
	UITextField *address1;
	UITextField *address2;
	UITextField *postCode;
	UITextField *city;
	UITextField *contact;
	UITextField *contactPhoneNo;
	UITextField *contactEmail;
	UITextField *currencyCode;
	UITextField *countryRegionCode;
	UITextField *customerPriceGroup;
	UITextField *paymentTermsCode;
	
	UIButton *btnReset;
	UIButton *btnCreate;
}

@property (nonatomic, retain) IBOutlet UITextField *no;
@property (nonatomic, retain) IBOutlet UITextField *name1;
@property (nonatomic, retain) IBOutlet UITextField *name2;
@property (nonatomic, retain) IBOutlet UITextField *address1;
@property (nonatomic, retain) IBOutlet UITextField *address2;
@property (nonatomic, retain) IBOutlet UITextField *postCode;
@property (nonatomic, retain) IBOutlet UITextField *city;
@property (nonatomic, retain) IBOutlet UITextField *contact;
@property (nonatomic, retain) IBOutlet UITextField *contactPhoneNo;
@property (nonatomic, retain) IBOutlet UITextField *contactEmail;
@property (nonatomic, retain) IBOutlet UITextField *currencyCode;
@property (nonatomic, retain) IBOutlet UITextField *countryRegionCode;
@property (nonatomic, retain) IBOutlet UITextField *customerPriceGroup;
@property (nonatomic, retain) IBOutlet UITextField *paymentTermsCode;

@property (nonatomic, retain) IBOutlet UIButton *btnReset;
@property (nonatomic, retain) IBOutlet UIButton *btnCreate;

- (IBAction) resetAction;
- (IBAction) createAction;

- (BOOL) generateXMLFile;

@end
