    //
//  CustomersViewController.m
//  DynamicsNAV
//
//  Created by DEV on 1/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "CustomersViewController.h"
#import "ImageAppDelegate.h"
#import "CustomerModel.h"

@implementation CustomersViewController

@synthesize gotoMainButton;
@synthesize search;

@synthesize tblCustomers;
@synthesize realCustomerList;

@synthesize barBlue;
@synthesize barWhite;

@synthesize pageNum;
@synthesize pageCount;

@synthesize pageNumber;

 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	barBlue = [UIImage imageNamed:@"bar_blue.png"];
	barWhite = [UIImage imageNamed:@"bar_white.png"];
	
	[tblCustomers setRowHeight:130.0f];
	[tblCustomers setSeparatorStyle:UITableViewCellSeparatorStyleNone];
	tblCustomers.backgroundView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background_product.png"]] autorelease];
}

#pragma mark Search Bar delegate functions

- (void) buildSearchArrayFrom: (NSString *) matchString
{
	NSString *upString = [matchString uppercaseString];
	
	ImageAppDelegate* appDelegate = (ImageAppDelegate*)[[UIApplication sharedApplication] delegate];
	
	if (appDelegate.customerList == nil) {
		return;
	}
	
	if (self.realCustomerList != nil) {
		[self.realCustomerList release];
		self.realCustomerList = nil;
	}
	
	self.realCustomerList = [[NSMutableArray alloc] init];
	
	for (CustomerModel *listEntry in appDelegate.customerList) 
	{
		if ([matchString length] == 0) {
			[self.realCustomerList addObject:listEntry];
			continue;
		}
		
		NSString *word1 = [listEntry name1];
		
		if (word1) {
			NSRange range1 = [[[[word1 componentsSeparatedByString:@" #"] objectAtIndex:0] uppercaseString] rangeOfString:upString];
			
			if (range1.location != NSNotFound)
			{
				[self.realCustomerList addObject:listEntry];
				continue;
			}
		}
	
		NSString *word2 = [listEntry name2];
		
		if (word2) {
			NSRange range2 = [[[[word2 componentsSeparatedByString:@" #"] objectAtIndex:0] uppercaseString] rangeOfString:upString];
			
			if (range2.location != NSNotFound)
				[self.realCustomerList addObject:listEntry];
		}
	}
	
	[self reloadCustomers];
}

// When the search text changes, update the array 
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
	assert(searchBar == self.search);
	
	[self buildSearchArrayFrom:searchText];
}

// When the search ("done") button is clicked, hide the keyboard
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
	assert(searchBar == self.search);
	
	[self.search resignFirstResponder];
}

#pragma mark XML parser

- (void) _parseCustomerXML
{
	NSString *path = [NSString stringWithFormat:@"%@/%@.%@", DOCUMENTS_FOLDER, CUSTOMERS_XML_FILE_NAME, XML_FILE_EXTENSION];
	NSString *data = [[NSString alloc] initWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
	
	ImageAppDelegate* appDelegate = (ImageAppDelegate*)[[UIApplication sharedApplication] delegate];
	
	if (appDelegate.customerList != nil) {
		[appDelegate.customerList release];
		appDelegate.customerList = nil;
	}
	
	appDelegate.customerList = [[NSMutableArray alloc] init];
	
	if (self.realCustomerList != nil) {
		[self.realCustomerList removeAllObjects];
	} else {
		self.realCustomerList = [[NSMutableArray alloc] init];
	}
	
	NSMutableArray * _list = [XMLParser GetTagValuesByToken:data
												   TagValue:@"Customers"];
	for (NSString * temp in _list)
	{
		// Parse the product's detail information.
		CustomerModel *customer = [[CustomerModel alloc] initialize];
		customer.no = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"No"];
		customer.name1 = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Name"];
		customer.name2 = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Name_2"];
		customer.address1 = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Address"];
		customer.address2 = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Address_2"];
		customer.postCode = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Post_Code"];
		customer.city = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"City"];
		customer.contact = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Contact"];
		customer.contactPhoneNo = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Contact_Phone_No"];
		customer.contactEmail = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Contact_E-Mail"];
		customer.currencyCode = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Currency_Code"];
		customer.countryRegionCode = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Country_Region_Code"];
		customer.customerPriceGroup = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Customer_Price_Group"];
		customer.paymentTermsCode = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Payment_Terms_Code"];
		
		[self.realCustomerList addObject:customer];
		
		[customer release];
	}
	
	appDelegate.customerList = self.realCustomerList;
	
	[data release];
}

- (void) reloadCustomers
{
	int total = (int)round([self.realCustomerList count] / PER_PAGE_ITEM_COUNT) + 1;
	
	[self setPageNum:1];
	[self setPageCount:total];
	
	[self.pageNumber setTitle:[NSString stringWithFormat:@"%d / %d", self.pageNum, self.pageCount]];
	
	[self.tblCustomers reloadData];	
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if ([self.realCustomerList count] == 0)
		return 0;
	
	return PER_PAGE_ITEM_COUNT;
}

- (void) modCell:(UITableViewCell *)aCell withCustomer:(CustomerModel *)customer
{
	// Name
	CGRect tRect;
	
	tRect = CGRectMake(10.0f, 10.0f, 700.0f, 40.0f);
	id name = [[UILabel alloc] initWithFrame:tRect];
	[name setFont:[UIFont fontWithName:@"American Typewriter" size:26.0f]];
	[name setBackgroundColor:[UIColor clearColor]];
	if ([customer name1] == nil) {
		if ([customer name2] == nil) {
			[name setText:@"Name: no value"];
		} else {
			[name setText:[NSString stringWithFormat:@"Name: %@", [customer name2]]];
		}
	} else {
		if ([customer name2] == nil) {
			[name setText:[NSString stringWithFormat:@"Name: %@", [customer name1]]];
		} else {
			[name setText:[NSString stringWithFormat:@"Name: %@ %@", [customer name1], [customer name2]]];
		}
	}

	// Address
	tRect = CGRectMake(10.0f, 50.0f, 700.0f, 35.0f);
	id address = [[UILabel alloc] initWithFrame:tRect];
	[address setFont:[UIFont systemFontOfSize:18.0f]];
	[address setBackgroundColor:[UIColor clearColor]];
	if ([customer address1] == nil) {
		if ([customer address2] == nil) {
			[address setText:@"Address: no value"];
		} else {
			[address setText:[NSString stringWithFormat:@"Address: %@", [customer address2]]];
		}
	} else {
		if ([customer address2] == nil) {
			[address setText:[NSString stringWithFormat:@"Address: %@", [customer address1]]];
		} else {
			[address setText:[NSString stringWithFormat:@"Address: %@ / %@", [customer address1], [customer address2]]];
		}
	}
	
	// City
	tRect = CGRectMake(10.0f, 90.0f, 700.0f, 35.0f);
	id city = [[UILabel alloc] initWithFrame:tRect];
	[city setFont:[UIFont systemFontOfSize:18.0f]];
	[city setBackgroundColor:[UIColor clearColor]];
	if ([customer city] == nil) {
		[city setText:[NSString stringWithFormat:@"City: no value"]];
	} else {
		[city setText:[NSString stringWithFormat:@"City: %@", [customer city]]];
	}
	
	[aCell setAccessoryType:UITableViewCellAccessoryDetailDisclosureButton];
	
	// Add to cell 
	[aCell addSubview:name];
	[aCell addSubview:address];
	[aCell addSubview:city];
	
	[name release];
	[address release];
	[city release];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"CustomerCell"] autorelease];
	
	// Display dark and light background in alternate rows -- see tableView:willDisplayCell:forRowAtIndexPath:.
	if (self.pageNum < 1)
		return cell;

	int index = (self.pageNum - 1) * PER_PAGE_ITEM_COUNT + indexPath.row;
	
	if (index >= [self.realCustomerList count])
		return cell;
	
	CustomerModel *customer = [self.realCustomerList objectAtIndex:index];
	
	[self modCell:cell withCustomer:customer];
	
    return cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
	int rowIndex = indexPath.row;
	BOOL flag = (rowIndex % 2 == 0);
	
	UIImage *backgroundImage = flag ? barBlue : barWhite;
	cell.backgroundView = [[[UIImageView alloc] initWithImage:backgroundImage] autorelease];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
	
	int index = (self.pageNum - 1) * PER_PAGE_ITEM_COUNT + indexPath.row;
	
	CustomerModel *customer = [self.realCustomerList objectAtIndex:index];
	
	[[ImageAppDelegate sharedAppDelegate] setCustomer:customer];
	
	[[ImageAppDelegate sharedAppDelegate] setShouldRefresh:NO];
	
	[self.navigationController pushViewController:[[ImageAppDelegate sharedAppDelegate] shoppingViewController] animated:YES];
}

- (IBAction)gotoMain:(id)sender
{
	[self.search resignFirstResponder];
	
	[[ImageAppDelegate sharedAppDelegate] showMainPage];
}

- (void)refresh
{
	self.realCustomerList = nil;
	[self.search resignFirstResponder];
	[self.search setText:@""];
	
	[self _parseCustomerXML];
	[self reloadCustomers];
}

- (IBAction)addCustomer:(id)sender
{
	[self.search resignFirstResponder];
	
	[self.navigationController pushViewController:[[ImageAppDelegate sharedAppDelegate] addCustomerController] animated:YES];
}

- (void) showCustomers
{
	[self refresh];
	
	[[ImageAppDelegate sharedAppDelegate] hiddenSplashView];
	
	if ([self.realCustomerList count] == 0)
		[[ImageAppDelegate sharedAppDelegate] showAlert:MSG_NO_CUSTOMERS];
}

- (void) viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	self.navigationController.navigationBarHidden = YES;

	if ([[ImageAppDelegate sharedAppDelegate] shouldRefresh]) {
		[[ImageAppDelegate sharedAppDelegate] showSplashView:@"Loading..."];
		
		[NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(showCustomers) userInfo:nil repeats:NO];
	}
}

#pragma mark Navigation functions

- (IBAction) gotoFirst
{
	if (self.realCustomerList == nil)
		return;
	
	[self setPageNum:1];
	[self.tblCustomers reloadData];
	
	[self.pageNumber setTitle:[NSString stringWithFormat:@"%d / %d", self.pageNum, self.pageCount]];
}

- (IBAction) gotoPrev
{
	if (self.realCustomerList == nil)
		return;
	
	if (self.pageNum < 2)
		return;
	
	[self setPageNum:(self.pageNum - 1)];
	[self.tblCustomers reloadData];
	
	[self.pageNumber setTitle:[NSString stringWithFormat:@"%d / %d", self.pageNum, self.pageCount]];
}

- (IBAction) gotoNext
{
	if (self.realCustomerList == nil)
		return;
	
	if (self.pageNum == self.pageCount)
		return;
	
	[self setPageNum:(self.pageNum + 1)];
	[self.tblCustomers reloadData];
	
	[self.pageNumber setTitle:[NSString stringWithFormat:@"%d / %d", self.pageNum, self.pageCount]];
}

- (IBAction) gotoLast
{
	if (self.realCustomerList == nil)
		return;
	
	[self setPageNum:self.pageCount];
	[self.tblCustomers reloadData];
	
	[self.pageNumber setTitle:[NSString stringWithFormat:@"%d / %d", self.pageNum, self.pageCount]];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return YES;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[gotoMainButton release];
	[search release];
	
	[tblCustomers release];
	[realCustomerList release];
	
	[barBlue release];
	[barWhite release];
	
    [super dealloc];
}


@end
