//
//  DetailViewController.m
//  Image
//
//  Created by System Administrator on 11/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#include <CFNetwork/CFNetwork.h>

#import "DetailViewController.h"
#import "ImageAppDelegate.h"
#import "ProductModel.h"

@implementation DetailViewController

@synthesize imgProduct;
@synthesize tblDetailInfo;
@synthesize txtDesc;
@synthesize lblPrice;
@synthesize lblTotalPrice;
@synthesize txtQuantity;
@synthesize lblName;
@synthesize btnOriginalProduct;
@synthesize btnOrderNow;
@synthesize txtWebText;

@synthesize popOverController;

@synthesize product;

- (BOOL)textFieldShouldReturn:(UITextField *)textField
// A delegate method called by the URL text field when the user taps the Return 
// key.  We just dismiss the keyboard.
{
	int quantity = [txtQuantity.text intValue];
	
	if (quantity < 1) {
		[lblTotalPrice setText:@"$ 0"];
	} else {
		int totalPrice = quantity * [product intUnitPrice];
		[lblTotalPrice setText:[NSString stringWithFormat:@"$ %d", totalPrice]];
	}

    [textField resignFirstResponder];
    return NO;
}

#pragma mark XML functions


- (void) _parseOrderXML: (NSString *) fileName
{
	NSString *path = [NSString stringWithFormat:@"%@/%@.%@", DOCUMENTS_FOLDER, fileName, XML_FILE_EXTENSION];
	NSString *data = [[NSString alloc] initWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
	
	ImageAppDelegate* appDelegate = (ImageAppDelegate*)[[UIApplication sharedApplication] delegate];
	
	if (appDelegate.orderList != nil) {
		[appDelegate.orderList release];
		appDelegate.orderList = nil;
	}
	
	appDelegate.orderList = [[NSMutableArray alloc] init];
	
	NSMutableArray * _list = [XMLParser GetTagValuesByToken:data
												   TagValue:@"Products"];
	for (NSString *temp in _list)
	{
		NSString *customerNo = (NSString *)[XMLParser GetFirstTagValueByToken:temp TagValue:@"Customer_No"];
		
		NSMutableArray *_orders = [XMLParser GetTagValuesByToken:temp
														TagValue:@"Orders"];
		
		for (NSString *item in _orders)
		{
			// Parse the product's detail information.
			OrderModel *order = [[OrderModel alloc] initialize];
			order.customerNo = customerNo;
			order.orderDatetime = (NSString *)[XMLParser GetFirstTagValueByToken:item TagValue:@"DateTime"];
			order.productNo = (NSString *)[XMLParser GetFirstTagValueByToken:item TagValue:@"Product_No"];
			order.quantity = [[XMLParser GetFirstTagValueByToken:temp TagValue:@"Quantity"] intValue];
			
			[appDelegate.orderList addObject:order];
			
			[order release];
		}
	}
	
	[data release];
}

- (BOOL) generateXMLFile
{
	NSMutableString *strFileData = [[NSMutableString alloc] init];
	
	NSMutableArray *orderList = [[ImageAppDelegate sharedAppDelegate] orderList];
	
	if (orderList == nil)
		[self _parseOrderXML:ORDERS_TEMP_XML_FILE_NAME];
	
	orderList = [[ImageAppDelegate sharedAppDelegate] orderList];
	
	// Append the order
	NSDateFormatter *dateFormat = [[[NSDateFormatter alloc] init] autorelease];
	[dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
	
	NSString *dateString = [dateFormat stringFromDate:[NSDate date]];
	
	CustomerModel *customer = [[ImageAppDelegate sharedAppDelegate] customer];
	
	OrderModel *order = [[OrderModel alloc] initialize];
	[order setProductNo:product.strNO];
	[order setOrderDatetime:dateString];
	[order setQuantity:[txtQuantity.text intValue]];
	[order setCustomerNo:customer.no];
	
	[orderList addObject:order];
	[order release];
	
	// Sort
	NSString *customerNo = nil;
	NSMutableArray *customerGroup = nil;
	NSMutableArray *noGroup = [[NSMutableArray alloc] init];
	NSMutableArray *sortedGroup = [[NSMutableArray alloc] init];
	
	for (OrderModel *sortItem in orderList)
	{
		customerNo = sortItem.customerNo;
		
		if ([noGroup containsObject:customerNo])
			continue;
		
		customerGroup = [[NSMutableArray alloc] init];
		
		for (OrderModel *tempItem in orderList)
		{
			if ([customerNo isEqual:tempItem.customerNo])
				[customerGroup addObject:tempItem];
		}
		
		[sortedGroup addObject:customerGroup];
		[customerGroup release];
		customerGroup = nil;
		
		[noGroup addObject:customerNo];
	}
	
	// Generate xml
	[strFileData appendString:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"];
	[strFileData appendString:@"<Root>\n"];
	
	for (NSMutableArray *sortedOrders in sortedGroup)
	{
		if (!sortedOrders || [sortedOrders count] == 0)
			break;
		
		OrderModel *firstItem = (OrderModel *)[sortedOrders objectAtIndex:0];
		
		[strFileData appendFormat:@"\t<Products>\n"];
		[strFileData appendFormat:@"\t\t<Customer_No>%@</Customer_No>\n", firstItem.customerNo];

		for (OrderModel *item in sortedOrders)
		{
			[strFileData appendFormat:@"\t\t<Orders>\n"];
			[strFileData appendFormat:@"\t\t\t<DateTime>%@</DateTime>\n", item.orderDatetime];
			[strFileData appendFormat:@"\t\t\t<Product_No>%@</Product_No>\n", item.productNo];
			[strFileData appendFormat:@"\t\t\t<Quantity>%d</Quantity>\n", item.quantity];
			[strFileData appendFormat:@"\t\t</Orders>\n"];
		}
		
		[strFileData appendFormat:@"\t</Products>\n"];
	}
	
	[strFileData appendString:@"</Root>"];
	
	NSString *path = [DOCUMENTS_FOLDER stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@", ORDERS_TEMP_XML_FILE_NAME, XML_FILE_EXTENSION]];
	
	BOOL retValue = [strFileData writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
	
	[strFileData release];
	[noGroup release];
	[sortedGroup release];
	
	return retValue;
}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
	
	[self setTitle:@"Product Information"];
}

- (void) viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	self.navigationController.navigationBarHidden = NO;
	[self.navigationController.navigationBar setBarStyle:UIBarStyleBlackTranslucent];

	[self loadProductInfo:[[ImageAppDelegate sharedAppDelegate] product]];
}

#pragma mark Tray

- (IBAction) showPopover
{
	if (popOverController == nil) {
		ProductTrayController *tray = [[ImageAppDelegate sharedAppDelegate] productTrayController];
		
		popOverController = [[UIPopoverController alloc] initWithContentViewController:tray];
	}
	
	[popOverController presentPopoverFromRect:CGRectMake(204.0, 399.0, 0.0, 0.0) 
									   inView:self.view
					 permittedArrowDirections:UIPopoverArrowDirectionAny 
									 animated:YES];
}

- (BOOL)popoverControllerShouldDismissPopover:(UIPopoverController *)popoverController {
    return YES;
}

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {

}

#pragma mark Load Product

- (void) loadProductInfo: (ProductModel *) productInfo
{
	if (productInfo == nil)
		return;
	
	product = productInfo;
	
	// set product's tray
	[[ImageAppDelegate sharedAppDelegate] setProductTray:product];
	
	NSString *path = [DOCUMENTS_FOLDER stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.jpg", [product strNO]]];
	
	if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
		[imgProduct setBackgroundImage:[UIImage imageWithContentsOfFile:path] forState:UIControlStateNormal];
	} else {
		[imgProduct setBackgroundImage:[UIImage imageNamed:@"NoImage.png"] forState:UIControlStateNormal];
	}
	
	[txtDesc setText:[product strDesc]];
	[txtWebText setText:[product strWebText]];
	[lblPrice setText:[NSString stringWithFormat:@"$ %d", [product intUnitPrice]]];
	[lblTotalPrice setText:[NSString stringWithFormat:@"$ %d", [product intUnitPrice]]];
	[txtQuantity setText:@"1"];
	[lblName setText:[product strNO]];
	
	[[self tblDetailInfo] reloadData];
}

- (IBAction) showOriginalProduct
{
	[self.btnOriginalProduct setHidden:YES];
	
	[self loadProductInfo:[[ImageAppDelegate sharedAppDelegate] product]];
}

- (IBAction) orderNow
{
	if ([txtQuantity.text isEqual:@""] || [txtQuantity.text intValue] < 1) {
		[[ImageAppDelegate sharedAppDelegate] showAlert:@"Specify quantity of product to order."];
		
		return;
	}
	
	if ([self generateXMLFile]) {
		[[ImageAppDelegate sharedAppDelegate] showAlert:MSG_ORDER_SUCCESS];
	} else {
		[[ImageAppDelegate sharedAppDelegate] showAlert:MSG_ORDER_FAIL];
	}

}

#pragma mark Product Detail Information

- (void) modCell:(UITableViewCell *)aCell withTitle:(NSString *) title info:(NSString *) info
{
	// Title
	CGRect tRect1 = CGRectMake(10.0f, 10.0f, 300.0f, 42.0f);
	id title1 = [[UILabel alloc] initWithFrame:tRect1];
	[title1 setText:title];
	[title1 setFont: [UIFont fontWithName:@"American Typewriter" size:24.0f]];
	[title1 setBackgroundColor:[UIColor clearColor]];
	
	// Data 
	CGRect tRect2 = CGRectMake(320.0f, 10.0f, 300.0f, 42.0f);
	id title2 = [[UILabel alloc] initWithFrame:tRect2];
	[title2 setText:info];
	[title2 setFont: [UIFont fontWithName:@"Helvetica" size:24.0f]];
	[title2 setBackgroundColor:[UIColor clearColor]];
	[title2 setLineBreakMode:UILineBreakModeWordWrap];
	[title2 setNumberOfLines:30];
	
	// Add to cell 
	[aCell addSubview:title1];
	[aCell addSubview:title2];
	
	[title1 release];
	[title2 release];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"DetailCell"] autorelease];
	
	int row = [indexPath row];
	
	if (product == nil) {
		if ([[ImageAppDelegate sharedAppDelegate] product] == nil) {
			return nil;
		}
		product = [[ImageAppDelegate sharedAppDelegate] product];
	}

	switch (row) {
		case 0:
			[self modCell:cell withTitle:@"Unit List Price" info:[NSString stringWithFormat:@"%d", product.intUnitListPrice]];
			break;
		case 1:
			[self modCell:cell withTitle:@"Unit Price" info:[NSString stringWithFormat:@"%d", product.intUnitPrice]];
			break;
		case 2:
			[self modCell:cell withTitle:@"Sales Unit of Measure" info:product.strSalesUnitMeasure];
			break;
		case 3:
			[self modCell:cell withTitle:@"Nyhed" info:[NSString stringWithFormat:@"%d", product.intNyhed]];
			break;
		case 4:
			[self modCell:cell withTitle:@"Web Forside" info:[NSString stringWithFormat:@"%d", product.intWebForSide]];
			break;
		default:
			break;
	}
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
	return cell;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return NO;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[imgProduct release];
	[tblDetailInfo release];
	[txtDesc release];
	[lblPrice release];
	[lblTotalPrice release];
	[txtQuantity release];
	[lblName release];
	[btnOriginalProduct release];
	[btnOrderNow release];
	[txtWebText release];
	[popOverController release];
	
	[product release];
	
    [super dealloc];
}


@end
