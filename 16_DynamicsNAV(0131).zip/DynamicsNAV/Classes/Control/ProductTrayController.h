//
//  ProductTrayController.h
//  DynamicsNAV
//
//  Created by DEV on 1/12/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProductTrayController : UITableViewController <UITableViewDelegate, UITableViewDataSource> {

}

- (void) modCell:(UITableViewCell *)aCell withTitle:(NSString *) title info:(NSString *) info;

@end
