//
//  ProductTrayController.m
//  DynamicsNAV
//
//  Created by DEV on 1/12/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "ProductTrayController.h"
#import "ProductModel.h"
#import "ImageAppDelegate.h"

@implementation ProductTrayController

#pragma mark -
#pragma mark View lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];

	self.tableView.rowHeight = 70;
	self.contentSizeForViewInPopover = CGSizeMake(400.0, 200.0);
	
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
	
	[self.tableView reloadData];
}

/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
*/


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Override to allow orientations other than the default portrait orientation.
    return YES;
}


#pragma mark -
#pragma mark Table view data source

- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	return 42.0;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	return @"Category";
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    switch (section) {
		case 0:			// category items
			return 2;
			break;
		default:
			break;
	}
	return 1;
}

- (void) modCell:(UITableViewCell *)aCell withTitle:(NSString *) title info:(NSString *) info
{
	CGRect tRect1 = CGRectMake(30.0f, 10.0f, 200.0f, 50.0f);
	id title1 = [[UILabel alloc] initWithFrame:tRect1];
	[title1 setText:title];
	[title1 setFont: [UIFont fontWithName:@"American Typewriter" size:18.0f]];
	[title1 setBackgroundColor:[UIColor clearColor]];
	
	CGRect tRect2 = CGRectMake(240.0f, 10.0f, 130.0f, 50.0f);
	id title2 = [[UILabel alloc] initWithFrame:tRect2];
	[title2 setText:info];
	[title2 setFont: [UIFont fontWithName:@"Helvetica" size:16.0f]];
	[title2 setBackgroundColor:[UIColor clearColor]];
	
	// Add to cell 
	[aCell addSubview:title1];
	[aCell addSubview:title2];
	
	[title1 release];
	[title2 release];
}

#define EMPTY_VALUE		@"No Category"

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"CategoryCell";
    
    UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    int row = [indexPath row];
	
	ProductModel *product = [[ImageAppDelegate sharedAppDelegate] productTray];
	
	if (product == nil)
		return cell;
	
	int section = [indexPath section];
	
	switch (section) {
		case 0:		// category items
			switch (row) {
				case 0:
					[self modCell:cell withTitle:@"Product Category:" info:product.category ? product.category.productCategory : EMPTY_VALUE];
					break;
				case 1:
					[self modCell:cell withTitle:@"Sub Product Category:" info:product.category ? product.category.subProductCategory : EMPTY_VALUE];
					break;
				default:
					break;
			}
			break;
		default:
			break;
	}	
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here. Create and push another view controller.
    /*
    <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
    // ...
    // Pass the selected object to the new view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
    [detailViewController release];
    */
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end

