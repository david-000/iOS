//
//  DetailViewController.h
//  Image
//
//  Created by System Administrator on 11/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ProductModel.h"
#import "CustomImageButton.h"

@interface DetailViewController : UIViewController <UIScrollViewDelegate, UIPopoverControllerDelegate, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate> {
	UIButton *imgProduct;
	UITableView *tblDetailInfo;
	UITextView *txtDesc;
	UILabel *lblPrice;
	UILabel *lblTotalPrice;
	UITextField *txtQuantity;
	UILabel *lblName;
	UIButton *btnOriginalProduct;
	UIButton *btnOrderNow;
	UITextView *txtWebText;
	UIPopoverController *popOverController;
	
	ProductModel *product;
}

@property (nonatomic, retain) IBOutlet UIButton *imgProduct;
@property (nonatomic, retain) IBOutlet UITableView *tblDetailInfo;
@property (nonatomic, retain) IBOutlet UITextView *txtDesc;
@property (nonatomic, retain) IBOutlet UILabel *lblPrice;
@property (nonatomic, retain) IBOutlet UILabel *lblTotalPrice;
@property (nonatomic, retain) IBOutlet UITextField *txtQuantity;
@property (nonatomic, retain) IBOutlet UILabel *lblName;
@property (nonatomic, retain) IBOutlet UIButton *btnOriginalProduct;
@property (nonatomic, retain) IBOutlet UIButton *btnOrderNow;
@property (nonatomic, retain) IBOutlet UITextView *txtWebText;
@property (nonatomic, retain) UIPopoverController *popOverController;

@property (nonatomic, retain) ProductModel *product;

- (void) loadProductInfo: (ProductModel *) productInfo;
- (IBAction) showPopover;
- (void) modCell:(UITableViewCell *)aCell withTitle:(NSString *) title info:(NSString *) info;
- (IBAction) orderNow;
- (void) _parseOrderXML: (NSString *) fileName;

- (BOOL) generateXMLFile;

@end
