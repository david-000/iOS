//
//  SynchronizeController.h
//  DynamicsNAV
//
//  Created by DEV on 1/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#define FTP_HOST_NAME		@"FTP.skanderby.dk"
#define FTP_USER_NAME		@"ipadtest"
#define FTP_USER_PASSWORD	@"LC8200"

#define DOCUMENTS_FOLDER			[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]

@interface SynchronizeController : UIViewController {
	UITextView *console;
	
	UIBarButtonItem *synchronize;
}

@property (nonatomic, retain) IBOutlet UITextView *console;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *synchronize;

- (BOOL) syncLocalTree;
- (IBAction) syncAction;

- (BOOL) appendOrders;

@end
