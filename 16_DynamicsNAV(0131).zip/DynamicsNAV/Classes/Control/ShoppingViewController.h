//
//  ShoppingViewController.h
//  DynamicsNAV
//
//  Created by DEV on 1/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductModel.h"
#import "XMLParser.h"
#import "ProductModel.h"
#import "OrderModel.h"
#import "CustomImageButton.h"

@interface ShoppingViewController : UIViewController <UIScrollViewDelegate, UISearchBarDelegate>
{
	UIScrollView *		shopView;
	UIImageView *		content;
	UIBarButtonItem *	gotoMainButton;
	UISearchBar *		search;
	UIImage *			noImage;
    
	NSMutableArray *	realProductList;
	
	UIBarButtonItem *	pageNumber;
	int					pageNum;
	int					pageCount;
}

@property (nonatomic, retain) IBOutlet UIScrollView *				shopView;
@property (nonatomic, retain) IBOutlet UIImageView *				content;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *			gotoMainButton;
@property (nonatomic, retain) IBOutlet UISearchBar *				search;

@property (nonatomic, retain) UIImage *			noImage;
@property (nonatomic, retain) NSMutableArray *						realProductList;

@property (nonatomic, retain) IBOutlet UIBarButtonItem *	pageNumber;
@property (nonatomic) int pageNum;
@property (nonatomic) int pageCount;

- (void) buildSearchArrayFrom: (NSString *) matchString;
- (IBAction)gotoBack:(id)sender;
- (void) _parseProductXML;
- (void) clearContent;
- (void) showProductDetailView: (CustomImageButton *) productBtn;
- (void) showProducts;
- (void) reloadProducts;
- (void) loadProducts;

- (IBAction) gotoFirst;
- (IBAction) gotoPrev;
- (IBAction) gotoNext;
- (IBAction) gotoLast;

@end
