    //
//  AddCustomerController.m
//  DynamicsNAV
//
//  Created by DEV on 1/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "AddCustomerController.h"
#import "ImageAppDelegate.h"

@implementation AddCustomerController

@synthesize no;
@synthesize name1;
@synthesize name2;
@synthesize address1;
@synthesize address2;
@synthesize postCode;
@synthesize city;
@synthesize contact;
@synthesize contactPhoneNo;
@synthesize contactEmail;
@synthesize currencyCode;
@synthesize countryRegionCode;
@synthesize customerPriceGroup;
@synthesize paymentTermsCode;

@synthesize btnReset;
@synthesize btnCreate;

 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

- (BOOL)textFieldShouldReturn:(UITextField *)textField
// A delegate method called by the URL text field when the user taps the Return 
// key.  We just dismiss the keyboard.
{
#pragma unused(textField)
    [textField resignFirstResponder];
    return NO;
}

- (void) viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	[self.navigationController setNavigationBarHidden:NO];
	[self.navigationController.navigationBar setBarStyle:UIBarStyleBlackTranslucent];
	
	[self setTitle:@"Add New Customer"];
}

- (IBAction) resetAction
{
	self.name1.text = @"";
	self.name2.text = @"";
	self.address1.text = @"";
	self.address2.text = @"";
	self.postCode.text = @"";
	self.city.text = @"";
	self.contact.text = @"";
	self.contactPhoneNo.text = @"";
	self.contactEmail.text = @"";
	self.currencyCode.text = @"";
	self.countryRegionCode.text = @"";
	self.customerPriceGroup.text = @"";
	self.paymentTermsCode.text = @"";
}

- (IBAction) createAction
{
	if ([self generateXMLFile] == YES) {
		[[ImageAppDelegate sharedAppDelegate] showAlert:MSG_NEW_CUSTOMER_SUCCESS];
	} else {
		[[ImageAppDelegate sharedAppDelegate] showAlert:MSG_NEW_CUSTOMER_FAIL];
	}
}

- (BOOL) generateXMLFile
{
	NSMutableString *strFileData = [[NSMutableString alloc] init];
	
	// Generate xml
	[strFileData appendString:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"];
	[strFileData appendString:@"<Root>\n"];
	[strFileData appendFormat:@"\t<Customers>\n"];
	[strFileData appendFormat:@"\t\t<No>%@</No>\n", no.text];
	[strFileData appendFormat:@"\t\t<Name>%@</Name>\n", name1.text];
	[strFileData appendFormat:@"\t\t<Name_2>%@</Name_2>\n", name2.text];
	[strFileData appendFormat:@"\t\t<Address>%@</Address>\n", address1.text];
	[strFileData appendFormat:@"\t\t<Address_2>%@</Address_2>\n", address2.text];
	[strFileData appendFormat:@"\t\t<Post_Code>%@</Post_Code>\n", postCode.text];
	[strFileData appendFormat:@"\t\t<City>%@</City>\n", city.text];
	[strFileData appendFormat:@"\t\t<Contact>%@</Contact>\n", contact.text];
	[strFileData appendFormat:@"\t\t<Contact_Phone_No>%@</Contact_Phone_No>\n", contactPhoneNo.text];
	[strFileData appendFormat:@"\t\t<Contact_E-Mail>%@</Contact_E-Mail>\n", contactEmail.text];
	[strFileData appendFormat:@"\t\t<Currency_Code>%@</Currency_Code>\n", currencyCode.text];
	[strFileData appendFormat:@"\t\t<Country_Region_Code>%@</Country_Region_Code>\n", countryRegionCode.text];
	[strFileData appendFormat:@"\t\t<Customer_Price_Group>%@</Customer_Price_Group>\n", customerPriceGroup.text];
	[strFileData appendFormat:@"\t\t<Payment_Terms_Code>%@</Payment_Terms_Code>\n", paymentTermsCode.text];
	[strFileData appendFormat:@"\t</Customers>\n"];
	[strFileData appendString:@"</Root>"];
	
	NSString *path = [DOCUMENTS_FOLDER stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@", NEW_CUSTOMER_XML_FILE_NAME, XML_FILE_EXTENSION]];
	
	BOOL retValue = [strFileData writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
	
	[strFileData release];
	
	return retValue;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return YES;
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[no release];
	[name1 release];
	[name2 release];
	[address1 release];
	[address2 release];
	[postCode release];
	[city release];
	[contact release];
	[contactPhoneNo release];
	[contactEmail release];
	[currencyCode release];
	[countryRegionCode release];
	[customerPriceGroup release];
	[paymentTermsCode release];
	
	[btnReset release];
	[btnCreate release];
	
    [super dealloc];
}


@end
