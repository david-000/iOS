//
//  myXMLParser.m
//  EditorTest
//
//  Created by System Administrator on 23.2.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//String

#import "XMLParser.h"
#import "ImageAppDelegate.h"

@implementation XMLParser

#pragma mark Low-level Functions

+(NSString *)GetFirstTagValueByToken:(NSString*)xmlString TagValue:(NSString*)tokenName
{
	NSMutableArray* values = [self GetTagValuesByToken:xmlString TagValue:tokenName];
	
	if(values == nil || [values count] < 1)
		return nil;
	
	NSString *firstContent = [NSString stringWithFormat:@"%@", (NSString*)[values objectAtIndex:0]];
	
	[values release];
	
	return firstContent;
}

+(NSMutableArray *)GetTagValues:(NSString*)xmlString sTagValue:(NSString*)startToken eTagValue:(NSString*)endToken
{
	NSString *bufferString = xmlString;
	NSString *rangeStr = @"";
	int curpos = 0, step = 1;
	NSRange beginPos, endPos;
	
	NSMutableArray *array;
	
	beginPos = [bufferString rangeOfString:startToken options:NSCaseInsensitiveSearch range:NSMakeRange(0, [bufferString length])];
	
	if(beginPos.length <= 0)
		return nil;
	
	array = [[NSMutableArray alloc] init];
	
	curpos = beginPos.location + beginPos.length;
	
	for(;;)
	{
		endPos = [bufferString rangeOfString:endToken options:NSCaseInsensitiveSearch range:NSMakeRange(curpos, [bufferString length] - curpos)];
		
		if(endPos.length <= 0)
			break;
		
		rangeStr = [[bufferString substringToIndex:(endPos.location)] substringFromIndex:(curpos)];
		step += [self GetTokenCount:rangeStr tokenStr:(NSString*)startToken] - 1;
		
		if(step == 0) 
		{
			NSString *data = @"";
			data = [[bufferString substringToIndex:(endPos.location)] substringFromIndex:(beginPos.location + beginPos.length)];
			[array addObject:data];
			beginPos = [bufferString rangeOfString:startToken options:NSCaseInsensitiveSearch range:NSMakeRange(endPos.location + endPos.length, [bufferString length] - endPos.location - endPos.length)];
			
			if(beginPos.length <= 0)
				break;
			
			curpos = beginPos.location + beginPos.length;
			
			step = 1;
		}
		else		
			curpos = endPos.location + endPos.length;
	}
	
	return array;
}

+(int)GetTokenCount:(NSString *)rangeStr tokenStr:(NSString*)tokenStr
{
	int bRange = 0, count = 0;
	
	for(;;)
	{
		NSRange iPos = [rangeStr rangeOfString:tokenStr options:NSCaseInsensitiveSearch range:NSMakeRange(bRange, [rangeStr length] - bRange)];
		
		if(iPos.length <= 0)
			break;
		
		bRange = iPos.location + iPos.length;
		
		count ++;
	}
	
	return count;
}

+(NSMutableArray *)GetTagValuesByToken:(NSString*)xmlString TagValue:(NSString*)tokenName
{
	if((!xmlString) || (!tokenName)) 
		return nil;
	
	NSString *startToken = [NSString stringWithFormat:@"<%@>", tokenName];
	NSString *endToken = [NSString stringWithFormat:@"</%@>", tokenName];
	
	NSMutableArray* values = [self GetTagValues:xmlString sTagValue:startToken eTagValue:endToken];
	
	return values;
}
//
//+(int) FriendSelectTypeProcess:(NSString *)data{
//
//	NSMutableArray *friends = [self GetTagValuesByToken:data TagValue:@"friend"];
//	NSString * friend_data;
//	
//	ImageLoaderAppDelegate * delegate = (ImageLoaderAppDelegate *) [[UIApplication sharedApplication] delegate];
//	[delegate.m_FriendArray removeAllObjects];
//
//	for(friend_data in friends)	
//	{
//		int friend_id = [[[self GetTagValuesByToken:friend_data TagValue:@"friendId"] objectAtIndex:0] intValue];
//							   
//		NSString *friend_name =  [[self GetTagValuesByToken:friend_data  TagValue:@"friendName"] objectAtIndex:0];
//		
//		FriendModel *model = [[FriendModel alloc] initialize];
//		[model setFriendModel:friend_id friendName:friend_name];
//		[delegate.m_FriendArray addObject:model];
//		[model release];
//	}
//	
//	[FriendModel writeToDB:delegate.m_FriendArray];
//	
//	return 1;
//							   
//}

@end
