//
//  myXMLParser.h
//  EditorTest
//
//  Created by System Administrator on 23.2.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface XMLParser : NSXMLParser <NSXMLParserDelegate>{
}

#pragma mark Low-level Functions

+(NSString *)GetFirstTagValueByToken:(NSString*)xmlString TagValue:(NSString*)tokenName;
+(NSMutableArray *)GetTagValues:(NSString*)xmlString sTagValue:(NSString*)startToken eTagValue:(NSString*)endToken;
+(int)GetTokenCount:(NSString *)rangeStr tokenStr:(NSString*)tokenStr;
+(NSMutableArray *)GetTagValuesByToken:(NSString*)xmlString TagValue:(NSString*)tokenName;

@end
