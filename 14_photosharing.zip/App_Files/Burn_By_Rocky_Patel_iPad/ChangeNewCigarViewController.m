//
//  ChangeNewCigarViewController.m
//  CigarBoss
//
//  Created by Nitin on 17/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ChangeNewCigarViewController.h"
#import "CigarBossAppDelegate.h"
#import "Cigar.h"
#import "CustomHighlightedCell.h"
#import "CigarViewController.h"
#import "SearchingOverlayView.h"
#import "SearchResultsObject.h"
#import "CigarsViewController.h"
#import "FilteredViewSearch.h"

CigarBossAppDelegate *appDelegate;

@implementation ChangeNewCigarViewController

@synthesize brand, cigars, forNewCigars;
@synthesize keys;


// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
        forNewCigars = NO;
    }
    return self;
}
- (id)initWithCoder:(NSCoder *)aDecoder
{
	self = [super initWithCoder:aDecoder];
	
	searchingTableView = nil;
	searchResultsDataSource = [[SearchResultsObject alloc] init];
	searchResultsDataSource.parent = self;
	
	already = NO;
	return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    
    searching = FALSE;
	
    //	if(self.brand) self.title = self.brand;
    arrCigarObj = [[NSMutableArray alloc]init];
    keysArray = [[NSMutableArray alloc]init];
    arrydic = [[NSMutableArray alloc]init];
    arrdist = [[NSMutableDictionary alloc] init];
    arrdist2 = [[NSMutableDictionary alloc] init];
    AllTitleindexArray = [[NSMutableArray alloc]init];
    //NSLog(@"CigarsViewController>>>>>>>>>>>>> Selft.Brand = %@ ",self.brand);
    if (self.brand) {
        UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 190, 30)];
        titleLabel.textColor = [UIColor whiteColor];
        titleLabel.textAlignment = UITextAlignmentCenter;
        titleLabel.text = self.brand;
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.font = [UIFont fontWithName:@"Copperplate" size:20.0];
        titleLabel.minimumFontSize = 6;
        titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//        titleLabel.adjustsFontSizeToFitWidth = YES;
        self.navigationItem.titleView = titleLabel;
        [titleLabel release];
        titleLabel = nil;
    }
    else{
        UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 190, 30)];
        titleLabel.textColor = [UIColor whiteColor];
        titleLabel.textAlignment = UITextAlignmentCenter;
        titleLabel.text =@"New Cigars"; 
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.font = [UIFont fontWithName:@"Copperplate" size:20.0];
        titleLabel.minimumFontSize = 6;
        titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//        titleLabel.adjustsFontSizeToFitWidth = YES;
        self.navigationItem.titleView = titleLabel;
        [titleLabel release];
    }
    
	mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 704)];
	bgView.image = [UIImage imageNamed:@"right_side.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
    [bgView release];
    
    mainTableView.tableHeaderView = topView;
	appDelegate = [[UIApplication sharedApplication] delegate];
    
    
	
	appDelegate = [[UIApplication sharedApplication] delegate];
    
	if(!cigars) {
        cigars = [[appDelegate cigarBrandArrays] objectForKey:brand];   
    }
    [self makeArray];
    
    [self.navigationController setNavigationBarHidden:NO animated:NO];
    //    NSLog(@"<<<<<<<<<< %@",cigars);
}
-(void)makeArray{
    
    storedArray = [[NSMutableArray alloc]init];
    
    for (int i =0; i < [cigars count]; i++) {
        NSString *t = [cigars objectAtIndex:i];
        [storedArray addObject:t];
        
        // [storedArray retain];
    }
    
	storedArray =(NSMutableArray *) [storedArray sortedArrayUsingSelector:@selector(compare:)];    
    
	for(int i = 0 ; i < [storedArray count]; i++){
        
 		Cigar *firstLetter = (Cigar *)[storedArray objectAtIndex:i];
        
        NSString *brnd = (NSString *)firstLetter.brand;
        [((NSMutableArray *)arrCigarObj) addObject:brnd];
        [arrCigarObj retain];
    }
    
    dictKeys = [[NSMutableDictionary alloc] init];
    arrCigarObj = [[arrCigarObj sortedArrayUsingSelector:@selector(compare:)] mutableCopy];
    
    NSMutableArray *newArray = [[NSMutableArray alloc] init];
    
    for (id item in arrCigarObj)
        if (NO == [newArray containsObject:item])
            [newArray addObject:item];
    
    
    arrCigarObj = newArray;
    
    
    BOOL found;
    
    // Loop through the books and create our keys
    for (NSString *book in arrCigarObj)
    {        
        NSString *c = [book  substringToIndex:1];
        
        found = NO;
        
        for (NSString *str in [arrdist allKeys])
        {
            if ([str isEqualToString:c])
            {
                found = YES;
            }
        }
        
        if (!found)
        {     
            [arrdist setValue:[[NSMutableArray alloc] init] forKey:c];
            [arrdist2 setValue:[[NSMutableArray alloc] init] forKey:book];   
        }
    }
    
    // Loop again and sort the books into their respective keys
    for (NSString *book in arrCigarObj)
    {
        [[arrdist objectForKey:[book substringToIndex:1]] addObject:book];
        [[arrdist2 objectForKey:[book substringToIndex:1]] addObject:book];
    }    
    
    // Sort each section array
    for (NSString *key in [arrdist allKeys])
    {
        [arrdist objectForKey:key];
    }    
    
    keys =(NSMutableArray *) [[[arrdist allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
}

//- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
//    
//    return [[arrdist allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
//}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {	
    
	return [[[arrdist allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section];
}
- (int)numberOfSectionsInTableView:(UITableView *)tableView
{	
    if (searching) {
        return 1;   
    }else{
        AllkeyIndexArray = [[[arrdist allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
        return [[arrdist allKeys] count];
    }
}



- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
    if (searching) {
        return [matchedStates count];
    }else{
        
        return [[arrdist valueForKey:[[[arrdist allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section]] count];
    }
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index {
    return  index;
    //	return [arrdist count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BrandCell"];
	
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"BrandCell"] autorelease];
	}
    if (searching) {
        cell.textLabel.text = [matchedStates objectAtIndex:indexPath.row];
        return cell;
    }else{
        
        NSArray *allKeys = AllkeyIndexArray;
        NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
        NSMutableArray *arrayForThisSection = [arrdist objectForKey:rightKey];
       // NSLog(@"arrayForThisSection = %@",arrayForThisSection);
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        //	cell.textLabel.text = [dictKeys objectAtIndex:indexPath.row];
        cell.textLabel.text = [arrayForThisSection objectAtIndex:indexPath.row];
//        if(forNewCigars){
//            cell.detailTextLabel.text = [arrayForThisSection objectAtIndex:indexPath.row];
//            cell.textLabel.text = [arrayForThisSection objectAtIndex:indexPath.row];
//        }
        cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:20.0];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        // NSLog(@"<<<<<<<<<<<<<< cell.textLabel.text  = %@ ",cell.textLabel.text);
        return cell;
        
    }
	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (searching) {
        CigarsViewController *c = [[CigarsViewController alloc] initWithNibName:@"CigarsViewController" bundle:nil];
        c.brand = [matchedStates objectAtIndex:indexPath.row];
        c.mShowType = 1;
        self.navigationItem.title=@"Back";
        [self.navigationController pushViewController:c animated:YES];
    }
    else
    {
        CigarsViewController *c = [[CigarsViewController alloc] initWithNibName:@"CigarsViewController" bundle:nil];
        NSArray *allKeys = keys;
        NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
        NSMutableArray *arrayForThisSection = [arrdist objectForKey:rightKey];
        c.brand = [arrayForThisSection objectAtIndex:indexPath.row];
        c.mShowType = 1;
        self.navigationItem.title=@"Back";
        [self.navigationController pushViewController:c animated:YES];
    }
}



#pragma mark -
#pragma mark UIsearch Delegate

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
	if(already) return;
	already = YES;
    searching  = TRUE;
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(closeSearch)];
	searchingOverlayView = [[SearchingOverlayView alloc] initWithFrame:CGRectMake(0, 141, 703, 704)];
	[self.view addSubview:searchingOverlayView];
	searchingOverlayView.parent = self;
	mainTableView.scrollEnabled = NO;
	//mainTableView.tableHeaderView = nil;
//	[self.view addSubview:searchBar];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar {
    [self performSelector:@selector(closeSearch)];
}

- (void)closeSearch
{
	already = NO;
    searching = FALSE;
	self.navigationItem.rightBarButtonItem = nil;
	[searchingOverlayView removeFromSuperview];
	[searchBar resignFirstResponder];
	if([searchBar.text length] != 0) {
        searchBar.text = @"";
        [searchingTableView removeFromSuperview];
    }
//	[searchBar removeFromSuperview];
//	searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 97, 703, 44)];
//	searchBar.delegate = self;
	mainTableView.tableHeaderView = topView;
	//[mainTableView reloadData];
	mainTableView.scrollEnabled = YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
	if([searchText length] == 0){
		if(searchingTableView){
			[searchingTableView removeFromSuperview];
		}
	} else {
		if(matchedStates){
			[matchedStates release];
			matchedStates = nil;
		}
		
		matchedStates = [[NSMutableArray alloc] init];
		
		
		NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
        //    NSDictionary *brandsDictionary = arrdist2;
        //    NSDictionary *brandsDictionary = arrdist;
		NSArray *allBrands = [brandsDictionary allKeys];
		for(NSString *brand in allBrands){
			NSRange titleResultsRange = [brand rangeOfString:searchText options:NSCaseInsensitiveSearch];
            //			NSLog(@"--------------Brand = %@",brand);
			if(titleResultsRange.length > 0){
				[matchedStates addObject:brand];
			}
		}
		
		//searchResultsDataSource.results = matchedStates;
        
		if(!searchingTableView)
		{
			searchingTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 141, 703, 304) style:UITableViewStylePlain];
			searchingTableView.delegate = self;
			searchingTableView.dataSource = self;
		}
		
		if(searchingTableView.superview != self.view){
			[self.view addSubview:searchingTableView];
		}
		
		[searchingTableView reloadData];
	}
}

-(void)viewDidAppear:(BOOL)animated
{
    if(AppDelegate.adStatus)
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 614)];
    }
    else
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 704)];
    }
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (toInterfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (void)refreshTableView {
    if(AppDelegate.adStatus)
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 614)];
    }
    else
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 704)];
    }
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
