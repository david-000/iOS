//
//  DisplayNewAddedCigarViewController.h
//  CigarBoss
//
//  Created by Nitin on 18/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DisplayNewAddedCigarViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    IBOutlet UITableView *mainTableView;
    NSMutableArray *cigars;
    NSArray *keys;
    NSMutableDictionary *indexes;
    BOOL loaded;
    BOOL forShops;
    NSMutableArray *brandNameArray;

}
@property (nonatomic,retain) NSMutableArray *cigars;
@end

