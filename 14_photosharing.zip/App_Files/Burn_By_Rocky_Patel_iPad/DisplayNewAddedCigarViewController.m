//
//  DisplayNewAddedCigarViewController.m
//  CigarBoss
//
//  Created by Nitin on 18/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "DisplayNewAddedCigarViewController.h"
#import "CigarBossAppDelegate.h"
#import "CustomHighlightedCell.h"
#import "Cigar.h"
#import "CigarViewController.h"

CigarBossAppDelegate *appDelegate;


@implementation DisplayNewAddedCigarViewController
@synthesize cigars;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    cigars = [[NSMutableArray alloc] init];
    brandNameArray= [[NSMutableArray alloc] init];
	if(!loaded){
        if(indexes){
            [indexes release];
            [keys release];
        }
        indexes = [[NSMutableDictionary alloc] init];
        appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
        NSArray *rating = [appDelegate NewCigarList];
        
        for(int i = 0; i<[rating count]; i++)
        {
            NSArray *firstLetter = [rating objectAtIndex:i];
            Cigar *cg = [[Cigar alloc]init];
            cg = [firstLetter objectAtIndex:1];
            [cigars addObject:cg];
            
            NSString *str = [firstLetter objectAtIndex:0];
            [brandNameArray addObject:str];
        }
            [brandNameArray retain];
    }
    
    
    mainTableView.backgroundColor = [UIColor clearColor];
    mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 367)];
	bgView.image = [UIImage imageNamed:@"Background640x734.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
       
    // Do any additional setup after loading the view from its nib.
}
-(int)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
	return 	[brandNameArray count];
}
- (void)viewWillAppear:(BOOL)animated
{
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BrandCell"];
    UILabel *typeLabel;
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil] autorelease];
               
        typeLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 3, 300, 40)];
        [typeLabel setTag:450];
        [cell.contentView addSubview:typeLabel];
        typeLabel.backgroundColor = [UIColor clearColor];
        cell.backgroundColor = [UIColor clearColor];
         typeLabel.textColor = [UIColor whiteColor];
	}	
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    typeLabel.text =  [brandNameArray objectAtIndex:indexPath.row];
  
	return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    BOOL tes = TRUE;
	CigarViewController *c = [[CigarViewController alloc] initWithNibName:@"CigarViewController" bundle:[NSBundle mainBundle]];
	Cigar *correctCig = [cigars objectAtIndex:indexPath.row];
	c.cigar = correctCig;
    c.pass = tes;
    self.navigationItem.title=@"Back";
	[self.navigationController pushViewController:c animated:YES];
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
