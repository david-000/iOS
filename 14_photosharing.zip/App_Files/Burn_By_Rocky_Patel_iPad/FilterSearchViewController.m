//
//  FilterSearchViewController.m
//  CigarBoss
//
//  Created by Nitin on 16/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FilterSearchViewController.h"
#import "Picker.h"
#import "PickerDelegate.h"
#import "CigarBossAppDelegate.h"
#import "FilterViewController.h"
#import "Cigar.h"
#import "FilteredViewControllerNew.h"
#import "FilteredViewSearch.h"
#import "SelectedButton.h"


CigarBossAppDelegate *appDelegate;

@implementation FilterSearchViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    //    self.navigationItem.title = @"Filter";
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 400, 44)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:24.0];
    label.font = [UIFont fontWithName:@"Copperplate" size:24.0];
    label.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    label.textAlignment = UITextAlignmentCenter;
    label.textColor =[UIColor whiteColor];
    label.text=@"Filter";
    
    self.navigationItem.titleView = label;
    [label release];
    strengthDict,ringDict,wrapperDict,lenDict, priceDict , countryDict = [[NSMutableDictionary alloc] init];
    
    SearchDictArray = [[NSMutableArray alloc]init];
    
    indexes = [[NSMutableDictionary alloc] init];
    
    dictSearch = [[NSMutableDictionary alloc] init];
    
    appDelegate = (CigarBossAppDelegate *)[UIApplication sharedApplication].delegate;
    
    // Do any additional setup after loading the view from its nib.
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
	//appDelegate = [[UIApplication sharedApplication] delegate];
	allCigarsArray = [[NSMutableArray alloc] init];
	
    brandsDictionary = [[NSDictionary alloc] init];
	brandsDictionary = [appDelegate cigarBrandArrays];
	NSArray *allArrays = [brandsDictionary allValues];
	for(NSArray *group in allArrays){
		for(Cigar *cigarG in group){
            if ( cigarG.isMyCigar == 1 ) {
                [allCigarsArray addObject:cigarG];
                [cigarG release];
            }
		}
	}
    
    NSMutableArray *arrPicker = [[NSMutableArray alloc] init];
    [arrPicker addObject:@"C0-No vein pathology"];
    [arrPicker addObject:@"C1-Spider or reticular veins"];
    [arrPicker addObject:@"C2-Varicose veins"];
    [arrPicker addObject:@"C3-Edema with veins"];
    [arrPicker addObject:@"C4-Skin change, no ulceration"];
    [arrPicker addObject:@"C5-Skin change, healed ulceration"];
    [arrPicker addObject:@"C6-Skin change, active ulceration"];
    
    
    objPickerStrength = [[Picker alloc] initWithFrame:CGRectMake(0.0f,748.0f, 703.0f, 320.0f) array:arrPicker];
    objPickerStrength.tag = 10;
	[objPickerStrength setParent : self];
	[objPickerStrength setDelegate:self];
	[self.view addSubview:objPickerStrength];
    [objPickerStrength release];
    
    
    objPickerRingGuage = [[Picker alloc] initWithFrame:CGRectMake(0.0f,748.0f, 703.0f, 320.0f) array:arrPicker];
    objPickerRingGuage.tag = 11;
	[objPickerRingGuage setParent : self];
	[objPickerRingGuage setDelegate:self];
	[self.view addSubview:objPickerRingGuage];
    [objPickerRingGuage release];
    
    objPickerCountry = [[Picker alloc] initWithFrame:CGRectMake(0.0f,748.0f, 703.0f, 320.0f) array:arrPicker];
    objPickerCountry.tag = 12;
	[objPickerCountry setParent : self];
	[objPickerCountry setDelegate:self];
	[self.view addSubview:objPickerCountry];
    [objPickerCountry release];
    
    objPickerWrapper = [[Picker alloc] initWithFrame:CGRectMake(0.0f,748.0f, 703.0f, 320.0f) array:arrPicker];
    objPickerWrapper.tag = 13;
	[objPickerWrapper setParent : self];
	[objPickerWrapper setDelegate:self];
	[self.view addSubview:objPickerWrapper];
    [objPickerWrapper release];
    
    objPickerLength = [[Picker alloc] initWithFrame:CGRectMake(0.0f,748.0f, 703.0f, 320.0f) array:arrPicker];
    objPickerLength.tag = 14;
	[objPickerLength setParent : self];
	[objPickerLength setDelegate:self];
	[self.view addSubview:objPickerLength];
    [objPickerLength release];
    
    objPickerPrice = [[Picker alloc] initWithFrame:CGRectMake(0.0f,748.0f, 703.0f, 320.0f) array:arrPicker];
    objPickerPrice.tag = 15;
	[objPickerPrice setParent : self];
	[objPickerPrice setDelegate:self];
	[self.view addSubview:objPickerPrice];
    [objPickerPrice release];
    
    
    btnCountry.titleLabel.textAlignment = UITextAlignmentLeft;
    btnStrength.titleLabel.textAlignment = UITextAlignmentCenter;
    btnWrapper.titleLabel.textAlignment = UITextAlignmentCenter;
    btnRing.titleLabel.textAlignment = UITextAlignmentCenter;
    btnPrice.titleLabel.textAlignment = UITextAlignmentCenter;
    btnLength.titleLabel.textAlignment = UITextAlignmentCenter;
    
    [scrollView setFrame:CGRectMake(0, 20, 703, 470)];
    [scrollView setContentSize:CGSizeMake(703, 470)];
    
    [self.view addSubview:mFirstView];
//    [self onBtnGoClick:99];
    
    [self.navigationController setNavigationBarHidden:YES animated:NO];
}

-(NSArray *)setFilteredObjects
{
    indexes = [[NSMutableDictionary alloc]init];
    
    //type = 1;
    //  NSLog(@">>>>>>>>>>>>> Main Key :%@", key);
    NSSortDescriptor *descriptor = [[[NSSortDescriptor alloc] initWithKey:key ascending:YES] autorelease];
    allCigarsArray = [[allCigarsArray sortedArrayUsingDescriptors:[NSArray arrayWithObject:descriptor]]mutableCopy ];
    
    if(type == 6)
    {
        [indexes setObject:[[NSMutableArray alloc] init] forKey:@"$1 - $4"];
        [indexes setObject:[[NSMutableArray alloc] init] forKey:@"$4 - $6"];
        [indexes setObject:[[NSMutableArray alloc] init] forKey:@"$6 - $8"];
        [indexes setObject:[[NSMutableArray alloc] init] forKey:@"$8 - $10"];
        [indexes setObject:[[NSMutableArray alloc] init] forKey:@"$10 - $14"];
        [indexes setObject:[[NSMutableArray alloc] init] forKey:@"$14+"];
    } else if(type == 1)
    {
        [indexes setObject:[[NSMutableArray alloc] init] forKey:@"Full"];
        [indexes setObject:[[NSMutableArray alloc] init] forKey:@"Medium - Full"];
        [indexes setObject:[[NSMutableArray alloc] init] forKey:@"Mild - Medium"];
    }
    
    for(Cigar *cigar in allCigarsArray)
    {
        if ( [[cigar valueForKey:key] isEqualToString:@""] )
            [cigar setValue:@"0" forKey:key];
        
        NSString *firstLetter = [[cigar valueForKey:key] substringToIndex:1];
        
        if(type == 0 || type == 1 ||type == 2|| type == 3 || type == 4 || type == 6 || type == 7) firstLetter = [cigar valueForKey:key];
        if(type == 6 || type == 7) firstLetter = [firstLetter stringByReplacingOccurrencesOfString:@" (Online)" withString:@""];
        if(type == 6 || type == 7) firstLetter = [firstLetter stringByReplacingOccurrencesOfString:@"(Online)" withString:@""];
        if(type == 6 || type == 7) firstLetter = [firstLetter stringByReplacingOccurrencesOfString:@"Online)" withString:@""];
        if(type == 6 || type == 7) firstLetter = [firstLetter stringByReplacingOccurrencesOfString:@"(online)" withString:@""];
        if(type == 6 || type == 7) firstLetter = [firstLetter stringByReplacingOccurrencesOfString:@"$" withString:@""];
        if(type == 6 && [firstLetter floatValue] == 0) continue;
        
        NSMutableArray *existingArray = [[NSMutableArray alloc]init];
        //NSLog(firstLetter);
        // if an array already exists in the name index dictionary
        // simply add the element to it, otherwise create an array
        // and add it to the name index dictionary with the letter as the key
        if(type == 6){
            float firstLetterFloatval = [firstLetter floatValue];
            if(firstLetterFloatval < 4.0){
                existingArray = [indexes valueForKey:@"$1 - $4"];
                [existingArray addObject:cigar];
            } else if(firstLetterFloatval >= 4.0 && firstLetterFloatval < 6.0){
                existingArray = [indexes valueForKey:@"$4 - $6"];
                [existingArray addObject:cigar];
            } else if(firstLetterFloatval >= 6.0 && firstLetterFloatval < 8.0){
                existingArray = [indexes valueForKey:@"$6 - $8"];
                [existingArray addObject:cigar];
            } else if(firstLetterFloatval >= 8.0 && firstLetterFloatval < 10.0){
                existingArray = [indexes valueForKey:@"$8 - $10"];
                [existingArray addObject:cigar];
            } else if(firstLetterFloatval >= 10.0 && firstLetterFloatval <= 14.0){
                existingArray = [indexes valueForKey:@"$10 - $14"];
                [existingArray addObject:cigar];
            } else if(firstLetterFloatval >= 14.0){
                existingArray = [indexes valueForKey:@"$14+"];
                [existingArray addObject:cigar];
            }
        } else if(type == 1){
            if([firstLetter isEqualToString:@"Full"]){
                existingArray = [indexes valueForKey:@"Full"];
                [existingArray addObject:cigar];
            } else if([firstLetter isEqualToString:@"Full Bodied"]){
                existingArray = [indexes valueForKey:@"Full"];
                [existingArray addObject:cigar];
            } else if([firstLetter isEqualToString:@"Medium to Full"]){
                existingArray = [indexes valueForKey:@"Medium - Full"];
                [existingArray addObject:cigar];
            } else if([firstLetter isEqualToString:@"Medium"]){
                existingArray = [indexes valueForKey:@"Medium - Full"];
                [existingArray addObject:cigar];
                existingArray = [indexes valueForKey:@"Mild - Medium"];
                [existingArray addObject:cigar];
            } else if([firstLetter isEqualToString:@"Medium-Full"]){
                existingArray = [indexes valueForKey:@"Medium - Full"];
                [existingArray addObject:cigar];
            } else if([firstLetter isEqualToString:@"Medium/Full Bodied"]){
                existingArray = [indexes valueForKey:@"Medium - Full"];
                [existingArray addObject:cigar];
            } else if([firstLetter isEqualToString:@"Mild"]){
                existingArray = [indexes valueForKey:@"Mild - Medium"];
                [existingArray addObject:cigar];
            }/* else if([firstLetter isEqualToString:@"Mild to Medium"]){
              existingArray = [indexes valueForKey:@"Mild - Medium"];
              [existingArray addObject:cigar];
              } else if([firstLetter isEqualToString:@"Mild-Medium"]){
              existingArray = [indexes valueForKey:@"Mild - Medium"];
              [existingArray addObject:cigar];
              } else if([firstLetter isEqualToString:@"Mild/Medium"]){
              existingArray = [indexes valueForKey:@"Mild - Medium"];
              [existingArray addObject:cigar];
              }
              */
        } else {
            if ((existingArray = [indexes valueForKey:firstLetter]))
            {
                [existingArray addObject:cigar];
            } else {
                NSMutableArray *tempArray = [NSMutableArray array];
                [indexes setObject:tempArray forKey:firstLetter];
                [tempArray addObject:cigar];
            }
        }
    }
    
    [indexes removeObjectForKey:@"Not Available"];
    keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    
    if(type == 6){
        [keys release];
        keys = [[NSArray arrayWithObjects:@"$1 - $4", @"$4 - $6", @"$6 - $8", @"$8 - $10", @"$10 - $14", @"$14+", nil] retain];
    }
    else if(type == 1)
    {
        [keys release];
        keys = [[NSArray arrayWithObjects:@"Full", @"Medium - Full", @"Mild - Medium", nil] retain];
    }
    
    
    if([key isEqualToString:@"strength"])
    {
        strengthDict = [[NSMutableDictionary alloc] initWithDictionary:indexes];
        [strengthDict retain];
    }
    if([key isEqualToString:@"ring"])
    {
        ringDict = [[NSMutableDictionary alloc] initWithDictionary:indexes];
    }
    if([key isEqualToString:@"country"])
    {
        countryDict = [[NSMutableDictionary alloc] initWithDictionary:indexes];
    }
    if([key isEqualToString:@"wrapper"])
    {
        wrapperDict = [[NSMutableDictionary alloc] initWithDictionary:indexes];
    }
    if([key isEqualToString:@"length"])
    {
        lenDict = [[NSMutableDictionary alloc] initWithDictionary:indexes];
    }
    if([key isEqualToString:@"price"])
    {
        priceDict = [[NSMutableDictionary alloc] initWithDictionary:indexes];
    }
    
    
    return keys;
}

-(NSMutableDictionary *)setMainFilteredDictionary:(NSDictionary *)dict
{
    
    NSString *tempKey;
    tempKey = [dict objectForKey:@"mainFilter"];
    int temptype;
    temptype = [[dict objectForKey:@"id"] intValue];
    
    //temptype = 1;
    //   NSLog(@">>>>>>>>>>>>> Main Key :%@", tempKey);
    NSSortDescriptor *descriptor = [[[NSSortDescriptor alloc] initWithKey:tempKey ascending:YES] autorelease];
    allCigarsArray = [[allCigarsArray sortedArrayUsingDescriptors:[NSArray arrayWithObject:descriptor]]mutableCopy ];
    
    return tempindexes;
}

- (void)didDoneValueSelection:(int)Langid name:(NSString *)strName Picker:(Picker *)pickerController
{
    
    if ([strName isEqualToString:@""] || [strName isEqualToString:Nil]) {
        strName = @"Click To Filter";
    }else
        if(pickerController.tag == 10)
        {
            btnStrength.titleLabel.text = strName;
            
        }else
            if(pickerController.tag == 11)
            {
                btnRing.titleLabel.text = strName;
                
            }else
                if(pickerController.tag == 12)
                {
                    
                    btnCountry.titleLabel.text = strName;
                }else
                    if(pickerController.tag == 13)
                    {
                        btnWrapper.titleLabel.text = strName;
                    }else
                        if(pickerController.tag == 14)
                        {
                            btnLength.titleLabel.text = strName;
                        }else
                            if(pickerController.tag == 15)
                            {
                                btnPrice.titleLabel.text = strName;
                            }
    //
}

- (void)didChangeValue:(int)Langid name:(NSString *)strName
{
    
}

-(IBAction)onSearchClick:(id)sender
{
    // [SearchDictArray removeAllObjects];
    
    if ( filterArray !=  nil )
        [filterArray release];
        
    filterArray = [[NSMutableArray alloc] init];
    [filterArray addObjectsFromArray:allCigarsArray];
    
    if([btnStrength.titleLabel.text isEqualToString:@"Click To Filter"])
    {
        
    }
    else
    {
        int count = [filterArray count];
        
        for ( int index = count - 1; index >= 0; index -- ) {
            
            Cigar *cigar = [filterArray objectAtIndex:index];
            
            if ( cigar.isMyCigar == YES ) {
            
                if ( mFirstPageMiddleButton.mSelected == YES && ([cigar.strength isEqualToString:@"Mild"] || [cigar.strength isEqualToString:@"Medium"]) ) {
                    continue;
                }
                
                if ( mFirstPageMediumButton.mSelected == YES && ([cigar.strength isEqualToString:@"Medium"] || [cigar.strength isEqualToString:@"Medium To Full"]) ) {
                    continue;
                }
                
                if ( mFirstPageFullButton.mSelected == YES && [cigar.strength isEqualToString:@"Full"] ) {
                    continue;
                }

                
            }
            
            [filterArray removeObjectAtIndex:index];
        }
        
    }
    
    //================ Country
    
    if([countryName isEqualToString:@"Click To Filter"])
    {
        
    }
    else
    {
        int count = [filterArray count];
        
        for ( int index = count - 1; index >= 0; index -- ) {
            
            Cigar *cigar = [filterArray objectAtIndex:index];
            
            if ( cigar.isMyCigar == YES ) {

                if ( mSecondPageBrazilButton.mSelected == YES && [cigar.country isEqualToString:@"Brazil"] ) {
                    continue;
                }
                
                if ( mSecondPageBahamaButton.mSelected == YES && [cigar.country isEqualToString:@"Bahamas"]) {
                    continue;
                }
                
                if ( mSecondPageDominicButton.mSelected == YES && [cigar.country isEqualToString:@"Dominican Republic"] ) {
                    continue;
                }
                
                if ( mSecondPageHondrasButton.mSelected == YES && [cigar.country isEqualToString:@"Honduras"] ) {
                    continue;
                }
                
                if ( mSecondPageMexicoButton.mSelected == YES && [cigar.country isEqualToString:@"Mexico"] ) {
                    continue;
                }
                
                if ( mSecondPageNicaraguaButton.mSelected == YES && [cigar.country isEqualToString:@"Nicaragua"] ) {
                    continue;
                }
                
                if ( mSecondPageUsaButton.mSelected == YES && [cigar.country isEqualToString:@"Usa"] ) {
                    continue;
                }
                
            }
            
            
            [filterArray removeObjectAtIndex:index];
        }
        
    }
    
    
    if([btnRing.titleLabel.text isEqualToString:@"Click To Filter"])
    {
        
    }
    else
    {
        int count = [filterArray count];
        
        for ( int index = count - 1; index >= 0; index -- ) {
            
            Cigar *cigar = [filterArray objectAtIndex:index];
            
            if ( cigar.isMyCigar == YES ) {
            
                if ( mThirdPageOverThirtyButton.mSelected == YES && ( [cigar.ring floatValue] >= 20 && [cigar.ring floatValue] <= 40 ) ) {
                    continue;
                }
                
                if ( mThirdPageOverFourtyButton.mSelected == YES && ( [cigar.ring floatValue] >= 40 && [cigar.ring floatValue] <= 50 ) ) {
                    continue;
                }
                
                if ( mThirdPageOverFiftyButton.mSelected == YES && ( [cigar.ring floatValue] >= 50 && [cigar.ring floatValue] <= 58 ) ) {
                    continue;
                }
                
                if ( mThirdPageOverFiftySixButton.mSelected == YES && [cigar.ring floatValue] >= 58  ) {
                    continue;
                }
                
            }
            
            [filterArray removeObjectAtIndex:index];
        }
        
        
    }
    
    //    //============= Length
    
    if([btnLength.titleLabel.text isEqualToString:@"Click To Filter"])
    {
        
    }
    else
    {
        int count = [filterArray count];
        
        for ( int index = count - 1; index >= 0; index -- ) {
            
            Cigar *cigar = [filterArray objectAtIndex:index];
            
            if ( cigar.isMyCigar == YES ) {
            
                if ( mFourthPageOverThreeButton.mSelected == YES && ( [cigar.length floatValue] >= 1 && [cigar.length floatValue] < 4 ) )  {
                    continue;
                }
                
                if ( mFourthPageOverFourButton.mSelected == YES && ( [cigar.length floatValue] >= 4 && [cigar.length floatValue] <= 6 ) )  {
                    continue;
                }
                
                if ( mFourthPageOverFiveButton.mSelected == YES && [cigar.length floatValue] >= 6 )  {
                    continue;
                }

            }
            
            [filterArray removeObjectAtIndex:index];
        }

    }


    //============ Price
    
    
    if([btnPrice.titleLabel.text isEqualToString:@"Click To Filter"])
    {
        
    }
    else
    {
        int count = [filterArray count];
        
        for ( int index = count - 1; index >= 0; index -- ) {
            
            Cigar *cigar = [filterArray objectAtIndex:index];
            
            if ( cigar.isMyCigar == YES ) {

                if ( mFifthPageOverOneButton.mSelected == YES && ( ( [cigar.price floatValue] >= 0 && [cigar.price floatValue] <= 8 )  || [cigar.price isEqualToString:@"N/A"] ) ) {
                    continue;
                }
                
                if ( mFifthPageOverFourButton.mSelected == YES && ( ( [cigar.price floatValue] >= 8 && [cigar.price floatValue] <= 12 )   || [cigar.price isEqualToString:@"N/A"] ) ) {
                    continue;
                }
                
                if ( mFifthPageOverSixButton.mSelected == YES && ( ([cigar.price floatValue] >= 12 && [cigar.price floatValue] <= 20 ) || [cigar.price isEqualToString:@"N/A"]) ) {
                    continue;
                }
                
                if ( mFifthPageOverEightButton.mSelected == YES && ( [cigar.price floatValue] >= 20  || [cigar.price isEqualToString:@"N/A"] )) {
                    continue;
                }

            }
            
            [filterArray removeObjectAtIndex:index];
        }
        
    }
    
    int count = [filterArray count];
    
    for ( int index = count - 1; index >= 0; index -- ) {
        
        Cigar *cigar = [filterArray objectAtIndex:index];
        
        if ( cigar.isMyCigar == NO ) {
            [filterArray removeObject:cigar];
        }
    }
    
    if([filterArray count] > 0)
    {
        mFirstPageMiddleButton.mSelected = NO;
        [mFirstPageMiddleButton setImage:[UIImage imageNamed:@"mild.png"] forState:UIControlStateNormal];
        mFirstPageMediumButton.mSelected = NO;
        [mFirstPageMediumButton setImage:[UIImage imageNamed:@"medium.png"] forState:UIControlStateNormal];
        mFirstPageFullButton.mSelected = NO;
        [mFirstPageFullButton setImage:[UIImage imageNamed:@"full.png"] forState:UIControlStateNormal];
        
        mSecondPageBrazilButton.mSelected = NO;
        mSecondPageBahamaButton.mSelected = NO;
        mSecondPageDominicButton.mSelected = NO;
        mSecondPageHondrasButton.mSelected = NO;
        mSecondPageMexicoButton.mSelected = NO;
        mSecondPageNicaraguaButton.mSelected = NO;
        mSecondPageUsaButton.mSelected = NO;

        [mSecondPageBrazilButton setImage:[UIImage imageNamed:@"brazil.png"] forState:UIControlStateNormal];
        [mSecondPageBahamaButton setImage:[UIImage imageNamed:@"bahamas.png"] forState:UIControlStateNormal];
        [mSecondPageDominicButton setImage:[UIImage imageNamed:@"dominican.png"] forState:UIControlStateNormal];
        [mSecondPageHondrasButton setImage:[UIImage imageNamed:@"honduras.png"] forState:UIControlStateNormal];
        [mSecondPageMexicoButton setImage:[UIImage imageNamed:@"mexico.png"] forState:UIControlStateNormal];
        [mSecondPageNicaraguaButton setImage:[UIImage imageNamed:@"nicaragua.png"] forState:UIControlStateNormal];
        [mSecondPageUsaButton setImage:[UIImage imageNamed:@"USA.png"] forState:UIControlStateNormal];

        mThirdPageOverThirtyButton.mSelected = NO;
        mThirdPageOverFourtyButton.mSelected = NO;
        mThirdPageOverFiftyButton.mSelected = NO;
        mThirdPageOverFiftySixButton.mSelected = NO;
        mThirdPageOverSixtyButton.mSelected = NO;
        
        [mThirdPageOverThirtyButton setImage:[UIImage imageNamed:@"small.png"] forState:UIControlStateNormal];
        [mThirdPageOverFourtyButton setImage:[UIImage imageNamed:@"medium_rg.png"] forState:UIControlStateNormal];
        [mThirdPageOverFiftyButton setImage:[UIImage imageNamed:@"large.png"] forState:UIControlStateNormal];
        [mThirdPageOverFiftySixButton setImage:[UIImage imageNamed:@"xl.png"] forState:UIControlStateNormal];
        [mThirdPageOverSixtyButton setImage:[UIImage imageNamed:@"60+.png"] forState:UIControlStateNormal];
        
        mFourthPageOverThreeButton.mSelected = NO;
        mFourthPageOverFourButton.mSelected = NO;
        mFourthPageOverFiveButton.mSelected = NO;
        mFourthPageOverSixButton.mSelected = NO;
        mFourthPageOverSevenButton.mSelected = NO;
        
        [mFourthPageOverThreeButton setImage:[UIImage imageNamed:@"short_length.png"] forState:UIControlStateNormal];
        [mFourthPageOverFourButton setImage:[UIImage imageNamed:@"medium_length.png"] forState:UIControlStateNormal];
        [mFourthPageOverFiveButton setImage:[UIImage imageNamed:@"long_length.png"] forState:UIControlStateNormal];
        [mFourthPageOverSixButton setImage:[UIImage imageNamed:@"6_7.png"] forState:UIControlStateNormal];
        [mFourthPageOverSevenButton setImage:[UIImage imageNamed:@"7+.png"] forState:UIControlStateNormal];
        
        mFifthPageOverOneButton.mSelected = NO;
        mFifthPageOverFourButton.mSelected = NO;
        mFifthPageOverSixButton.mSelected = NO;
        mFifthPageOverEightButton.mSelected = NO;
        mFifthPageOverTenButton.mSelected = NO;
        mFifthPageOverFourteenButton.mSelected = NO;
        
        [mFifthPageOverOneButton setImage:[UIImage imageNamed:@"0-8.png"] forState:UIControlStateNormal];
        [mFifthPageOverFourButton setImage:[UIImage imageNamed:@"8-12.png"] forState:UIControlStateNormal];
        [mFifthPageOverSixButton setImage:[UIImage imageNamed:@"12-20.png"] forState:UIControlStateNormal];
        [mFifthPageOverEightButton setImage:[UIImage imageNamed:@"20+.png"] forState:UIControlStateNormal];
        [mFifthPageOverTenButton setImage:[UIImage imageNamed:@"10-14.png"] forState:UIControlStateNormal];
        [mFifthPageOverFourteenButton setImage:[UIImage imageNamed:@"14+.png"] forState:UIControlStateNormal];
        
        FilteredViewSearch *filterViewSearch = [[FilteredViewSearch alloc] initWithNibName:@"FilteredViewSearch" bundle:nil];
        
        filterViewSearch.cigars = filterArray;
        self.navigationItem.title=@"Back";
        [self.navigationController pushViewController:filterViewSearch animated:YES];
        [self.navigationController setNavigationBarHidden:NO animated:YES];
    }else
    {
        [appDelegate showAlertWithTitle:@"Message!!" message:@"No Cigar Found!!!"];
    }
    
}
-(void)setArrayData:(NSString *)strValue
{
    [filterArray addObjectsFromArray:[indexes objectForKey:strValue]];
}


-(IBAction)onBtnGoClick:(NSInteger)tag;
{
    //    UIButton *btn = sender;
    CGContextRef context = UIGraphicsGetCurrentContext();
    [UIView beginAnimations:nil context:context];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.4];
    [UIView commitAnimations];
    //    NSLog(@">>>>>>>>>>>>>>> Key values :%@", [self setFilteredObjects]);
    
    if( tag == 99)
    {
        type = 1;
        key = @"strength";
        // NSLog(@">>>>>>>>>>>>>>> button title :%@", btnRing.titleLabel.text);
        if ([btnRing.titleLabel.text isEqualToString:@""]) {
            btnRing.titleLabel.text = @"Click To Filter";
        }
        //        [objPickerStrength removeView];
        [objPickerRingGuage removeView];
        [objPickerPrice removeView];
        [objPickerCountry removeView];
        [objPickerWrapper removeView];
        [objPickerLength removeView];
        
        objPickerStrength.array = (NSMutableArray *)[self setFilteredObjects];
        [objPickerStrength presentView:0];
        
    }
    if( tag == 100)
    {
        type = 2;
        key = @"ring";
        objPickerRingGuage.array = (NSMutableArray *)[self setFilteredObjects];
        [objPickerRingGuage presentView:0];
        [objPickerStrength removeView];
        //        [objPickerRingGuage removeView];
        [objPickerPrice removeView];
        [objPickerCountry removeView];
        [objPickerWrapper removeView];
        [objPickerLength removeView];
        
    }
    if( tag == 101)
    {
        type = 3;
        key = @"country";
        objPickerCountry.array = (NSMutableArray *)[self setFilteredObjects];
        [objPickerCountry presentView:0];
        [objPickerStrength removeView];
        [objPickerRingGuage removeView];
        [objPickerPrice removeView];
        //        [objPickerCountry removeView];
        [objPickerWrapper removeView];
        [objPickerLength removeView];
        
    }
    if( tag == 102)
    {
        type = 4;
        key = @"wrapper";
        objPickerWrapper.array = (NSMutableArray *)[self setFilteredObjects];
        [objPickerWrapper presentView:0];
        [objPickerStrength removeView];
        [objPickerRingGuage removeView];
        [objPickerPrice removeView];
        [objPickerCountry removeView];
        //        [objPickerWrapper removeView];
        [objPickerLength removeView];
        
    }
    if( tag == 103)
    {
        type = 5;
        key = @"length";
        objPickerLength.array = (NSMutableArray *)[self setFilteredObjects];
        [objPickerLength presentView:0];
        [objPickerStrength removeView];
        [objPickerRingGuage removeView];
        [objPickerPrice removeView];
        [objPickerCountry removeView];
        [objPickerWrapper removeView];
        //[objPickerLength removeView];
        
    }
    if( tag == 104)
    {
        type = 6;
        key = @"price";
        objPickerPrice.array = (NSMutableArray *)[self setFilteredObjects];
        [objPickerPrice presentView:0];
        
        [objPickerStrength removeView];
        [objPickerRingGuage removeView];
        //   [objPickerPrice removeView];
        [objPickerCountry removeView];
        [objPickerWrapper removeView];
        [objPickerLength removeView];
        
    }
    
    if (btnStrength.titleLabel.text == nil) {
        btnStrength.titleLabel.text = @"Click To Filter";
    }
    if (btnRing.titleLabel.text == nil) {
        btnRing.titleLabel.text = @"Click To Filter";
    }
    if (btnWrapper.titleLabel.text == nil) {
        btnWrapper.titleLabel.text = @"Click To Filter";
    }
    if (btnPrice.titleLabel.text == nil) {
        btnPrice.titleLabel.text = @"Click To Filter";
    }
    if (btnLength.titleLabel.text == nil) {
        btnLength.titleLabel.text = @"Click To Filter";
    }
    if (countryName == nil) {
        countryName = @"Click To Filter";
    }
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [AppDelegate hideAdView];
    
    [self.navigationController setNavigationBarHidden:YES animated:animated];
}

-(void)viewDidAppear:(BOOL)animated
{
    [scrollView setFrame:CGRectMake(0, 0, 703, 704)];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (IBAction)nextButtonClicked:(id)sender
{
    UIButton *selectedButton = (UIButton *)sender;
    
    if ( selectedButton.tag == 1001) {
        [self.view addSubview:mSecondView];
//        [ self onBtnGoClick:101];
        [mFirstView removeFromSuperview];
    } else if ( selectedButton.tag == 1002 ) {
        [self.view addSubview:mThirdView];
//        [self onBtnGoClick:100];
        [mSecondView removeFromSuperview];
    } else if ( selectedButton.tag == 1003 ) {
        [self.view addSubview:mFourthView];
//        [self onBtnGoClick:103];
        [mThirdView removeFromSuperview];
    } else if ( selectedButton.tag == 1004 ) {
        [self.view addSubview:mFifthView];
//        [self onBtnGoClick:104];
        [mFourthView removeFromSuperview];
    }
}


- (IBAction)prevButtonClicked:(id)sender
{
    UIButton *selectedButton = (UIButton *)sender;
    
    if ( selectedButton.tag == 2002 ) {
        [self.view addSubview:mFirstView];
//        [self onBtnGoClick:99];
        [mSecondView removeFromSuperview];
    } else if ( selectedButton.tag == 2003 ) {
        [self.view addSubview:mSecondView];
//        [self onBtnGoClick:101];
        [mThirdView removeFromSuperview];
    } else if ( selectedButton.tag == 2004 ) {
        [self.view addSubview:mThirdView];
//        [self onBtnGoClick:100];
        [mFourthView removeFromSuperview];
    } else if ( selectedButton.tag == 2005 ) {
        [self.view addSubview:mFourthView];
//        [self onBtnGoClick:103];
        [mFifthView removeFromSuperview];
    }
    
}

- (IBAction)startOverButtonClicked:(id)sender
{
    // [SearchDictArray removeAllObjects];
    [self setValueInSearchField];
    [self onSearchClick:nil];
}

- (IBAction)firstPageFilterButtonClicked:(id)sender
{
    SelectedButton *button = (SelectedButton *)sender;
    
    switch (button.tag) {
        case 100: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"mild_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
            } else {
                [button setImage:[UIImage imageNamed:@"mild.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 101: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"medium_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
            } else {
                [button setImage:[UIImage imageNamed:@"medium.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 102: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"full_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"full.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        default:
            break;
    }
}

- (IBAction)secondPageFilterButtonClicked:(id)sender
{
    SelectedButton *button = (SelectedButton *)sender;
    
    switch (button.tag) {
        case 200: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"brazil_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"brazil.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 201: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"bahamas_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"bahamas.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 202: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"dominican_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"dominican.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 203: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"honduras_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"honduras.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 204: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"mexico_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"mexico.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 205: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"nicaragua_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"nicaragua.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 206: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"USA_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"USA.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        default:
            break;
    }
    
}

- (IBAction)thirdPageFilterButtonClicked:(id)sender
{
    SelectedButton *button = (SelectedButton *)sender;
    
    switch (button.tag) {
        case 300: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"small2.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"small.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 301: {
            
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"medium2_rg.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"medium_rg.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
            
        }
            break;
            
        case 302: {
            
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"large2.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"large.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
            
        }
            break;
            
        case 303: {
            
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"xl2.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"xl.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
            
            break;
            
        }
            
        case 304: {
            
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"60+_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"60+.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
            
        }
            
        default:
            break;
    }
    
}

- (IBAction)fourthPageFilterButtonClicked:(id)sender
{
    SelectedButton *button = (SelectedButton *)sender;
    
    switch (button.tag) {
        case 400: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"short2_length.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"short_length.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 401: {
            
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"medium2_length.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"medium_length.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
            
        }
            break;
            
        case 402: {
            
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"long2_length.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"long_length.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
            
        }
            break;
            
        case 403: {
            
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"6_7_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"6_7.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
            
            break;
            
        }
            
        case 404: {
            
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"7+_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"7+.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
            
        }
            break;
            
        default:
            break;
    }
}

- (IBAction)fifthPageFilterButtonClicked:(id)sender
{
    SelectedButton *button = (SelectedButton *)sender;
    
    switch (button.tag) {
        case 500: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"0-82.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
            } else {
                [button setImage:[UIImage imageNamed:@"0-8.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 501: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"8-122.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
            } else {
                [button setImage:[UIImage imageNamed:@"8-12.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 502: {
            
            if ( button.mSelected == NO ) {
                
                [button setImage:[UIImage imageNamed:@"12-202.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"12-20.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 503: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"20+2.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
            } else {
                [button setImage:[UIImage imageNamed:@"20+.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 504: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"10-14_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
            } else {
                [button setImage:[UIImage imageNamed:@"10-14.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        case 505: {
            if ( button.mSelected == NO ) {
                [button setImage:[UIImage imageNamed:@"14+_checked.png"] forState:UIControlStateNormal];
                button.mSelected = YES;
                
            } else {
                [button setImage:[UIImage imageNamed:@"14+.png"] forState:UIControlStateNormal];
                button.mSelected = NO;
            }
        }
            break;
            
        default:
            break;
    }
}

- (void) setValueInSearchField
{
    btnStrength.titleLabel.text = @"Click To Filter";
    countryName = @"Click To Filter";
    btnRing.titleLabel.text = @"Click To Filter";
    btnLength.titleLabel.text = @"Click To Filter";
    btnPrice.titleLabel.text = @"Click To Filter";
    
    if ( mFirstPageMediumButton.mSelected ) {
        btnStrength.titleLabel.text = @"Medium - Full";
    }
    
    if ( mFirstPageMiddleButton.mSelected ) {
        btnStrength.titleLabel.text = @"Mild - Medium";
    }
    
    if ( mFirstPageFullButton.mSelected == YES )
        btnStrength.titleLabel.text = @"Full";
    
    if ( mSecondPageBrazilButton.mSelected == YES )
        countryName = @"Brazil";
    
    if ( mSecondPageBahamaButton.mSelected == YES )
        countryName = @"Bahamas";
    
    if ( mSecondPageDominicButton.mSelected == YES )
        countryName = @"Dominican Republic";
    
    if ( mSecondPageHondrasButton.mSelected == YES )
        countryName = @"Honduras";
    
    if ( mSecondPageMexicoButton.mSelected == YES )
        countryName = @"Mexico";
    
    if ( mSecondPageNicaraguaButton.mSelected == YES )
        countryName = @"Nicaragua";
    
    if ( mSecondPageUsaButton.mSelected == YES )
        countryName = @"Usa";
    
    if ( mThirdPageOverThirtyButton.mSelected == YES )
        btnRing.titleLabel.text = @"30 - 40";
    
    if ( mThirdPageOverFourtyButton.mSelected == YES )
        btnRing.titleLabel.text = @"42 - 48";
    
    if ( mThirdPageOverFiftyButton.mSelected == YES )
        btnRing.titleLabel.text = @"50 - 54";
    
    if ( mThirdPageOverFiftySixButton.mSelected == YES )
        btnRing.titleLabel.text = @"56 - 58";
    
    if ( mThirdPageOverSixtyButton.mSelected == YES )
        btnRing.titleLabel.text = @"60+";
    
    if ( mFourthPageOverThreeButton.mSelected == YES )
        btnLength.titleLabel.text = @"3";
    
    if ( mFourthPageOverFourButton.mSelected == YES )
        btnLength.titleLabel.text = @"4";
    
    if ( mFourthPageOverFiveButton.mSelected == YES )
        btnLength.titleLabel.text = @"5";
    
    if ( mFourthPageOverSixButton.mSelected == YES )
        btnLength.titleLabel.text = @"6";
    
    if ( mFourthPageOverSevenButton.mSelected == YES )
        btnLength.titleLabel.text = @"7";
    
    if ( mFifthPageOverOneButton.mSelected == YES )
        btnPrice.titleLabel.text = @"$1 - $4";
    
    if ( mFifthPageOverFourButton.mSelected == YES )
        btnPrice.titleLabel.text = @"$4 - $6";
    
    if ( mFifthPageOverSixButton.mSelected == YES )
        btnPrice.titleLabel.text = @"$6 - $8";
    
    if ( mFifthPageOverEightButton.mSelected == YES )
        btnPrice.titleLabel.text = @"$8 - $10";
    
    if ( mFifthPageOverTenButton.mSelected == YES )
        btnPrice.titleLabel.text = @"$10 - $14";
    
    if ( mFifthPageOverFourteenButton.mSelected == YES )
        btnPrice.titleLabel.text = @"$14+";
    
}

@end
