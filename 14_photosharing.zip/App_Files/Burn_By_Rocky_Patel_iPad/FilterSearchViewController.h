//
//  FilterSearchViewController.h
//  CigarBoss
//
//  Created by Nitin on 16/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PickerDelegate.h"
#import "CategoryListViewController.h"
#import "SelectedButton.h"

@class Picker;
@interface FilterSearchViewController : UIViewController<PickerDelegate,UIPickerViewDelegate, SubstitutableDetailViewController>
{
    IBOutlet UIButton *btnGo;
    IBOutlet UIButton *btnSearch;
    
    IBOutlet UIScrollView *scrollView;
    
    Picker *objPickerStrength;
    
    Picker *objPickerRingGuage;
    
    Picker *objPickerCountry;
    
    Picker *objPickerWrapper;
    
    Picker *objPickerLength;
    
    Picker *objPickerPrice;
    
    NSMutableArray *allCigarsArray;
    
    IBOutlet UIButton *btnStrength;
    IBOutlet UIButton *btnRing;
    IBOutlet UIButton *btnLength;
    IBOutlet UIButton *btnPrice;
    IBOutlet UIButton *btnWrapper;
    IBOutlet UIButton *btnCountry;   
    

    IBOutlet UILabel *lblStrength;
    IBOutlet UILabel *lblRing;
    IBOutlet UILabel *lblLength;
    IBOutlet UILabel *lblPrice;
    IBOutlet UILabel *lblWrapper;
    IBOutlet UILabel *lblCountry;   
    
    NSString *key;
    int type;
    
	NSMutableDictionary *indexes;
	NSArray *keys;
    
    NSMutableDictionary *dictSearch;
    
    NSString *strengthText;
    NSString *countryText;
    NSString *lengthText;
    NSString *priceText;
    NSString *ringText;
    NSString *wrapperText;
    
    NSMutableArray *SearchDictArray;
    
    
    NSMutableDictionary *tempindexes;
    NSDictionary *brandsDictionary;
    
    NSMutableArray *arrStrengthFilterd;
    NSMutableArray *arrRingFilterd;
    NSMutableArray *arrWrapperFilterd;
    NSMutableArray *arrLengthFilterd;
    NSMutableArray *arrPriceFilterd;
    NSMutableArray *arrCountryFilterd;

    NSMutableArray *filterArray;
    
    
    NSMutableDictionary *strengthDict;
    NSMutableDictionary *ringDict;
    NSMutableDictionary *wrapperDict;

    NSMutableDictionary *lenDict;
    NSMutableDictionary *priceDict;
    NSMutableDictionary *countryDict;

    IBOutlet UIView     *mFirstView;
    IBOutlet UIView     *mSecondView;
    IBOutlet UIView     *mThirdView;
    IBOutlet UIView     *mFourthView;
    IBOutlet UIView     *mFifthView;
    
    IBOutlet SelectedButton   *mFirstPageMiddleButton;
    IBOutlet SelectedButton   *mFirstPageMediumButton;
    IBOutlet SelectedButton   *mFirstPageFullButton;
    
    IBOutlet SelectedButton   *mSecondPageBrazilButton;
    IBOutlet SelectedButton   *mSecondPageBahamaButton;
    IBOutlet SelectedButton   *mSecondPageDominicButton;
    IBOutlet SelectedButton   *mSecondPageHondrasButton;
    IBOutlet SelectedButton   *mSecondPageMexicoButton;
    IBOutlet SelectedButton   *mSecondPageNicaraguaButton;
    IBOutlet SelectedButton   *mSecondPageUsaButton;
    
    IBOutlet SelectedButton   *mThirdPageOverThirtyButton;
    IBOutlet SelectedButton   *mThirdPageOverFourtyButton;
    IBOutlet SelectedButton   *mThirdPageOverFiftyButton;
    IBOutlet SelectedButton   *mThirdPageOverFiftySixButton;
    IBOutlet SelectedButton   *mThirdPageOverSixtyButton;
    
    IBOutlet SelectedButton   *mFourthPageOverThreeButton;
    IBOutlet SelectedButton   *mFourthPageOverFourButton;
    IBOutlet SelectedButton   *mFourthPageOverFiveButton;
    IBOutlet SelectedButton   *mFourthPageOverSixButton;
    IBOutlet SelectedButton   *mFourthPageOverSevenButton;
    
    IBOutlet SelectedButton   *mFifthPageOverOneButton;
    IBOutlet SelectedButton   *mFifthPageOverFourButton;
    IBOutlet SelectedButton   *mFifthPageOverSixButton;
    IBOutlet SelectedButton   *mFifthPageOverEightButton;
    IBOutlet SelectedButton   *mFifthPageOverTenButton;
    IBOutlet SelectedButton   *mFifthPageOverFourteenButton;
    
    NSInteger            mCurrentPage;
    NSString             *countryName;
}

-(IBAction)onBtnGoClick:(NSInteger)tag;
-(NSArray *)setFilteredObjects;
-(IBAction)onSearchClick:(id)sender;
-(NSMutableDictionary *)setMainFilteredDictionary:(NSDictionary *)dict;

- (IBAction)nextButtonClicked:(id)sender;
- (IBAction)prevButtonClicked:(id)sender;
- (IBAction)firstPageFilterButtonClicked:(id)sender;
- (IBAction)secondPageFilterButtonClicked:(id)sender;
- (IBAction)thirdPageFilterButtonClicked:(id)sender;
- (IBAction)fourthPageFilterButtonClicked:(id)sender;
- (IBAction)fifthPageFilterButtonClicked:(id)sender;
- (IBAction)startOverButtonClicked:(id)sender;

@end
