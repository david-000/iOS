//
//  ChangeNewCigarViewController.h
//  CigarBoss
//
//  Created by Nitin on 17/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CategoryListViewController.h"

@class SearchResultsObject;
@class SearchingOverlayView;


@interface ChangeNewCigarViewController :UIViewController<UISearchBarDelegate, SubstitutableDetailViewController, UITableViewDelegate, UITableViewDataSource> {
	IBOutlet UITableView *mainTableView;
	IBOutlet UIView      *topView;
	NSString *brand;
	NSArray *cigars;
	id appDelegate;
    BOOL forNewCigars;
    NSMutableArray *storedArray;
    //=========
    IBOutlet UISearchBar *searchBar;
    UITableView *searchingTableView;
    NSMutableArray *matchedStates;
    
    NSMutableArray *keysArray;
    SearchResultsObject *searchResultsDataSource;
	SearchingOverlayView *searchingOverlayView;
    BOOL already;
    BOOL searching;
    
    NSMutableArray *arrCigarObj;
    
  	NSMutableDictionary *indexes;
    
    NSMutableDictionary *arrdist;
    NSMutableDictionary *arrdist2;
    NSMutableDictionary *dictKeys;
    NSArray *AllkeyIndexArray;
    NSMutableArray *AllTitleindexArray;
    
    
    NSMutableArray *arrydic;
}

@property (nonatomic, assign) NSString *brand;
@property (nonatomic, assign) NSArray *cigars; @property (nonatomic, assign) BOOL forNewCigars;
@property (nonatomic, retain)     NSMutableArray *keys;


-(void)makeArray;
- (void)refreshTableView;

@end
