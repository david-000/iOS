//
//  LastViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LastViewController : UIViewController {
    NSMutableDictionary *indexes;
    NSMutableArray *preferredShops;
    NSArray *keys;
    
    IBOutlet UITableView *mainTableView;
}

@property (nonatomic, retain) NSMutableArray *preferredShops;

@end
