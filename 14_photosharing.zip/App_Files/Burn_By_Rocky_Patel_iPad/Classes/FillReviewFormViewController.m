//
//  FillReviewFormViewController.m
//  CigarBoss
//
//  Created by Nitin on 20/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
#import <QuartzCore/QuartzCore.h>
#import "FillReviewFormViewController.h"
#import "MyClass.h"
#import "Cigar.h"
#import "TouchXML.h"
#import "CigarViewController.h"

#import "CigarBossAppDelegate.h"

CigarBossAppDelegate *appDelegate;

#define MAX_NUM_PADDING_CHARS 2
#define OUTPUT_LINE_LENGTH 64
#define INPUT_LINE_LENGTH ((OUTPUT_LINE_LENGTH / BASE64_UNIT_SIZE) * BINARY_UNIT_SIZE)
#define CR_LF_SIZE 2
#define xx 65
#define BINARY_UNIT_SIZE 3
#define BASE64_UNIT_SIZE 4



@implementation FillReviewFormViewController

@synthesize callingViewController;

@synthesize brandId,type,brandName;
@synthesize activityView;
CigarViewController *objCigarView;

#pragma mark for data64 algo methods

static unsigned char base64EncodeLookup[65] =
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static unsigned char base64DecodeLookup[256] =
{
	xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, 
	xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, 
	xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, 62, xx, xx, xx, 63, 
	52, 53, 54, 55, 56, 57, 58, 59, 60, 61, xx, xx, xx, xx, xx, xx, 
	xx,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 
	15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, xx, xx, xx, xx, xx, 
	xx, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 
	41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, xx, xx, xx, xx, xx, 
	xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, 
	xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, 
	xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, 
	xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, 
	xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, 
	xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, 
	xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, 
	xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, xx, 
};

-(NSString *)getStringFromImage:(UIImage *)image{
	
	if(image) {		
		//NSLog(@"getStringFromImage");
		NSData *dataObj = UIImageJPEGRepresentation(image,90);				
		return [dataObj base64Encoding];		
		//return [self base64EncodedString:dataObj];
	} else {		
		return @"";		
	}
}

- (NSString *)base64EncodedString:(NSData *)nsdata1
{
	//printf("\n inside the base64EncodedString");
	size_t outputLength;
	char *outputBuffer =
	NewBase64Encode([nsdata1 bytes], [nsdata1 length], true, &outputLength);
	
	NSString *result =	[[[NSString alloc]
						  initWithBytes:outputBuffer
						  length:outputLength
						  encoding:NSASCIIStringEncoding]
						 autorelease];
	free(outputBuffer);
	return result;
}

char *NewBase64Encode (
					   const void *buffer,
					   size_t length,
					   bool separateLines,
					   size_t *outputLength) {
	//printf("\n inside the newbase64encode");
	const unsigned char *inputBuffer = (const unsigned char *)buffer;
	
	size_t outputBufferSize =
	((length / BINARY_UNIT_SIZE)
	 + ((length % BINARY_UNIT_SIZE) ? 1 : 0))
	* BASE64_UNIT_SIZE;
	if (separateLines)
	{
		outputBufferSize +=
		(outputBufferSize / OUTPUT_LINE_LENGTH) * CR_LF_SIZE;
	}
	
	outputBufferSize += 1;
	
	char *outputBuffer = (char *)malloc(outputBufferSize);
	if (!outputBuffer)
	{
		return NULL;
	}
	
	size_t i = 0;
	size_t j = 0;
	const size_t lineLength = separateLines ? INPUT_LINE_LENGTH : length;
	size_t lineEnd = lineLength;
	
	while (true)
	{
		if (lineEnd > length)
		{
			lineEnd = length;
		}
		
		for (; i + BINARY_UNIT_SIZE - 1 < lineEnd; i += BINARY_UNIT_SIZE)
		{
			outputBuffer[j++] = base64EncodeLookup[(inputBuffer[i] & 0xFC) >> 2];
			outputBuffer[j++] = base64EncodeLookup[((inputBuffer[i] & 0x03) << 4)
												   | ((inputBuffer[i + 1] & 0xF0) >> 4)];
			outputBuffer[j++] = base64EncodeLookup[((inputBuffer[i + 1] & 0x0F) << 2)
												   | ((inputBuffer[i + 2] & 0xC0) >> 6)];
			outputBuffer[j++] = base64EncodeLookup[inputBuffer[i + 2] & 0x3F];
		}
		
		if (lineEnd == length)
		{
			break;
		}
		
		outputBuffer[j++] = '\r';
		outputBuffer[j++] = '\n';
		lineEnd += lineLength;
	}
	
	if (i + 1 < length)
	{
		//
		// Handle the single '=' case
		//
		outputBuffer[j++] = base64EncodeLookup[(inputBuffer[i] & 0xFC) >> 2];
		outputBuffer[j++] = base64EncodeLookup[((inputBuffer[i] & 0x03) << 4)
											   | ((inputBuffer[i + 1] & 0xF0) >> 4)];
		outputBuffer[j++] = base64EncodeLookup[(inputBuffer[i + 1] & 0x0F) << 2];
		outputBuffer[j++] =	'=';
	}
	else if (i < length)
	{
		//
		// Handle the double '=' case
		//
		outputBuffer[j++] = base64EncodeLookup[(inputBuffer[i] & 0xFC) >> 2];
		outputBuffer[j++] = base64EncodeLookup[(inputBuffer[i] & 0x03) << 4];
		outputBuffer[j++] = '=';
		outputBuffer[j++] = '=';
	}
	outputBuffer[j] = 0;
	
	//
	// Set the output length and return the buffer
	//
	if (outputLength)
	{
		*outputLength = j;
	}
	return outputBuffer;
}

-(void)setParent:(CigarViewController *)obj
{
    objCigarView = obj;
}

void *NewBase64Decode(
					  const char *inputBuffer,
					  size_t length,
					  size_t *outputLength)
{
	//NSLog(@"NewBase64Decode");
	if (length == -1)
	{
		length = strlen(inputBuffer);
	}
	
	size_t outputBufferSize = (length / BASE64_UNIT_SIZE) * BINARY_UNIT_SIZE;
	unsigned char *outputBuffer = (unsigned char *)malloc(outputBufferSize);
	
	size_t i = 0;
	size_t j = 0;
	while (i < length)
	{
		//
		// Accumulate 4 valid characters (ignore everything else)
		//
		unsigned char accumulated[BASE64_UNIT_SIZE];
		size_t accumulateIndex = 0;
		while (i < length)
		{
			unsigned char decode = base64DecodeLookup[inputBuffer[i++]];
			if (decode != xx)
			{
				accumulated[accumulateIndex] = decode;
				accumulateIndex++;
				
				if (accumulateIndex == BASE64_UNIT_SIZE)
				{
					break;
				}
			}
		}
		
		//
		// Store the 6 bits from each of the 4 characters as 3 bytes
		//
		outputBuffer[j] = (accumulated[0] << 2) | (accumulated[1] >> 4);
		outputBuffer[j + 1] = (accumulated[1] << 4) | (accumulated[2] >> 2);
		outputBuffer[j + 2] = (accumulated[2] << 6) | accumulated[3];
		j += accumulateIndex - 1;
	}
	
	if (outputLength)
	{
		*outputLength = j;
	}
	return outputBuffer;
}

-(NSData *)dataFromBase64String:(NSString *)aString
{
	//NSLog(@"dataFromBase64String");
	NSData *data = [aString dataUsingEncoding:NSASCIIStringEncoding];
	size_t outputLength;
	void *outputBuffer = NewBase64Decode([data bytes], [data length], &outputLength);
	NSData *result = [NSData dataWithBytes:outputBuffer length:outputLength];
	free(outputBuffer);
	return result;
}


#pragma mark -
#pragma mark path for Document Directory 

-(NSString *)applicationDocumentsDirectory {
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
	return basePath;
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


-(IBAction)closeView:(id)sender
{
//    [callingViewController viewDidLoad];
//    CGPoint offset = CGPointMake(0, 350);
//    [callingViewController.scrollView setContentOffset:offset];
    [self dismissModalViewControllerAnimated:YES]; 
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    appDelegate = (CigarBossAppDelegate *)[UIApplication sharedApplication].delegate;
    
    rateStarValue = 0;
    [scrollView setContentSize:CGSizeMake(704, 780)];
    [scrollView setScrollEnabled:YES];
    self.title = @"Review Form";
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 1024, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =self.title; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];
    txtRenote.layer.cornerRadius = 10.0;
    txtRenote.layer.borderWidth = 1.5;
    
    CGRect datePickerF = datePicker.frame;
    datePickerF.origin = CGPointMake(0, 754);
    datePicker.frame = datePickerF;
    NSDate *date = datePicker.date;
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
    
    datePickerLabel.text = [dateFormatter stringFromDate:date];
    [dateFormatter release];
    [self.view addSubview:datePicker];
    
    viewThatClosesDatEPicker = [[MyClass alloc] initWithFrame:CGRectMake(0, 0, 1024, 430)];
    viewThatClosesDatEPicker.backgroundColor = [UIColor blackColor];
    viewThatClosesDatEPicker.parentViewsViewController = self;
    [viewThatClosesDatEPicker setAlpha:0.0];
    
    
    [self.view addSubview:viewThatClosesDatEPicker];
    [self.view bringSubviewToFront:datePicker];
    
    [super viewDidLoad];
    
    
    // Do any additional setup after loading the view from its nib.
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(void)textViewDidBeginEditing:(UITextView *)textView
{
    if (textView.tag == 13) {
        [scrollView setContentOffset:CGPointMake(0, 250) animated:YES];
    }
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.tag == 7) {
        
        //        [scrollView setContentOffset:CGPointMake(0, 40) animated:YES];
    }
    if (textField.tag == 8) {
        
        [scrollView setContentOffset:CGPointMake(0, 125) animated:YES];
    }
    
    if (textField.tag == 9) {
        
        [scrollView setContentOffset:CGPointMake(0, 200) animated:YES];
    }
    
    if (textField.tag == 11) {
        [scrollView setContentOffset:CGPointMake(0, 350) animated:YES];
    }
    
}

-(void)textViewDidEndEditing:(UITextView *)textView {
    [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];    
}

-(void)textFieldDidEndEditing:(UITextField *)textField {
    [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    // Any new character added is passed in as the "text" parameter
    if ([text isEqualToString:@"\n"]) {
        // Be sure to test for equality using the "isEqualToString" message
        [txtRenote resignFirstResponder];
        [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
        return FALSE;
    }
    return TRUE;
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(IBAction)onStarButtonClick:(id)sender
{
    UIButton *btn = (UIButton *)sender;
    
    if(btn.tag == 111)
    {
        [s1 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s2 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        [s3 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        [s4 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        [s5 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        
        rateStarValue = 1;
    }
    if(btn.tag == 222)
    {
        [s1 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s2 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s3 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        [s4 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        [s5 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        
        rateStarValue = 2;
    }
    if(btn.tag == 333)
    {
        [s1 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s2 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s3 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s4 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        [s5 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        
        rateStarValue = 3;
    }
    if(btn.tag == 444)
    {
        [s1 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s2 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s3 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s4 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s5 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        
        rateStarValue = 4;
    }
    if(btn.tag == 555)
    {
        [s1 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s2 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s3 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s4 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        [s5 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        
        rateStarValue = 5;
    }
    
}

- (void)openDatePicker
{
    [txtstarRate resignFirstResponder];
    [txtPricePaid resignFirstResponder];
    [txtRenote resignFirstResponder];
    [txtHeadline resignFirstResponder];
    [txtRate resignFirstResponder];
    
    //    [UIView beginAnimations:nil context:Nil];
    //    [UIView setAnimationDuration:.5];
    //    CGRect datePickerF = datePicker.frame;
    //    datePickerF.origin = CGPointMake(0, 155);
    //    datePicker.frame = datePickerF;
    //    viewThatClosesDatEPicker.alpha = .2;
    //    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:Nil];
    [UIView setAnimationDuration:.5];
    CGRect datePickerF = datePicker.frame;
    datePickerF.origin = CGPointMake(0, 754-datePickerF.size.height);
    datePicker.frame = datePickerF;
    viewThatClosesDatEPicker.alpha = .2;
    [UIView commitAnimations];
    
}

- (void)closeDatePicker
{
    [UIView beginAnimations:nil context:Nil];
    [UIView setAnimationDuration:.5];
    CGRect datePickerF = datePicker.frame;
    datePickerF.origin = CGPointMake(0, 744);
    datePicker.frame = datePickerF;
    viewThatClosesDatEPicker.alpha = 0.0;
    NSDate *date = datePicker.date;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
    
    datePickerLabel.text = [dateFormatter stringFromDate:date];
    [dateFormatter release];
    [UIView commitAnimations];
}

- (IBAction)UploadImage{
    UIActionSheet *action = [[UIActionSheet alloc]initWithTitle:@"" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Take A Photo",@"Existing Photo",nil];//@"Clear Message Log" == 0 
    //    action.tag = 99;
    [action showInView:self.view];
    [action release];
    
}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    CustomImagePickerController * picker = [[CustomImagePickerController alloc] init];
    picker.delegate = self;
    if(buttonIndex==0)
    { 
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
            picker.sourceType = UIImagePickerControllerSourceTypeCamera;
            [self presentModalViewController:picker animated:YES];
        }
        else {
            
            UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Unavailable Source" message:@"This function needs a camera which is only available on the iPhone or iPod." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alert show];
            [alert release];
        }
    }
    else if(buttonIndex==1)
    {
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentModalViewController:picker animated:YES];
    }
    [actionSheet dismissWithClickedButtonIndex:2 animated:YES]; 
}
- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *capturedImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];

    [picker dismissModalViewControllerAnimated:YES];      
    
    imgUpload.image = capturedImage;
    
    [self waitUntillImageCaptured:capturedImage];
    //    
    //    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    //    NSString *documentsDirectory = [paths objectAtIndex:0];
    //    NSString *tempname = [NSString stringWithFormat:@"%@.png",type];
    //    NSString *savedImagePath = [documentsDirectory stringByAppendingPathComponent:tempname];
    ////    UIImage *image = imgUpload.image; // imageView is my image from camera
    //        
    //    UIImage *thumbnail;
    //    	
    //	UIImageView *mainImageView = [[UIImageView alloc] initWithImage:capturedImage];
    //	
    //	CGRect clippedRect = CGRectMake(0, 0, capturedImage.size.width,  capturedImage.size.height);
    //    
    //	UIGraphicsBeginImageContext(CGSizeMake(capturedImage.size.width, capturedImage.size.height));
    //	CGContextRef currentContext = UIGraphicsGetCurrentContext();
    //	
    //	CGContextClipToRect( currentContext, clippedRect);
    //	
    //	CGFloat scaleFactor = 1.0;
    //	//this will automatically scale any CGImage down/up to the required thumbnail side (length) when the CGImage gets drawn into the context on the next line of code
    //	CGContextScaleCTM(currentContext, scaleFactor, scaleFactor);
    //	
    //	[mainImageView.layer renderInContext:currentContext];
    //	
    //	thumbnail = UIGraphicsGetImageFromCurrentImageContext();
    //	
    //	UIGraphicsEndImageContext();
    //	NSData *imageData = UIImagePNGRepresentation(thumbnail);
    //	
    //	[imageData writeToFile:savedImagePath atomically:YES];
    //NSLog(@"------- Image Data = %@ ",imageData);
    
    //	NSString *imageName = [NSString stringWithFormat:@"%@.png", type];
    //	NSString *imagePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:imageName];
    //	[imagePath retain];
    
}


-(void)waitUntillImageCaptured:(UIImage *)originalImage
{
    UIImage *tempimg = originalImage;
    //UIImageWriteToSavedPhotosAlbum(tempimg,nil,nil,nil);
    
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	CGSize newSize = CGSizeMake(1024, 704);
    
  //  newSize = CGSizeMake(tempimg.size.width,tempimg.size.height);

	UIGraphicsBeginImageContext(newSize);
    
	[tempimg drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
	// Get the new image from the context
	UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
	// End the context
	UIGraphicsEndImageContext();
	
    NSString *strUser = [NSString stringWithFormat:@"%@",type];
    [strUser retain];
    NSString * strUserLocal = [strUser stringByAppendingString:@"temp.png"];
    
    NSString *imagePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:strUserLocal];
    UIImageView *tempView = [[UIImageView alloc] initWithImage:newImage];
    NSData *data = [NSData dataWithData:UIImagePNGRepresentation(tempView.image)];
    [tempView release];
    
    if(data != nil) {
        [CigarBossAppDelegate adSkipBackUpAttributeToItemAtURL:imagePath];
        [data writeToFile:imagePath atomically:YES];
    }
    else{
        [[NSFileManager defaultManager] removeItemAtPath:imagePath error:NULL];
    }
    
    [pool release];
    
    // [self performSelector:@selector(thumbWithSideOfLength:) withObject:strUser afterDelay:0.3];
}
#pragma mark -
#pragma mark make thumbnail image 
- (void)thumbWithSideOfLength:(NSString*)strImgName 
{        
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
	NSString *fullPathToThumbImage = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@temp.png", strImgName]];
    
	UIImage *thumbnail;
    
	UIImage *mainImage = [UIImage imageWithContentsOfFile:fullPathToThumbImage];
	
	UIImageView *mainImageView = [[UIImageView alloc] initWithImage:mainImage];
	
	CGRect clippedRect = CGRectMake(0, 0, mainImage.size.width,  mainImage.size.height);
	
    CGFloat scaleFactor = 0.8;
    
	UIGraphicsBeginImageContext(CGSizeMake(mainImage.size.width * scaleFactor, mainImage.size.height * scaleFactor));
	CGContextRef currentContext = UIGraphicsGetCurrentContext();
	
	CGContextClipToRect(currentContext, clippedRect);	
	
	CGContextScaleCTM(currentContext, scaleFactor, scaleFactor);
	
	[mainImageView.layer renderInContext:currentContext];
	
	thumbnail = UIGraphicsGetImageFromCurrentImageContext();
	
	UIGraphicsEndImageContext();
	NSData *imageData = UIImagePNGRepresentation(thumbnail);
    
    [CigarBossAppDelegate adSkipBackUpAttributeToItemAtURL:fullPathToThumbImage];
	[imageData writeToFile:fullPathToThumbImage atomically:YES];
    imgUpload.backgroundColor = [UIColor clearColor];
    [imgUpload imageFromImagePath:fullPathToThumbImage];
    
    [mainImageView release];
}


-(IBAction)CallWebService

{
    [appDelegate showLoadingView:self.view];
    UserMail = [NSUserDefaults standardUserDefaults];
    UserName = [NSUserDefaults standardUserDefaults];
    
    NSString *imagePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@temp.png", type]];
    
    NSString *imgString = [self getStringFromImage:[UIImage imageWithContentsOfFile:imagePath]];
    
	[imgString retain];
    
    NSString *mail = [UserMail objectForKey:@"isMail"]; 
    NSString *user = [UserName objectForKey:@"isUser"];
    
    
    
    if(datePickerLabel.text.length > 0 && txtHeadline.text.length > 0 && txtPricePaid.text.length > 0 && txtRenote.text.length)
    {    
        if([[NSString stringWithFormat:@"%d",rateStarValue] isEqualToString:@"0"])
        {
             [appDelegate hideLoadingView];
            UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"" message:@"Please fill star" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alert show];
            [alert release];
        }else{
            NSString *webService = [NSString stringWithFormat:soapAction];
            NSString *soapMessage = [NSString stringWithFormat:
                                     @"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                                     "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
                                     "<soap:Body>\n"
                                     "<cigarreview xmlns=\"%@\">\n"
                                     "<brandid>%@</brandid>"
                                     "<brandname>%@</brandname>"
                                     "<username>%@</username>"
                                     "<email>%@</email>"
                                     "<type>%@</type>"
                                     "<starate>%d</starate>"
                                     "<datesmoked>%@</datesmoked>"
                                     "<pricepaid>%@</pricepaid>"
                                     "<headline>%@</headline>"
                                     "<renote>%@</renote>"
                                     "<rate>%@</rate>"
                                     "<pic>%@</pic>"
                                     "</cigarreview>\n"
                                     "</soap:Body>\n"
                                     "</soap:Envelope>\n",xmlns,brandId,brandName,user,mail,type,rateStarValue,datePickerLabel.text,txtPricePaid.text,txtHeadline.text,txtRenote.text,txtRate.text,imgString
                                     ];
            
            //NSLog(@"soap msg : %@", soapMessage);
            NSURL *url = [NSURL URLWithString:webService];
            NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:60.0];
            NSString *msgLength = [NSString stringWithFormat:@"%d", [soapMessage length]];
            
            [theRequest addValue: @"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theRequest addValue: [webService stringByAppendingString:@"/cigarreview"] forHTTPHeaderField:@"SOAPAction"];
            [theRequest addValue: msgLength forHTTPHeaderField:@"Content-Length"];
            [theRequest setHTTPMethod:@"POST"];
            [theRequest setHTTPBody: [soapMessage dataUsingEncoding:NSUTF8StringEncoding]];
            
            NSURLConnection *theConnection = [[NSURLConnection alloc] initWithRequest:theRequest delegate:self];	
            if(theConnection) {
                //webData = [[NSMutableData data] retain];		
            }else {
                NSLog(@"The Connection is NULL");
            }
        }
    }else
    {
        [appDelegate hideLoadingView];
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"" message:@"Please fill all detial" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        
        [alert show];
        [alert release];
    }
}
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	webData = [[NSMutableData data] retain];
    // NSLog(@"data = %@ ",webData);
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	[webData appendData:data];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    //	[[ActivityIndicator sharedActivityIndicator]hide];
	NSLog(@"ERROR with theConenction %@",error);
    [appDelegate hideLoadingView];
	UIAlertView *connectionAlert = [[UIAlertView alloc] initWithTitle:@"Information !" message:@"Internet / Service Connection Error" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[connectionAlert show];
	[connectionAlert release];
	
	[connection release];
	[webData release];
	
	
	return;
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection {
    CXMLDocument *doc = [[[CXMLDocument alloc] initWithData:webData options:0 error:nil] autorelease];
   	NSArray *nodes1 = [doc nodesForXPath:@"//return" error:nil];
  
	for (CXMLElement *node in nodes1) {		
		
		for(int counter = 0; counter < [node childCount]; counter++) {		    
            
			if ([[[node childAtIndex:counter] name] isEqualToString:@"text"]) {					
				NSString *str = [[node childAtIndex:counter] stringValue];			
				
				if ([str isEqualToString:@"Success"]) {
                    
					UIAlertView *connectionAlert = [[UIAlertView alloc] initWithTitle:@"Message !" message:@"Thanks for your review! \n It will be posted shortly." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                    [connectionAlert show];
                    [connectionAlert release];
				}
                else if ([str isEqualToString:@"You Are Already Reviewed It"]) {
                    
					UIAlertView *connectionAlert = [[UIAlertView alloc] initWithTitle:@"Message !" message:@"You Are Already Reviewed It." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                    [connectionAlert show];
                    [connectionAlert release];
				}
                // [self.navigationController popToViewController:objCigarView animated:YES];
                //   [callingViewController viewDidLoad];
                //    CGPoint offset = CGPointMake(0, 350);
                //  [callingViewController.scrollView setContentOffset:offset];
                [self dismissModalViewControllerAnimated:YES];
                
			}
		}
	}
    [appDelegate hideLoadingView];
	[connection release];
	[webData release];
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
