//
//  MyWishList.h
//  CigarBoss
//
//  Created by Chintan on 13/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyWishList : UIViewController
{
    
    IBOutlet UITableView *mainTableView;
    NSMutableArray *cigars;
    NSArray *keys;
    NSMutableDictionary *indexes;
    
    BOOL forShops;
    IBOutlet UISegmentedControl *forShopsControl;
    
    BOOL loaded;
    IBOutlet UIButton *btnEdit;
    
    NSMutableArray *arrBlank;
    
    IBOutlet UIToolbar *toolBar;
}

@property (nonatomic, retain) NSMutableArray        *cigars;
@property (nonatomic, retain) NSMutableArray        *wishList;


- (IBAction)changeStuff:(id)sender;
-(IBAction)onAddbtnClick:(id)sender;
- (IBAction)onbtnEditClick:(id)sender;
@end
