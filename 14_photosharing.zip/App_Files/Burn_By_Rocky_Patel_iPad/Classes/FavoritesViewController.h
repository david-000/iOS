//
//  FavoritesViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FavoritesViewController : UIViewController {
	IBOutlet UITableView *mainTableView;
	NSMutableArray *cigars;
	NSArray *keys;
	NSMutableDictionary *indexes;
	
	BOOL forShops;
    IBOutlet UISegmentedControl *forShopsControl;
	
	BOOL loaded;
}

- (IBAction)changeStuff:(id)sender;

@end
