//
//  LargePhotoViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageViewiPhone.h"

@interface LargePhotoViewController : UIViewController <UIScrollViewDelegate> {
	IBOutlet UIImageView *imageView;
	UIImage *image;
    UIScrollView *scrollView;
    IBOutlet UIToolbar *toolBar;
	
	IBOutlet UIBarButtonItem *backBarButton;
	IBOutlet UIBarButtonItem *forwardBarButton;
	IBOutlet UIBarButtonItem *sharebtn;	
	IBOutlet UIBarButtonItem *commentbtn;
	IBOutlet UIBarButtonItem *descbtn;
	NSMutableArray *viewControllers;
	
	NSString *pageControlUsed;
	
	NSMutableArray *arrData;
	
	int currentPage;
	
	int height;
	int width;
    
	NSString *flagShow;
	
	NSTimer *menuHideTimer;
    AsyncImageViewiPhone *controller;
    
    NSString *brandName;
}

@property (nonatomic, assign ) UIImage *image;
@property (nonatomic, retain)  NSString *brandName;

@property (nonatomic, retain) NSMutableArray *viewControllers;
@property (nonatomic, assign) int currentPage;
@property (nonatomic, retain) NSMutableArray *arrData;

@property (nonatomic, retain) NSString *flagShow;

-(IBAction) onClickBackBarButton;
-(IBAction) onClickForwardBarButton;
-(IBAction) onClickShareButton;
-(IBAction) onClickCommentButton;
-(IBAction) onClickDescButton;

-(void) setParent:(id)sender;
-(void) setBean:(id)sender;
-(void)makingViewControllerArray;
-(void) changePageManually;
- (void)loadScrollViewWithPage:(int)page;
-(void) unloadImages:(int)page;
-(void) hideMenus;
-(void) showMenus;
-(void) setToolBar;
-(void) setToolBar;
-(NSString *)applicationDocumentsDirectory;
-(void)DeleteAllImages;


@end
