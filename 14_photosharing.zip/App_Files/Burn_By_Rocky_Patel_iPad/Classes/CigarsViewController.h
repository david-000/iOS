//
//  CigarsViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSString (trimLeadingWhitespace)
-(NSString*)stringByTrimmingLeadingWhitespace;
@end

@implementation NSString (trimLeadingWhitespace)
-(NSString*)stringByTrimmingLeadingWhitespace {
    NSInteger i = 0;
	
    while ([[NSCharacterSet whitespaceCharacterSet] characterIsMember:[self characterAtIndex:i]]) {
        i++;
    }
	
	while([[NSCharacterSet newlineCharacterSet] characterIsMember:[self characterAtIndex:i]]){
		i++;
	}
    return [self substringFromIndex:i];
}
@end

@class SearchResultsObject;
@class SearchingOverlayView;

@interface CigarsViewController : UIViewController<UISearchBarDelegate> {
	IBOutlet UITableView *mainTableView;
	
	NSString *brand;
	NSMutableArray *cigars;
	id appDelegate;
    BOOL forNewCigars;
    NSMutableArray *storedArray;
    //=========
    IBOutlet UISearchBar *searchBar;
    UITableView *searchingTableView;
    NSMutableArray *matchedStates;
    
    NSMutableArray *keysArray;
    SearchResultsObject *searchResultsDataSource;
	SearchingOverlayView *searchingOverlayView;
    BOOL already;
    BOOL searching;
    
    NSMutableArray *arrCigarObj;
  	NSMutableDictionary *indexes;
    NSMutableDictionary *arrdist;
        NSMutableDictionary *arrdist2;
    NSMutableDictionary *dictKeys;
    NSArray *AllkeyIndexArray;
    NSMutableArray *AllTitleindexArray;
    
    NSMutableArray *arrydic;
}

@property (nonatomic, assign) NSString *brand;
@property (nonatomic, assign) NSMutableArray *cigars;
@property (nonatomic, assign) BOOL forNewCigars;
@property (nonatomic, retain)     NSMutableArray *keys;
@property (nonatomic) NSInteger mShowType;

-(void)makeArray;

@end
