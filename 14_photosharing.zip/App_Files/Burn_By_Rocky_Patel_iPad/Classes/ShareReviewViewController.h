//
//  ShareReviewViewController.h
//  CigarBoss
//
//  Created by Nitin on 20/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

//#define soapAction @"http://logisticinfotech.com/client/webservicecigar/soap-server.php"
//#define xmlns @"http://logisticinfotech.com/soap/cigarboss"



#define soapAction @"http://cigarboss.co/webservice/soap-server.php"

#define xmlns @"http://cigarboss.co/soap/cigarboss"


@interface ShareReviewViewController : UIViewController<UITextFieldDelegate>
{
    IBOutlet UITextField *txtMail;
    IBOutlet UITextField *txtPass;
    IBOutlet UIButton *btnLogin;
    NSUserDefaults *userDefault;
    NSUserDefaults *userMail;
    NSUserDefaults *userName;
    
    NSString *brandId;
    NSString *type;
    NSString *brandName;
    
    NSMutableData *webData;
	NSXMLParser *xmlParser;
	NSString *element;
}
@property (nonatomic, retain) NSString *brandId;
@property (nonatomic,retain) NSString *type;
@property (nonatomic,retain) NSString *brandName;
-(IBAction)onBtnLoginClick:(id)sender;
-(void)setParent:(id)sender;


@end
