//
//  FavoritesViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MyHumidorsViewController : UIViewController {
	IBOutlet UITableView *mainTableView;

    IBOutlet UIView *innerView1;
    IBOutlet UIButton *EditButton;
    
	NSMutableArray *cigars;
	NSArray *keys;
	NSMutableDictionary *indexes;
	
	BOOL forShops;
    IBOutlet UISegmentedControl *forShopsControl;
	
	BOOL loaded;
    IBOutlet UIView *myview;
    
}

@property (nonatomic, retain) NSMutableArray        *cigars;
@property (nonatomic, retain) NSMutableArray        *humidorArray;


- (IBAction)changeStuff:(id)sender;
-(IBAction)onAddbtnClick:(id)sender;
- (IBAction)onbtnEditClick:(id)sender;
@end
