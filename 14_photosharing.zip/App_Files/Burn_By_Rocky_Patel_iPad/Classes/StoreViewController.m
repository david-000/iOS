//
//  CigarViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "StoreViewController.h"
#import "NSAttributedString+Attributes.h"
#import "OHAttributedLabel.h"
#import "LargePhotoViewController.h"
#import "RateStarView.h"
#import "WebViewController.h"
#import <CoreLocation/CoreLocation.h>
#import <MessageUI/MessageUI.h>
#import "TSMiniWebBrowser.h"

@implementation StoreViewController

@synthesize newCigar;
@synthesize cigar;
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */

- (void)sendEMail
{
    if ([MFMailComposeViewController canSendMail]) {
        
        MFMailComposeViewController *mailViewController = [[MFMailComposeViewController alloc] init];
        mailViewController.mailComposeDelegate = self;
        [mailViewController setToRecipients:[NSArray arrayWithObject:[newCigar objectForKey:@"email"]]];
        
        [self presentModalViewController:mailViewController animated:YES];
        [mailViewController release];
    }
}

-(void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error :(NSError*)error {
    
    [self dismissModalViewControllerAnimated:YES];
}

- (void)web
{
    NSString *website = [newCigar objectForKey:@"website"];
    if([website rangeOfString:@"http://"].location == NSNotFound){
        website = [NSString stringWithFormat:@"http://%@", website];
    }
    WebViewController *w = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
    w.url = [NSURL URLWithString:website];
    w.title = @"";

    [self presentModalViewController:w animated:YES];
    
    
    //TSMiniWebBrowser *webBrowser = [[[TSMiniWebBrowser alloc] initWithUrl:[NSURL URLWithString:website]] autorelease];
    //[self presentModalViewController:webBrowser animated:YES];
    //[webBrowser release];
}

- (void)call
{
    NSString *phone = [newCigar objectForKey:@"phone"];
    NSString *temp;
    temp = phone;
    phone = [phone stringByReplacingOccurrencesOfString:@" " withString:@""];
    //[temp release];
    temp = phone;
    phone = [phone stringByReplacingOccurrencesOfString:@"(" withString:@""];
    // [temp release];
    temp = phone;
    phone = [phone stringByReplacingOccurrencesOfString:@")" withString:@""];
    // [temp release];
    temp = phone;
    phone = [phone stringByReplacingOccurrencesOfString:@"-" withString:@""];
    //[temp release];
    temp = nil;
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@", phone]]];
}

- (void)directions
{
    appDelegate = [[UIApplication sharedApplication] delegate];
    CLLocationCoordinate2D loc = [appDelegate userLocation];
    
    NSString *urlString = [NSString stringWithFormat:@"http://maps.google.com/maps?daddr=%@2&saddr=%f,%f", [[newCigar objectForKey:@"location"] stringByReplacingOccurrencesOfString:@" " withString:@""], loc.latitude, loc.longitude];
   // NSLog(urlString);
    [[UIApplication sharedApplication] openURL: [NSURL URLWithString: urlString]];
}


- (void)ClickEventOnImage:(id)sender
{
    LargePhotoViewController *l = [[LargePhotoViewController alloc] initWithNibName:@"LargePhotoViewController" bundle:nil];
    l.image = [[sender view] image];
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:l animated:YES];

}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
    
    if ( AppDelegate.adStatus == true )
        scrollView.frame = CGRectMake(0, 0, 703, 614);
    else
        scrollView.frame = CGRectMake(0, 0, 703, 704);
    
	rView.forShops = YES;
	rView.shop = newCigar;
	
	//scrollView.frame = CGRectMake(0, 44, 320, scrollView.frame.size.height);
	for(UILabel *lbl in [scrollView subviews]){
		if(![lbl isKindOfClass:[UILabel class]]) continue;
		//lbl.textColor = [UIColor lightGrayColor];
		//if(white == NO){
        if(![lbl.text isEqualToString:@"tap address for directions"])
            lbl.textColor = [UIColor whiteColor];
		//white = YES;
		//} else white = NO;
		lbl.shadowColor = [UIColor colorWithWhite:.2 alpha:.6];
		lbl.shadowOffset = CGSizeMake(0, -1.0);
		
		
		//if(lbl.tag == 55) lbl.textColor = [UIColor whiteColor];
		//if(lbl.tag == 56) lbl.textColor = [UIColor lightGrayColor];
	}
    
    NSMutableArray *ratingA = [[[UIApplication sharedApplication] delegate] findFavoriteShop:[newCigar objectForKey:@"id"]];
	[ratingsView setRating:[[ratingA objectAtIndex:1] intValue]];
    
     rView.test = [[ratingA objectAtIndex:1] intValue];
    
    tLabel.text = [newCigar objectForKey:@"name"];
	self.title = @"Shops";
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 703, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =self.title; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];

	typeLabel.text = [newCigar objectForKey:@"name"];
	brandLabel.text = [newCigar objectForKey:@"address"];
    @try {
        NSString *address = [newCigar objectForKey:@"address"];
        //address = [address stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSArray *components = [address componentsSeparatedByString:@","];
        NSString *first = [components objectAtIndex:0];
        NSString *city = [[components objectAtIndex:1] stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSString *stateAndZip = [components objectAtIndex:2];
        brandLabel.text = [NSString stringWithFormat:@"%@\n%@, %@", first, city, stateAndZip];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
	lengthLabel.text = [newCigar objectForKey:@"email"];
	ringLabel.text = [newCigar objectForKey:@"website"];
	strengthLabel.text = [newCigar objectForKey:@"store_hours"];
	descriptionLabel.text = [newCigar objectForKey:@"description"];
	countryLabel.text = [newCigar objectForKey:@"sales_line"];
	cigarLabel.text =[newCigar objectForKey:@"phone"];
	
    
    
    
	photos = [[newCigar objectForKey:@"photos"] componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]];
	NSMutableArray *newP = [[NSMutableArray alloc] init];
	for(NSString *string in photos){
		if([string length] > 0){
			[newP addObject:string];
		}
	}
	photos = newP;
	@try {
		NSString *url1 = [photos objectAtIndex:0];
		if([url1 rangeOfString:@"http://"].location == NSNotFound){
			url1 = [@"http://" stringByAppendingString:[photos objectAtIndex:0]];
		}
		[photo1 setAlpha:1.0];
        photo1.tag = 0;
        photo1.isHeadThumb = NO;
		[photo1 setBackgroundColor:[UIColor clearColor]];
		[photo1 loadImageFromURL:[NSURL URLWithString:url1]];
		UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc]
												 initWithTarget:self action:@selector(ClickEventOnImage:)];
        [tapRecognizer setNumberOfTouchesRequired:1];
        [tapRecognizer setDelegate:self];
        //Don't forget to set the userInteractionEnabled to YES, by default It's NO.
        photo1.userInteractionEnabled = YES;
        [photo1 addGestureRecognizer:tapRecognizer];
	}
	@catch (NSException * e) {
	}
	
	@try {
		NSString *url1 = [photos objectAtIndex:1];
		if([url1 rangeOfString:@"http://"].location == NSNotFound){
			url1 = [@"http://" stringByAppendingString:[photos objectAtIndex:1]];
		}
		[photo2 setAlpha:1.0];
        photo2.tag = 1;
        photo2.isHeadThumb = NO;
		[photo2 setBackgroundColor:[UIColor clearColor]];
		[photo2 loadImageFromURL:[NSURL URLWithString:url1]];
		UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc]
												 initWithTarget:self action:@selector(ClickEventOnImage:)];
        [tapRecognizer setNumberOfTouchesRequired:1];
        [tapRecognizer setDelegate:self];
        //Don't forget to set the userInteractionEnabled to YES, by default It's NO.
        photo2.userInteractionEnabled = YES;
        [photo2 addGestureRecognizer:tapRecognizer];
	}
	@catch (NSException * e) {
	}
	
	@try {
		NSString *url1 = [photos objectAtIndex:2];
		if([url1 rangeOfString:@"http://"].location == NSNotFound){
			url1 = [@"http://" stringByAppendingString:[photos objectAtIndex:2]];
		}
		[photo3 setAlpha:1.0];
        photo3.isHeadThumb = NO;
        photo3.tag = 2;
		[photo3 setBackgroundColor:[UIColor clearColor]];
		[photo3 loadImageFromURL:[NSURL URLWithString:url1]];
		UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc]
												 initWithTarget:self action:@selector(ClickEventOnImage:)];
        [tapRecognizer setNumberOfTouchesRequired:1];
        [tapRecognizer setDelegate:self];
        //Don't forget to set the userInteractionEnabled to YES, by default It's NO.
        photo3.userInteractionEnabled = YES;
        [photo3 addGestureRecognizer:tapRecognizer];
	}
	@catch (NSException * e) {
	}
    
	@try {
		NSString *url1 = [photos objectAtIndex:3];
		if([url1 rangeOfString:@"http://"].location == NSNotFound){
			url1 = [@"http://" stringByAppendingString:[photos objectAtIndex:3]];
		}
		[photo4 setAlpha:1.0];
        photo4.tag = 3;
        photo4.isHeadThumb = NO;
		[photo4 setBackgroundColor:[UIColor clearColor]];
		[photo4 loadImageFromURL:[NSURL URLWithString:url1]];
		UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc]
												 initWithTarget:self action:@selector(ClickEventOnImage:)];
        [tapRecognizer setNumberOfTouchesRequired:1];
        [tapRecognizer setDelegate:self];
        //Don't forget to set the userInteractionEnabled to YES, by default It's NO.
        photo4.userInteractionEnabled = YES;
        [photo4 
		 addGestureRecognizer:tapRecognizer];
	}
	@catch (NSException * e) {
	}
	
	CGSize maxSize = CGSizeMake(600, MAXFLOAT);
	CGSize newSize = [descriptionLabel.text sizeWithFont:descriptionLabel.font
									   constrainedToSize:maxSize
										   lineBreakMode:descriptionLabel.lineBreakMode];
	
	descriptionLabel.frame = CGRectMake(descriptionLabel.frame.origin.x,
										descriptionLabel.frame.origin.y+28- 204,
										newSize.width,
										newSize.height);
    CGRect frame2 = descLabel.frame;
    frame2.origin.y -= 200;
    descLabel.frame = frame2;
    
    CGRect frame111 = photo1.frame;
    frame111.origin.y = descriptionLabel.frame.origin.y + descriptionLabel.frame.size.height + 30;
    photo1.frame = frame111;
    
    frame111 = photo2.frame;
    frame111.origin.y = descriptionLabel.frame.origin.y + descriptionLabel.frame.size.height + 30;
    photo2.frame = frame111;
    
    frame111 = photo3.frame;
    frame111.origin.y = descriptionLabel.frame.origin.y + descriptionLabel.frame.size.height + 30 + 200;
    photo3.frame = frame111;
    
    frame111 = photo4.frame;
    frame111.origin.y = descriptionLabel.frame.origin.y + descriptionLabel.frame.size.height + 30 + 200;
    photo4.frame = frame111;
	
	float scrollViewHeight = 800 + newSize.height;
	[scrollView setContentSize:CGSizeMake(703, scrollViewHeight+120)];
	
    NSString *imagePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png",[newCigar objectForKey:@"name"]]];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:imagePath] == YES) {
        imageView.isThumb = YES;
        [imageView imageFromImagePath:imagePath];
    }
    else 
    {
        
        NSString *url = [newCigar objectForKey:@"logo"];
        NSString *str = [newCigar objectForKey:@"name"];
        if([url rangeOfString:@"http://"].location == NSNotFound){
            url = [@"http://" stringByAppendingString:[newCigar objectForKey:@"logo"]];
        }
        
        [imageView setAlpha:1.0]; [imageView setBackgroundColor:[UIColor clearColor]];
        imageView.tag = 100;
//        [imageView loadImageFromURL:[NSURL URLWithString:url]];
        [imageView loadImageFromURL:[NSURL URLWithString:url] : str]; 
    }
	/*OHAttributedLabel *reviewsLabel = [[OHAttributedLabel alloc] initWithFrame:CGRectMake(16, scrollViewHeight-5, 287, 20)];
     reviewsLabel.numberOfLines = 0;
     reviewsLabel.font = descriptionLabel.font;
     NSMutableString *finalReviewsString = [[NSMutableString alloc] init];
     int i = 0;
     reviewsLabel.lineBreakMode = descriptionLabel.lineBreakMode;
     // for those calls we don't specify a range so it affects the whole string
     //[attrStr setFont:[UIFont fontWithName:@"Copperplate" size:18]];
     //[attrStr setTextColor:[UIColor grayColor]];
     
     // now we only change the color of "Hello"
     //[attrStr setTextColor:[UIColor redColor] range:NSMakeRange(0,5)];	
     
     /**(2)** Affect the NSAttributedString to the OHAttributedLabel *******/
	//label1.attributedText = attrStr;
	// and add a link to the "share your food!" text
	/*for(NSDictionary *review in cigar.reviews){
     if(i == 0){
     [finalReviewsString appendString:[[review allKeys] objectAtIndex:0]];
     } else {
     [finalReviewsString appendFormat:@"\n\n%@", [[review allKeys] objectAtIndex:0]];
     }
     
     i++;
     }
     reviewsLabel.backgroundColor = [UIColor clearColor];
     reviewLabel.backgroundColor = [UIColor clearColor];
     //reviewsLabel.text = finalReviewsString;
     //NSMutableAttributedString *attrStr = [NSMutableAttributedString attributedStringWithString:[finalReviewsString copy]];
     //[attrStr setFont:reviewsLabel.font];
     //[attrStr setTextColor:reviewsLabel.textColor];
     //reviewsLabel.attributedText = attrStr;
     reviewsLabel.text = finalReviewsString;
     //[finalReviewsString release];
     for(NSDictionary *review in cigar.reviews){
     [reviewsLabel addCustomLink:[NSURL URLWithString:[[review allValues] objectAtIndex:0]] inRange:[finalReviewsString rangeOfString:[[review allKeys] objectAtIndex:0]]];
     
     }
     [finalReviewsString release];
     newSize = [reviewsLabel.text sizeWithFont:reviewsLabel.font
     constrainedToSize:maxSize
     lineBreakMode:reviewsLabel.lineBreakMode];
     reviewsLabel.frame = CGRectMake(16, 5+scrollViewHeight, 287, newSize.height);
     scrollViewHeight += 5 + newSize.height+7;
     [scrollView addSubview:reviewsLabel];
     [scrollView setContentSize:CGSizeMake(320, scrollViewHeight+20)];
     
     //BOOL white = NO;
     for(UILabel *lbl in [scrollView subviews]){
     if(![lbl isKindOfClass:[UILabel class]]) continue;
     //lbl.textColor = [UIColor lightGrayColor];
     //if(white == NO){
     lbl.textColor = [UIColor whiteColor];
     //white = YES;
     //} else white = NO;
     lbl.shadowColor = [UIColor colorWithWhite:.2 alpha:.6];
     lbl.shadowOffset = CGSizeMake(0, -1.0);
     
     
     //if(lbl.tag == 55) lbl.textColor = [UIColor whiteColor];
     //if(lbl.tag == 56) lbl.textColor = [UIColor lightGrayColor];
     }
     
     reviewLabel.textColor = [UIColor whiteColor];
     
     NSString *url = cigar.pictureURL;
     if([url rangeOfString:@"http://"].location == NSNotFound){
     url = [@"http://" stringByAppendingString:cigar.pictureURL];
     }
     [imageView setAlpha:1.0]; [imageView setBackgroundColor:[UIColor clearColor]];
     [imageView loadImageFromURL:[NSURL URLWithString:url]];
     
     NSMutableArray *ratingA = [[[UIApplication sharedApplication] delegate] findCigarMatch:cigar];
     [ratingsView setRating:[[ratingA objectAtIndex:1] intValue]];
     [ratingsView setCigar:cigar];*/
}

-(NSString *)applicationDocumentsDirectory {
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    return basePath;
}


/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)viewWillAppear:(BOOL)animated
{
	self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (toInterfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[newCigar release];
    [super dealloc];
}


@end
