//
//  AboutViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"


@interface AboutViewController : UIViewController {
    IBOutlet AsyncImageView *imageView;
    IBOutlet UITextView *textView;
    
    NSURLConnection *connection;
    NSMutableData *data;
    
    IBOutlet UIWebView *blogWeb;
}

- (IBAction)close:(id)sender;

@end
