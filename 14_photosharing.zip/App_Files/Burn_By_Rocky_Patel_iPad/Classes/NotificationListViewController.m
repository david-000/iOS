//
//  NotificationListViewController.m
//  CigarBoss_Free
//
//  Created by jin on 12/28/12.
//
//

#import "NotificationListViewController.h"
#import "CigarBossAppDelegate.h"
#import "SharedData.h"
#import "NotifyData.h"
#import "CustomHighlightedCell.h"

@interface NotificationListViewController ()

@end

@implementation NotificationListViewController
@synthesize mNotificationList;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    mNotificationList = [[NSMutableArray alloc] init];
    mNotificationList = [appDelegate.mDatabaseManager getNotificationList];
    
    mTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];

	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 748)];
	bgView.image = [UIImage imageNamed:@"right_side.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];

    self.title = @"Notifications";
    
    // Do any additional setup after loading the view from its nib.
}

- (void)dealloc
{
    [mNotificationList release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (int)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
    return [mNotificationList count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80.0f;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //NSLog(@">>>>>>>>Table going to load");

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NotificationCell"];
	
	if( cell == nil ){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"NotificationCell"] autorelease];
	}
    
    NotifyData *notifyData = [self.mNotificationList objectAtIndex:indexPath.row];

    cell.textLabel.textColor = [UIColor whiteColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textLabel.text = notifyData.mNotifyMsg;
    cell.textLabel.numberOfLines = 2;
    cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
    
    NSDateFormatter *fmt = [[[NSDateFormatter alloc] init] autorelease];
    [fmt setDateFormat:@"MM-dd-yyyy hh:mm"];

    cell.detailTextLabel.text = [fmt stringFromDate:[NSDate dateWithTimeIntervalSince1970:[notifyData.mNotifyDateStr intValue]]];
    
    return cell;
}

@end
