//
//  NewCigarMainViewController.h
//  CigarBoss
//
//  Created by Nitin on 16/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewCigarMainViewController : UIViewController

@end
