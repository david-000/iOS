//
//  BrandsViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "BrandsViewController.h"
#import "Cigar.h"
#import "CigarsViewController.h"
#import "CustomHighlightedCell.h"
#import "SearchingOverlayView.h"
#import "SearchResultsObject.h"
#import "AddCigarDetailViewController.h"
#import "CigarBossAppDelegate.h"
#import "NonCubanViewController.h"
#import "CubanViewController.h"

CigarBossAppDelegate *appDelegate;

@implementation BrandsViewController
@synthesize strFrom,strSelected, searchBar;
@synthesize mShowType;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        
        arrNonCuban= [[NSMutableArray alloc] init];
        
        indexes = [[NSMutableDictionary alloc] init];
        searchingTableView = nil;
        searchResultsDataSource = [[SearchResultsObject alloc] init];
        searchResultsDataSource.parent = self;
        
        already = NO;
        // Custom initialization
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
	self = [super initWithCoder:aDecoder];
	
    arrNonCuban= [[NSMutableArray alloc] init];
    
	indexes = [[NSMutableDictionary alloc] init];
	searchingTableView = nil;
	searchResultsDataSource = [[SearchResultsObject alloc] init];
	searchResultsDataSource.parent = self;
	
	already = NO;
	return self;
}

//- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView 
//{
//    return 1;
//}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@">>>>>>>>Table going to load");
	CustomHighlightedCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainCell"];
    
    for(UIView *tempView in [cell.contentView subviews]) {
		[tempView removeFromSuperview];
		tempView = nil;
	}
    
	if(cell == nil)
    {
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
	}
    
    
	cell.backgroundView = nil;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.contentView.backgroundColor = [UIColor clearColor];
	cell.textLabel.backgroundColor = [UIColor clearColor];
	cell.textLabel.textColor = [UIColor whiteColor];
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 6, 450, 45)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentLeft;
    [titleLabel sizeToFit];
    cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:20];
    
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	return cell;
    
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{	
    return @"Brands";
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //    CigarsViewController *c = [[CigarsViewController alloc] initWithNibName:@"CigarsViewController" bundle:nil];
    //    
    //    if(cubanFlag)
    //    {
    //        NSLog(@">>>>>>>>>>>>> 6: %d", [[arrdistNew allKeys] count]);
    //        NSArray *allKeys = keysNew;
    //        NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
    //        NSMutableArray *arrayForThisSection = [arrdistNew objectForKey:rightKey];
    //        c.brand = [arrayForThisSection objectAtIndex:indexPath.row];
    //    }
    //    else
    //    {
    //        NSArray *allKeys = keys;
    //        NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
    //        NSMutableArray *arrayForThisSection = [arrdist objectForKey:rightKey];
    //        c.brand = [arrayForThisSection objectAtIndex:indexPath.row];
    //    }
    //    [self.navigationController pushViewController:c animated:YES];
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad 
{
    [super viewDidLoad];
	//cubanFlag = FALSE;
    
    searchResultsDataSource.mShowType = mShowType;
    
    NSLog(@"View Did LOAD>>>>>>>>>>>>::");
    Ncigars = [[NSMutableArray alloc] init];
    
    appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    //[appDelegate showLoadingView]; 
    
    NSArray *rating = [appDelegate NewCigarList];
    
    for(int i = 0; i<[rating count]; i++)
    {
        NSArray *firstLetter = [rating objectAtIndex:i];
        Cigar *cg = [[Cigar alloc]init];
        cg = [firstLetter objectAtIndex:1];
        [Ncigars addObject:cg];
    }
    [Ncigars retain];    
    int count;
    
    NSUserDefaults *ImageNumber = [NSUserDefaults standardUserDefaults];
    if ([ImageNumber integerForKey:@"CigarImageNumber"] > 0) {
        
        count = [ImageNumber integerForKey:@"CigarImageNumber"];
    }
    else{
        count = 0;
    }
    
    
    if([Ncigars count] > 0){
        NSString *tempBrandId = [NSString stringWithFormat:@"4000%d",count];
        
        for (int k = 0; k < [Ncigars count] ; k++) {
            Cigar *cgar = [[Cigar alloc] init];
            cgar = [Ncigars objectAtIndex:k];
            cgar.brandId = tempBrandId;
            if([cgar.cuban isEqualToString:@"true"])
            {
                //NSLog(@"Testing of Cuban %@ ",cgar);
            }
            NSString *tempBrand = cgar.brand;
            
            tempBrand = [tempBrand stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:[[tempBrand substringToIndex:1] uppercaseString]];
            
            
            NSMutableArray *addArray;
            NSMutableDictionary *appDelBrandsArrays = [appDelegate cigarBrandArrays];
            if([appDelBrandsArrays objectForKey:tempBrand] == nil){
                addArray = [[NSMutableArray alloc] init];
                [appDelBrandsArrays setObject:addArray forKey:tempBrand];
            } else {
                addArray = [appDelBrandsArrays objectForKey:tempBrand];
            }
            
            [addArray addObject:cgar];
        }        
    }
    
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;

	self.title = @"Brands";
	UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(50, 0, 160, 44)];
	label.backgroundColor = [UIColor clearColor];
	label.font = [UIFont boldSystemFontOfSize:22.0];
    label.font = [UIFont fontWithName:@"Copperplate" size:20.0];
	label.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
	label.textAlignment = UITextAlignmentCenter;
	label.textColor =[UIColor whiteColor];
	label.text=self.title;	
	self.navigationItem.titleView = label;		
	[label release];
    
    
    //    mainTableView.frame = CGRectMake(0, 46, 320, 400);
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 704)];
	bgView.image = [UIImage imageNamed:@"right_side.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
    [bgView release];

    [self showSegmentAction];
}

-(void)hideByPerform
{
    [appDelegate hideLoadingView];
}

-(void)onPlusClick
{
    AddCigarDetailViewController *objaddCigar = [[AddCigarDetailViewController alloc]initWithNibName:@"AddCigarDetailViewController" bundle:nil];
    objaddCigar.title = @"New Brand";
    
    strSelected=@"";

    objaddCigar.ParentObj = self;
    [self presentModalViewController:objaddCigar animated:YES];
    [objaddCigar release];
}
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(closeSearch)];
	if(already) return;
	already = YES;
    
    [objNonCubanView.tableView setContentOffset:CGPointMake(0, 0) animated:YES];
    objNonCubanView.tableView.scrollEnabled = NO;
	searchingOverlayView = [[SearchingOverlayView alloc] initWithFrame:CGRectMake(0, 141, 703, 748)];
	[self.view addSubview:searchingOverlayView];
	searchingOverlayView.parent = self;
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar {
    [self performSelector:@selector(closeSearch)];
}

- (void)closeSearch
{
	already = NO;
	self.navigationItem.rightBarButtonItem = nil;
	[searchingOverlayView removeFromSuperview];
	[searchBar resignFirstResponder];
    searchBar.text = @"";
    
    [searchBarNew resignFirstResponder];
    searchBarNew.text = @"";
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(onPlusClick)];
    
	if([searchBar.text length] != 0) [searchingTableView removeFromSuperview];
    
	[searchingTableView removeFromSuperview];
    objNonCubanView.tableView.scrollEnabled = YES;
}

-(void)viewDidAppear:(BOOL)animated
{
    if(AppDelegate.adStatus)
    {
        @try {
            [objNonCubanView.tableView setFrame:CGRectMake(0, 0, 703, 614)];
        }
        @catch (NSException *exception) {
            
        }
    }
    else
    {
        @try {
            [objNonCubanView.tableView setFrame:CGRectMake(0, 0, 703, 704)];
        }
        @catch (NSException *exception) {
            
        }        
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

-(void)moveTOCigarsViewController:(NSString *)brand
{
    CigarsViewController *c = [[CigarsViewController alloc] initWithNibName:@"CigarsViewController" bundle:nil];
    c.brand = brand;
    c.mShowType = mShowType;
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:c animated:YES];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
	if([searchText length] == 0)
    {
		if(searchingTableView){
			[searchingTableView removeFromSuperview];
		}
	} 
    else 
    {
		if(matchedStates)
        {
			[matchedStates release];
			matchedStates = nil;
		}
		
		matchedStates = [[NSMutableArray alloc] init];
				
		NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
        //    NSLog(@">>>>>>>> ArrDict = %@ >>>>\n \n",arrdist);
        
        //  NSLog(@">>>>>>>> brandsDictionary = %@  >>>>\n \n",brandsDictionary);
        
        BOOL isMyCigar = NO;
        
		NSArray *allBrands = [brandsDictionary allKeys];
		for(NSString *brand in allBrands){
			NSRange titleResultsRange = [brand rangeOfString:searchText options:NSCaseInsensitiveSearch];
			if(titleResultsRange.length > 0){
                
                NSArray *cigars = [[appDelegate cigarBrandArrays] objectForKey:brand];
                
                if ( mShowType == 0 ) {
                    
                    isMyCigar = YES;
                    
                    for (Cigar *cigarData in cigars) {
                        if ( cigarData.isMyCigar == 0 ) {
                            isMyCigar = NO;
                            break;
                        }
                    }
                    
                    if ( isMyCigar == NO )
                        [matchedStates addObject:brand];

                } else {
                    

                    if ( cigars != nil && [cigars count] > 0 ) {
                    
                        isMyCigar = NO;
                        
                        for (Cigar *cigarData in cigars) {
                            if ( cigarData.isMyCigar == 1 ) {
                                isMyCigar = YES;
                                break;
                            }
                        }
                        
                        if ( isMyCigar == YES )
                            [matchedStates addObject:brand];

                    }

                }
			}
		}
        
        
        NSLog(@"count = %d", [matchedStates count]);
        
		searchResultsDataSource.results = matchedStates;
		if(!searchingTableView)
		{
			searchingTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 141, 703, 260) style:UITableViewStylePlain];
			searchingTableView.delegate = searchResultsDataSource;
			searchingTableView.dataSource = searchResultsDataSource;
		}
		
		if(searchingTableView.superview != self.view){
			[self.view addSubview:searchingTableView];
		}
		
		[searchingTableView reloadData];
	}
}

-(void)reloaTableDataForSegment
{
    [objNonCubanView SetTableData];
}

-(void) showSegmentAction {
    
    [searchBarNew resignFirstResponder];
    [searchBar resignFirstResponder];
    
    /*
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(onPlusClick)];
     */
    searchBar.text = @"";
    searchBarNew.text= @"";
    [searchingTableView removeFromSuperview];

    if (objNonCubanView != nil) {
        if ([objNonCubanView.tableView numberOfSections] == 0 )
            [objNonCubanView SetTableData];
    }
    else
    {
        objNonCubanView = [[NonCubanViewController alloc] initWithNibName:@"NonCubanViewController" bundle:nil];
        objNonCubanView.mShowType = mShowType;
        objNonCubanView.view.frame = CGRectMake(0, 0, 703, 704);
        [objNonCubanView setParent:self];
        [self.view addSubview:objNonCubanView.tableView];
        
        objNonCubanView.tableView.tableHeaderView = topView;
    }
    
    if(AppDelegate.adStatus)
    {
        @try {
            [objNonCubanView.tableView setFrame:CGRectMake(0, 0, 703, 614)];
        }
        @catch (NSException *exception) {
            
        }
    }
    else
    {
        @try {
            [objNonCubanView.tableView setFrame:CGRectMake(0, 0, 703, 704)];
        }
        @catch (NSException *exception) {
            
        }
    }
    
    objNonCubanView.tableView.hidden = FALSE;
    [self.view bringSubviewToFront:objNonCubanView.tableView];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (toInterfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (void) refreshTableView {
    
    if(AppDelegate.adStatus)
    {
        @try {
            [objNonCubanView.tableView setFrame:CGRectMake(0, 0, 703, 614)];
        }
        @catch (NSException *exception) {
            
        }
    }
    else
    {
        @try {
            [objNonCubanView.tableView setFrame:CGRectMake(0, 0, 703, 704)];
        }
        @catch (NSException *exception) {
            
        }        
    }

    
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
