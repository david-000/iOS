//
//  TwitterPreviewController.m
//  CigarBoss
//
//  Created by Nitin on 16/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TwitterPreviewController.h"
#import <Twitter/TWTweetComposeViewController.h>
#import "CigarBossAppDelegate.h"
#import <QuartzCore/QuartzCore.h>


CigarBossAppDelegate *appdelegate;

@implementation TwitterPreviewController
@synthesize cigarTwit;
@synthesize popOverController;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
-(void)setParentObject:(id)sender{
    parent = sender;
}
- (void)viewDidLoad
{
    appdelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    [super viewDidLoad];
    textView.text = cigarTwit;
    textView.layer.cornerRadius = 10.0;
    textView.textColor=[UIColor blackColor];
    //textView.backgroundColor = [UIColor clearColor];
    textView.backgroundColor = [UIColor colorWithRed:215.0/255.0 green:215.0/255.0 blue:215.0/255.0 alpha:1.0];
    
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)CallTwitter
{	
    TWTweetComposeViewController *twitter = [[TWTweetComposeViewController alloc] init];
    
    [twitter setInitialText:[NSString stringWithFormat:@"%@",textView.text]];
    
//    [twitter addImage:[UIImage imageWithData:@""]];

    UIImage *tempImage = [self scaleAndRotateImage:capturedImg];
   
    [twitter addImage:tempImage];
    
    [twitter addURL:[NSURL URLWithString:@"http://cigarbossapp.com/"]];
    
    [self presentViewController:twitter animated:YES completion:nil];
    
    twitter.completionHandler = ^(TWTweetComposeViewControllerResult res) {
        
        if(res == TWTweetComposeViewControllerResultDone)
        {
            
            UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:@"Succes!" message:@"Your Tweet was posted succesfully" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            
            [alertView show];

            [parent dismissModalViewControllerAnimated:YES];
            
        }else if(res == TWTweetComposeViewControllerResultCancelled)
        {
            
            UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:@"Canceled" message:@"Your Tweet was not posted" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            
            [alertView show];
        }
        [self dismissModalViewControllerAnimated:YES];
    };
}

//rotate image
-(UIImage *)scaleAndRotateImage:(UIImage *)image 
{  
	int kMaxResolution = 320; // Or whatever  
	
	CGImageRef imgRef = image.CGImage;  
	
	CGFloat width = CGImageGetWidth(imgRef);  
	CGFloat height = CGImageGetHeight(imgRef);  
	
	CGAffineTransform transform = CGAffineTransformIdentity;  
	CGRect bounds = CGRectMake(0, 0, width, height);  
	if (width > kMaxResolution || height > kMaxResolution)
	{  
		CGFloat ratio = width/height;  
		if (ratio > 1) {  
			bounds.size.width = kMaxResolution;  
			bounds.size.height = bounds.size.width / ratio;  
		}  
		else
		{  
			bounds.size.height = kMaxResolution;  
			bounds.size.width = bounds.size.height * ratio;  
		}  
	}  
	
	CGFloat scaleRatio = bounds.size.width / width;  
	CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));  
	CGFloat boundHeight;  
	UIImageOrientation orient = image.imageOrientation;  
	switch(orient) 
	{  
			
		case UIImageOrientationUp: //EXIF = 1  
			transform = CGAffineTransformIdentity;  
			break;  
			
		case UIImageOrientationUpMirrored: //EXIF = 2  
			transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);  
			transform = CGAffineTransformScale(transform, -1.0, 1.0);  
			break;  
			
		case UIImageOrientationDown: //EXIF = 3  
			transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);  
			transform = CGAffineTransformRotate(transform, M_PI);  
			break;  
			
		case UIImageOrientationDownMirrored: //EXIF = 4  
			transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);  
			transform = CGAffineTransformScale(transform, 1.0, -1.0);  
			break;  
			
		case UIImageOrientationLeftMirrored: //EXIF = 5  
			boundHeight = bounds.size.height;  
			bounds.size.height = bounds.size.width;  
			bounds.size.width = boundHeight;  
			transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);  
			transform = CGAffineTransformScale(transform, -1.0, 1.0);  
			transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);  
			break;  
			
		case UIImageOrientationLeft: //EXIF = 6  
			boundHeight = bounds.size.height;  
			bounds.size.height = bounds.size.width;  
			bounds.size.width = boundHeight;  
			transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);  
			transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);  
			break;  
			
		case UIImageOrientationRightMirrored: //EXIF = 7  
			boundHeight = bounds.size.height;  
			bounds.size.height = bounds.size.width;  
			bounds.size.width = boundHeight;  
			transform = CGAffineTransformMakeScale(-1.0, 1.0);  
			transform = CGAffineTransformRotate(transform, M_PI / 2.0);  
			break;  
			
		case UIImageOrientationRight: //EXIF = 8  
			boundHeight = bounds.size.height;  
			bounds.size.height = bounds.size.width;  
			bounds.size.width = boundHeight;  
			transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);  
			transform = CGAffineTransformRotate(transform, M_PI / 2.0);  
			break;  
			
		default:  
			[NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];  
			
	}  
	
	UIGraphicsBeginImageContext(bounds.size);  
	
	CGContextRef context = UIGraphicsGetCurrentContext();  
	
	if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft)
	{  
		CGContextScaleCTM(context, -scaleRatio, scaleRatio);  
		CGContextTranslateCTM(context, -height, 0);  
	}  
	else
	{  
		CGContextScaleCTM(context, scaleRatio, -scaleRatio);  
		CGContextTranslateCTM(context, 0, -height);  
	}  
	
	CGContextConcatCTM(context, transform);  
	
	CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);  
	UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();  
	UIGraphicsEndImageContext();  
	
	return imageCopy;  
}  

- (BOOL)textView:(UITextView *)textView1 shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    // Any new character added is passed in as the "text" parameter
    if ([text isEqualToString:@"\n"]) {
        // Be sure to test for equality using the "isEqualToString" message
        [textView resignFirstResponder];
        
        return FALSE;
    }
    return TRUE;
}

- (IBAction)UploadImage{
    
    UIActionSheet *action = [[UIActionSheet alloc]initWithTitle:@"" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Take A Photo",@"Existing Photo",nil];//@"Clear Message Log" == 0 
    //    action.tag = 99;
//    [action showInView:self.view];
    [action showInView:[self.view window]];
    [action release];
    
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        @try {                
            if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                imagePickerController = [[CustomImagePickerController alloc] init];
                imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
                imagePickerController.navigationBar.barStyle = UIBarStyleBlack;                
                imagePickerController.delegate = self;
                imagePickerController.allowsEditing = NO;

                [self presentModalViewController:imagePickerController animated:YES];
                [imagePickerController release];
            }
            else 
            {
                [appdelegate showAlertWithTitle:@"Info" message:@"This function needs a camera which is only available on the iPhone or iPod."];
            }
        }
        @catch (NSException *e) {
            
        }
    }
    if (buttonIndex == 1) {
        if ( [popOverController isPopoverVisible] ) {
            [popOverController dismissPopoverAnimated:YES];
        } else {
            
            CustomImagePickerController *picker = [[CustomImagePickerController alloc] init];
            picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            picker.navigationBar.barStyle = UIBarStyleBlack;                
            picker.delegate = self;
            
            UIPopoverController *popoverController = [[UIPopoverController alloc] initWithContentViewController:picker];
            
            popoverController.delegate = self;
            CGRect popoverRect = [self.view convertRect:[self.view frame] fromView:[self.view superview]];
            popoverRect.size.width = MIN(popoverRect.size.width, 80);
            popoverRect.origin.x = popoverRect.origin.x + 150;
            [popoverController presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            
            self.popOverController = popoverController;
            
        }
    }
    //[actionSheet dismissWithClickedButtonIndex:2 animated:YES]; 
}
- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *capturedImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    imgView.image = capturedImage;
    capturedImg = capturedImage;

    [picker dismissModalViewControllerAnimated:YES];

}

-(IBAction)closeTwit
{    
   [parent dismissModalViewControllerAnimated:YES];
}


-(void)dealloc
{
    [popOverController release];
    [super dealloc];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
