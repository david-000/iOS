//
//  communityViewController.h
//  CigarBoss
//
//  Created by Nitin on 13/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

//#define soapAction @"http://logisticinfotech.com/client/webservicecigar/soap-server.php"
//#define xmlns @"http://logisticinfotech.com/soap/cigarboss"


#define soapAction @"http://cigarboss.co/webservice/soap-server.php"

#define xmlns @"http://cigarboss.co/soap/cigarboss"


#import <UIKit/UIKit.h>

@interface communityViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    IBOutlet UITableView *mainTable;
    
    NSMutableData *webData;
	NSXMLParser *xmlParser;
	NSString *element;
    NSMutableArray *userArray;
    BOOL flag;
    NSArray *keys;
	NSMutableDictionary *indexes;
    NSMutableArray *testingofArray;
}
@property(nonatomic,assign)BOOL flag;
@end
