//
//  FavoritesViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FavoritesViewController.h"
#import "CustomHighlightedCell.h"
#import "CigarViewController.h"
#import "StoreViewController.h"

@interface NSString (trimLeadingWhitespace)
-(NSString*)stringByTrimmingLeadingWhitespace;
@end

@implementation NSString (trimLeadingWhitespace)
-(NSString*)stringByTrimmingLeadingWhitespace {
    NSInteger i = 0;
	
    while ([[NSCharacterSet whitespaceCharacterSet] characterIsMember:[self characterAtIndex:i]]) {
        i++;
    }
	
	while([[NSCharacterSet newlineCharacterSet] characterIsMember:[self characterAtIndex:i]]){
		i++;
	}
    return [self substringFromIndex:i];
}
@end

@implementation FavoritesViewController


 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
		forShops = NO;
    }
    return self;
}


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)changeStuff:(id)sender
{
	forShops = !forShops;
	[mainTableView reloadData];
}

- (void)viewWillAppear:(BOOL)animated
{
	[cigars release];
	cigars = [[NSMutableArray alloc] init];
	id appDelegate = [[UIApplication sharedApplication] delegate];
	for(NSArray *rating in [appDelegate ratings]){
		[cigars addObject:[rating objectAtIndex:0]];
	}
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editEntries:)];
	[mainTableView setEditing:NO];
	[self setEditing:NO];
	if(indexes){
		[indexes release];
		[keys release];
	}
	indexes = [[NSMutableDictionary alloc] init];
    //id appDelegate = [[UIApplication sharedApplication] delegate];
    for(NSArray *rating in [appDelegate ratings]){
        NSString *firstLetter = [rating objectAtIndex:1];;
        NSMutableArray *existingArray;
        if((existingArray = [indexes valueForKey:firstLetter])){
            [existingArray addObject:[rating objectAtIndex:0]];
        } else {
            NSMutableArray *tempArray = [NSMutableArray array];
            [indexes setObject:tempArray forKey:firstLetter];
            [tempArray addObject:[rating objectAtIndex:0]];
        }
    }
	loaded = YES;
	
    
	NSSortDescriptor *desc = [NSSortDescriptor sortDescriptorWithKey:nil ascending:NO selector:@selector(localizedCompare:)];
    keys = [[indexes allKeys] sortedArrayUsingDescriptors:[NSArray arrayWithObject:desc]];
	keys = [[NSMutableArray alloc] initWithArray:keys];
	[mainTableView reloadData];
}

- (void)editEntries:(UIBarButtonItem *)sender
{
	[mainTableView setEditing:!mainTableView.editing animated:YES];
	self.editing = !self.editing;
	
	if(!self.editing){
		self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editEntries:)];
	} else {
		self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(editEntries:)];
	}
}

- (void)viewDidLoad {
    [super viewDidLoad];
	
	if(!loaded){
	if(indexes){
		[indexes release];
		[keys release];
	}
	indexes = [[NSMutableDictionary alloc] init];
    id appDelegate = [[UIApplication sharedApplication] delegate];
    for(NSArray *rating in [appDelegate ratings]){
        NSString *firstLetter = [rating objectAtIndex:1];;
        NSMutableArray *existingArray;
        if((existingArray = [indexes valueForKey:firstLetter])){
            [existingArray addObject:[rating objectAtIndex:0]];
        } else {
            NSMutableArray *tempArray = [NSMutableArray array];
            [indexes setObject:tempArray forKey:firstLetter];
            [tempArray addObject:[rating objectAtIndex:0]];
        }
    }
		loaded = YES;
	
    
	NSSortDescriptor *desc = [NSSortDescriptor sortDescriptorWithKey:nil ascending:NO selector:@selector(localizedCompare:)];
    keys = [[indexes allKeys] sortedArrayUsingDescriptors:[NSArray arrayWithObject:desc]];
	keys = [[NSMutableArray alloc] initWithArray:keys];
    //keys = [[NSArray alloc] initWithObjects:@"5", @"4", @"3", @"2", "1", nil];
    //NSLog([indexes description]);
	}
	
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editEntries:)];
	
//	self.title = @"Favorites";
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 703, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =@"Favorites"; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:20.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];
	mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 704)];
	bgView.image = [UIImage imageNamed:@"right_side.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
	[bgView release];
    
	self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
	
	cigars = [[NSMutableArray alloc] init];
	id appDelegate = [[UIApplication sharedApplication] delegate];
	for(NSArray *rating in [appDelegate ratings]){
		[cigars addObject:[rating objectAtIndex:0]];
	}
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{	
	if(forShops) return 1;
    return [keys count];
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return nil;
	if(forShops) return nil;
    return keys;
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
	if(forShops) return nil;
    return index;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if(forShops) return [[(CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate] favoriteShops] count];
    NSString *correctKey = [keys objectAtIndex:section];
    NSArray *arrayForThisSection = [indexes objectForKey:correctKey];
    return [arrayForThisSection count];
    //return 0;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
	if(forShops) return nil;
    return [NSString stringWithFormat:@"%@ stars", [keys objectAtIndex:section]];
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(forShops){
        NSMutableArray *shops = [[[UIApplication sharedApplication] delegate] favoriteShops];
        [shops removeObjectAtIndex:indexPath.row];
        [[[UIApplication sharedApplication] delegate] saveFavoriteShops];
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        return;
    }
	
	
	NSString *correctKey = [keys objectAtIndex:indexPath.section];
    NSArray *arrayForThisSection = [indexes objectForKey:correctKey];
	Cigar *correctCig = [arrayForThisSection objectAtIndex:indexPath.row];
	Cigar *cigarHere = correctCig;
	id appDelegate = [[UIApplication sharedApplication] delegate];
	NSArray *removeRating = nil;
	for(NSArray *rating in [appDelegate ratings]){
		if([cigarHere isEqualCigar:[rating objectAtIndex:0]]){
		removeRating = rating;
		}
	}
	if(removeRating){
		[[appDelegate ratings] removeObject:removeRating];
		[appDelegate saveData];
	}
	[arrayForThisSection removeObjectAtIndex:indexPath.row];
	if([cigars count] == 0){
		[self editEntries:nil];
	}
	if([arrayForThisSection count] == 0){
		[keys removeObjectAtIndex:indexPath.section];
		[tableView deleteSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationLeft];
	} else {
		[tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
	}
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BrandCell"];
	
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"BrandCell"] autorelease];
	}
	
	if(forShops){
		NSArray *shops = [[[UIApplication sharedApplication] delegate] favoriteShops];
        //NSLog([[[shops objectAtIndex:indexPath.row] objectAtIndex:0] description]);
		cell.textLabel.text = [[[shops objectAtIndex:indexPath.row] objectAtIndex:0] objectForKey:@"name"];
        cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
        
        NSString *address = [[[shops objectAtIndex:indexPath.row] objectAtIndex:0] objectForKey:@"address"];
        cell.detailTextLabel.text = address;
        cell.detailTextLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
        
        @try {
            NSArray *components = [address componentsSeparatedByString:@","];
            NSString *city = [[components objectAtIndex:1] stringByReplacingOccurrencesOfString:@" " withString:@""];
            NSString *stateAndZip = [components objectAtIndex:2];
            NSArray *stateComponents = [stateAndZip componentsSeparatedByString:@" "];
            NSString *state = [stateComponents objectAtIndex:1];
            //cell.detailTextLabel.text = [[[shops objectAtIndex:indexPath.row] objectAtIndex:0] objectForKey:@"address"];
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%@, %@", city, state];

        }
        @catch (NSException *exception) {
            
        }
        @finally {
            
        }
        //address = [address stringByReplacingOccurrencesOfString:@" " withString:@""];
        
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        //cell.detailTextLabel.text = @"";
	} else {
	NSString *correctKey = [keys objectAtIndex:indexPath.section];
    NSArray *arrayForThisSection = [indexes objectForKey:correctKey];
	Cigar *correctCig = [arrayForThisSection objectAtIndex:indexPath.row];
	cell.textLabel.textColor = [UIColor whiteColor];
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.adjustsFontSizeToFitWidth = YES;
	cell.textLabel.text = [correctCig.brand stringByTrimmingLeadingWhitespace];
    cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	cell.detailTextLabel.text = correctCig.type;
    cell.detailTextLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
	}
	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(forShops){
		StoreViewController *sView = [[StoreViewController alloc] initWithNibName:@"StoreViewController" bundle:nil];
		NSArray *shops = [[[UIApplication sharedApplication] delegate] favoriteShops];
		sView.newCigar = [[shops objectAtIndex:indexPath.row] objectAtIndex:0];
        self.navigationItem.title=@"Back";
		[self.navigationController pushViewController:sView animated:YES];
		return;
	}
	CigarViewController *c = [[CigarViewController alloc] initWithNibName:@"CigarViewController" bundle:[NSBundle mainBundle]];
	NSString *correctKey = [keys objectAtIndex:indexPath.section];
    NSArray *arrayForThisSection = [indexes objectForKey:correctKey];
	Cigar *correctCig = [arrayForThisSection objectAtIndex:indexPath.row];
	c.cigar = correctCig;
    self.navigationItem.title=@"Back";
	[self.navigationController pushViewController:c animated:YES];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (toInterfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

-(void)viewDidAppear:(BOOL)animated
{
    if(AppDelegate.adStatus)
    {
        [mainTableView setFrame:CGRectMake(0, 37, 703, 621)];
    }
    else
    {
        [mainTableView setFrame:CGRectMake(0, 37, 703, 667)];
    }
}
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
