//
//  FilteredViewFinal.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FilteredViewSearch.h"
#import "Cigar.h"
#import "CustomHighlightedCell.h"
#import "CigarBossAppDelegate.h"


@implementation FilteredViewSearch
@synthesize cigars, dictIndexes;
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 748)];
	bgView.image = [UIImage imageNamed:@"right_side.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
}

-(void)setTableData:(NSMutableArray *)arrKey from:(NSMutableDictionary *)mainIndex
{
    
    keys = arrKey;
    [keys retain];
    indexes = mainIndex;
    [indexes retain];
    
    dictIndexes = mainIndex;
    [dictIndexes retain];
    indexes = [[NSMutableDictionary alloc] init];
    keys = [[NSMutableArray alloc] init];
    
    [indexes removeAllObjects];
    [keys removeAllObjects];
    
    //    NSArray *arrDict = [seachFor allKeys];
    //    NSLog(@">>>>>>>>>>> array Dict :%@", arrDict);
    //    
    //    for (NSString *str in arrDict) {
    //        NSArray *array = [dictIndexes objectForKey:[seachFor objectForKey:str]];
    //        NSLog(@">>>>>>>>>>>>>>> array values :%@", [dictIndexes objectForKey:[seachFor objectForKey:str]]);
    //        
    //        for(Cigar *cigar in array){
    //            [keys addObject:cigar];
    //        }
    //    }
    
    NSSortDescriptor *sortDesc = [NSSortDescriptor sortDescriptorWithKey:@"brand" ascending:YES];
    [keys sortUsingDescriptors:[NSArray arrayWithObject:sortDesc]];
    
    for(Cigar *key in keys){
        NSString *firstLetter = [key.brand substringToIndex:1];
        NSMutableArray *existingArray;
        if ((existingArray = [indexes valueForKey:firstLetter])) 
        {
            [existingArray addObject:key];
        } else {
            NSMutableArray *tempArray = [NSMutableArray array];
            [indexes setObject:tempArray forKey:firstLetter];
            [tempArray addObject:key];
        }
    }
    
    keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    
    //NSLog(@">>>>>>>>>>>>>>> indexes key :%@", indexes);
    [mainTableView reloadData];
}

- (int)numberOfSectionsInTableView:(UITableView *)tableView
{
    /*NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
     keys = [brandsDictionary allKeys];*/
    indexes = [[NSMutableDictionary alloc] init];
    keys = [[NSMutableArray alloc] init];
    
    for(Cigar *cigar in cigars){
        if ( cigar.isMyCigar == 1 )
            [keys addObject:cigar];
    }
    
    NSSortDescriptor *sortDesc = [NSSortDescriptor sortDescriptorWithKey:@"brand" ascending:YES];
	[keys sortUsingDescriptors:[NSArray arrayWithObject:sortDesc]];
	
	for(Cigar *key in keys){
		NSString *firstLetter = [key.brand substringToIndex:1];
		NSMutableArray *existingArray;
		//NSLog(firstLetter);
		// if an array already exists in the name index dictionary
		// simply add the element to it, otherwise create an array
		// and add it to the name index dictionary with the letter as the key
		if ((existingArray = [indexes valueForKey:firstLetter])) 
		{
			[existingArray addObject:key];
		} else {
			NSMutableArray *tempArray = [NSMutableArray array];
			[indexes setObject:tempArray forKey:firstLetter];
			[tempArray addObject:key];
		}
	}
    
	keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
	return [indexes count];
	//return 1;
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
	// returns the array of section titles. There is one entry for each unique character that an element begins with
	// [A,B,C,D,E,F,G,H,I,K,L,M,N,O,P,R,S,T,U,V,X,Y,Z]
	return keys;
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index {
	return index;
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
	NSArray *allKeys = keys;
	NSString *rightKey = [allKeys objectAtIndex:section];
	NSMutableArray *arrayForThisSection = [indexes objectForKey:rightKey];
	return [arrayForThisSection count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainCell"];
	
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"MainCell"] autorelease];
	}
	
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	//cell.textLabel.text = [[cigars objectAtIndex:indexPath.row] valueForKey:@"type"];
	//cell.detailTextLabel.text = [[cigars objectAtIndex:indexPath.row] valueForKey:@"brand"];
	cell.textLabel.textColor = [UIColor whiteColor];
    
    NSArray *allKeys = keys;
	NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
	NSMutableArray *arrayForThisSection = [indexes objectForKey:rightKey];
    Cigar *correctCigar = [arrayForThisSection objectAtIndex:indexPath.row];
    cell.textLabel.text = correctCigar.brand;
    cell.detailTextLabel.text = correctCigar.type;
    cell.detailTextLabel.font = [UIFont fontWithName:@"Copperplate" size:16.0];
    cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
	
	return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {	
	return [keys objectAtIndex:section];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	CigarViewController *c = [[CigarViewController alloc] initWithNibName:@"CigarViewController" bundle:nil];
	NSArray *allKeys = keys;
	NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
	NSMutableArray *arrayForThisSection = [indexes objectForKey:rightKey];
    Cigar *correctCigar = [arrayForThisSection objectAtIndex:indexPath.row];
    c.cigar = correctCigar;
    c.isUpdate = TRUE;
    self.title=@"Back";
	[self.navigationController pushViewController:c animated:YES];
}
-(void)viewWillAppear:(BOOL)animated
{
    self.title = @"Filter";
    
    [AppDelegate showAdView];
    
    if(AppDelegate.adStatus)
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 614)];
    }
    else
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 704)];
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
