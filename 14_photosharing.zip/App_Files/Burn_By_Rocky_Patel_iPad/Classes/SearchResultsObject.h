//
//  SearchResultsObject.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SearchResultsObject : NSObject {
	NSArray *results;
	id parent;
}

@property (nonatomic, assign) NSArray *results;
@property (nonatomic, assign) id parent;
@property (nonatomic) NSInteger mShowType;
@end
