//
//  ViewUserReview.m
//  CigarBoss
//
//  Created by Nitin on 27/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "ViewUserReview.h"
#import "LargePhotoViewController.h"
#import "CigarBossAppDelegate.h"

CigarBossAppDelegate *appDelegate;

#pragma mark VerticalAlign
@interface UILabel (VerticalAlign)
- (void)alignTop;
- (void)alignBottom;
@end

// -- file: UILabel+VerticalAlign.m
@implementation UILabel (VerticalAlign)

- (void)alignTop {
    CGSize fontSize = [self.text sizeWithFont:self.font];
    
    double finalHeight = fontSize.height * self.numberOfLines;
    double finalWidth = self.frame.size.width;    //expected width of label
    
    CGSize theStringSize = [self.text sizeWithFont:self.font constrainedToSize:CGSizeMake(finalWidth, finalHeight) lineBreakMode:self.lineBreakMode];
    
    
    int newLinesToPad = (finalHeight  - theStringSize.height) / fontSize.height;
    
    for(int i=0; i< newLinesToPad; i++)
    {
        self.text = [self.text stringByAppendingString:@" \n"];
    }
}

- (void)alignBottom {
    CGSize fontSize = [self.text sizeWithFont:self.font];
    double finalHeight = fontSize.height * self.numberOfLines;
    double finalWidth = self.frame.size.width;    //expected width of label
    CGSize theStringSize = [self.text sizeWithFont:self.font constrainedToSize:CGSizeMake(finalWidth, finalHeight) lineBreakMode:self.lineBreakMode];
    int newLinesToPad = (finalHeight  - theStringSize.height) / fontSize.height;
    for(int i=0; i<newLinesToPad; i++)
        self.text = [NSString stringWithFormat:@" \n%@",self.text];
}
@end



@implementation ViewUserReview

@synthesize dictObj;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    appDelegate = (CigarBossAppDelegate *)[UIApplication sharedApplication].delegate;
    
    
    // NSLog(@"-- Dict Obj = %@",dictObj);
    [appDelegate showLoadingView:self.view];
//    self.navigationItem.title = [NSString stringWithFormat:@"%@'s Review",[dictObj objectForKey:@"username"]];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 400, 44)];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:20.0];
    label.font = [UIFont fontWithName:@"Copperplate" size:20.0];
    label.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    label.textAlignment = UITextAlignmentCenter;
    label.textColor =[UIColor whiteColor];
    label.text=[NSString stringWithFormat:@"%@'s Review",[dictObj objectForKey:@"username"]];	
    self.navigationItem.titleView = label;
    [label release];

    [scrollView setFrame:CGRectMake(0, 0, 703, 704)];
    [scrollView setContentSize:CGSizeMake(703, 550)];
    [scrollView setScrollEnabled:YES];
    
    
    lblDateSmoked.text = [dictObj objectForKey:@"dateSmoked"];
    lblHeadline.text = [dictObj objectForKey:@"headline"];
    txtHeadline.text = [dictObj objectForKey:@"headline"];
    txtHeadline.layer.cornerRadius = 5.0;
    
    lblHeadline.numberOfLines = 2;
    [lblHeadline alignTop];
    
    lblPrice.text = [dictObj objectForKey:@"pricePaid"];
    lblRate.text = [dictObj objectForKey:@"rate"];
    
    txtRenote.text = [dictObj objectForKey:@"renote"];
    txtRenote.layer.cornerRadius = 5.0;
    txtRenote.layer.borderWidth = 1.5;
    
    NSString *star = [dictObj objectForKey:@"startRate"];
    
    
    if(star.length > 0)
    {
        if([star isEqualToString:@"1"]){
            [s1 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s2 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
            [s3 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
            [s4 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
            [s5 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        }
        
        if([star isEqualToString:@"2"]){
            [s1 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s2 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s3 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
            [s4 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
            [s5 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        }
        
        if([star isEqualToString:@"3"]){
            [s1 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s2 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s3 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s4 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
            [s5 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        }
        
        if([star isEqualToString:@"4"]){
            [s1 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s2 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s3 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s4 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s5 setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
        }
        
        if([star isEqualToString:@"5"]){
            [s1 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s2 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s3 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s4 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
            [s5 setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];
        }
        
        NSString *url1 = [dictObj objectForKey:@"imageurl"];
        
        if([url1 rangeOfString:@"http://"].location == NSNotFound){
            
            url1 = [@"http://" stringByAppendingString:[dictObj objectForKey:@"imageurl"]];
            
        }
        UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc]
                                                 initWithTarget:self action:@selector(ClickEventOnImage:)];
        [tapRecognizer setNumberOfTouchesRequired:1];
        [tapRecognizer setDelegate:self];
        
        //Don't forget to set the userInteractionEnabled to YES, by default It's NO.
        imgView.userInteractionEnabled = YES;
        [imgView addGestureRecognizer:tapRecognizer];
        [imgView loadImageFromURL:[NSURL URLWithString:url1]];
        [imgView setAlpha:1.0];
        [imgView setBackgroundColor:[UIColor clearColor]];
        
        [scrollView setContentSize:CGSizeMake(703, 860)];
    }
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewDidAppear:(BOOL)animated
{
    if(AppDelegate.adStatus)
    {
        
         [scrollView setContentSize:CGSizeMake(703, 880)];
    }
    else
    {
        
    }
}

- (void)ClickEventOnImage:(id)sender
{
    AsyncImageView *async = (AsyncImageView *)[sender view];
    LargePhotoViewController *l = [[LargePhotoViewController alloc] initWithNibName:@"LargePhotoViewController" bundle:nil];
    
    l.image = [[sender view] image];    
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:l animated:YES];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
