//
//  MyNotesViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 11/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyNotesViewController : UIViewController{
    IBOutlet UITableView *mainTableView;
    NSMutableArray *notes;
    IBOutlet UIButton *btnEdit;
}
-(IBAction)onAddbtnClick:(id)sender;
- (IBAction)onbtnEditClick:(id)sender;
@end
