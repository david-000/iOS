//
//  CigarViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CigarBossAppDelegate.h"
#import "CigarViewController.h"
#import "NSAttributedString+Attributes.h"
#import "OHAttributedLabel.h"
#import "LargePhotoViewController.h"
#import "JSON.h"
#import "SHK.h"
#import "WebViewController.h"
#import "AddNoteViewController.h"
#import "MTLabel.h"
#import "ViewNoteViewController.h"
#import "ShareReviewViewController.h"
#import "FillReviewFormViewController.h"
#import "TouchXML.h"
#import "CustomHighlightedCell.h"
#import "CigarBossAppDelegate.h"
#import "ViewUserReview.h"
#import "TSMiniWebBrowser.h"
#import <Twitter/TWTweetComposeViewController.h>
#import "TwitterPreviewController.h"
#import "RateStarView.h"
#import "SHKMail.h"


#pragma mark VerticalAlign
@interface UILabel (VerticalAlign)
- (void)alignTop;
- (void)alignBottom;
@end

// -- file: UILabel+VerticalAlign.m
@implementation UILabel (VerticalAlign)

- (void)alignTop {
    CGSize fontSize = [self.text sizeWithFont:self.font];
    
    double finalHeight = fontSize.height * self.numberOfLines;
    double finalWidth = self.frame.size.width;    //expected width of label
    
    CGSize theStringSize = [self.text sizeWithFont:self.font constrainedToSize:CGSizeMake(finalWidth, finalHeight) lineBreakMode:self.lineBreakMode];
    
    
    int newLinesToPad = (finalHeight  - theStringSize.height) / fontSize.height;
    
    for(int i=0; i< newLinesToPad; i++)
    {
        self.text = [self.text stringByAppendingString:@" \n"];
    }
}

- (void)alignBottom {
    CGSize fontSize = [self.text sizeWithFont:self.font];
    double finalHeight = fontSize.height * self.numberOfLines;
    double finalWidth = self.frame.size.width;    //expected width of label
    CGSize theStringSize = [self.text sizeWithFont:self.font constrainedToSize:CGSizeMake(finalWidth, finalHeight) lineBreakMode:self.lineBreakMode];
    int newLinesToPad = (finalHeight  - theStringSize.height) / fontSize.height;
    for(int i=0; i<newLinesToPad; i++)
        self.text = [NSString stringWithFormat:@" \n%@",self.text];
}
@end
//Blog Reviews - Click To Read

@implementation CigarViewController

CigarBossAppDelegate *appDelegate;

@synthesize cigar, scrollView, forFeaturedCigar,pass,isUpdate;
@synthesize popOverController;
@synthesize mShowType;
@synthesize mDic;
;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
        adjustedLabels = [[NSMutableArray alloc] init];
        loadedAlready = NO;
    }
    return self;
}

- (void)ClickEventOnImage:(id)sender
{
    if ( cigar.isOutOfStock == 1 )
        return;
    
    if ( [[sender view] image] != nil ) {

        LargePhotoViewController *l = [[LargePhotoViewController alloc] initWithNibName:@"LargePhotoViewController" bundle:nil];
        
        l.image = [[sender view] image];
        self.navigationItem.title=@"Back";
        [self.navigationController pushViewController:l animated:YES];

    }
    
}
-(void)loadURL:(NSURL *)url
{
    WebViewController *w = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
    w.url = url;    
    [self presentModalViewController:w animated:YES];
//    TSMiniWebBrowser *webBrowser = [[TSMiniWebBrowser alloc] initWithUrl:url];
//    [self presentModalViewController:webBrowser animated:YES];
//    [webBrowser release];
}

- (void)loadURLOLD:(NSURL *)url
{
  //  NSLog(@"LOad URL >>>>>>>>>>>>> Called");
    WebViewController *w = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
    w.url = url;
    [self presentModalViewController:w animated:YES];
    [w release];
}


- (void)viewDidAppear:(BOOL)animated
{
    NSMutableArray *cigarArray = [appDelegate findHumidorMatch:self.cigar];
    if(cigarArray){
        humidorCountLabel.text = [cigarArray objectAtIndex:1];
    }
    
    if(AppDelegate.adStatus)
    {
        [scrollView setFrame:CGRectMake(0, 0, 703, 614)];        
    }
    else
    {
        [scrollView setFrame:CGRectMake(0, 0, 703, 704)];            
    }

}

- (void)twitter
{	
   //   NSLog(@"twitter begins");
    if ([[[UIDevice currentDevice] systemVersion] intValue] < 5.0) {
        SHKItem *item;
        self.view.autoresizingMask = UIViewAutoresizingNone;
        self.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        item = [SHKItem text:[NSString stringWithFormat:@"#nowsmoking '%@ %@' via Cigar_Boss_APP for iPad", brandLabel.text, typeLabel.text]];
        [SHK setRootViewController:self.navigationController.tabBarController];
        [NSClassFromString(@"SHKTwitter") performSelector:@selector(shareItem:) withObject:item];
    }
    else
    {
        TwitterPreviewController *tpc = [[TwitterPreviewController alloc] initWithNibName:@"TwitterPreviewController" bundle:nil];
        [tpc setParentObject:self];
        tpc.cigarTwit = twitString;
        [self presentModalViewController:tpc animated:YES];

    }
}

- (void)facebook
{	
	// Create the item to share (in this example, a url)
	//NSURL *url = [NSURL URLWithString:;
    
    UIAlertView *alttakePhoto = [[UIAlertView alloc]initWithTitle:@"Select Photo" message:@"Please Select Source For Share Photo If You Want" delegate:self cancelButtonTitle:@"Without Photo" otherButtonTitles:@"Take Photo",@"Library", nil];
    alttakePhoto.tag = 100;
    [alttakePhoto show];
    [alttakePhoto release];
    

//	SHKItem *item;
//	
//	
//	/*(int repsTotal = 0;
//	 for(NSDictionary *workout in logsArray){
//	 repsTotal += [[workout objectForKey:@"reps"] intValue];
//	 }
//	 
//	 item = [SHKItem URL:url title:[NSString stringWithFormat:@"%@ (week %d): %d reps over %d workouts! - via Panda90X", self.parentWorkout, self.week, repsTotal, [logsArray count]]];
//	 
//	 */
//	self.view.autoresizingMask = UIViewAutoresizingNone;
//	self.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
//	item = [SHKItem text:[NSString stringWithFormat:@"#nowsmoking '%@ %@' via Cigar Boss for iPhone", brandLabel.text, typeLabel.text]];
//	[SHK setRootViewController:self.navigationController.tabBarController];
//	
//	// Get the ShareKit action sheet
//	/*SHKActionSheet *actionSheet = [SHKActionSheet actionSheetForItem:item];*/
//	
//	// Display the action sheet
//	[NSClassFromString(@"SHKFacebook") performSelector:@selector(shareItem:) withObject:item];
}

- (IBAction)requestCigarButtonClicked:(id)sender
{
    MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
    
    picker.mailComposeDelegate = self;
    
    [picker setSubject:@"A Cigar Request From Your Custom Cigar Boss Application"];
	[picker setMessageBody:[NSString stringWithFormat:@"I would like for you to bring in the %@ %@ cigar.", cigar.brand, cigar.length] isHTML:NO];
    
    [self presentViewController:picker animated:YES completion:nil];
    [picker release];
}

- (void) facebookShareImage : (UIImage *) image
{
    if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook]) {
        
        mySLComposerSheet = [[SLComposeViewController alloc] init];
        mySLComposerSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        [mySLComposerSheet setInitialText:[NSString stringWithFormat:@"#nowsmoking '%@ %@' via Cigar Boss for iPhone", brandLabel.text, typeLabel.text]];
        [mySLComposerSheet addImage:image];
        [self presentViewController:mySLComposerSheet animated:YES completion:nil];
        
        [mySLComposerSheet setCompletionHandler:^(SLComposeViewControllerResult result) {
            NSLog(@"dfsdf");
            NSString *output;
            switch (result) {
                case SLComposeViewControllerResultCancelled:
                    output = @"Post Canceled.";
                    [mySLComposerSheet dismissModalViewControllerAnimated:YES];
                    break;
                case SLComposeViewControllerResultDone:
                    output = @"Post Success.";
                    [mySLComposerSheet dismissModalViewControllerAnimated:YES];
                    break;
                default:
                    break;
            }
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook Message" message:output delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            [alert show];
        }];
        
    }
}


-(void)StarRateWebFunction : (NSString *)id
{
    [appDelegate showLoadingView:self.view];
    if(cigar.brandId){
        NSString *webService = [NSString stringWithFormat:soapAction];
        NSString *soapMessage = [NSString stringWithFormat:
                                 @"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                                 "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
                                 "<soap:Body>\n"
                                 "<Totalcigarreview xmlns=\"%@\">\n"
                                 "<brandid>%@</brandid>"
                                 "</Totalcigarreview>\n"
                                 "</soap:Body>\n"
                                 "</soap:Envelope>\n",xmlns,id
                                 ];
        
        // NSLog(@"soap msg : %@", soapMessage);
        NSURL *url = [NSURL URLWithString:webService];
        NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:60.0];
        NSString *msgLength = [NSString stringWithFormat:@"%d", [soapMessage length]];
        
        [theRequest addValue: @"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
        [theRequest addValue: [webService stringByAppendingString:@"/Totalcigarreview"] forHTTPHeaderField:@"SOAPAction"];
        [theRequest addValue: msgLength forHTTPHeaderField:@"Content-Length"];
        [theRequest setHTTPMethod:@"POST"];
        [theRequest setHTTPBody: [soapMessage dataUsingEncoding:NSUTF8StringEncoding]];
        
        NSURLConnection *theConnection = [[NSURLConnection alloc] initWithRequest:theRequest delegate:self];	
        if(theConnection) {
            //webData = [[NSMutableData data] retain];		
        }else {
          //  NSLog(@"The Connection is NULL");
        }
    }
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView.tag == 100){
        
        CustomImagePickerController * picker = [[CustomImagePickerController alloc] init];
        picker.view.tag = 30000;
        picker.delegate = self;
        
        if (buttonIndex == 1) {
            
            if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])  {
                picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentModalViewController:picker animated:YES];
            }
            else{
                UIAlertView *altnot=[[UIAlertView alloc]initWithTitle:@"Camera Not Available" message:@"Camera Not Available" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                altnot.tag=103;
                [altnot show];
                [altnot release];
                
            }
        }
        else if(buttonIndex == 2)
        {
            if ( [popOverController isPopoverVisible] ) {
                [popOverController dismissPopoverAnimated:YES];
            } else {
                
                CustomImagePickerController *picker = [[CustomImagePickerController alloc] init];
                picker.view.tag = 30000;
                picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                picker.navigationBar.barStyle = UIBarStyleBlack;                
                picker.delegate = self;
                
                UIPopoverController *popoverController = [[UIPopoverController alloc] initWithContentViewController:picker];
                
                popoverController.delegate = self;
                CGRect popoverRect = [self.view convertRect:[self.view frame] fromView:[self.view superview]];
                popoverRect.size.width = MIN(popoverRect.size.width, 80);
                popoverRect.origin.x = popoverRect.origin.x + 150;
                [popoverController presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                
                self.popOverController = popoverController;
                
            }
        }

        else{
            [alertView dismissWithClickedButtonIndex:0 animated:YES];
            [self performSelector:@selector(altcancelclicked_fbshare) withObject:nil afterDelay:0.4];

        }
    } else if ( alertView.tag == 200 ) {
        
        CustomImagePickerController * picker = [[CustomImagePickerController alloc] init];
        picker.view.tag = 40000;
        picker.delegate = self;
        
        if (buttonIndex == 1) {
            
            if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])  {
                picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentModalViewController:picker animated:YES];
            }
            else{
                UIAlertView *altnot=[[UIAlertView alloc]initWithTitle:@"Camera Not Available" message:@"Camera Not Available" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                altnot.tag=103;
                [altnot show];
                [altnot release];
                
            }
        }
        else if(buttonIndex == 2)
        {
            if ( [popOverController isPopoverVisible] ) {
                [popOverController dismissPopoverAnimated:YES];
            } else {
                
                CustomImagePickerController *picker = [[CustomImagePickerController alloc] init];
                picker.view.tag = 40000;
                picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                picker.navigationBar.barStyle = UIBarStyleBlack;
                picker.delegate = self;
                
                UIPopoverController *popoverController = [[UIPopoverController alloc] initWithContentViewController:picker];
                
                popoverController.delegate = self;
                CGRect popoverRect = [self.view convertRect:[self.view frame] fromView:[self.view superview]];
                popoverRect.size.width = MIN(popoverRect.size.width, 80);
                popoverRect.origin.x = popoverRect.origin.x + 150;
                [popoverController presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                
                self.popOverController = popoverController;
                
            }
        }
        
    }
//    [alertView dismissWithClickedButtonIndex:0 animated:YES];
}

-(void)altcancelclicked_fbshare{
    
    if ( [[UIDevice currentDevice].systemVersion floatValue] < 6.0 ) {
        
        SHKItem *item;
        
        self.view.autoresizingMask = UIViewAutoresizingNone;
        self.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        item = [SHKItem text:[NSString stringWithFormat:@"#nowsmoking '%@ %@' via Cigar Boss for iPhone", brandLabel.text, typeLabel.text]];
        [SHK setRootViewController:self.navigationController.tabBarController];
        [NSClassFromString(@"SHKFacebook") performSelector:@selector(shareItem:) withObject:item];
        
    } else {
        
        [self facebookShareImage:nil];
        
    }
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    [picker dismissModalViewControllerAnimated:YES];
    
    UIImageView *imgview1=[[UIImageView alloc]initWithImage:[info objectForKey:@"UIImagePickerControllerOriginalImage"]];
    
    if ( picker.view.tag == 30000 ) {
        
        if ( [[UIDevice currentDevice].systemVersion floatValue] < 6.0 ) {
            
            SHKItem *item;
            
            self.view.autoresizingMask = UIViewAutoresizingNone;
            self.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
            NSString *strfb=[NSString stringWithFormat:@"#nowsmoking '%@ %@' via Cigar Boss for iPhone", brandLabel.text, typeLabel.text];
            [strfb retain];
            item = [SHKItem image:imgview1.image title:strfb];
            [SHK setRootViewController:self.navigationController.tabBarController];
            
            // Display the action sheet
            [NSClassFromString(@"SHKFacebook") performSelector:@selector(shareItem:) withObject:item];
            [imgview1 release];
            [strfb release];
            
        } else {
            
            [self performSelector:@selector(facebookShareImage:) withObject:imgview1.image afterDelay:1.0];
        }
        
    } else {
        [self shareImageViaInstagram :imgview1.image];
    }
    
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	webData = [[NSMutableData data] retain];
    // NSLog(@"data = %@ ",webData);
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	[webData appendData:data];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    //	[[ActivityIndicator sharedActivityIndicator]hide];
    
    [appDelegate hideLoadingView];
	NSLog(@"ERROR with theConenction %@",error);
	UIAlertView *connectionAlert = [[UIAlertView alloc] initWithTitle:@"Information !" message:@"Internet / Service Connection Error" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[connectionAlert show];
	[connectionAlert release];
	
	[connection release];
	[webData release];
	
	return;
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    NSLog(@"Connection Did Finish Loading Called");
    userArray = [[NSMutableArray alloc] init];
    tblView.dataSource = nil;
    tblView.delegate = self;
    starReview = @"0";
    CXMLDocument *doc = [[[CXMLDocument alloc] initWithData:webData options:0 error:nil] autorelease];
  //  NSLog(@"Doc = %@ ",doc);
	NSArray *nodes1 = [doc nodesForXPath:@"//return" error:nil];
    
	for (CXMLElement *node in nodes1) {		
		
		for(int counter = 0; counter < [node childCount]; counter++) {		    
            
			if ([[[node childAtIndex:counter] name] isEqualToString:@"Totalreview"]) {					
                if([[[[node childAtIndex:counter] childAtIndex:0] name] isEqualToString:@"review"])
                {
                    starReview = [[[node childAtIndex:counter] childAtIndex:0] stringValue];
                    [starReview retain];
				}
                
                if([[[[node childAtIndex:counter] childAtIndex:1] name] isEqualToString:@"totalrates"])
                {
                    star = [[[node childAtIndex:counter] childAtIndex:1] stringValue];
                    [star retain];
				}
            }
            
            if ([[[node childAtIndex:counter] name] isEqualToString:@"UserList"]) {					
                
                for(int c = 0; c < [[[node childAtIndex:counter] children] count]; c++) {
                //    NSLog(@"Node = %@ ",[[node childAtIndex:counter] childAtIndex:c]);
                    if([[[[node childAtIndex:counter] childAtIndex:c] name] isEqualToString:@"List"])
                    {
                        NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
                        
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:0] name] isEqualToString:@"cigarId"])
                        {
                            NSString *w = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:0] stringValue];
                            [dict setObject:w forKey:@"cigarId"];                                
                        }
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:2] name] isEqualToString:@"brandname"])
                        {
                            NSString *w = @"";
                            w = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:2] stringValue];
                            [dict setObject:w forKey:@"brandname"];                                                        
                        }
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:3] name] isEqualToString:@"username"])
                        {
                            NSString *w = @"";
                            w = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:3] stringValue];
                            [dict setObject:w forKey:@"username"];                                                        
                        }
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:4] name] isEqualToString:@"email"])
                        {
                            NSString *w  = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:4] stringValue];
                            [dict setObject:w forKey:@"email"];                                
                        }
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:5] name] isEqualToString:@"cigType"])
                        {
                            NSString *w  = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:5] stringValue];
                            [dict setObject:w forKey:@"cigType"];                                                        
                        }
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:6] name] isEqualToString:@"startRate"])
                        {
                            NSString *w  = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:6] stringValue];
                            [dict setObject:w forKey:@"startRate"]; 
                        }
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:7] name] isEqualToString:@"dateSmoked"])
                        {
                            NSString *w  = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:7] stringValue];
                            [dict setObject:w forKey:@"dateSmoked"];         
                        }
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:8] name] isEqualToString:@"pricePaid"])
                        {
                            NSString *w  = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:8] stringValue];
                            [dict setObject:w forKey:@"pricePaid"];                                                        
                        }
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:9] name] isEqualToString:@"headline"])
                        {
                            NSString *w  = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:9] stringValue];
                            [dict setObject:w forKey:@"headline"];                                                               
                        }
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:10] name] isEqualToString:@"renote"])
                        {
                            NSString *w  = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:10] stringValue];
                            [dict setObject:w forKey:@"renote"];                                                       
                        }
                        
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:11] name] isEqualToString:@"imageurl"])
                        {
                            NSString *w = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:11] stringValue];
                            [dict setObject:w forKey:@"imageurl"];                                
                        }
                        
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:12] name] isEqualToString:@"rate"])
                        {
                            NSString *w  = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:12] stringValue];
                            [dict setObject:w forKey:@"rate"];                                        
                        }
                        
                        if([[[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:13] name] isEqualToString:@"approve"])
                        {
                            NSString *w = [[[[node childAtIndex:counter] childAtIndex:c] childAtIndex:13] stringValue];
                            [dict setObject:w forKey:@"approve"];                                
                        }
                        
                        [userArray addObject:dict];
                        [userArray retain];
                    }
                }
            }
    	}
    }
    [appDelegate hideLoadingView];
	[connection release];
	[webData release];
    [self setReviewText]; 
    [self setDataInTable];
}


-(void)setDataInTable
{
    if([userArray count] > 0)
    {
        tblView.dataSource = self;
        tblView.hidden = FALSE;
        
        [tblView setFrame:CGRectMake(0, scr + 20, 703, 145*[userArray count])];
        //[scrollView setContentSize:CGSizeMake(320, scr+260)];
        [scrollView setContentSize:CGSizeMake(703, scr+145*[userArray count] + 20)];
        tblView.scrollEnabled=NO;
        scr = scr+145*[userArray count] + 20;
    }
    [appDelegate hideLoadingView];
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
	return 	[userArray count];
}
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 145.0f;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ViewCell"];
    for(UIView *tempView in [cell.contentView subviews]) {
		[tempView removeFromSuperview];
		tempView = nil;
	}
    
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
	}
    
    
	cell.backgroundView = nil;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.contentView.backgroundColor = [UIColor clearColor];
	cell.textLabel.backgroundColor = [UIColor clearColor];
	cell.textLabel.textColor = [UIColor whiteColor];
    
    NSMutableDictionary *dic = [userArray objectAtIndex:indexPath.row];
    
    //NSLog(@">>>>>>>>>>>>>>> \n %@",dic);
    
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(30,21, 600, 20)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentLeft;
    titleLabel.text = [dic objectForKey:@"username"];
    titleLabel.backgroundColor = [UIColor clearColor];

    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:22];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    [cell.contentView addSubview:titleLabel];
    [titleLabel release];
    titleLabel = nil;
    
    //============================ Star in TableView Cell ============================
    
    if([[dic objectForKey:@"startRate"] floatValue])
    {
        float xVal = 0;
        UIView *starV = [[UIView alloc] initWithFrame:CGRectMake(30, 40, 600, 30)];
        int starVal = [[dic objectForKey:@"startRate"] intValue];
        for (int k = 1; k <= 5 ; k++) {
            UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(xVal, 5, 30, 30)];
            [starV addSubview:btn];
            [btn setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
            [btn setUserInteractionEnabled:NO];
            
            if(k <= starVal)
            {
                [btn setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];       
            }
            [btn release];
            xVal += 31;
        }
        [cell.contentView addSubview:starV];
    }
    //===============================================================================
    
    
    UILabel *lbldate;
    lbldate = [[UILabel alloc] initWithFrame:CGRectMake(30, 75, 600, 20)];
    lbldate.numberOfLines = 1;
    lbldate.text =[NSString stringWithFormat:@"Date Smoked : %@",[dic objectForKey:@"dateSmoked"]]  ;
    [lbldate alignTop];
    lbldate.backgroundColor = [UIColor clearColor];
    lbldate.textColor = [UIColor whiteColor];
    lbldate.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    titleLabel.minimumFontSize = 10;
    [cell.contentView addSubview:lbldate];
    [lbldate release];
    lbldate = nil;
    
    UILabel *lblheadline;
    lblheadline = [[UILabel alloc] initWithFrame:CGRectMake(30, 100, 600, 15)];
    lblheadline.numberOfLines = 1;
    lblheadline.text =[NSString stringWithFormat:@"Headline : %@",[dic objectForKey:@"headline"]]  ;
    [lblheadline alignTop];
    lblheadline.backgroundColor = [UIColor clearColor];
    lblheadline.textColor = [UIColor whiteColor];
    lblheadline.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    lbldate.minimumFontSize = 10;
    [cell.contentView addSubview:lblheadline];
    [lblheadline release];
    lblheadline = nil;
    
    UILabel *lbldescType;
    lbldescType = [[UILabel alloc] initWithFrame:CGRectMake(30, 115, 650, 30)];
    lbldescType.numberOfLines = 2;
    lbldescType.text =[NSString stringWithFormat:@"Note : %@",[dic objectForKey:@"renote"]]  ;
    [lbldescType alignTop];
    lbldescType.backgroundColor = [UIColor clearColor];
    lbldescType.textColor = [UIColor whiteColor];
    lbldescType.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    titleLabel.minimumFontSize = 10;
    [cell.contentView addSubview:lbldescType];
    [lbldescType release];
    lbldescType = nil;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
	ViewUserReview *vur = [[ViewUserReview alloc] initWithNibName:@"ViewUserReview" bundle:nil];
    vur.dictObj = [userArray objectAtIndex:indexPath.row];
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:vur animated:YES];  
}

-(NSString*) trimString:(NSString *)theString 
{
    NSString *theStringTrimmed = [theString stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return theStringTrimmed;
}

-(NSString *) removeNull:(NSString *) string {    
    
    NSRange range = [string rangeOfString:@"null"];
    
    if (range.length > 0 || string == nil) {
        string = @"";
    }
    string = [self trimString:string];
    return string;
}



-(void)setReviewText
{
    if ( starReview == nil )
        starReview = @"0";
    
    [totRevLabel setText:[NSString stringWithFormat:@"Total Reviews : %@",starReview]];
    [objRatingView setRating:[star floatValue]];
}

- (void)viewWillAppear:(BOOL)animated
{
    id appDelegate = [[UIApplication sharedApplication] delegate];
    NSMutableArray *cigarArray = [appDelegate findWishlistMatch:self.cigar];
    if(cigarArray){
        [btnMyWishList setImage:[UIImage imageNamed:@"Add2WishListCheckedButton.png"] forState:UIControlStateNormal];
    } else {
        [btnMyWishList setImage:[UIImage imageNamed:@"Add2WishList.png"] forState:UIControlStateNormal];
    }
    
    if(isUpdate){
        [self StarRateWebFunction :cigar.brandId];
        CGRect frame = scrollView.frame;
        frame.size.height = 367;
        scrollView.frame = frame;
        isUpdate = NO;
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    
}

- (IBAction)shareInstagramButtonClicked:(id)sender
{
    UIAlertView *alttakePhoto = [[UIAlertView alloc]initWithTitle:@"Select Photo" message:@"Please Select Source For Share Photo If You Want" delegate:self cancelButtonTitle:@"Without Photo" otherButtonTitles:@"Take Photo",@"Library", nil];
    alttakePhoto.tag = 200;
    [alttakePhoto show];
    [alttakePhoto release];
}

-(IBAction)onRevBtnClick:(id)sender
{
   // isUpdate = YES;
    userDefault = [NSUserDefaults standardUserDefaults];
    
    
    NSString *uname = [userDefault objectForKey:@"isChecked"]; 
    
    
    
    if([uname isEqualToString:@"UserName"])
    {
        FillReviewFormViewController *frf = [[FillReviewFormViewController alloc]initWithNibName:@"FillReviewFormViewController" bundle:nil];
        [frf setParent:self];
        frf.brandId = cigar.brandId ;
        frf.type = cigar.type;
        frf.brandName = cigar.brand;
        [self presentModalViewController:frf animated:YES];
        frf.callingViewController = self;
        
        
        // [self.navigationController pushViewController:frf animated:YES];
    }
    else
    {
        ShareReviewViewController *shRev = [[ShareReviewViewController alloc]initWithNibName:@"ShareReviewViewController" bundle:nil];
        shRev.brandId = cigar.brandId;   
        [shRev setParent:self];
        shRev.type = cigar.type;
        shRev.brandName = cigar.brand;
        shRev.title = @"Reviewer's Detail form";
        self.navigationItem.title=@"Back";
        [self.navigationController pushViewController:shRev animated:YES];
    }
    
}
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
 //   starReview = @"0";
    
    appDelegate =(CigarBossAppDelegate *) [[UIApplication sharedApplication] delegate];
        
    if (cigar.twit.length > 0) {
        
        twitString = [NSString stringWithFormat:@"#nowsmoking @BURNbyRP %@ %@ %@ via @Cigar_Boss_APP for iPad",cigar.twit, cigar.brand, cigar.type];
        
    }else
    {
        twitString = [NSString stringWithFormat:@"#nowsmoking @BURNbyRP  %@ %@ via @Cigar_Boss_APP for iPad", cigar.brand, cigar.type];
    }
    
    [twitString retain];
    
    photoArray = [[NSMutableArray alloc]init];
   // userArray = [[NSMutableArray alloc]init];
    
    
    if(loadedAlready){
        for(UILabel *label in adjustedLabels){
            label.alpha = 0.0;
            [label release];
        }
        [objRatingView removeFromSuperview];
        [lblstar removeFromSuperview];
        [adjustedLabels removeAllObjects];
     //   [tblView removeFromSuperview];
        
    }
    
    
    tblView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 703, 200)];
    tblView.hidden = TRUE;
    tblView.delegate = self;
    tblView.backgroundColor = [UIColor clearColor];
    [scrollView addSubview:tblView];    

    btnRev = [[UIButton alloc]init];
    
    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc]
                                             initWithTarget:self action:@selector(ClickEventOnImage:)];
    [tapRecognizer setNumberOfTouchesRequired:1];
    [tapRecognizer setDelegate:self];
    
    //Don't forget to set the userInteractionEnabled to YES, by default It's NO.
    imageView.userInteractionEnabled = YES;
    [imageView addGestureRecognizer:tapRecognizer];
	
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 703, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text = cigar.brand;
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:22];
    titleLabel.minimumFontSize = 18;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
//    self.navigationItem.title = cigar.brand;
    
    [titleLabel release];
    titleLabel = nil;
    typeLabel.text = [NSString stringWithFormat:@"%@ - %@ x %@", cigar.type,cigar.length,cigar.ring];
    
	typeLabel.text = cigar.type;
	brandLabel.text = cigar.brand;
    
//    facebookButton.frame = CGRectMake(488, 125, facebookButton.frame.size.width, facebookButton.frame.size.height);
//    twitterButton.frame = CGRectMake(378, 125, twitterButton.frame.size.width, twitterButton.frame.size.height);
    
    if ( [cigar.price isEqualToString:@"N/A"] )
        priceLabel.text = [NSString stringWithFormat:@"Price: %@", cigar.price];
    else
        priceLabel.text = [NSString stringWithFormat:@"Price: $ %@", cigar.price];
    
	cigarLabel.text = [NSString stringWithFormat:@"Cigar: %@", cigar.type];
	//sizeLabel.text = [NSString stringWithFormat:@"Size: %@", cigar.size];
	lengthLabel.text = [NSString stringWithFormat:@"Length: %@", cigar.length];
	ringLabel.text = [NSString stringWithFormat:@"Ring Gauge: %@", cigar.ring];
	countryLabel.text = [NSString stringWithFormat:@"Country: %@", cigar.country];
	colorLabel.text = [NSString stringWithFormat:@"Wrapper: %@", cigar.wrapper];
    //	originLabel.text = [NSString stringWithFormat:@"Origin: %@", cigar.origin];
	strengthLabel.text = [NSString stringWithFormat:@"Strength: %@", cigar.strength];
	descriptionLabel.text = cigar.generalInfo;
	CGSize maxSize = CGSizeMake(600, MAXFLOAT);
	CGSize newSize = [descriptionLabel.text sizeWithFont:descriptionLabel.font
									   constrainedToSize:maxSize
										   lineBreakMode:descriptionLabel.lineBreakMode];
	
	descriptionLabel.frame = CGRectMake(descriptionLabel.frame.origin.x,
										descriptionLabel.frame.origin.y,
										newSize.width,
										newSize.height);
    
    if ( mShowType == 1 ) {
        
        if ( [cigar.boxprice isEqualToString:@"0"] )
            boxPriceLabel.text = [NSString stringWithFormat:@"Box Price: %@", @"N/A"];
        else
            boxPriceLabel.text = [NSString stringWithFormat:@"Box Price: $ %@", cigar.boxprice];
        
    } else {
        boxPriceLabel.text = [NSString stringWithFormat:@"Box Price: %@", @"Not Available"];
    }

	
	float scrollViewHeight = descriptionLabel.frame.origin.y + newSize.height;
	[scrollView setContentSize:CGSizeMake(703, scrollViewHeight)];
    
    //4 photos
    if(forFeaturedCigar){
        scrollViewHeight += 50;
        AsyncImageView *photo1 = [[AsyncImageView alloc] initWithFrame:CGRectMake(descriptionLabel.frame.origin.x, scrollViewHeight, 300, 200)];
        AsyncImageView *photo2 = [[AsyncImageView alloc] initWithFrame:CGRectMake(350, scrollViewHeight, 300, 200)];
        scrollViewHeight += 230;
        AsyncImageView *photo3 = [[AsyncImageView alloc] initWithFrame:CGRectMake(descriptionLabel.frame.origin.x, scrollViewHeight, 300, 200)];
        AsyncImageView *photo4 = [[AsyncImageView alloc] initWithFrame:CGRectMake(350, scrollViewHeight, 300, 200)];
        
        scrollViewHeight += 100;
        
        [scrollView addSubview:photo1];
        [scrollView addSubview:photo2];
        [scrollView addSubview:photo3];
        [scrollView addSubview:photo4];
        
        NSMutableArray *photos = [appDelegate featuredPhotos];
        photoArray = photos;
        
        @try {
            NSString *url1 = [photos objectAtIndex:0];
            if([url1 rangeOfString:@"http://"].location == NSNotFound){
                url1 = [@"http://" stringByAppendingString:[photos objectAtIndex:0]];
            }
            [photo1 setAlpha:1.0];
            photo1.tag = 0;
            [photo1 setBackgroundColor:[UIColor clearColor]];
            //            [photo1 loadImageFromURL:[NSURL URLWithString:url1]];
            [photo1 loadImageFromURL:[NSURL URLWithString:url1] : [cigar.brand stringByAppendingFormat:@"%d",1]];            
            UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc]
                                                     initWithTarget:self action:@selector(ClickEventOnImage:)];
            [tapRecognizer setNumberOfTouchesRequired:1];
            [tapRecognizer setDelegate:self];
            //Don't forget to set the userInteractionEnabled to YES, by default It's NO.
            photo1.userInteractionEnabled = YES;
            [photo1 addGestureRecognizer:tapRecognizer];
        }
        @catch (NSException * e) {
        }
        
        @try {
            NSString *url1 = [photos objectAtIndex:1];
            if([url1 rangeOfString:@"http://"].location == NSNotFound){
                url1 = [@"http://" stringByAppendingString:[photos objectAtIndex:1]];
            }
            [photo2 setAlpha:1.0];
            photo2.tag = 1;
            [photo2 setBackgroundColor:[UIColor clearColor]];
            // [photo2 loadImageFromURL:[NSURL URLWithString:url1]];
            [photo2 loadImageFromURL:[NSURL URLWithString:url1] : [cigar.brand stringByAppendingFormat:@"%d",2]];
            UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc]
                                                     initWithTarget:self action:@selector(ClickEventOnImage:)];
            [tapRecognizer setNumberOfTouchesRequired:1];
            [tapRecognizer setDelegate:self];
            //Don't forget to set the userInteractionEnabled to YES, by default It's NO.
            photo2.userInteractionEnabled = YES;
            [photo2 addGestureRecognizer:tapRecognizer];
        }
        @catch (NSException * e) {
        }
        
        @try {
            NSString *url1 = [photos objectAtIndex:2];
            if([url1 rangeOfString:@"http://"].location == NSNotFound){
                url1 = [@"http://" stringByAppendingString:[photos objectAtIndex:2]];
            }
            [photo3 setAlpha:1.0];
            photo3.tag = 2;
            [photo3 setBackgroundColor:[UIColor clearColor]];
            //            [photo3 loadImageFromURL:[NSURL URLWithString:url1]];
            [photo3 loadImageFromURL:[NSURL URLWithString:url1] : [cigar.brand stringByAppendingFormat:@"%d",3]];
            UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc]
                                                     initWithTarget:self action:@selector(ClickEventOnImage:)];
            [tapRecognizer setNumberOfTouchesRequired:1];
            [tapRecognizer setDelegate:self];
            //Don't forget to set the userInteractionEnabled to YES, by default It's NO.
            photo3.userInteractionEnabled = YES;
            [photo3 addGestureRecognizer:tapRecognizer];
        }
        @catch (NSException * e) {
        }
		
        @try {
            NSString *url1 = [photos objectAtIndex:3];
            if([url1 rangeOfString:@"http://"].location == NSNotFound){
                url1 = [@"http://" stringByAppendingString:[photos objectAtIndex:3]];
            }
            [photo4 setAlpha:1.0];
            photo4.tag = 3;
            [photo4 setBackgroundColor:[UIColor clearColor]];
            //[photo4 loadImageFromURL:[NSURL URLWithString:url1]];
            [photo4 loadImageFromURL:[NSURL URLWithString:url1] : [cigar.brand stringByAppendingFormat:@"%d",4]];
            UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc]
                                                     initWithTarget:self action:@selector(ClickEventOnImage:)];
            [tapRecognizer setNumberOfTouchesRequired:1];
            [tapRecognizer setDelegate:self];
            //Don't forget to set the userInteractionEnabled to YES, by default It's NO.
            photo4.userInteractionEnabled = YES;
            [photo4 
             addGestureRecognizer:tapRecognizer];
        }
        @catch (NSException * e) {
        }
        
        scrollViewHeight += 110;
    }
    
    //NOTES
    scrollViewHeight += 17;
    OHAttributedLabel *myNotesLabel1 = [[OHAttributedLabel alloc] initWithFrame:CGRectMake(descriptionLabel.frame.origin.x, scrollViewHeight, 200, 30)];
    myNotesLabel1.textColor = [UIColor whiteColor];
    myNotesLabel1.backgroundColor = [UIColor clearColor];
    myNotesLabel1.font = [UIFont fontWithName:@"Copperplate-Bold" size:22];
    myNotesLabel1.text = @"My Notes:";
    myNotesLabel1.parentView = self;
    [scrollView addSubview:myNotesLabel1];
    
    
    NSMutableArray *myNotesForThisCigar = [appDelegate findNotesMatch:cigar];
    if(myNotesForThisCigar){
        OHAttributedLabel *myNotesLabel = [[OHAttributedLabel alloc] initWithFrame:CGRectMake(descriptionLabel.frame.origin.x, scrollViewHeight-5, 600, 20)];
        myNotesLabel.myNotes = YES;
        myNotesLabel.textColor = [UIColor whiteColor];
        myNotesLabel.numberOfLines = 0;
        myNotesLabel.parentView = self;
//        myNotesLabel.font = descriptionLabel.font;
//        myNotesLabel.font = [UIFont boldSytemFontofSize:descriptionLabel];
        myNotesLabel.font = [UIFont fontWithName:@"Copperplate" size:22];
        //myNotesLabel.lineHeight = 16.0;
        myNotesLabel.clipsToBounds = NO;
        
        NSMutableString *finalMyNotesLabel = [[NSMutableString alloc] init];
        int i = 0;
        //myNotesLabel.lineBreakMode = descriptionLabel.lineBreakMode;
        // for those calls we don't specify a range so it affects the whole string
        //[attrStr setFont:[UIFont systemFontOfSize:22]];
        //[attrStr setTextColor:[UIColor grayColor]];
        
        // now we only change the color of "Hello"
        //[attrStr setTextColor:[UIColor redColor] range:NSMakeRange(0,5)];	
        
        /**(2)** Affect the NSAttributedString to the OHAttributedLabel *******/
        //label1.attributedText = attrStr;
        // and add a link to the "share your food!" text
        for(NSDictionary *saveDict in [myNotesForThisCigar objectAtIndex:1]){
            
            if(i == 0){
                NSDate *date = [saveDict objectForKey:@"date"];
                
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
                NSString *ii = [NSString stringWithFormat:@"%@ - %@ - %@ points", [saveDict objectForKey:@"location"], [dateFormatter stringFromDate:date], [saveDict objectForKey:@"score0or100"]];
                [finalMyNotesLabel appendString:ii];
            } else {
                NSDate *date = [saveDict objectForKey:@"date"];
                
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
                NSString *ii = [NSString stringWithFormat:@"%@ - %@ - %@ points", [saveDict objectForKey:@"location"], [dateFormatter stringFromDate:date], [saveDict objectForKey:@"score0or100"]];
                [finalMyNotesLabel appendFormat:@"\n%@", ii];
            }    
            i++;
        }
        
        i = 0;
        for(NSDictionary *saveDict in [myNotesForThisCigar objectAtIndex:1]){
            NSDate *date = [saveDict objectForKey:@"date"];
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
            NSString *ii = [NSString stringWithFormat:@"%@ - %@ - %@ points", [saveDict objectForKey:@"location"], [dateFormatter stringFromDate:date], [saveDict objectForKey:@"score0or100"]];
            
            [myNotesLabel addCustomLink:[NSURL URLWithString:[NSString stringWithFormat:@"%d", i]] inRange:[finalMyNotesLabel rangeOfString:ii]];
            i++;
        }
        
        myNotesLabel.backgroundColor = [UIColor clearColor];
        //myNotesLabel.text = finalMyNotesLabel;
        //NSMutableAttributedString *attrStr = [NSMutableAttributedString attributedStringWithString:[finalMyNotesLabel copy]];
        //[attrStr setFont:myNotesLabel.font];
        //[attrStr setTextColor:myNotesLabel.textColor];
        //myNotesLabel.attributedText = attrStr;
        myNotesLabel.text = finalMyNotesLabel;
        //[finalMyNotesLabel release];
        /*for(NSDictionary *review in cigar.reviews){
         [myNotesLabel addCustomLink:[NSURL URLWithString:[[review allValues] objectAtIndex:0]] inRange:[finalMyNotesLabel rangeOfString:[[review allKeys] objectAtIndex:0]]];
         
         }*/
        [adjustedLabels addObject:myNotesLabel];
        [finalMyNotesLabel release];
        scrollViewHeight += 42;
        newSize = [myNotesLabel.text sizeWithFont:myNotesLabel.font
                                constrainedToSize:maxSize
                                    lineBreakMode:descriptionLabel.lineBreakMode];
        myNotesLabel.frame = CGRectMake(descriptionLabel.frame.origin.x, 5+scrollViewHeight-2, 600, newSize.height+3);
        scrollViewHeight += 5 + 40 + newSize.height+7;
        [scrollView addSubview:myNotesLabel];
        scrollViewHeight -= 39;
    } else {
        scrollViewHeight += 49;
    }
    
    addNoteButton.frame = CGRectMake(descriptionLabel.frame.origin.x, scrollViewHeight, 266, 38);
    [scrollView addSubview:addNoteButton];
    
    scrollViewHeight += 38;
    
	UILabel *reviewLabel = [[UILabel alloc] initWithFrame:CGRectMake(descriptionLabel.frame.origin.x, scrollViewHeight+20, 703, 20)];
	reviewLabel.text = @"Blog Reviews - Click To Read";
    reviewLabel.font = [UIFont fontWithName:@"Copperplate-Bold" size:22];
    [adjustedLabels addObject:reviewLabel];
    
    UILabel *clickToRead = [[UILabel alloc] initWithFrame:reviewLabel.frame];
    clickToRead.font = clickToRateLabel.font;
    [adjustedLabels addObject:clickToRead];
    clickToRead.textColor = clickToRateLabel.textColor;
    CGRect clickFrame = clickToRead.frame;
    clickFrame.origin.x += 105;
    //    clickFrame.origin.y += 2;
    clickToRead.backgroundColor = [UIColor clearColor];
    clickToRead.frame = clickFrame;
    clickToRead.text = @"";

    [clickToRead setFont:[UIFont fontWithName:@"Copperplate-Bold" size:22]];
    clickToRead.font = [UIFont fontWithName:@"Copperplate-Bold" size:22];
    
    [scrollView addSubview:clickToRead];
    
    
    
    NSMutableArray *cigarArray = [appDelegate findHumidorMatch:self.cigar];
    if(cigarArray){
        humidorCountLabel.text = [cigarArray objectAtIndex:1];
    }
    
	[scrollView addSubview:reviewLabel];
	scrollViewHeight += 50;
	[scrollView setContentSize:CGSizeMake(703, scrollViewHeight)];
	
	OHAttributedLabel *reviewsLabel = [[OHAttributedLabel alloc] initWithFrame:CGRectMake(16, scrollViewHeight-5, 287, 30)];
	reviewsLabel.numberOfLines = 0;
    reviewsLabel.parentView = self;
	reviewsLabel.font = descriptionLabel.font;
    reviewsLabel.userInteractionEnabled = YES;
    [reviewsLabel setFont:[UIFont fontWithName:@"Copperplate" size:22]];
	NSMutableString *finalReviewsString = [[NSMutableString alloc] init];
	int y = 0;
    [adjustedLabels addObject:reviewsLabel];
	reviewsLabel.lineBreakMode = descriptionLabel.lineBreakMode;
	
	for(NSDictionary *review in cigar.reviews){
		if(y == 0){
			[finalReviewsString appendString:[[review allKeys] objectAtIndex:0]];
		} else {
			[finalReviewsString appendFormat:@"\n\n%@", [[review allKeys] objectAtIndex:0]];
		}
		y++;
	}
	reviewsLabel.backgroundColor = [UIColor clearColor];
	reviewLabel.backgroundColor = [UIColor clearColor];
	
	reviewsLabel.text = finalReviewsString;
	//[finalReviewsString release];
	for(NSDictionary *review in cigar.reviews){
		[reviewsLabel addCustomLink:[NSURL URLWithString:[[review allValues] objectAtIndex:0]] inRange:[finalReviewsString rangeOfString:[[review allKeys] objectAtIndex:0]]];
        
	}
	[finalReviewsString release];
	newSize = [reviewsLabel.text sizeWithFont:reviewsLabel.font
							constrainedToSize:maxSize
								lineBreakMode:reviewsLabel.lineBreakMode];
	reviewsLabel.frame = CGRectMake(descriptionLabel.frame.origin.x, 5+scrollViewHeight, 287, newSize.height+20);
	scrollViewHeight += 5 + 20 + newSize.height+7;
	[scrollView addSubview:reviewsLabel];
    
       scrollViewHeight += 10;
    
    lblUserReview.frame = CGRectMake(descriptionLabel.frame.origin.x, scrollViewHeight, 125, 25);
    lblUserReview.text = @"User Reviews:";
    lblUserReview.font = [UIFont fontWithName:@"Copperplate-Bold" size:22];
    [scrollView addSubview:lblUserReview];  
    
    
    
    btnReviewNew.frame = CGRectMake(200, scrollViewHeight, 155, 27);
    [scrollView addSubview:btnReviewNew];
    
    
    scrollViewHeight = scrollViewHeight + 50;
    
    lblstar =[[UILabel alloc]initWithFrame:CGRectMake(250, scrollViewHeight - 5, 180, 25)];
    lblstar.text = @"Average Rating";
    lblstar.font = [UIFont fontWithName:@"Copperplate" size:22];
    lblstar.backgroundColor = [UIColor clearColor];
    [scrollView addSubview:lblstar];
    
    scrollViewHeight += 20;
    
    
    NSMutableArray *ratingA = [appDelegate findCigarMatch:cigar];

    int rate = (int)[[ratingA objectAtIndex:1] floatValue];
   // NSLog(@">>>>>>>>>> Rate Value = %d ",rate);
    [ratingsView setRating:rate];
    [rView setCigar:cigar];
    rView.test = rate;
    
    totRevLabel.frame = CGRectMake(descriptionLabel.frame.origin.x, scrollViewHeight, 250, 25);
    [scrollView addSubview:totRevLabel];
    
    objRatingView = [[RatingView alloc] initWithFrame:CGRectMake(250, scrollViewHeight, 175, 30)];
    [objRatingView setClipsToBounds:YES];
    [scrollView addSubview:objRatingView];
    
    scrollViewHeight += 35;
	[scrollView setContentSize:CGSizeMake(703, scrollViewHeight + 40)];
	
    scr = scrollViewHeight;
    
	//BOOL white = NO;
	for(UILabel *lbl in [scrollView subviews]){
		if(![lbl isKindOfClass:[UILabel class]]) continue;
		//lbl.textColor = [UIColor lightGrayColor];
		//if(white == NO){
        lbl.textColor = [UIColor whiteColor];
        //white = YES;
		//} else white = NO;
		lbl.shadowColor = [UIColor colorWithWhite:.2 alpha:.6];
		lbl.shadowOffset = CGSizeMake(0, -1.0);
	}
	
	reviewLabel.textColor = [UIColor whiteColor];
    
    if ( cigar.isOutOfStock == YES ) {
        
        [imgView setImage:[UIImage imageNamed:@"out_of_stock.png"]];
        
    } else {
        
        if(pass)
        {
            NSFileManager *fileManager = [NSFileManager defaultManager];
            if ([fileManager fileExistsAtPath:cigar.pictureURL] == YES) {
                [self imageFromImagePath:cigar.pictureURL];
                imageView.hidden = TRUE;
            }
        }
        else
        {
            NSString *imagePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png",cigar.brand]];
            
            NSFileManager *fileManager = [NSFileManager defaultManager];
            
            if ([fileManager fileExistsAtPath:imagePath] == YES) {
                [imageView imageFromImagePath:imagePath];
                pathOfImage = [NSString stringWithFormat:@"%@",imagePath];
            }
            else
            {
                //            NSString *url = cigar.pictureURL;
                //            if([url rangeOfString:@"http://"].location == NSNotFound){
                //                url = [@"http://" stringByAppendingString:cigar.pictureURL];
                //            }
                //            [imageView setAlpha:1.0]; [imageView setBackgroundColor:[UIColor clearColor]];
                //            [imageView loadImageFromURL:[NSURL URLWithString:url] : cigar.brand];
                NSString *url = cigar.pictureURL;
                
                
                if([url rangeOfString:@"/var"].location != NSNotFound)
                {
                    [imageView setAlpha:1.0]; [imageView setBackgroundColor:[UIColor clearColor]];
                    [imageView imageFromImagePath:url];
                    pathOfImage = [NSString stringWithFormat:@"%@",url];
                    
                    btnReviewNew.hidden = YES;
                    lblUserReview.hidden = YES;
                    lblstar.hidden = YES;
                    totRevLabel.hidden = YES;
                    objRatingView.hidden = YES;
                    reviewLabel.hidden = YES;
                    clickToRead.hidden = YES;
                    [scrollView setContentSize:CGSizeMake(703, scrollViewHeight - 120)];
                    
                }else{
                    
                    if([url rangeOfString:@"http://"].location == NSNotFound){
                        url = [@"http://" stringByAppendingString:cigar.pictureURL];
                    }
                    [imageView setAlpha:1.0]; [imageView setBackgroundColor:[UIColor clearColor]];
                    [imageView loadImageFromURL:[NSURL URLWithString:url] : cigar.brand];
                    pathOfImage = [NSString stringWithFormat:@"%@/%@.png",imagePath,cigar.brand];
                    // NSLog(@">>>>%@ ",pathOfImage); 
                }
            }
            imgView.hidden = TRUE;
            scr = scrollViewHeight;
        }
        
    }
    loadedAlready = YES;
    [self setReviewText];
    
    [self.navigationController setNavigationBarHidden:NO animated:NO];

//    [tblView reloadData];
}  
-(NSString *)applicationDocumentsDirectory {
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
	return basePath;
}
-(void) imageFromImagePath : (NSString *) path {
    
    UIImage *img = [UIImage imageWithContentsOfFile:path];
    
    [imgView setImage:img];
}
- (IBAction)addToMyList{
    [btnMyWishList setImage:[UIImage imageNamed:@"Add2WishListCheckedButton.png"] forState:UIControlStateNormal];
    id appDelegate = [[UIApplication sharedApplication] delegate];
    NSMutableArray *cigarArray = [appDelegate findWishlistMatch:self.cigar];
    if(cigarArray){
        
    } else {
        cigarArray = [[NSMutableArray alloc] initWithCapacity:2];
        [cigarArray addObject:cigar];
        [cigarArray addObject:[NSString stringWithFormat:@"%d", 1]];
        [appDelegate addWishlist:cigarArray];
        [appDelegate saveWishListData];
    }
    
}
- (void)displayNoteViewControllerWithIntId:(int)Id
{
    ViewNoteViewController *viewNote = [[ViewNoteViewController alloc] initWithNibName:@"ViewNoteViewController" bundle:nil];
    NSMutableArray *myNotesForThisCigar = [[appDelegate findNotesMatch:cigar] objectAtIndex:1];
    viewNote.note = [myNotesForThisCigar objectAtIndex:Id];
    [self presentModalViewController:viewNote animated:YES];
}

- (void)addNote
{
    AddNoteViewController *addNoteViewController = [[AddNoteViewController alloc] initWithNibName:@"AddNoteViewController" bundle:[NSBundle mainBundle]];
    [addNoteViewController setCigar:self.cigar];
    addNoteViewController.scrollSize = scr;
    addNoteViewController.callingViewController = self;
    [self presentModalViewController:addNoteViewController animated:YES];
}

- (IBAction)addToHumidors
{
    id appDelegate = [[UIApplication sharedApplication] delegate];
    NSMutableArray *cigarArray = [appDelegate findHumidorMatch:self.cigar];
    if(cigarArray){
        NSString *humidorCurrentCount = [cigarArray objectAtIndex:1];
        int count = [humidorCurrentCount intValue];
        count++;
        if(count > 99) count = 99;
        /*NSArray *oArray = cigarArray;
         cigarArray = [[NSMutableArray alloc] initWithCapacity:2];
         [cigarArray addObject:cigar];
         [cigarArray addObject:[NSString stringWithFormat:@"%d", rating]];
         [appDelegate addFavorite:cigarArray];
         [[appDelegate ratings] replaceObjectAtIndex:[[appDelegate ratings] indexOfObject:oArray] withObject:cigarArray];
         */[cigarArray replaceObjectAtIndex:1 withObject:[NSString stringWithFormat:@"%d", count]];
        humidorCountLabel.text = [NSString stringWithFormat:@"%d", count];
        [appDelegate saveHumidorData];
    } else {
        cigarArray = [[NSMutableArray alloc] initWithCapacity:2];
        [cigarArray addObject:cigar];
        [cigarArray addObject:[NSString stringWithFormat:@"%d", 1]];
        [appDelegate addHumidor:cigarArray];
        humidorCountLabel.text = @"1";
        [appDelegate saveHumidorData];
    }
}

- (void) shareImageViaInstagram : (UIImage *) image
{
    NSString  *jpgPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/share.igo"];
    
    [UIImagePNGRepresentation(image) writeToFile:jpgPath atomically:YES];
    
    NSURL *igImageHookFile = [NSURL fileURLWithPath:jpgPath];
    
    self.mDic.UTI = @"com.instagram.photo";
    self.mDic = [self setupControllerWithURL:igImageHookFile usingDelegate:self];
    self.mDic=[UIDocumentInteractionController interactionControllerWithURL:igImageHookFile];
    [self.mDic presentOpenInMenuFromRect:CGRectMake(0, 0, 320, 480) inView:self.view animated: YES ];
}

- (UIDocumentInteractionController *) setupControllerWithURL: (NSURL*) fileURL usingDelegate: (id <UIDocumentInteractionControllerDelegate>) interactionDelegate {
    UIDocumentInteractionController *interactionController = [UIDocumentInteractionController interactionControllerWithURL: fileURL];
    interactionController.delegate = interactionDelegate;
    return interactionController;
}

#pragma mark -
#pragma mark Managing the popover

- (void)showRootPopoverButtonItem:(UIBarButtonItem *)barButtonItem {
    
    // Add the popover button to the toolbar.
    
    /*
    NSMutableArray *itemsArray = [mToolBar.items mutableCopy];
    [itemsArray insertObject:barButtonItem atIndex:0];
    [mToolBar setItems:itemsArray animated:NO];
    [itemsArray release];
     */
}


- (void)invalidateRootPopoverButtonItem:(UIBarButtonItem *)barButtonItem {
    
    // Remove the popover button from the toolbar.
    
    /*
    NSMutableArray *itemsArray = [mToolBar.items mutableCopy];
    [itemsArray removeObject:barButtonItem];
    [mToolBar setItems:itemsArray animated:NO];
    [itemsArray release];
     */
}

#pragma mark UIInterfaceOrientation delegate

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (toInterfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [popOverController release];
    [super dealloc];
}

#pragma mark MFMailComposeView Delegate

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
			//flagFromPicker = TRUE;
			//[HaikuAppDelegate showAlertTitle:@"Result" message:@"Mail sending canceled."];
			break;
		case MFMailComposeResultSaved: {
			break;
		}
		case MFMailComposeResultSent: {
			break;
		}
		case MFMailComposeResultFailed: {
			break;
		}
		default: {
			break;
		}
	}
    
    [controller dismissViewControllerAnimated:YES completion:nil];
}

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [controller dismissViewControllerAnimated:YES completion:nil];
}


@end
