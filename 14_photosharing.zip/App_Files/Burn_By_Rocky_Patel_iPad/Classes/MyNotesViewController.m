//
//  MyNotesViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 11/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyNotesViewController.h"
#import "CustomHighlightedCell.h"
#import "Cigar.h"
#import "MyNotesViewController2.h"
#import "CigarBossAppDelegate.h"

CigarBossAppDelegate *appDelegate;

@implementation MyNotesViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        id appDelegate = [[UIApplication sharedApplication] delegate];
        NSMutableArray *tempNotes = [[NSMutableArray alloc] init];
        for(NSArray *noteA in [appDelegate notes]){
            [tempNotes addObject:[noteA objectAtIndex:0]];
        }
        
        NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"brand" ascending:YES];
        notes = [[tempNotes sortedArrayUsingDescriptors:[NSArray arrayWithObject:sort]] retain];
        [tempNotes release];
        notes = [[NSMutableArray alloc] initWithArray:notes];
        UIBarButtonItem *editBtn = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(edit)];
        self.navigationItem.rightBarButtonItem = editBtn;
        //NSLog([notes description]);
    }
    return self;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [notes count]+1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BrandCell"];
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"BrandCell"] autorelease];
	}
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.textLabel.textColor = [UIColor whiteColor];
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    if([notes count] != indexPath.row){
        cell.textLabel.text = [[notes objectAtIndex:indexPath.row] brand];
        cell.detailTextLabel.text = [[notes objectAtIndex:indexPath.row] type];
        cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:22];
	}else
    {
        cell.backgroundColor = [UIColor clearColor];
        UIView *vie = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 703, 60)];
        [vie setBackgroundColor:[UIColor clearColor]];
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(50,2, 500, 40)];
        lbl.font = [UIFont fontWithName:@"Copperplate" size:22.0];
        lbl.text = @"Click Plus Sign To Add";
        lbl.textColor = [UIColor whiteColor];
        [lbl setBackgroundColor:[UIColor clearColor]];
        [vie addSubview:lbl];
        
        UIButton *button11 = [UIButton buttonWithType:UIButtonTypeContactAdd];
        [button11 addTarget:self action:@selector(onAddbtnClick:) forControlEvents:UIControlEventTouchUpInside];
        button11.frame = CGRectMake(660, 7, 30, 30);
        [vie addSubview:button11];
        
        [cell.contentView addSubview:vie];
    }
    
	return cell;
}
- (IBAction)onbtnEditClick:(id)sender
{
    [mainTableView setEditing:!mainTableView.editing animated:YES];
    //    UIButton *btn = (UIButton *) [self.view viewWithTag:88];
    
    UIButton *btn2 = (UIButton *) sender;
    if(btn2.tag == 88){
        [btn2 setTitle:@"Save" forState:UIControlStateNormal];
        [btn2 setTag:99];
    }
    else if(btn2.tag == 99)
    {
        [btn2 setTitle:@"Edit" forState:UIControlStateNormal];
        [btn2 setTag:88];
    }
}

- (void)edit
{
	[mainTableView setEditing:!mainTableView.editing animated:YES];
	self.editing = !self.editing;
	
	if(!self.editing){
		self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(edit)];
	} else {
		self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(edit)];
	}
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if([notes count] != indexPath.row){
        NSMutableArray *myNotesForThisCigar = [[[UIApplication sharedApplication] delegate] findNotesMatch:[notes objectAtIndex:indexPath.row]];
        [notes removeObjectAtIndex:indexPath.row];
        NSMutableArray *delAr = [[[UIApplication sharedApplication] delegate] notes];
        [delAr removeObject:myNotesForThisCigar];
        [[[UIApplication sharedApplication] delegate] saveMyNotesData];
        [mainTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationTop];
        if([notes count] == 0) [self edit];
    }
}

- (void)tableView:(UITableView *)tb didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if([notes count] != indexPath.row){
        Cigar *cigar = [notes objectAtIndex:indexPath.row];
        NSMutableArray *myNotesForThis = [[[[UIApplication sharedApplication] delegate] findNotesMatch:cigar] objectAtIndex:1];
        
        MyNotesViewController2 *n = [[MyNotesViewController2 alloc] initWithNibName:@"MyNotesViewController2" bundle:nil];
        n.notes = myNotesForThis;
        self.navigationItem.title=@"Back";
        [self.navigationController pushViewController:n animated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
-(void)viewDidAppear:(BOOL)animated
{
    if(AppDelegate.adStatus)
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 614)];
    }
    else
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 704)];        
    }
    
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 704)];
	bgView.image = [UIImage imageNamed:@"right_side.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
	
//	self.title = @"My Notes";
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 703, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =@"My Notes"; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];
}
-(IBAction)onAddbtnClick:(id)sender
{
    appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate.mCategoryListViewController showDetailView:0];
    //    BrandsViewController *brand = [[BrandsViewController alloc]initWithNibName:@"BrandsViewController" bundle:nil] ;
    //    [self.navigationController pushViewController:brand animated:YES];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
