//
//  MyWishList.m
//  CigarBoss
//
//  Created by Chintan on 13/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MyWishList.h"
#import "CustomHighlightedCell.h"
#import "CigarViewController.h"
#import "StoreViewController.h"
#import "CigarBossAppDelegate.h"

CigarBossAppDelegate *appDelegate;

@interface NSString (trimLeadingWhitespace)
-(NSString*)stringByTrimmingLeadingWhitespace;
@end

@implementation NSString (trimLeadingWhitespace)
-(NSString*)stringByTrimmingLeadingWhitespace {
    NSInteger i = 0;
	
    while ([[NSCharacterSet whitespaceCharacterSet] characterIsMember:[self characterAtIndex:i]]) {
        i++;
    }
	
	while([[NSCharacterSet newlineCharacterSet] characterIsMember:[self characterAtIndex:i]]){
		i++;
	}
    return [self substringFromIndex:i];
}
@end

@implementation MyWishList
@synthesize cigars;
@synthesize wishList;


// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
		forShops = NO;
    }
    return self;
}

- (void)changeStuff:(id)sender
{
	forShops = !forShops;
	[mainTableView reloadData];
}
-(IBAction)onAddbtnClick:(id)sender
{
    appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate.mCategoryListViewController showDetailView:0];
    //    BrandsViewController *brand = [[BrandsViewController alloc]initWithNibName:@"BrandsViewController" bundle:nil] ;
    //    [self.navigationController pushViewController:brand animated:YES];
}

- (void)viewWillAppear:(BOOL)animated
{
    
    toolBar.hidden = FALSE;
    toolBar.frame = CGRectMake(0, 0, 703, 44);
    [self.view bringSubviewToFront:toolBar];

    
    [self.cigars removeAllObjects];
    
    NSMutableArray *cigarArray = [[NSMutableArray alloc] init];
    
	id appDelegate = [[UIApplication sharedApplication] delegate];
	for(NSArray *rating in [appDelegate WishList]){
		[cigarArray addObject:[rating objectAtIndex:0]];
	}
    
    self.wishList = [appDelegate WishList];
    
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editEntries:)];
	[mainTableView setEditing:NO];
	[self setEditing:NO];

    NSSortDescriptor *desc = [NSSortDescriptor sortDescriptorWithKey:@"brand" ascending:YES selector:@selector(localizedCompare:)];
    [self.cigars addObjectsFromArray:[cigarArray sortedArrayUsingDescriptors:[NSArray arrayWithObject:desc]]];
    
    /*
     [cigars release];
     cigars = [[NSMutableArray alloc] init];
     id appDelegate = [[UIApplication sharedApplication] delegate];
     for(NSArray *rating in [appDelegate WishList]){
     [cigars addObject:[rating objectAtIndex:0]];
     }
     */
    
    
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editEntries:)];
	[mainTableView setEditing:NO];
	[self setEditing:NO];
    
    
    /*
     if(indexes){
     [indexes release];
     [keys release];
     }
     indexes = [[NSMutableDictionary alloc] init];
     //id appDelegate = [[UIApplication sharedApplication] delegate];
     for(NSArray *rating in [appDelegate WishList]){
     NSString *firstLetter = [rating objectAtIndex:1];;
     NSMutableArray *existingArray;
     if((existingArray = [indexes valueForKey:firstLetter])){
     [existingArray addObject:[rating objectAtIndex:0]];
     } else {
     NSMutableArray *tempArray = [NSMutableArray array];
     [indexes setObject:tempArray forKey:firstLetter];
     [tempArray addObject:[rating objectAtIndex:0]];
     }
     }
     */
    
	loaded = YES;
	
    /*
     NSSortDescriptor *desc = [NSSortDescriptor sortDescriptorWithKey:nil ascending:NO selector:@selector(localizedCompare:)];
     keys = [[indexes allKeys] sortedArrayUsingDescriptors:[NSArray arrayWithObject:desc]];
     keys = [[NSMutableArray alloc] initWithArray:keys];
     */
	[mainTableView reloadData];

}

- (void)editEntries:(UIBarButtonItem *)sender
{
	[mainTableView setEditing:!mainTableView.editing animated:YES];
	self.editing = !self.editing;
	
	if(!self.editing){
		self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editEntries:)];
	} else {
		self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(editEntries:)];
	}
}
- (IBAction)onbtnEditClick:(id)sender
{
    [mainTableView setEditing:!mainTableView.editing animated:YES];
    
    UIButton *btn2 = (UIButton *) sender;
    if(btn2.tag == 77){
        [btn2 setTitle:@"Save" forState:UIControlStateNormal];
        [btn2 setTag:66];
    }
    else if(btn2.tag == 66)
    {
        [btn2 setTitle:@"Edit" forState:UIControlStateNormal];
        [btn2 setTag:77];
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
	
	if(!loaded){
        
        cigars = [[NSMutableArray alloc] init];
        NSMutableArray *cigarArray = [[NSMutableArray alloc] init];
        id appDelegate = [[UIApplication sharedApplication] delegate];
        for(NSArray *rating in [appDelegate WishList]){
            [cigarArray addObject:[rating objectAtIndex:0]];
        }
        
        NSSortDescriptor *desc = [NSSortDescriptor sortDescriptorWithKey:@"brand" ascending:YES selector:@selector(localizedCompare:)];
        [cigars addObjectsFromArray:[cigarArray sortedArrayUsingDescriptors:[NSArray arrayWithObject:desc]]];
        
		loaded = YES;
        
        
        /*
         if(indexes){
         [indexes release];
         [keys release];
         }
         indexes = [[NSMutableDictionary alloc] init];
         id appDelegate = [[UIApplication sharedApplication] delegate];
         for(NSArray *rating in [appDelegate WishList]){
         NSString *firstLetter = [rating objectAtIndex:1];;
         NSMutableArray *existingArray;
         if((existingArray = [indexes valueForKey:firstLetter])){
         [existingArray addObject:[rating objectAtIndex:0]];
         } else {
         NSMutableArray *tempArray = [NSMutableArray array];
         [indexes setObject:tempArray forKey:firstLetter];
         [tempArray addObject:[rating objectAtIndex:0]];
         }
         }
         loaded = YES;
         
         
         NSSortDescriptor *desc = [NSSortDescriptor sortDescriptorWithKey:nil ascending:NO selector:@selector(localizedCompare:)];
         keys = [[indexes allKeys] sortedArrayUsingDescriptors:[NSArray arrayWithObject:desc]];
         keys = [[NSMutableArray alloc] initWithArray:keys];
         //keys = [[NSArray alloc] initWithObjects:@"5", @"4", @"3", @"2", "1", nil];
         //NSLog([indexes description]);
         */
	}

	
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(editEntries:)];
	
//	self.title = @"My Wish List";
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 703, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =@"My Wish List"; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];
    
    btnEdit = [[UIButton alloc]init];
    
	mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 704)];
	bgView.image = [UIImage imageNamed:@"right_side.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
	
	self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
	
	cigars = [[NSMutableArray alloc] init];
	id appDelegate = [[UIApplication sharedApplication] delegate];
	for(NSArray *rating in [appDelegate WishList]){
		[cigars addObject:[rating objectAtIndex:0]];
	}
    
    if(forShops){
        forShopsControl.selectedSegmentIndex = 1;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{	
	if(forShops)
    {
        return 1;
    }
    else
    {
        return 1;
    }
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return nil;
	if(forShops) return nil;
    return keys;
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
	if(forShops)
    {
        return 0;   
    }
    else
    {
        return index;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if(forShops)
    {
        return [[[[UIApplication sharedApplication] delegate] favoriteShops] count];
    }
    else
    {
        /*
         if (section != [keys count]) {
         NSString *correctKey = [keys objectAtIndex:section];
         NSArray *arrayForThisSection = [indexes objectForKey:correctKey];
         return [arrayForThisSection count];
         }
         return 1;
         */
        
        return [self.cigars count] + 1;
    }
    //return 0;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return nil;
    
	if(forShops)
    {
        return nil;
    }
    else
    {
        return nil;
        //        return [NSString stringWithFormat:@"%@ stars", [keys objectAtIndex:section]];
    }
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(forShops){
        NSMutableArray *shops = [[[UIApplication sharedApplication] delegate] favoriteShops];
        [shops removeObjectAtIndex:indexPath.row];
        [[[UIApplication sharedApplication] delegate] saveFavoriteShops];
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        return;
    }
	
    Cigar *correctCig = [cigars objectAtIndex:indexPath.row];
    Cigar *cigarHere = correctCig;
    id appDelegate = [[UIApplication sharedApplication] delegate];
    
    NSArray *removeRating = nil;
    
    for ( NSArray *rating in [appDelegate WishList] ) {
        if ( [cigarHere isEqualCigar:[rating objectAtIndex:0]] ) {
            removeRating = rating;
        }
    }
    
    if ( removeRating ) {
        [[appDelegate WishList] removeObject:removeRating];
        [cigars removeObject:cigarHere];
        [appDelegate saveWishListData];
    }
    
    if([cigars count] == 0){
        [self editEntries:nil];
    }
    
    [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
    
    /*
     if (indexPath.section != [keys count]) {
     NSString *correctKey = [keys objectAtIndex:indexPath.section];
     NSArray *arrayForThisSection = [indexes objectForKey:correctKey];
     Cigar *correctCig = [arrayForThisSection objectAtIndex:indexPath.row];
     Cigar *cigarHere = correctCig;
     id appDelegate = [[UIApplication sharedApplication] delegate];
     NSArray *removeRating = nil;
     for(NSArray *rating in [appDelegate WishList]){
     if([cigarHere isEqualCigar:[rating objectAtIndex:0]]){
     removeRating = rating;
     }
     }
     if(removeRating){
     [[appDelegate WishList] removeObject:removeRating];
     [appDelegate saveWishListData];
     }
     [arrayForThisSection removeObjectAtIndex:indexPath.row];
     
     if([cigars count] == 0){
     [self editEntries:nil];
     }
     if([arrayForThisSection count] == 0){
     [keys removeObjectAtIndex:indexPath.section];
     [tableView deleteSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationLeft];
     } else {
     [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
     }
     }
     */
}

- (void)tableView:(UITableView *)tableView willBeginEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
     [[cell.contentView viewWithTag:451] setAlpha:0.0];*/
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BrandCell"];
	UIButton *button;
    UIButton *up, *down;
    UILabel *typeLabel, *detailLabel;
    
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil] autorelease];
        button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setBackgroundImage:[UIImage imageNamed:@"Remove.png"] forState:UIControlStateNormal];
        [button setFrame:CGRectMake(10, 5, 50, 50)];
        [cell.contentView addSubview:button];
        [button addTarget:self action:@selector(smokeNow:) forControlEvents:UIControlEventTouchUpInside];
        [button setTag:667];
        
        up = [UIButton buttonWithType:UIButtonTypeCustom];
        up.frame = CGRectMake(350, 5, 15, 15);
        up.tag = 700;
        //   [cell.contentView addSubview:up];
        //    [up addTarget:self action:@selector(upCigar:) forControlEvents:UIControlEventTouchUpInside];
        // [up setBackgroundImage:[UIImage imageNamed:@"UpArrow2.png"] forState:UIControlStateNormal];
        
        down = [UIButton buttonWithType:UIButtonTypeCustom];
        down.frame = CGRectMake(350, 23, 15, 15);
        [down setBackgroundImage:[UIImage imageNamed:@"DownArrow2.png"] forState:UIControlStateNormal];
        down.tag = 702;
        up.alpha = 0.0;
        down.alpha = 0.0;
        //        [cell.contentView addSubview:down];
        //      [down addTarget:self action:@selector(downCigar:) forControlEvents:UIControlEventTouchUpInside];
        
        typeLabel = [[UILabel alloc] initWithFrame:CGRectMake(70, 5, 215, 25)];
        [typeLabel setTag:450];
        [cell.contentView addSubview:typeLabel];
        
        detailLabel = [[UILabel alloc] initWithFrame:CGRectMake(80, 30, 215, 25)];
        detailLabel.tag = 451;
        [cell.contentView addSubview:detailLabel];
	} 
    else {
        button = [cell.contentView viewWithTag:667];
        typeLabel = [cell.contentView viewWithTag:450];
        detailLabel = [cell.contentView viewWithTag:451];
        up = [cell.contentView viewWithTag:700];
        down = [cell.contentView viewWithTag:702];
    }
	
    if ( indexPath.row != [cigars count] ) {
        
        Cigar *correctCig = [cigars objectAtIndex:indexPath.row];
        NSString *correctKey = [self getCigarHumidorCount:correctCig];
        
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        //cell.textLabel.text = [correctCig.type stringByTrimmingLeadingWhitespace];
        //CGRect typeLabelFrame = cell.textLabel.frame;
        //typeLabelFrame.origin.y -= 5;
        //cell.textLabel.frame = typeLabelFrame;
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        //   cell.detailTextLabel.text = correctKey;
        cell.detailTextLabel.textColor = [UIColor whiteColor];
        cell.detailTextLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
        cell.imageView.image = [UIImage imageNamed:@"Icon~ipad.png"];
        
        cell.imageView.alpha = .05;
        
        typeLabel.text = [correctCig.brand stringByTrimmingLeadingWhitespace];
        typeLabel.adjustsFontSizeToFitWidth = YES;
        typeLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
        typeLabel.textColor = [UIColor whiteColor];
        typeLabel.backgroundColor = [UIColor clearColor];
        
        detailLabel.text = [correctCig.type stringByTrimmingLeadingWhitespace];
        detailLabel.font = [UIFont fontWithName:@"Copperplate" size:14.0];
        detailLabel.textColor = [UIColor lightGrayColor];
        detailLabel.backgroundColor = [UIColor clearColor];
        detailLabel.alpha = .9;
        if(tableView.editing) detailLabel.alpha = 0.0; else detailLabel.alpha = .9;
    }
    else
    {
        
        button.hidden = true;
        cell.selectionStyle = UITableViewCellEditingStyleNone;
        
        detailLabel.backgroundColor = [UIColor clearColor];
        typeLabel.backgroundColor = [UIColor clearColor];
        
        UIView *vie = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 703, 60)];
        [vie setBackgroundColor:[UIColor clearColor]];
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(40,10, 350, 40)];
        lbl.font = [UIFont fontWithName:@"Copperplate" size:22.0];
        lbl.text = @"Click Plus Sign To Add";
        lbl.textColor = [UIColor whiteColor];
        lbl.font = [UIFont fontWithName:@"Copperplate" size:22.0];
        [lbl setBackgroundColor:[UIColor clearColor]];
        [cell addSubview:lbl];
        
        UIButton *button11 = [UIButton buttonWithType:UIButtonTypeContactAdd];
        [button11 addTarget:self action:@selector(onAddbtnClick:) forControlEvents:UIControlEventTouchUpInside];
        button11.frame = CGRectMake(660, 15, 30, 30);
        [cell addSubview:button11];
        
        // [cell.contentView addSubview:vie];
    }
    /* typeLabel.frame = cell.textLabel.frame;
     typeLabel.text = cell.textLabel.text;
     typeLabel.textColor = [UIColor whiteColor];
     typeLabel.backgroundColor = [UIColor redColor];
     typeLabel.font = cell.textLabel.font;
     cell.textLabel.alpha = 0.0;*/
	
	return cell;
}

- (void)smokeNow:(UIButton *)button
{
    id appDelegate = [[UIApplication sharedApplication] delegate];
    UITableViewCell *cell = [[button superview] superview];
    NSIndexPath *indexPath = [mainTableView indexPathForCell:cell];
    
    Cigar *correctCig = [cigars objectAtIndex:indexPath.row];
    NSString *correctKey = [self getCigarHumidorCount:correctCig];
    NSMutableArray *cigarArray = [appDelegate findWishlistMatch:correctCig];
    
    int count = [correctKey intValue];
    count --;
    
    if ( count == 0 )
    {
        Cigar *cigarHere = correctCig;
        
        id appDelegate = [[UIApplication sharedApplication] delegate];
        NSArray *removeRating = nil;
        for(NSArray *rating in [appDelegate WishList]){
            if([cigarHere isEqualCigar:[rating objectAtIndex:0]]){
                removeRating = rating;
            }
        }
        if(removeRating){
            [[appDelegate WishList] removeObject:removeRating];
            [appDelegate saveWishListData];
        }
        
        [cigars removeObjectAtIndex:indexPath.row];
        if([cigars count] == 0){
            [self editEntries:nil];
        }
        
        [mainTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        
        return;
        
    }
    
    /*NSArray *oArray = cigarArray;
     cigarArray = [[NSMutableArray alloc] initWithCapacity:2];
     [cigarArray addObject:cigar];
     [cigarArray addObject:[NSString stringWithFormat:@"%d", rating]];
     [appDelegate addFavorite:cigarArray];
     [[appDelegate ratings] replaceObjectAtIndex:[[appDelegate ratings] indexOfObject:oArray] withObject:cigarArray];
     */[cigarArray replaceObjectAtIndex:1 withObject:[NSString stringWithFormat:@"%d", count]];
    [appDelegate saveWishListData];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%d", count];
}

- (void)upCigar:(id)sender
{
    id appDelegate = [[UIApplication sharedApplication] delegate];
    UITableViewCell *cell = [[sender superview] superview];
    NSIndexPath *indexPath = [mainTableView indexPathForCell:cell];
    NSString *correctKey = [keys objectAtIndex:indexPath.section];
    NSArray *arrayForThisSection = [indexes objectForKey:correctKey];
	Cigar *correctCig = [arrayForThisSection objectAtIndex:indexPath.row];
    NSMutableArray *cigarArray = [appDelegate findWishlistMatch:correctCig];
    NSString *humidorCurrentCount = [cigarArray objectAtIndex:1];
    int count = [humidorCurrentCount intValue];
    count++;
    if(count > 99) count = 99;
    /*NSArray *oArray = cigarArray;
     cigarArray = [[NSMutableArray alloc] initWithCapacity:2];
     [cigarArray addObject:cigar];
     [cigarArray addObject:[NSString stringWithFormat:@"%d", rating]];
     [appDelegate addFavorite:cigarArray];
     [[appDelegate ratings] replaceObjectAtIndex:[[appDelegate ratings] indexOfObject:oArray] withObject:cigarArray];
     */[cigarArray replaceObjectAtIndex:1 withObject:[NSString stringWithFormat:@"%d", count]];
    [appDelegate saveWishListData];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%d", count];
}

- (void)downCigar:(id)sender
{
    id appDelegate = [[UIApplication sharedApplication] delegate];
    UITableViewCell *cell = [[sender superview] superview];
    NSIndexPath *indexPath = [mainTableView indexPathForCell:cell];
    NSString *correctKey = [keys objectAtIndex:indexPath.section];
    NSArray *arrayForThisSection = [indexes objectForKey:correctKey];
	Cigar *correctCig = [arrayForThisSection objectAtIndex:indexPath.row];
    NSMutableArray *cigarArray = [appDelegate findWishlistMatch:correctCig];
    NSString *humidorCurrentCount = [cigarArray objectAtIndex:1];
    int count = [humidorCurrentCount intValue];
    count--;
    if(count <1) count = 1;
    /*NSArray *oArray = cigarArray;
     cigarArray = [[NSMutableArray alloc] initWithCapacity:2];
     [cigarArray addObject:cigar];
     [cigarArray addObject:[NSString stringWithFormat:@"%d", rating]];
     [appDelegate addFavorite:cigarArray];
     [[appDelegate ratings] replaceObjectAtIndex:[[appDelegate ratings] indexOfObject:oArray] withObject:cigarArray];
     */[cigarArray replaceObjectAtIndex:1 withObject:[NSString stringWithFormat:@"%d", count]];
    [appDelegate saveWishListData];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%d", count];
}

- (NSString *) getCigarHumidorCount : (Cigar *) cigar
{
    for ( NSArray *wish in self.wishList ) {
        if ( [[wish objectAtIndex:0] isEqualCigar:cigar] )
            return [wish objectAtIndex:1];
    }
    
    return @"";
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
	if(forShops){
		StoreViewController *sView = [[StoreViewController alloc] initWithNibName:@"StoreViewController" bundle:nil];
		NSArray *shops = [[[UIApplication sharedApplication] delegate] favoriteShops];
		sView.newCigar = [[shops objectAtIndex:indexPath.row] objectAtIndex:0];
        self.navigationItem.title=@"Back";
		[self.navigationController pushViewController:sView animated:YES];
		return;
	}
    
    if (indexPath.row != [[appDelegate WishList] count]) {
        CigarViewController *c = [[CigarViewController alloc] initWithNibName:@"CigarViewController" bundle:[NSBundle mainBundle]];
        Cigar *correctCig = [cigars objectAtIndex:indexPath.row];
        c.cigar = correctCig;
        self.navigationItem.title=@"Back";
        [self.navigationController pushViewController:c animated:YES];
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}


-(void)viewDidAppear:(BOOL)animated
{
    if(AppDelegate.adStatus)
    {
        [mainTableView setFrame:CGRectMake(0, 44, 703, 614)];
    }
    else
    {
        [mainTableView setFrame:CGRectMake(0, 44, 703, 660)];
    }
}
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
