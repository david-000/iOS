//
//  CigarDatabaseData.m
//  CigarBoss_Free
//
//  Created by WYP on 9/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CigarDatabaseData.h"

@implementation CigarDatabaseData
@synthesize mBrandId;
@synthesize mBrandData;

@end
