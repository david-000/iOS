//
//  CustomCigarPinObject.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CustomCigarPinObject.h"


@implementation CustomCigarPinObject
@synthesize title, subtitle, coordinate, cigar;


@end
