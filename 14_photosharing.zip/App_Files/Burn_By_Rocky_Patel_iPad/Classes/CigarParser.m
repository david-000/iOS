//
//  CigarParser.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CigarParser.h"
#import "CigarBossAppDelegate.h"
#import "BrandsViewController.h"

@implementation CigarParser

- (id)init
{
	self = [super init];
	shouldUseCurrentTag = NO;
	currentString = nil;
	onReviews = NO;
	
	return self;
}

- (void)parse
{
	if(parseLink == nil){
		//NSBundle *mainBundle = [NSBundle mainBundle];
		//NSString *link = [mainBundle pathForResource:@"cigarapp" ofType:@"xml"];
		//NSXMLParser *parser = [[NSXMLParser alloc] initWithData:[[NSData dataWithContentsOfFile:link] retain]];
		//NSXMLParser *parser = [[NSXMLParser alloc] initWithContentsOfURL:[NSURL URLWithString:@"http://apartmentpostcards.com/cigarboss/cigarapp.xml"]];
		//[parser setDelegate:self];
		NSDate *lastSyncedDate = [[NSKeyedUnarchiver unarchiveObjectWithFile:[self dateFilePath]] retain];
		if(lastSyncedDate != nil && ([[[NSDate alloc] init] timeIntervalSinceDate:lastSyncedDate] >= (60*60*24*10))){
            NSString *weeklyOrMonthly = [[NSUserDefaults standardUserDefaults] objectForKey:@"CigarBoss_weeklyOrMonthly"];
            if(weeklyOrMonthly == nil || [weeklyOrMonthly isEqualToString:@"weekly"] || [weeklyOrMonthly isEqualToString:@""]){
                NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://cigarboss.co/cigarnew.xml"] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:180.0];
                connection = [[NSURLConnection alloc] initWithRequest:request delegate:self]; //notice how delegate set to self object
                AppDelegate.isCigarLoading = YES;
                
                if ( AppDelegate.mCategoryListViewController.mSelectedIndexPath != nil && AppDelegate.mCategoryListViewController.mSelectedIndexPath.row == 0 ) {
                    BrandsViewController *brandsVc = (BrandsViewController *)[AppDelegate.mNavigationController.viewControllers objectAtIndex:0];
                    
                    if ( brandsVc != nil ) {
                        [AppDelegate showLoadingView:brandsVc.view];
                    }
                }
                
                return;
            } else {
                if([[[NSDate alloc] init] timeIntervalSinceDate:lastSyncedDate] >= (60*60*24*7*4)){
                    NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://cigarboss.co/cigarnew.xml"] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:180.0];
                    connection = [[NSURLConnection alloc] initWithRequest:request delegate:self]; //notice how delegate set to self object
                    AppDelegate.isCigarLoading = YES;
                    
                    if ( AppDelegate.mCategoryListViewController.mSelectedIndexPath != nil && AppDelegate.mCategoryListViewController.mSelectedIndexPath.row == 0 ) {
                        BrandsViewController *brandsVc = (BrandsViewController *)[AppDelegate.mNavigationController.viewControllers objectAtIndex:0];
                        
                        if ( brandsVc != nil ) {
                            [AppDelegate showLoadingView:brandsVc.view];
                        }
                    }

                    return;
                }
            }
		}
		
		NSFileManager *defaultFileManager = [NSFileManager defaultManager];
		if([defaultFileManager fileExistsAtPath:[self dataFilePath]]){
			NSXMLParser *parser = [[NSXMLParser alloc] initWithData:[defaultFileManager contentsAtPath:[self dataFilePath]]];
			[parser setDelegate:self];
			[parser parse];
			return;
		}
		NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://cigarboss.co/cigarnew.xml"] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:180.0];
		connection = [[NSURLConnection alloc] initWithRequest:request delegate:self]; //notice how delegate set to self object
        AppDelegate.isCigarLoading = YES;
        
        if ( AppDelegate.mCategoryListViewController.mSelectedIndexPath != nil && AppDelegate.mCategoryListViewController.mSelectedIndexPath.row == 0 ) {
            BrandsViewController *brandsVc = (BrandsViewController *)[AppDelegate.mNavigationController.viewControllers objectAtIndex:0];
            
            if ( brandsVc != nil ) {
                [AppDelegate showLoadingView:brandsVc.view];
            }
        }

		//NSString *meh = [[NSString alloc] initWithData:[NSData dataWithContentsOfFile:link] encoding:4];
		//[parser parse];
		//NSLog([[parser parserError] description]);
	} else {
		NSXMLParser *parser = [[NSXMLParser alloc] initWithData:[[NSData dataWithContentsOfFile:parseLink] retain]];
		[parser setDelegate:self];
		//NSString *meh = [[NSString alloc] initWithData:[NSData dataWithContentsOfFile:link] encoding:4];
		[parser parse];
	}
}



- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	/*UIAlertView *errorView = [[UIAlertView alloc] initWithTitle:@"Failed Loading" message:@"CigarBoss couldn't connect to the CigarBoss.com servers." delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
     [errorView show];
     [errorView release];*/
    
    AppDelegate.isCigarLoading = NO;
    [AppDelegate hideLoadingView];

    
	NSFileManager *defaultFileManager = [NSFileManager defaultManager];
	if([defaultFileManager fileExistsAtPath:[self dataFilePath]]){
		NSXMLParser *parser = [[NSXMLParser alloc] initWithData:[defaultFileManager contentsAtPath:[self dataFilePath]]];
		[parser setDelegate:self];
		[parser parse];
	} else {
		NSBundle *mainBundle = [NSBundle mainBundle];
		NSString *link = [mainBundle pathForResource:@"cigarapp" ofType:@"xml"];
		NSXMLParser *parser = [[NSXMLParser alloc] initWithData:[[NSData dataWithContentsOfFile:link] retain]];
		//NSXMLParser *parser = [[NSXMLParser alloc] initWithContentsOfURL:[NSURL URLWithString:@"http://apartmentpostcards.com/cigarboss/cigarapp.xml"]];
		[parser setDelegate:self];
		[parser parse];
	}
	[[(CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate] defaultImageView] setHidden:YES];
}

//the URL connection calls this repeatedly as data arrives
- (void)connection:(NSURLConnection *)theConnection didReceiveData:(NSData *)incrementalData {
	if (data==nil) { data = [[NSMutableData alloc] initWithCapacity:2048]; } 
	[data appendData:incrementalData];
}

//the URL connection calls this once all the data has downloaded
- (void)connectionDidFinishLoading:(NSURLConnection*)theConnection {
	//so self data now has the complete image 
	[connection release];
	connection=nil;
	/*if ([[self subviews] count]>0) {
     //then this must be another image, the old one is still in subviews
     [[[self subviews] objectAtIndex:0] removeFromSuperview]; //so remove it (releases it also)
     }*/
    
    [CigarBossAppDelegate adSkipBackUpAttributeToItemAtURL:[self dataFilePath]];
    
	if([data writeToFile:[self dataFilePath] atomically:YES]){
		NSDate *now = [[NSDate alloc] init];
		[NSKeyedArchiver archiveRootObject:now toFile:[self dateFilePath]];
	}
	NSXMLParser *parser = [[NSXMLParser alloc] initWithData:data];
	[parser setDelegate:self];
	[parser parse];
	
	[data release]; //don't need this any more, its in the UIImageView now
	data=nil;

    AppDelegate.isCigarLoading = NO;

    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *) [[UIApplication sharedApplication] delegate];
    if ( appDelegate.mCategoryListViewController.mSelectedIndexPath != nil && appDelegate.mCategoryListViewController.mSelectedIndexPath.row == 0 ) {
        BrandsViewController *brandsVc = (BrandsViewController *)[appDelegate.mNavigationController.viewControllers objectAtIndex:0];
        
        [appDelegate hideLoadingView];
        if ( brandsVc != nil ) {
            [brandsVc showSegmentAction];
        }
    }
}

- (NSString *)dataFilePath
{
	NSString *dataFilePath;
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	dataFilePath = [[documentsDirectory stringByAppendingPathComponent:@"stuff.xml"] retain];
	return dataFilePath;
}

- (NSString *)dateFilePath
{
	NSString *dataFilePath;
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	dataFilePath = [[documentsDirectory stringByAppendingPathComponent:@"date.xml"] retain];
	return dataFilePath;
}

#pragma mark Begin XML Delegate Methods

- (void)parser:(NSXMLParser *)parser 
didStartElement:(NSString *)elementName 
  namespaceURI:(NSString *)namespace
 qualifiedName:(NSString *)qName 
	attributes:(NSDictionary *)attributeDict
{
	if([elementName isEqualToString:@"cigar"]){
		NSString *tempBrand = [attributeDict objectForKey:@"brand"];
		tempBrand = [tempBrand stringByReplacingOccurrencesOfString:@"{" withString:@""];
		tempBrand = [tempBrand stringByReplacingOccurrencesOfString:@"}" withString:@""];
		tempBrand = [tempBrand stringByReplacingOccurrencesOfString:@"_" withString:@" "];
        
        NSString *tempBrandId = [attributeDict objectForKey:@"id"];
        
		NSMutableArray *addArray;
		NSMutableDictionary *appDelBrandsArrays = [[[UIApplication sharedApplication] delegate] cigarBrandArrays];
		if([appDelBrandsArrays objectForKey:tempBrand] == nil){
			addArray = [[NSMutableArray alloc] init];
			[appDelBrandsArrays setObject:addArray forKey:tempBrand];
		} else {
			addArray = [appDelBrandsArrays objectForKey:tempBrand];
		}
		currentCigar = [[Cigar alloc] init];
		currentCigar.brand = tempBrand;
        currentCigar.brandId = tempBrandId;
		[addArray addObject:currentCigar];
	} else if([elementName isEqualToString:@"reviews"]){
		onReviews = YES;
	} else if(![elementName isEqualToString:@"CigarApp"] && ![elementName isEqualToString:@"cigar"]){
		shouldUseCurrentTag = YES;
	}
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if(shouldUseCurrentTag == NO) return;
	if(!currentString){
		currentString = [[NSMutableString alloc] init];
	}
	
	[currentString appendString:string];
}

- (void)parser:(NSXMLParser *)parser 
 didEndElement:(NSString *)elementName
  namespaceURI:(NSString *)namespace 
 qualifiedName:(NSString *)qName
{
	if([elementName isEqualToString:@"link_name"] && onReviews){
		lastLinkName = [currentString copy];
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"link"] && onReviews){
		[currentCigar.reviews addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[currentString copy], [lastLinkName copy], nil]];
		//[lastLinkName release];
		lastLinkName = nil;
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"reviews"]){
		onReviews = NO;
    } else if([elementName isEqualToString:@"featured_picture_url"]){
		NSMutableArray *featuredPhotos = [[[UIApplication sharedApplication] delegate] featuredPhotos];
        [featuredPhotos addObject:[currentString copy]];
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"type"]){
		currentCigar.type = [currentString stringByReplacingOccurrencesOfString:@"_" withString:@" "];
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"picture_url"]){
		currentCigar.pictureURL = currentString;
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"price"]){
		currentCigar.price = currentString;
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"boxprice"]){
		currentCigar.boxprice = currentString;
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"length"]){
		currentCigar.length = currentString;
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"ring"]){
		currentCigar.ring = currentString;
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"strength"]){
		currentCigar.strength = currentString;
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"country"]){
		currentCigar.country = currentString;
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"wrapper"]){
		currentCigar.wrapper = currentString;
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"origin"]){
		currentCigar.origin = currentString;
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"leaf"]){
		currentCigar.leaf = currentString;
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"general_info"]){
		currentCigar.generalInfo = currentString;
		[currentString release];
		currentString = nil;
	}else if([elementName isEqualToString:@"twitter"]){
		currentCigar.twit = currentString;
		[currentString release];
		currentString = nil;
	}
    else if([elementName isEqualToString:@"cubancigar"]){
		currentCigar.cuban = currentString;
        
		[currentString release];
		currentString = nil;
	} else if([elementName isEqualToString:@"newcigar"]){
        if([currentString isEqualToString:@"true"]){
            currentCigar.newCigar = @"YES";
            NSMutableArray *cigars = [[[UIApplication sharedApplication] delegate] newCigars];
            [cigars addObject:currentCigar];
        }
        [currentString release];
        currentString = nil;
    } else if([elementName isEqualToString:@"com"]){
        if([currentString isEqualToString:@"true"]){
            //currentCigar.newCigar = @"YES";
            [[[UIApplication sharedApplication] delegate] setCOM:currentCigar];
        }
        [currentString release];
        currentString = nil;
    } else if([elementName isEqualToString:@"overalltopten"]){
        NSMutableDictionary *dict = [[[[UIApplication sharedApplication] delegate] topTenDictionary] objectForKey:@"overall"];
        [dict setObject:currentCigar forKey:currentString];
        [currentString release];
        currentString = nil;
    } else if([elementName isEqualToString:@"mildtopten"]){
        NSMutableDictionary *dict = [[[[UIApplication sharedApplication] delegate] topTenDictionary] objectForKey:@"mild"];
        [dict setObject:currentCigar forKey:currentString];
        [currentString release];
        currentString = nil;
    } else if([elementName isEqualToString:@"mediumtopten"]){
        NSMutableDictionary *dict = [[[[UIApplication sharedApplication] delegate] topTenDictionary] objectForKey:@"medium"];
        [dict setObject:currentCigar forKey:currentString];
        [currentString release];
        currentString = nil;
    } else if([elementName isEqualToString:@"fulltopten"]){
        NSMutableDictionary *dict = [[[[UIApplication sharedApplication] delegate] topTenDictionary] objectForKey:@"full"];
        [dict setObject:currentCigar forKey:currentString];
        [currentString release];
        currentString = nil;
    } else if([elementName isEqualToString:@"economytopten"]){
        NSMutableDictionary *dict = [[[[UIApplication sharedApplication] delegate] topTenDictionary] objectForKey:@"economy"];
        [dict setObject:currentCigar forKey:currentString];
        [currentString release];
        currentString = nil;
    }
	//NSLog(@">>>>>>>> %@ ",currentCigar.cuban);
	shouldUseCurrentTag = NO;
}

- (void)parserDidEndDocument:(NSXMLParser *)parser
{
	[[[[UIApplication sharedApplication] delegate] defaultImageView] setHidden:YES];
    //  NSLog([[[[UIApplication sharedApplication] delegate] topTenDictionary] description]);
}

#pragma mark End NSXML Delegate Methods

@end
