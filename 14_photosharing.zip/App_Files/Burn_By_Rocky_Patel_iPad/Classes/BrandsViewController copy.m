//
//  BrandsViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "BrandsViewController.h"
#import "Cigar.h"
#import "CigarsViewController.h"
#import "CustomHighlightedCell.h"
#import "SearchingOverlayView.h"
#import "SearchResultsObject.h"
#import "AddCigarDetailViewController.h"
#import "CigarBossAppDelegate.h"

CigarBossAppDelegate *appDelegate;

@implementation BrandsViewController
@synthesize strFrom,strSelected;
// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
	self = [super initWithCoder:aDecoder];
	
    arrCuban = [[NSMutableArray alloc] init];
    arrNonCuban= [[NSMutableArray alloc] init];
    
	indexes = [[NSMutableDictionary alloc] init];
	searchingTableView = nil;
	searchResultsDataSource = [[SearchResultsObject alloc] init];
	searchResultsDataSource.parent = self;
	
	already = NO;
	return self;
}


- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView 
{
    if(cubanFlag)
    {
        NSLog(@">>>>>>>>>>>>> 1: %d", [[arrdistNew allKeys] count]);
        return [[arrdistNew allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];       
    }
    else
    {
        return [[arrdist allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    }
}

- (int)numberOfSectionsInTableView:(UITableView *)tableView
{	
    NSLog(@"tableView 2:%d", tableView.tag);
    if(cubanFlag)
    {
        //        AllkeyIndexArrayNew = [[NSArray alloc] init];   
        return [[arrdistNew allKeys] count];       
    }
    else
    {
        //AllkeyIndexArray = [[NSArray alloc] init];
        
        return [[arrdist allKeys] count];
    }
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{        
    if(cubanFlag)
    {
        NSLog(@">>>>>>>>>>>>> 3: %d", [[arrdistNew valueForKey:[[[arrdistNew allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section]] count]);
        return [[arrdistNew valueForKey:[[[arrdistNew allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section]] count];
    }
    else
    {
        return [[arrdist valueForKey:[[[arrdist allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section]] count];
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //NSLog(@">>>>>>>>Table going to load");
	CustomHighlightedCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainCell"];
    
    for(UIView *tempView in [cell.contentView subviews]) {
		[tempView removeFromSuperview];
		tempView = nil;
	}
    
	if(cell == nil)
    {
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
	}
    
    
	cell.backgroundView = nil;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.contentView.backgroundColor = [UIColor clearColor];
	cell.textLabel.backgroundColor = [UIColor clearColor];
	cell.textLabel.textColor = [UIColor whiteColor];
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 6, 300, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentLeft;
    cell.textLabel.font = [UIFont boldSystemFontOfSize:16];
    
    
    if (cubanFlag) 
    {
        if (tableView == mainTableViewNew) {
            
            @try {
                
                NSArray *allKeys = AllkeyIndexArrayNew;
                
                //NSLog(@">>>>>>>>>>>>>>> All keys :%@", AllkeyIndexArrayNew);
                NSLog(@">>>>>>>>>>>>> 4: %d section count :%d", [[arrdistNew allKeys] count], indexPath.section);
                if ([allKeys count] != 0) {
                    NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
                    NSLog(@">>>>>>>>> Rightkey :%@", rightKey);
                    NSMutableArray *arrayForThisSection = [arrdistNew objectForKey:rightKey];
                    NSLog(@">>>>>>>>> Rightkey :%d", [arrayForThisSection count]);
                    cell.textLabel.textColor = [UIColor whiteColor];
                    cell.selectionStyle = UITableViewCellSelectionStyleNone;
                    cell.textLabel.text = [arrayForThisSection objectAtIndex:indexPath.row];    
                }
            }
            @catch (NSException *exception) {
                NSLog(@">>>%@",exception);
            }
        }
        
    }
    else
    {
        NSArray *allKeys = AllkeyIndexArray;
        NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
        NSMutableArray *arrayForThisSection = [arrdist objectForKey:rightKey];
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.text = [arrayForThisSection objectAtIndex:indexPath.row];            
    }
    
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	return cell;
    
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{	
    
    if(cubanFlag)
    {
        if (tableView == mainTableViewNew) {
            NSLog(@"tableView 1:%d and Character :%@", tableView.tag, [[[arrdistNew allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section]);
            NSLog(@">>>>>>>>>>>>> 5: %d", [[arrdistNew allKeys] count]);
            return [[[arrdistNew allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section];       
        }
    }
    else
    {
        return [[[arrdist allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CigarsViewController *c = [[CigarsViewController alloc] initWithNibName:@"CigarsViewController" bundle:nil];
    
    if(cubanFlag)
    {
        NSLog(@">>>>>>>>>>>>> 6: %d", [[arrdistNew allKeys] count]);
        NSArray *allKeys = keysNew;
        NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
        NSMutableArray *arrayForThisSection = [arrdistNew objectForKey:rightKey];
        c.brand = [arrayForThisSection objectAtIndex:indexPath.row];
    }
    else
    {
        NSArray *allKeys = keys;
        NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
        NSMutableArray *arrayForThisSection = [arrdist objectForKey:rightKey];
        c.brand = [arrayForThisSection objectAtIndex:indexPath.row];
    }
    [self.navigationController pushViewController:c animated:YES];
    
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	//cubanFlag = FALSE;
    
    NSLog(@"View Did LOAD>>>>>>>>>>>>::");
    Ncigars = [[NSMutableArray alloc] init];
    
    appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [appDelegate showLoadingView]; 
    
    mainTableViewNew.hidden = TRUE;
    mainTableViewNew.tableHeaderView = searchBarNew;
    mainTableViewNew.backgroundColor = [UIColor clearColor];
	mainTableViewNew.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
    
    NSArray *rating = [appDelegate NewCigarList];
    
    for(int i = 0; i<[rating count]; i++)
    {
        NSArray *firstLetter = [rating objectAtIndex:i];
        Cigar *cg = [[Cigar alloc]init];
        cg = [firstLetter objectAtIndex:1];
        [Ncigars addObject:cg];
    }
    [Ncigars retain];    
    int count;
    
    NSUserDefaults *ImageNumber = [NSUserDefaults standardUserDefaults];
    if ([ImageNumber integerForKey:@"CigarImageNumber"] > 0) {
        
        count = [ImageNumber integerForKey:@"CigarImageNumber"];
    }else{
        count = 0;
    }
    
    
    if([Ncigars count] > 0){
        NSString *tempBrandId = [NSString stringWithFormat:@"4000%d",count];
        
        for (int k = 0; k < [Ncigars count] ; k++) {
            Cigar *cgar = [[Cigar alloc] init];
            cgar = [Ncigars objectAtIndex:k];
            cgar.brandId = tempBrandId;
            if([cgar.cuban isEqualToString:@"true"])
            {
                //NSLog(@"Testing of Cuban %@ ",cgar);
            }
            NSString *tempBrand = cgar.brand;
            
            tempBrand = [tempBrand stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:[[tempBrand substringToIndex:1] uppercaseString]];
            
            
            NSMutableArray *addArray;
            NSMutableDictionary *appDelBrandsArrays = [appDelegate cigarBrandArrays];
            if([appDelBrandsArrays objectForKey:tempBrand] == nil){
                addArray = [[NSMutableArray alloc] init];
                [appDelBrandsArrays setObject:addArray forKey:tempBrand];
            } else {
                addArray = [appDelBrandsArrays objectForKey:tempBrand];
            }
            
            [addArray addObject:cgar];
        }        
    }
    
    
    //===============
    topView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 45)];
    [topView setBackgroundColor:[UIColor blackColor]];
    
    NSArray *segmentArray = [[NSArray alloc] initWithObjects:@"Non-Cuban",@"Cuban", nil];
    segment = [[UISegmentedControl alloc] initWithItems:segmentArray];
    segment.frame = CGRectMake(40, 5, 240, 35);
    [segment addTarget:self action:@selector(segmentAction:) forControlEvents:UIControlEventValueChanged];
    segment.segmentedControlStyle = UISegmentedControlStyleBar;
    if([strSelected isEqualToString:@"cuban"])
    {
        [segment setSelectedSegmentIndex:1];
        //[segment setSelectedSegmentIndex:segment.selectedSegmentIndex];
    }
    else
    {
        [segment setSelectedSegmentIndex:0];
    }
    UIColor *newTintColor = [UIColor colorWithRed: 10/255.0 green:20/255.0 blue:0/255.0 alpha:1.0];
    
    [segment setTintColor:[UIColor colorWithRed: 10/255.0 green:40/255.0 blue:0/255.0 alpha:1.0]];
    //segment.tintColor = [UIColor colorWithRed: 10/255.0 green:20/255.0 blue:0/255.0 alpha:1.0];
    UIColor *newSelectedTintColor = [UIColor colorWithRed: 0/255.0 green:40/255.0 blue:0/255.0 alpha:1.0];
    [[[segment subviews] objectAtIndex:0] setTintColor:newSelectedTintColor];
    
    
    [topView addSubview:segment];
    [self.view addSubview:topView];
    
    //    [self.view addSubview:segment];
    //===============
    
	self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
	self.title = @"Brands";
	
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(onPlusClick)];
    
	
    //    mainTableView.frame = CGRectMake(0, 46, 320, 400);
    mainTableView.tableHeaderView = searchBar;
	
    //   [mainTableView setFrame:CGRectMake(0, 45, 320, 200)];
    
	mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 367)];
	bgView.image = [UIImage imageNamed:@"Background640x734.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
    
      
    [self performSelector:@selector(callsement) withObject:nil afterDelay:0.3]; 
    
    
    
            
    
}
-(void)callsement
{
    //   [appDelegate showLoadingView]; 
    
    
    if([strFrom isEqualToString:@"newcigar"])
    {
//        strFrom=@"";
        //if(segment.selectedSegmentIndex ==1)
        if([strSelected isEqualToString:@"cuban"])
           
        {
            [self makeArrayNew:arrCuban];
             [segment setSelectedSegmentIndex:1];
            //[mainTableViewNew reloadData];
            //[mainTableViewNew reloadSectionIndexTitles];

        }
        else
        {
            [self makeArray:arrNonCuban];
            [segment setSelectedSegmentIndex:0];
            [mainTableView reloadData];
            [mainTableView reloadSectionIndexTitles];
        }
           
    }
    else
    {
        [self makeArray:arrNonCuban];
        [segment setSelectedSegmentIndex:0];
        [mainTableView reloadData];
        [mainTableView reloadSectionIndexTitles];
    }
    
    
    
}

-(void)makeArray:(NSMutableArray *)storedArray
{
    NSLog(@">>>>> MAke Array");
    arrCigarObj = [[NSMutableArray alloc]init];
    
    
    arrdist = [[NSMutableDictionary alloc] init];
    arrdist2 = [[NSMutableDictionary alloc] init];
    
    
	storedArray =(NSMutableArray *) [storedArray sortedArrayUsingSelector:@selector(compare:)];    
    
	for(int i = 0 ; i < [storedArray count]; i++){
        
 		Cigar *firstLetter = (Cigar *)[storedArray objectAtIndex:i];
        
        NSString *brnd = (NSString *)firstLetter.brand;
        [((NSMutableArray *)arrCigarObj) addObject:brnd];
        [arrCigarObj retain];
    }
    
    
    arrCigarObj = [[arrCigarObj sortedArrayUsingSelector:@selector(compare:)] mutableCopy];
    
    NSMutableArray *newArray = [[NSMutableArray alloc] init];
    NSMutableArray *existingArray = [[NSMutableArray alloc] init];
    NSMutableDictionary *First= [[NSMutableDictionary alloc] init];
    for (id item in arrCigarObj){
        if (NO == [newArray containsObject:item])
            [newArray addObject:item];
        
        if ((existingArray = [First valueForKey:item])) 
		{
			[existingArray addObject:item];
		} 
        else {
			NSMutableArray *tempArray = [NSMutableArray array];
			[First setObject:tempArray forKey:item];
			[tempArray addObject:item];
		}
    }
    
    arrCigarObj = newArray;
    
    BOOL found;
    
    // Loop through the books and create our keys
    for (NSString *book in arrCigarObj)
    {        
        NSString *c = [book  substringToIndex:1];
        
        found = NO;
        
        for (NSString *str in [arrdist allKeys])
        {
            if ([str isEqualToString:c])
            {
                found = YES;
            }
        }
        
        if (!found)
        {     
            [arrdist setValue:[[NSMutableArray alloc] init] forKey:c];
            [arrdist2 setValue:[[NSMutableArray alloc] init] forKey:book];   
        }
    }
    
    // Loop again and sort the books into their respective keys
    for (NSString *book in arrCigarObj)
    {
        [[arrdist objectForKey:[book substringToIndex:1]] addObject:book];
        [[arrdist2 objectForKey:[book substringToIndex:1]] addObject:book];
    }    
    
    // Sort each section array
    for (NSString *key in [arrdist allKeys])
    {
        [arrdist objectForKey:key];
    }    
    
    keys =(NSMutableArray *) [[[arrdist allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    
    
    [self performSelector:@selector(hideByPerform) withObject:nil afterDelay:0.3];   
    
    AllkeyIndexArray = [[[arrdist allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    
    [mainTableView reloadData];
    [mainTableView reloadSectionIndexTitles];
    LoadedNonCuban = TRUE;
}

-(void)makeArrayNew:(NSMutableArray *)storedArray
{
     NSLog(@">>>>> MAke NEW Array");
    arrCigarObjNew = [[NSMutableArray alloc]init];
    
    
    arrdistNew = [[NSMutableDictionary alloc] init];
    arrdist2New = [[NSMutableDictionary alloc] init];
    
    
    [arrdistNew removeAllObjects];
    [arrdist2New removeAllObjects];
    [arrCigarObjNew removeAllObjects];
    //[keysNew release];
    
    keysNew = [[NSMutableArray alloc] init];
    
	storedArray =(NSMutableArray *) [storedArray sortedArrayUsingSelector:@selector(compare:)];    
    
    
    for(int i = 0 ; i < [storedArray count]; i++){
        
 		Cigar *firstLetter = (Cigar *)[storedArray objectAtIndex:i];
        
        NSString *brnd = (NSString *)firstLetter.brand;
        [((NSMutableArray *)arrCigarObjNew) addObject:brnd];
        [arrCigarObjNew retain];
    }
    
    arrCigarObjNew = [[arrCigarObjNew sortedArrayUsingSelector:@selector(compare:)] mutableCopy];
    
    NSMutableArray *newArray = [[NSMutableArray alloc] init];
    
    for (id item in arrCigarObjNew)
        if (NO == [newArray containsObject:item])
            [newArray addObject:item];
    
    arrCigarObjNew = newArray;
    
    BOOL found;
    
    // Loop through the books and create our keys
    for (NSString *book in arrCigarObjNew)
    {        
        NSString *c = [book  substringToIndex:1];
        
        found = NO;
        
        for (NSString *str in [arrdistNew allKeys])
        {
            if ([str isEqualToString:c])
            {
                found = YES;
            }
        }
        
        if (!found)
        {     
            [arrdistNew setValue:[[NSMutableArray alloc] init] forKey:c];
            [arrdist2New setValue:[[NSMutableArray alloc] init] forKey:book];   
        }
    }
    
    // Loop again and sort the books into their respective keys
    for (NSString *book in arrCigarObjNew)
    {
        [[arrdistNew objectForKey:[book substringToIndex:1]] addObject:book];
        [[arrdist2New objectForKey:[book substringToIndex:1]] addObject:book];
    }    
    
    // Sort each section array
    for (NSString *key in [arrdistNew allKeys])
    {
        [arrdistNew objectForKey:key];
    }    
    //[keysNew release];
    keysNew =(NSMutableArray *) [[[arrdistNew allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    [keysNew retain];    
    
    [self performSelector:@selector(hideByPerform) withObject:nil afterDelay:0.3];        
    
    
    LoadedCuban = TRUE;
    
    NSLog(@">>>>>>>>>>>>> 7: %d", [[arrdistNew allKeys] count]);
    //[AllkeyIndexArrayNew removeAllObjects];
    AllkeyIndexArrayNew = (NSMutableArray *)[[[arrdistNew allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    
    [mainTableViewNew reloadData];
    [mainTableViewNew reloadSectionIndexTitles];
    
}
-(void)hideByPerform
{
    [appDelegate hideLoadingView];
}


-(void)onPlusClick
{
    AddCigarDetailViewController *objaddCigar = [[AddCigarDetailViewController alloc]initWithNibName:@"AddCigarDetailViewController" bundle:nil];
    objaddCigar.title = @"New Brand";
    //objaddCigar.ParentObj = self;
    if(segment.selectedSegmentIndex ==1)
    {
        strSelected = @"cuban";
    }
    else
    {
        strSelected=@"";
    }
    objaddCigar.ParentObj = self;
    [self presentModalViewController:objaddCigar animated:YES];
    //[self.navigationController pushViewController:objaddCigar animated:YES];
}
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(closeSearch)];
	if(already) return;
	already = YES;
    
    //	searchingOverlayView = [[SearchingOverlayView alloc] initWithFrame:CGRectMake(0, 44, 320, 440)];
    //	[self.view addSubview:searchingOverlayView];
    //	searchingOverlayView.parent = self;
    //	mainTableView.scrollEnabled = NO;
    //	//mainTableView.tableHeaderView = nil;
    //	[self.view addSubview:searchBar];
}

- (void)closeSearch
{
	already = NO;
	self.navigationItem.rightBarButtonItem = nil;
	[searchingOverlayView removeFromSuperview];
	[searchBar resignFirstResponder];
    searchBar.text = @"";
    [searchBarNew resignFirstResponder];
    searchBarNew.text = @"";    
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(onPlusClick)];
    
	if([searchBar.text length] != 0) [searchingTableView removeFromSuperview];
    if([searchBarNew.text length] != 0) [searchingTableView removeFromSuperview];
    
    //  [searchBarNew removeFromSuperview];
	//[searchBar removeFromSuperview];
	[searchingTableView removeFromSuperview];
    searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 74, 320, 44)];
	searchBar.delegate = self;
    
    if(cubanFlag)
    {
        searchBarNew = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 74, 320, 44)];
        searchBarNew.delegate = self;
      	mainTableViewNew.tableHeaderView = searchBarNew;
        mainTableViewNew.scrollEnabled = YES;        
    }
    else
    {
        searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 74, 320, 44)];
        searchBar.delegate = self;    
       	mainTableView.tableHeaderView = searchBar;
       	mainTableView.scrollEnabled = YES;
    }
    //	mainTableView.tableHeaderView = searchBar;
	//[mainTableView reloadData];
	mainTableView.scrollEnabled = YES;
}
-(void)viewDidAppear:(BOOL)animated
{
    if(appDelegate.adStatus)
    {
        [mainTableView setFrame:CGRectMake(0, 45, 320, 270)];
        [mainTableViewNew setFrame:CGRectMake(0, 45, 320, 270)];
        
    }
    else
    {
        [mainTableView setFrame:CGRectMake(0, 45, 320, 322)];
        [mainTableViewNew setFrame:CGRectMake(0, 45, 320, 322)];
        
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    NSLog(@"its new cigar??????????????????????%@",strFrom);
    
     //NSLog(@"??? Why here %d;;;;;",segment.selectedSegmentIndex);
    if(segment.selectedSegmentIndex ==1)
    {
       
        [mainTableViewNew reloadData];
        
    }
    else
    {
        [mainTableView reloadData];
    }
    //[mainTableView reloadSectionIndexTitles];
    
    
    //[mainTableViewNew reloadSectionIndexTitles];
    
    //    if(!cubanFlag){
    //    [self segmentAction:segment];        
    //    }
    
    
    if(cubanFlag)
    {
        
    }
    else
    {
        LoadedCuban =FALSE;
        LoadedNonCuban = FALSE;
        if ([indexes count]>0) {
            [indexes removeAllObjects];
        }
        arrdistNew = [[NSMutableDictionary alloc] init];
        
        // appDelegate = [(CigarBossAppDelegate *)[UIApplication sharedApplication] delegate];
        
        NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
        
        keys = [brandsDictionary allKeys];
        keys = [keys sortedArrayUsingSelector:@selector(compare:)];
        
        for(NSString *key in keys){
            NSString *firstLetter = [key substringToIndex:1];
            NSMutableArray *existingArray;
            //NSLog(firstLetter);
            // if an array already exists in the name index dictionary
            // simply add the element to it, otherwise create an array
            // and add it to the name index dictionary with the letter as the key
            if ((existingArray = [indexes valueForKey:firstLetter])) 
            {
                [existingArray addObject:key];
            } 
            else 
            {
                NSMutableArray *tempArray = [NSMutableArray array];
                [indexes setObject:tempArray forKey:firstLetter];
                [tempArray addObject:key];
            }
        }
        NSMutableArray *testingofArray = [[NSMutableArray alloc] init];
        keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
        
        for(int k = 0 ; k < [keys count] ; k++)
        {
            NSArray *arr = [indexes objectForKey:[keys objectAtIndex:k]];
            for (int j = 0; j < [arr count]; j++) {
                
                NSMutableArray *cigars = [[appDelegate cigarBrandArrays] objectForKey:[arr objectAtIndex:j]];
                for(int m = 0 ; m < [cigars count] ; m ++)
                {
                    Cigar *cg  = (Cigar *)[cigars objectAtIndex:m];
                    
                    if ([cg.cuban isEqualToString:@"true"]) {
                        [arrCuban addObject:cg];
                    }
                    else
                    {
                        [arrNonCuban addObject:cg];
                    }
                    [testingofArray addObject:cg];
                    
                }
            }
        }
        
        InsertedData = TRUE;
    }
    if([strFrom isEqualToString:@"newcigar"])
    {
        NSLog(@"its new cigar?????????????????????? %d",segment.selectedSegmentIndex);
        [self viewDidLoad];
        if([strSelected isEqualToString:@"cuban"])
        {
            mainTableViewNew.hidden=FALSE;
            [mainTableView removeFromSuperview];
            
        }
        //[self segmentAction:segment];
        
        
    }
}


- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
	if([searchText length] == 0)
    {
		if(searchingTableView){
			[searchingTableView removeFromSuperview];
		}
	} 
    else 
    {
		if(matchedStates)
        {
			[matchedStates release];
			matchedStates = nil;
		}
		
		matchedStates = [[NSMutableArray alloc] init];
		
		
		NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
        //    NSLog(@">>>>>>>> ArrDict = %@ >>>>\n \n",arrdist);
        
        //  NSLog(@">>>>>>>> brandsDictionary = %@  >>>>\n \n",brandsDictionary);   
		NSArray *allBrands = [brandsDictionary allKeys];
		for(NSString *brand in allBrands){
			NSRange titleResultsRange = [brand rangeOfString:searchText options:NSCaseInsensitiveSearch];
			if(titleResultsRange.length > 0){
				[matchedStates addObject:brand];
			}
		}
        
        //        if(cubanFlag)
        //        {
        //           // NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
        //            NSArray *allBrands = [arrdistNew allKeys];
        //            for(NSString *brand in allBrands){
        //                NSRange titleResultsRange = [brand rangeOfString:searchText options:NSCaseInsensitiveSearch];
        //                if(titleResultsRange.length > 0){
        //                    [matchedStates addObject:brand];
        //                }
        //            }   
        //        }
        //        else
        //        {
        //            NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
        //            NSArray *allBrands = [arrdist allKeys];
        //            for(NSString *brand in allBrands){
        //                NSRange titleResultsRange = [brand rangeOfString:searchText options:NSCaseInsensitiveSearch];
        //                if(titleResultsRange.length > 0){
        //                    [matchedStates addObject:brand];
        //                }
        //            }       
        //        }
		
		searchResultsDataSource.results = matchedStates;
		if(!searchingTableView)
		{
			searchingTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 90, 320, 157) style:UITableViewStylePlain];
			searchingTableView.delegate = searchResultsDataSource;
			searchingTableView.dataSource = searchResultsDataSource;
		}
		
		if(searchingTableView.superview != self.view){
			[self.view addSubview:searchingTableView];
		}
		
		[searchingTableView reloadData];
	}
}


-(void) segmentAction: (id) sender
{
    // [appDelegate showLoadingView];  
    [searchBarNew resignFirstResponder];
    [searchBar resignFirstResponder];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(onPlusClick)];
    searchBar.text = @"";
    searchBarNew.text= @"";
    [searchingTableView removeFromSuperview];
    
    
    switch([sender selectedSegmentIndex])
    {
        case 0: 
            cubanFlag = FALSE;    
            
            mainTableView.hidden = FALSE;
            mainTableViewNew.hidden = TRUE;
            [self makeArray:arrNonCuban];
            [mainTableView reloadData];
            if([strSelected isEqualToString:@"cuban"])
            {
                [self.view addSubview:mainTableView];
                
            }
        
            break;
            
		case 1: 
            cubanFlag = TRUE; 
            
            mainTableView.hidden = TRUE;
            mainTableViewNew.hidden = FALSE;
            
            [self makeArrayNew:arrCuban];                
            
            break;
    }
}

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
