//
//  BrandsViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryListViewController.h"

//@class CigarBossAppDelegate;
@class SearchResultsObject;
@class SearchingOverlayView;
@class NonCubanViewController, CubanViewController;


@interface BrandsViewController : UIViewController<UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate, SubstitutableDetailViewController> 
{
	IBOutlet UITableView *mainTableView;
	IBOutlet UISearchBar *searchBar;
	
    IBOutlet UITableView *mainTableViewNew;
	IBOutlet UISearchBar *searchBarNew;
    
	BOOL already;
    BOOL InsertedData;
    
	UITableView *searchingTableView;
	NSMutableArray *matchedStates;
    
	SearchResultsObject *searchResultsDataSource;
	SearchingOverlayView *searchingOverlayView;
	
//	CigarBossAppDelegate *appDelegate;
	NSArray *keys;
	NSMutableDictionary *indexes;
    
    NSMutableArray *Ncigars;
        
   IBOutlet UIView *topView;
    NSMutableArray *arrNonCuban;
    
    BOOL cubanFlag;
    
    
    NSMutableArray *arrCigarObj;
    NSMutableDictionary *arrdist;
    NSMutableDictionary *arrdist2;
    NSArray *AllkeyIndexArray;

	NSArray *keysNew;
    NSMutableArray *arrCigarObjNew;
    NSMutableDictionary *arrdistNew;
    NSMutableDictionary *arrdist2New;
    NSMutableArray *AllkeyIndexArrayNew;

    NSString *strSelected;
    NSString *strFrom;
    BOOL LoadedNonCuban;
    
    NonCubanViewController *objNonCubanView;
}

@property(nonatomic,retain) IBOutlet UISearchBar *searchBar;
@property(nonatomic,retain) NSString *strFrom;
@property(nonatomic,retain) NSString *strSelected;
@property(nonatomic) NSInteger       mShowType;
-(void)onPlusClick;
-(void) showSegmentAction;
-(void) segmentAction: (id) sender;
-(void)reloaTableDataForSegment;
-(void)moveTOCigarsViewController:(NSString *)brand;
- (void) refreshTableView;


@end