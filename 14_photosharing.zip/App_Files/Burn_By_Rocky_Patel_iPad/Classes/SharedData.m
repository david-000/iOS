//
//  SharedData.m
//  CigarBoss_Free
//
//  Created by Lion User on 17/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CigarBossAppDelegate.h"
#import "SharedData.h"
#import "Cigar.h"

static SharedData *g_sharedInfo = nil;

@implementation SharedData
@synthesize mOperationQueue;
@synthesize mEventsArray;

- (id) init {
	if ( self = [super init] ) {
		[self initSharedData];
	}
	return self;
}

- (void) dealloc
{
    [mOperationQueue release];
    [super dealloc];
}

- (void) initSharedData
{
    mOperationQueue = [[NSOperationQueue alloc] init];
    [mOperationQueue setMaxConcurrentOperationCount:1];
    
    mEventsArray = [[NSMutableArray alloc] init];
}

+ (SharedData *) sharedData {
    
	if (g_sharedInfo == nil) {
		g_sharedInfo = [[SharedData alloc] init];
	}
    
	return g_sharedInfo;
}

- (NSMutableArray *) getStaffFavoriteArray
{
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *) [[UIApplication sharedApplication] delegate];

    NSMutableArray *typeArray = [[NSMutableArray alloc] init];
    NSMutableArray *sortedArray = [[NSMutableArray alloc] init];
    
    NSArray *keys;
    NSMutableDictionary *indexes = [[NSMutableDictionary alloc] init];
    
    NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
    
    keys = [brandsDictionary allKeys];
    keys = [keys sortedArrayUsingSelector:@selector(compare:)];
    
    for(NSString *key in keys){
        NSString *firstLetter = [key substringToIndex:1];
        NSMutableArray *existingArray;
        
        if ((existingArray = [indexes valueForKey:firstLetter]))
        {
            [existingArray addObject:key];
        }
        else
        {
            NSMutableArray *tempArray = [NSMutableArray array];
            [indexes setObject:tempArray forKey:firstLetter];
            [tempArray addObject:key];
        }
    }
    
    keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    
    for(int k = 0 ; k < [keys count] ; k++)
    {
        NSArray *arr = [indexes objectForKey:[keys objectAtIndex:k]];
        for (int j = 0; j < [arr count]; j++) {
            
            NSMutableArray *cigars = [[appDelegate cigarBrandArrays] objectForKey:[arr objectAtIndex:j]];
            for(int m = 0 ; m < [cigars count] ; m ++)
            {
                Cigar *cg  = (Cigar *)[cigars objectAtIndex:m];
                
                if ( cg.isStaffFavorite == 1 )
                    [typeArray addObject:cg];
            }
            
        }
    }
    
    NSSortDescriptor *desc = [NSSortDescriptor sortDescriptorWithKey:@"brand" ascending:YES selector:@selector(localizedCompare:)];
    [sortedArray addObjectsFromArray:[typeArray sortedArrayUsingDescriptors:[NSArray arrayWithObject:desc]]];
    [typeArray release];
    [indexes release];
    
    return sortedArray;
}

- (NSMutableArray *) getSpecialArray
{
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *) [[UIApplication sharedApplication] delegate];
    
    NSMutableArray *typeArray = [[NSMutableArray alloc] init];
    NSMutableArray *sortedArray = [[NSMutableArray alloc] init];
    
    NSArray *keys;
    NSMutableDictionary *indexes = [[NSMutableDictionary alloc] init];
    
    NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
    
    keys = [brandsDictionary allKeys];
    keys = [keys sortedArrayUsingSelector:@selector(compare:)];
    
    for(NSString *key in keys){
        NSString *firstLetter = [key substringToIndex:1];
        NSMutableArray *existingArray;
        
        if ((existingArray = [indexes valueForKey:firstLetter]))
        {
            [existingArray addObject:key];
        }
        else
        {
            NSMutableArray *tempArray = [NSMutableArray array];
            [indexes setObject:tempArray forKey:firstLetter];
            [tempArray addObject:key];
        }
    }
    
    keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    
    for(int k = 0 ; k < [keys count] ; k++)
    {
        NSArray *arr = [indexes objectForKey:[keys objectAtIndex:k]];
        for (int j = 0; j < [arr count]; j++) {
            
            NSMutableArray *cigars = [[appDelegate cigarBrandArrays] objectForKey:[arr objectAtIndex:j]];
            for(int m = 0 ; m < [cigars count] ; m ++)
            {
                Cigar *cg  = (Cigar *)[cigars objectAtIndex:m];
                
                if ( cg.isSpecial == 1 )
                    [typeArray addObject:cg];
            }
            
        }
    }
    
    NSSortDescriptor *desc = [NSSortDescriptor sortDescriptorWithKey:@"brand" ascending:YES selector:@selector(localizedCompare:)];
    [sortedArray addObjectsFromArray:[typeArray sortedArrayUsingDescriptors:[NSArray arrayWithObject:desc]]];
    [typeArray release];
    [indexes release];
    
    return sortedArray;
}

- (NSMutableArray *) getFeaturedCigarArray
{
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *) [[UIApplication sharedApplication] delegate];
    
    NSMutableArray *typeArray = [[NSMutableArray alloc] init];
    NSMutableArray *sortedArray = [[NSMutableArray alloc] init];
    
    NSArray *keys;
    NSMutableDictionary *indexes = [[NSMutableDictionary alloc] init];
    
    NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
    
    keys = [brandsDictionary allKeys];
    keys = [keys sortedArrayUsingSelector:@selector(compare:)];
    
    for(NSString *key in keys){
        NSString *firstLetter = [key substringToIndex:1];
        NSMutableArray *existingArray;
        
        if ((existingArray = [indexes valueForKey:firstLetter]))
        {
            [existingArray addObject:key];
        }
        else
        {
            NSMutableArray *tempArray = [NSMutableArray array];
            [indexes setObject:tempArray forKey:firstLetter];
            [tempArray addObject:key];
        }
    }
    
    keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    
    for(int k = 0 ; k < [keys count] ; k++)
    {
        NSArray *arr = [indexes objectForKey:[keys objectAtIndex:k]];
        for (int j = 0; j < [arr count]; j++) {
            
            NSMutableArray *cigars = [[appDelegate cigarBrandArrays] objectForKey:[arr objectAtIndex:j]];
            for(int m = 0 ; m < [cigars count] ; m ++)
            {
                Cigar *cg  = (Cigar *)[cigars objectAtIndex:m];
                
                if ( cg.isFeaturedCigar == 1 && cg.isMyCigar == 1 )
                    [typeArray addObject:cg];
            }
            
        }
    }
    
    NSSortDescriptor *desc = [NSSortDescriptor sortDescriptorWithKey:@"brand" ascending:YES selector:@selector(localizedCompare:)];
    [sortedArray addObjectsFromArray:[typeArray sortedArrayUsingDescriptors:[NSArray arrayWithObject:desc]]];
    [typeArray release];
    [indexes release];
    
    return sortedArray;
}

+ (void) saveUpdatedTime : (double) update_time
{
    NSLog(@"update time = %f", update_time);
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        
    [defaults setInteger:(int)update_time forKey:@"updated_time"];
    [defaults synchronize];
}

+ (double) getUpdatedTime
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    return [defaults doubleForKey:@"updated_time"];
}

+ (void) saveEventUpdatedTime : (double) update_time
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    [defaults setInteger:(int)update_time forKey:@"event_updated_time"];
    [defaults synchronize];
}

+ (double) getEventUpdatedTime
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    return [defaults doubleForKey:@"event_updated_time"];
}

+ ( NSDate *) getUTCFormateDate : (NSDate *) localDate
{  
    NSTimeZone* currentTimeZone = [NSTimeZone localTimeZone];
    NSTimeZone* utcTimeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    
    NSInteger currentGMTOffset = [currentTimeZone secondsFromGMTForDate:localDate];
    NSInteger gmtOffset = [utcTimeZone secondsFromGMTForDate:localDate];
    NSTimeInterval gmtInterval = gmtOffset - currentGMTOffset;
    
    NSDate* destinationDate = [[[NSDate alloc] initWithTimeInterval:gmtInterval sinceDate:localDate] autorelease];
    return destinationDate;    
}

@end
