//
//  CigarViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Cigar.h"
#import "AsyncImageView.h"
#import "RatingView.h"
#import "CategoryListViewController.h"
#import <Accounts/Accounts.h>
#import <Social/SLRequest.h>
#import <Social/Social.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>
#import <MessageUI/MFMessageComposeViewController.h>

@class RateStarView;
@interface CigarViewController : UIViewController <UIImagePickerControllerDelegate,UIAlertViewDelegate,UINavigationControllerDelegate,UITableViewDelegate,UITableViewDataSource, SubstitutableDetailViewController, UIPopoverControllerDelegate, UIGestureRecognizerDelegate, UIDocumentInteractionControllerDelegate, MFMailComposeViewControllerDelegate>{
	    
    RatingView *objRatingView;
    
    IBOutlet UILabel *typeLabel;
	IBOutlet UILabel *brandLabel;
	IBOutlet UILabel *cigarLabel;
	IBOutlet UILabel *sizeLabel;
	IBOutlet UILabel *lengthLabel;
	IBOutlet UILabel *ringLabel;
	IBOutlet UILabel *countryLabel;
	IBOutlet UILabel *colorLabel;
	IBOutlet UILabel *originLabel;
	IBOutlet UILabel *strengthLabel;
	IBOutlet UILabel *descriptionLabel;
    IBOutlet UILabel *priceLabel;
	IBOutlet UIScrollView *scrollView;
    IBOutlet UILabel *boxPriceLabel;
    IBOutlet UILabel *clickToRateLabel;
	Cigar *cigar;
	IBOutlet UIButton *addNoteButton;
    IBOutlet UIButton *facebookButton;
    IBOutlet UIButton *twitterButton;
	IBOutlet AsyncImageView *imageView;
    
    IBOutlet UILabel *lblstar;
	
    
    IBOutlet RateStarView *rView;
    IBOutlet UIView *ratingsView;
    
    IBOutlet UILabel *humidorCountLabel;
    NSMutableArray *adjustedLabels;
    
    IBOutlet UILabel *totRevLabel;
    IBOutlet UILabel *lblUserReview;
    
    
    BOOL forFeaturedCigar;
    
    BOOL loadedAlready;
    NSMutableArray *revLink;
    
    NSMutableArray *photoArray;
    IBOutlet UIButton *btnRev;
    
    NSUserDefaults *userDefault;
    IBOutlet UIImageView *imgView;
    BOOL pass;
    
    NSMutableData *webData;
	NSXMLParser *xmlParser;
	NSString *element;
    
    NSString *revText;
    NSString *revTotalText;
    
    NSString *star;
    NSString *starReview;
    
    
    NSMutableArray *userArray;
    
    UITableView *tblView;
    
    float scr;
    
    IBOutlet UIButton *btnReviewNew;
    IBOutlet UIButton *btnMyWishList;
    BOOL isUpdate;
    
    NSString *pathOfImage;
    NSString *twitString;
    
    UIPopoverController *popOverController;
    SLComposeViewController *mySLComposerSheet;

}
//#define soapAction @"http://logisticinfotech.com/client/webservicecigar/soap-server.php"
//#define xmlns @"http://logisticinfotech.com/soap/cigarboss"

#define soapAction @"http://cigarboss.co/webservice/soap-server.php"
#define xmlns @"http://cigarboss.co/soap/cigarboss"

@property (nonatomic, assign) Cigar *cigar;
@property (nonatomic, assign) UIScrollView *scrollView;
@property (nonatomic, retain) UIDocumentInteractionController *mDic;

@property (nonatomic, assign) BOOL forFeaturedCigar;
@property (nonatomic, assign) BOOL pass;

@property (nonatomic, assign)  BOOL isUpdate;
@property (nonatomic, retain) UIPopoverController *popOverController;
@property (nonatomic) NSInteger mShowType;
- (IBAction)twitter;
- (IBAction)facebook;

- (IBAction)requestCigarButtonClicked:(id)sender;
- (IBAction)addToHumidors;
- (IBAction)addToMyList;
- (IBAction)addNote;
-(void)onRevicButtonClick;
- (IBAction)shareInstagramButtonClicked:(id)sender;
-(void)StarRateWebFunction : (NSString *) id;

-(IBAction)onRevBtnClick:(id)sender;
-(void) imageFromImagePath : (NSString *) path;
- (void)loadImageFromURL:(NSURL*)url : (NSString*)name;
-(NSString *)applicationDocumentsDirectory;
- (void) facebookShareImage : (UIImage *) image;

-(void)setDataInTable;

-(void)setReviewText;
-(void)loadURL:(NSURL *)url;
-(void)altcancelclicked_fbshare;
@end
