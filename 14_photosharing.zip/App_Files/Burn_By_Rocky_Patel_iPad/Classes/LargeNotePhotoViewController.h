//
//  LargeNotePhotoViewController.h
//  CigarBoss
//
//  Created by Nitin on 16/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LargeNotePhotoViewController : UIViewController
{
    IBOutlet UIImageView *imageView;
	UIImage *image;

}
@property (nonatomic, assign ) UIImage *image;
-(IBAction)closeView:(id)sender;
@end
