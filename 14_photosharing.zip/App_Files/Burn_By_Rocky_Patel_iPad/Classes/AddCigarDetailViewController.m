//
//  AddCigarDetailViewController.m
//  CigarBoss
//
//  Created by Nitin on 14/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AddCigarDetailViewController.h"
#import "CigarBossAppDelegate.h"

#import <QuartzCore/QuartzCore.h>


CigarBossAppDelegate *appDelegate;

@implementation AddCigarDetailViewController
@synthesize ParentObj;
@synthesize popOverController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    ParentObj.strFrom=@"newcigar";
    [scrollView setFrame:CGRectMake(0, 44, 703, 704)];
    [scrollView setContentSize:CGSizeMake(703, 800)];
    [scrollView setScrollEnabled:YES];
    txtDesc.layer.cornerRadius = 5.0;
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(IBAction)closeView
{
    [self dismissModalViewControllerAnimated:YES]; 
}

-(IBAction)OnbtnDoneClick:(id)sender{
    
    if(txtName.text.length > 0 && txtBrand.text.length > 0){
        [self AddCigarwriteToPlist];
    }
    else
    {
        UIAlertView *e = [[UIAlertView alloc] initWithTitle:@"Blank Fields!" message:@"You have left some fields blank!" delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
        [e show];
        [e release];
        return;
    }
}

- (void)AddCigarwriteToPlist
{
    int count;
    
    NSUserDefaults *ImageNumber = [NSUserDefaults standardUserDefaults];
    if ([ImageNumber integerForKey:@"CigarImageNumber"] > 0) {
        
        count = [ImageNumber integerForKey:@"CigarImageNumber"];
    }else{
        count = 0;
    }
//    
//    
//    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
//    NSString *documentsDirectory = [paths objectAtIndex:0];
//    NSString *tempname = [NSString stringWithFormat:@"CigarImage%d.png",count];
//    NSString *savedImagePath = [documentsDirectory stringByAppendingPathComponent:tempname];
//    UIImage *image = imgCigarView.image; // imageView is my image from camera
//    NSData *imageData = UIImagePNGRepresentation(image);
//    [imageData writeToFile:savedImagePath atomically:NO]; 
//    
    NSUserDefaults *number2 = [NSUserDefaults standardUserDefaults];
    count++;
    [number2 setInteger:count forKey:@"CigarImageNumber"];
    [number2 synchronize];
    
    
    Cigar *newCigObj = [[Cigar alloc]init];
    
    newCigObj.brand = txtBrand.text;
    newCigObj.origin =@"";
    newCigObj.type =txtName.text;
    newCigObj.price =txtPrice.text;
    newCigObj.length =txtLength.text;
    newCigObj.ring = txtRing.text;
    newCigObj.strength = txtStrenth.text;
    newCigObj.country = txtCountry.text;
    newCigObj.generalInfo = txtDesc.text;
    newCigObj.pictureURL = [NSString stringWithFormat:@"%@",savedImagePath];
    newCigObj.boxprice = @"Not Available";
    newCigObj.wrapper = @"Not Available";
    
    appDelegate =(CigarBossAppDelegate *) [[UIApplication sharedApplication] delegate];
    //NSMutableArray *cigars = [[appDelegate cigarBrandArrays] objectForKey:@"null"];
    
    NSMutableArray *cigarArray = [[NSMutableArray alloc] initWithCapacity:2];
    [cigarArray addObject:txtBrand.text];
    [cigarArray addObject:newCigObj];
    [appDelegate addNewCigarList:cigarArray];
    [appDelegate saveNewCigarList];
    
    NSString *tempBrandId = [NSString stringWithFormat:@"400%d",count];
    newCigObj.brandId = tempBrandId;
    
    NSString *tempBrand = txtBrand.text;
    
    tempBrand = [tempBrand stringByReplacingCharactersInRange:NSMakeRange(0,1) withString:[[tempBrand substringToIndex:1] uppercaseString]];
    
    NSMutableArray *addArray;
    NSMutableDictionary *appDelBrandsArrays = [appDelegate cigarBrandArrays];
    if([appDelBrandsArrays objectForKey:tempBrand] == nil){
        addArray = [[NSMutableArray alloc] init];
        [appDelBrandsArrays setObject:addArray forKey:tempBrand];
    } else {
        addArray = [appDelBrandsArrays objectForKey:tempBrand];
    }
    
    [addArray addObject:newCigObj];
    
    [ParentObj reloaTableDataForSegment];
    [self dismissModalViewControllerAnimated:YES];
    
}

- (IBAction)UploadImage{
    
    //    imagePickerController = [[UIImagePickerController alloc] init];
    //    imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    //    imagePickerController.navigationBar.barStyle = UIBarStyleBlack;
    //    imagePickerController.delegate = self;
    //    imagePickerController.allowsEditing = NO;
    //    [self presentModalViewController:imagePickerController animated:YES];
    //    [imagePickerController release];
    UIActionSheet *action = [[UIActionSheet alloc]initWithTitle:@"" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Take A Photo",@"Existing Photo",nil];//@"Clear Message Log" == 0 
    //    action.tag = 99;
    [action showInView:self.view];
    [action release];
}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    CustomImagePickerController * picker = [[CustomImagePickerController alloc] init];
	picker.delegate = self;
    if(buttonIndex==0)
    { 
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
//            picker.sourceType = UIImagePickerControllerSourceTypeCamera;
//            [self presentModalViewController:picker animated:YES];
            picker = [[CustomImagePickerController alloc] init];
            picker.sourceType = UIImagePickerControllerSourceTypeCamera;
            picker.navigationBar.barStyle = UIBarStyleBlack;                
            picker.delegate = self;
            picker.allowsEditing = NO;
            [self presentModalViewController:picker animated:YES];
            [picker release];
        
        }
        else {
            
            UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Unavailable Source" message:@"This function needs a camera which is only available on the iPhone or iPod." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alert show];
            [alert release];
        }
    }
    else if(buttonIndex==1)
    {
        if ( [popOverController isPopoverVisible] ) {
            [popOverController dismissPopoverAnimated:YES];
        } else {
            
            CustomImagePickerController *picker = [[CustomImagePickerController alloc] init];
            picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            picker.navigationBar.barStyle = UIBarStyleBlack;                
            picker.delegate = self;
            
            UIPopoverController *popoverController = [[UIPopoverController alloc] initWithContentViewController:picker];
            
            popoverController.delegate = self;
            CGRect popoverRect = [self.view convertRect:[self.view frame] fromView:[self.view superview]];
            popoverRect.size.width = MIN(popoverRect.size.width, 80);
            popoverRect.origin.x = popoverRect.origin.x + 150;
            [popoverController presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            
            self.popOverController = popoverController;
            
        }
        
    }
    [actionSheet dismissWithClickedButtonIndex:2 animated:YES]; 
}
- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *capturedImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
//    imgCigarView.image = capturedImage;
    
    [picker dismissModalViewControllerAnimated:YES];      

    [self performSelector:@selector(waitUntillImageCaptured:) withObject:capturedImage afterDelay:0.2];
}

-(void)waitUntillImageCaptured:(UIImage *)originalImage
{
    //UIImageOrientation    originalOrientation = originalImage.imageOrientation;
    
    UIImage *tempimg;// = [self rotateImage:originalImage byOrientationFlag:originalOrientation];
    
    tempimg = [self scaleAndRotateImage:originalImage];
    //UIImageWriteToSavedPhotosAlbum(tempimg,nil,nil,nil);
    
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    
    
    int count;
    
    NSUserDefaults *ImageNumber = [NSUserDefaults standardUserDefaults];
    if ([ImageNumber integerForKey:@"CigarImageNumber"] > 0) {
        
        count = [ImageNumber integerForKey:@"CigarImageNumber"];
    }else{
        count = 0;
    }
    
    
   
  
    NSString *strUser = [NSString stringWithFormat:@"CigarImage%d.png",count];
    [strUser retain];
    
    NSString *imagePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:strUser];
    
    savedImagePath = [NSString stringWithFormat:@"%@",imagePath];
    [savedImagePath retain];
    UIImageView *tempView = [[UIImageView alloc] initWithImage:tempimg];
    NSData *data = [NSData dataWithData:UIImagePNGRepresentation(tempView.image)];
    [tempView release];
    
    if(data != nil) {
        [CigarBossAppDelegate adSkipBackUpAttributeToItemAtURL:imagePath];
        [data writeToFile:imagePath atomically:YES];
    }
    else{
        [[NSFileManager defaultManager] removeItemAtPath:imagePath error:NULL];
    }
    
    [pool release];
    
    [self performSelector:@selector(thumbWithSideOfLength:) withObject:strUser afterDelay:0.3];
}
# pragma -
# pragma Scale and Rotate according to Orientation

- (UIImage *)scaleAndRotateImage:(UIImage *)image {
    int kMaxResolution = 550; // Or whatever
    
    CGImageRef imgRef = image.CGImage;
    
    CGFloat width = CGImageGetWidth(imgRef);
    CGFloat height = CGImageGetHeight(imgRef);
    
    
    CGAffineTransform transform = CGAffineTransformIdentity;
    CGRect bounds = CGRectMake(0, 0, width, height);
    if (width > kMaxResolution || height > kMaxResolution) {
        CGFloat ratio = width/height;
        if (ratio > 1) {
            bounds.size.width = kMaxResolution;
            bounds.size.height = roundf(bounds.size.width / ratio);
        }
        else {
            bounds.size.height = kMaxResolution;
            bounds.size.width = roundf(bounds.size.height * ratio);
        }
    }
    
    CGFloat scaleRatio = bounds.size.width / width;
    CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
    CGFloat boundHeight;
    UIImageOrientation orient = image.imageOrientation;
    switch(orient) {
            
        case UIImageOrientationUp: //EXIF = 1
            
            // landscape right
            transform = CGAffineTransformIdentity;
            break;
            
        case UIImageOrientationUpMirrored: //EXIF = 2
            transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            break;
            
        case UIImageOrientationDown: //EXIF = 3
            
            // landscape left
            transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationDownMirrored: //EXIF = 4
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
            transform = CGAffineTransformScale(transform, 1.0, -1.0);
            break;
            
        case UIImageOrientationLeftMirrored: //EXIF = 5
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationLeft: //EXIF = 6
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationRightMirrored: //EXIF = 7
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeScale(-1.0, 1.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
            
        case UIImageOrientationRight: //EXIF = 8
            
            // Portrait Mode 
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
            
        default:
            [NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];
    }
    
    UIGraphicsBeginImageContext(bounds.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {
        CGContextScaleCTM(context, -scaleRatio, scaleRatio);
        CGContextTranslateCTM(context, -height, 0);
    }
    else {
        CGContextScaleCTM(context, scaleRatio, -scaleRatio);
        CGContextTranslateCTM(context, 0, -height);
    }
    
    CGContextConcatCTM(context, transform);
    
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
    UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return imageCopy;
}

#pragma mark -
#pragma mark make thumbnail image 

- (void)thumbWithSideOfLength:(NSString*)strImgName {
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
	
    //NSString *fullPathToUser = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.jpg", strImgName]];
    
	NSString *fullPathToThumbImage = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@", strImgName]];
    
    imgCigarView.backgroundColor = [UIColor clearColor];
    
    [imgCigarView setImage:[UIImage imageWithContentsOfFile:fullPathToThumbImage]];
}

#pragma mark -
#pragma mark path for Document Directory
-(NSString *)applicationDocumentsDirectory {
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
	return basePath;
}


- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    // Any new character added is passed in as the "text" parameter
    if ([text isEqualToString:@"\n"]) {
        // Be sure to test for equality using the "isEqualToString" message
        [txtDesc resignFirstResponder];
        [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
        return FALSE;
    }
    return TRUE;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.tag == 7) {
       
        [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    }
    if (textField.tag == 8) {
       
        [scrollView setContentOffset:CGPointMake(0, 60) animated:YES];
    }
    
    if (textField.tag == 9) {
       
        [scrollView setContentOffset:CGPointMake(0, 80) animated:YES];
    }
    if (textField.tag == 10) {
       
        [scrollView setContentOffset:CGPointMake(0, 120) animated:YES];
    }
    if (textField.tag == 11) {
       
        
        [scrollView setContentOffset:CGPointMake(0, 150) animated:YES];
    }
    if (textField.tag == 12) {
       
        
        [scrollView setContentOffset:CGPointMake(0, 190) animated:YES];
    }
    if (textField.tag == 13) {
       
        
        [scrollView setContentOffset:CGPointMake(0, 240) animated:YES];
        
       
    }
    if (textField.tag == 14) {
       
        
        [scrollView setContentOffset:CGPointMake(0, 400) animated:YES];
       
    }
    if (textField.tag == 15) {
       
        
        [scrollView setContentOffset:CGPointMake(0, 330) animated:YES];    }
    if (textField.tag == 16) {
        [scrollView setContentOffset:CGPointMake(0, 390) animated:YES];
    }
}
-(void)textViewDidBeginEditing:(UITextView *)textView
{
    if (textView.tag == 16) {
        [scrollView setContentOffset:CGPointMake(0, 415) animated:YES];
    }
    
}

- (void)textFieldDidEndEditing:(UITextView *)textView {
    [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
}

- (void)textViewDidEndEditing:(UITextView *)textView {
    [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)keyboardWillShow:(NSNotification *)notif {
    CGRect scrollViewFrame = scrollView.frame;
    [UIView beginAnimations:nil context:Nil];
    [UIView setAnimationDuration:.3];
    CGSize keyBoardSize = [[[notif userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey]CGRectValue].size;
    scrollViewFrame.size = CGSizeMake(703, scrollViewFrame.size.height-keyBoardSize.height);
    scrollView.frame = scrollViewFrame;
    
    [scrollView setContentOffset:CGPointMake(0, 400) animated: YES];
    
    [UIView commitAnimations];
}

- (void)keyboardWillHide:(NSNotification *)notif {
    //    CGRect scrollViewFrame = scrollView.frame;
    //    [UIView beginAnimations:nil context:Nil];
    //    [UIView setAnimationDuration:.3];
    //    CGSize keyBoardSize = [[[notif userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey]CGRectValue].size;
    //    scrollViewFrame.size = CGSizeMake(320, scrollViewFrame.size.height+keyBoardSize.height);
    //    scrollView.frame = scrollViewFrame;
    //    CGPoint bottomOffset = CGPointMake(0, 0);
    //    [scrollView setContentOffset:bottomOffset];
    /*if([pricePaidTextfield isFirstResponder] || [tastingNotesTextField isFirstResponder]){
     CGPoint bottomOffset = CGPointMake(0, 100);
     [scrollView setContentOffset: bottomOffset animated: YES];
     }*/
    //    [UIView commitAnimations];
   // NSLog(@"Inside keyboardWillHide");
}

- (void)dealloc
{
    [popOverController release];
    [super dealloc];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
