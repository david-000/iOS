//
//  MyNotesViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 11/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyNotesViewController2.h"
#import "CustomHighlightedCell.h"
#import "ViewNoteViewController.h"

@implementation MyNotesViewController2

@synthesize notes;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        /*id appDelegate = [[UIApplication sharedApplication] delegate];
        NSMutableArray *tempNotes = [[NSMutableArray alloc] init];
        for(NSArray *noteA in [appDelegate notes]){
            [tempNotes addObject:[noteA objectAtIndex:0]];
        }
        
        NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"brand" ascending:YES];
        notes = [tempNotes sortedArrayUsingDescriptors:[NSArray arrayWithObject:sort]];
        [tempNotes release];
        NSLog([notes description]);*/
    }
    return self;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [notes count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BrandCell"];
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"BrandCell"] autorelease];
	}
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.textLabel.textColor = [UIColor whiteColor];
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    NSDictionary *saveDict = [notes objectAtIndex:indexPath.row];
    NSDate *date = [saveDict objectForKey:@"date"];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
    cell.textLabel.adjustsFontSizeToFitWidth = YES;
    cell.textLabel.minimumFontSize = 12.0;
    cell.textLabel.text = [NSString stringWithFormat:@"%@ - %@ - %@ points", [saveDict objectForKey:@"location"], [dateFormatter stringFromDate:date], [saveDict objectForKey:@"score0or100"]];
	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ViewNoteViewController *v = [[ViewNoteViewController alloc] initWithNibName:@"ViewNoteViewController" bundle:nil];
    v.note = [notes objectAtIndex:indexPath.row];
    [self presentModalViewController:v animated:YES];
    
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)edit
{
	[mainTableView setEditing:!mainTableView.editing animated:YES];
	self.editing = !self.editing;
	
	if(!self.editing){
		self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(edit)];
	} else {
		self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(edit)];
	}
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [notes removeObjectAtIndex:indexPath.row];
    [[[UIApplication sharedApplication] delegate] saveMyNotesData];
    [mainTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationTop];
    if([notes count] == 1){
        [self setEditing:NO animated:YES];
        [mainTableView setEditing:NO animated:YES];
        self.navigationItem.rightBarButtonItem = nil;
    }
}

-(void)viewDidAppear:(BOOL)animated
{
    if(AppDelegate.adStatus)
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 614)];
    }
    else
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 704)];        
    }
    
}
- (void)viewDidLoad
{

    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if([notes count] > 1){
        UIBarButtonItem *editBtn = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(edit)];
        self.navigationItem.rightBarButtonItem = editBtn;
    }
    
    mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 704)];
	bgView.image = [UIImage imageNamed:@"right_side.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
	
	self.title = @"My Notes";
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 703, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =self.title; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
