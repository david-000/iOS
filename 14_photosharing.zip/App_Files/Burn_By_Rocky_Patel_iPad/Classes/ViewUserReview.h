//
//  ViewUserReview.h
//  CigarBoss
//
//  Created by Nitin on 27/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"


@interface ViewUserReview : UIViewController<UITextFieldDelegate,UITextViewDelegate,UIScrollViewDelegate>

{
    IBOutlet UIScrollView *scrollView;
    IBOutlet UIImageView *imgUpload;
    
    IBOutlet UIButton *s1;
    IBOutlet UIButton *s2;
    IBOutlet UIButton *s3;
    IBOutlet UIButton *s4;
    IBOutlet UIButton *s5;
    
    
    IBOutlet UILabel *lblPrice;
    IBOutlet UILabel *lblHeadline;
    IBOutlet UILabel *lblRenote;
    
    IBOutlet UITextView *txtRenote;
    
    IBOutlet UILabel *lblRate;
    IBOutlet UILabel *lblDateSmoked;
    
    IBOutlet UIButton *btnClose;
    
    IBOutlet AsyncImageView *imgView;
    NSMutableDictionary *dictObj;
    
    IBOutlet UITextView *txtHeadline;
    IBOutlet UIImageView *TempImgView;
    
   
}

@property (nonatomic,retain) NSMutableDictionary *dictObj;

@end
