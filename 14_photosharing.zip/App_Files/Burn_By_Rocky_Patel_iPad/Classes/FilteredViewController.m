//
//  FilteredViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FilteredViewController.h"
#import "Cigar.h"
#import "CigarViewController.h"
#import "CustomHighlightedCell.h"




@implementation FilteredViewController

@synthesize filterType;
@synthesize allCigarsArray;

 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
		filterType = 0;
		indexes = [[NSMutableDictionary alloc] init];
    }
    return self;
}



- (int)numberOfSectionsInTableView:(UITableView *)tableView
{
	NSString *key = @"type";
	if(filterType == 1) key = @"strength";
	if(filterType == 2) key = @"ring";
	if(filterType == 3) key = @"country";
	if(filterType == 4) key = @"wrapper";
	if(filterType == 5) key = @"length";
	if(filterType == 6) key = @"price";
	if(filterType == 7) key = @"boxprice";
	
	NSSortDescriptor *descriptor = [[[NSSortDescriptor alloc] initWithKey:key ascending:YES] autorelease];
	allCigarsArray = [allCigarsArray sortedArrayUsingDescriptors:[NSArray arrayWithObject:descriptor]];
	for(Cigar *cigar in allCigarsArray){
		NSString *firstLetter = [[cigar valueForKey:key] substringToIndex:1];
		if(filterType == 1 ||filterType == 2|| filterType == 3 || filterType == 4 || filterType == 6 || filterType == 7) firstLetter = [cigar valueForKey:key];
		if(filterType == 6 || filterType == 7) firstLetter = [firstLetter stringByReplacingOccurrencesOfString:@" (Online)" withString:@""];
		if(filterType == 6 || filterType == 7) firstLetter = [firstLetter stringByReplacingOccurrencesOfString:@"$" withString:@""];
		
		NSMutableArray *existingArray;
		//NSLog(firstLetter);
		// if an array already exists in the name index dictionary
		// simply add the element to it, otherwise create an array
		// and add it to the name index dictionary with the letter as the key
		if (existingArray = [indexes valueForKey:firstLetter]) 
		{
			[existingArray addObject:cigar];
		} else {
			NSMutableArray *tempArray = [NSMutableArray array];
			[indexes setObject:tempArray forKey:firstLetter];
			[tempArray addObject:cigar];
		}
	}
	[indexes removeObjectForKey:@"Not Available"];
	keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
	if(filterType == 6){
		[keys release];
		//keys = [[[indexes allKeys] sortedArrayUsingFunction:floatSort context:NULL] retain];
	}
	return [indexes count];
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
	// returns the array of section titles. There is one entry for each unique character that an element begins with
	// [A,B,C,D,E,F,G,H,I,K,L,M,N,O,P,R,S,T,U,V,X,Y,Z]
	return keys;
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index {
	return index;
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
	NSArray *allKeys = keys;
	NSString *rightKey = [allKeys objectAtIndex:section];
	NSMutableArray *arrayForThisSection = [indexes objectForKey:rightKey];
	return [arrayForThisSection count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainCell"];
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"MainCell"] autorelease];
	}
	
	cell.textLabel.textColor = [UIColor whiteColor];
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	NSArray *allKeys = keys;
	NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
	NSMutableArray *arrayForThisSection = [indexes objectForKey:rightKey];
	cell.textLabel.text = [[arrayForThisSection objectAtIndex:indexPath.row] valueForKey:@"type"];
    cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:16];
	cell.detailTextLabel.text = [[arrayForThisSection objectAtIndex:indexPath.row] valueForKey:@"brand"];
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	//cell.textLabel.text = [[[[keys objectAtIndex:indexPath.row] stringByReplacingOccurrencesOfString:@"_" withString:@" "] stringByReplacingOccurrencesOfString:@"{" withString:@""] stringByReplacingOccurrencesOfString:@"}" withString:@""];;
	
	return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {	
	if(filterType == 6)
		return [@"$" stringByAppendingString:[keys objectAtIndex:section]];
	else 
		return [keys objectAtIndex:section];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	CigarViewController *c = [[CigarViewController alloc] initWithNibName:@"CigarViewController" bundle:nil];
	NSArray *allKeys = keys;
	NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
	NSMutableArray *arrayForThisSection = [indexes objectForKey:rightKey];
	c.cigar = [arrayForThisSection objectAtIndex:indexPath.row];
    self.navigationItem.title=@"Back";
	[self.navigationController pushViewController:c animated:YES];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 420)];
	bgView.image = [UIImage imageNamed:@"Background640x734.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
	
	[indexes release];
}


@end
