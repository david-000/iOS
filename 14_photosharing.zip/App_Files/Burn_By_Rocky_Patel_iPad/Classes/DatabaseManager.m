//
//  DatabaseManager.m
//  GolfScoreBook
//
//  Created by System Administrator on 5/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CigarDatabaseData.h"
#import "DatabaseManager.h"
#import "Base64.h"

@implementation DatabaseManager

- (BOOL) initConnect {

	BOOL result = [self connect];
	
	if (!result) {
		return result;
	}
	
	pthread_mutex_init(&mMutex, NULL);
	
	return result;
}

- (void) dealloc {

	[super dealloc];
	
	pthread_mutex_destroy(&mMutex);
}

- (BOOL) connect {
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0];

	NSString* databasePath = [documentsPath stringByAppendingPathComponent:@"brand.sqlite"];
	
	int result = sqlite3_open([databasePath UTF8String], &mDatabase);
	
	if ( result != SQLITE_OK ) {
		sqlite3_close(mDatabase);
		return NO;
	}
	
	return YES;
}


- (BOOL) createDBAndTables {

	char* errorMsg;
		
	NSString* strQuoteQuery = [NSString stringWithFormat:@"Create table if not exists %@ ( %@ integer unique, %@ BLOB )",
                               @"tbl_brand",
                               @"brand_id",
                               @"brand_data"];
	
	if (sqlite3_exec(mDatabase, [strQuoteQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
	{
		sqlite3_close(mDatabase);
		return NO;
	}
    
    NSString *strEventQuery = [NSString stringWithFormat:@"Create table if not exists %@( %@ integer unique, %@ VARCHAR(255), %@ VARCHAR(255), %@ VARCHAR(255), %@ VARCHAR(255), %@ VARCHAR(255) )",
                               @"tbl_event",
                               @"event_id",
                               @"event_title",
                               @"event_date",
                               @"event_from",
                               @"event_to",
                               @"event_desc"];
    
	if (sqlite3_exec(mDatabase, [strEventQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
	{
		sqlite3_close(mDatabase);
		return NO;
	}
    
    NSString *strNotifyQuery = [NSString stringWithFormat:@"Create table if not exists %@( %@ integer, %@ VARCHAR(255), %@ VARCHAR(255) )",
                               @"tbl_notify",
                               @"notify_id",
                               @"notify_msg",
                               @"notify_date"];
    
	if (sqlite3_exec(mDatabase, [strNotifyQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
	{
		sqlite3_close(mDatabase);
		return NO;
	}

	
	return YES;
}

- (BOOL) isExistingBrand:(NSInteger)brandId {
    	
	const char* sqlStatement = [[NSString stringWithFormat:@"select * from %@ where %@ = %d",
								 @"tbl_brand",
                                 @"brand_id",
                                 brandId
								 ] UTF8String];
    
	sqlite3_stmt *stmt;
	
	[self dbconn_lock];
	
	if(sqlite3_prepare_v2(mDatabase, sqlStatement, -1, &stmt, NULL) == SQLITE_OK)
	{
		while(sqlite3_step(stmt) == SQLITE_ROW)
		{
            sqlite3_finalize(stmt);
            [self dbconn_unlock];
            
			return YES;
		}
	}
	
	// Release the compiled statement from memory
	sqlite3_finalize(stmt);
	[self dbconn_unlock];
	
	return FALSE;
    
    
}

- (BOOL) isExistingEvent:(NSInteger)eventId {
    
	const char* sqlStatement = [[NSString stringWithFormat:@"select * from %@ where %@ = %d",
								 @"tbl_event",
                                 @"event_id",
                                 eventId
								 ] UTF8String];
    
	sqlite3_stmt *stmt;
	
	[self dbconn_lock];
	
	if(sqlite3_prepare_v2(mDatabase, sqlStatement, -1, &stmt, NULL) == SQLITE_OK)
	{
		while(sqlite3_step(stmt) == SQLITE_ROW)
		{
            sqlite3_finalize(stmt);
            [self dbconn_unlock];
            
			return YES;
		}
	}
	
	// Release the compiled statement from memory
	sqlite3_finalize(stmt);
	[self dbconn_unlock];
	
	return FALSE;
}


- (BOOL) isExistingNotify:(NSInteger)notifyId {
    
	const char* sqlStatement = [[NSString stringWithFormat:@"select * from %@ where %@ = %d",
								 @"tbl_notify",
                                 @"notify_id",
                                 notifyId
								 ] UTF8String];
    
	sqlite3_stmt *stmt;
	
	[self dbconn_lock];
	
	if(sqlite3_prepare_v2(mDatabase, sqlStatement, -1, &stmt, NULL) == SQLITE_OK)
	{
		while(sqlite3_step(stmt) == SQLITE_ROW)
		{
            sqlite3_finalize(stmt);
            [self dbconn_unlock];
            
			return YES;
		}
	}
	
	// Release the compiled statement from memory
	sqlite3_finalize(stmt);
	[self dbconn_unlock];
	
	return NO;
}

- (BOOL) insertNotify : (NSInteger) notify_id : (NotifyData *) notify {
	
	NSString *strQuery = @"";
	char* errorMsg;
    
	strQuery = [NSString stringWithFormat:@"insert into %@ ( %@, %@, %@ ) values ( %d, '%@', '%@' )",
                @"tbl_notify",
				@"notify_id",
				@"notify_msg",
                @"notify_date",
                notify.mNotifyId,
                [Base64 encode:[notify.mNotifyMsg dataUsingEncoding:NSUTF8StringEncoding]],
                notify.mNotifyDateStr];
    
	[self dbconn_lock];
	
	if (sqlite3_exec(mDatabase, [strQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
	{
		sqlite3_close(mDatabase);
        [self dbconn_unlock];
		return NO;
	}
    
	[self dbconn_unlock];
	
	return YES;
}

- (BOOL) insertEvent : (NSInteger) event_id : (EventData *) event {
	
	NSString *strQuery = @"";
	char* errorMsg;
    
	strQuery = [NSString stringWithFormat:@"insert into %@ ( %@, %@, %@, %@, %@, %@ ) values ( %d, '%@', '%@', '%@', '%@', '%@' )",
                @"tbl_event",
				@"event_id",
				@"event_title",
                @"event_date",
                @"event_from",
                @"event_to",
                @"event_desc",
                event.mEventId,
                [Base64 encode:[event.mTitle dataUsingEncoding:NSUTF8StringEncoding]],
                event.mDate,
                event.mFrom,
                event.mTo,
                [Base64 encode:[event.mDescription dataUsingEncoding:NSUTF8StringEncoding]]];
    
	[self dbconn_lock];
	
	if (sqlite3_exec(mDatabase, [strQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
	{
		sqlite3_close(mDatabase);
        [self dbconn_unlock];
		return NO;
	}
    
	[self dbconn_unlock];
	
	return YES;
}

- (BOOL) deleteEvent : (NSInteger) event_id
{
    char *errorMsg;
    NSString *strQuery = @"";
    
    strQuery = [NSString stringWithFormat:@"delete from tbl_event where event_id = %d",
                event_id];
    
    
    [self dbconn_lock];
	
	if (sqlite3_exec(mDatabase, [strQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
	{
		[self dbconn_unlock];
		return NO;
	}
	
	[self dbconn_unlock];
	
	return YES;
}

- (BOOL) deleteNotify : (NSInteger) notify_id
{
    char *errorMsg;
    NSString *strQuery = @"";
    
    strQuery = [NSString stringWithFormat:@"delete from tbl_notify where notify_id = %d",
                notify_id];
    
    
    [self dbconn_lock];
	
	if (sqlite3_exec(mDatabase, [strQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
	{
		[self dbconn_unlock];
		return NO;
	}
	
	[self dbconn_unlock];
	
	return YES;
}

- (BOOL) updateEvent:(NSInteger)event_id : (EventData *) event {
    [self deleteEvent:event_id];
    [self insertEvent:event_id :event];
    return YES;
}

- (BOOL) updateNotify:(NSInteger)notify_id : (NotifyData *) notify {
    [self deleteNotify:notify_id];
    [self insertNotify:notify_id :notify];
    return YES;
}


- (BOOL) insertBrand : (NSInteger) brand_id : (NSString *) brand {
	
	NSString *strQuery = @"";
    
    NSData *brandData = [brand dataUsingEncoding:NSUTF8StringEncoding];
	
	strQuery = [NSString stringWithFormat:@"insert into %@ ( %@, %@ ) values ( %d, ? )",
                @"tbl_brand",
				@"brand_id",
				@"brand_data",
                brand_id,
                brandData];
	
	sqlite3_stmt *stmt;
	
	[self dbconn_lock];
	
	if(sqlite3_prepare_v2(mDatabase, [strQuery UTF8String], -1, &stmt, NULL) == SQLITE_OK)
	{
		sqlite3_bind_blob(stmt, 1, [brandData bytes], [brandData length], SQLITE_TRANSIENT);
	}else{
		
	}
	
	if (sqlite3_step(stmt) != SQLITE_DONE){
		sqlite3_finalize(stmt);
		[self dbconn_unlock];
		return NO;
	}
	
	sqlite3_finalize(stmt);
	[self dbconn_unlock];
	
	return YES;
}

- (BOOL) deleteNotifys
{
    char *errorMsg;
    NSString *strQuery = @"";
    
    strQuery = @"delete from tbl_notify";
    
    
    [self dbconn_lock];
	
	if (sqlite3_exec(mDatabase, [strQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
	{
		[self dbconn_unlock];
		return NO;
	}
	
	[self dbconn_unlock];
	
	return YES;
    
}

- (BOOL) deleteBrand : (NSInteger) brand_id
{
    char *errorMsg;
    NSString *strQuery = @"";
    
    strQuery = [NSString stringWithFormat:@"delete from tbl_brand where brand_id = %d",
                brand_id];
    
    
    [self dbconn_lock];
	
	if (sqlite3_exec(mDatabase, [strQuery UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
	{
		[self dbconn_unlock];
		return NO;
	}	
	
	[self dbconn_unlock];
	
	return YES;

}

- (BOOL) updateBrand:(NSInteger)brand_id :(NSString *)brand {
    [self deleteBrand:brand_id];
    [self insertBrand:brand_id :brand];
    return YES;
}

- (NSMutableArray *) getNotificationList {
    
    NSMutableArray  *notifyList = [[NSMutableArray alloc] init];
    
    const char* sqlStatement = [[NSString stringWithFormat:@"select * from %@ order by notify_date desc",
								 @"tbl_notify"
								 ] UTF8String];
    
	sqlite3_stmt *stmt;
	
	[self dbconn_lock];
	
	if(sqlite3_prepare_v2(mDatabase, sqlStatement, -1, &stmt, NULL) == SQLITE_OK)
	{
		while(sqlite3_step(stmt) == SQLITE_ROW)
		{

            NotifyData *notifyData = [[NotifyData alloc] init];
            
			int notifyId = sqlite3_column_int(stmt, 0);
            char *notifyMsg = (char *) sqlite3_column_text(stmt, 1);
            char *notifyDate = (char *) sqlite3_column_text(stmt, 2);
            
            notifyData.mNotifyId = notifyId;
            
            if ( notifyMsg == NULL )
                notifyData.mNotifyMsg = @"";
            else
                notifyData.mNotifyMsg = [[NSString alloc] initWithData:[Base64 decode:[NSString stringWithUTF8String:notifyMsg]] encoding:NSUTF8StringEncoding];
            
            if ( notifyDate == NULL )
                notifyData.mNotifyDateStr = @"";
            else
                notifyData.mNotifyDateStr = [NSString stringWithUTF8String:notifyDate];
            
            [notifyList addObject:notifyData];
            
            [notifyData release];
		}
	}
	
	// Release the compiled statement from memory
	sqlite3_finalize(stmt);
	[self dbconn_unlock];
	
	return notifyList;

}

- (NSMutableArray *) getBrandList {

    NSMutableArray  *brandList = [[NSMutableArray alloc] init];
	
	const char* sqlStatement = [[NSString stringWithFormat:@"select * from %@",
								 @"tbl_brand"
								 ] UTF8String];
    
	sqlite3_stmt *stmt;
	
	[self dbconn_lock];
	
	if(sqlite3_prepare_v2(mDatabase, sqlStatement, -1, &stmt, NULL) == SQLITE_OK)
	{
		while(sqlite3_step(stmt) == SQLITE_ROW)
		{
			
			NSInteger brandId = sqlite3_column_int(stmt, 0);
            NSData *data = [[NSData alloc] initWithBytes:sqlite3_column_blob(stmt, 1) length:sqlite3_column_bytes(stmt, 1)];
            
            CigarDatabaseData *cigarData = [[CigarDatabaseData alloc] init];
            cigarData.mBrandId = brandId;
            cigarData.mBrandData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];

            [brandList addObject:cigarData];
            
            [data release];
            [cigarData release];
		}
	}
	
	// Release the compiled statement from memory
	sqlite3_finalize(stmt);
	[self dbconn_unlock];
	
	return brandList;
}


/*

- (NSDate *) getDate:(NSString *)dateString {

	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"HH:mm dd/MM/yyyy"];	
	
	NSDate *defaultDate = [dateFormatter dateFromString:dateString];
	[dateFormatter release];
	
	return defaultDate;
}
 
 */

#pragma mark -
#pragma mark Memory management

-(void)disConnect {
	sqlite3_close(mDatabase);	
}

-(void)dbconn_lock {
	pthread_mutex_lock(&mMutex);
}

-(void)dbconn_unlock {
	pthread_mutex_unlock(&mMutex);
}

@end
