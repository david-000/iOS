//
//  FilteredViewControllerNew.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FilteredViewController.h"


@interface FilteredViewControllerNew : UIViewController {
	int type;
	BOOL gotThis;
	
	id appDelegate;
	NSMutableArray *allCigarsArray;
	NSMutableDictionary *indexes;
	NSArray *keys;
	
	IBOutlet UITableView *mainTableView;
}


@property (nonatomic, assign) int type;
@property (nonatomic, assign) NSMutableArray *allCigarsArray;
@end
