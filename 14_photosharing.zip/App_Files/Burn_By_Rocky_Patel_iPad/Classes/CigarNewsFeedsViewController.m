//
//  CigarNewsFeedsViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CigarNewsFeedsViewController.h"
#import "CustomHighlightedCell.h"
#import "WebViewController.h"
#import "RootViewController.h"
#import "CigarBossAppDelegate.h"


@implementation CigarNewsFeedsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        feedsArray = [[NSMutableArray alloc] init];
        [feedsArray addObject:@"http://www.stogieguys.com/feed/"];
        [feedsArray addObject:@"http://www.tomscigars.com/feed/"];
    }
    return self;
}

-(void)viewDidAppear:(BOOL)animated
{
    if(AppDelegate.adStatus)
    {
        [mainTableView setFrame:CGRectMake(0, 0, 320, 315)];
    }
    else
    {
        [mainTableView setFrame:CGRectMake(0, 0, 320, 370)];        
    }
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.title = @"Cigar News";
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 190, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =@"News Cigar"; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];
	mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 367)];
	bgView.image = [UIImage imageNamed:@"Background640x734.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
}

- (int)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
	return [feedsArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BrandCell"];
	
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"BrandCell"] autorelease];
	}
	
	cell.textLabel.textColor = [UIColor whiteColor];
    cell.textLabel.text = [feedsArray objectAtIndex:indexPath.row];
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    RootViewController *feedViewController = [[RootViewController alloc] initWithNibName:@"RootViewController" bundle:nil];
    feedViewController.feeds = [NSArray arrayWithObject:[feedsArray objectAtIndex:indexPath.row]];
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:feedViewController animated:YES];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void)dealloc
{
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
