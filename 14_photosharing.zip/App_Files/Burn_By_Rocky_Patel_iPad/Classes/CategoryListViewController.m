//
//  CategoryListViewController.m
//  CigarBoss_PRO
//
//  Created by System Administrator on 5/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "CategoryListViewController.h"
#import "DetailViewController.h"
#import "CigarBossAppDelegate.h"
#import "HomeViewController.h"
#import "CigarViewController.h"
#import "BrandsViewController.h"
#import "ChangeNewCigarViewController.h"
#import "FilterSearchViewController.h"
#import "RootViewController.h"
#import "TopTenView.h"
#import "LastViewController.h"
#import "communityViewController.h"
#import "TSMiniWebBrowser.h"
#import "MyHumidorsViewController.h"
#import "MyNotesViewController.h"
#import "MapViewController.h"
#import "MyWishList.h"
#import "FavoritesViewController.h"
#import "WebViewController.h"
#import "SettingsViewController.h"
#import "Kal.h"
#import "SharedData.h"
#import "HolidaySqliteDataSource.h"
#import "NewFeatureViewController.h"
#import "CigarsViewController.h"
#import "NotificationListViewController.h"

@implementation CategoryListViewController
@synthesize mPopOverVc, mSplitVc, mRootPopOverButton;
@synthesize mSelectedIndexPath;
@synthesize mSelectedEventIndexPath;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    
    self.contentSizeForViewInPopover = CGSizeMake(310.0, 800.0);
    mTabBar.delegate = self;
    
    mSelectedIndexPath = [[NSIndexPath alloc] init];
    mSelectedEventIndexPath = [[NSIndexPath alloc] init];
//    [mTabBar setSelectedItem:mHomeTabBarItem];
    
    // Do any additional setup after loading the view from its nib.
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return 19;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ( tableView.tag == 3000 ) {
        
        EventData *event =  [(HolidaySqliteDataSource *)mKalViewController.dataSource holidayAtIndexPath:indexPath];
        
        
        CGSize labelSize = [event.mDescription sizeWithFont:[UIFont systemFontOfSize:16] constrainedToSize:CGSizeMake(650, MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
    
        return 118 + labelSize.height + 25;
    }
    
    return tableView.rowHeight;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CategoryCell"];
	if(cell == nil){
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CategoryCell"] autorelease];
        
        if ( indexPath.row == 0 ) {
            [tableView selectRowAtIndexPath:indexPath animated:YES scrollPosition:UITableViewScrollPositionMiddle];
        }
	}
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.textLabel.textColor = [UIColor whiteColor];
    cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:18];
    
	
	int row = indexPath.row;
	switch(row)
	{
		case 0:
			cell.textLabel.text = @"CIGAR BRANDS";
            cell.imageView.image = [UIImage imageNamed:@"CigarListIcon75x75.png"];
			break;
		case 1:
			cell.textLabel.text = @"NEW CIGARS";
            cell.imageView.image = [UIImage imageNamed:@"NewCigars_iPad.png"];
			break;
        case 2:
            cell.textLabel.text = @"EVENTS";
            cell.imageView.image = [UIImage imageNamed:@"events.png"];
            break;
		case 3:
            cell.textLabel.text = @"FEATURED CIGARS";
            cell.imageView.image = [UIImage imageNamed:@"CigarOfMonth75x75.png"];
			break;
        case 4:
            cell.textLabel.text = @"TOP TEN";
            cell.imageView.image = [UIImage imageNamed:@"TopTen75x75.png"];
            break;
        case 5:
            cell.textLabel.text = @"STAFF FAVORITES";
            cell.imageView.image = [UIImage imageNamed:@"staff_picks.png"];
            break;
		case 6:
            cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:20];
            cell.textLabel.text = @"CIGAR FINDER";
            cell.imageView.image = [UIImage imageNamed:@"FilterIcon_iPad.png"];
			break;
        case 7:
            cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:20];
            cell.textLabel.text = @"SPECIALS";
            cell.imageView.image = [UIImage imageNamed:@"specials.png"];
            break;
        case 8:
            cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:20];
            cell.textLabel.text = @"Notifications";
            cell.imageView.image = [UIImage imageNamed:@"notification.png"];
            break;
		case 9:
            cell.textLabel.text = @"CIGAR NEWS";
            cell.imageView.image = [UIImage imageNamed:@"CigarNews_iPad.png"];
			break;
        case 10:
            cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:20];
            cell.textLabel.text = @"MY HUMIDOR";
            cell.imageView.image = [UIImage imageNamed:@"HumidorIcon75x75.png"];
            break;
        case 11:
            cell.textLabel.text = @"MY WISH LIST";
            cell.imageView.image = [UIImage imageNamed:@"WishListtIcon.png"];
            break;
        case 12:
            cell.textLabel.text = @"MY CIGAR NOTES";
            cell.imageView.image = [UIImage imageNamed:@"NotePad75x75.png"];
            break;
        case 13:
            cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:20];
            cell.textLabel.text = @"My Favorites";
            cell.imageView.image = [UIImage imageNamed:@"Favorite75x75.png"];
            break;
		case 14:
            cell.textLabel.text = @"CIGAR WIKI";
            cell.imageView.image = [UIImage imageNamed:@"CigarWiki75x75.png"];
			break;
        case 15:
            cell.textLabel.text = @"WEBSITE";
            cell.imageView.image = [UIImage imageNamed:@"website_icon.png"];
            break;
        case 16:
            cell.textLabel.text = @"FACEBOOK";
            cell.imageView.image = [UIImage imageNamed:@"facebook.png"];
            break;
        case 17:
            cell.textLabel.text = @"TWITTER";
            cell.imageView.image = [UIImage imageNamed:@"twitter.png"];
            break;
        case 18:
			cell.textLabel.text = @"ABOUT CIGAR BOSS";
            cell.imageView.image = [UIImage imageNamed:@"about_cigar_boss.png"];
            break;
        case 19:
            cell.textLabel.text = @"CONTACT";
            cell.imageView.image = [UIImage imageNamed:@"Contact75x75.png"];
            break;
        default:
            break;
            
	}
    
    cell.selectionStyle = UITableViewCellSelectionStyleGray;
	cell.accessoryType = UITableViewCellAccessoryNone;
	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ( tableView.tag == 3000 ) {
        
        self.mSelectedEventIndexPath = indexPath;
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"CigarBoss" message:@"Do you want to add this event to iCal?" delegate:self cancelButtonTitle:@"YES" otherButtonTitles:@"NO", nil];
        alertView.tag = 5000;
        [alertView show];
        [alertView release];

    } else {
        self.mSelectedIndexPath = indexPath;
        [self showDetailView:indexPath.row];
    }

}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if ( alertView.tag == 5000 ) {
        
        if ( buttonIndex == 0 ) {
            
            EventData *event =  [(HolidaySqliteDataSource *)mKalViewController.dataSource holidayAtIndexPath:self.mSelectedEventIndexPath];
            
            [self createEvent:event.mTitle at:@"" starting:event.mStartDate ending:event.mEndDate withBody:event.mDescription andUrl:nil];
            
        }
        
    }
}

- (void)showDetailView:(NSInteger) selectedIndex {
    
    UIViewController *detailViewController = nil;
    
    switch (selectedIndex) {
        case 0: {
            
            BrandsViewController *brandsView = [[BrandsViewController alloc] initWithNibName:@"BrandsViewController" bundle:nil];
            brandsView.mShowType = 1;
            detailViewController = brandsView;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:brandsView];
            mNavigationBar.topItem.title = @"BRANDS";
            [mTabBar setSelectedItem:mBrandsTabBarItem];
            mSelectedTabbarIndex = 1;
            self.mSelectedIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
            
            [mCaqtegoryTableView selectRowAtIndexPath:self.mSelectedIndexPath animated:YES scrollPosition:UITableViewScrollPositionMiddle];
            
            if ( AppDelegate.isCigarLoading == YES )
                [AppDelegate showLoadingView:brandsView.view];

            [AppDelegate showAdView];
        }
            
            break;
        case 1: {
            
            ChangeNewCigarViewController *cView = [[ChangeNewCigarViewController alloc] initWithNibName:@"ChangeNewCigarViewController" bundle:nil];
            cView.cigars = [(CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate] newCigars];
            NSSortDescriptor *sortDesc = [NSSortDescriptor sortDescriptorWithKey:@"brand" ascending:YES];
            cView.cigars = [[cView.cigars sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDesc]] retain];
            cView.forNewCigars = YES;
            if([cView.cigars count] < 1){
                [cView release];
                UIAlertView *eView = [[UIAlertView alloc] initWithTitle:@"No New Cigars!" message:@"There are no new cigars to view! Check back later!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [eView show];
                [eView release];
                return;
            }
            
            mNavigationBar.topItem.title = @"NEW CIGARS";
            cView.title = @"NEW CIGARS";
            self.navigationItem.title=@"Back";
            detailViewController = cView;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:cView];
            
            [AppDelegate showAdView];
        }
            
            break;
            
        case 2: {
            
            mKalViewController = [[KalViewController alloc] initWithSelectedDate:[NSDate date]];

            mKalViewController.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Today" style:UIBarButtonItemStyleBordered target:self action:@selector(showAndSelectToday)] autorelease];
            mKalViewController.delegate = self;
            id dataSource = [[HolidaySqliteDataSource alloc] init];
            mKalViewController.dataSource = dataSource;
            
            // Setup the navigation stack and display it.
            
            detailViewController = mKalViewController;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:mKalViewController];
            mNavigationBar.topItem.title = @"EVENTS";

            CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
            
            if ( appDelegate.pushReceived == YES )
                appDelegate.pushReceived = NO;
            
            [appDelegate hideAdView];
            /*
            
            
            if ( appDelegate.pushReceived == YES ) {
                EventData *event =  [(HolidaySqliteDataSource *)mKalViewController.dataSource holidayAtEventId:appDelegate.mEventId];
                [mKalViewController showAndSelectDate:event.mNSDate];
                appDelegate.pushReceived;
            }
             */

        }
            
            break;
        case 3: {
            
            NewFeatureViewController *c = [[NewFeatureViewController alloc] initWithNibName:@"NewFeatureViewController" bundle:nil];
            
            SharedData *sharedData = [SharedData sharedData];
            
            c.showType = 3;
            c.cigars = [sharedData getFeaturedCigarArray];
            mNavigationBar.topItem.title = @"FEATURED CIGARS";
            c.title = @"FEATURED CIGARS";
            self.navigationItem.title=@"Back";
            detailViewController = c;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:c];
            
            [AppDelegate showAdView];
            
        }
            break;
            
        case 4: {
            
            TopTenView *t = [[TopTenView alloc] initWithNibName:@"TopTenView" bundle:nil];
            detailViewController = t;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:t];
            mNavigationBar.topItem.title = @"Top 10";
            
            [AppDelegate showAdView];
        }
            break;
            
        case 5: {
            
            NewFeatureViewController *c = [[NewFeatureViewController alloc] initWithNibName:@"NewFeatureViewController" bundle:nil];
            
            SharedData *sharedData = [SharedData sharedData];
            
            c.showType = 0;
            c.cigars = [sharedData getStaffFavoriteArray];
            mNavigationBar.topItem.title = @"STAFF FAVORITES";
            c.title = @"STAFF FAVORITES";
            self.navigationItem.title=@"Back";
            detailViewController = c;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:c];
            
            [AppDelegate showAdView];
        }
            break;
            
        case 7: {
            
            NewFeatureViewController *c = [[NewFeatureViewController alloc] initWithNibName:@"NewFeatureViewController" bundle:nil];
            
            SharedData *sharedData = [SharedData sharedData];
            
            c.showType = 1;
            c.cigars = [sharedData getSpecialArray];
            mNavigationBar.topItem.title = @"SPECIALS";
            c.title = @"SPECIALS";
            self.navigationItem.title=@"Back";
            detailViewController = c;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:c];
            
            [AppDelegate showAdView];
        }
            break;
            
        case 8: {
            
            NotificationListViewController *c = [[NotificationListViewController alloc] initWithNibName:@"NotificationListViewController" bundle:nil];
            
            mNavigationBar.topItem.title = @"Notifications";
            c.title = @"Notifications";
            self.navigationItem.title=@"Back";
            detailViewController = c;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:c];
            
            [AppDelegate showAdView];

        }
            break;
            
        case 6: {
            
            FilterSearchViewController *filtersView = [[FilterSearchViewController alloc] initWithNibName:@"FilterSearchViewController" bundle:nil];
            detailViewController = filtersView;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:filtersView];
            mNavigationBar.topItem.title = @"CIGAR FINDER";
            [mTabBar setSelectedItem:mFilterTabBarItem];
            mSelectedTabbarIndex = 2;
            
            [AppDelegate hideAdView];
        }

            break;

        case 9: {
            
            RootViewController *c = [[RootViewController alloc] initWithNibName:@"RootViewController" bundle:nil];
            detailViewController = c;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:c];
            mNavigationBar.topItem.title = @"CIGAR NEWS";
            
            [AppDelegate showAdView];
        }
            
            break;

            
        case 10: {
            MyHumidorsViewController *humidorView = [[MyHumidorsViewController alloc] initWithNibName:@"MyHumidorsViewController" bundle:nil];
            detailViewController = humidorView;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:humidorView];
            mNavigationBar.topItem.title = @"MY HUMIDOR";
            [mTabBar setSelectedItem:mHumidorTabBarItem];
            mSelectedTabbarIndex = 3;
            
            [AppDelegate showAdView];
        }
            
            break;
            
        case 11: {
            
            MyWishList *mywishlist = [[MyWishList alloc] initWithNibName:@"MyWishList" bundle:nil];
            self.title = @"Back";
            detailViewController = mywishlist;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:mywishlist];
            mNavigationBar.topItem.title = @"MY WISH LIST";
			[mTabBar setSelectedItem:mLocalShopTabBarItem];
            mSelectedTabbarIndex = 4;
            [AppDelegate showAdView];
        }
            
            break;
            
        case 12: {
            
            MyNotesViewController *myNotes = [[MyNotesViewController alloc] initWithNibName:@"MyNotesViewController" bundle:nil];
            detailViewController = myNotes;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:myNotes];
            mNavigationBar.topItem.title = @"MY NOTES";
            
            [AppDelegate showAdView];
        }
            
            break;
            
        case 13: {
            
            FavoritesViewController *favlist = [[FavoritesViewController alloc] initWithNibName:@"FavoritesViewController" bundle:nil];
            detailViewController = favlist;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:favlist];
            mNavigationBar.topItem.title = @"MY FAVORITES";
            
            [AppDelegate showAdView];
        }
            break;
            
        case 14: {
            
            WebViewController *webViewController = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
            webViewController.url = [NSURL URLWithString:@"http://en.wikipedia.org/wiki/Cigar"];
            webViewController.navigationController.navigationItem.title = @"CIGAR WIKI";
            [self presentModalViewController:webViewController animated:YES];
            [webViewController release];
            
            return;
        }
            break;
         
        case 15: {
            
            WebViewController *webViewController = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
            webViewController.url = [NSURL URLWithString:@"http://www.burnbyrockypatel.com"];
            webViewController.navigationController.navigationItem.title = @"WEBSITE";
            [self presentModalViewController:webViewController animated:YES];
            [webViewController release];
            
        }
            
            break;
            
        case 16: {
            
            WebViewController *webViewController = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
            webViewController.url = [NSURL URLWithString:@"https://www.facebook.com/burnbyrockypatel"];
            webViewController.navigationController.navigationItem.title = @"FACEBOOK";
            [self presentModalViewController:webViewController animated:YES];
            [webViewController release];
            
            return;
            
        }
            break;
            
        case 17: {
            
            WebViewController *webViewController = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
            webViewController.url = [NSURL URLWithString:@"https://twitter.com/BURNbyRP"];
            webViewController.navigationController.navigationItem.title = @"TWITTER";
            [self presentModalViewController:webViewController animated:YES];
            [webViewController release];
            
            return;
        }
            break;
            
        case 18: {
            
            NSString *urlAddress = @"http://cigarboss.blogspot.com/";
            NSURL *url = [NSURL URLWithString:urlAddress];
            WebViewController *w = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
            w.url = url;
            [self presentModalViewController:w animated:YES];
            return;

        }
            break;
            
        case 19: {
            if ([MFMailComposeViewController canSendMail]) {
                
                MFMailComposeViewController *mailViewController = [[MFMailComposeViewController alloc] init];
                mailViewController.mailComposeDelegate = self;
                [mailViewController setToRecipients:[NSArray arrayWithObject:@"blake@burnbyrockypatel.com"]];
                
                
                [self presentModalViewController:mailViewController animated:YES];
                [mailViewController release];
                
            }
            
            break;
        }
            
        default:
            break;
    }

    
    NSArray *viewControllers = [[NSArray alloc] initWithObjects:self.navigationController, AppDelegate.mNavigationController, nil];
    AppDelegate.mSplitViewController.viewControllers = viewControllers;
    
    [viewControllers release];
    
    // Dismiss the popover if it's present.
    if (mPopOverVc != nil) {
        [mPopOverVc dismissPopoverAnimated:YES];
    }
    
    if (mRootPopOverButton != nil) {
//        [detailViewController showRootPopoverButtonItem:self.mRootPopOverButton];
    }
    
    [detailViewController release];    
}

- (void)showAndSelectToday
{
    KalViewController *kalVc = (KalViewController *) AppDelegate.mNavigationController.topViewController;
    [kalVc showAndSelectDate:[NSDate date]];
//    [kal showAndSelectDate:[NSDate date]];
}

- (BOOL)createEvent:(NSString *)title
                 at:(NSString *)location
           starting:(NSDate *)startDate
             ending:(NSDate *)endDate
           withBody:(NSString *)body
             andUrl:(NSURL *)url
{
    
    EKEventStore *eventStore = [[EKEventStore alloc] init];
    
    [eventStore requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{

            EKEvent *event  = [EKEvent eventWithEventStore:eventStore];
            event.title     = title;
            event.location  = location;
            event.startDate = startDate;
            event.endDate   = endDate;
            event.notes     = body;
            if (url)
                event.URL   = url;
            
            [event setCalendar:[eventStore defaultCalendarForNewEvents]];
            
            EKEventEditViewController *eventViewController = [[EKEventEditViewController alloc] init];
            eventViewController.event = event;
            eventViewController.eventStore = eventStore;
            eventViewController.editViewDelegate = self;
            
            [self presentModalViewController:eventViewController animated:YES];
            
        });
        

    }];
    
    return TRUE;
}

#pragma mark - MFMailViewController Delegate Function\

-(void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error :(NSError*)error {
    
    [self dismissModalViewControllerAnimated:YES];
    
}

#pragma mark -
#pragma mark Rotation support

- (BOOL)splitViewController: (UISplitViewController*)svc shouldHideViewController:(UIViewController *)vc inOrientation:(UIInterfaceOrientation)orientation {
    return NO;
}

- (void)splitViewController:(UISplitViewController*)svc willHideViewController:(UIViewController *)aViewController withBarButtonItem:(UIBarButtonItem*)barButtonItem forPopoverController:(UIPopoverController*)pc {
    
    /*
    // Keep references to the popover controller and the popover button, and tell the detail view controller to show the button.
    barButtonItem.title = @"MPSPlayer";
    
    self.mPopOverVc = pc;
    self.mRootPopOverButton = barButtonItem;
    
    NSInteger index = [[[mSplitVc.viewControllers objectAtIndex:1] viewControllers] count];
    
    if ( index == 0 )
        return;
    
    UIViewController <SubstitutableDetailViewController> *detailViewController = [[[mSplitVc.viewControllers objectAtIndex:1] viewControllers] objectAtIndex:index - 1];
    
    [detailViewController showRootPopoverButtonItem:mRootPopOverButton];
     */
}


- (void)splitViewController:(UISplitViewController*)svc willShowViewController:(UIViewController *)aViewController invalidatingBarButtonItem:(UIBarButtonItem *)barButtonItem {
    
    // Nil out references to the popover controller and the popover button, and tell the detail view controller to hide the button.
    /*
    NSInteger index = [[[mSplitVc.viewControllers objectAtIndex:1] viewControllers] count];
    
    if ( index == 0 )
        return;
    
    UIViewController <SubstitutableDetailViewController> *detailViewController = [[[mSplitVc.viewControllers objectAtIndex:1] viewControllers] objectAtIndex:index - 1];
    
    [detailViewController invalidateRootPopoverButtonItem:mRootPopOverButton];
    
    self.mPopOverVc = nil;
    self.mRootPopOverButton = nil;
     */
}

#pragma mark UITabBar Delegate

- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item {
    
    NSInteger index = item.tag;
    
    if ( mSelectedTabbarIndex == index )
        return;
    
    mSelectedTabbarIndex = index;
    
//    UIViewController <SubstitutableDetailViewController> *detailViewController = nil;

    switch (index) {
        case 1: {
            
            /*
            BrandsViewController *brandsView = [[BrandsViewController alloc] initWithNibName:@"BrandsViewController" bundle:nil];
            detailViewController = brandsView;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:brandsView];
            mNavigationBar.topItem.title = @"Brands";

            self.mSelectedIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
             */
            
            [mCaqtegoryTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
            
            [self showDetailView:0];
            
            /*
            if ( AppDelegate.isCigarLoading == YES )
                [AppDelegate showLoadingView:brandsView.view];
             */

        }
            break;
            
        case 2: {
            
            /*
            FilterSearchViewController *filtersView = [[FilterSearchViewController alloc] initWithNibName:@"FilterSearchViewController" bundle:nil];
            detailViewController = filtersView;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:filtersView];
            mNavigationBar.topItem.title = @"Filter";
             */
            
            [mCaqtegoryTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:6 inSection:0] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
            
            [self showDetailView:6];
        }
            
            break;
            
        case 3: {
            
            /*
            MyHumidorsViewController *humidorVc = [[MyHumidorsViewController alloc] initWithNibName:@"MyHumidorsViewController" bundle:nil];
            detailViewController = humidorVc;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:humidorVc];
            mNavigationBar.topItem.title = @"My Humidor";
             */
            
            [mCaqtegoryTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:10 inSection:0] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
            
            [self showDetailView:10];
        }
            
            break;	
            
        case 4: {
            
            /*
            MapViewController *mapVc = [[MapViewController alloc] initWithNibName:@"MapViewController" bundle:nil];
            detailViewController = mapVc;
            AppDelegate.mNavigationController.viewControllers = [NSArray arrayWithObject:mapVc];
            mNavigationBar.topItem.title = @"Local Shops";
             */
            [mCaqtegoryTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:11 inSection:0] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
            
            [self showDetailView:11];
        }
            
            break;
            
        default:
            break;
    }
    
    
    /*
    NSArray *viewControllers = [[NSArray alloc] initWithObjects:self.navigationController, AppDelegate.mNavigationController, nil];
    AppDelegate.mSplitViewController.viewControllers = viewControllers;
    
    [viewControllers release];
    
    // Dismiss the popover if it's present.
    if (mPopOverVc != nil) {
        [mPopOverVc dismissPopoverAnimated:YES];
    }
    
    if (mRootPopOverButton != nil) {
        //        [detailViewController showRootPopoverButtonItem:self.mRootPopOverButton];
    }
    
    [detailViewController release];
    */
}

#pragma mark EKEventEditViewDelegate Method

- (void)eventEditViewController:(EKEventEditViewController *)controller didCompleteWithAction:(EKEventEditViewAction)action
{
    if ( action == EKEventEditViewActionSaved ) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"CigarBoss" message:@"Event saved to Cal" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        alertView.tag = 4000;
        [alertView show];
        [alertView release];
    }
    
    [controller dismissViewControllerAnimated:YES completion:nil];
}


@end
