//
//  LargePhotoViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LargePhotoViewController.h"
#import "CigarBossAppDelegate.h"
#import "StoreViewController.h"

@implementation LargePhotoViewController
@synthesize image;
@synthesize viewControllers;
@synthesize currentPage;
@synthesize arrData;
@synthesize flagShow,brandName;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    
    scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 460)];
    
	scrollView.maximumZoomScale = 1.0;
	scrollView.minimumZoomScale = 1.0;
	scrollView.clipsToBounds = NO;
	scrollView.scrollEnabled = YES;
	// a page is the width of the scroll view
	[scrollView setBackgroundColor:[UIColor blackColor]];
	
	scrollView.pagingEnabled = YES;
	scrollView.showsHorizontalScrollIndicator = YES;
	scrollView.showsVerticalScrollIndicator = YES;
	scrollView.delegate = self;
	
	//	scroll.showsHorizontalScrollIndicator = YES;
	[self.view addSubview:scrollView];
    
    //	self.title = @"View Photos";
    //	imageView.image = image;
    
    width = 320;
    height = 370;
}



- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
- (void)viewWillAppear:(BOOL)animated {
    [self DeleteAllImages];
    [super viewWillAppear:animated];
	//self.title = objBean.title;
    
	
    [[UIApplication sharedApplication] setStatusBarHidden:FALSE animated:TRUE];
	
    
    //	[self setToolBar];
	for (UIView *view in scrollView.subviews) {
		[view removeFromSuperview];
	}	
    if([arrData count] == 0 && image){
        imageView.image = image;
        [self.view addSubview:imageView];
        return;
    }
    else{
        [self.view bringSubviewToFront:toolBar];
        [self makingViewControllerArray];
    }
	pageControlUsed = @"notpageControlUsed";
    
}


-(void)DeleteAllImages { 
    
    BOOL isDir = NO;
    NSInteger ObjfileCount = 0;
    NSArray *subpaths;
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES); 
    NSString *pathToDocumentsDir = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    
    if ([fileManager fileExistsAtPath:pathToDocumentsDir isDirectory:&isDir] && isDir) {
        subpaths = [[[NSArray alloc]initWithArray:[fileManager subpathsAtPath:pathToDocumentsDir]]autorelease];
        ObjfileCount = [subpaths count];  
    }
    else{
        
        subpaths = [[[NSArray alloc]initWithObjects:nil]autorelease];
    }
    
    NSError *error = nil;
    
    if(subpaths) {
        int iVal = 0;
        for (NSString *strFileName in subpaths) {
            
            if ([strFileName length] > 0) {                
                //                NSString *tempAtIndex=[strFileName substringWithRange:NSMakeRange([strFileName length]-4,0)];
                
                if([[strFileName lowercaseString] isEqualToString: [NSString stringWithFormat:@"%d.png", iVal]]) {
                    
                    BOOL success = [fileManager removeItemAtPath: [pathToDocumentsDir stringByAppendingPathComponent:strFileName] error:&error];
                    if (!success || error) {
                        NSLog(@"Error Deleting All Image at Path ::>>%@",strFileName);
                    }else{
                        NSLog(@"Deleting All Image ");
                    }
                    iVal = iVal + 1;
                }
            }
        }
    }
}

#pragma mark -
#pragma mark Methods for ScrollViewiPhone 

-(void)makingViewControllerArray {
	
//	NSLog(@"\n makingViewControllerArray current page : %d", [arrData count]);
	[scrollView setFrame:CGRectMake(0, 0, 480, 370)];
	scrollView.contentSize = CGSizeMake(scrollView.frame.size.width * [arrData count], 
										scrollView.frame.size.height);
	NSMutableArray *controllers = [[NSMutableArray alloc] init];
    for (unsigned i = 0; i < [arrData count]; i++) {
        [controllers addObject:[NSNull null]];
    }
    self.viewControllers = controllers;
    [controllers release];
	
	[self loadScrollViewWithPage:0];
}

-(void) changePageManually {
	
	//NSLog(@"current page number : %d", currentPage);
    [scrollView setFrame:CGRectMake(0, 0, 480, 370)];
	CGRect frame = scrollView.frame;
	frame.origin.x = frame.size.width * currentPage;
	frame.origin.y = 0;
	[scrollView scrollRectToVisible:frame animated:NO];
}


- (void)loadScrollViewWithPage:(int)page {
	
    if (page < 0) return;
    if (page >= [arrData count]) return;
    
	// replace the placeholder if necessary
	
	//NSLog(@"array count : %d", [arrData count]);
	if (page != 0) {
		controller = [viewControllers objectAtIndex:page-1];
		if ((NSNull *)controller == [NSNull null]) {
            
			
			//controller = [[AsyncImageViewiPhone alloc] initWithFrame:CGRectMake(0,0,width,height)];
            controller = [[AsyncImageViewiPhone alloc] initWithFrame:CGRectMake(0,0,320,480)];
			[controller setIndexPath:page - 1];
			
			
			NSString *imageName, *imagePath, *imageUrl;
			
            imageName = [NSString stringWithFormat:@"%@%d.png",brandName, page-1];
            //[objBean.title stringByAppendingString:@".png"];
            imageUrl = [arrData objectAtIndex:page-1];
            
			imagePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:imageName];
			
			NSFileManager *fileManager = [NSFileManager defaultManager];
			
			if ([fileManager fileExistsAtPath:imagePath] == YES) {
				[controller imageFromImagePath:imagePath];
			}
			else 
            {
				[controller loadImageFromURL:[NSURL URLWithString:imageUrl]];
			}
			
			[viewControllers replaceObjectAtIndex:page-1 withObject:controller];
			[controller release];
		}
        
		if (nil == controller.superview) {
			CGRect frame = scrollView.frame;
			frame.origin.x = frame.size.width * (page-1);
			frame.origin.y = 0;
			controller.frame = frame;
			[controller removeFromSuperview];
			[scrollView addSubview:controller];
		}
	}
	
    controller = [viewControllers objectAtIndex:page];
    if ((NSNull *)controller == [NSNull null]) {
		controller = [[AsyncImageViewiPhone alloc] initWithFrame:CGRectMake(0,0,320,480)];
        [controller setIndexPath:page];
		
		NSString *imageName, *imagePath, *imageUrl;
		
        imageName = [NSString stringWithFormat:@"%@%d.png",brandName ,page];
        imageUrl = [arrData objectAtIndex:page];
		
		imagePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:imageName];
		
		NSFileManager *fileManager = [NSFileManager defaultManager];
		
		if ([fileManager fileExistsAtPath:imagePath] == YES) {
			[controller imageFromImagePath:imagePath];
		}
		else 
        {
			[controller loadImageFromURL:[NSURL URLWithString:imageUrl]];
		}
		
        [viewControllers replaceObjectAtIndex:page withObject:controller];
        [controller release];
    }
    
	if (nil == controller.superview) {
        CGRect frame = scrollView.frame;
        frame.origin.x = frame.size.width * page;
        frame.origin.y = 0;
		controller.frame = frame;
		
		[controller removeFromSuperview];
        [scrollView addSubview:controller];
    }
	
	if (page != [arrData count]-1) {
		controller = [viewControllers objectAtIndex:page+1];
		if ((NSNull *)controller == [NSNull null]) {
			controller = [[AsyncImageViewiPhone alloc] initWithFrame:CGRectMake(0,0,320,480)];
            [controller setIndexPath:page + 1];
			
			NSString *imageName, *imagePath, *imageUrl;
            imageName = [NSString stringWithFormat:@"%@%d.png", brandName,page + 1];
            imageUrl = [arrData objectAtIndex:page+1];
            
			imagePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:imageName];
			
			NSFileManager *fileManager = [NSFileManager defaultManager];
			
			if ([fileManager fileExistsAtPath:imagePath] == YES) {
				[controller imageFromImagePath:imagePath];
			}
			else 
            {
				[controller loadImageFromURL:[NSURL URLWithString:imageUrl]];
			}
			
			[viewControllers replaceObjectAtIndex:page+1 withObject:controller];
			[controller release];
            
		}
		if (nil == controller.superview) {
			CGRect frame = scrollView.frame;
			frame.origin.x = frame.size.width * (page+1);
			frame.origin.y = 0;
			controller.frame = frame;
			[controller removeFromSuperview];
			[scrollView addSubview:controller];
		}
	}
	
    [self unloadImages:page];
}

-(void) unloadImages:(int)page {
    
    for (int i = 0; i < [viewControllers count]; i++) {
		if (i != page && i != page+1 && i != page-1) {			
			
            controller = [viewControllers objectAtIndex:i];			
            
            if ((NSNull *)controller != [NSNull null]) {
                if(controller.connection != nil) {
                    [controller.connection cancel];
                    controller.connection = nil;
                }
				[controller removeFromSuperview];
				controller = nil;
				[viewControllers replaceObjectAtIndex:i withObject:[NSNull null]];
			}
		}
    }
}

#pragma mark -
#pragma mark ScrollView delegate Methods

- (void)scrollViewDidScroll:(UIScrollView *)sender {
	
	if (![pageControlUsed isEqualToString:@"notpageControlUsed"]) {
		//NSLog(@">>>>>>>>>>>>>>>>>>>>> page control used before");
        return;
    }
	else {
		//NSLog(@"\n>>>>>>>>>>>>>>>>>>>>> page control used");
		
		CGFloat pageWidth = scrollView.frame.size.width;
		
		int page;
		
		page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
		
		currentPage = page;
		
		pageControlUsed = @"notpageControlUsed";
		[scrollView setFrame:CGRectMake(0, 0, 480, 370)];
		//NSLog(@"scrollViewDidScroll current page =>>>>>>>>>%d",currentPage);
		[self loadScrollViewWithPage:page];   
	}	
	
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
	//NSLog(@"\nscrollViewDidEndDecelerating\n");
	pageControlUsed = @"notpageControlUsed";
}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
	//NSLog(@"\nScrollViewDidScroll\n");
	
}

// At the begin of scroll dragging, reset the boolean used when scrolls originate from the UIPageControl
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    
}
-(NSString *)applicationDocumentsDirectory {
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
	return basePath;
}



-(void)viewWillDisappear:(BOOL)animated {
    
	if(menuHideTimer != nil && [menuHideTimer isValid]) {
		[menuHideTimer invalidate];		
		menuHideTimer = nil;
	}		
}

- (void)dealloc {
    [self DeleteAllImages];
    [super dealloc];
}


@end
