//
//  SearchingOverlayView.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SearchingOverlayView : UIView {
	id parent;
}

@property (nonatomic, assign) id parent;

@end
