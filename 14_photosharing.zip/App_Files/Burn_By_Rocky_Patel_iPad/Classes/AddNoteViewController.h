//
//  AddNoteViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 11/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomImagePickerController.h"

@class CigarViewController;
@class MyClass;
@class Cigar;


@interface AddNoteViewController : UIViewController<UISplitViewControllerDelegate, UIImagePickerControllerDelegate,UIActionSheetDelegate,UINavigationControllerDelegate,UITextFieldDelegate,UITextViewDelegate, UIPopoverControllerDelegate>
{
    IBOutlet UIDatePicker *datePicker;
    IBOutlet UILabel *datePickerLabel;
    
    MyClass *viewThatClosesDatEPicker;
    
    IBOutlet UIScrollView *scrollView;
    
    IBOutlet UITextField *locationTextField, *pricePaidTextfield;
    IBOutlet UITextView *tastingNotesTextField;
    IBOutlet UITextField *scoreTextField;
    UITextField *firstResponder;
    
    Cigar *cigar;
    CigarViewController *callingViewController;
    
    UIPopoverController *popOverController;
    
    IBOutlet UIImageView *imgUpload;
    CustomImagePickerController *imagePickerController;
    IBOutlet UIButton *btnUpload;
    
    
    NSString *savedImagePath;
    float scrollSize;
}

@property (nonatomic, assign) Cigar *cigar;
@property (nonatomic, assign) float scrollSize;
@property (nonatomic, assign) CigarViewController *callingViewController;
@property (nonatomic, retain) UIPopoverController *popOverController;

- (IBAction)openDatePicker;

- (void)closeDatePicker;

- (IBAction)UploadImage;
- (IBAction)close;
- (IBAction)save;



- (UIImage *)scaleAndRotateImage:(UIImage *)image;
- (void)thumbWithSideOfLength:(NSString*)strImgName;
-(NSString *)applicationDocumentsDirectory;

@end
