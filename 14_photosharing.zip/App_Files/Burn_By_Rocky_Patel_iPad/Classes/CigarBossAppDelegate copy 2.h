//
//  CigarBossAppDelegate.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

@class AdWhirlView;
@class Cigar;

@interface CigarBossAppDelegate : NSObject <UIApplicationDelegate, UITabBarControllerDelegate> {
    UIWindow *window;
    UITabBarController *tabBarController;
	NSMutableArray *ratings;
	
	NSMutableDictionary *cigarBrandArrays;
	UIImageView *defaultImageView;
	
	NSURLConnection *connection;
	NSMutableData *data;
	NSArray *preferredStores;
	NSMutableArray *favoriteShops;
    NSMutableArray *newCigars;
    
    CLLocationCoordinate2D userLocation;
    
    NSString *kAdMobPublisherID;
    NSString *kAdWhirlSDKKey;
    AdWhirlView *ad;
    Cigar *COM;
    NSMutableDictionary *topTenDictionary;
    NSMutableArray *humidors;
    
    NSMutableArray *notes;
    
    NSMutableArray *featuredPhotos;
    
}

@property (nonatomic, assign) NSMutableArray *newCigars;

@property (nonatomic, assign) NSMutableArray *ratings;
@property (nonatomic, assign) NSMutableArray *humidors;

@property (nonatomic, assign) NSMutableArray *notes;

@property (nonatomic, assign) NSMutableArray *featuredPhotos;

@property (nonatomic) CLLocationCoordinate2D userLocation;

@property (nonatomic, assign) NSMutableArray *favoriteShops;
@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UITabBarController *tabBarController;
@property (nonatomic, assign) IBOutlet NSMutableDictionary *cigarBrandArrays;
@property (nonatomic, assign) IBOutlet UIImageView *defaultImageView;

@property (nonatomic, assign) Cigar *COM;
@property (nonatomic, assign) NSMutableDictionary *topTenDictionary;

@property (nonatomic, assign) NSArray *preferredStores;

- (void)toggleAdView;

@end
