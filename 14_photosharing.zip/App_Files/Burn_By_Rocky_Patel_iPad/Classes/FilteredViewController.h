//
//  FilteredViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FilteredViewController : UIViewController {
	int filterType;
	NSMutableArray *allCigarsArray;
	NSMutableDictionary *indexes;
	NSArray *keys;
	
	IBOutlet UITableView *mainTableView;
}

@property int filterType;
@property (nonatomic, assign) NSMutableArray *allCigarsArray;

@end
