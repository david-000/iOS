//
//  CigarBossOperation.h
//  CigarBoss_Free
//
//  Created by Lion User on 17/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequestDelegate.h"

#define LOCAL_SERVER_URL @"http://cigarboss.co/frontend/webapi.php"
#define EMAIL @"contact@burnbyrockypatel.com"

@interface CigarBossOperation : NSObject<ASIHTTPRequestDelegate>
{
    NSInteger           mLastCid;
    NSInteger           mLastBrandUpdateTime;
    NSInteger           mLastEventUpdateTime;
    
    BOOL                mIsRequestingNotification;
}

@property (nonatomic) BOOL      mIsRequestingNotification;

- (void) requestSetToken : (NSString *) token;
- (void) requestGetBrands : (NSInteger) last_cid;
- (void) requestGetUpdateBrands : (NSString *) email;
- (void) requestGetNotification : (NSString *) email;
+ (void) parseCigarData;

@end
