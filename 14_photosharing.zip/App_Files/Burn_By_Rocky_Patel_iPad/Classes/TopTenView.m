//
//  TopTenView.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TopTenView.h"
#import "CustomHighlightedCell.h"
#import "CigarViewController.h"
#import "CigarBossAppDelegate.h"
@implementation TopTenView

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        allTopTens = [[[UIApplication sharedApplication] delegate] topTenDictionary];
        currentTopTen = [allTopTens objectForKey:@"overall"];
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (IBAction)topTenCategoryChanged:(id)sender
{
   // NSLog(@"top ten segmented touched");
    NSString *title = [[segCont titleForSegmentAtIndex:[segCont selectedSegmentIndex]] lowercaseString];
    currentTopTen = [allTopTens objectForKey:title];
    [mainTableView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.title = @"Top Tens";
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 703, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =@"Top Tens"; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];
	mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 704)];
	bgView.image = [UIImage imageNamed:@"right_side.png"];
	
    [segCont removeAllSegments];
    [segCont insertSegmentWithTitle:@"Overall" atIndex:0 animated:NO];
    [segCont insertSegmentWithTitle:@"Mild" atIndex:1 animated:NO];
    [segCont insertSegmentWithTitle:@"Medium" atIndex:2 animated:NO];
    [segCont insertSegmentWithTitle:@"Full" atIndex:3 animated:NO];
    [segCont insertSegmentWithTitle:@"Economy" atIndex:4 animated:NO];
    [segCont setSelectedSegmentIndex:0];
    [self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];

}
-(void)viewDidAppear:(BOOL)animated
{
    if(AppDelegate.adStatus)
    {
        [mainTableView setFrame:CGRectMake(0, 30, 703, 550)];
    }
    else
    {
        [mainTableView setFrame:CGRectMake(0, 30, 703, 640)];
    }
    
}


- (int)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
	return [[currentTopTen allKeys] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BrandCell"];
	
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"BrandCell"] autorelease];
	}
	
	cell.textLabel.textColor = [UIColor whiteColor];
    NSString *spaceForBrandLabelText = @"%d   %@";
    if(indexPath.row == 9){
        spaceForBrandLabelText = @"%d %@";
    }
    
    cell.detailTextLabel.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"     %@", [[currentTopTen objectForKey:[NSString stringWithFormat:@"%d", indexPath.row+1]] type]];
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	//cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = [NSString stringWithFormat:spaceForBrandLabelText, indexPath.row+1, [[currentTopTen objectForKey:[NSString stringWithFormat:@"%d", indexPath.row+1]] brand]];
    cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:22.0];
	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CigarViewController *cigarViewController = [[CigarViewController alloc] initWithNibName:@"CigarViewController" bundle:nil];
    cigarViewController.cigar = [currentTopTen objectForKey:[NSString stringWithFormat:@"%d", indexPath.row+1]];
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:cigarViewController animated:YES];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
