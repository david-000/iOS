//
//  FilteredViewFinal.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CigarViewController.h"

@class CigarBossAppDelegate;

@interface FilteredViewFinal : UIViewController {
	IBOutlet UITableView *mainTableView;
	NSArray *cigars;
    
    CigarBossAppDelegate *appDelegate;
	NSMutableArray *keys;
	NSMutableDictionary *indexes;
}

@property (nonatomic, assign) NSArray *cigars;

@end
