//
//  communityViewController.m
//  CigarBoss
//
//  Created by Nitin on 13/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
#import "Cigar.h"
#import "communityViewController.h"
#import "CigarBossAppDelegate.h"
#import "TouchXML.h"
#import "CustomHighlightedCell.h"
#import "ViewUserReview.h"
#import "CigarBossAppDelegate.h"
#import "CigarViewController.h"


CigarBossAppDelegate *appDelegate;
@implementation communityViewController
@synthesize flag;
CigarBossAppDelegate *appDelegate;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        flag = YES;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
-(void)viewWillAppear:(BOOL)animated
{
    if(flag){
        [self CallCommunity];
        flag = NO;
    }
    
    NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
    keys = [[NSArray alloc] init];
    indexes = [[NSMutableDictionary alloc] init];
	keys = [brandsDictionary allKeys];
	keys = [keys sortedArrayUsingSelector:@selector(compare:)];
	
	for(NSString *key in keys){
		NSString *firstLetter = [key substringToIndex:1];
		NSMutableArray *existingArray;
		//NSLog(firstLetter);
		// if an array already exists in the name index dictionary
		// simply add the element to it, otherwise create an array
		// and add it to the name index dictionary with the letter as the key
		if ((existingArray = [indexes valueForKey:firstLetter])) 
		{
			[existingArray addObject:key];
		} 
        else {
			NSMutableArray *tempArray = [NSMutableArray array];
			[indexes setObject:tempArray forKey:firstLetter];
			[tempArray addObject:key];
		}
	}
    testingofArray = [[NSMutableArray alloc] init];
	keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    
    for(int k = 0 ; k < [keys count] ; k++)
    {
        NSArray *arr = [indexes objectForKey:[keys objectAtIndex:k]];
        for (int j = 0; j < [arr count]; j++) {
            
            NSMutableArray *cigars = [[appDelegate cigarBrandArrays] objectForKey:[arr objectAtIndex:j]];
            for(int m = 0 ; m < [cigars count] ; m ++)
            {
                Cigar *cg  = (Cigar *)[cigars objectAtIndex:m];
                
                [testingofArray addObject:cg];
                
            }
        }
    }
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
	mainTable.backgroundColor = [UIColor clearColor];
	mainTable.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 704)];
	bgView.image = [UIImage imageNamed:@"right_side.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
    
    
    if([userArray count] > 0)
    {
        [mainTable reloadData];
    }
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 703, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =@"Community"; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];

    // Do any additional setup after loading the view from its nib.
}
-(void)CallCommunity
{
    [appDelegate showLoadingView:self.view];
    
    NSString *webService = [NSString stringWithFormat:soapAction];
    NSString *soapMessage = [NSString stringWithFormat:
                             @"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                             "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
                             "<soap:Body>\n"
                             "<lattestcigarreview xmlns=\"%@\">\n"
                             "<blank></blank>"
                             "</lattestcigarreview>\n"
                             "</soap:Body>\n"
                             "</soap:Envelope>\n",xmlns];
    
    // NSLog(@"soap msg : %@", soapMessage);
    NSURL *url = [NSURL URLWithString:webService];
    NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:60.0];
    NSString *msgLength = [NSString stringWithFormat:@"%d", [soapMessage length]];
    
    [theRequest addValue: @"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [theRequest addValue: [webService stringByAppendingString:@"/lattestcigarreview"] forHTTPHeaderField:@"SOAPAction"];
    [theRequest addValue: msgLength forHTTPHeaderField:@"Content-Length"];
    [theRequest setHTTPMethod:@"POST"];
    [theRequest setHTTPBody: [soapMessage dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection *theConnection = [[NSURLConnection alloc] initWithRequest:theRequest delegate:self];	
    if(theConnection) {
        //webData = [[NSMutableData data] retain];		
    }else {
        NSLog(@"The Connection is NULL");
    }
    
    
}


-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	webData = [[NSMutableData data] retain];
    // NSLog(@"data = %@ ",webData);
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	[webData appendData:data];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    //	[[ActivityIndicator sharedActivityIndicator]hide];
    
    [appDelegate hideLoadingView];
	NSLog(@"ERROR with theConenction %@",error);
	UIAlertView *connectionAlert = [[UIAlertView alloc] initWithTitle:@"Information !" message:@"Internet / Service Connection Error" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[connectionAlert show];
	[connectionAlert release];
	
	[connection release];
	[webData release];
	
	return;
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    userArray = [[NSMutableArray alloc] init];
    
    
    CXMLDocument *doc = [[[CXMLDocument alloc] initWithData:webData options:0 error:nil] autorelease];
    
	NSArray *nodes1 = [doc nodesForXPath:@"//return" error:nil];
    
	for (CXMLElement *node in nodes1) {		
        
		for(int counter = 0; counter < [node childCount]; counter++) {		    
            
            if ([[[node childAtIndex:counter] name] isEqualToString:@"List"]) {					
                
                NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
                for(int c = 0; c < [[[node childAtIndex:counter] children] count]; c++) {
                    //NSLog(@">>>>>>>>>>>>>>>>> %@ ",[[[node childAtIndex:counter] childAtIndex:c] name]);
                    if([[[[node childAtIndex:counter] childAtIndex:c] name] isEqualToString:@"cigarId"])
                    {
                        NSString *w = [[[node childAtIndex:counter] childAtIndex:c]  stringValue];
                        [dict setObject:w forKey:@"cigarId"];                                
                    }
                    if([[[[node childAtIndex:counter] childAtIndex:c] name] isEqualToString:@"brandname"])
                    {
                        NSString *w = [[[node childAtIndex:counter] childAtIndex:c]  stringValue];
                        [dict setObject:w forKey:@"brandname"];                                
                    }
                    
                    if([[[[node childAtIndex:counter] childAtIndex:c] name] isEqualToString:@"Brand_ID"])
                    {
                        NSString *w = [[[node childAtIndex:counter] childAtIndex:c]  stringValue];
                        [dict setObject:w forKey:@"Brand_ID"];                                
                    }
                    
                    if([[[[node childAtIndex:counter] childAtIndex:c] name] isEqualToString:@"username"])
                    {
                        NSString *w = @"";
                        w = [[[node childAtIndex:counter] childAtIndex:c] stringValue];
                        [dict setObject:w forKey:@"username"];                                                        
                    }
                    if([[[[node childAtIndex:counter] childAtIndex:c] name] isEqualToString:@"email"])
                    {
                        NSString *w  = [[[node childAtIndex:counter] childAtIndex:c] stringValue];
                        [dict setObject:w forKey:@"email"];                                
                    }
                    if([[[[node childAtIndex:counter] childAtIndex:c]  name] isEqualToString:@"cigType"])
                    {
                        NSString *w  = [[[node childAtIndex:counter] childAtIndex:c]  stringValue];
                        [dict setObject:w forKey:@"cigType"];                                                        
                    }
                    if([[[[node childAtIndex:counter] childAtIndex:c] name] isEqualToString:@"startRate"])
                    {
                        NSString *w  = [[[node childAtIndex:counter] childAtIndex:c]  stringValue];
                        [dict setObject:w forKey:@"startRate"]; 
                    }
                    if([[[[node childAtIndex:counter] childAtIndex:c]  name] isEqualToString:@"dateSmoked"])
                    {
                        NSString *w  = [[[node childAtIndex:counter] childAtIndex:c]  stringValue];
                        [dict setObject:w forKey:@"dateSmoked"];         
                    }
                    if([[[[node childAtIndex:counter] childAtIndex:c]  name] isEqualToString:@"pricePaid"])
                    {
                        NSString *w  = [[[node childAtIndex:counter] childAtIndex:c]  stringValue];
                        [dict setObject:w forKey:@"pricePaid"];                                                        
                    }
                    if([[[[node childAtIndex:counter] childAtIndex:c]  name] isEqualToString:@"headline"])
                    {
                        NSString *w  = [[[node childAtIndex:counter] childAtIndex:c]  stringValue];
                        [dict setObject:w forKey:@"headline"];                                                               
                    }
                    if([[[[node childAtIndex:counter] childAtIndex:c]  name] isEqualToString:@"renote"])
                    {
                        NSString *w  = [[[node childAtIndex:counter] childAtIndex:c]  stringValue];
                        [dict setObject:w forKey:@"renote"];                                                       
                    }
                    
                    if([[[[node childAtIndex:counter] childAtIndex:c]  name] isEqualToString:@"imageurl"])
                    {
                        NSString *w = [[[node childAtIndex:counter] childAtIndex:c]  stringValue];
                        [dict setObject:w forKey:@"imageurl"];                                
                    }
                    
                    if([[[[node childAtIndex:counter] childAtIndex:c] name] isEqualToString:@"rate"])
                    {
                        NSString *w  = [[[node childAtIndex:counter] childAtIndex:c] stringValue];
                        [dict setObject:w forKey:@"rate"];                                        
                    }
                    
                    if([[[[node childAtIndex:counter] childAtIndex:c] name] isEqualToString:@"approve"])
                    {
                        NSString *w = [[[node childAtIndex:counter] childAtIndex:c]  stringValue];
                        [dict setObject:w forKey:@"approve"];                                
                    }
                    
                    
                }
                //NSLog(@"Dict %@",dict);
                [userArray addObject:dict];
            }
        }
    }
    [connection release];
	[webData release];
    [appDelegate hideLoadingView];
    [mainTable reloadData];
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 110.0f;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [userArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BrandCell"];
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil] autorelease];
	}
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.textLabel.textColor = [UIColor whiteColor];
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    NSMutableDictionary *dic = [userArray objectAtIndex:indexPath.row];
    //        cell.textLabel.text = [[userArray objectAtIndex:indexPath.row] objectForKey:@"cigType"];
    //
    //        cell.detailTextLabel.text = [[userArray objectAtIndex:indexPath.row] objectForKey:@"headline"];
    //        cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    //	    
    //    //============================ Star in TableView Cell ============================
    //    
    //    if([[dic objectForKey:@"startRate"] floatValue] || [[dic objectForKey:@"startRate"] isEqualToString:@"0"])
    //    {
    //        float xVal = 0;
    //        UIView *starV = [[UIView alloc] initWithFrame:CGRectMake(150, 5, 175, 30)];
    //        int starVal = [[dic objectForKey:@"startRate"] intValue];
    //        for (int k = 0; k < 5 ; k++) {
    //            UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(xVal, 0, 30, 30)];
    //            [starV addSubview:btn];
    //            [btn setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
    //            [btn setUserInteractionEnabled:NO];
    //            
    //            if(k < starVal)
    //            {
    //                [btn setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];       
    //            }
    //            [btn release];
    //            xVal += 31;
    //        }
    //        [cell.contentView addSubview:starV];
    //    }
    
    UILabel *BrandtitleLabel = [[UILabel alloc]initWithFrame:CGRectMake(30,15, 600, 20)];
    BrandtitleLabel.textColor = [UIColor whiteColor];
    BrandtitleLabel.textAlignment = UITextAlignmentLeft;
    BrandtitleLabel.text = [dic objectForKey:@"brandname"];
    BrandtitleLabel.backgroundColor = [UIColor clearColor];
    BrandtitleLabel.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    BrandtitleLabel.minimumFontSize = 10;
    BrandtitleLabel.adjustsFontSizeToFitWidth = YES;
    [cell.contentView addSubview:BrandtitleLabel];
    [BrandtitleLabel release];
    BrandtitleLabel = nil;
    
    UILabel *BrandTypeLabel = [[UILabel alloc]initWithFrame:CGRectMake(30,40, 200, 20)];
    BrandTypeLabel.textColor = [UIColor whiteColor];
    BrandTypeLabel.textAlignment = UITextAlignmentLeft;
    BrandTypeLabel.text = [dic objectForKey:@"cigType"];
    BrandTypeLabel.backgroundColor = [UIColor clearColor];
    BrandTypeLabel.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    BrandTypeLabel.minimumFontSize = 10;
    BrandTypeLabel.adjustsFontSizeToFitWidth = YES;
    [cell.contentView addSubview:BrandTypeLabel];
    [BrandTypeLabel release];
    BrandTypeLabel = nil;
    
    
    
    
    
    //============================ Star in TableView Cell ============================
    
    if([[dic objectForKey:@"startRate"] floatValue])
    {
        float xVal = 0;
        UIView *starV = [[UIView alloc] initWithFrame:CGRectMake(225, 55, 35, 15)];
        int starVal = [[dic objectForKey:@"startRate"] intValue];
        for (int k = 1; k <= 5 ; k++) {
            UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(xVal, 5, 15, 15)];
            [starV addSubview:btn];
            [btn setBackgroundImage:[UIImage imageNamed:@"ReviewStarsOutline88x88.png"] forState:UIControlStateNormal];
            [btn setUserInteractionEnabled:NO];
            
            if(k <= starVal)
            {
                [btn setBackgroundImage:[UIImage imageNamed:@"ReviewStars88x88.png"] forState:UIControlStateNormal];       
            }
            [btn release];
            xVal += 16;
        }
        [cell.contentView addSubview:starV];
    }
    //===============================================================================
    
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(30,60, 400, 20)];
    titleLabel.textColor = [UIColor grayColor];
    titleLabel.textAlignment = UITextAlignmentLeft;
    titleLabel.text = [dic objectForKey:@"username"];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:22];
    titleLabel.minimumFontSize = 10;
    titleLabel.adjustsFontSizeToFitWidth = YES;
    [cell.contentView addSubview:titleLabel];
    [titleLabel release];
    titleLabel = nil;
    
    //=================
    
    
    UILabel *lbldate;
    lbldate = [[UILabel alloc] initWithFrame:CGRectMake(30, 80, 400, 20)];
    lbldate.numberOfLines = 1;
    lbldate.text =[NSString stringWithFormat:@"Date Smoked: %@",[dic objectForKey:@"dateSmoked"]]  ;
    [lbldate alignTop];
    lbldate.backgroundColor = [UIColor clearColor];
    lbldate.textColor = [UIColor grayColor];
    lbldate.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    titleLabel.minimumFontSize = 10;
    [cell.contentView addSubview:lbldate];
    [lbldate release];
    lbldate = nil;
    
    UILabel *lblheadline;
    lblheadline = [[UILabel alloc] initWithFrame:CGRectMake(30, 65, 280, 15)];
    lblheadline.numberOfLines = 1;
    lblheadline.text =[NSString stringWithFormat:@"Headline : %@",[dic objectForKey:@"headline"]]  ;
    [lblheadline alignTop];
    lblheadline.backgroundColor = [UIColor clearColor];
    lblheadline.textColor = [UIColor whiteColor];
    lblheadline.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    lbldate.minimumFontSize = 10;
    //   [cell.contentView addSubview:lblheadline];
    [lblheadline release];
    lblheadline = nil;
    
    UILabel *lbldescType;
    lbldescType = [[UILabel alloc] initWithFrame:CGRectMake(30, 75, 280, 30)];
    lbldescType.numberOfLines = 2;
    lbldescType.text =[NSString stringWithFormat:@"Note : %@",[dic objectForKey:@"renote"]]  ;
    [lbldescType alignTop];
    lbldescType.backgroundColor = [UIColor clearColor];
    lbldescType.textColor = [UIColor whiteColor];
    lbldescType.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    titleLabel.minimumFontSize = 10;
    //   [cell.contentView addSubview:lbldescType];
    [lbldescType release];
    lbldescType = nil;
    
    //===============================================================================
    
	return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
	ViewUserReview *vur = [[ViewUserReview alloc] initWithNibName:@"ViewUserReview" bundle:nil];
    vur.dictObj = [userArray objectAtIndex:indexPath.row];
    NSString *bId = [[userArray objectAtIndex:indexPath.row] objectForKey:@"Brand_ID"];
    //    [self.navigationController pushViewController:vur animated:YES];  
    
    for (int l = 0; l < [testingofArray count]; l++) {
        Cigar *cg = (Cigar *)[testingofArray objectAtIndex:l];
        if([cg.brandId isEqualToString:bId])
        {
            CigarViewController *c = [[CigarViewController alloc] initWithNibName:@"CigarViewController" bundle:[NSBundle mainBundle]];
            c.cigar = cg;
            c.isUpdate = YES;
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 400, 44)];
            label.backgroundColor = [UIColor clearColor];
            label.font = [UIFont boldSystemFontOfSize:22.0];
            label.font = [UIFont fontWithName:@"Copperplate" size:22.0];
            label.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
            label.textAlignment = UITextAlignmentCenter;
            label.textColor =[UIColor whiteColor];
            label.text=self.title;	
            self.navigationItem.titleView = label;		
            [label release];
            self.navigationItem.title=@"Back";
            [self.navigationController pushViewController:c animated:YES];
        }
    }
}

-(void)viewDidAppear:(BOOL)animated
{
    if(AppDelegate.adStatus)
    {
        [mainTable setFrame:CGRectMake(0, 40, 703, 584)];
    }
    else
    {
        [mainTable setFrame:CGRectMake(0, 40, 703, 704)];        
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
