//
//  MyClass.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 11/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AddNoteViewController;
@class ViewNoteViewController;

@interface MyClass : UIView {
    AddNoteViewController *parentViewsViewController;
    ViewNoteViewController *parentViewContr;
}

@property (nonatomic, assign) AddNoteViewController *parentViewsViewController;
@property (nonatomic, assign) ViewNoteViewController *parentViewContr;
@end
