//
//  CubanViewController.h
//  CigarBoss
//
//  Created by Nilesh on 04/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BrandsViewController;
@interface CubanViewController : UITableViewController<UISearchBarDelegate>
{
    UITableView *searchingTableView;
    
    NSArray *keys;
	NSMutableDictionary *indexes;
    
    NSMutableArray *Ncigars;
    
    NSMutableArray *arrCuban;
    
    NSMutableArray *arrCigarObj;
    NSMutableDictionary *arrdist;
    NSMutableDictionary *arrdist2;
    NSArray *AllkeyIndexArray;
    
    BrandsViewController *objParent;
}


-(void)setParent:(BrandsViewController *)obj;
-(void)SetTableData;
-(void)makeArray:(NSMutableArray *)storedArray;

@end
