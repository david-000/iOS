//
//  CigarDatabaseData.h
//  CigarBoss_Free
//
//  Created by WYP on 9/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CigarDatabaseData : NSObject
{
    NSInteger       mBrandId;
    NSString        *mBrandData;
}

@property (nonatomic) NSInteger             mBrandId;
@property (nonatomic, retain) NSString      *mBrandData;

@end
