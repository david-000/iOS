//
//  FilteredViewControllerNew.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FilteredViewControllerNew.h"
#import "Cigar.h"
#import "CigarBossAppDelegate.h"
#import "CustomHighlightedCell.h"
#import "FilteredViewFinal.h"

NSComparisonResult floatSort(id num1, id num2, void *context)
{
    float v1 = [num1 floatValue];
    float v2 = [num2 floatValue];
    if (v1 < v2)
        return NSOrderedAscending;
    else if (v1 > v2)
        return NSOrderedDescending;
    else
        return NSOrderedSame;
}

@implementation FilteredViewControllerNew
@synthesize type;
@synthesize allCigarsArray;

 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
		type = 0;
		indexes = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	FilteredViewFinal *f = [[FilteredViewFinal alloc] initWithNibName:@"FilteredViewFinal" bundle:[NSBundle mainBundle]];
	f.cigars = [indexes objectForKey:[keys objectAtIndex:indexPath.row]];
    self.navigationItem.title=@"Back";
	[self.navigationController pushViewController:f animated:YES];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 420)];
	bgView.image = [UIImage imageNamed:@"Background640x734.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
	
	if(!gotThis){
		appDelegate = [[UIApplication sharedApplication] delegate];
		
		NSString *key = @"type";
		if(type == 1) key = @"strength";
		if(type == 2) key = @"ring";
		if(type == 3) key = @"country";
		if(type == 4) key = @"wrapper";
		if(type == 5) key = @"length";
		if(type == 6) key = @"price";
		if(type == 7) key = @"boxprice";
		//NSLog(@"<<<<<<<<<<All Cigar Array = %@ ",allCigarsArray);
        
		NSSortDescriptor *descriptor = [[[NSSortDescriptor alloc] initWithKey:key ascending:YES] autorelease];
		allCigarsArray = [allCigarsArray sortedArrayUsingDescriptors:[NSArray arrayWithObject:descriptor]];
        
        if(type == 6){
            [indexes setObject:[[NSMutableArray alloc] init] forKey:@"Under $3"];
            [indexes setObject:[[NSMutableArray alloc] init] forKey:@"$3 - $5"];
            [indexes setObject:[[NSMutableArray alloc] init] forKey:@"$5 - $7"];
            [indexes setObject:[[NSMutableArray alloc] init] forKey:@"$7 - $10"];
            [indexes setObject:[[NSMutableArray alloc] init] forKey:@"Over $15"];
            [indexes setObject:[[NSMutableArray alloc] init] forKey:@"$10 - $15"];
        } else if(type == 1){
            [indexes setObject:[[NSMutableArray alloc] init] forKey:@"Full"];
            [indexes setObject:[[NSMutableArray alloc] init] forKey:@"Medium - Full"];
            [indexes setObject:[[NSMutableArray alloc] init] forKey:@"Mild - Medium"];
        }
        
		for(Cigar *cigar in allCigarsArray){
			NSString *firstLetter = [[cigar valueForKey:key] substringToIndex:1];
			if(type == 0 || type == 1 ||type == 2|| type == 3 || type == 4 || type == 6 || type == 7) firstLetter = [cigar valueForKey:key];
			if(type == 6 || type == 7) firstLetter = [firstLetter stringByReplacingOccurrencesOfString:@" (Online)" withString:@""];
			if(type == 6 || type == 7) firstLetter = [firstLetter stringByReplacingOccurrencesOfString:@"(Online)" withString:@""];
			if(type == 6 || type == 7) firstLetter = [firstLetter stringByReplacingOccurrencesOfString:@"Online)" withString:@""];
			if(type == 6 || type == 7) firstLetter = [firstLetter stringByReplacingOccurrencesOfString:@"(online)" withString:@""];
			if(type == 6 || type == 7) firstLetter = [firstLetter stringByReplacingOccurrencesOfString:@"$" withString:@""];
			if(type == 6 && [firstLetter floatValue] == 0) continue;
			
			NSMutableArray *existingArray;
			//NSLog(firstLetter);
			// if an array already exists in the name index dictionary
			// simply add the element to it, otherwise create an array
			// and add it to the name index dictionary with the letter as the key
            if(type == 6){
                float firstLetterFloatval = [firstLetter floatValue];
                if(firstLetterFloatval < 3.0){
                    existingArray = [indexes valueForKey:@"Under $3"];
                    [existingArray addObject:cigar];
                } else if(firstLetterFloatval >= 3.0 && firstLetterFloatval < 5.0){
                    existingArray = [indexes valueForKey:@"$3 - $5"];
                    [existingArray addObject:cigar];
                } else if(firstLetterFloatval >= 5.0 && firstLetterFloatval < 7.0){
                    existingArray = [indexes valueForKey:@"$5 - $7"];
                    [existingArray addObject:cigar];
                } else if(firstLetterFloatval >= 7.0 && firstLetterFloatval < 10.0){
                    existingArray = [indexes valueForKey:@"$7 - $10"];
                    [existingArray addObject:cigar];
                } else if(firstLetterFloatval >= 10.0 && firstLetterFloatval <= 15.0){
                    existingArray = [indexes valueForKey:@"$10 - $15"];
                    [existingArray addObject:cigar];
                } else if(firstLetterFloatval >= 15.0){
                    existingArray = [indexes valueForKey:@"Over $15"];
                    [existingArray addObject:cigar];
                }
            } else if(type == 1){
                if([firstLetter isEqualToString:@"Full"]){
                    existingArray = [indexes valueForKey:@"Full"];
                    [existingArray addObject:cigar];
                } else if([firstLetter isEqualToString:@"Full Bodied"]){
                    existingArray = [indexes valueForKey:@"Full"];
                    [existingArray addObject:cigar];
                } else if([firstLetter isEqualToString:@"Medium to Full"]){
                    existingArray = [indexes valueForKey:@"Medium - Full"];
                    [existingArray addObject:cigar];
                } else if([firstLetter isEqualToString:@"Medium"]){
                    existingArray = [indexes valueForKey:@"Medium - Full"];
                    [existingArray addObject:cigar];
                } else if([firstLetter isEqualToString:@"Medium-Full"]){
                    existingArray = [indexes valueForKey:@"Medium - Full"];
                    [existingArray addObject:cigar];
                } else if([firstLetter isEqualToString:@"Medium/Full Bodied"]){
                    existingArray = [indexes valueForKey:@"Medium - Full"];
                    [existingArray addObject:cigar];
                } else if([firstLetter isEqualToString:@"Mild"]){
                    existingArray = [indexes valueForKey:@"Mild - Medium"];
                    [existingArray addObject:cigar];
                } else if([firstLetter isEqualToString:@"Mild to Medium"]){
                    existingArray = [indexes valueForKey:@"Mild - Medium"];
                    [existingArray addObject:cigar];
                } else if([firstLetter isEqualToString:@"Mild-Medium"]){
                    existingArray = [indexes valueForKey:@"Mild - Medium"];
                    [existingArray addObject:cigar];
                } else if([firstLetter isEqualToString:@"Mild/Medium"]){
                    existingArray = [indexes valueForKey:@"Mild - Medium"];
                    [existingArray addObject:cigar];
                }
            } else {
                if (existingArray = [indexes valueForKey:firstLetter]) 
                {
                    [existingArray addObject:cigar];
                } else {
                    NSMutableArray *tempArray = [NSMutableArray array];
                    [indexes setObject:tempArray forKey:firstLetter];
                    [tempArray addObject:cigar];
                }
            }
		}
		[indexes removeObjectForKey:@"Not Available"];
		keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
        
		if(type == 6){
			[keys release];
			//keys = [[[indexes allKeys] sortedArrayUsingFunction:floatSort context:NULL] retain];
            //keys = [[indexes allKeys] retain];
            keys = [[NSArray arrayWithObjects:@"Under $3", @"$3 - $5", @"$5 - $7", @"$7 - $10", @"$10 - $15", @"Over $15", nil] retain];
		} else if(type == 1){
            [keys release];
			//keys = [[[indexes allKeys] sortedArrayUsingFunction:floatSort context:NULL] retain];
            //keys = [[indexes allKeys] retain];
            keys = [[NSArray arrayWithObjects:@"Full", @"Medium - Full", @"Mild - Medium", nil] retain];
        }
		
		gotThis = YES;
	}
    
   // NSLog(@"--------------- %@ ",keys);
}

- (int)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [keys count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainCell"];
	
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MainCell"] autorelease];
	}
	
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.textLabel.text = [keys objectAtIndex:indexPath.row];
	cell.textLabel.textColor = [UIColor whiteColor];
    cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:16];
	
	return cell;
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
