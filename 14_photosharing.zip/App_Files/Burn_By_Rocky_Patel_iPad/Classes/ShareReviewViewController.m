//
//  ShareReviewViewController.m
//  CigarBoss
//
//  Created by Nitin on 20/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ShareReviewViewController.h"

#import "CigarViewController.h"
#import "TouchXML.h"
#import "CigarBossAppDelegate.h"
#import "FillReviewFormViewController.h"


CigarBossAppDelegate *appDelegate;

@implementation ShareReviewViewController
CigarViewController *objCigar;
@synthesize brandId;
@synthesize type,brandName;

-(void)setParent:(CigarViewController *)obj
{
    objCigar = obj;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    
    userDefault = [NSUserDefaults standardUserDefaults];
    // [userDefault synchronize];
    
    NSString *uname = [userDefault objectForKey:@"isChecked"]; 
    
    if([uname isEqualToString:@"UserName"])
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
-(IBAction)CallWebService

{
    [appDelegate showLoadingView:self.view];
    
    NSString *webService = [NSString stringWithFormat:soapAction];
    NSString *soapMessage = [NSString stringWithFormat:
                             @"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                             "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
                             "<soap:Body>\n"
                             "<usercheck xmlns=\"%@\">\n"
                             "<username>%@</username>"
                             "</usercheck>\n"
                             "</soap:Body>\n"
                             "</soap:Envelope>\n",xmlns,txtPass.text
                             ];
    
  //  NSLog(@"soap msg : %@", soapMessage);
    NSURL *url = [NSURL URLWithString:webService];
    NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:60.0];
    NSString *msgLength = [NSString stringWithFormat:@"%d", [soapMessage length]];
    
    [theRequest addValue: @"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [theRequest addValue: [webService stringByAppendingString:@"/usercheck"] forHTTPHeaderField:@"SOAPAction"];
    [theRequest addValue: msgLength forHTTPHeaderField:@"Content-Length"];
    [theRequest setHTTPMethod:@"POST"];
    [theRequest setHTTPBody: [soapMessage dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection *theConnection = [[NSURLConnection alloc] initWithRequest:theRequest delegate:self];	
    if(theConnection) {
        //webData = [[NSMutableData data] retain];		
    }else {
        NSLog(@"The Connection is NULL");
    }
}
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	webData = [[NSMutableData data] retain];
    // NSLog(@"data = %@ ",webData);
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	[webData appendData:data];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    //	[[ActivityIndicator sharedActivityIndicator]hide];
	NSLog(@"ERROR with theConenction %@",error);
    [appDelegate hideLoadingView];
	UIAlertView *connectionAlert = [[UIAlertView alloc] initWithTitle:@"Information !" message:@"Internet / Service Connection Error" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[connectionAlert show];
	[connectionAlert release];
	
	[connection release];
	[webData release];
	
	return;
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection {
    CXMLDocument *doc = [[[CXMLDocument alloc] initWithData:webData options:0 error:nil] autorelease];
   	NSArray *nodes1 = [doc nodesForXPath:@"//return" error:nil];
    //  NSLog(@"<<<<<<<< %@ ",nodes1);
	for (CXMLElement *node in nodes1) {		
		
		for(int counter = 0; counter < [node childCount]; counter++) {		    
            
			if ([[[node childAtIndex:counter] name] isEqualToString:@"text"]) {					
				NSString *str = [[node childAtIndex:counter] stringValue];			
				
				if ([str isEqualToString:@"success"]) {
                    
					UIAlertView *connectionAlert = [[UIAlertView alloc] initWithTitle:@"Message !" message:@"Thank you..." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                    [connectionAlert show];
                    [connectionAlert release];
                    FillReviewFormViewController *frf = [[FillReviewFormViewController alloc]initWithNibName:@"FillReviewFormViewController" bundle:nil];
                    [frf setParent:objCigar];
                    frf.brandId = brandId;
                    frf.type = type;
                    frf.brandName = brandName;
                    frf.title = @"Review Form";
                    [self presentModalViewController:frf animated:YES];
				}
                else {
                    
					UIAlertView *connectionAlert = [[UIAlertView alloc] initWithTitle:@"Message !" message:@"This User name already Exists.\n Try Different one.!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                    [connectionAlert show];
                    [connectionAlert release];
				}
			}
		}
	}
    [appDelegate hideLoadingView];
	[connection release];
	[webData release];
    
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(IBAction)onBtnLoginClick:(id)sender
{
    
    if(txtPass.text.length > 0 && txtMail.text.length > 0)
    {
        userDefault = [NSUserDefaults standardUserDefaults];
        [userDefault setObject:@"UserName" forKey:@"isChecked"];
        [userDefault synchronize];
        
        userMail = [NSUserDefaults standardUserDefaults];
        [userMail setObject:txtMail.text forKey:@"isMail"];    
        [userMail synchronize];
        
        userName = [NSUserDefaults standardUserDefaults];
        [userName setObject:txtPass.text forKey:@"isUser"];    
        [userName synchronize];
        [self CallWebService];
        
        // [self.navigationController pushViewController:frf animated:YES];
    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
