//
//  NonCubanViewController.h
//  CigarBoss
//
//  Created by Nilesh on 04/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@class BrandsViewController;

@interface NonCubanViewController : UITableViewController<UISearchBarDelegate>
{
    UITableView *searchingTableView;
    
    NSArray *keys;
	NSMutableDictionary *indexes;
    
    NSMutableArray *Ncigars;
    
    NSMutableArray *arrCuban;
    
    NSMutableArray *arrCigarObj;
    NSMutableDictionary *arrdist;
    NSMutableDictionary *arrdist2;
    NSArray *AllkeyIndexArray;
    
    BrandsViewController *objParent;
}

@property (nonatomic) NSInteger     mShowType;
@property (nonatomic, retain) NSMutableArray       *arrCigarObj;

-(void)setParent:(BrandsViewController *)obj;
-(void)SetTableData;
-(void)makeArray:(NSMutableArray *)storedArray;


@end
