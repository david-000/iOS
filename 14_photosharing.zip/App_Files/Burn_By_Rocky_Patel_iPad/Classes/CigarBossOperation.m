//
//  CigarBossOperation.m
//  CigarBoss_Free
//
//  Created by Lion User on 17/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CigarBossAppDelegate.h"
#import "CigarBossOperation.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "Cigar.h"
#import "SharedData.h"
#import "SBJSON.h"
#import "CigarDatabaseData.h"
#import "EventData.h"
#import "NotifyData.h"

@implementation CigarBossOperation
@synthesize mIsRequestingNotification;

- (void) requestGetBrands : (NSInteger) last_cid
{
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate showFirstLoadingView:appDelegate.objStartUp.view];
    
    NSString *urlString = [NSString stringWithFormat:@"%@?task=getalldata&email=%@&last_cid=%d&count=500", LOCAL_SERVER_URL, EMAIL, last_cid];
    
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:urlString]];
    
    [request setRequestMethod:@"GET"];
	[request setDidFinishSelector:@selector(requestGetBrandsDidFinish:)];
	[request setDidFailSelector:@selector(requestGetBrandsDidFail:)];
    [request setDelegate:self];
    [request setTimeOutSeconds:60];
    
    SharedData *sharedData = [SharedData sharedData];
    
    [sharedData.mOperationQueue addOperation:request];
}

- (void) requestGetUpdateBrands : (NSString *) email;
{
    if ( mLastBrandUpdateTime == 0 )
        mLastBrandUpdateTime = [SharedData getUpdatedTime];
    
    NSString *urlString = [NSString stringWithFormat:@"%@?task=getupdatedata&email=%@&last_date=%d", LOCAL_SERVER_URL, EMAIL, mLastBrandUpdateTime];
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:urlString]];
    
    [request setRequestMethod:@"GET"];
	[request setDidFinishSelector:@selector(requestGetUpdateBrandsDidFinish:)];
	[request setDidFailSelector:@selector(requestGetUpdateBrandsDidFail:)];
    [request setDelegate:self];
    [request setTimeOutSeconds:60];
    
    SharedData *sharedData = [SharedData sharedData];
    
    [sharedData.mOperationQueue addOperation:request];
}

- (void) requestGetEvent : (NSString *) email
{
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate showFirstLoadingView:appDelegate.objStartUp.view];
    
    NSString *urlString = [NSString stringWithFormat:@"%@?task=getallevents&email=%@", LOCAL_SERVER_URL, EMAIL];
    
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:urlString]];
    
    [request setRequestMethod:@"GET"];
	[request setDidFinishSelector:@selector(requestGetEventsDidFinish:)];
	[request setDidFailSelector:@selector(requestGetEventsDidFail:)];
    [request setDelegate:self];
    [request setTimeOutSeconds:60];
    
    SharedData *sharedData = [SharedData sharedData];
    
    [sharedData.mOperationQueue addOperation:request];
}

- (void) requestGetUpdateEvent : (NSString *) email
{
    if ( mLastEventUpdateTime == 0 )
        mLastEventUpdateTime = [SharedData getEventUpdatedTime];
    
    NSString *urlString = [NSString stringWithFormat:@"%@?task=getupdateevents&email=%@&last_date=%d", LOCAL_SERVER_URL, EMAIL, mLastEventUpdateTime];
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:urlString]];
    
    [request setRequestMethod:@"GET"];
	[request setDidFinishSelector:@selector(requestGetUpdateEventDidFinish:)];
	[request setDidFailSelector:@selector(requestGetUpdateEventDidFail:)];
    [request setDelegate:self];
    [request setTimeOutSeconds:60];
    
    SharedData *sharedData = [SharedData sharedData];
    
    [sharedData.mOperationQueue addOperation:request];
}

- (void) requestGetNotification : (NSString *) email
{
    mIsRequestingNotification = YES;
    
    NSString *urlString = [NSString stringWithFormat:@"%@?task=getsentnotify&email=%@", LOCAL_SERVER_URL, EMAIL];
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:urlString]];
    
    [request setRequestMethod:@"GET"];
	[request setDidFinishSelector:@selector(requestGetNotificationDidFinish:)];
	[request setDidFailSelector:@selector(requestGetNotificationDidFail:)];
    [request setDelegate:self];
    [request setTimeOutSeconds:60];
    
    SharedData *sharedData = [SharedData sharedData];
    
    [sharedData.mOperationQueue addOperation:request];
}

+ (void) parseCigarData
{
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *) [[UIApplication sharedApplication] delegate];
    NSMutableArray *cigarDataArray = [appDelegate.mDatabaseManager getBrandList];
    
    SBJsonParser *jsonParser = [SBJsonParser new];
    
    id brandObject;
    
    for ( int i = 0; i < [cigarDataArray count]; i ++ ) {
        CigarDatabaseData *data = [cigarDataArray objectAtIndex:i];
        
        brandObject = [jsonParser objectWithString:data.mBrandData];
        
        if ( [[brandObject objectForKey:@"bdf"] intValue] == 1 ) {
            [appDelegate.mDatabaseManager deleteBrand:[[brandObject objectForKey:@"id"] intValue]];
            continue;
        }
        
        NSEnumerator *typesEnumerator = [[brandObject objectForKey:@"types"] objectEnumerator];
        
        id type;
        
        while ( ( type = [typesEnumerator nextObject] ) ) {
            
            if ( [[type objectForKey:@"dfg"] intValue] == 0 ) {

                Cigar *cigar = [[Cigar alloc] init];
                cigar.brandId = [type objectForKey:@"tid"];
                
                cigar.brand = [brandObject objectForKey:@"brand"];
                
                NSMutableArray *addArray;
                NSMutableDictionary *appDelBrandsArrays = [appDelegate cigarBrandArrays];
                if([appDelBrandsArrays objectForKey:cigar.brand] == nil){
                    addArray = [[NSMutableArray alloc] init];
                    [appDelBrandsArrays setObject:addArray forKey:cigar.brand];
                } else {
                    addArray = [appDelBrandsArrays objectForKey:cigar.brand];
                }
                
                [addArray addObject:cigar];
                
                cigar.pictureURL = [brandObject objectForKey:@"url"];
                cigar.strength = [brandObject objectForKey:@"strength"];
                cigar.wrapper = [brandObject objectForKey:@"wrap"];
                cigar.generalInfo = [brandObject objectForKey:@"ginfo"];
                cigar.twit = [brandObject objectForKey:@"turl"];
                
                if ( [[brandObject objectForKey:@"cuban"] isEqualToString:@"1"] )
                    cigar.cuban = @"true";
                else
                    cigar.cuban = @"false";
                
                
                cigar.ring = [type objectForKey:@"ri"];
                cigar.type = [type objectForKey:@"ty"];
                cigar.length = [type objectForKey:@"lt"];
                
                if ( [[type objectForKey:@"pr"] isEqualToString:@"0"] )
                    cigar.price = @"N/A";
                else
                    cigar.price = [type objectForKey:@"pr"];
                
                
                cigar.ring = [type objectForKey:@"ri"];
                cigar.boxprice = [type objectForKey:@"bp"];
                cigar.newCigar = [type objectForKey:@"nc"];
                cigar.country = [brandObject objectForKey:@"country"];
                
                if ( ![[brandObject objectForKey:@"rn1"] isEqualToString:@""] && ![[brandObject objectForKey:@"rl1"] isEqualToString:@""] ) {
                    [cigar.reviews addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[brandObject objectForKey:@"rl1"], [brandObject objectForKey:@"rn1"], nil]];
                }
                
                if ( ![[brandObject objectForKey:@"rn2"] isEqualToString:@""] && ![[brandObject objectForKey:@"rl2"] isEqualToString:@""] ) {
                    [cigar.reviews addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[brandObject objectForKey:@"rl2"], [brandObject objectForKey:@"rn2"], nil]];
                }
                
                if ( ![[brandObject objectForKey:@"rn3"] isEqualToString:@""] && ![[brandObject objectForKey:@"rl3"] isEqualToString:@""] ) {
                    [cigar.reviews addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[brandObject objectForKey:@"rl3"], [brandObject objectForKey:@"rn3"], nil]];
                }
                
                cigar.isFeaturedCigar = [[type objectForKey:@"fc"] intValue];
                cigar.isSpecial = [[type objectForKey:@"sp"] intValue];
                cigar.specialStr = [type objectForKey:@"spc"];
                cigar.isStaffFavorite = [[type objectForKey:@"sf"] intValue];
                cigar.staffFavoriteStr = [type objectForKey:@"sfc"];
                cigar.isOutOfStock = [[type objectForKey:@"out"] intValue];
                cigar.isDeleted = [[type objectForKey:@"dfg"] intValue];
                cigar.isMyCigar = [[type objectForKey:@"my"] intValue];
                
                
                int topten = [[type objectForKey:@"t10"] intValue];
                
                if ( cigar.isMyCigar == 1 && topten == 1 ) {
                    
                    NSMutableDictionary *dict;
                    
                    
                    dict = [[appDelegate topTenDictionary] objectForKey:@"overall"];
                    
                    if ( [[type objectForKey:@"o"] intValue] != 0 )
                        [dict setObject:cigar forKey:[type objectForKey:@"o"]];
                    
                    dict = [[appDelegate topTenDictionary] objectForKey:@"mild"];
                    
                    if ( [[type objectForKey:@"m"] intValue] != 0 )
                        [dict setObject:cigar forKey:[type objectForKey:@"m"]];
                    
                    dict = [[appDelegate topTenDictionary] objectForKey:@"medium"];
                    
                    if ( [[type objectForKey:@"d"] intValue] != 0 )
                        [dict setObject:cigar forKey:[type objectForKey:@"d"]];
                    
                    dict = [[appDelegate topTenDictionary] objectForKey:@"full"];
                    
                    if ( [[type objectForKey:@"f"] intValue] != 0 )
                        [dict setObject:cigar forKey:[type objectForKey:@"f"]];
                    
                    dict = [[appDelegate topTenDictionary] objectForKey:@"economy"];
                    
                    if ( [[type objectForKey:@"e"] intValue] != 0 )
                        [dict setObject:cigar forKey:[type objectForKey:@"e"]];
                    
                    
                }
                
                if ( cigar.isMyCigar == 1 && [cigar.newCigar isEqualToString:@"1"] ) {
                    NSMutableArray *cigars = [appDelegate newCigars];
                    [cigars addObject:cigar];
                }
                
                [cigar release];
                
            }
            
        }
        
    }
    
    [[appDelegate defaultImageView] setHidden:YES];
    
    [appDelegate hideLoadingView];
}

- (void) requestGetUpdateBrandsDidFinish : (ASIHTTPRequest *) request
{
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NSString *resStr = [request responseString];
    
    if (resStr &&  resStr != nil ) {
        
        SBJsonWriter *jsonWritter = [SBJsonWriter new];
        SBJsonParser *jsonParser = [SBJsonParser new];
        id brandObject = [jsonParser objectWithString:resStr];
        
        NSDictionary *resultDictionary = [brandObject objectForKey:@"results"];
        
        if ( [resultDictionary objectForKey:@"lid"] != [NSNull null] ) {
            mLastCid = [[resultDictionary objectForKey:@"lid"
                         ] intValue];
        }
        
        [SharedData saveUpdatedTime:[[resultDictionary objectForKey:@"tm"] doubleValue]];
        
        NSEnumerator *brandObjectEnumberator = [[resultDictionary objectForKey:@"list"] objectEnumerator];
        
        id brand;
        
        NSInteger deleted = 0;
        NSInteger typeCount = 0;
        NSInteger count = 0;
        NSString *brandId = @"";

        
        while ( (brand = [brandObjectEnumberator nextObject]) ) {
            
            count ++;
            
            brandId = [brand objectForKey:@"id"];
            deleted = [[brand objectForKey:@"bdf"] intValue];
            
            
            if ( deleted == 1 ) {
                [appDelegate.mDatabaseManager deleteBrand:[brandId intValue]];
                continue;
            }
            
            NSEnumerator *typesEnumerator = [[brand objectForKey:@"types"] objectEnumerator];
            
            typeCount = [[typesEnumerator allObjects] count];
            
            if ( typeCount == 0 ) {
                [appDelegate.mDatabaseManager deleteBrand:[brandId intValue]];
                continue;
            }
            
            if ( [appDelegate.mDatabaseManager isExistingBrand:[brandId intValue]] ) {
                [appDelegate.mDatabaseManager updateBrand:[brandId intValue]:[jsonWritter stringWithObject:brand]];
            } else {
                [appDelegate.mDatabaseManager insertBrand:[brandId intValue] :[jsonWritter stringWithObject:brand]];
            }
            
        }
        
        [jsonParser release];
        [jsonWritter release];
        
        [CigarBossOperation parseCigarData];
        
        [[appDelegate defaultImageView] setHidden:YES];
        [appDelegate hideLoadingView];
        [appDelegate.mCategoryListViewController showDetailView:0];
        
        [self requestGetUpdateEvent:@""];
    }
}

- (void) requestGetUpdateBrandsDidFail : (ASIHTTPRequest *) request
{
    NSString *resStr = [request responseString];
    NSLog(@"error message = %@", resStr);
    
    [CigarBossOperation parseCigarData];
    
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];

    [[appDelegate defaultImageView] setHidden:YES];
    [appDelegate hideLoadingView];
    [appDelegate.mCategoryListViewController showDetailView:0];
}

- (void) requestGetBrandsDidFinish : (ASIHTTPRequest *) request
{
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NSString *resStr = [request responseString];
    
    if (resStr &&  resStr != nil ) {
        
        SBJsonWriter *jsonWritter = [SBJsonWriter new];
        SBJsonParser *jsonParser = [SBJsonParser new];
        id brandObject = [jsonParser objectWithString:resStr];
        
        NSDictionary *resultDictionary = [brandObject objectForKey:@"results"];
        
        if ( [resultDictionary objectForKey:@"lid"] != [NSNull null] ) {
            mLastCid = [[resultDictionary objectForKey:@"lid"
                         ] intValue];
        }
        
        NSEnumerator *brandObjectEnumberator = [[resultDictionary objectForKey:@"list"] objectEnumerator];
        
        id brand;
        
        NSInteger count = 0;
        NSInteger typeCount = 0;
        NSInteger deletedCount = 0;
        
        while ( (brand = [brandObjectEnumberator nextObject]) ) {
            
            count ++;
            
            if ( [[brand objectForKey:@"bdf"] intValue] == 1 )
                continue;
            
            NSEnumerator *typesEnumerator = [[brand objectForKey:@"types"] objectEnumerator];
            
            deletedCount = 0;
            typeCount = 0;
            
            id type;
            
            while ( (type = [typesEnumerator nextObject] ) ) {
                
                typeCount ++;
                
                if ( [[type objectForKey:@"dfg"] intValue] == 1 ) {
                    deletedCount ++;
                } else {

                    Cigar *cigar = [[Cigar alloc] init];
                    
                    cigar.brandId = [type objectForKey:@"tid"];
                    cigar.brand = [brand objectForKey:@"brand"];
                    
                    NSMutableArray *addArray;
                    NSMutableDictionary *appDelBrandsArrays = [appDelegate cigarBrandArrays];
                    if([appDelBrandsArrays objectForKey:cigar.brand] == nil){
                        addArray = [[NSMutableArray alloc] init];
                        [appDelBrandsArrays setObject:addArray forKey:cigar.brand];
                    } else {
                        addArray = [appDelBrandsArrays objectForKey:cigar.brand];
                    }
                    
                    [addArray addObject:cigar];
                    
                    cigar.pictureURL = [brand objectForKey:@"url"];
                    cigar.strength = [brand objectForKey:@"strength"];
                    cigar.wrapper = [brand objectForKey:@"wrap"];
                    cigar.generalInfo = [brand objectForKey:@"ginfo"];
                    cigar.twit = [brand objectForKey:@"turl"];
                    cigar.country = [brand objectForKey:@"country"];
                    cigar.cuban = @"false";
                    
                    
                    cigar.ring = [type objectForKey:@"ri"];
                    cigar.type = [type objectForKey:@"ty"];
                    cigar.length = [type objectForKey:@"lt"];
                    cigar.price = [type objectForKey:@"pr"];
                    cigar.ring = [type objectForKey:@"ri"];
                    cigar.boxprice = [type objectForKey:@"bp"];
                    cigar.newCigar = [type objectForKey:@"nc"];
                    
                    if ( ![[brand objectForKey:@"rn1"] isEqualToString:@""] && ![[brand objectForKey:@"rl1"] isEqualToString:@""] ) {
                        [cigar.reviews addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[brand objectForKey:@"rl1"], [brand objectForKey:@"rn1"], nil]];
                    }
                    
                    if ( ![[brand objectForKey:@"rn2"] isEqualToString:@""] && ![[brand objectForKey:@"rl2"] isEqualToString:@""] ) {
                        [cigar.reviews addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[brand objectForKey:@"rl2"], [brand objectForKey:@"rn2"], nil]];
                    }
                    
                    if ( ![[brand objectForKey:@"rn3"] isEqualToString:@""] && ![[brand objectForKey:@"rl3"] isEqualToString:@""] ) {
                        [cigar.reviews addObject:[[NSDictionary alloc] initWithObjectsAndKeys:[brand objectForKey:@"rl3"], [brand objectForKey:@"rn3"], nil]];
                    }
                    
                    cigar.isFeaturedCigar = [[type objectForKey:@"fc"] intValue];
                    cigar.isSpecial = [[type objectForKey:@"sp"] intValue];
                    cigar.specialStr = [type objectForKey:@"spc"];
                    cigar.isStaffFavorite = [[type objectForKey:@"sf"] intValue];
                    cigar.staffFavoriteStr = [type objectForKey:@"sfc"];
                    cigar.isOutOfStock = [[type objectForKey:@"out"] intValue];
                    cigar.isDeleted = [[type objectForKey:@"dfg"] intValue];
                    cigar.isMyCigar = [[type objectForKey:@"my"] intValue];
                    
                    int topten = [[type objectForKey:@"t10"] intValue];
                    
                    if ( cigar.isMyCigar == 1 && topten == 1 ) {
                        
                        NSMutableDictionary *dict;
                        
                        
                        dict = [[appDelegate topTenDictionary] objectForKey:@"overall"];
                        
                        if ( [[type objectForKey:@"o"] intValue] != 0 )
                            [dict setObject:cigar forKey:[type objectForKey:@"o"]];
                        
                        dict = [[appDelegate topTenDictionary] objectForKey:@"mild"];
                        
                        if ( [[type objectForKey:@"m"] intValue] != 0 )
                            [dict setObject:cigar forKey:[type objectForKey:@"m"]];
                        
                        dict = [[appDelegate topTenDictionary] objectForKey:@"medium"];
                        
                        if ( [[type objectForKey:@"d"] intValue] != 0 )
                            [dict setObject:cigar forKey:[type objectForKey:@"d"]];
                        
                        dict = [[appDelegate topTenDictionary] objectForKey:@"full"];
                        
                        if ( [[type objectForKey:@"f"] intValue] != 0 )
                            [dict setObject:cigar forKey:[type objectForKey:@"f"]];
                        
                        dict = [[appDelegate topTenDictionary] objectForKey:@"economy"];
                        
                        if ( [[type objectForKey:@"e"] intValue] != 0 )
                            [dict setObject:cigar forKey:[type objectForKey:@"e"]];
                        
                    }
                    
                    if ( cigar.isMyCigar == 1 && [cigar.newCigar isEqualToString:@"1"] ) {
                        NSMutableArray *cigars = [appDelegate newCigars];
                        [cigars addObject:cigar];
                    }
                    
                    [cigar release];
                    
                }
                
            }
            
            if ( typeCount > deletedCount ) {
                [appDelegate.mDatabaseManager insertBrand:[[brand objectForKey:@"id"] intValue] :[jsonWritter stringWithObject:brand]];
            }
        }
        
        [jsonParser release];
        [jsonWritter release];
        
        [SharedData saveUpdatedTime:[[resultDictionary objectForKey:@"tm"] doubleValue]];
        
        if ( count == 0 ) {
            [self requestGetEvent:@""];
        } else {
            [self requestGetBrands:mLastCid];
        }
    }
}

- (void) requestGetBrandsDidFail : (ASIHTTPRequest *) request
{
    NSLog(@"error = %@", [[request
                           error] description]);
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *) [[UIApplication sharedApplication] delegate];
    [appDelegate showAlertWithTitle:@"Cigar Boss" message:@"Network Error. Please retry later."];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    [defaults setBool:NO forKey:@"UseWebService"];

    [[appDelegate defaultImageView] setHidden:YES];
    [appDelegate hideLoadingView];
    [appDelegate.mCategoryListViewController showDetailView:0];
}

- (void) requestGetEventsDidFinish : (ASIHTTPRequest *) request
{
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    SharedData *sharedData = [SharedData sharedData];
    
    NSString *resStr = [request responseString];
    
    if (resStr &&  resStr != nil ) {
        
        SBJsonParser *jsonParser = [SBJsonParser new];
        id eventObject = [jsonParser objectWithString:resStr];
        
        NSDictionary *resultDictionary = [eventObject objectForKey:@"results"];
        
        NSEnumerator *eventObjectEnumberator = [[resultDictionary objectForKey:@"list"] objectEnumerator];
        
        id event;
        
        while ( (event = [eventObjectEnumberator nextObject]) ) {
            
            EventData *eventData = [[EventData alloc] init];
            
            eventData.mEventId = [[event objectForKey:@"id"] intValue];
            eventData.mTitle = [event objectForKey:@"title"];
            eventData.mDate = [event objectForKey:@"date"];
            eventData.mFrom = [event objectForKey:@"from"];
            eventData.mTo = [event objectForKey:@"to"];
            eventData.mDescription = [event objectForKey:@"desc"];
            
            [sharedData.mEventsArray addObject:eventData];
            [eventData release];
            
            [appDelegate.mDatabaseManager insertEvent:eventData.mEventId :eventData];
        }
        
        [jsonParser release];
        
        [SharedData saveEventUpdatedTime:[[resultDictionary objectForKey:@"tm"] doubleValue]];
        
        CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
        
        [[appDelegate defaultImageView] setHidden:YES];
        [appDelegate hideLoadingView];
        [appDelegate.mCategoryListViewController showDetailView:0];
    }
    
    [self requestGetNotification:EMAIL];
}

- (void) requestGetEventsDidFail : (ASIHTTPRequest *) request
{
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [[appDelegate defaultImageView] setHidden:YES];
    [appDelegate hideLoadingView];
    [appDelegate.mCategoryListViewController showDetailView:0];
}

- (void) requestGetUpdateEventDidFinish : (ASIHTTPRequest *) request
{
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NSString *resStr = [request responseString];
    
    if (resStr &&  resStr != nil ) {
        
        SBJsonParser *jsonParser = [SBJsonParser new];
        id eventObject = [jsonParser objectWithString:resStr];
        
        NSDictionary *resultDictionary = [eventObject objectForKey:@"results"];
        
        NSEnumerator *eventObjectEnumberator = [[resultDictionary objectForKey:@"list"] objectEnumerator];
        
        id event;
        
        while ( ( event = [eventObjectEnumberator nextObject]) ) {
            
            EventData *eventData = [[EventData alloc] init];
            
            eventData.mEventId = [[event objectForKey:@"id"] intValue];
            eventData.mTitle = [event objectForKey:@"title"];
            eventData.mDate = [event objectForKey:@"date"];
            eventData.mFrom = [event objectForKey:@"from"];
            eventData.mTo = [event objectForKey:@"to"];
            eventData.mDescription = [event objectForKey:@"desc"];
            
            if ( [appDelegate.mDatabaseManager isExistingEvent:eventData.mEventId] )
                [appDelegate.mDatabaseManager updateEvent:eventData.mEventId :eventData];
            else
                [appDelegate.mDatabaseManager insertEvent:eventData.mEventId :eventData];
            
            [eventData release];
        }
        
        [jsonParser release];
        
        [SharedData saveEventUpdatedTime:[[resultDictionary objectForKey:@"tm"] doubleValue]];
        
        [self requestGetNotification:EMAIL];
    }
}

- (void) requestGetUpdateEventDidFail : (ASIHTTPRequest *) request
{
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [[appDelegate defaultImageView] setHidden:YES];
    [appDelegate hideLoadingView];
    [appDelegate.mCategoryListViewController showDetailView:0];
}

- (void) requestGetNotificationDidFinish : (ASIHTTPRequest *) request
{
    mIsRequestingNotification = NO;
    
    CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NSString *resStr = [request responseString];
    
    if (resStr &&  resStr != nil ) {
        
        [appDelegate.mDatabaseManager deleteNotifys];
        
        SBJsonParser *jsonParser = [SBJsonParser new];
        id eventObject = [jsonParser objectWithString:resStr];
        
        NSEnumerator *eventObjectEnumberator = [[eventObject objectForKey:@"results"] objectEnumerator];

        id event;
        
        while ( ( event = [eventObjectEnumberator nextObject]) ) {
            
            NotifyData *notifyData = [[NotifyData alloc] init];
            
            notifyData.mNotifyId = [[event objectForKey:@"eid"] intValue];
            notifyData.mNotifyMsg = [event objectForKey:@"msg"];
            notifyData.mNotifyDateStr = [event objectForKey:@"sdt"];
            
            [appDelegate.mDatabaseManager insertNotify:notifyData.mNotifyId :notifyData];
            
            [notifyData release];
        }
        
        [jsonParser release];

        if ( appDelegate.pushReceived == YES ) {
            
            [appDelegate.mCategoryListViewController showDetailView:8];
            appDelegate.pushReceived = NO;
        }
    }

}

- (void) requestGetNotificationDidFail : (ASIHTTPRequest *) request
{
    mIsRequestingNotification = NO;    
}

@end
