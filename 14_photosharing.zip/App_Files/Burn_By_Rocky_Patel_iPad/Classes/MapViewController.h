//
//  MapViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
#import "GoogleLocalConnection.h"
#import "CigarBossAppDelegate.h"
@interface MapViewController : UIViewController <UISearchBarDelegate,UISearchDisplayDelegate> {

	IBOutlet MKMapView *mapView;
	NSMutableData *data;
	NSMutableDictionary *news;
	GoogleLocalConnection *googleLocalConnection;
	NSArray *someStuff;
	
	CigarBossAppDelegate *appDelegate;
	
	BOOL foundLocation;
    CLLocationCoordinate2D lastNonPreferredStoreCoordinate;
    NSString *lastNonPreferredStoreNumber;
    NSMutableArray *annotationsForRemoval;
    
    IBOutlet UISearchBar *searchBar;
}

- (IBAction)segControl:(UISegmentedControl *)sender;
- (IBAction)findShops;

@end
