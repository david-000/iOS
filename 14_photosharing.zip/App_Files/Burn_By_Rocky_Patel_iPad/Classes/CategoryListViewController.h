//
//  CategoryListViewController.h
//  CigarBoss_PRO
//
//  Created by System Administrator on 5/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <EventKit/EventKit.h>
#import <EventKitUI/EKEventEditViewController.h>

#import "KalViewController.h"

@protocol SubstitutableDetailViewController
- (void)showRootPopoverButtonItem:(UIBarButtonItem *)barButtonItem;
- (void)invalidateRootPopoverButtonItem:(UIBarButtonItem *)barButtonItem;
@end

@interface CategoryListViewController : UIViewController <UITabBarDelegate, MFMailComposeViewControllerDelegate, UITableViewDelegate, EKEventEditViewDelegate>
{
    UISplitViewController            *mSplitViewController;
    UIPopoverController              *mPopOverVc;    
    UIBarButtonItem                  *mRootPopOverButton;
    
    IBOutlet UITableView             *mCaqtegoryTableView;
    IBOutlet UITabBar                *mTabBar;
    IBOutlet UITabBarItem            *mHomeTabBarItem;
    IBOutlet UITabBarItem            *mBrandsTabBarItem;
    IBOutlet UITabBarItem            *mFilterTabBarItem;
    IBOutlet UITabBarItem            *mHumidorTabBarItem;
    IBOutlet UITabBarItem            *mLocalShopTabBarItem;
    IBOutlet UINavigationBar         *mNavigationBar;
    
    NSIndexPath                      *mSelectedIndexPath;
    NSIndexPath                      *mSelectedEventIndexPath;
    NSInteger                        mSelectedTabbarIndex;
    
    KalViewController               *mKalViewController;
}

@property (nonatomic, assign) IBOutlet  UISplitViewController   *mSplitVc;
@property (nonatomic, retain)           UIPopoverController     *mPopOverVc;
@property (nonatomic, retain)           UIBarButtonItem         *mRootPopOverButton;
@property (nonatomic, retain)           NSIndexPath             *mSelectedIndexPath;
@property (nonatomic, retain)           NSIndexPath             *mSelectedEventIndexPath;

- (void)showDetailView:(NSInteger) selectedIndex;


@end
