//
//  RateStarView.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Cigar.h"


@interface RateStarView : UIView {
	NSMutableArray *stars;
	int rating;
	Cigar *cigar;
	BOOL forShops;
	NSDictionary *shop;
    int test;
}
@property (nonatomic,readwrite) int test;
@property (nonatomic,assign) int rating;
@property (nonatomic, assign) Cigar *cigar;
@property (nonatomic, assign) BOOL forShops
;
@property (nonatomic, assign) NSDictionary *shop;

@end
