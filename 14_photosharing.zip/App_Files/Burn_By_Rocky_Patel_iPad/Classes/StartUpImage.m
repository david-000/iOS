//
//  StartUpImage.m
//  CigarBoss
//
//  Created by Chintan on 14/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "StartUpImage.h"
#import "CigarBossAppDelegate.h"

@implementation StartUpImage
@synthesize imgstartUp;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

-(IBAction)LeftArrowClick{
    
//    NSLog(@"Left arrow clicked");
        imageCount--;
    if(imageCount == 1)
    {
        btnClose.hidden = FALSE;
        btnfinish.hidden = TRUE;
        btnLeft.hidden = TRUE;
        btnRight.hidden  = FALSE;
    }

    if (imageCount == 0) {
        imageCount = 7;
    }
    if(imageCount != 1 )
    {
        btnRight.hidden = FALSE;
        btnfinish.hidden = TRUE;
    }
        imgstartUp.image = [UIImage imageNamed:[NSString stringWithFormat:@"%d.png",imageCount]];
    lblinfo.text = [NSString stringWithFormat:@"%d of 7",imageCount];
    
}
-(IBAction)OnFinishClick
{
		if ( FULLVERSION == 0 )
			[AppDelegate showAdView];
    	
     self.view.hidden = TRUE;
}
-(IBAction)rightArrowClick{
    
//    NSLog(@"right arrow clicked");    
            imageCount++;
    if (imageCount == 8) {

        imageCount =1;
    }
    if(imageCount == 7)
    {
        
        btnfinish.hidden = FALSE;
        btnRight.hidden = TRUE;
    }
    if(imageCount != 1 )
    {
        btnLeft.hidden = FALSE;
        btnClose.hidden = TRUE;
    }
        imgstartUp.image = [UIImage imageNamed:[NSString stringWithFormat:@"%d.png",imageCount]];
        lblinfo.text = [NSString stringWithFormat:@"%d of 7",imageCount];
    
}
-(IBAction)OncloseClick{
    
    if ( FULLVERSION == 0 )
    	[AppDelegate showAdView];
    	
    self.view.hidden = TRUE;
    
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [AppDelegate hideAdView];
    imageCount = 1;
    [self.view setFrame:CGRectMake(0, 0, 1024, 748)];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
