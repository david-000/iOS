//
//  MapViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MapViewController.h"
#import "JSON.h"
#import "GoogleLocalObject.h"
#import "GTMNSString+URLArguments.h"
#import "CustomCigarPinObject.h"
#import "StoreViewController.h"
#import "CigarBossAppDelegate.h"

CigarBossAppDelegate *appDelegate;
@implementation MapViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	mapView.delegate = self;
	appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
	someStuff = [appDelegate preferredStores];
    //[appDelegate hideAdView];
    
    searchBar.frame = CGRectMake(0, 0, 703, 44);
    //searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 44, 320, 44)];
    
    //[self.view addSubview:searchBar];
    
	if([someStuff count] == 0 || !someStuff){
		[NSTimer scheduledTimerWithTimeInterval:1.24 target:self selector:@selector(tryPinsAgain) userInfo:nil repeats:NO];
	}
	for(NSDictionary *dictionary in someStuff){
		CustomCigarPinObject *newPin = [[CustomCigarPinObject alloc] init];
		newPin.title = [dictionary objectForKey:@"name"];
		newPin.subtitle = [dictionary objectForKey:@"address"];
		if(![dictionary objectForKey:@"location"]) continue;
		newPin.cigar = dictionary;
		NSString *spaceFree = [[dictionary objectForKey:@"location"] stringByReplacingOccurrencesOfString:@" " withString:@""];
		NSArray *coordinates = [spaceFree componentsSeparatedByString:@","];
		[newPin setCoordinate:CLLocationCoordinate2DMake([[coordinates objectAtIndex:0] floatValue], [[coordinates objectAtIndex:1] floatValue])];
		[mapView addAnnotation:newPin];
	}
	
	googleLocalConnection = [[GoogleLocalConnection alloc] initWithDelegate:self];
	//[googleLocalConnection getGoogleObjectsWithQuery:@"cigars" andMapRegion:[mapView region] andNumberOfResults:8 addressesOnly:YES andReferer:@"http://apartmentpostcards.com/"];
	foundLocation = NO;
	/*NSURL *url = [NSURL URLWithString:@"http://maps.google.com?q=grocery&mrt=yp&sll=37.769561,-122.412844&z=14&output=json"];
     NSURLRequest *request = [NSURLRequest requestWithURL:url];
     data = [[NSMutableData alloc] init];
     NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];*/
	mapView.showsUserLocation = YES;
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Find Shops" style:UIBarButtonItemStyleDone target:self action:@selector(findShops)];
	self.title = @"Local Shops";
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(60, 5, 130, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =self.title; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:18.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];

}

- (void)tryPinsAgain
{
	someStuff = [[[UIApplication sharedApplication] delegate] preferredStores];
	if([someStuff count] == 0 || !someStuff){
		[NSTimer scheduledTimerWithTimeInterval:1.24 target:self selector:@selector(tryPinsAgain) userInfo:nil repeats:NO];
	}
	for(NSDictionary *dictionary in someStuff){
		CustomCigarPinObject *newPin = [[CustomCigarPinObject alloc] init];
		newPin.title = [dictionary objectForKey:@"name"];
		newPin.subtitle = [dictionary objectForKey:@"address"];
		newPin.cigar = dictionary;
		if(![dictionary objectForKey:@"location"]) continue;
		NSString *spaceFree = [[dictionary objectForKey:@"location"] stringByReplacingOccurrencesOfString:@" " withString:@""];
		NSArray *coordinates = [spaceFree componentsSeparatedByString:@","];
		[newPin setCoordinate:CLLocationCoordinate2DMake([[coordinates objectAtIndex:0] floatValue], [[coordinates objectAtIndex:1] floatValue])];
		[mapView addAnnotation:newPin];
	}
}
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(closeSearch)];
    
  //  self.navigationItem.rightBarButtonItem.title = @"Done";

}
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{

}


//-(void)searchBarTextDidEndEditing:(UISearchBar *)searchBar1
//{
//    [self showAddressforSearch:searchBar1.text] ;
//    self.navigationItem.rightBarButtonItem = nil;
//	[searchBar resignFirstResponder];
//    
//    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Find Shops" style:UIBarButtonItemStyleDone target:self action:@selector(findShops)];
//    
//
//}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar1
{

    
    [self showAddressforSearch:searchBar1.text] ;
    self.navigationItem.rightBarButtonItem = nil;
	[searchBar resignFirstResponder];

    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Find Shops" style:UIBarButtonItemStyleDone target:self action:@selector(findShops)];
    searchBar.text = @"";
    
}

- (void)closeSearch
{

	self.navigationItem.rightBarButtonItem = nil;

	[searchBar resignFirstResponder];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Find Shops" style:UIBarButtonItemStyleDone target:self action:@selector(findShops)];
    
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)dat
{
	[data appendData:dat];
}

- (void)mapView:(MKMapView *)mapView didFailToLocateUserWithError:(NSError *)error
{
	UIAlertView *eView = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Couldn't find your location!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[eView show];
	[eView release];
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{
	if(![annotation isKindOfClass:[CustomCigarPinObject class]]){
        MKPinAnnotationView *annView=[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"MyPin"];
        if(![[annotation title] isEqualToString:@"Current Location"]){
            annView.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        } else {
            return nil;
        }
        annView.animatesDrop=TRUE;  
        annView.canShowCallout = YES;  
        [annView setSelected:YES];  
        //  NSLog(@"pin height: %f, pin : %f", annView.frame.size.height, annView.frame.size.width);
        annView.calloutOffset = CGPointMake(-5, 5);  
        return annView;
    }
	
	MKAnnotationView *customAnn = [mapView dequeueReusableAnnotationViewWithIdentifier:@"MyPin"];
	if(customAnn == nil){
		customAnn = [[[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"MyPin"] autorelease];
	}
	//customAnn.centerOffset = CGPointMake(7,-15);
	//customAnn.calloutOffset = CGPointMake(-8,0);
	customAnn.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
	[customAnn.rightCalloutAccessoryView addTarget:self action:@selector(showShop:) forControlEvents:UIControlEventTouchUpInside];
	//customAnn.animatesDrop = YES;
	customAnn.canShowCallout = YES;
	//customAnn.image = [UIImage imageNamed:@"PreferredStore32x76.png"];'
    UIImage *customImage = [UIImage imageNamed:@"MapIcon.png"];
    customAnn.image = customImage;
	//[customAnn addSubview:[UIImage imageNamed:@"PreferredStore32x76.png"]];
	//customAnn.pinColor = [UIColor greenColor];
	
	return customAnn;
	
	return nil;
	/*
     MKPinAnnotationView *annView=[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"MyPin"];
     annView.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
     annView.animatesDrop=TRUE;  
     annView.canShowCallout = YES;  
     [annView setSelected:YES];  
     annView.pinColor = MKPinAnnotationColorGreen;
     NSLog(@"pin height: %f, pin : %f", annView.frame.size.height, annView.frame.size.width);
     annView.calloutOffset = CGPointMake(-5, 5);  
     return annView;*/
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1){
        CLLocationCoordinate2D loc1 = lastNonPreferredStoreCoordinate;
        CLLocationCoordinate2D loc = [appDelegate userLocation];
        
        NSString *urlString = [NSString stringWithFormat:@"http://maps.google.com/maps?daddr=%f,%f2&saddr=%f,%f", loc1.latitude, loc1.longitude, loc.latitude, loc.longitude];
        [[UIApplication sharedApplication] openURL: [NSURL URLWithString: urlString]];
    } else if(buttonIndex == 2){
        NSString *phone = lastNonPreferredStoreNumber;
        NSString *temp;
        temp = phone;
        phone = [phone stringByReplacingOccurrencesOfString:@" " withString:@""];
        //[temp release];
        temp = phone;
        phone = [phone stringByReplacingOccurrencesOfString:@"(" withString:@""];
        // [temp release];
        temp = phone;
        phone = [phone stringByReplacingOccurrencesOfString:@")" withString:@""];
        // [temp release];
        temp = phone;
        phone = [phone stringByReplacingOccurrencesOfString:@"-" withString:@""];
        //[temp release];
        temp = nil;
        
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@", phone]]];
    }
}

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control
{
    if(![view.annotation isKindOfClass:[CustomCigarPinObject class]]){
        /*CLLocationCoordinate2D loc1 = view.annotation.coordinate;
         CLLocationCoordinate2D loc = [appDelegate userLocation];
         
         NSString *urlString = [NSString stringWithFormat:@"http://maps.google.com/maps?daddr=%f,%f2&saddr=%f,%f", loc1.latitude, loc1.longitude, loc.latitude, loc.longitude];
         NSLog(urlString);
         [[UIApplication sharedApplication] openURL: [NSURL URLWithString: urlString]];*/
        lastNonPreferredStoreNumber = [view.annotation phoneNumber];
        lastNonPreferredStoreCoordinate = view.annotation.coordinate;
        UIAlertView *e = [[UIAlertView alloc] initWithTitle:view.annotation.title message:[NSString stringWithFormat:@"%@\n%@", [view.annotation streetAddress], [view.annotation phoneNumber]] delegate:self cancelButtonTitle:@"Close" otherButtonTitles:@"Directions", @"Call", nil];
        [e show];
        [e release];
        return;
    }
	appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
	StoreViewController *sView = [[StoreViewController alloc] initWithNibName:@"StoreViewController" bundle:nil];
	sView.newCigar = [view.annotation cigar];
    self.navigationItem.title=@"Back";
	[self.navigationController pushViewController:sView animated:YES];
	//self.view = sView.view;
	/*[UIView beginAnimations:nil context:nil];
     [UIView setAnimationDuration:1.0];
     [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight
     forView:[appDelegate window]
     cache:YES];
     [[appDelegate window] addSubview:sView.view];
     sView.view.frame = CGRectMake(0, 20, 320, sView.view.frame.size.height);
     [UIView commitAnimations];*/
}

//==================


-(CLLocationCoordinate2D) addressLocationforSearch:(NSString *)str {
    
	NSString *urlString = [NSString stringWithFormat:@"http://maps.google.com/maps/geo?q=%@&output=csv", 
						   [str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
	NSString *locationString;// = [NSString stringWithContentsOfURL:[NSURL URLWithString:urlString]];
    locationString = [NSString stringWithContentsOfURL:[NSURL URLWithString:urlString] encoding:NSUTF8StringEncoding error:nil];
	NSArray *listItems = [locationString componentsSeparatedByString:@","];
	
	double latitude = 0.0;
	double longitude = 0.0;
    
	if([listItems count] >= 4 && [[listItems objectAtIndex:0] isEqualToString:@"200"]) {
		latitude = [[listItems objectAtIndex:2] doubleValue];
		longitude = [[listItems objectAtIndex:3] doubleValue];
	}
	else {
		latitude = 22.2836;
		longitude = 70.80;
	}
	
     
	CLLocationCoordinate2D location;
	location.latitude = latitude;
	location.longitude = longitude;
	
	return location;
}

-(void) showAddressforSearch:(NSString *)str 
{
	
	[mapView setZoomEnabled:YES];
	[mapView setScrollEnabled:YES];
	[mapView setDelegate:self];
	
	MKCoordinateRegion region;
	MKCoordinateSpan span;
	span.latitudeDelta = 0.02;
	span.longitudeDelta = 0.02;
	
	CLLocationCoordinate2D location = [self addressLocationforSearch:str];
   
       
	region.span=span;  
	region.center=location; 
    
    
    CustomCigarPinObject *newPin = [[CustomCigarPinObject alloc] init];
    newPin.title = @"";
    newPin.subtitle = @"";
   
    newPin.coordinate = region.center;
	[mapView addAnnotation:newPin];
	[mapView selectAnnotation:newPin animated:YES];
	[mapView setRegion:region animated:TRUE];
	[mapView regionThatFits:region];
 
}

//=====================

- (void)showShop:(UIButton *)sender
{	
}

- (void)viewWillAppear:(BOOL)animated
{
    appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate hideAdView];
	self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
}

- (void)viewWillDisappear:(BOOL)animated
{
		if ( FULLVERSION == 0 )
    	[appDelegate showAdView];

		self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
}

- (void)segControl:(UISegmentedControl *)sender
{
	if(sender.selectedSegmentIndex == 0) [mapView setMapType:MKMapTypeStandard];
	if(sender.selectedSegmentIndex == 1) [mapView setMapType:MKMapTypeSatellite];
	if(sender.selectedSegmentIndex == 2) [mapView setMapType:MKMapTypeHybrid];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	NSString *final = [[NSString alloc] initWithBytes:(const char *)[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
	
	if(final == nil) NSLog(@"mm");
	
	SBJSON *parser = [[SBJSON alloc] init];
	//printf((const char *)[data bytes]);
	news = [parser objectWithString:final];
	news = [news retain];
	
	[data release];
	[connection release];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	NSLog([error description]);
}

- (void) googleLocalConnection:(GoogleLocalConnection *)conn didFinishLoadingWithGoogleLocalObjects:(NSMutableArray *)objects andViewPort:(MKCoordinateRegion)region
{
    if ([objects count] == 0) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No matches found near this location" message:@"Try another place name or address (or move the map and try again)" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        [alert release];
    }
    else {
        id userAnnotation=mapView.userLocation;
        annotationsForRemoval = [[NSMutableArray alloc] init];
        for(id ann in mapView.annotations){
            if(![ann isKindOfClass:[CustomCigarPinObject class]]){
                if(![[ann title] isEqualToString:@"Current Location"]){
                    [annotationsForRemoval addObject:ann];
                }
            }
        }
        if(annotationsForRemoval){
            [mapView removeAnnotations:annotationsForRemoval];
            [annotationsForRemoval release];
        }
        [mapView addAnnotations:objects];
      
        if(userAnnotation!=nil)
			[mapView addAnnotation:userAnnotation];
        [mapView setRegion:region];
    }
    
    // s[self tryPinsAgain];
}

- (void)findShops
{
    

//        [googleLocalConnection getGoogleObjectsWithQuery:@"cigar shop, cigars, cigar, tobacco shop" andMapRegion:[mapView region] andNumberOfResults:8 addressesOnly:YES andReferer:@"http://apartmentpostcards.com/" counter:0];
    googleLocalConnection.Pagecount = 0;
    [googleLocalConnection getGoogleObjectsWithQuery:[mapView region]];
    
}

- (void)googleLocalConnection:(GoogleLocalConnection *)conn didFailWithError:(NSError *)error
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error finding place - Try again" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
    [alert show];
    [alert release];
}

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
	if(foundLocation)return;
	foundLocation = YES;
    
	[NSTimer scheduledTimerWithTimeInterval:1.8 target:self selector:@selector(zoom) userInfo:nil repeats:NO];
}

- (void)zoom
{
	MKCoordinateSpan span = MKCoordinateSpanMake(0.01, 0.5);
	MKCoordinateRegion region = MKCoordinateRegionMake(mapView.userLocation.location.coordinate, span);
	[mapView setRegion:region animated:YES];
}


 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
     return UIInterfaceOrientationIsLandscape(interfaceOrientation);
 }

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    //[appDelegate showAdView];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
