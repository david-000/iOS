//
//  CustomImagePickerController.h
//  ATEval2Go
//
//  Created by Frank Jacob on 9/20/12.
//  Copyright (c) 2012 Smarty Ears. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomImagePickerController : UIImagePickerController

@end
