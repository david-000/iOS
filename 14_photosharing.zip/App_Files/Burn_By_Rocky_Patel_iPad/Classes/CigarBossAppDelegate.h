//
//  CigarBossAppDelegate.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
#import "StartUpImage.h"
#import "CategoryListViewController.h"
#import "RootViewController.h"
#import "Mobclix.h"
#import "MobclixAds.h"
#import "CigarBossOperation.h"
#import "DatabaseManager.h"

#define tintColor [UIColor colorWithRed:0.0f/255.0f green:0.0f/255.0f blue:0.0f/255.0f alpha:1.0f]
#define ipadFrame CGRectMake(0, 0, 1024, 768)
#define iphoneFrame CGRectMake(0, 0, 320, 480)
#define loadiPhone CGRectMake(95, 230, 130, 40)
#define loadiPad CGRectMake(319, 300, 130, 40)
#define AppDelegate     ((CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate])

@class AdWhirlView;
@class Cigar;


@interface CigarBossAppDelegate : NSObject <UIApplicationDelegate, UITabBarControllerDelegate, MobclixAdViewDelegate, CLLocationManagerDelegate> {
    UIWindow *window;
    IBOutlet UISplitViewController          *mSplitViewController;
    IBOutlet UINavigationController         *mNavigationController;
    IBOutlet CategoryListViewController     *mCategoryListViewController;
    UITabBarController *tabBarController;
	NSMutableArray *ratings;
	
	NSMutableDictionary *cigarBrandArrays;
	UIImageView *defaultImageView;
	
	NSURLConnection *connection;
	NSMutableData *data;
	NSMutableArray *preferredStores;
	NSMutableArray *favoriteShops;
    NSMutableArray *newCigars;
    
    CLLocationCoordinate2D userLocation;
    
    NSString *kAdMobPublisherID;
    NSString *kAdWhirlSDKKey;
    AdWhirlView *ad;
    Cigar *COM;
    NSMutableDictionary *topTenDictionary;
    NSMutableArray *humidors;
    NSMutableArray *WishList;
    
    NSMutableArray *notes;
    
    NSMutableArray *featuredPhotos;
    StartUpImage *objStartUp;
    
    NSMutableArray *NewCigarList;
    
    UIView *loadView;
    UIView *viewBack;
    UIActivityIndicatorView *spinningWheel;
    NSMutableArray *globalDictionary;
    BOOL adStatus;
    
    RootViewController *mRootVc;
    MobclixAdView* iadBanner;
    
    CigarBossOperation *cigarBossOperation;
    DatabaseManager  *mDatabaseManager;
}

@property (nonatomic) NSInteger                    mEventId;
@property (nonatomic) BOOL                         pushReceived;
@property (nonatomic, retain) StartUpImage        *objStartUp;
@property (nonatomic, retain) CigarBossOperation *cigarBossOperation;
@property (nonatomic, retain) DatabaseManager *mDatabaseManager;
@property (nonatomic, retain) RootViewController *mRootVc;
@property (nonatomic, retain) IBOutlet UISplitViewController    *mSplitViewController;
@property (nonatomic, retain) IBOutlet UINavigationController   *mNavigationController;
@property (nonatomic, retain) IBOutlet CategoryListViewController *mCategoryListViewController;
@property (nonatomic, assign) BOOL adStatus;
@property (nonatomic, retain) NSMutableArray *globalDictionary;
@property (nonatomic, retain) NSMutableArray *newCigars;

@property (nonatomic, retain) NSMutableArray *ratings;
@property (nonatomic, retain) NSMutableArray *humidors;
@property (nonatomic, retain) NSMutableArray *WishList; 
@property (nonatomic, retain) NSMutableArray *NewCigarList;
@property (nonatomic, retain) NSMutableArray *notes;

@property (nonatomic, assign) NSMutableArray *featuredPhotos;

@property (nonatomic) CLLocationCoordinate2D userLocation;

@property (nonatomic, retain) NSMutableArray *favoriteShops;
@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UITabBarController *tabBarController;
@property (nonatomic, retain)  NSMutableDictionary *cigarBrandArrays;
@property (nonatomic, retain)  UIImageView *defaultImageView;

@property (nonatomic, retain) Cigar *COM;
@property (nonatomic, retain) NSMutableDictionary *topTenDictionary;

@property (nonatomic, retain) NSMutableArray *preferredStores;
@property (nonatomic, retain) AdWhirlView *ad;
@property (nonatomic) BOOL isCigarLoading;

- (void)toggleAdView;
- (NSString *)dataFilePathForHumidors;
- (NSString *)dataFilePathForWishList;
- (void)saveData;
- (void)addFavorite:(NSMutableArray *)cigar;
- (void)saveRatings;
- (NSString *)dataFilePathForHumidors;
- (void)saveHumidorData;
- (void)addHumidor:(NSMutableArray *)cigar;
- (void)saveHumidors;
- (NSString *)dataFilePathForWishList;
- (void)saveWishListData;
- (void)addWishList:(NSMutableArray *)cigar;
- (void)saveWishList;
- (NSMutableArray *)findCigarMatch:(Cigar *)cigar;
- (NSMutableArray *)findNotesMatch:(Cigar *)cigar;
- (NSMutableArray *)findHumidorMatch:(Cigar *)cigar;
- (NSMutableArray *)findWishlistMatch:(Cigar *)cigar;

- (NSString *)dataFilePathForMyNotes;
- (void)saveMyNotesData;
- (void)addNote:(NSMutableArray *)cigar;
- (void)saveMyNotes;

- (NSString *)dataFilePathForNewCigarList;
- (void)saveNewCigarList;
- (void)addNewCigarList:(NSMutableArray *)cigar;
- (void)saveNewCigarListData;

- (void)saveWishList;
- (NSMutableArray *)findNewCigarList:(NSString *)cigar;
- (void) showAlertWithTitle:(NSString *)title message:(NSString *)message;

-(void) showFirstLoadingView : (UIView *) parentView;
-(void) showLoadingView : (UIView *) parentView;
-(void) hideLoadingView;
- (void)hideAdView;
- (void)showAdView;
- (void)createAdBanner;
+ (BOOL)adSkipBackUpAttributeToItemAtURL : (NSString *) path;

@end
