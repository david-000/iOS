//
//  SearchResultsObject.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SearchResultsObject.h"
#import "CigarsViewController.h"


@implementation SearchResultsObject

@synthesize results, parent;
@synthesize mShowType;

- (int)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
	return [results count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {	
	return @"Search Results";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"StaticCell"];
	
	if(cell == nil){
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"StaticCell"] autorelease];
	}
	
	cell.textLabel.text = [results objectAtIndex:indexPath.row];
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	CigarsViewController *c = [[CigarsViewController alloc] initWithNibName:@"CigarsViewController" bundle:nil];
	c.brand = [results objectAtIndex:indexPath.row];
    c.mShowType = mShowType;
//    self.navigationItem.title=@"Back";
	[[parent navigationController] pushViewController:c animated:YES];
}


@end
