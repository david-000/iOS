//
//  StartUpImage.h
//  CigarBoss
//
//  Created by Chintan on 14/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StartUpImage : UIViewController
{
    IBOutlet UIImageView *imgstartUp;
    IBOutlet UIButton *btnLeft,*btnRight,*btnClose,*btnfinish;
    IBOutlet UILabel *lblinfo;
    
    int imageCount;
    
    
    IBOutlet UIView *topView;
}
@property(nonatomic,retain) UIImageView *imgstartUp;

-(IBAction)LeftArrowClick;
-(IBAction)rightArrowClick;
-(IBAction)OncloseClick;
-(IBAction)OnFinishClick;
@end
