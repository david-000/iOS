//
//  StoreViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Cigar.h"
#import "AsyncImageView.h"
#import "CigarBossAppDelegate.h"

@class RateStarView;

@interface StoreViewController : UIViewController {
	IBOutlet UILabel *typeLabel;
	IBOutlet UILabel *brandLabel;
	IBOutlet UILabel *cigarLabel;
	IBOutlet UILabel *sizeLabel;
	IBOutlet UILabel *lengthLabel;
	IBOutlet UILabel *ringLabel;
	IBOutlet UILabel *countryLabel;
	IBOutlet UILabel *colorLabel;
	IBOutlet UILabel *originLabel;
	IBOutlet UILabel *strengthLabel;
	IBOutlet UILabel *descriptionLabel;
    CigarBossAppDelegate *appDelegate;
    IBOutlet UILabel *tLabel;
	IBOutlet UIScrollView *scrollView;
	Cigar *cigar;
	NSDictionary *newCigar;
	NSMutableArray *photos;
    
	IBOutlet RateStarView *rView;
    
    IBOutlet UILabel *descLabel;
	
	IBOutlet AsyncImageView *photo1, *photo2, *photo3, *photo4;
	
	IBOutlet AsyncImageView *imageView;
	IBOutlet UIView *ratingsView;
}
- (IBAction)sendEMail;
- (IBAction)call;
- (IBAction)web;
- (IBAction)directions;


@property (nonatomic, assign) Cigar *cigar;
@property (nonatomic, retain) NSDictionary *newCigar;

-(NSString *)applicationDocumentsDirectory ;
@end
