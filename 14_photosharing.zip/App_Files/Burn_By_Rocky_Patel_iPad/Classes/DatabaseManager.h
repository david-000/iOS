//
//  DatabaseManager.h
//  Jewel
//
//  Created by System Administrator on 6/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <sqlite3.h>
#import <pthread.h>
#import "EventData.h"
#import "NotifyData.h"

@interface DatabaseManager : NSObject {
	sqlite3 *mDatabase;
	pthread_mutex_t	mMutex;
}


- (BOOL) initConnect;
- (BOOL) connect;
- (void) disConnect;
- (void) dbconn_lock;
- (void) dbconn_unlock;
- (BOOL) createDBAndTables;

- (BOOL) isExistingEvent:(NSInteger)eventId;
- (BOOL) insertEvent : (NSInteger) event_id : (EventData *) event;
- (BOOL) deleteEvent : (NSInteger) event_id;
- (BOOL) updateEvent:(NSInteger)event_id :(EventData *)event;

- (BOOL) isExistingBrand : (NSInteger ) brandId;
- (BOOL) insertBrand : (NSInteger) brand_id : (NSString *) brand;
- (BOOL) updateBrand : (NSInteger) brand_id : (NSString *) brand;

- (BOOL) isExistingNotify:(NSInteger)notifyId;
- (BOOL) insertNotify : (NSInteger) notify_id : (NotifyData *) notify;
- (BOOL) deleteNotify : (NSInteger) notify_id;
- (BOOL) updateNotify : (NSInteger) notify_id : (NotifyData *) notify;
- (BOOL) deleteNotifys;

- (NSMutableArray *) getBrandList;
- (NSMutableArray *) getNotificationList;

@end
