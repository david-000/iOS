//
//  NonCubanViewController.m
//  CigarBoss
//
//  Created by Nilesh on 04/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "NonCubanViewController.h"
#import "BrandsViewController.h"
#import "Cigar.h"
#import "CustomHighlightedCell.h"
#import "CigarBossAppDelegate.h"


@implementation NonCubanViewController

CigarBossAppDelegate *appDelegate;
@synthesize mShowType;
@synthesize arrCigarObj;

-(void)setParent:(BrandsViewController *)obj
{
    objParent = obj;
}

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    arrCuban = [[NSMutableArray alloc] init];   
	indexes = [[NSMutableDictionary alloc] init];
    //self.tableView.tableHeaderView = objParent.searchBar;
	
    //   [mainTableView setFrame:CGRectMake(0, 45, 320, 200)];
	self.tableView.backgroundColor = [UIColor clearColor];
	self.tableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
    
    [self SetTableData];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView 
{
    return [[arrdist allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
}

- (int)numberOfSectionsInTableView:(UITableView *)tableView
{	
    return [[arrdist allKeys] count];
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
    NSLog(@"section = %d count = %d", section, [[arrdist valueForKey:[[[arrdist allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section]] count]);
    
    return [[arrdist valueForKey:[[[arrdist allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section]] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //NSLog(@">>>>>>>>Table going to load");
	CustomHighlightedCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainCell"];
    
    for(UIView *tempView in [cell.contentView subviews]) {
		[tempView removeFromSuperview];
		tempView = nil;
	}
    
	if(cell == nil)
    {
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
	}
    
    
	cell.backgroundView = nil;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.contentView.backgroundColor = [UIColor clearColor];
	cell.textLabel.backgroundColor = [UIColor clearColor];
	cell.textLabel.textColor = [UIColor whiteColor];
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 6, 300, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentLeft;
    [titleLabel sizeToFit];
    cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:20];
    cell.textLabel.minimumFontSize = 10;
    cell.textLabel.adjustsFontSizeToFitWidth = YES;
    NSArray *allKeys = AllkeyIndexArray;
    NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
    NSMutableArray *arrayForThisSection = [arrdist objectForKey:rightKey];
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textLabel.text = [arrayForThisSection objectAtIndex:indexPath.row];            
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	return cell;
    
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{	
    
    return [[[arrdist allKeys] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] objectAtIndex:section];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *allKeys = keys;
    NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
    NSMutableArray *arrayForThisSection = [arrdist objectForKey:rightKey];
    [objParent moveTOCigarsViewController:[arrayForThisSection objectAtIndex:indexPath.row]];
}

-(void)SetTableData
{
    NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
    
    keys = [brandsDictionary allKeys];
    keys = [keys sortedArrayUsingSelector:@selector(compare:)];
    
    for(NSString *key in keys){
        NSString *firstLetter = [key substringToIndex:1];
        NSMutableArray *existingArray;
        
        if ((existingArray = [indexes valueForKey:firstLetter])) 
        {
            [existingArray addObject:key];
        } 
        else 
        {
            NSMutableArray *tempArray = [NSMutableArray array];
            [indexes setObject:tempArray forKey:firstLetter];
            [tempArray addObject:key];
        }
    }
    
    keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    
    for(int k = 0 ; k < [keys count] ; k++)
    {
        NSArray *arr = [indexes objectForKey:[keys objectAtIndex:k]];
        for (int j = 0; j < [arr count]; j++) {
            
            NSMutableArray *cigars = [[appDelegate cigarBrandArrays] objectForKey:[arr objectAtIndex:j]];
            for(int m = 0 ; m < [cigars count] ; m ++)
            {
                Cigar *cg  = (Cigar *)[cigars objectAtIndex:m];
                
                if ( mShowType == 1 ) {

                    if ( cg.isMyCigar == 1 )
                        [arrCuban addObject:cg];
                    
                } else {
                    if ( cg.isMyCigar == 0 )
                        [arrCuban addObject:cg];
                }
            }
        }
    }
    
    [self makeArray:arrCuban];
}

-(void)viewWillAppear:(BOOL)animated
{

}

-(void)makeArray:(NSMutableArray *)storedArray
{
    NSLog(@">>>>> MAke Array");
    arrCigarObj = [[NSMutableArray alloc]init];
    
    
    arrdist = [[NSMutableDictionary alloc] init];
    arrdist2 = [[NSMutableDictionary alloc] init];
    
    
	storedArray =(NSMutableArray *) [storedArray sortedArrayUsingSelector:@selector(compare:)];    
    
	for(int i = 0 ; i < [storedArray count]; i++){
        
 		Cigar *firstLetter = (Cigar *)[storedArray objectAtIndex:i];
        
        NSString *brnd = (NSString *)firstLetter.brand;
        [((NSMutableArray *)arrCigarObj) addObject:brnd];
        [arrCigarObj retain];
    }
    
    
    arrCigarObj = [[arrCigarObj sortedArrayUsingSelector:@selector(compare:)] mutableCopy];
    
    NSMutableArray *newArray = [[NSMutableArray alloc] init];
    NSMutableArray *existingArray = [[NSMutableArray alloc] init];
    NSMutableDictionary *First= [[NSMutableDictionary alloc] init];
    for (id item in arrCigarObj){
        if (NO == [newArray containsObject:item])
            [newArray addObject:item];
        
        if ((existingArray = [First valueForKey:item])) 
		{
			[existingArray addObject:item];
		} 
        else {
			NSMutableArray *tempArray = [NSMutableArray array];
			[First setObject:tempArray forKey:item];
			[tempArray addObject:item];
		}
    }
    
    arrCigarObj = newArray;
    
    BOOL found;
    
    // Loop through the books and create our keys
    for (NSString *book in arrCigarObj)
    {        
        NSString *c = [book  substringToIndex:1];
        
        found = NO;
        
        for (NSString *str in [arrdist allKeys])
        {
            if ([str isEqualToString:c])
            {
                found = YES;
            }
        }
        
        if (!found)
        {     
            [arrdist setValue:[[NSMutableArray alloc] init] forKey:c];
            [arrdist2 setValue:[[NSMutableArray alloc] init] forKey:book];   
        }
    }
    
    // Loop again and sort the books into their respective keys
    for (NSString *book in arrCigarObj)
    {
        [[arrdist objectForKey:[book substringToIndex:1]] addObject:book];
        [[arrdist2 objectForKey:[book substringToIndex:1]] addObject:book];
    }    
    
    // Sort each section array
    for (NSString *key in [arrdist allKeys])
    {
        [arrdist objectForKey:key];
    }    
    
    keys =(NSMutableArray *) [[[arrdist allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    
    AllkeyIndexArray = [[[arrdist allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
    
    [self.tableView reloadData];
    [self.tableView reloadSectionIndexTitles];
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (toInterfaceOrientation == UIInterfaceOrientationLandscapeRight);
}


@end
