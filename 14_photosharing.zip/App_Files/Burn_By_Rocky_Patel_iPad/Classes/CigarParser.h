//
//  CigarParser.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Cigar.h"

@interface CigarParser : NSObject<NSXMLParserDelegate> {
	BOOL shouldUseCurrentTag;
	NSMutableString *currentString;
	Cigar *currentCigar;
	BOOL onReviews;
	NSString *lastLinkName;
	
	NSURLConnection *connection;
	NSMutableData *data;
	NSString *parseLink;
}

- (void)parse;

@end
