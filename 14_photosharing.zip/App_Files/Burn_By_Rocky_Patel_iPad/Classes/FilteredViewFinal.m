//
//  FilteredViewFinal.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FilteredViewFinal.h"
#import "Cigar.h"
#import "CustomHighlightedCell.h"
#import "CigarBossAppDelegate.h"


@implementation FilteredViewFinal
@synthesize cigars;
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 420)];
	bgView.image = [UIImage imageNamed:@"Background640x734.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
}

- (int)numberOfSectionsInTableView:(UITableView *)tableView
{
    /*NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
	keys = [brandsDictionary allKeys];*/
    indexes = [[NSMutableDictionary alloc] init];
    keys = [[NSMutableArray alloc] init];
    for(Cigar *cigar in cigars){
        [keys addObject:cigar];
    }
    
    NSSortDescriptor *sortDesc = [NSSortDescriptor sortDescriptorWithKey:@"brand" ascending:YES];
	[keys sortUsingDescriptors:[NSArray arrayWithObject:sortDesc]];
	
	for(Cigar *key in keys){
		NSString *firstLetter = [key.brand substringToIndex:1];
		NSMutableArray *existingArray;
		//NSLog(firstLetter);
		// if an array already exists in the name index dictionary
		// simply add the element to it, otherwise create an array
		// and add it to the name index dictionary with the letter as the key
		if ((existingArray = [indexes valueForKey:firstLetter])) 
		{
			[existingArray addObject:key];
		} else {
			NSMutableArray *tempArray = [NSMutableArray array];
			[indexes setObject:tempArray forKey:firstLetter];
			[tempArray addObject:key];
		}
	}
    
	keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
	return [indexes count];
	//return 1;
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
	// returns the array of section titles. There is one entry for each unique character that an element begins with
	// [A,B,C,D,E,F,G,H,I,K,L,M,N,O,P,R,S,T,U,V,X,Y,Z]
	return keys;
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index {
	return index;
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
	NSArray *allKeys = keys;
	NSString *rightKey = [allKeys objectAtIndex:section];
	NSMutableArray *arrayForThisSection = [indexes objectForKey:rightKey];
	return [arrayForThisSection count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainCell"];
	
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"MainCell"] autorelease];
	}
	
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	//cell.textLabel.text = [[cigars objectAtIndex:indexPath.row] valueForKey:@"type"];
	//cell.detailTextLabel.text = [[cigars objectAtIndex:indexPath.row] valueForKey:@"brand"];
	cell.textLabel.textColor = [UIColor whiteColor];
    
    NSArray *allKeys = keys;
	NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
	NSMutableArray *arrayForThisSection = [indexes objectForKey:rightKey];
    Cigar *correctCigar = [arrayForThisSection objectAtIndex:indexPath.row];
    cell.textLabel.text = correctCigar.brand;
    cell.detailTextLabel.text = correctCigar.type;
    cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:16];
	
	return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {	
	return [keys objectAtIndex:section];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	CigarViewController *c = [[CigarViewController alloc] initWithNibName:@"CigarViewController" bundle:nil];
	NSArray *allKeys = keys;
	NSString *rightKey = [allKeys objectAtIndex:indexPath.section];
	NSMutableArray *arrayForThisSection = [indexes objectForKey:rightKey];
    Cigar *correctCigar = [arrayForThisSection objectAtIndex:indexPath.row];
    c.cigar = correctCigar;
    self.navigationItem.title=@"Back";
	[self.navigationController pushViewController:c animated:YES];
}



- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
