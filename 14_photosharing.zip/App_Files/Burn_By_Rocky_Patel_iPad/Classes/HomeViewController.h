//
//  HomeViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryListViewController.h"

@class CigarBossAppDelegate;

@interface HomeViewController : UIViewController<SubstitutableDetailViewController> {
	CigarBossAppDelegate *appDelegate;
    IBOutlet UIScrollView *scrollView;
    BOOL checkStatus;
}

- (IBAction)showBrands:(UIButton *)sender;
- (IBAction)showFilter:(UIButton *)sender;
- (IBAction)showFavori:(UIButton *)sender;
- (IBAction)showLocalS:(UIButton *)sender;
- (IBAction)showContac:(UIButton *)sender;
- (IBAction)showAboutu:(UIButton *)sender;
- (IBAction)showLast:(UIButton *)sender;

- (IBAction)OpenWikipedia:(UIButton *)sender;
- (IBAction)OpenNewCigar:(UIButton *)sender;
- (IBAction)OpenCigarOfMonth:(UIButton *)sender;
- (IBAction)OpenMyHumidor:(UIButton *)sender;
- (IBAction)OpenMyWishList:(UIButton *)sender;
- (IBAction)OpenMyNotes:(UIButton *)sender;
- (IBAction)OpenSettings:(UIButton *)sender;
- (IBAction)OpenCigarNews:(UIButton *)sender;
- (IBAction)OpenTopTen;

- (IBAction)OpenTour:(UIButton *)sender;
-(IBAction)onNewCigarView:(id)sender;

- (IBAction)onFilterBtnClick:(UIButton *)sender;
-(IBAction)openCommunity:(id)sender;
-(void)DeleteAllImages;
@property (nonatomic,assign)    BOOL checkStatus;
@end
