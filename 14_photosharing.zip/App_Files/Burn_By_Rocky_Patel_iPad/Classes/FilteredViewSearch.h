//
//  FilteredViewFinal.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CigarViewController.h"

@class CigarBossAppDelegate;

@interface FilteredViewSearch : UIViewController {
	IBOutlet UITableView *mainTableView;
	NSArray *cigars;
    
    CigarBossAppDelegate *appDelegate;
	NSMutableArray *keys;
	NSMutableDictionary *indexes;
    
    NSMutableDictionary *dictIndexes;
}

@property (nonatomic, retain) NSMutableDictionary *dictIndexes;
@property (nonatomic, assign) NSArray *cigars;

-(void)setTableData:(NSMutableArray *)arrKey from:(NSMutableDictionary *)mainIndex;


@end
