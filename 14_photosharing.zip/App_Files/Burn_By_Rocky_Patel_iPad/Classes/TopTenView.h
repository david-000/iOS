//
//  TopTenView.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryListViewController.h"

@interface TopTenView : UIViewController <SubstitutableDetailViewController> {
    IBOutlet UITableView *mainTableView;
    IBOutlet UISegmentedControl *segCont;
    NSDictionary *allTopTens;
    NSDictionary *currentTopTen;
}

- (IBAction)topTenCategoryChanged:(id)sender;

@end
