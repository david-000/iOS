//
//  CigarBossAppDelegate.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CigarBossAppDelegate.h"
#import "CigarParser.h"
#import "CigarBossOperation.h"
#import "JSON.h"
#import "GADBannerView.h"
#import "AdWhirlView.h"
#import "FlurryAnalytics.h"
#import "StartUpImage.h"
#import <QuartzCore/QuartzCore.h>
#import "HomeViewController.h"
#import "BrandsViewController.h"
#import "ChangeNewCigarViewController.h"
#include <sys/xattr.h>
#import "Kal.h"

@implementation CigarBossAppDelegate

@synthesize favoriteShops;
@synthesize window;
@synthesize userLocation;
@synthesize ratings;
@synthesize tabBarController, cigarBrandArrays, defaultImageView;
@synthesize preferredStores;
@synthesize newCigars;
@synthesize humidors,WishList;
@synthesize COM, topTenDictionary;
@synthesize notes;
@synthesize featuredPhotos;
@synthesize NewCigarList;
@synthesize globalDictionary,adStatus;
@synthesize mNavigationController;
@synthesize mSplitViewController;
@synthesize mCategoryListViewController;
@synthesize mRootVc;
@synthesize ad;
@synthesize isCigarLoading;
@synthesize cigarBossOperation;
@synthesize mDatabaseManager;
@synthesize objStartUp;
@synthesize pushReceived;
@synthesize mEventId;

#pragma mark -
#pragma mark Application lifecycle

- (void)toggleAdView
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:.3];
    if(ad.alpha == 0) ad.alpha = 1.0; else ad.alpha = 0.0;
    [UIView commitAnimations];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {  
    
    if ( [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey] == nil ) {
        
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes: UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert];
    }

    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleBlackTranslucent animated:YES];
    
    mDatabaseManager = [[DatabaseManager alloc] init];
    
    if ( [mDatabaseManager initConnect] == NO )
        NSLog(@"Database Connect failed");
    
    if ( [mDatabaseManager createDBAndTables] == NO )
        NSLog(@"Database Table Create failed");
    
    NSString *checkit = @"";
    NSUserDefaults *chekFirst = [NSUserDefaults standardUserDefaults];
    checkit = [chekFirst objectForKey:@"FirstTime"];
    if (![checkit isEqualToString:@"FirstTimeLaunch"]) {
        
    }
    
    [window setRootViewController:mSplitViewController];
    [self.mCategoryListViewController showDetailView:0];
    
    [Mobclix startWithApplicationId:@"D4401997-F773-4B01-B029-D749B9DA717E"];
    
		iadBanner = [[MobclixAdViewiPad_728x90 alloc] initWithFrame:CGRectMake(320, 658, 728, 90)];
    [iadBanner setDelegate:self];    
    [iadBanner resumeAdAutoRefresh];

    [self.mSplitViewController.view addSubview:iadBanner];

    if ( FULLVERSION == 0 ) {
        [iadBanner setHidden:NO];
    } else {
        [iadBanner setHidden:YES];
    }
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    BOOL useWebService = [defaults boolForKey:@"UseWebService"];
    
    if (![checkit isEqualToString:@"FirstTimeLaunch"] || useWebService == NO) {
        
        objStartUp = [[StartUpImage alloc] initWithNibName:@"StartUpImage" bundle:nil];
        
        [mSplitViewController.view addSubview:objStartUp.view];
        
    }

    
    NSUserDefaults *chekFirst1 = [NSUserDefaults standardUserDefaults];
    [chekFirst1 setObject:@"FirstTimeLaunch" forKey:@"FirstTime"];
    [chekFirst1 synchronize];
    

    [FlurryAnalytics startSession:@"YXH5JK62XJTJ2YXKIW7I"];
    newCigars = [[NSMutableArray alloc] init];
    CLLocationManager *locationManager2 = [[CLLocationManager alloc] init];
    [locationManager2 startUpdatingLocation];
    
    CLLocation *location = locationManager2.location;
    [FlurryAnalytics setLatitude:location.coordinate.latitude            
                       longitude:location.coordinate.longitude            
              horizontalAccuracy:location.horizontalAccuracy            
                verticalAccuracy:location.verticalAccuracy]; 
    
    globalDictionary = [[NSMutableArray alloc] init];
    
    featuredPhotos = [[NSMutableArray alloc] init];
    topTenDictionary = [[NSMutableDictionary alloc] init];
    [topTenDictionary setObject:[[NSMutableDictionary alloc] init] forKey:@"overall"];
    [topTenDictionary setObject:[[NSMutableDictionary alloc] init] forKey:@"mild"];
    [topTenDictionary setObject:[[NSMutableDictionary alloc] init] forKey:@"medium"];
    [topTenDictionary setObject:[[NSMutableDictionary alloc] init] forKey:@"full"];
    [topTenDictionary setObject:[[NSMutableDictionary alloc] init] forKey:@"economy"];    
    
    // Override point for customization after application launch.
	cigarBrandArrays = [[NSMutableDictionary alloc] init];

	ratings = [NSKeyedUnarchiver unarchiveObjectWithFile:[self dataFilePath]];
	//ratings array = array containing arrays - arrays in array have rating at index 1 and cigar object at index 0
	if(!ratings){
		ratings = [[NSMutableArray alloc] init];
	} else {
		ratings = [[NSMutableArray alloc] initWithArray:ratings];
		//9NSLog([ratings description]);
	}
    
    humidors = [NSKeyedUnarchiver unarchiveObjectWithFile:[self dataFilePathForHumidors]];
    if(!humidors){
        humidors = [[NSMutableArray alloc] init];
    } else {
        humidors = [[NSMutableArray alloc] initWithArray:humidors];
    }
    
    //Wish list
    WishList = [NSKeyedUnarchiver unarchiveObjectWithFile:[self dataFilePathForWishList]];
    if(!WishList){
        WishList = [[NSMutableArray alloc] init];
    } else {
        WishList = [[NSMutableArray alloc] initWithArray:WishList];
    }
    
    NewCigarList = [NSKeyedUnarchiver unarchiveObjectWithFile:[self dataFilePathForNewCigarList]];
    if(!NewCigarList){
        NewCigarList = [[NSMutableArray alloc] init];
    } else {
        NewCigarList = [[NSMutableArray alloc] initWithArray:NewCigarList];
        //  NSLog(@"NewCigarList  =%@ ",NewCigarList);
    }    
    
    notes = [NSKeyedUnarchiver unarchiveObjectWithFile:[self dataFilePathForMyNotes]];
    if(!notes){
        notes = [[NSMutableArray alloc] init];
    } else {
        notes = [[NSMutableArray alloc] initWithArray:notes];
    }
	
	if([[NSUserDefaults standardUserDefaults] objectForKey:@"CigarBoss_favoriteShops"]){
		favoriteShops = [[NSMutableArray alloc] initWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:@"CigarBoss_favoriteShops"]];
	} else {
		favoriteShops = [[NSMutableArray alloc] init];
	}
    
    self.cigarBossOperation = [[CigarBossOperation alloc] init];
	
    useWebService = [defaults boolForKey:@"UseWebService"];
    
    if (![checkit isEqualToString:@"FirstTimeLaunch"]) {
        [self.cigarBossOperation requestGetBrands:0];
        [defaults setBool:YES forKey:@"UseWebService"];
    } else {
        
        if ( useWebService ) {
            [self.cigarBossOperation requestGetUpdateBrands:0];
        } else {
            [self.cigarBossOperation requestGetBrands:0];
            [defaults setBool:YES forKey:@"UseWebService"];
        }
    }

    [window bringSubviewToFront:defaultImageView];
    

    if (![checkit isEqualToString:@"FirstTimeLaunch"]) {
        [window bringSubviewToFront:objStartUp.view];
    }else{

    }

    [window makeKeyAndVisible];

    if ( [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey] != nil ) {
        pushReceived = YES;
    }

    
    return YES;
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    

    if (userInfo) {
//        NSDictionary *notif = [userInfo objectForKey:@"aps"];
////        NSString *eventId = [notif objectForKey:@"eid"];
////        mEventId = [eventId intValue];
        pushReceived = YES;
        
        CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
        [appDelegate.mCategoryListViewController showDetailView:2];
    }

    
    /*
    //Urban Airship
    [[UAPush shared] handleNotification:userInfo applicationState:application.applicationState];
    [[UAPush shared] resetBadge]; // zero badge after push received
    
    NSLog(@"userInfo: %@", userInfo);
    if (userInfo) {
        NSDictionary *notif = [userInfo objectForKey:@"aps"];
        NSString *message = [notif objectForKey:@"alert"];
        [self checkPushMessageForUrl:message];
    }
     */
}

-(void)checkPushMessageForUrl:(NSString*)message{
    
    NSArray *comp = [message componentsSeparatedByString:@"www"];
    if ([comp count] > 1) {
        NSString *url = [NSString stringWithFormat:@"http://www%@", [comp objectAtIndex:1]];
        NSLog(@"opening URL: %@", url);
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
    }
    
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error{
    NSLog(@"fail to register remote push notification: %@", [error localizedDescription]);
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken{
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    if ( [prefs boolForKey:@"isRegistered"] )
        return;

    data = [[NSMutableData alloc] init];
    
    NSLog(@"APN device token: %@", deviceToken);
    
    NSString *device_token = [NSString stringWithFormat:@"%@", deviceToken];
    
    NSString *token = @"";
    
    NSRange range;
    
    range.location = 1;
    range.length = [device_token length] - 2;
    
    token = [device_token substringWithRange:range];
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    
    array = (NSMutableArray *)[token componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    NSString *finalToken = @"";
    
    for ( int i = 0; i < [array count]; i ++ ) {
        finalToken = [finalToken stringByAppendingString:[array objectAtIndex:i]];
    }
    
    NSLog(@"token = %@", finalToken);
    
    NSString *urlString = [NSString stringWithFormat:@"%@?task=settoken&email=%@&token=%@", LOCAL_SERVER_URL, EMAIL, finalToken];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    NSLog(@"urlString: %@", urlString);
    NSURLConnection *urlConnection = [NSURLConnection connectionWithRequest:request delegate:self];
    [urlConnection start];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    UIView *view = viewController.view;
    for(id subview in view.subviews){
        if([subview isKindOfClass:[UITableView class]]){
            CGRect frame = [subview frame];
            if([viewController.title isEqualToString:@"Top Tens"]){
                frame.size.height = 295;
            } else {
                frame.size.height = 367;
            }
            [subview setFrame:frame];
        }
    }
}

- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation
{
    userLocation = newLocation.coordinate;
    //NSLog(@"Location: %@", [newLocation description]);
}

-(void)adWhirlDidFailToReceiveAd:(AdWhirlView *)adWhirlView usingBackup:(BOOL)yesOrNo {
    adStatus = false;
    
    //The code to show my own Ad banner again
	//NSLog(@"test");
}

- (void)hideAdView
{
    iadBanner.hidden = YES;
}

- (void)showAdView
{
    iadBanner.hidden = NO;
}

- (void)createAdBanner
{

}

- (void)adWhirlDidReceiveAd:(AdWhirlView *)adWhirlView {
	[UIView beginAnimations:@"AdWhirlDelegate.adWhirlDidReceiveAd:"
					context:nil];
    adStatus = true;
    
    if(self.tabBarController.selectedIndex == 0)
    {
        HomeViewController *hmc = [self.tabBarController.viewControllers objectAtIndex:0];
        [hmc viewDidAppear:NO];
        
    }
    
	[UIView setAnimationDuration:0.7];
	
	CGSize adSize = [adWhirlView actualAdSize];
	CGRect newFrame = adWhirlView.frame;
	
	newFrame.size = adSize;

	newFrame.origin.x = 511.5;
	
	adWhirlView.frame = newFrame;
	
	[UIView commitAnimations];
}

- (NSString *)adWhirlApplicationKey {
    //	NSLog(@"ok good");
	return @"f05df4cd613344edba5ccef9f15c8164";
}

- (NSString *)admobPublisherID
{
    return @"a14e0be77394213";
}

- (UIViewController *)viewControllerForPresentingModalView {
	return mSplitViewController;
}


- (void)saveFavoriteShops
{
	
	[[NSUserDefaults standardUserDefaults] setObject:[favoriteShops copy] forKey:@"CigarBoss_favoriteShops"];
    //	NSLog([favoriteShops description]);
}

- (NSString *)dataFilePath
{
	NSString *dataFilePath;
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	dataFilePath = [[documentsDirectory stringByAppendingPathComponent:@"ratings.plist"] retain];
	return dataFilePath;
}

- (void)saveData
{
	[NSKeyedArchiver archiveRootObject:[ratings copy] toFile:[self dataFilePath]];
}

- (void)addFavorite:(NSMutableArray *)cigar
{
	[ratings addObject:cigar];
	[self saveData];
}

- (void)saveRatings
{
	[self saveData];
}

//=============


- (NSString *)dataFilePathForHumidors
{
	NSString *dataFilePath;
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	dataFilePath = [[documentsDirectory stringByAppendingPathComponent:@"ratings2.plist"] retain];
	return dataFilePath;
}
- (void)saveHumidorData
{
	[NSKeyedArchiver archiveRootObject:[humidors copy] toFile:[self dataFilePathForHumidors]];
}

- (void)addHumidor:(NSMutableArray *)cigar
{
	[humidors addObject:cigar];
	[self saveHumidorData];
}


- (void)saveHumidors
{
	[self saveHumidorData];
}


//=============


- (NSString *)dataFilePathForNewCigarList
{
	NSString *dataFilePath;
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	dataFilePath = [[documentsDirectory stringByAppendingPathComponent:@"NewCigar.plist"] retain];
	return dataFilePath;
}
- (void)saveNewCigarListData
{
	[NSKeyedArchiver archiveRootObject:[NewCigarList copy] toFile:[self dataFilePathForNewCigarList]];
}


- (void)addNewCigarList:(NSMutableArray *)cigar
{
    // NSLog(@">>>>>>cigar  cigar   %@",cigar);
    
    if (!NewCigarList || NewCigarList == nil) {
        NewCigarList = [[NSMutableArray alloc]init];
    }
	[NewCigarList addObject:cigar];
    [NewCigarList retain];
	[self saveNewCigarList];
}
- (void)saveNewCigarList
{
	[self saveNewCigarListData];
}




- (void)saveWishList
{
	[self saveWishListData];
}


- (void)addWishlist:(NSMutableArray *)cigar
{
	[WishList addObject:cigar];
	[self saveWishListData];
}


- (NSString *)dataFilePathForWishList
{
	NSString *dataFilePath;
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	dataFilePath = [[documentsDirectory stringByAppendingPathComponent:@"WishList.plist"] retain];
	return dataFilePath;
}
- (void)saveWishListData
{
	[NSKeyedArchiver archiveRootObject:[WishList copy] toFile:[self dataFilePathForWishList]];
}

- (void)addWishList:(NSMutableArray *)cigar
{
	[WishList addObject:cigar];
	[self saveWishListData];
}


- (void) showAlertWithTitle:(NSString *)title message:(NSString *)message {
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
	[alert show];
	[alert release];
}


- (NSString *)dataFilePathForMyNotes
{
	NSString *dataFilePath;
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	dataFilePath = [[documentsDirectory stringByAppendingPathComponent:@"notes.plist"] retain];
	return dataFilePath;
}

-(void) showFirstLoadingView : (UIView *) parentView {
    
    if (loadView == nil) {
		loadView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, parentView.frame.size.width, parentView.frame.size.height)];
        loadView.opaque = NO;
        loadView.backgroundColor = [UIColor clearColor];
        //loadView.alpha = 0.8;
		
        viewBack = [[UIView alloc] initWithFrame:CGRectMake((loadView.frame.size.width - 130 ) / 2, (loadView.frame.size.height - 40) / 2, 130, 40)];
        viewBack.backgroundColor = [UIColor blackColor];
        viewBack.alpha = 0.7f;
        viewBack.layer.masksToBounds = NO;
        viewBack.layer.cornerRadius = 8;
        
        spinningWheel = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(5.0, 5.0, 30.0, 30.0)];
        [spinningWheel startAnimating];
        //        spinningWheel.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;
        [viewBack addSubview:spinningWheel];
        [spinningWheel release];
        
        UILabel *lblLoading = [[UILabel alloc] initWithFrame:CGRectMake(23, 6, 110, 25)];
        lblLoading.backgroundColor = [UIColor clearColor];
        lblLoading.font = [UIFont fontWithName:@"Helvetica-Bold" size:16.0];
        lblLoading.textAlignment = UITextAlignmentCenter;
        lblLoading.textColor = [UIColor whiteColor];
        lblLoading.text = @"Loading...";
        [viewBack addSubview:lblLoading];
        [loadView addSubview:viewBack];
    } else {
        [loadView removeFromSuperview];
    }
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        loadView.frame = iphoneFrame;
        viewBack.frame = loadiPhone;
    }
    else
    {
        loadView.frame = ipadFrame;
        //        viewBack.frame = loadiPad;
    }
    
    [parentView addSubview:loadView];
}


-(void) showLoadingView : (UIView *) parentView {
    
    if (loadView == nil) {
		loadView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, parentView.frame.size.width, parentView.frame.size.height)];
        loadView.opaque = NO;
        loadView.backgroundColor = [UIColor clearColor];
        //loadView.alpha = 0.8;
		
        viewBack = [[UIView alloc] initWithFrame:CGRectMake((loadView.frame.size.width - 130 ) / 2, (loadView.frame.size.height - 40) / 2, 130, 40)];
        viewBack.backgroundColor = [UIColor blackColor];
        viewBack.alpha = 0.7f;
        viewBack.layer.masksToBounds = NO;
        viewBack.layer.cornerRadius = 8; 
        
        spinningWheel = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(5.0, 5.0, 30.0, 30.0)];
        [spinningWheel startAnimating];
        //        spinningWheel.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;
        [viewBack addSubview:spinningWheel];
        [spinningWheel release];		
        
        UILabel *lblLoading = [[UILabel alloc] initWithFrame:CGRectMake(23, 6, 110, 25)];
        lblLoading.backgroundColor = [UIColor clearColor];
        lblLoading.font = [UIFont fontWithName:@"Helvetica-Bold" size:16.0];
        lblLoading.textAlignment = UITextAlignmentCenter;
        lblLoading.textColor = [UIColor whiteColor];
        lblLoading.text = @"Loading...";
        [viewBack addSubview:lblLoading];
        [loadView addSubview:viewBack];
    } else {
        [loadView removeFromSuperview];
    }
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        loadView.frame = iphoneFrame;
        viewBack.frame = loadiPhone;        
    }
    else
    {
        loadView.frame = ipadFrame;  
        viewBack.frame = loadiPad;
    }
    
    [parentView addSubview:loadView];
}

-(void) hideLoadingView {
    NSLog(@"Hide Activity Indicator/Loading Panel called");
	[loadView removeFromSuperview];
}

- (void)saveMyNotesData
{
	[NSKeyedArchiver archiveRootObject:[notes copy] toFile:[self dataFilePathForMyNotes]];
}

- (void)addNote:(NSMutableArray *)cigar
{
	[notes addObject:cigar];
	[self saveMyNotesData];
}

- (void)saveMyNotes
{
	[self saveMyNotesData];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}
- (NSMutableArray *)findNewCigarList:(NSString *)cigar
{
	//Cigar *returnVal = nil;
	for(NSMutableArray *array in NewCigarList){
		Cigar *compareCigar = [array objectAtIndex:0];
		if([compareCigar isEqualCigar:cigar]) return array;
	}
	
	return nil;
}


- (NSMutableArray *)findCigarMatch:(Cigar *)cigar
{
	//Cigar *returnVal = nil;
	for(NSMutableArray *array in ratings){
		Cigar *compareCigar = [array objectAtIndex:0];
		if([compareCigar isEqualCigar:cigar]) return array;
	}
	
	return nil;
}

- (NSMutableArray *)findNotesMatch:(Cigar *)cigar
{
	//Cigar *returnVal = nil;
	for(NSMutableArray *array in notes){
		Cigar *compareCigar = [array objectAtIndex:0];
		if([compareCigar isEqualCigar:cigar]) return array;
	}
	
	return nil;
}

- (NSMutableArray *)findHumidorMatch:(Cigar *)cigar
{
	//Cigar *returnVal = nil;
	for(NSMutableArray *array in humidors){
		Cigar *compareCigar = [array objectAtIndex:0];
		if([compareCigar isEqualCigar:cigar]) return array;
	}
	
	return nil;
}
- (NSMutableArray *)findWishlistMatch:(Cigar *)cigar
{
    //	Cigar *returnVal = nil;
	for(NSMutableArray *array in WishList){
		Cigar *compareCigar = [array objectAtIndex:0];
		if([compareCigar isEqualCigar:cigar]) return array;
	}
	
	return nil;
}

- (NSMutableArray *)findFavoriteShop:(NSString *)favID
{
	for(NSMutableArray *array in favoriteShops){
		NSDictionary *compareCigar = [array objectAtIndex:0];
		if([[compareCigar objectForKey:@"id"] isEqualToString:favID]) return array;
	}
	
	return nil;
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)newData
{
	[data appendData:newData];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{   
	NSString *dataString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    if (dataString &&  dataString != nil ) {
        
        SBJsonParser *jsonParser = [SBJsonParser new];
        id eventObject = [jsonParser objectWithString:dataString];
        
        NSInteger status = [[eventObject objectForKey:@"status"] intValue];
        NSString *result = [eventObject objectForKey:@"results"];
        
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        [prefs setBool:YES forKey:@"isRegistered"];
        [prefs synchronize];
    }
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    
    if ( self.cigarBossOperation == nil )
        return;
    
    if ( self.cigarBossOperation.mIsRequestingNotification == YES )
        return;
    
    [self.cigarBossOperation requestGetNotification:EMAIL];
    
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    CLLocationManager *locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager startUpdatingLocation];
    
    /*
	if(![[[NSUserDefaults standardUserDefaults] objectForKey:@"CigarBossLaunched"] isEqualToString:@"2"]){
        int launchNum = 0;
        launchNum += [[[NSUserDefaults standardUserDefaults] objectForKey:@"CigarBossLaunched"] intValue];
        launchNum++;
        [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%d", launchNum] forKey:@"CigarBossLaunched"];
        //  NSLog(@"%d", launchNum);
    } else {
        UIAlertView *a = [[UIAlertView alloc] initWithTitle:@"Thanks for installing!" message:@"Like Cigar Boss? Rate us on the App Store!" delegate:self cancelButtonTitle:@"No thanks" otherButtonTitles:@"Sure!", nil];
        [a show];
        [a release];
        int launchNum = 4;
        [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%d", launchNum] forKey:@"CigarBossLaunched"];
    }
     */
    
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
    

}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1){
        if ( FULLVERSION == 0 ) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://itunes.apple.com/us/app/cigar-boss-hd/id538404039?ls=1&mt=8"]];            
        } else {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://itunes.apple.com/us/app/cigar-boss-pro-hd/id538405757?ls=1&mt=8"]];
        }
    }
}
- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
}


#pragma mark -
#pragma mark UITabBarControllerDelegate methods

/*
 // Optional UITabBarControllerDelegate method.
 - (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
 }
 */

/*
 // Optional UITabBarControllerDelegate method.
 - (void)tabBarController:(UITabBarController *)tabBarController didEndCustomizingViewControllers:(NSArray *)viewControllers changed:(BOOL)changed {
 }
 */
     
- (void)adViewDidFinishLoad:(MobclixAdView*)adView {
     NSLog(@"Ad Loaded: %@.", NSStringFromCGSize(adView.frame.size));
    
    if ( FULLVERSION == 0 )
        adStatus = true;
    
    
    UIViewController *viewController = [AppDelegate.mNavigationController.viewControllers objectAtIndex:0];
        
    if ( [viewController class] == [BrandsViewController class] || [viewController class] == [ChangeNewCigarViewController class] ) {
        [viewController refreshTableView];
    }
}
     
- (void)adView:(MobclixAdView*)adView didFailLoadWithError:(NSError*)error {
    NSLog(@"Ad Failed: %@.", NSStringFromCGSize(adView.frame.size));
    adStatus = false;
}
     
- (void)adViewWillTouchThrough:(MobclixAdView*)adView {
    NSLog(@"Ad Will Touch Through: %@.", NSStringFromCGSize(adView.frame.size));
}
     
- (void)adViewDidFinishTouchThrough:(MobclixAdView*)adView {
    NSLog(@"Ad Did Finish Touch Through: %@.", NSStringFromCGSize(adView.frame.size));
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}

+ (BOOL)adSkipBackUpAttributeToItemAtURL : (NSString *) path {
    
    /*
    double version = [[[UIDevice currentDevice] systemVersion] floatValue];
    
    if ( version < 5.1 ) {
        const char* filepath = [path fileSystemRepresentation];
        const char* name = "com.apple.MobileBackup";
        u_int8_t attrValue = 1;
        
        int result = setxattr(filepath, name, &attrValue, sizeof(attrValue), 0, 0);
        return result == 0;
    } else if ( version >= 5.1 ) {
        NSError *error = nil;
        NSURL *url = [NSURL URLWithString:path];
        [url setResourceValue:[NSNumber numberWithBool:YES] forKey:@"NSURLIsExcludedFromBackupKey" error:&error];
        
        return error == nil;
    }
     */
    
    return false;
}

- (void)dealloc {
    [tabBarController release];
    [window release];
    [mSplitViewController release];
    [mNavigationController release];
    [mCategoryListViewController release];
    [super dealloc];
}

@end

