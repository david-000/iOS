//
//  FilterViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FilterViewController.h"
#import "Cigar.h"
#import "FilteredViewControllerNew.h"
#import "CustomHighlightedCell.h"
#import "CigarBossAppDelegate.h"

@implementation FilterViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

- (id)initWithCoder:(NSCoder *)aDecoder
{
	self = [super initWithCoder:aDecoder];
	
	
	return self;
}
	

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return 6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BrandCell"];
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"BrandCell"] autorelease];
	}
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.textLabel.textColor = [UIColor whiteColor];
    cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:16];
    
	
	int row = indexPath.row;
	switch(row+1)
	{
		case 0:
			cell.textLabel.text = @"By Type";
			break;
		case 1:
			cell.textLabel.text = @"By Strength";
			break;
		case 2:
			cell.textLabel.text = @"By Ring Guage";
			break;
		case 3:
			cell.textLabel.text = @"By Country";
			break;
		case 4:
			cell.textLabel.text = @"By Wrapper";
			break;
		case 5:
			cell.textLabel.text = @"By Length";
			break;
		case 6:
			cell.textLabel.text = @"By Price";
			break;
		case 7:
			cell.textLabel.text = @"By Box Price";
			break;
	}
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	
	return cell;
}
	
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	FilteredViewControllerNew *f = [[FilteredViewControllerNew alloc] initWithNibName:@"FilteredViewControllerNew" bundle:nil];
	f.allCigarsArray = allCigarsArray;
	f.type = indexPath.row+1;
	int row = indexPath.row;
	switch(row+1)
	{
		case 0:
			f.title = @"By Type";
			break;
		case 1:
			f.title = @"By Strength";
			break;
		case 2:
			f.title = @"By Ring Guage";
			break;
		case 3:
			f.title = @"By Country";
			break;
		case 4:
			f.title = @"By Wrapper";
			break;
		case 5:
			f.title = @"By Length";
			break;
		case 6:
			f.title = @"By Price";
			break;
		case 7:
			f.title = @"By box price";
			break;
	}
    self.navigationItem.title=@"Back";
	[self.navigationController pushViewController:f animated:YES];
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
	appDelegate = [[UIApplication sharedApplication] delegate];
	allCigarsArray = [[NSMutableArray alloc] init];
	
	NSDictionary *brandsDictionary = [appDelegate cigarBrandArrays];
	NSArray *allArrays = [brandsDictionary allValues];
	for(NSArray *group in allArrays){
		for(Cigar *cigarG in group){
			[allCigarsArray addObject:cigarG];
			[cigarG release];
		}
	}
	
	mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 420)];
	bgView.image = [UIImage imageNamed:@"Background640x734.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
	
	self.title = @"Filter";
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 190, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =self.title; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:16.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
