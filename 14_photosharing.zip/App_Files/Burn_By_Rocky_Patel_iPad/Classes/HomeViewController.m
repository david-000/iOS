//
//  HomeViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "HomeViewController.h"
#import "CigarBossAppDelegate.h"
#import "AdWhirlView.h"
#import <MessageUI/MessageUI.h>
#import "AboutViewController.h"
#import "LastViewController.h"
#import "CigarsViewController.h"
#import "WebViewController.h"
#import "CigarNewsFeedsViewController.h"
#import "CigarViewController.h"
#import "TopTenView.h"
#import "SettingsViewController.h"
#import "MyHumidorsViewController.h"
#import "MyNotesViewController.h"
#import "RootViewController.h"
#import "MyWishList.h"
#import "ChangeNewCigarViewController.h"
#import "FilterSearchViewController.h"
#import "DisplayNewAddedCigarViewController.h"
#import "StartUpImage.h"
#import "FavoritesViewController.h"
#import "communityViewController.h"
#import "TSMiniWebBrowser.h"

StartUpImage *objStartUp;

@implementation HomeViewController
@synthesize checkStatus;
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
 // Custom initialization
 }
 return self;
 }
 */
- (IBAction)OpenTour:(UIButton *)sender
{
    objStartUp = [[StartUpImage alloc] initWithNibName:@"StartUpImage" bundle:nil];
    
    [appDelegate.window addSubview:objStartUp.view];
    
}
- (IBAction)OpenNewCigar:(UIButton *)sender
{
    ChangeNewCigarViewController *cView = [[ChangeNewCigarViewController alloc] initWithNibName:@"ChangeNewCigarViewController" bundle:nil];
    cView.cigars = [[[UIApplication sharedApplication] delegate] newCigars];
    NSSortDescriptor *sortDesc = [NSSortDescriptor sortDescriptorWithKey:@"brand" ascending:YES];
    cView.cigars = [[cView.cigars sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDesc]] retain];
    cView.forNewCigars = YES;
    if([cView.cigars count] < 1){
        [cView release];
        UIAlertView *eView = [[UIAlertView alloc] initWithTitle:@"No New Cigars!" message:@"There are no new cigars to view! Check back later!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [eView show];
        [eView release];
    } else {
//        UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 190, 30)];
//        titleLabel.textColor = [UIColor whiteColor];
//        titleLabel.textAlignment = UITextAlignmentCenter;
//        titleLabel.text =@"New Cigars"; 
//        titleLabel.backgroundColor = [UIColor clearColor];
//        titleLabel.font = [UIFont fontWithName:@"Copperplate" size:16.0];
//        titleLabel.minimumFontSize = 10;
//        titleLabel.adjustsFontSizeToFitWidth = YES;
//        self.navigationItem.titleView = titleLabel;
//        [titleLabel release];
//        titleLabel = nil;
        cView.title = @"New Cigars";
        self.navigationItem.title=@"Back";
        [self.navigationController pushViewController:cView animated:YES];
    }
    //[self presentModalViewController:cView animated:YES];
}

-(IBAction)onNewCigarView:(id)sender
{
    DisplayNewAddedCigarViewController *dnad = [[DisplayNewAddedCigarViewController alloc]initWithNibName:@"DisplayNewAddedCigarViewController" bundle:nil];
    self.title=@"Back";
    [self.navigationController pushViewController:dnad animated:YES];
}

- (IBAction)OpenWikipedia:(UIButton *)sender
{
    WebViewController *webViewController = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
    webViewController.url = [NSURL URLWithString:@"http://en.wikipedia.org/wiki/Cigar"];

    [self presentModalViewController:webViewController animated:YES];
}

- (IBAction)OpenCigarNews:(UIButton *)sender
{
    RootViewController *c = [[RootViewController alloc] initWithNibName:@"RootViewController" bundle:[NSBundle mainBundle]];
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:c animated:YES];
}

- (IBAction)OpenMyNotes:(UIButton *)sender
{
    MyNotesViewController *myNotes = [[MyNotesViewController alloc] initWithNibName:@"MyNotesViewController" bundle:[NSBundle mainBundle]];
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:myNotes animated:YES];
}

- (IBAction)OpenTopTen
{
    TopTenView *t = [[TopTenView alloc] initWithNibName:@"TopTenView" bundle:nil];
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:t animated:YES];
}

- (IBAction)OpenSettings:(UIButton *)sender
{
    SettingsViewController *settingsView = [[SettingsViewController alloc] initWithNibName:@"SettingsViewController" bundle:nil];
 
    [self presentModalViewController:settingsView animated:YES];
}


- (IBAction)OpenMyHumidor:(UIButton *)sender
{
    appDelegate.tabBarController.selectedIndex = 3;
//    MyHumidorsViewController *myHumidorViewController = [[MyHumidorsViewController alloc] initWithNibName:@"MyHumidorsViewController" bundle:[NSBundle mainBundle]];
//    [self.navigationController pushViewController:myHumidorViewController animated:YES];
}
- (IBAction)OpenMyWishList:(UIButton *)sender{
    
    MyWishList *mywishlist = [[MyWishList alloc] initWithNibName:@"MyWishList" bundle:[NSBundle mainBundle]];
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:mywishlist animated:YES];
}

- (IBAction)OpenCigarOfMonth:(UIButton *)sender
{
    CigarViewController *cigarView = [[CigarViewController alloc] initWithNibName:@"CigarViewController" bundle:nil];
    [cigarView setCigar:[[[UIApplication sharedApplication] delegate] COM]];
    [cigarView setForFeaturedCigar:YES];
    if([[[UIApplication sharedApplication] delegate] COM] == nil){
        UIAlertView *eView = [[UIAlertView alloc] initWithTitle:@"No COM!" message:@"There is no Cigar of the Month, sorry!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [eView show];
        [eView release];
        [cigarView release];
    } else{ 
    self.navigationItem.title=@"Back";
        [self.navigationController pushViewController:cigarView animated:YES];
    }
}

-(IBAction)openCommunity:(id)sender
{
    communityViewController *mycommunityViewController = [[communityViewController alloc] initWithNibName:@"communityViewController" bundle:[NSBundle mainBundle]];
    mycommunityViewController.flag = YES;
    mycommunityViewController.title = @"Community";
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:mycommunityViewController animated:YES];
}

-(void)viewDidAppear:(BOOL)animated
{
    NSLog(@">>>>>>>> %d ",appDelegate.adStatus);
    if(appDelegate.adStatus || checkStatus)
    {
        [scrollView setFrame:CGRectMake(-7, -6, 320, 320)];
        [scrollView setContentSize:CGSizeMake(320,650)];
    }
    else
    {
        [scrollView setFrame:CGRectMake(-7, -6, 320, 375)]; 
        [scrollView setContentSize:CGSizeMake(320,700)];
    }
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    
    [super viewDidLoad];
	[scrollView setScrollEnabled:YES];
	[scrollView setContentSize:CGSizeMake(320,600)];
    scrollView.frame = CGRectMake(-7, -6, 320, 450);
    scrollView.showsVerticalScrollIndicator = NO;
	//[adWhirlView setBackgroundColor:[UIColor redColor]];
	appDelegate =(CigarBossAppDelegate *) [[UIApplication sharedApplication] delegate];
	
	self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 190, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =@"Cigar Boss"; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:16.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];
}

- (IBAction)showBrands:(UIButton *)sender
{
	appDelegate.tabBarController.selectedIndex = 1;
}

- (IBAction)showFilter:(UIButton *)sender
{
	appDelegate.tabBarController.selectedIndex = 2;
}

- (IBAction)showFavori:(UIButton *)sender
{
//	appDelegate.tabBarController.selectedIndex = 3;
    FavoritesViewController *fvc = [[FavoritesViewController alloc] initWithNibName:@"FavoritesViewController" bundle:nil];
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:fvc animated:YES];
}

- (IBAction)showLocalS:(UIButton *)sender
{
	appDelegate.tabBarController.selectedIndex = 4;
}

- (IBAction)showContac:(UIButton *)sender
{
    if ([MFMailComposeViewController canSendMail]) {
        
        MFMailComposeViewController *mailViewController = [[MFMailComposeViewController alloc] init];
        mailViewController.mailComposeDelegate = self;
        [mailViewController setToRecipients:[NSArray arrayWithObject:@"blake@burnbyrockypatel.com"]];


        [self presentModalViewController:mailViewController animated:YES];
        [mailViewController release];
        
    }
}

- (IBAction)showAboutu:(UIButton *)sender
{
//    AboutViewController *a = [[AboutViewController alloc] initWithNibName:@"AboutViewController" bundle:nil];
//    [self presentModalViewController:a animated:YES];
    NSString *urlAddress = @"http://cigarboss.blogspot.com/";
    NSURL *url = [NSURL URLWithString:urlAddress];
    WebViewController *w = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
    w.url = url;    
    [self presentModalViewController:w animated:YES];
//    TSMiniWebBrowser *webBrowser = [[TSMiniWebBrowser alloc] initWithUrl:url];
//    [self presentModalViewController:webBrowser animated:YES];
//    [webBrowser release];
}

- (IBAction)showLast:(UIButton *)sender
{
    LastViewController *l = [[LastViewController alloc] initWithNibName:@"LastViewController" bundle:[NSBundle mainBundle]];
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:l animated:YES];
}

-(void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error :(NSError*)error {
    
    [self dismissModalViewControllerAnimated:YES];
    
}


/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (IBAction)onFilterBtnClick:(UIButton *)sender
{
    FilterSearchViewController *f = [[FilterSearchViewController alloc]initWithNibName:@"FilterSearchViewController" bundle:nil] ;
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:f animated:YES];
}



- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}
-(void)DeleteAllImages { 
    
    BOOL isDir = NO;
    NSInteger ObjfileCount = 0;
    NSArray *subpaths;
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES); 
    NSString *pathToDocumentsDir = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    
    if ([fileManager fileExistsAtPath:pathToDocumentsDir isDirectory:&isDir] && isDir) {
        subpaths = [[[NSArray alloc]initWithArray:[fileManager subpathsAtPath:pathToDocumentsDir]]autorelease];
        ObjfileCount = [subpaths count];  
    }
    else{
        
        subpaths = [[[NSArray alloc]initWithObjects:nil]autorelease];
    }
    
    NSError *error = nil;
    
    if(subpaths) {
        int iVal = 0;
        for (NSString *strFileName in subpaths) {
            
            if ([strFileName length] > 0) {                
                //                NSString *tempAtIndex=[strFileName substringWithRange:NSMakeRange([strFileName length]-4,0)];
                
                if([[strFileName lowercaseString] isEqualToString: [NSString stringWithFormat:@"%d.png", iVal]]) {
                    
                    BOOL success = [fileManager removeItemAtPath: [pathToDocumentsDir stringByAppendingPathComponent:strFileName] error:&error];
                    if (!success || error) {
                        NSLog(@"Error Deleting All Image at Path ::>>%@",strFileName);
                    }else{
                        NSLog(@"Deleting All Image ");
                    }
                    iVal = iVal + 1;
                }
            }
        }
    }
}

@end
