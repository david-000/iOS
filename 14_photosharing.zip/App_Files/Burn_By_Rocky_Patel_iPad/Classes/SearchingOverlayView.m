//
//  SearchingOverlayView.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 7/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SearchingOverlayView.h"


@implementation SearchingOverlayView

@synthesize parent;

- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        // Initialization code
		self.backgroundColor = [UIColor blackColor];
		self.alpha = .5;
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	[parent closeSearch];
}

- (void)dealloc {
    [super dealloc];
}


@end
