//
//  AddNoteViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 11/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AddNoteViewController.h"
#import "MyClass.h"
#import "Cigar.h"
#import "CigarViewController.h"
#import "CigarBossAppDelegate.h"
#import <QuartzCore/QuartzCore.h>


@implementation AddNoteViewController

@synthesize callingViewController;
@synthesize cigar;
@synthesize scrollSize;
@synthesize popOverController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [scrollView setContentSize:CGSizeMake(703, 748)];
    
    CGRect datePickerF = datePicker.frame;
    datePickerF.origin = CGPointMake(0, 748);
    datePicker.frame = datePickerF;
    NSDate *date = datePicker.date;
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
    
    datePickerLabel.text = [dateFormatter stringFromDate:date];
    [dateFormatter release];
    [self.view addSubview:datePicker];
    
    viewThatClosesDatEPicker = [[MyClass alloc] initWithFrame:CGRectMake(0, 44, 1024, 700)];
    viewThatClosesDatEPicker.backgroundColor = [UIColor blackColor];
    viewThatClosesDatEPicker.parentViewsViewController = self;
    [viewThatClosesDatEPicker setAlpha:0.0];
    
    locationTextField.font = [datePickerLabel font];
    pricePaidTextfield.font = [datePickerLabel font];
    tastingNotesTextField.font = datePickerLabel.font;
    
    tastingNotesTextField.layer.cornerRadius = 10.0;
    tastingNotesTextField.layer.borderWidth = 1.5;
    locationTextField.textColor = datePickerLabel.textColor;
    pricePaidTextfield.textColor = datePickerLabel.textColor;
    //tastingNotesTextField.textColor = datePickerLabel.textColor;
    
    scoreTextField.font = [datePickerLabel font];
    scoreTextField.textColor = datePickerLabel.textColor;
    
    [self.view addSubview:viewThatClosesDatEPicker];
    [self.view bringSubviewToFront:datePicker];
    // Do any additional setup after loading the view from its nib.
}

- (void)close { 
    
    [self dismissModalViewControllerAnimated:YES]; 
}

- (IBAction)save
{
    int count;
    
    NSUserDefaults *number = [NSUserDefaults standardUserDefaults];
    if ([number integerForKey:@"SetCount"] > 0) {
        
        count = [number integerForKey:@"SetCount"];
        count ++;
    }else{
        count = 0;
    }
    
    
    //    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    //    NSString *documentsDirectory = [paths objectAtIndex:0];
    //    NSString *tempname = [NSString stringWithFormat:@"savedImage%d",count];
    //    NSString *savedImagePath = [documentsDirectory stringByAppendingPathComponent:tempname];
    //    UIImage *image = imgUpload.image; // imageView is my image from camera
    //    NSData *imageData = UIImagePNGRepresentation(image);
    //    [imageData writeToFile:savedImagePath atomically:NO];  
    
    //    NSUserDefaults *number2 = [NSUserDefaults standardUserDefaults];
    //    count++;
    //    [number2 setInteger:count forKey:@"SetCount"];
    //    [number2 synchronize];
    
    if([locationTextField.text length] < 1 || [pricePaidTextfield.text length] < 1 || [tastingNotesTextField.text length] < 1 || [scoreTextField.text length] < 1){
        UIAlertView *e = [[UIAlertView alloc] initWithTitle:@"Blank Fields!" message:@"You have left some fields blank!" delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
        [e show];
        [e release];
        return;
    }
    scoreTextField.text = [NSString stringWithFormat:@"%d", [scoreTextField.text intValue]];
    NSMutableDictionary *saveDict = [[NSMutableDictionary alloc] init];
    [saveDict setObject:datePicker.date forKey:@"date"];
    [saveDict setObject:locationTextField.text forKey:@"location"];
    [saveDict setObject:pricePaidTextfield.text forKey:@"pricePaid"];
    [saveDict setObject:tastingNotesTextField.text forKey:@"tastingNotes"];
    [saveDict setObject:scoreTextField.text forKey:@"score0or100"];
    if(savedImagePath.length > 0){
        [saveDict setObject:savedImagePath forKey:@"UpImage"];
    }else
    {
        [saveDict setObject:@"" forKey:@"UpImage"];    
    }
    NSLog(@"savedImagePath = %@ ",savedImagePath);
    id appDelegate = [[UIApplication sharedApplication] delegate];
    NSMutableArray *notes = [appDelegate notes];
    NSMutableArray *cigarArray = [appDelegate findNotesMatch:self.cigar];
	if(cigarArray){
        [[cigarArray objectAtIndex:1] addObject:saveDict];
		[appDelegate saveMyNotesData];
	} else {
		cigarArray = [[NSMutableArray alloc] initWithCapacity:2];
		[cigarArray addObject:cigar];
		[cigarArray addObject:[[NSMutableArray alloc] initWithObject:saveDict]];
		[appDelegate addNote:cigarArray];
		[appDelegate saveMyNotesData];
	}
    [callingViewController viewDidLoad];
    CGPoint offset = CGPointMake(0, 350);
//    [callingViewController.scrollView setContentOffset:offset];
    [callingViewController.scrollView setContentSize:CGSizeMake(1024, scrollSize)];
    [self dismissModalViewControllerAnimated:YES];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range 
 replacementText:(NSString *)text
{
    // Any new character added is passed in as the "text" parameter
    if ([text isEqualToString:@"\n"]) {
        // Be sure to test for equality using the "isEqualToString" message
        [textView resignFirstResponder];
        
        // Return FALSE so that the final '\n' character doesn't get added
        return FALSE;
    }
    // For any other character return TRUE so that the text gets added to the view
    return TRUE;
}


-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.tag == 32) {
        
        [scrollView setContentOffset:CGPointMake(0, 60) animated:YES];
    }
    
    if (textField.tag == 33) {
        
        [scrollView setContentOffset:CGPointMake(0, 100) animated:YES];
    }
    if (textField.tag == 35) {
        
        [scrollView setContentOffset:CGPointMake(0, 200) animated:YES];
    }
    
}
-(void)textViewDidBeginEditing:(UITextView *)textView
{
    if (textView.tag == 34) {
        [scrollView setContentOffset:CGPointMake(0, 160) animated:YES];
    }
    
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
}

-(void)textViewDidEndEditing:(UITextField *)textField
{
    [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}

- (void)openDatePicker
{
    [locationTextField resignFirstResponder];
    [pricePaidTextfield resignFirstResponder];
    [tastingNotesTextField resignFirstResponder];
    
    [scoreTextField resignFirstResponder];
    [UIView beginAnimations:nil context:Nil];
    [UIView setAnimationDuration:.5];
    CGRect datePickerF = datePicker.frame;
    datePickerF.origin = CGPointMake(0, 748-datePickerF.size.height);
    datePicker.frame = datePickerF;
    viewThatClosesDatEPicker.alpha = .2;
    [UIView commitAnimations];
}

- (void)closeDatePicker
{
    [UIView beginAnimations:nil context:Nil];
    [UIView setAnimationDuration:.5];
    CGRect datePickerF = datePicker.frame;
    datePickerF.origin = CGPointMake(0, 748);
    datePicker.frame = datePickerF;
    viewThatClosesDatEPicker.alpha = 0.0;
    NSDate *date = datePicker.date;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
    
    datePickerLabel.text = [dateFormatter stringFromDate:date];
    [dateFormatter release];
    [UIView commitAnimations];
}

- (void)viewWillAppear:(BOOL)animated {
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:self.view.window]; 
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:self.view.window];
}

-(void)viewWillDisappear:(BOOL)animated {
    [self setEditing:NO animated:YES];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil]; 
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil]; 
}

- (void)keyboardWillShow:(NSNotification *)notif {
    CGRect scrollViewFrame = scrollView.frame;
    [UIView beginAnimations:nil context:Nil];
    [UIView setAnimationDuration:.3];
    CGSize keyBoardSize = [[[notif userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey]CGRectValue].size;
    scrollViewFrame.size = CGSizeMake(1024, scrollViewFrame.size.height-keyBoardSize.height);
    scrollView.frame = scrollViewFrame;
    if([pricePaidTextfield isFirstResponder] || [tastingNotesTextField isFirstResponder]){
        CGPoint bottomOffset = CGPointMake(0, 360);
        [scrollView setContentOffset: bottomOffset animated: YES];
    }
    if([scoreTextField isFirstResponder]){
        CGPoint bottomOffset = CGPointMake(0, 460);
        [scrollView setContentOffset: bottomOffset animated: YES];
    }
    [UIView commitAnimations];
}

- (void)keyboardWillHide:(NSNotification *)notif {
    CGRect scrollViewFrame = scrollView.frame;
    [UIView beginAnimations:nil context:Nil];
    [UIView setAnimationDuration:.3];
    CGSize keyBoardSize = [[[notif userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey]CGRectValue].size;
    scrollViewFrame.size = CGSizeMake(1024, scrollViewFrame.size.height+keyBoardSize.height);
    scrollView.frame = scrollViewFrame;
    CGPoint bottomOffset = CGPointMake(0, 0);
    [scrollView setContentOffset:bottomOffset];
    /*if([pricePaidTextfield isFirstResponder] || [tastingNotesTextField isFirstResponder]){
     CGPoint bottomOffset = CGPointMake(0, 100);
     [scrollView setContentOffset: bottomOffset animated: YES];
     }*/
    [UIView commitAnimations];
  //  NSLog(@"Inside keyboardWillHide");
}

- (IBAction)UploadImage{
    
    //    imagePickerController = [[UIImagePickerController alloc] init];
    //    imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    //    imagePickerController.navigationBar.barStyle = UIBarStyleBlack;
    //    imagePickerController.delegate = self;
    //    imagePickerController.allowsEditing = NO;
    //    [self presentModalViewController:imagePickerController animated:YES];
    //    [imagePickerController release];
    UIActionSheet *action = [[UIActionSheet alloc]initWithTitle:@"" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Take A Photo",@"Existing Photo",nil];//@"Clear Message Log" == 0 
    //    action.tag = 99;
    [action showInView:self.view];
    [action release];
    
}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{

    if(buttonIndex==0)
    { 
        
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
            //            picker.sourceType = UIImagePickerControllerSourceTypeCamera;
            //            [self presentModalViewController:picker animated:YES];
            CustomImagePickerController * picker = [[CustomImagePickerController alloc] init];
            picker.sourceType = UIImagePickerControllerSourceTypeCamera;
            picker.navigationBar.barStyle = UIBarStyleBlack;                
            picker.delegate = self;
            picker.allowsEditing = NO;
            [self presentModalViewController:picker animated:YES];
            [picker release];
        }
        else {
            
            UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Unavailable Source" message:@"This function needs a camera which is only available on the iPhone or iPod." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            
            [alert show];
            [alert release];
        }
    }
    else if(buttonIndex==1)
    {

        if ( [popOverController isPopoverVisible] ) {
            [popOverController dismissPopoverAnimated:YES];
        } else {
            
            CustomImagePickerController *picker = [[CustomImagePickerController alloc] init];
            picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            picker.navigationBar.barStyle = UIBarStyleBlack;                
            picker.delegate = self;
            
            UIPopoverController *popoverController = [[UIPopoverController alloc] initWithContentViewController:picker];
            
            popoverController.delegate = self;
            CGRect popoverRect = [self.view convertRect:[self.view frame] fromView:[self.view superview]];
            popoverRect.size.width = MIN(popoverRect.size.width, 80);
            popoverRect.origin.x = popoverRect.origin.x + 150;
            [popoverController presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            
            self.popOverController = popoverController;
            
        }
        
    }
    [actionSheet dismissWithClickedButtonIndex:2 animated:YES]; 
}
- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *capturedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    NSString *moviePath = [[info objectForKey:UIImagePickerControllerMediaURL] path];
    
    if ( picker.sourceType == UIImagePickerControllerSourceTypeCamera )
        [picker dismissModalViewControllerAnimated:YES];      
    else {
        [popOverController dismissPopoverAnimated:YES];
    }
        
    //imgUpload.image = capturedImage;
    [self performSelector:@selector(waitUntillImageCaptured:) withObject:capturedImage afterDelay:0.2];
}

-(void)waitUntillImageCaptured:(UIImage *)originalImage
{
    //UIImageOrientation    originalOrientation = originalImage.imageOrientation;
    
    UIImage *tempimg;// = [self rotateImage:originalImage byOrientationFlag:originalOrientation];
    
    tempimg = [self scaleAndRotateImage:originalImage];
    //UIImageWriteToSavedPhotosAlbum(tempimg,nil,nil,nil);
    
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    
  
    
    NSUserDefaults *SetCounterValue =[NSUserDefaults standardUserDefaults];

    int count = [[SetCounterValue objectForKey:@"SetCount"] intValue];
 //   NSLog(@">>>>>>>>> %d",count);
   // int count = [ImageNumber integerForKey:@"SetCount"];
    
    
    
    NSString *strUser = [NSString stringWithFormat:@"savedImage%d.png",count];
    [strUser retain];
    
    count = count + 1;
    [SetCounterValue setObject:[NSString stringWithFormat:@"%d",count] forKey:@"SetCount"];
    [SetCounterValue synchronize]; 
    
    NSString *imagePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:strUser];
    
    savedImagePath = [NSString stringWithFormat:@"%@",imagePath];
    [savedImagePath retain];
    UIImageView *tempView = [[UIImageView alloc] initWithImage:tempimg];
    NSData *data = [NSData dataWithData:UIImagePNGRepresentation(tempView.image)];
    [tempView release];
    
    if(data != nil) {
        [CigarBossAppDelegate adSkipBackUpAttributeToItemAtURL:imagePath];
        [data writeToFile:imagePath atomically:YES];
    }
    else{
        [[NSFileManager defaultManager] removeItemAtPath:imagePath error:NULL];
    }
    
    [pool release];
    
    [self performSelector:@selector(thumbWithSideOfLength:) withObject:strUser afterDelay:0.3];
}
# pragma -
# pragma Scale and Rotate according to Orientation

- (UIImage *)scaleAndRotateImage:(UIImage *)image {
    int kMaxResolution = 550; // Or whatever
    
    CGImageRef imgRef = image.CGImage;
    
    CGFloat width = CGImageGetWidth(imgRef);
    CGFloat height = CGImageGetHeight(imgRef);
    
    
    CGAffineTransform transform = CGAffineTransformIdentity;
    CGRect bounds = CGRectMake(0, 0, width, height);
    if (width > kMaxResolution || height > kMaxResolution) {
        CGFloat ratio = width/height;
        if (ratio > 1) {
            bounds.size.width = kMaxResolution;
            bounds.size.height = roundf(bounds.size.width / ratio);
        }
        else {
            bounds.size.height = kMaxResolution;
            bounds.size.width = roundf(bounds.size.height * ratio);
        }
    }
    
    CGFloat scaleRatio = bounds.size.width / width;
    CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
    CGFloat boundHeight;
    UIImageOrientation orient = image.imageOrientation;
    switch(orient) {
            
        case UIImageOrientationUp: //EXIF = 1
            
            // landscape right
            transform = CGAffineTransformIdentity;
            break;
            
        case UIImageOrientationUpMirrored: //EXIF = 2
            transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            break;
            
        case UIImageOrientationDown: //EXIF = 3
            
            // landscape left
            transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationDownMirrored: //EXIF = 4
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
            transform = CGAffineTransformScale(transform, 1.0, -1.0);
            break;
            
        case UIImageOrientationLeftMirrored: //EXIF = 5
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationLeft: //EXIF = 6
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationRightMirrored: //EXIF = 7
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeScale(-1.0, 1.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
            
        case UIImageOrientationRight: //EXIF = 8
            
            // Portrait Mode 
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
            
        default:
            [NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];
    }
    
    UIGraphicsBeginImageContext(bounds.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {
        CGContextScaleCTM(context, -scaleRatio, scaleRatio);
        CGContextTranslateCTM(context, -height, 0);
    }
    else {
        CGContextScaleCTM(context, scaleRatio, -scaleRatio);
        CGContextTranslateCTM(context, 0, -height);
    }
    
    CGContextConcatCTM(context, transform);
    
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
    UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return imageCopy;
}

#pragma mark -
#pragma mark make thumbnail image 

- (void)thumbWithSideOfLength:(NSString*)strImgName {
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
	
    //NSString *fullPathToUser = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.jpg", strImgName]];
    
	NSString *fullPathToThumbImage = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@", strImgName]];
    
//    imgUpload.backgroundColor = [UIColor clearColor];
    
    UIImage *image = [UIImage imageWithContentsOfFile:fullPathToThumbImage];
    
    [imgUpload setImage:[UIImage imageWithContentsOfFile:fullPathToThumbImage]];
}

#pragma mark -
#pragma mark path for Document Directory
-(NSString *)applicationDocumentsDirectory {
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
	return basePath;
}

- (void)dealloc
{
    [popOverController release];
    [super dealloc];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

@end
