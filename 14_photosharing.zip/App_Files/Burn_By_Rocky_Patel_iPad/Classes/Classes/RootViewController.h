//
//  RootViewController.h
//  RSSFun
//
//  Created by Ray Wenderlich on 1/24/11.
//  Copyright 2011 Ray Wenderlich. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WebViewController2;

@interface RootViewController : UIViewController {
    IBOutlet UITableView *tableView;
    NSOperationQueue *_queue;
    NSArray *_feeds;
    NSArray *feeds;
    NSMutableArray *_allEntries;
    WebViewController2 *_webViewController;
}

@property (retain) UITableView *tableView;
@property (retain) NSOperationQueue *queue;
@property (retain) NSArray *feeds;
@property (retain) NSMutableArray *allEntries;
@property (retain) WebViewController2 *webViewController;

@end
