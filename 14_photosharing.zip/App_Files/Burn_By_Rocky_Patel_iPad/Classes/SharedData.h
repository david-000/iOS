//
//  SharedData.h
//  CigarBoss_Free
//
//  Created by Lion User on 17/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SharedData : NSObject
{
    NSOperationQueue                            *mOperationQueue;
}

@property (nonatomic, retain) NSOperationQueue      *mOperationQueue;
@property (nonatomic, retain) NSMutableArray        *mEventsArray;

+ (SharedData *) sharedData;
- (void) initSharedData;
- (NSMutableArray *) getStaffFavoriteArray;
- (NSMutableArray *) getSpecialArray;
- (NSMutableArray *) getOutOfStockArray;
- (NSMutableArray *) getFeaturedCigarArray;
+ (void) saveUpdatedTime : (double) update_time;
+ (double) getUpdatedTime;
+ (void) saveEventUpdatedTime : (double) update_time;
+ (double) getEventUpdatedTime;
+ ( NSDate *) getUTCFormateDate : (NSDate *) localDate;

@end
