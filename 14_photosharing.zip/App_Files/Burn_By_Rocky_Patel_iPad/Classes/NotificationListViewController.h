//
//  NotificationListViewController.h
//  CigarBoss_Free
//
//  Created by jin on 12/28/12.
//
//

#import <UIKit/UIKit.h>

@interface NotificationListViewController : UIViewController
{
    IBOutlet UITableView        *mTableView;
    
}

@property (nonatomic, retain) NSMutableArray        *mNotificationList;

@end
