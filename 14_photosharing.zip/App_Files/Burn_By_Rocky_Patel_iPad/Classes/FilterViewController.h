//
//  FilterViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FilterViewController : UIViewController {
	IBOutlet UITableView *mainTableView;
	id appDelegate;
	NSMutableArray *allCigarsArray;
}

@end
