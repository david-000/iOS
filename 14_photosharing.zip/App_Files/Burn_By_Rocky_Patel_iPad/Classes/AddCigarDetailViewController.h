//
//  AddCigarDetailViewController.h
//  CigarBoss
//
//  Created by Nitin on 14/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
//@class Cigar;
#import "Cigar.h"
#import "BrandsViewController.h"
#import "CustomImagePickerController.h"

@interface AddCigarDetailViewController : UIViewController<UITextFieldDelegate,UIScrollViewDelegate,UITextViewDelegate,UISplitViewControllerDelegate, UIImagePickerControllerDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    IBOutlet UIScrollView *scrollView;
    IBOutlet UILabel *lblname;
    IBOutlet UIButton *btnDone;
    IBOutlet UILabel *lblAtt;
    
    IBOutlet UIImageView *imgCigarView;
    CustomImagePickerController *imagePickerController;
    
    
    IBOutlet UITextField *txtName;
    IBOutlet UITextField *txtBrand;
    IBOutlet UITextField *txtCigar;
    IBOutlet UITextField *txtPrice;
    IBOutlet UITextField *txtOrigin;
    IBOutlet UITextField *txtCountry;
    IBOutlet UITextField *txtRing;
    IBOutlet UITextField *txtLength;
    IBOutlet UITextField *txtStrenth;
    IBOutlet UITextView *txtDesc;
    
    BrandsViewController *ParentObj;
    NSString *savedImagePath;
    Cigar *cigar;
    
    UIPopoverController *popOverController;
}

@property (nonatomic,assign)  BrandsViewController *ParentObj;
@property (nonatomic, retain) UIPopoverController *popOverController;

-(IBAction)OnbtnDoneClick:(id)sender;
- (IBAction)UploadImage;
- (void)AddCigarwriteToPlist;
-(IBAction)closeView;

- (UIImage *)scaleAndRotateImage:(UIImage *)image;
- (void)thumbWithSideOfLength:(NSString*)strImgName;
-(NSString *)applicationDocumentsDirectory;

@end
