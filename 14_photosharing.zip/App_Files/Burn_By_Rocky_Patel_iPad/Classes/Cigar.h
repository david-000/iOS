//
//  Cigar.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Cigar : NSObject {
	NSString *brand;
	NSString *pictureURL;
	NSString *type;
	NSString *boxprice;
	NSString *price;
	NSString *length;
	NSString *ring;
	NSString *strength;
	NSString *country;
	NSString *wrapper;
	NSString *origin;
	NSString *leaf;
	NSString *generalInfo;
	NSMutableArray *reviews;
    NSString *newCigar;
    NSString *brandId;
    NSString *cuban;
    NSString *twit;
    NSInteger isSpecial;
    NSString *specialStr;
    NSInteger isStaffFavorite;
    NSString *staffFavoriteStr;
    NSInteger isOutOfStock;
    NSString *outOfStockStr;
    NSInteger isDeleted;
    NSInteger isFeaturedCigar;
    NSInteger isMyCigar;
}

@property (nonatomic, copy) NSString *brand;
@property (nonatomic, copy) NSString *pictureURL;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *boxprice;
@property (nonatomic, copy) NSString *price;
@property (nonatomic, copy) NSString *length;
@property (nonatomic, copy) NSString *ring;
@property (nonatomic, copy) NSString *strength;
@property (nonatomic, copy) NSString *country;
@property (nonatomic, copy) NSString *wrapper;
@property (nonatomic, copy) NSString *origin;
@property (nonatomic, copy) NSString *leaf;
@property (nonatomic, copy) NSString *generalInfo;
@property (nonatomic, assign) NSMutableArray *reviews;
@property (nonatomic, copy) NSString *newCigar;
@property (nonatomic, copy) NSString *brandId;
@property (nonatomic, copy) NSString *cuban;    
@property (nonatomic, copy) NSString *twit;
@property (nonatomic) NSInteger isSpecial;
@property (nonatomic, copy) NSString *specialStr;
@property (nonatomic) NSInteger isStaffFavorite;
@property (nonatomic, copy) NSString *staffFavoriteStr;
@property (nonatomic) NSInteger isOutOfStock;
@property (nonatomic, copy) NSString *outOfStockStr;
@property (nonatomic) NSInteger isDeleted;
@property (nonatomic) NSInteger isFeaturedCigar;
@property (nonatomic) NSInteger isMyCigar;

@end
