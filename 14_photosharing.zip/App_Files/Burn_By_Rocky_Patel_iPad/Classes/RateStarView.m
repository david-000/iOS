//
//  RateStarView.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "CigarBossAppDelegate.h"
#import "RateStarView.h"


@implementation RateStarView

@synthesize cigar;
@synthesize shop;
@synthesize forShops;
@synthesize test;
@synthesize rating;

- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
		forShops = NO;
        // Initialization code
		stars = [[NSMutableArray alloc] initWithCapacity:5];
		rating = 0;
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
	self = [super initWithCoder:aDecoder];
	
	stars = [[NSMutableArray alloc] initWithCapacity:5];
	rating = 0;
	
	return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
	self.backgroundColor = [UIColor clearColor];
    
	for(int i = 0; i < 5; i++){
		CGRect frame = CGRectMake(i*30, 0, 30, 30);
		UIImageView *star = [[UIImageView alloc] initWithFrame:frame];
		star.image = [UIImage imageNamed:@"ReviewStarsOutline88x88.png"];
		[self addSubview:star];
		[stars addObject:star];
	}
	//NSLog(@">>>>>>>>>>> ratting value in RateStar View: %d", rating);
	for(UIImageView *image in stars)
    {        
		if(image.frame.origin.x <= ((rating-1)*33)+5){
			image.image = [UIImage imageNamed:@"ReviewStars88x88.png"];
		} else {
			image.image = [UIImage imageNamed:@"ReviewStarsOutline88x88.png"];
		}
	}
    
    if(test < 6 && !forShops)
    {
        for(UIImageView *image in stars)
        {        
            if(image.frame.origin.x <= ((test-1)*33)+5){
                image.image = [UIImage imageNamed:@"ReviewStars88x88.png"];
            } else {
                image.image = [UIImage imageNamed:@"ReviewStarsOutline88x88.png"];
            }
        }   
    }
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	//[self.superview setUserInteractionEnabled:NO];
	UITouch *touch = [touches anyObject];
	rating = floor([touch locationInView:self].x/33.0) + 1;
	for(UIImageView *image in stars){
		if(image.frame.origin.x <= ((rating-1)*33)+5){
			image.image = [UIImage imageNamed:@"ReviewStars88x88.png"];
		} else {
			image.image = [UIImage imageNamed:@"ReviewStarsOutline88x88.png"];
		}
	}
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch *touch = [touches anyObject];
	rating = floor([touch locationInView:self].x/33.0) + 1;
	for(UIImageView *image in stars){
		if(image.frame.origin.x <= ((rating-1)*33)){
			image.image = [UIImage imageNamed:@"ReviewStars88x88.png"];
		} else {
			image.image = [UIImage imageNamed:@"ReviewStarsOutline88x88.png"];
		}
	}
    
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	//[self.superview setUserInteractionEnabled:YES];
	CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
	
	if(forShops){
		NSMutableArray *cigarArray = [appDelegate findFavoriteShop:[shop objectForKey:@"id"]];
		if(cigarArray){
			/*NSArray *oArray = cigarArray;
			 cigarArray = [[NSMutableArray alloc] initWithCapacity:2];
			 [cigarArray addObject:cigar];
			 [cigarArray addObject:[NSString stringWithFormat:@"%d", rating]];
			 [appDelegate addFavorite:cigarArray];
			 [[appDelegate ratings] replaceObjectAtIndex:[[appDelegate ratings] indexOfObject:oArray] withObject:cigarArray];
			 */[cigarArray replaceObjectAtIndex:1 withObject:[NSString stringWithFormat:@"%d", rating]];
			[appDelegate saveData];
			[appDelegate saveFavoriteShops];
		} else {
			cigarArray = [[NSMutableArray alloc] initWithCapacity:2];
			[cigarArray addObject:shop];
			[cigarArray addObject:[NSString stringWithFormat:@"%d", rating]];
			NSMutableArray *shops = [appDelegate favoriteShops];
			[shops addObject:cigarArray];
			[appDelegate saveFavoriteShops];
		}
		return;
	}
	
	NSMutableArray *cigarArray = [appDelegate findCigarMatch:self.cigar];
	if(cigarArray){
		/*NSArray *oArray = cigarArray;
		cigarArray = [[NSMutableArray alloc] initWithCapacity:2];
		[cigarArray addObject:cigar];
		[cigarArray addObject:[NSString stringWithFormat:@"%d", rating]];
		[appDelegate addFavorite:cigarArray];
		[[appDelegate ratings] replaceObjectAtIndex:[[appDelegate ratings] indexOfObject:oArray] withObject:cigarArray];
		*/[cigarArray replaceObjectAtIndex:1 withObject:[NSString stringWithFormat:@"%d", rating]];
		[appDelegate saveData];
	} else {
		cigarArray = [[NSMutableArray alloc] initWithCapacity:2];
		[cigarArray addObject:cigar];
		[cigarArray addObject:[NSString stringWithFormat:@"%d", rating]];
		[appDelegate addFavorite:cigarArray];
		[appDelegate saveData];
	}
}

- (void)dealloc {
    [super dealloc];
}


@end
