//
//  EventData.m
//  CigarBoss_PRO
//
//  Created by jin on 11/27/12.
//
//

#import "EventData.h"

@implementation EventData
@synthesize mEventId;
@synthesize mTitle;
@synthesize mDate;
@synthesize mFrom;
@synthesize mTo;
@synthesize mDescription;
@synthesize mNSDate;
@synthesize mStartDate;
@synthesize mEndDate;

@end
