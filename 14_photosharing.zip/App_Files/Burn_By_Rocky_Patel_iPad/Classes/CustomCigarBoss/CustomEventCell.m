//
//  CustomEventCell.m
//  CigarBoss_PRO
//
//  Created by jin on 11/30/12.
//
//

#import "CustomEventCell.h"
#import "EventData.h"

@implementation CustomEventCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setCellData : (EventData *) data
{
    NSDateFormatter *fmt = [[[NSDateFormatter alloc] init] autorelease];
    [fmt setDateFormat:@"MM/dd/yyyy"];
    
    mTitleLabel.text = data.mTitle;
    mDateLabel.text = [fmt stringFromDate:data.mNSDate];
    
    [fmt setDateFormat:@"hh:mm"];
    mTimeLabel.text = [NSString stringWithFormat:@"%@ ~ %@", [fmt stringFromDate:data.mStartDate], [fmt stringFromDate:data.mEndDate]];
    
    NSString *description = [NSString stringWithFormat:@"%@", data.mDescription];
    CGSize labelSize = [description sizeWithFont:[UIFont systemFontOfSize:16] constrainedToSize:CGSizeMake(650, MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
    mDescription.numberOfLines = 0;
    mDescription.frame = CGRectMake(mDescription.frame.origin.x, 118, 650, labelSize.height);
    
    mDescription.text = description;
}

@end
