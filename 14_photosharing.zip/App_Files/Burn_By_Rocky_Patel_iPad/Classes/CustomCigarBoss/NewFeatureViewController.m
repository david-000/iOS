//
//  CigarsViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "NewFeatureViewController.h"
#import "CigarBossAppDelegate.h"
#import "Cigar.h"
#import "CustomHighlightedCell.h"
#import "CigarViewController.h"
#import "SearchingOverlayView.h"
#import "SearchResultsObject.h"


CigarBossAppDelegate *appDelegate;

@implementation NewFeatureViewController

@synthesize cigars, showType;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
- (id)initWithCoder:(NSCoder *)aDecoder
{
	self = [super initWithCoder:aDecoder];
	
	searchingTableView = nil;
	searchResultsDataSource = [[SearchResultsObject alloc] init];
	searchResultsDataSource.parent = self;
	
	already = NO;
	return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

    searching = FALSE;
    
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, 703, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    
    if ( showType == 0 ) {
        titleLabel.text =@"Staff Favorites";
    } else if ( showType == 1 ) {
        titleLabel.text = @"Specials";
    }
    
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:20.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];

    appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
    
    mainTableView.tableHeaderView = mTopView;
    
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 748)];
	bgView.image = [UIImage imageNamed:@"right_side.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
}


- (int)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (int)tableView:(UITableView *)tableView numberOfRowsInSection:(int)section
{
    if (searching) {
        return [matchedStates count];
    }else{
        return [cigars count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BrandCell"];
	
	if(cell == nil){
		cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"BrandCell"] autorelease];
	}
    
    if (searching) {
        
        Cigar *cigar = [matchedStates objectAtIndex:indexPath.row];

        if ( showType == 0 )
            cell.textLabel.text = [NSString stringWithFormat:@"%@ %@ - %@", cigar.brand, cigar.type, cigar.staffFavoriteStr];
        else if ( showType == 1 ) {
            cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", cigar.brand, cigar.type];
        } else if ( showType == 2 ) {
            cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", cigar.brand, cigar.type];
        } else if ( showType == 3 ) {
            cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", cigar.brand, cigar.type];
        }
        
        return cell;

    } else {
        
        Cigar *cigar = [cigars objectAtIndex:indexPath.row];

        cell.textLabel.textColor = [UIColor whiteColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        if ( showType == 0 )
            cell.textLabel.text = [NSString stringWithFormat:@"%@ %@ - %@", cigar.brand, cigar.type, cigar.staffFavoriteStr];
        else if ( showType == 1 ) {
            cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", cigar.brand, cigar.type];
            cell.detailTextLabel.font = [UIFont fontWithName:@"Copperplate" size:20.0];
            cell.detailTextLabel.text = cigar.specialStr;
        } else if ( showType == 2 ) {
            cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", cigar.brand, cigar.type];
        } else {
            cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", cigar.brand, cigar.type];
        }
        
        cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:20];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        return cell;
        
    }
	
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (searching) {
        
        CigarViewController *c = [[CigarViewController alloc] initWithNibName:@"CigarViewController" bundle:nil];
        c.cigar = [matchedStates objectAtIndex:indexPath.row];
        self.navigationItem.title=@"Back";
        [self.navigationController pushViewController:c animated:YES];

    } else {

        CigarViewController *c = [[CigarViewController alloc] initWithNibName:@"CigarViewController" bundle:[NSBundle mainBundle]];
        c.cigar = [cigars objectAtIndex:indexPath.row];
        c.isUpdate = YES;
        self.navigationItem.title=@"Back";
        [self.navigationController pushViewController:c animated:YES];

    }
}



#pragma mark -
#pragma mark UIsearch Delegate

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
	if(already) return;
	already = YES;
    searching  = TRUE;
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(closeSearch)];
	searchingOverlayView = [[SearchingOverlayView alloc] initWithFrame:CGRectMake(0, 44, 703, 704)];
	[self.view addSubview:searchingOverlayView];
	searchingOverlayView.parent = self;
    [searchingOverlayView release];
	mainTableView.scrollEnabled = NO;
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar {
    [self performSelector:@selector(closeSearch)];
}

- (void)closeSearch
{
	already = NO;
    searching = FALSE;
    
	self.navigationItem.rightBarButtonItem = nil;
    
	[searchingOverlayView removeFromSuperview];
	[searchBar resignFirstResponder];
	if([searchBar.text length] != 0) [searchingTableView removeFromSuperview];
	[searchBar removeFromSuperview];
	searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, 703, 44)];
	searchBar.delegate = self;
    
	mainTableView.tableHeaderView = searchBar;
	mainTableView.scrollEnabled = YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
	if([searchText length] == 0){
        
		if(searchingTableView){
			[searchingTableView removeFromSuperview];
		}

	} else {
        
		if(matchedStates){
			[matchedStates release];
			matchedStates = nil;
		}
		
		matchedStates = [[NSMutableArray alloc] init];
		
        for ( Cigar *cigar in cigars) {
            
			NSRange titleResultsRange = [cigar.brand rangeOfString:searchText options:NSCaseInsensitiveSearch];

			if(titleResultsRange.length > 0){
				[matchedStates addObject:cigar];
			}
        
        }
		        
		if(!searchingTableView)
		{
			searchingTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 44, 703, 310) style:UITableViewStylePlain];
			searchingTableView.delegate = self;
			searchingTableView.dataSource = self;
		}
		
		if(searchingTableView.superview != self.view){
			[self.view addSubview:searchingTableView];
		}
		
		[searchingTableView reloadData];
	}
}


-(void)viewDidAppear:(BOOL)animated
{
    if(AppDelegate.adStatus)
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 614)];
    }
    else
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 704)];
    }
    
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [cigars release];
    [super dealloc];
}


@end
