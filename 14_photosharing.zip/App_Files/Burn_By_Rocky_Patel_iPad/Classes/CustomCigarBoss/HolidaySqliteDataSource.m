/*
 * Copyright (c) 2009 Keith Lazuka
 * License: http://www.opensource.org/licenses/mit-license.html
 */

#import <sqlite3.h>

#import "HolidaySqliteDataSource.h"
#import "Holiday.h"
#import "EventData.h"
#import "Base64.h"
#import <EventKit/EventKit.h>

static BOOL IsDateBetweenInclusive(NSDate *date, NSDate *begin, NSDate *end)
{
  return [date compare:begin] != NSOrderedAscending && [date compare:end] != NSOrderedDescending;
}

@interface HolidaySqliteDataSource ()
- (NSArray *)holidaysFrom:(NSDate *)fromDate to:(NSDate *)toDate;
@end

@implementation HolidaySqliteDataSource

+ (HolidaySqliteDataSource *)dataSource
{
  return [[[[self class] alloc] init] autorelease];
}

- (id)init
{
  if ((self = [super init])) {
    items = [[NSMutableArray alloc] init];
    holidays = [[NSMutableArray alloc] init];
  }
  return self;
}

- (Holiday *)holidayAtIndexPath:(NSIndexPath *)indexPath
{
  return [items objectAtIndex:indexPath.row];
}

- (EventData *)holidayAtEventId:(NSInteger)event_id
{
    for ( EventData *event in items ) {
        if ( event.mEventId == event_id )
            return event;
    }
    
    return nil;
}

#pragma mark UITableViewDataSource protocol conformance

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSString *CellIdentifier = [NSString stringWithFormat:@"Cell%d-%d", indexPath.section, indexPath.row];
    
    CustomEventCell *customCell;
    
    customCell = (CustomEventCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if ( customCell == nil ) {
        
        NSArray *arrayObject = [[NSBundle mainBundle] loadNibNamed:@"CustomEventCell" owner:self options:nil];
        customCell = [arrayObject objectAtIndex:0];
        
        [customCell setCellData:[items objectAtIndex:indexPath.row]];
    }
    
 	return customCell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [items count];
}

#pragma mark Sqlite access

- (NSString *)databasePath
{
  return [[NSBundle mainBundle] pathForResource:@"holidays" ofType:@"db"];
}

- (void)loadHolidaysFrom:(NSDate *)fromDate to:(NSDate *)toDate delegate:(id<KalDataSourceCallbacks>)delegate
{
    NSLog(@"Fetching holidays from the database between %@ and %@...", fromDate, toDate);
	sqlite3 *db;
    NSDateFormatter *fmt = [[[NSDateFormatter alloc] init] autorelease];
  
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0];

    NSString* databasePath = [documentsPath stringByAppendingPathComponent:@"brand.sqlite"];

    
	if(sqlite3_open([databasePath UTF8String], &db) == SQLITE_OK) {
        
            const char *sql = "select * from tbl_event where event_date between ? and ?";
        
            sqlite3_stmt *stmt;
            if(sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) == SQLITE_OK) {
                
                [fmt setDateFormat:@"yyyy-MM-dd hh:mm:ss"];
                
                sqlite3_bind_text(stmt, 1, [[fmt stringFromDate:fromDate] UTF8String], -1, SQLITE_STATIC);
                sqlite3_bind_text(stmt, 2, [[fmt stringFromDate:toDate] UTF8String], -1, SQLITE_STATIC);
                
                while(sqlite3_step(stmt) == SQLITE_ROW) {
                    
                    EventData *eventData = [[EventData alloc] init];
                    
                    eventData.mEventId = sqlite3_column_int(stmt, 0);
                    eventData.mTitle = [[NSString alloc] initWithData:[Base64 decode:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 1)]] encoding:NSUTF8StringEncoding];
                    eventData.mDate = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 2)];
                    eventData.mFrom = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 3)];
                    eventData.mTo = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 4)];
                    eventData.mDescription = [[NSString alloc] initWithData:[Base64 decode:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 5)]] encoding:NSUTF8StringEncoding];
                    
                    [fmt setDateFormat:@"yyyy-MM-dd"];
                    eventData.mNSDate = [fmt dateFromString:eventData.mDate];
                    
                    [fmt setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                    eventData.mStartDate = [fmt dateFromString:[NSString stringWithFormat:@"%@ %@", eventData.mDate, eventData.mFrom]];
                    eventData.mEndDate = [fmt dateFromString:[NSString stringWithFormat:@"%@ %@", eventData.mDate, eventData.mTo]];
                    [holidays addObject:eventData];
			}
		}
        
		sqlite3_finalize(stmt);
	}
    
	sqlite3_close(db);
    [delegate loadedDataSource:self];
}

#pragma mark KalDataSource protocol conformance

- (void)presentingDatesFrom:(NSDate *)fromDate to:(NSDate *)toDate delegate:(id<KalDataSourceCallbacks>)delegate
{
  [holidays removeAllObjects];
  [self loadHolidaysFrom:fromDate to:toDate delegate:delegate];
}

- (NSArray *)markedDatesFrom:(NSDate *)fromDate to:(NSDate *)toDate
{
  return [[self holidaysFrom:fromDate to:toDate] valueForKeyPath:@"mNSDate"];
}

- (void)loadItemsFromDate:(NSDate *)fromDate toDate:(NSDate *)toDate
{
  [items addObjectsFromArray:[self holidaysFrom:fromDate to:toDate]];
}

- (void)removeAllItems
{
  [items removeAllObjects];
}

#pragma mark -

- (NSArray *)holidaysFrom:(NSDate *)fromDate to:(NSDate *)toDate
{
  NSMutableArray *matches = [NSMutableArray array];
  for (EventData *eventData in holidays)
    if (IsDateBetweenInclusive(eventData.mStartDate, fromDate, toDate))
      [matches addObject:eventData];
  
  return matches;
}

- (void)dealloc
{
  [items release];
  [holidays release];
  [super dealloc];
}

@end
