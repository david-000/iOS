//
//  NSObject+NotifyData.h
//  CigarBoss_Free
//
//  Created by jin on 12/28/12.
//
//

#import <Foundation/Foundation.h>

@interface NotifyData : NSObject
{

}

@property (nonatomic) NSInteger          mNotifyId;
@property (nonatomic, retain) NSString  *mNotifyMsg;
@property (nonatomic, retain) NSDate    *mNotifyDate;
@property (nonatomic, retain) NSString  *mNotifyDateStr;

@end
