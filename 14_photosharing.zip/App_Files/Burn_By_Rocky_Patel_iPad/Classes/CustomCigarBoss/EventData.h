//
//  EventData.h
//  CigarBoss_PRO
//
//  Created by jin on 11/27/12.
//
//

#import <Foundation/Foundation.h>

@interface EventData : NSObject
{
    
}

@property (nonatomic)   NSInteger       mEventId;
@property (nonatomic, retain) NSString  *mTitle;
@property (nonatomic, retain) NSString  *mDate;
@property (nonatomic, retain) NSString  *mFrom;
@property (nonatomic, retain) NSString  *mTo;
@property (nonatomic, retain) NSString  *mDescription;
@property (nonatomic, retain) NSDate    *mNSDate;
@property (nonatomic, retain) NSDate    *mStartDate;
@property (nonatomic, retain) NSDate    *mEndDate;
@end
