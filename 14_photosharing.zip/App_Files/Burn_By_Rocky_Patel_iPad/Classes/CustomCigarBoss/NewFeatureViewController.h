//
//  NewFeatureViewController.h
//  CigarBoss_PRO
//
//  Created by jin on 11/25/12.
//
//

#import <UIKit/UIKit.h>
#import "CategoryListViewController.h"

@interface NSString (trimLeadingWhitespace)
-(NSString*)stringByTrimmingLeadingWhitespace;
@end

@implementation NSString (trimLeadingWhitespace)
-(NSString*)stringByTrimmingLeadingWhitespace {
    NSInteger i = 0;
	
    while ([[NSCharacterSet whitespaceCharacterSet] characterIsMember:[self characterAtIndex:i]]) {
        i++;
    }
	
	while([[NSCharacterSet newlineCharacterSet] characterIsMember:[self characterAtIndex:i]]){
		i++;
	}
    return [self substringFromIndex:i];
}
@end

@class SearchResultsObject;
@class SearchingOverlayView;

@interface NewFeatureViewController : UIViewController<UISearchBarDelegate, UITableViewDelegate, UITableViewDataSource> {
	IBOutlet UITableView    *mainTableView;
	IBOutlet UIView         *mTopView;
	NSArray                 *cigars;
	id                      appDelegate;

    IBOutlet UISearchBar    *searchBar;
    UITableView             *searchingTableView;
    NSMutableArray          *matchedStates;
    
    SearchResultsObject     *searchResultsDataSource;
	SearchingOverlayView    *searchingOverlayView;
    BOOL                    already;
    BOOL                    searching;
    
    NSInteger               showType;
}

@property (nonatomic, assign) NSArray *cigars;
@property (nonatomic) NSInteger showType;

@end
