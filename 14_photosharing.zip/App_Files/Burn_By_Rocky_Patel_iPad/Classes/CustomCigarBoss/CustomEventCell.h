//
//  CustomEventCell.h
//  CigarBoss_PRO
//
//  Created by jin on 11/30/12.
//
//

#import <UIKit/UIKit.h>
#import "EventData.h"

@interface CustomEventCell : UITableViewCell
{
    IBOutlet UILabel           *mTitleLabel;
    IBOutlet UILabel           *mDateLabel;
    IBOutlet UILabel           *mTimeLabel;
    IBOutlet UILabel           *mDescription;
}

- (void)setCellData : (EventData *) data;

@end
