//
//  SelectedButton.h
//  CigarBoss_PRO
//
//  Created by jin on 12/1/12.
//
//

#import <UIKit/UIKit.h>

@interface SelectedButton : UIButton

@property (nonatomic)  BOOL     mSelected;
@end
