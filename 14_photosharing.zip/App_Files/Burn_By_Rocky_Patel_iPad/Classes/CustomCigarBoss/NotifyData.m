//
//  NSObject+NotifyData.m
//  CigarBoss_Free
//
//  Created by jin on 12/28/12.
//
//

#import "NotifyData.h"

@implementation NotifyData
@synthesize mNotifyId;
@synthesize mNotifyMsg;
@synthesize mNotifyDate;

@end
