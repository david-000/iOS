//
//  FillReviewFormViewController.h
//  CigarBoss
//
//  Created by Nitin on 20/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageViewiPhone.h"
#import "CustomImagePickerController.h"

@class CigarViewController;
@class MyClass;
@class Cigar;
@class CigarViewController;

@interface FillReviewFormViewController : UIViewController<UISplitViewControllerDelegate, UIImagePickerControllerDelegate,UIActionSheetDelegate,UINavigationControllerDelegate,UITextFieldDelegate,UITextViewDelegate,UITextViewDelegate>
{
    IBOutlet UITextField *txtstarRate;
    IBOutlet UITextField *txtDateSmoke;
    IBOutlet UITextField *txtPricePaid;
    IBOutlet UITextField *txtHeadline;
//    IBOutlet UITextField *txtRenote;
    IBOutlet UITextField *txtRate;
    
    IBOutlet UITextView *txtRenote;
    
    IBOutlet UIScrollView *scrollView;
    IBOutlet UIButton *btnDone;
    IBOutlet UIButton *btnImage;
    
    IBOutlet UIDatePicker *datePicker;
    IBOutlet UILabel *datePickerLabel;
    
    MyClass *viewThatClosesDatEPicker;
    
    CigarViewController *callingViewController;
    
    IBOutlet UIImageView *imgUpload;
    CustomImagePickerController *imagePickerController;
    IBOutlet UIButton *btnUpload;
    
    NSString *strBarcodeid;
	NSMutableData *webData;
	NSXMLParser *xmlParser;
	NSString *element;
    
    
    IBOutlet UIButton *s1;
    IBOutlet UIButton *s2;
    IBOutlet UIButton *s3;
    IBOutlet UIButton *s4;
    IBOutlet UIButton *s5;
    
    NSUserDefaults *UserMail;
    
    NSUserDefaults *UserName;
    int rateStarValue;
 
    
    NSString *brandId;
    NSString *type;
 NSString *brandName;
    //=========
    
    UIView *loadView;
    UIView *viewBack;

    IBOutlet UIActivityIndicatorView * activityView;
    
    
    
    
}
//#define soapAction @"http://logisticinfotech.com/client/webservicecigar/soap-server.php"
//#define xmlns @"http://logisticinfotech.com/soap/cigarboss"
//http://logisticinfotech.com/client/webservicecigar/soap-server.php


//#define soapAction @"http://logisticinfotech.com/client/webservicecigar/soap-server.php"
//#define xmlns @"http://logisticinfotech.com/soap/cigarboss"


#define soapAction @"http://cigarboss.co/webservice/soap-server.php"

#define xmlns @"http://cigarboss.co/soap/cigarboss"


@property(nonatomic,retain)  UIActivityIndicatorView * activityView;

@property (nonatomic, assign) CigarViewController *callingViewController;

@property (nonatomic,retain) NSString *brandId;
@property (nonatomic,retain) NSString *type;
@property (nonatomic,retain) NSString *brandName;
- (IBAction)openDatePicker;

- (void)closeDatePicker;

- (IBAction)UploadImage;
- (NSData *)dataFromBase64String:(NSString *)aString;
- (NSString *)base64EncodedString:(NSData *)nsdata1;
- (NSString *)getStringFromImage:(UIImage *)image;

char *NewBase64Encode(
					  const void *inputBuffer,
					  size_t length,
					  bool separateLines,
					  size_t *outputLength);
-(IBAction)CallWebService;

-(IBAction)onStarButtonClick:(id)sender;
-(NSString *)applicationDocumentsDirectory;
-(void)setParent:(id)sender;
-(void)waitUntillImageCaptured:(UIImage *)originalImage;
- (void)thumbWithSideOfLength:(NSString*)strImgName;

-(IBAction)closeView:(id)sender;

@end
