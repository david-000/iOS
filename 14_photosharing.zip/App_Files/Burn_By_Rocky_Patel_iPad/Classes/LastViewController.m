//
//  LastViewController.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 8/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LastViewController.h"
#import "CustomHighlightedCell.h"
#import "StoreViewController.h"
#import "CigarBossAppDelegate.h"


@implementation LastViewController
@synthesize preferredShops;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        //NSArray *sortedStates = [statesArray sortedArrayUsingSelector:@selector(compare:)];
        
        CigarBossAppDelegate *appDelegate = (CigarBossAppDelegate *)[[UIApplication sharedApplication] delegate];
        self.preferredShops = appDelegate.preferredStores;
        indexes = [[NSMutableDictionary alloc] init];
        
        for(NSDictionary *state in preferredShops){
            NSString *firstLetter = [state objectForKey:@"state"];
            NSMutableArray *existingArray;
            if((existingArray = [indexes valueForKey:firstLetter])){
                [existingArray addObject:state];
            } else {
                NSMutableArray *tempArray = [NSMutableArray array];
                [indexes setObject:tempArray forKey:firstLetter];
                [tempArray addObject:state];
            }
        }
        if(!preferredShops || [preferredShops count] == 0) [self tryPinsAgain]; else
            keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
        
       // NSLog([indexes description]);
        
        
        return self;
    }
    return self;
}

- (void)tryPinsAgain
{
	preferredShops = [[[UIApplication sharedApplication] delegate] preferredStores];
	if([preferredShops count] == 0 || !preferredShops){
		[NSTimer scheduledTimerWithTimeInterval:1.24 target:self selector:@selector(tryPinsAgain) userInfo:nil repeats:NO];
	} else {
        for(NSDictionary *state in preferredShops){
            NSString *firstLetter = [state objectForKey:@"state"];
            NSMutableArray *existingArray;
            if((existingArray = [indexes valueForKey:firstLetter])){
                [existingArray addObject:state];
            } else {
                NSMutableArray *tempArray = [NSMutableArray array];
                [indexes setObject:tempArray forKey:firstLetter];
                [tempArray addObject:state];
            }
        }
        
        keys = [[[indexes allKeys] sortedArrayUsingSelector:@selector(compare:)] retain];
        
        [mainTableView reloadData];
    }
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = @"Preferred Shops";
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 703, 30)];
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.textAlignment = UITextAlignmentCenter;
    titleLabel.text =self.title; 
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate" size:22.0];
    titleLabel.minimumFontSize = 10;
    titleLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
//    titleLabel.adjustsFontSizeToFitWidth = YES;
    self.navigationItem.titleView = titleLabel;
    [titleLabel release];
    mainTableView.backgroundColor = [UIColor clearColor];
	mainTableView.separatorColor = [UIColor colorWithWhite:.4 alpha:.4];
	UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 748)];
	bgView.image = [UIImage imageNamed:@"right_side.png"];
	[self.view addSubview:bgView];
	[self.view sendSubviewToBack:bgView];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    if(AppDelegate.adStatus)
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 614)];
    }
    else
    {
        [mainTableView setFrame:CGRectMake(0, 0, 703, 704)];        
    }
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [keys count];
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return nil;
    return keys;
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
    return index;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *correctKey = [keys objectAtIndex:section];
    NSArray *arrayForThisSection = [indexes objectForKey:correctKey];
    return [arrayForThisSection count];
    //return 0;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [keys objectAtIndex:section];
}

- (void)tableView:(UITableView *)t didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    StoreViewController *sView = [[StoreViewController alloc] initWithNibName:@"StoreViewController" bundle:[NSBundle mainBundle]];
    
    NSString *correctKey = [keys objectAtIndex:indexPath.section];
    NSArray *arrayForThisSection = [indexes objectForKey:correctKey];
    sView.newCigar = [arrayForThisSection objectAtIndex:indexPath.row];
    self.navigationItem.title=@"Back";
    [self.navigationController pushViewController:sView animated:YES];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[CustomHighlightedCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    // Configure the cell.
    NSString *correctKey = [keys objectAtIndex:indexPath.section];
    NSArray *arrayForThisSection = [indexes objectForKey:correctKey];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.detailTextLabel.textColor = [UIColor whiteColor];
    NSString *address = [[arrayForThisSection objectAtIndex:indexPath.row] objectForKey:@"address"];
    cell.detailTextLabel.text = address;
    @try {
        NSArray *components = [address componentsSeparatedByString:@","];
        NSString *city = [[components objectAtIndex:1] stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSString *stateAndZip = [components objectAtIndex:2];
        NSArray *stateComponents = [stateAndZip componentsSeparatedByString:@" "];
        NSString *state = [stateComponents objectAtIndex:1];
        //cell.detailTextLabel.text = [[[shops objectAtIndex:indexPath.row] objectAtIndex:0] objectForKey:@"address"];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@, %@", city, state];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
    cell.textLabel.text = [[arrayForThisSection objectAtIndex:indexPath.row] objectForKey:@"name"];
    cell.textLabel.font = [UIFont fontWithName:@"Copperplate" size:22];
    
    return cell;
}
#pragma mark - View lifecycle

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ) || (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (void)dealloc
{
    [indexes release];
    [keys release];
    [preferredShops release];
}

@end
