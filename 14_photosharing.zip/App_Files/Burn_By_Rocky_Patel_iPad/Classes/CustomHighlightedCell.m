//
//  CustomHighlightedCell.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CustomHighlightedCell.h"


@implementation CustomHighlightedCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if ((self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])) {
        // Initialization code
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {

    [super setSelected:selected animated:animated];
	if(selected){
		// Configure the view for the selected state
		UIImageView *bg = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 703, 60)];
		bg.image = [UIImage imageNamed:@"Highlight640x88.png"];
		self.backgroundView = bg;
	} else {
		self.backgroundView = nil;
	}
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    [super setEditing:editing animated:animated];
    UILabel *detailLabel = (UILabel *)[self.contentView viewWithTag:451];
    UILabel *typeLabel = (UILabel *)[self.contentView viewWithTag:450];
    if(detailLabel){
        if(editing){
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:.3];
            detailLabel.alpha = .0;
            typeLabel.frame = CGRectMake(80, 7, 360, 40);
            [[self.contentView viewWithTag:700] setAlpha:1.0];
            [[self.contentView viewWithTag:702] setAlpha:1.0];
            [UIView commitAnimations];
        } else {
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:.3];
            detailLabel.alpha = .9;
            typeLabel.frame = CGRectMake(80, 3, 430, 40);
            [[self.contentView viewWithTag:700] setAlpha:0];
            [[self.contentView viewWithTag:702] setAlpha:0.0];
            [UIView commitAnimations];
        }
    }
}


- (void)dealloc {
    [super dealloc];
}


@end
