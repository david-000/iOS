//
//  DetailViewController.h
//  CigarBoss_PRO
//
//  Created by System Administrator on 5/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryListViewController.h"

@interface DetailViewController : UIViewController<SubstitutableDetailViewController>
{
    UIToolbar                       *mToolBar;
}

@property (nonatomic, retain) IBOutlet UIToolbar *mToolBar;

@end
