//
//  AlertCurrencyPicker.h
//  SalesBell
//
//  Created by Chintan Adatiya on 20/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DatePicker : UIView {
	UIDatePicker *pickerView;
	
}
@property(nonatomic,retain) UIDatePicker *pickerView;

-(void)showDate;
-(void) presentView;
-(void) removeView;
- (void)setObject:(id)sender;

@end
