//
//  CustomImagePickerController.m
//  ATEval2Go
//
//  Created by Frank Jacob on 9/20/12.
//  Copyright (c) 2012 Smarty Ears. All rights reserved.
//

#import "CustomImagePickerController.h"

@implementation CustomImagePickerController

- (BOOL)shouldAutorotate {
	return NO;
}

- (NSUInteger)supportedInterfaceOrientations {
	return UIInterfaceOrientationMaskPortrait;
}

@end
