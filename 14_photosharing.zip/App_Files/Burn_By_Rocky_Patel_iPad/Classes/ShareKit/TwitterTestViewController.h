//
//  TwitterTestViewController.h
//  TwitterTest
//
//  Created by Erwin Zwart on 07-06-11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Twitter/TWTweetComposeViewController.h>

@interface TwitterTestViewController  : UIViewController   {
    
    
}

- (IBAction)shareOnTwitter:(id)sender;
- (void) isComplete:(id)sender;

@end


