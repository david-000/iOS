//
//  RatingView.m
//  YoutubeProject
//
//  Created by Chintan Adatiya on 13/04/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "RatingView.h"


@implementation RatingView


- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
		
		//imgBlank = [UIImage imageNamed:@"ReviewStarsOutline88x88.png"];
		//imgFull = [UIImage imageNamed:@"ReviewStars88x88.png"];
        imgBlank = [UIImage imageNamed:@"starzBlank.png"];
        imgFull = [UIImage imageNamed:@"StarFull1.png"];
		
		UIView *view1 = [[UIView alloc] initWithFrame:CGRectMake(0,0,30,30)];
		view1.clipsToBounds = YES;
		
		imgStarFull1 = [[UIImageView alloc] initWithImage:imgFull];
		imgStarFull1.frame = CGRectMake(-30,0,30,30);
		[view1 addSubview:imgStarFull1];
		
        imgStarBlank1 = [[UIImageView alloc] initWithImage:imgBlank];		
		imgStarBlank1.frame = CGRectMake(0,0,30,30);
		[view1 addSubview:imgStarBlank1];
		
		
		
		UIView *view2 = [[UIView alloc] initWithFrame:CGRectMake(30,0,30,30)];
		view2.clipsToBounds = YES;
		
		imgStarFull2 = [[UIImageView alloc] initWithImage:imgFull];
		imgStarFull2.frame = CGRectMake(-30,0,30,30);
		[view2 addSubview:imgStarFull2];
		
        imgStarBlank2 = [[UIImageView alloc] initWithImage:imgBlank];		
		imgStarBlank2.frame = CGRectMake(0,0,30,30);
		[view2 addSubview:imgStarBlank2];
		
		
		UIView *view3 = [[UIView alloc] initWithFrame:CGRectMake(60,0,30,30)];
		view3.clipsToBounds = YES;
		
		imgStarFull3 = [[UIImageView alloc] initWithImage:imgFull];
		imgStarFull3.frame = CGRectMake(-30,0,30,30);
		[view3 addSubview:imgStarFull3];
		
        imgStarBlank3 = [[UIImageView alloc] initWithImage:imgBlank];		
		imgStarBlank3.frame = CGRectMake(0,0,30,30);
		[view3 addSubview:imgStarBlank3];
		
		
		
		UIView *view4 = [[UIView alloc] initWithFrame:CGRectMake(90,0,30,30)];
		view4.clipsToBounds = YES;
		
		imgStarFull4 = [[UIImageView alloc] initWithImage:imgFull];
		imgStarFull4.frame = CGRectMake(-30,0,30,30);
		[view4 addSubview:imgStarFull4];
		
        imgStarBlank4 = [[UIImageView alloc] initWithImage:imgBlank];		
		imgStarBlank4.frame = CGRectMake(0,0,30,30);
		[view4 addSubview:imgStarBlank4];
		
		
		
		UIView *view5 = [[UIView alloc] initWithFrame:CGRectMake(120,0,30,30)];
		view5.clipsToBounds = YES;
		
		imgStarFull5 = [[UIImageView alloc] initWithImage:imgFull];
		imgStarFull5.frame = CGRectMake(-30,0,30,30);
		[view5 addSubview:imgStarFull5];
		
        imgStarBlank5 = [[UIImageView alloc] initWithImage:imgBlank];		
		imgStarBlank5.frame = CGRectMake(0,0,30,30);
		[view5 addSubview:imgStarBlank5];
		
		
		arrayStarFull = [[NSMutableArray alloc] init];
		[arrayStarFull addObject:imgStarFull1];
		[arrayStarFull addObject:imgStarFull2];
		[arrayStarFull addObject:imgStarFull3];
		[arrayStarFull addObject:imgStarFull4];
		[arrayStarFull addObject:imgStarFull5];
        
        arrayStarBlank = [[NSMutableArray alloc] init];
		[arrayStarBlank addObject:imgStarBlank1];
		[arrayStarBlank addObject:imgStarBlank2];
		[arrayStarBlank addObject:imgStarBlank3];
		[arrayStarBlank addObject:imgStarBlank4];
		[arrayStarBlank addObject:imgStarBlank5];
		
		[self addSubview:view1];
		[self addSubview:view2];
		[self addSubview:view3];
		[self addSubview:view4];
		[self addSubview:view5];
		
    }
	//[self setRating:3.4];
    return self;
}

-(void) setRating:(float)rating {
	
    int fullCount = rating;
	if(rating > 0) {
		for(int i=0;i<fullCount;i++) {
			UIImageView *imgView = [arrayStarFull objectAtIndex:i];
            
			[imgView setFrame:CGRectMake(2.5,0,25,30)];
			[self layoutIfNeeded];
            
//            UIImageView *imgBlankView = [arrayStarBlank objectAtIndex:i];
//            imgBlankView.hidden=YES;
            
		}
		if (fullCount != 5) {
			UIImageView *imgView = [arrayStarFull objectAtIndex:fullCount];
			rating = rating - fullCount;
			int point = round(30*rating)-30;
			//NSLog(@"\n>>>Point : %d",point);
			[imgView setFrame:CGRectMake(5+point,0,25,30)];
		}
	} else {
		for(int i=0;i<5;i++) {
			UIImageView *imgView = [arrayStarFull objectAtIndex:i];
			[imgView setFrame:CGRectMake(-30,0,25,30)];
			[self layoutIfNeeded];
		}
	}
	
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

- (void)dealloc {
    [super dealloc];
}


@end
