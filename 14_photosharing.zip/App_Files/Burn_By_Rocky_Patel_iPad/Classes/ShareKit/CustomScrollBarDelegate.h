

@protocol CustomScrollBarDelegate


@required
- (void)touchesEndedScroll:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesBeganScroll:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesMovedScroll:(NSSet *)touches withEvent:(UIEvent *)event;

@optional
//- (void)didChangeDate:(NSDate *)d;

@end