





#import <UIKit/UIKit.h>
#import "CustomScrollBarDelegate.h"
//@class DataBean;
//@class DetailViewiPhone;
@class CustomScrollBar;

@interface AsyncImageViewiPhone : UIView <UIApplicationDelegate, CustomScrollBarDelegate, UIScrollViewDelegate> {
	
	NSURLConnection* connection; 
	NSMutableData* data; 
	
	UIImageView *image;
	UIImageView* imageView;
	
	UIActivityIndicatorView *scrollingWheel;
		
//	DataBean *objBeanData;
	
	int indexPath;
	int flagSetThumbnail;
    
  //  DetailViewiPhone *objParent;
	
	CustomScrollBar *scroller;
	
	CGRect fullFrame;
	
	BOOL flagShow;
    NSString *imgObj;
	
	float imgWidth, imgHeight;
}

@property (nonatomic, assign) int indexPath;
@property (nonatomic, assign) int flagSetThumbnail;
@property (nonatomic, retain) NSURLConnection *connection;

-(void)loadImageFromURL:(NSURL*)url;
-(void) setObject:(id)sender;
-(UIImage*) image;
-(id) initWithFrame:(CGRect)frame;
- (void)thumbWithSideOfLength:(double)length imageName:(NSString*)strImgName;
-(NSString *)applicationDocumentsDirectory;
-(void) imageFromImagePath : (NSString *) path;
-(void) setBean:(id)sender;
-(void) setViewAnimation:(CGRect)frame;


@end
