
#import "CustomScrollBar.h"

@implementation CustomScrollBar

@synthesize del;

#pragma mark -
#pragma mark Touch Delegate methods 
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
	if ([del respondsToSelector:@selector(touchesBeganScroll:withEvent:)]) {
        [del touchesBeganScroll:touches withEvent:event];
    }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
	if ([del respondsToSelector:@selector(touchesMovedScroll:withEvent:)]) {
        [del touchesMovedScroll:touches withEvent:event];
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
	if ([del respondsToSelector:@selector(touchesEndedScroll:withEvent:)]) {
        [del touchesEndedScroll:touches withEvent:event];
    }	
}

- (void)dealloc {
    [super dealloc];
}


@end
