//
//  RatingView.h
//  YoutubeProject
//
//  Created by Chintan Adatiya on 13/04/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RatingView : UIView {
	UIImageView *imgStarBlank1;
	UIImageView *imgStarBlank2;
	UIImageView *imgStarBlank3;
	UIImageView *imgStarBlank4;
	UIImageView *imgStarBlank5;
	
	UIImageView *imgStarFull1;
	UIImageView *imgStarFull2;
	UIImageView *imgStarFull3;
	UIImageView *imgStarFull4;
	UIImageView *imgStarFull5;
	
	UIImage *imgBlank;
	UIImage *imgFull;
	
	NSMutableArray *arrayStarFull;
	NSMutableArray *arrayStarBlank;
}

-(void) setRating:(float)rating;

@end
