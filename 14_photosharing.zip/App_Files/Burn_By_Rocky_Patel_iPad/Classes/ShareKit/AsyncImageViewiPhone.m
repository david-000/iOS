
#import "AsyncImageViewiPhone.h"
#import <CFNetwork/CFNetwork.h>

#import "CustomScrollBar.h"
#import "ASIHTTPRequest.h"
#import "CigarBossAppDelegate.h"
#import "LargePhotoViewController.h"


@implementation AsyncImageViewiPhone

CigarBossAppDelegate *appDelegate;

@synthesize indexPath;
@synthesize flagSetThumbnail;
@synthesize connection;

//-(void) setObject:(LargePhotoViewController *) obj {
//	objParent = obj;
//}

//-(void) setBean:(DataBean *)obj {
//	objBeanData = obj;
//}

- (id)initWithFrame:(CGRect)frame {
	
    if ((self = [super initWithFrame:frame])) {
		
		self.clipsToBounds = YES;
        
        scroller = [[CustomScrollBar alloc] initWithFrame:self.bounds];
        scroller.maximumZoomScale = 4.0;
        scroller.minimumZoomScale = 1.0;	
        scroller.clipsToBounds = YES;
        
        // a page is the width of the scroll view
        //scroller.backgroundColor = [UIColor redColor];
        scroller.scrollEnabled = YES;
        scroller.multipleTouchEnabled = YES;
        scroller.userInteractionEnabled = YES;
        scroller.showsHorizontalScrollIndicator = YES;
        scroller.showsVerticalScrollIndicator = YES;
        scroller.scrollsToTop = NO;
        scroller.delegate = self;
        scroller.del = self;
        scroller.contentSize = frame.size;
        
        scrollingWheel = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
        appDelegate = (CigarBossAppDelegate *)[UIApplication sharedApplication].delegate;
        float x = self.bounds.size.width/2;
        //float y = (self.bounds.size.height/2)+10;
        float y = (480/2)+10;
        scrollingWheel.center = CGPointMake(x, y);
        scrollingWheel.hidesWhenStopped = YES;
        [scroller addSubview:scrollingWheel];
        [scrollingWheel release];
        
        imageView = [[UIImageView alloc] init];
		[scroller addSubview:imageView];
        [self addSubview:scroller];
    }
    return self;
}

#pragma mark -
#pragma mark image from document Directory

-(void) imageFromImagePath : (NSString *) path {
	
    
	UIImageView *tempimageView = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:path]];
	UIImage *img = [UIImage imageWithContentsOfFile:path];
    
    scroller.frame = self.bounds;
    
    //    if (img != nil) {
    [imageView setBackgroundColor:[UIColor clearColor]];
    [scroller setBackgroundColor:[UIColor clearColor]];
    fullFrame = tempimageView.frame;
    
    //imageView.contentMode = UIViewContentModeScaleAspectFit;	
    imageView.image = img;
    //[scroller addSubview:imageView];
    //[imageView release];
    [scroller bringSubviewToFront:scrollingWheel];
    //[self addSubview:scroller];
    
    
    float expWidth, expHeight, orgWidth, orgHeight;
    
    //orgWidth = tempimageView.frame.size.width;
    orgWidth=320;
    orgHeight = tempimageView.frame.size.height;
    orgHeight=370;
    expWidth = 320;
    expHeight = (orgHeight * expWidth)/orgWidth;
    
    if (expHeight < 460) {
        expHeight = 370;
        expWidth = (orgWidth * expHeight)/orgHeight;
    }
    
    expHeight = 370;
    expWidth = (orgWidth * expHeight)/orgHeight;
    
    if (expWidth < 320) {
        expWidth = 320;
        expHeight = (orgHeight * expWidth)/orgWidth;
    }
    
    [imageView setNeedsLayout];
    [imageView setNeedsDisplay];
    
    [scrollingWheel stopAnimating];
    
    imageView.frame = CGRectMake(0,0,expWidth,expHeight);
    
    //scroller.frame = CGRectMake(0,0,expWidth,expHeight);
    scroller.contentSize = CGSizeMake(expWidth, expHeight);	

    
}

-(void)hideScrollingWheel {
	[scrollingWheel stopAnimating];
}

#pragma mark -
#pragma mark image from Url 
- (void)loadImageFromURL:(NSURL*)url {
	
   // NSLog(@"<<<<<<<<<< URL = %@ and image at :%d",url, indexPath);
	[scrollingWheel startAnimating];
	if (connection!=nil) {
		[connection cancel];
		[connection release];
		connection = nil;
	} 
	if (data!=nil) { 
		[data release];
		data = nil;
	}	
    //	if (imageView != nil) {
    //		[imageView removeFromSuperview];
    //		imageView = nil;
    //	}
	
	if(url == nil)
	{
		[scrollingWheel stopAnimating];
	}
	else {
		NSURLRequest* request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReturnCacheDataElseLoad timeoutInterval:60.0];
		connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	}
}

#pragma mark -
#pragma mark methods for connection
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	
	data = [[NSMutableData data] retain];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)dataObj {
	
	[data appendData:dataObj];
}

- (void) connectionDidFinishLoading:(NSURLConnection *)theConnection {
	
	[connection release];
	connection=nil;
	
    //	if ([[self subviews] count]>0) {
    //		[[[self subviews] objectAtIndex:0] removeFromSuperview]; //so remove it (releases it also)
    //	}
	
	NSString *imageName = [NSString stringWithFormat:@"%d.png", indexPath];
	NSString *imagePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:imageName];
	
	
	if(data != nil) {
        [CigarBossAppDelegate adSkipBackUpAttributeToItemAtURL:imagePath];
		[data writeToFile:imagePath atomically:YES];
		[self thumbWithSideOfLength:0.0 imageName:imageName];
	}
	else
		[[NSFileManager defaultManager] removeItemAtPath:imagePath error:NULL];
    
}

-(void)connection:(NSURLConnection *)theconnection didFailWithError:(NSError *)error {
	
	//NSLog(@"ERROR with theConenction");
	
	[scrollingWheel stopAnimating];
	
	[theconnection release];
	
	[data release];
    
    connection = nil;
    
	return;
}

#pragma mark -
#pragma mark make thumbnail image 
- (void)thumbWithSideOfLength:(double)length imageName:(NSString*)strImgName {
	
    //NSLog(@"\nImageName : %@",strImgName);
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
	
    NSString *fullPathToThumbImage = [documentsDirectory stringByAppendingPathComponent:strImgName];
	
	UIImage *thumbnail;
	
	UIImage *mainImage = [UIImage imageWithContentsOfFile:fullPathToThumbImage];
	
	UIImageView *mainImageView = [[UIImageView alloc] initWithImage:mainImage];
	
	CGRect clippedRect = CGRectMake(0, 0, mainImage.size.width,  mainImage.size.height);
    
	UIGraphicsBeginImageContext(CGSizeMake(mainImage.size.width, mainImage.size.height));
	CGContextRef currentContext = UIGraphicsGetCurrentContext();
	
	CGContextClipToRect( currentContext, clippedRect);
	
	CGFloat scaleFactor = 1.0;
	//this will automatically scale any CGImage down/up to the required thumbnail side (length) when the CGImage gets drawn into the context on the next line of code
	CGContextScaleCTM(currentContext, scaleFactor, scaleFactor);
	
	[mainImageView.layer renderInContext:currentContext];
	
	thumbnail = UIGraphicsGetImageFromCurrentImageContext();
	
	UIGraphicsEndImageContext();
	NSData *imageData = UIImagePNGRepresentation(thumbnail);
	
    [CigarBossAppDelegate adSkipBackUpAttributeToItemAtURL:fullPathToThumbImage];

	[imageData writeToFile:fullPathToThumbImage atomically:YES];
    //NSLog(@"------- Image Data = %@ ",imageData);
    
	NSString *imageName = [NSString stringWithFormat:@"%d.png", indexPath];
	NSString *imagePath = [[self applicationDocumentsDirectory] stringByAppendingPathComponent:imageName];
	[imagePath retain];
    
	[self performSelector:@selector(imageFromImagePath:) withObject:imagePath afterDelay:2.0];
    
}


#pragma mark -
#pragma mark path for Document Directory 
-(NSString *)applicationDocumentsDirectory {
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
	NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
	return basePath;
}

- (UIImage*) image {
	
	UIImageView* iv = [[self subviews] objectAtIndex:0];
	return [iv image];
}

#pragma mark -
#pragma mark scrollView Delegate Methods

-(UIView*)viewForZoomingInScrollView:(UIScrollView *)scrollView {
	return imageView;
}

#pragma mark -
#pragma mark Touch Delegate Methods


- (void)touchesBeganScroll:(NSSet *)touches withEvent:(UIEvent *)event {
	
}

- (void)touchesMovedScroll:(NSSet *)touches withEvent:(UIEvent *)event {
	
}

- (void)touchesEndedScroll:(NSSet *)touches withEvent:(UIEvent *)event {
	
	UITouch *touch = [touches anyObject];
	/*
     if ([touch tapCount] == 1) {
     if ([objParent.flagShow isEqualToString:@"isShown"])) {
     [objParent hideMenus];
     }
     else {
     [objParent showMenus];
     }
     }
     */
	if ([touch tapCount] == 2) {
		if(flagShow) {
			flagShow = FALSE;		
			[scroller setZoomScale:1.0];
			[self setViewAnimation:CGRectMake(20,20,280,330)];
			
		} else {
			flagShow = TRUE;
			[self setViewAnimation:fullFrame];
		}
	}
}

-(void) setViewAnimation:(CGRect)frame {		
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.5];
	
	imageView.frame = frame;
    //imageView.frame = CGRectMake(0, 0, 320, 367);
	scroller.contentSize = frame.size;
	
	[UIView commitAnimations];
}

- (void)dealloc {
	[super dealloc];
}

@end
