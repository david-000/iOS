//
//  CustomScrollBar.h
//  Prayer
//
//  Created by Chintan Adatiya on 08/10/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CustomScrollBarDelegate.h"

@interface CustomScrollBar : UIScrollView {
	@public
	NSObject<CustomScrollBarDelegate> *del;
}

@property (nonatomic, assign) NSObject<CustomScrollBarDelegate> *del;


@end
