//
//  WebViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController {
    IBOutlet UIWebView *webView;
    NSURL *url;
}

@property (nonatomic, copy) NSURL *url;

- (IBAction)close;

@end
