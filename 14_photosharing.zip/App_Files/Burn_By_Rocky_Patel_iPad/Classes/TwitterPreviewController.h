//
//  TwitterPreviewController.h
//  CigarBoss
//
//  Created by Nitin on 16/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomImagePickerController.h"

@interface TwitterPreviewController : UIViewController<UISplitViewControllerDelegate, UIImagePickerControllerDelegate,UIActionSheetDelegate,UINavigationControllerDelegate,UITextViewDelegate>
{
    IBOutlet UIImageView *imgView;
    IBOutlet UIButton *btnAddImage;
    IBOutlet UIButton *btnPreivew;
    NSString *cigarTwit;
    IBOutlet UITextView *textView;
    
    UIImage *capturedImg;
    CustomImagePickerController *imagePickerController;
    UIPopoverController *popOverController;
    id parent;
}
- (IBAction)CallTwitter;
-(IBAction)closeTwit;
@property (nonatomic,retain)NSString *cigarTwit;
@property (nonatomic, retain) UIPopoverController *popOverController;

-(void)setParentObject:(id)sender;

//rotate image
-(UIImage *)scaleAndRotateImage:(UIImage *)image ;
@end
