//
//  AlertCurrencyPicker.m
//  SalesBell
//
//  Created by Chintan Adatiya on 20/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "DatePicker.h"
#import "ViewNoteViewController.h"

@implementation DatePicker

@synthesize pickerView;



ViewNoteViewController *objAddView;

-(void)setObject :(id)sender {
	objAddView = sender;
}

- (DatePicker *) initWithFrame: (CGRect)rect {
	self = [super initWithFrame:rect];

	[self setBackgroundColor:[UIColor colorWithRed:(41.0/255.0) green:(43.0/255.0) blue:(59.0/255.0) alpha:1.0f]];	
	
	UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
	[button setFrame:CGRectMake(260.0f, 225.0f, 50.0f, 30.0f)];
	[button setImage:[UIImage imageNamed:@"done.png"] forState:UIControlStateNormal];
	[button addTarget:self action:@selector(showDate) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:button];
		
	pickerView = [[UIDatePicker alloc] initWithFrame:CGRectMake(0.0f,0.0f,320.0f,280.0f)];
	[self addSubview:pickerView];
	[pickerView setDatePickerMode:UIDatePickerModeDate];
	[pickerView setUserInteractionEnabled:YES];
    [pickerView setMaximumDate:[NSDate date]];
	[pickerView release];

	return self;
}

-(void)showDate {
	
	[objAddView SetDate:pickerView.date];	
}

- (void) removeView {	
	CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
	[UIView setAnimationDuration:0.3];
	
	CGRect rect = [self frame];	
	rect.origin.y = 480.0f;
	[self setFrame:rect];	
	[UIView commitAnimations];
}

- (void) presentView {
	CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:0.4];
    
   
//     [scrollView setContentOffset:CGPointMake(0,50) animated:YES];
	
	CGRect rect = [self frame];
	rect.origin.y = 210.0f;
	[self setFrame:rect];
	[UIView commitAnimations];	
}

- (void)dealloc {
    [super dealloc];
}


@end
