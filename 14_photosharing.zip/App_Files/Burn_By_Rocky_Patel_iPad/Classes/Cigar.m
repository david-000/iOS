//
//  Cigar.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Cigar.h"


@implementation Cigar

- (id)init
{
	self = [super init];
	reviews = [[NSMutableArray alloc] init];
	return self;
}

- (id)initWithCoder:(NSCoder *)coder {
    self = [super init];
    brandId =[[coder decodeObjectForKey:@"CBBrandId"] retain];
    brand = [[coder decodeObjectForKey:@"CBBrand"] retain];
	pictureURL = [[coder decodeObjectForKey:@"CBPictureURL"] retain];
	type = [[coder decodeObjectForKey:@"CBType"] retain];
	boxprice = [[coder decodeObjectForKey:@"CBBoxPrice"] retain];
	price = [[coder decodeObjectForKey:@"CBPrice"] retain];
	length = [[coder decodeObjectForKey:@"CBLength"] retain];
	ring = [[coder decodeObjectForKey:@"CBRing"] retain];
	strength = [[coder decodeObjectForKey:@"CBStrength"] retain];
	country = [[coder decodeObjectForKey:@"CBCountry"] retain];
	wrapper = [[coder decodeObjectForKey:@"CBWrapper"] retain];
	origin = [[coder decodeObjectForKey:@"CBOrigin"] retain];
	leaf = [[coder decodeObjectForKey:@"CBLeaf"] retain];
	generalInfo = [[coder decodeObjectForKey:@"CBGeneralInfo"] retain];
	reviews = [[coder decodeObjectForKey:@"CBReviews"] retain];
    cuban = [[coder decodeObjectForKey:@"CBCuban"] retain];
    twit = [[coder decodeObjectForKey:@"CBTwit"] retain];
    
    return self;
}

- (NSComparisonResult)compare:(Cigar *)otherObject {
    return [self.type compare:otherObject.type];
}

//- (NSString *)description
//{
//	return type;
//}

- (void)encodeWithCoder:(NSCoder *)coder {
    [coder encodeObject:brandId forKey:@"CBBrandId"]; 
    [coder encodeObject:brand forKey:@"CBBrand"];
	[coder encodeObject:cuban forKey:@"CBCuban"];
    [coder encodeObject:pictureURL forKey:@"CBPictureURL"];
	[coder encodeObject:type forKey:@"CBType"];
	[coder encodeObject:boxprice forKey:@"CBBoxPrice"];
	[coder encodeObject:price forKey:@"CBPrice"];
	[coder encodeObject:length forKey:@"CBLength"];
	[coder encodeObject:ring forKey:@"CBRing"];
	[coder encodeObject:strength forKey:@"CBStrength"];
	[coder encodeObject:country forKey:@"CBCountry"];
	[coder encodeObject:wrapper forKey:@"CBWrapper"];
	[coder encodeObject:origin forKey:@"CBOrigin"];
	[coder encodeObject:leaf forKey:@"CBLeaf"];
	[coder encodeObject:generalInfo forKey:@"CBGeneralInfo"];
	[coder encodeObject:reviews forKey:@"CBReviews"];
	[coder encodeObject:twit forKey:@"CBTwit"];
}

- (BOOL)isEqualCigar:(Cigar *)compareCigar
{
    if(![compareCigar.brandId isEqualToString:self.brandId]) return NO;
	if(![compareCigar.brand isEqualToString:self.brand]) return NO;
	//if(![compareCigar.cuban isEqualToString:self.cuban]) return NO;
    if(![compareCigar.pictureURL isEqualToString:self.pictureURL]) return NO;
	if(![compareCigar.type isEqualToString:self.type]) return NO;
	if(![compareCigar.boxprice isEqualToString:self.boxprice]) return NO;
	if(![compareCigar.price isEqualToString:self.price]) return NO;
	if(![compareCigar.length isEqualToString:self.length]) return NO;
	if(![compareCigar.ring isEqualToString:self.ring]) return NO;
	if(![compareCigar.strength isEqualToString:self.strength]) return NO;
	if(![compareCigar.country isEqualToString:self.country]) return NO;
	if(![compareCigar.wrapper isEqualToString:self.wrapper]) return NO;
	if(![compareCigar.generalInfo isEqualToString:self.generalInfo]) return NO;
    //if(![compareCigar.twit isEqualToString:self.twit]) return NO;
    
	return YES;
}

@synthesize brandId;
@synthesize cuban;
@synthesize brand;
@synthesize pictureURL;
@synthesize type;
@synthesize boxprice;
@synthesize price;
@synthesize length;
@synthesize ring;
@synthesize strength;
@synthesize country;
@synthesize wrapper;
@synthesize origin;
@synthesize leaf;
@synthesize generalInfo;
@synthesize reviews;
@synthesize newCigar;
@synthesize twit;
@synthesize isSpecial;
@synthesize isOutOfStock;
@synthesize isStaffFavorite;
@synthesize specialStr;
@synthesize outOfStockStr;
@synthesize staffFavoriteStr;
@synthesize isDeleted;
@synthesize isFeaturedCigar;
@synthesize isMyCigar;

@end
