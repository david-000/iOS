//
//  MyClass.m
//  CigarBoss
//
//  Created by Anthony Frizalone on 11/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyClass.h"
#import "AddNoteViewController.h"
#import "ViewNoteViewController.h"
@implementation MyClass


@synthesize parentViewsViewController;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [parentViewsViewController closeDatePicker];
    [parentViewContr closeDatePicker];

}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
