//
//  CigarNewsFeedsViewController.h
//  CigarBoss
//
//  Created by Anthony Frizalone on 11/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CigarNewsFeedsViewController : UIViewController
{
    IBOutlet UITableView *mainTableView;
    NSMutableArray *feedsArray;
}

@end
