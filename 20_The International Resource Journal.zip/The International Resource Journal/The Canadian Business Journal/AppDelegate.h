//
//  The_Canadian_Business_JournalAppDelegate.h
//  The Canadian Business Journal
//
//  Created by Mark Voskresenskiy on 29.11.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
