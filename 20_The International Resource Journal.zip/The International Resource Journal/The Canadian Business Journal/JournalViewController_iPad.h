//
//  JournalViewController_iPad.h
//  The Canadian Business Journal
//
//  Created by Jin Bei on 12/20/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface JournalViewController_iPad : UIViewController <UITextFieldDelegate, UIScrollViewDelegate>
{
    NSString *mgzBaseUrl;
    int pageCount;
    int curPage;
    BOOL *isLoading;
    BOOL *isLoaded;
    BOOL isAnimating;
    BOOL isShowingToolbar;
    int curLoadingThumbImage;
    int curLoadingPage;
    int swipeDirection;
    int isShowingKeyboard;
    int thumbBufferStart;
    int thumbBufferEnd;
    NSMutableArray *thumbViewList;
    
}
@property (nonatomic, retain) IBOutlet UIScrollView *vwThumbScroll;
@property (nonatomic, retain) IBOutlet UIView *vwTopBar;
@property (nonatomic, retain) IBOutlet UIView *vwContainer;
@property (nonatomic, retain) IBOutlet UIImageView *imgCover;
@property (nonatomic, retain) IBOutlet UILabel *lblPage;
@property (nonatomic, retain) IBOutlet UIButton *btnContact;
@property (nonatomic, retain) IBOutlet UIButton *btnAbout;

@property (nonatomic, retain) IBOutlet UINavigationBar *navigationBar;
@property (nonatomic, retain) IBOutlet UINavigationItem *navigationItem;
@property (nonatomic, retain) IBOutlet UIToolbar *toolBar;
@property (nonatomic, retain) IBOutlet UITextField *tfPageNumber;
@property (nonatomic, retain) IBOutlet UIImageView *imgLogo;
@property (nonatomic, retain) UIView *vwCurPage;
@property (nonatomic, retain) UIView *vwPrevPage;
@property (nonatomic, retain) UIView *vwNextPage;


- (IBAction)contactButtonPressed:(id)sender;
- (IBAction)aboutButtonPressed:(id)sender;
- (IBAction)subscribeButtonPressed:(id)sender;
- (IBAction)goButtonPressed:(id)sender;
- (IBAction)nextButtonPressed:(id)sender;
- (IBAction)prevButtonPressed:(id)sender;

- (void)loadThumbImages;
- (void)loadPDFdatas:(NSNumber *)number;
- (UIView *)loadPageAtIndex:(int)n;
- (UIImage*)loadPDF:(NSString*)_pdfFileName frame:(CGRect)_frame;
- (void)buildPages;
- (void)selectPageForNumber:(int)pageIndex;
- (void)swipeHandler:(UISwipeGestureRecognizer *)recognizer;
- (void)thumbScrollTapHandler:(UITapGestureRecognizer *)recognizer;
- (void)contentTapHandler:(UITapGestureRecognizer *)recognizer;
- (void)removeAllChilds:(UIView *)parent;
- (void)loadThumbPage:(int)index;
- (void)keyboardWillShow: (NSNotification *)notif;
- (void)keyboardwillHide: (NSNotification *)notif;
@end
