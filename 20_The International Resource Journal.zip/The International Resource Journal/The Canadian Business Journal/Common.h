//
//  Common.h
//  The International Resource Journal
//
//  Created by Jin Bei on 3/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MAGAZINE_INFO_URL @"http://www.internationalresourcejournal.com/E-MAG/App/Current/info.xml"
#define MAGAZINE_BASE_URL @"http://www.internationalresourcejournal.com/E-MAG/App/Current/IRJ_Current%20"
#define MAGAZINE_THUMB_BASE_URL @"http://www.internationalresourcejournal.com/E-MAG/App/Current/mini/IRJ_Current_Page_%03d.jpg"