//
//  Utilities.h
//  The Canadian Business Journal
//
//  Created by Mark Voskresenskiy on 30.11.11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <CoreGraphics/CoreGraphics.h>

CGAffineTransform aspectFit(CGRect innerRect, CGRect outerRect);
