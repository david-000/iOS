//
//  ContactViewController.h
//  The Canadian Business Journal
//
//  Created by Mark Voskresenskiy on 11.11.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AboutViewController_iPad.h"

@interface ContactViewController_iPad : UIViewController{
    id<BackViewController> delegate;
    IBOutlet UITextView *textView;
}

@property(nonatomic,assign)id<BackViewController> delegate;

-(IBAction)touchedBackButton:(id)sender;

@end
