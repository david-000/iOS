//
//  JournalViewController_iPad.h
//  The Canadian Business Journal
//
//  Created by Jin Bei on 12/20/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JournalViewController_iPhone : UIViewController <UITextFieldDelegate, UIScrollViewDelegate>
{
    NSString *mgzBaseUrl;
    int pageCount;
    int curPage;
    BOOL *isLoading;
    BOOL *isLoaded;
    BOOL isAnimating;
    BOOL isShowingToolbar;
    int curLoadingPage;
    int swipeDirection;
    int isShowingKeyboard;
    
}
@property (nonatomic, retain) IBOutlet UIView *vwTopBar;
@property (nonatomic, retain) IBOutlet UIView *vwContainer;
@property (nonatomic, retain) IBOutlet UIImageView *imgCover;
@property (nonatomic, retain) IBOutlet UILabel *lblPage;
@property (nonatomic, retain) IBOutlet UIButton *btnContact;
@property (nonatomic, retain) IBOutlet UIButton *btnAbout;

@property (nonatomic, retain) IBOutlet UINavigationBar *navigationBar;
@property (nonatomic, retain) IBOutlet UIToolbar *toolBar;
@property (nonatomic, retain) IBOutlet UITextField *tfPageNumber;
@property (nonatomic, retain) IBOutlet UIImageView *imgLogo;
@property (nonatomic, retain) UIView *vwCurPage;
@property (nonatomic, retain) UIView *vwPrevPage;
@property (nonatomic, retain) UIView *vwNextPage;


- (IBAction)contactButtonPressed:(id)sender;
- (IBAction)homeButtonPressed:(id)sender;
- (IBAction)aboutButtonPressed:(id)sender;
- (IBAction)goButtonPressed:(id)sender;
- (IBAction)nextButtonPressed:(id)sender;
- (IBAction)prevButtonPressed:(id)sender;

- (void)loadPDFdatas:(NSNumber *)number;
- (UIView *)loadPageAtIndex:(int)n;
- (UIImage*)loadPDF:(NSString*)_pdfFileName frame:(CGRect)_frame;
- (void)buildPages;
- (void)swipeHandler:(UISwipeGestureRecognizer *)recognizer;
- (void)contentTapHandler:(UITapGestureRecognizer *)recognizer;
- (void)removeAllChilds:(UIView *)parent;
- (void)keyboardWillShow: (NSNotification *)notif;
- (void)keyboardwillHide: (NSNotification *)notif;
@end
