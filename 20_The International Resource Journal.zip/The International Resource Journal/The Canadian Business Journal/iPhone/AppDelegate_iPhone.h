//
//  The_Canadian_Business_JournalAppDelegate_iPhone.h
//  The Canadian Business Journal
//
//  Created by Mark Voskresenskiy on 29.11.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"
#import "JournalViewController_iPhone.h"

@interface AppDelegate_iPhone : AppDelegate{
    JournalViewController_iPhone *controller;
}

@end
