//
//  The_Canadian_Business_JournalAppDelegate_iPhone.m
//  The Canadian Business Journal
//
//  Created by Mark Voskresenskiy on 29.11.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate_iPhone.h"
#import <SystemConfiguration/SystemConfiguration.h>
#import "Reachability.h"

@implementation AppDelegate_iPhone

-(BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions{
    if ([[Reachability reachabilityWithHostName:@"http://www.canadianbusinessjournal.ca" ] currentReachabilityStatus] == NotReachable)
	{
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Not connect" message:@"It is not connect with Internet" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease];
		[alert show];
	}
	else
	{
		controller = [[JournalViewController_iPhone alloc] initWithNibName:@"JournalViewController_iPhone" bundle:[NSBundle mainBundle]];
		[self.window addSubview:controller.view];
	}
    [self.window makeKeyAndVisible];
    return YES;
}

@end
