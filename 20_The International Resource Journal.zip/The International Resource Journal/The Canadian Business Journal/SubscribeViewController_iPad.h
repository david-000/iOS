//
//  SubscribeViewController_iPad.h
//  The Canadian Business Journal
//
//  Created by Jin Bei on 1/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubscribeViewController_iPad : UIViewController <UIWebViewDelegate>
@property (nonatomic, retain) IBOutlet UIWebView *webView;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *vwActivityIndicator;
- (IBAction)backButtonPressed:(id)sender;
@end
