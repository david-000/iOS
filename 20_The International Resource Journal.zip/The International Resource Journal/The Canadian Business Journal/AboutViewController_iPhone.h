//
//  AboutViewController.h
//  The Canadian Business Journal
//
//  Created by Mark Voskresenskiy on 11.11.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BackViewController;

@interface AboutViewController_iPhone : UIViewController{
    id <BackViewController> delegate;
    IBOutlet UITextView *_textView;
}

@property (nonatomic,assign) id <BackViewController> delegate;

-(IBAction)touchedBackButton:(id)sender;

@end


@protocol BackViewController

- (void)backToMainView:(UIViewController*)nativeController;

@end