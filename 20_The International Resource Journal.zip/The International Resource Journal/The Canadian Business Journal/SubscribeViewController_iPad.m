//
//  SubscribeViewController_iPad.m
//  The Canadian Business Journal
//
//  Created by Jin Bei on 1/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SubscribeViewController_iPad.h"

@implementation SubscribeViewController_iPad
@synthesize webView, vwActivityIndicator;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.internationalresourcejournal.com/subscribe.php"]];
    [webView loadRequest:request];
    [vwActivityIndicator startAnimating];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return YES;
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [vwActivityIndicator stopAnimating];
    vwActivityIndicator.hidden = YES;
}
- (IBAction)backButtonPressed:(id)sender
{
    [self dismissModalViewControllerAnimated:YES];
}
- (void)dealloc
{
    [webView release];
    [vwActivityIndicator release];
    [super dealloc];
}
@end
