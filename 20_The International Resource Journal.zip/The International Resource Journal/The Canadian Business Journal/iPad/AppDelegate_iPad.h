//
//  The_Canadian_Business_JournalAppDelegate_iPad.h
//  The Canadian Business Journal
//
//  Created by Mark Voskresenskiy on 29.11.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"
#import "JournalViewController_iPad.h"

@interface AppDelegate_iPad : AppDelegate{
    JournalViewController_iPad *controller;
}

@end
