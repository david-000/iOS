//
//  JournalViewController_iPad.m
//  The Canadian Business Journal
//
//  Created by Jin Bei on 12/20/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//
#import <QuartzCore/QuartzCore.h>
#import "JournalViewController_iPhone.h"
#import "TouchXML.h"
#import "Utilities.h"
#import "ContactViewController_iPhone.h"
#import "AboutViewController_iPhone.h"
#import "Common.h"
#define kDirectionToNext 0
#define kDirectionToPrevious 1
#define kIndicatorTag 20
#define kPageFirstImageTag 11
#define kPageSecondImageTag 12
@implementation JournalViewController_iPhone
@synthesize vwContainer, imgCover;
@synthesize vwCurPage, vwNextPage, vwPrevPage;
@synthesize lblPage, btnAbout, btnContact, vwTopBar;
@synthesize navigationBar, toolBar, tfPageNumber;
@synthesize imgLogo;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - Initializing and Loading

//Bring initial informations from the server
- (void)fetchInformation
{

    
    NSURL *xml_url = [NSURL URLWithString:MAGAZINE_INFO_URL];
    CXMLDocument *xml_doc = [[CXMLDocument alloc] initWithContentsOfURL:xml_url options:0 error:nil];
    NSArray *nodes = [xml_doc nodesForXPath:@"//xml" error:NULL];
    CXMLElement *node = [nodes objectAtIndex:0];
    NSInteger pages_count = [[[node nodeForXPath:@"./pagecount" error:NULL] stringValue] intValue];
    mgzBaseUrl = MAGAZINE_BASE_URL;
    pageCount = pages_count;
}
- (void)removeAllChilds:(UIView *)parent
{
    NSArray *subviews = [parent subviews];
    for (UIView *view in subviews)
        [view removeFromSuperview];
}
- (void)loadPDFdatas:(NSNumber *) number
{
    NSAutoreleasePool *threadPool = [[NSAutoreleasePool alloc] init];
    int pageNumber;
    if (number == nil)
        pageNumber = curLoadingPage;
    else
        pageNumber = [number intValue];
    
    if (!isLoading[pageNumber] && !isLoaded[pageNumber])
    {
        isLoading[pageNumber] = YES;
        NSString *serverURL = [NSString stringWithFormat:@"%@%d.pdf", mgzBaseUrl, (pageNumber + 1)];
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:serverURL]];
        
        //Writing to the local area
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
        NSString *documentPath = [paths objectAtIndex:0];
        NSString *localURL = [NSString stringWithFormat:@"%03d.pdf", pageNumber];
        localURL = [documentPath stringByAppendingPathComponent:localURL];
        NSLog(@"Writing: %@", localURL);
        [data writeToFile:localURL atomically:YES];
        isLoading[pageNumber] = NO;
        isLoaded[pageNumber] = YES;
        UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
        BOOL bLandscape = (orientation == UIInterfaceOrientationLandscapeLeft) || (orientation == UIInterfaceOrientationLandscapeRight);
        if (!bLandscape)
        {
            if (curPage == pageNumber)
            {
                //[self.vwCurPage removeFromSuperview];
                [self removeAllChilds:vwContainer];
                self.vwCurPage = [self loadPageAtIndex:pageNumber];
                [self.vwContainer addSubview:self.vwCurPage];
            }
            else if (curPage - 1 == pageNumber)
            {
                self.vwPrevPage = [self loadPageAtIndex:pageNumber];
            }
            else if (curPage + 1 == pageNumber)
            {
                self.vwNextPage = [self loadPageAtIndex:pageNumber];
            }
        }
        else
        {
            if (curPage == pageNumber || curPage + 1 == pageNumber)
            {
                //[self.vwCurPage removeFromSuperview];
                [self removeAllChilds:vwContainer];
                self.vwCurPage = [self loadPageAtIndex:curPage];
                [self.vwContainer addSubview:self.vwCurPage];
            }
            else if (curPage - 2 == pageNumber || curPage - 1 == pageNumber)
            {
                self.vwPrevPage = [self loadPageAtIndex:(curPage - 2)];
            }
            else if (curPage + 2 == pageNumber || curPage + 3 == pageNumber)
            {
                self.vwNextPage = [self loadPageAtIndex:(curPage + 2)];
            }
        }
        
    }
    if (number == nil)
    {
        curLoadingPage++;
        if (curLoadingPage < pageCount)
            [NSThread detachNewThreadSelector:@selector(loadPDFdatas:) toTarget:self withObject:nil];
        
    }
    [threadPool release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    CGRect frame = self.view.frame;
    frame.origin.y = 20;
    [self.view setFrame:frame];
    [self fetchInformation];
    isLoading = (BOOL *)malloc(sizeof(BOOL) * pageCount);
    isLoaded = (BOOL *)malloc(sizeof(BOOL) * pageCount);
    [UIView beginAnimations:@"splash" context:nil];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    self.imgCover.alpha = 0;
    [UIView commitAnimations];
    curPage = 0;
    navigationBar.topItem.title = [NSString stringWithFormat:@"%d of %d", curPage + 1, pageCount];
    [self buildPages];
    curLoadingPage = 0;
    isAnimating = NO;
    isShowingKeyboard = NO;
    for (int i = 0; i < pageCount; i++)
    {
        isLoaded[i] = NO;
        isLoading[i] = NO;
    }
    isShowingToolbar = NO;
    CGAffineTransform transform = CGAffineTransformMakeTranslation(0, -navigationBar.frame.size.height);
    navigationBar.transform = transform;
    
    transform = CGAffineTransformMakeTranslation(0,toolBar.frame.size.height);
    toolBar.transform = transform;
    imgLogo.transform = transform;
    [self.vwContainer addSubview:self.vwCurPage];
    
    UISwipeGestureRecognizer *leftSwipeRecognizer = [[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeHandler:)] autorelease];
    [leftSwipeRecognizer setDirection:UISwipeGestureRecognizerDirectionLeft];
    [self.vwContainer addGestureRecognizer:leftSwipeRecognizer];
    
    UISwipeGestureRecognizer *rightSwipeRecognizer = [[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeHandler:)] autorelease];
    [rightSwipeRecognizer setDirection:UISwipeGestureRecognizerDirectionRight];
    [self.vwContainer addGestureRecognizer:rightSwipeRecognizer];
    
    
    UITapGestureRecognizer *tapGestureRecognizerContent = [[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(contentTapHandler:)] autorelease];
    tapGestureRecognizerContent.cancelsTouchesInView = NO;
	tapGestureRecognizerContent.delaysTouchesBegan   = NO;
	tapGestureRecognizerContent.delaysTouchesEnded   = NO;
    [self.vwContainer addGestureRecognizer:tapGestureRecognizerContent];

    [NSThread detachNewThreadSelector:@selector(loadPDFdatas:) toTarget:self withObject:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardwillHide:) name:UIKeyboardWillHideNotification object:nil];
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    
}

#pragma mark -
#pragma mark - Device Rotation Handling
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (true);
}
- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    //[self.vwCurPage removeFromSuperview];
    [self removeAllChilds:vwContainer];
    self.vwCurPage = nil;
    self.vwPrevPage = nil;
    self.vwNextPage = nil;
    //if (curPage % 2 == 1)
    //    curPage--;
    
    [self buildPages];
    [self.vwContainer addSubview:self.vwCurPage];
}
#pragma mark -
#pragma mark Scrolling Pages

- (void)swipePageWithDirection:(int)direction
{
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    BOOL bLandscape = (orientation == UIInterfaceOrientationLandscapeLeft) || (orientation == UIInterfaceOrientationLandscapeRight);
    swipeDirection = direction;
    if (direction == kDirectionToNext)
    {
        
        if (curPage + 1 >= pageCount)
            return;

        CATransition *transition = [[[CATransition alloc] init] autorelease];
        [transition setType:kCATransitionPush];
        [transition setDuration:0.5];
        [transition setSubtype:kCATransitionFromRight];
        [transition setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
        transition.delegate = self;
        //[vwCurPage removeFromSuperview];
        [self removeAllChilds:vwContainer];
        [vwContainer addSubview:vwNextPage];
        [vwContainer.layer addAnimation:transition forKey:@"next"];
        isAnimating = YES;
        
    }
    else if (direction == kDirectionToPrevious)
    {
        if (curPage - 1 < 0)
            return;

        
        CATransition *transition = [[[CATransition alloc] init] autorelease];
        [transition setType:kCATransitionPush];
        [transition setDuration:0.5];
        [transition setSubtype:kCATransitionFromLeft];
        [transition setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
        transition.delegate = self;
        //[vwCurPage removeFromSuperview];
        [self removeAllChilds:vwContainer];
        [vwContainer addSubview:vwPrevPage];
        [vwContainer.layer addAnimation:transition forKey:@"previous"];
    }
    
}
- (UIView *)loadPageAtIndex:(int)num
{
    if (num < 0 || num >= pageCount)
        return nil;
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    BOOL bLandscape = (orientation == UIInterfaceOrientationLandscapeLeft) || (orientation == UIInterfaceOrientationLandscapeRight);
    UIView *container = [[UIView alloc] initWithFrame:CGRectMake(0, 0, vwContainer.frame.size.width , vwContainer.frame.size.height)];
    container.backgroundColor = [UIColor whiteColor];
    if (!bLandscape)
    {
        CGRect frame = container.frame;
        UIImage *image;
        if (isLoaded[num] == YES)
        {
            NSString *fileName = [NSString stringWithFormat:@"%03d.pdf", num];
            image = [self loadPDF:fileName frame:frame];
        }
        else
        {
            //image = [UIImage imageNamed:@"noimage.png"];
            image = nil;
        }
        UIImageView *imageView = [[[UIImageView alloc] initWithFrame:frame] autorelease];
        imageView.image = image;
        [container addSubview:imageView];
        if (!isLoaded[num])
        {
            UIActivityIndicatorView *activityIndicator = [[[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(00, 00, 30, 30)] autorelease];
            [activityIndicator setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleGray];
            [activityIndicator setCenter:CGPointMake(frame.size.width/2, frame.size.height/2)];
            activityIndicator.tag = 11;
            [activityIndicator startAnimating];
            [container addSubview:activityIndicator];
            
        }
        else
        {
            
            UILabel *pageNumber = [[[UILabel alloc] init] autorelease] ;
            if (num % 2 == 0)
            {
                pageNumber.frame = CGRectMake(frame.size.width - 100, 50, 80, 20);
                pageNumber.textAlignment = UITextAlignmentRight;
            }
            else
            {
                pageNumber.frame = CGRectMake(20, 50, 80, 20);
                pageNumber.textAlignment = UITextAlignmentLeft;
            }
            pageNumber.backgroundColor = [UIColor clearColor];
            pageNumber.textColor = [UIColor blackColor];
            pageNumber.font = [UIFont fontWithName:@"Helvetica" size:24];
            pageNumber.text = [NSString stringWithFormat:@"%d", (num + 1)];
            //[container addSubview:pageNumber];

        }
    }
    else
    {
        int n = num;
        if (n % 2 != 1)
            n--;
        if (n + 1 < pageCount)
        {
            CGRect frame2 = CGRectMake(container.frame.size.width/2, 0, container.frame.size.width/2 - 8 - 1, container.frame.size.height);
            UIImage *image2;
            if (isLoaded[n + 1] == YES)
            {
                NSString *fileName = [NSString stringWithFormat:@"%03d.pdf", n + 1];
                image2 = [self loadPDF:fileName frame:CGRectMake(0, 0, frame2.size.width, frame2.size.height)];
            }
            else
            {
                //image = [UIImage imageNamed:@"Default-Portrait~ipad.png"];
                image2 = nil;
            }
            UIImageView *imageView2 = [[[UIImageView alloc] initWithFrame:frame2] autorelease];
            imageView2.image = image2;
            [container addSubview:imageView2];
            if (!isLoaded[n + 1])
            {
                UIActivityIndicatorView *activityIndicator = [[[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(00, 00, 30, 30)] autorelease];
                [activityIndicator setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleGray];
                [activityIndicator setCenter:CGPointMake(frame2.size.width/2 + frame2.origin.x, frame2.size.height/2)];
                activityIndicator.tag = 11;
                [activityIndicator startAnimating];
                [container addSubview:activityIndicator];
                
                
            }
            else
            {
                UILabel *pageNumber = [[[UILabel alloc] init] autorelease] ;
                
                pageNumber.frame = CGRectMake(container.frame.size.width - 100, 30, 80, 20);
                pageNumber.textAlignment = UITextAlignmentRight;
                
                pageNumber.backgroundColor = [UIColor clearColor];
                pageNumber.textColor = [UIColor blackColor];
                pageNumber.font = [UIFont fontWithName:@"Helvetica" size:20];
                pageNumber.text = [NSString stringWithFormat:@"%d", (n + 2)];
                //[container addSubview:pageNumber];
            }
        }
        CGRect frame1 = CGRectMake(10, 0, container.frame.size.width/2 - 8 - 1, container.frame.size.height);
        UIImage *image1;
        if (n < 0)
        {
            UIImageView *imageView1 = [[[UIImageView alloc] initWithFrame:frame1] autorelease];
            imageView1.image = [UIImage imageNamed:@"Default-Portrait~ipad.png"];
            [container addSubview:imageView1];
        }
        else
        {
            if (isLoaded[n] == YES)
            {
                NSString *fileName = [NSString stringWithFormat:@"%03d.pdf", n];
                image1 = [self loadPDF:fileName frame:frame1];
            }
            else
            {
                //image = [UIImage imageNamed:@"Default-Portrait~ipad.png"];
                image1 = nil;
            }
            UIImageView *imageView1 = [[[UIImageView alloc] initWithFrame:frame1] autorelease];
            imageView1.image = image1;
            [container addSubview:imageView1];
            if (!isLoaded[n])
            {
                UIActivityIndicatorView *activityIndicator = [[[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(00, 00, 30, 30)] autorelease];
                [activityIndicator setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleGray];
                [activityIndicator setCenter:CGPointMake(frame1.size.width/2, frame1.size.height/2)];
                activityIndicator.tag = 11;
                [activityIndicator startAnimating];
                [container addSubview:activityIndicator];
                
                
            }
            else
            {	
                UILabel *pageNumber = [[[UILabel alloc] init] autorelease] ;
   
                pageNumber.frame = CGRectMake(20, 30, 80, 20);
                pageNumber.textAlignment = UITextAlignmentLeft;
                pageNumber.backgroundColor = [UIColor clearColor];
                pageNumber.textColor = [UIColor blackColor];
                pageNumber.font = [UIFont fontWithName:@"Helvetica" size:20];
                pageNumber.text = [NSString stringWithFormat:@"%d", (n + 1)];
                //[container addSubview:pageNumber];
            }
        }
        
    }
    return [container autorelease];
    
}
- (void)buildPages
{
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    BOOL bLandscape = (orientation == UIInterfaceOrientationLandscapeLeft) || (orientation == UIInterfaceOrientationLandscapeRight);
    if (self.vwPrevPage == nil)
    {
        if (!bLandscape)
        {
            if (curPage > 0)
            {
                self.vwPrevPage = [self loadPageAtIndex:(curPage - 1)];
            }
        }
        else
        {
            if (curPage > 1)
            {
                self.vwPrevPage = [self loadPageAtIndex:(curPage - 2)];
            }
        }
    }
    if (self.vwCurPage == nil)
    {
        self.vwCurPage = [self loadPageAtIndex:curPage];
    }
    if (self.vwNextPage == nil)
    {
        if (!bLandscape)
        {
            if (curPage + 1 < pageCount)
            {
                self.vwNextPage = [self loadPageAtIndex:(curPage + 1)];
            }
        }
        else
        {
            if (curPage + 2 < pageCount)
            {
                self.vwNextPage = [self loadPageAtIndex:(curPage + 2)];
            }
        }
    }
}
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    BOOL bLandscape = (orientation == UIInterfaceOrientationLandscapeLeft) || (orientation == UIInterfaceOrientationLandscapeRight);
    int nextPage;
    if (swipeDirection == kDirectionToNext)
    {
        self.vwPrevPage = nil;
        self.vwPrevPage = self.vwCurPage;
        self.vwCurPage = self.vwNextPage;
        self.vwNextPage = nil;
        if (!bLandscape)
            nextPage = curPage + 1;
        else
        {
            nextPage = curPage + 2;
            if (nextPage >= pageCount)
                nextPage = pageCount - 1;
        }
        
    }
    else
    {
        self.vwNextPage = nil;
        self.vwNextPage = self.vwCurPage;
        self.vwCurPage = self.vwPrevPage;
        self.vwPrevPage = nil;
        if (!bLandscape)
            nextPage = curPage - 1;
        else
        {
            
            nextPage = curPage - 2;
            if (nextPage < 0)
                nextPage = 0;
        }
    }
    curPage = nextPage;
    navigationBar.topItem.title = [NSString stringWithFormat:@"%d of %d", curPage + 1, pageCount];
    if (!bLandscape)
        [NSThread detachNewThreadSelector:@selector(loadPDFdatas:) toTarget:self withObject:[NSNumber numberWithInt:curPage]];
    else
    {
        int offset = (curPage + 1) % 2;
        if (curPage - offset > 0)
            [NSThread detachNewThreadSelector:@selector(loadPDFdatas:) toTarget:self withObject:[NSNumber numberWithInt:curPage - offset]];
        if (curPage - offset + 1 < pageCount)
            [NSThread detachNewThreadSelector:@selector(loadPDFdatas:) toTarget:self withObject:[NSNumber numberWithInt:curPage - offset + 1]];
    }
        isAnimating = NO;
    [self buildPages];
}
- (void)swipeHandler:(UISwipeGestureRecognizer *)recognizer
{
    if (isAnimating)
        return; 
    if (recognizer.direction == UISwipeGestureRecognizerDirectionRight)
    {
        isAnimating = YES;
        [self swipePageWithDirection:kDirectionToPrevious];
    }
    else if (recognizer.direction == UISwipeGestureRecognizerDirectionLeft)
    {
        isAnimating = YES;
        [self swipePageWithDirection:kDirectionToNext];
    }
}

#pragma mark -
#pragma mark Tapping Control

- (void)contentTapHandler:(UITapGestureRecognizer *)recognizer
{
    if (isShowingKeyboard == YES)
    {
        [tfPageNumber resignFirstResponder];
        return;
    }
    [UIView beginAnimations:@"showtoolbar" context:nil];
    [UIView setAnimationDuration:1];
    if (isShowingToolbar)
    {
        isShowingToolbar = NO;
        CGAffineTransform transform = CGAffineTransformMakeTranslation(0, -navigationBar.frame.size.height);
        navigationBar.transform = transform;
        
        
        transform = CGAffineTransformMakeTranslation(0,  toolBar.frame.size.height);
        toolBar.transform = transform;
        imgLogo.transform = transform;
        
    }
    else
    {
        isShowingToolbar = YES;
        CGAffineTransform transform = CGAffineTransformMakeTranslation(0, 0);
        navigationBar.transform = transform;
        transform = CGAffineTransformMakeTranslation(0, 0);
        toolBar.transform = transform;
        imgLogo.transform = transform;
    }
    
    
    [UIView commitAnimations];
}
#pragma mark -
#pragma mark Load PDF
-(UIImage*)loadPDF:(NSString*)_pdfFileName frame:(CGRect)_frame{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *documentPath = [paths objectAtIndex:0];
    NSString *localFilePath = [documentPath stringByAppendingPathComponent:_pdfFileName];
    NSLog(@"Reading: %@", localFilePath);
    NSURL *_pdfURL = [NSURL fileURLWithPath:localFilePath];
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(NULL, 
                                                 _frame.size.width, 
                                                 _frame.size.height, 
                                                 8,						/* bits per component*/
                                                 _frame.size.width * 4, 	/* bytes per row */
                                                 colorSpace, 
                                                 kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
    CGColorSpaceRelease(colorSpace);
    CGContextClipToRect(context, CGRectMake(0, 0, _frame.size.width, _frame.size.height));
    
    CFURLRef pdfURL = (CFURLRef)_pdfURL;
    CGPDFDocumentRef pdfDoc = CGPDFDocumentCreateWithURL((CFURLRef)pdfURL);
    CGPDFPageRef page = CGPDFDocumentGetPage(pdfDoc, 1);
    CGContextSaveGState(context);
    CGContextSetRGBFillColor(context, 1, 1, 1, 1);
    CGContextFillRect(context, CGRectMake(0, 0, _frame.size.width, _frame.size.height));
    NSLog(@"Rect: %f, %f", _frame.size.width, _frame.size.height);
    CGContextRestoreGState(context);
    CGAffineTransform transform = aspectFit(CGPDFPageGetBoxRect(page, kCGPDFMediaBox),
											CGContextGetClipBoundingBox(context));
	CGContextConcatCTM(context, transform);
    
    CGContextDrawPDFPage(context, page);
    
    CGImageRef image = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    UIImage *im = [UIImage imageWithCGImage:image];
    CGImageRelease(image);
    CGPDFDocumentRelease(pdfDoc);
    return im;
}

#pragma mark -
#pragma mark Actions

- (void)contactButtonPressed:(id)sender
{
    ContactViewController_iPhone *controller = [[ContactViewController_iPhone alloc] initWithNibName:@"ContactViewController_iPhone" bundle:[NSBundle mainBundle]];
    [self presentModalViewController:controller animated:YES];
}
- (IBAction)homeButtonPressed:(id)sender
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"http://www.internationalresourcejournal.com"]];
}
- (void)aboutButtonPressed:(id)sender
{
    AboutViewController_iPhone *controller = [[AboutViewController_iPhone alloc] initWithNibName:@"AboutViewController_iPhone" bundle:[NSBundle mainBundle]];
    [self presentModalViewController:controller animated:YES];
}
- (void)goButtonPressed:(id)sender
{
    int number = [tfPageNumber.text intValue]-1;
	if((number>pageCount)||(number<0)){
		UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Error" message:@"Page is not present with this number!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] autorelease];
		[alert show];
		return;
	}
    [tfPageNumber resignFirstResponder];
    curPage = number;
    navigationBar.topItem.title = [NSString stringWithFormat:@"%d of %d", curPage + 1, pageCount];
    if (curPage - curLoadingPage > 0)
        [NSThread detachNewThreadSelector:@selector(loadPDFdatas:) toTarget:self withObject:[NSNumber numberWithInt:curPage]];
    //[self.vwCurPage removeFromSuperview];
    [self removeAllChilds:vwContainer];
    self.vwNextPage = nil;
    self.vwCurPage = nil;
    self.vwPrevPage = nil;
    [self buildPages];
    [self.vwContainer addSubview:self.vwCurPage];
    isAnimating = NO;
}

- (void)nextButtonPressed:(id)sender
{
    [self swipePageWithDirection:kDirectionToNext];   
    isAnimating = NO;
}

- (void)prevButtonPressed:(id)sender
{
    [self swipePageWithDirection:kDirectionToPrevious];
    isAnimating = NO;
}

#pragma mark -
#pragma mark UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [tfPageNumber resignFirstResponder];
    return false;
}

#pragma mark -
#pragma mark Keyboard Notification
- (void)keyboardWillShow: (NSNotification *)notif
{
    isShowingKeyboard = YES;
    NSDictionary *info = [notif userInfo];
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    
    CGRect keyboardEndFrame;
    
    [[info objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
    [[info objectForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardEndFrame];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:animationCurve];
    [UIView setAnimationDuration:animationDuration];
    CGRect keyboardFrame = [self.view convertRect:keyboardEndFrame toView:nil];
    CGAffineTransform transform = CGAffineTransformMakeTranslation(0, -keyboardFrame.size.height);
    //[toolBar setFrame:CGRectMake(0, toolBar.frame.origin.y - 500, toolBar.frame.size.width, 44)];
    toolBar.transform = transform;
    [UIView commitAnimations];
}
- (void)keyboardwillHide: (NSNotification *)notif
{
    isShowingKeyboard = NO;
    NSDictionary *info = [notif userInfo];
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    
    CGRect keyboardEndFrame;
    
    [[info objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    [[info objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
    [[info objectForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardEndFrame];
    CGRect keyboardFrame = [self.view convertRect:keyboardEndFrame toView:nil];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:animationCurve];
    [UIView setAnimationDuration:animationDuration];
    CGAffineTransform transform = CGAffineTransformMakeTranslation(0, 0);
    toolBar.transform = transform;
    //[toolBar setFrame:CGRectMake(0, toolBar.frame.origin.y + keyboardFrame.size.height, toolBar.frame.size.width, 44)];
    [UIView commitAnimations];
}
#pragma mark -
#pragma mark dealloc
- (void)dealloc
{
    [vwCurPage release];
    [vwNextPage release];
    [vwPrevPage release];
    [vwContainer release];
    [lblPage release];
    [btnAbout release];
    [vwTopBar release];
    [navigationBar release];
    [toolBar release];
    [tfPageNumber release];
    free(isLoaded);
    free(isLoading);
    [imgCover release];
    [imgLogo release];
    [super dealloc];
}

@end
