//
//  WelComeViewController.h
//  dirty santa
//
//  Created by ymhstar on 11/27/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SoundFx.h"

#define SANTANA_SPEED       0.03

@interface WelComeViewController : UIViewController<UIPickerViewDelegate, UIPickerViewDataSource>{
    IBOutlet UIImageView*   m_backImage;
    IBOutlet UIImageView*   m_santaImage;
    IBOutlet UIButton*      m_startBtn;
    SoundFx*	sound;
    NSTimer	*timer;
	NSTimer	*soundtimer;
    NSMutableArray*    soundData;
    NSMutableArray*    soundTimerData;
    IBOutlet UIPickerView *pickerView;
    IBOutlet UIView* pView;
    NSString*       realSoundStr;
    int         santanaIndex;
    BOOL        addFlag;
    float       timerCount;
    float       realTimer;
    
    BOOL        touchFlag;
    
}

@property(nonatomic, retain) IBOutlet UIImageView*   m_backImage;
@property(nonatomic, retain) IBOutlet UIImageView*   m_santaImage;
@property(nonatomic, retain) IBOutlet UIButton*      m_startBtn;
@property (nonatomic, retain) UIView		*pView;
@property (nonatomic, retain) UIPickerView	*pickerView;
@property (nonatomic, retain)  NSMutableArray*    soundData;

-(IBAction)btnClicked:(id)sender;
- (void)transitionView:(BOOL)flag;
-(void)onSantanaTimer:(id)sender;

-(void)onStartTimer:(id)sender;
-(void)onSoundTimer:(id)sender;

-(void)audioPlay;
-(void)audioStop;

-(void)timerFilter;

@end
