//
//  ResourceManager.h
//  StrikeKnight
//
//  Created by admin on 6/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#ifndef _RESOURCE_MANAGER_H_
#define _RESOURCE_MANAGER_H_

#import "AudioToolBox/AudioToolBox.h"



class ResourceManager
{
public:
	ResourceManager();
	virtual ~ResourceManager();
		
	static ResourceManager* sharedInstance();
	static void releaseInstance();
	
	static ResourceManager* shared;
	
	///////////////Resource /////////
	
	SEL m_backgroundMusicCompletionSelector;
	id m_backgroundMusicCompletionListener;
	
	// PlayView
	CGImageRef dartCGImage[DART_ANI_NUM];	
	CGImageRef blueballoonCGImage[BALLOON_ANI_NUM];	
	CGImageRef greenballoonCGImage[BALLOON_ANI_NUM];	
	CGImageRef redballoonCGImage[BALLOON_ANI_NUM];	
	CGImageRef yellowballoonCGImage[BALLOON_ANI_NUM];	
	CGImageRef gasballoonCGImage[16];	
	CGImageRef rewardCGImage[30];	
	CGImageRef missLeftCGImage[17];	
	CGImageRef missRightCGImage[17];	
	
	// Sound Manager	
	SystemSoundID m_dartflySound;
	SystemSoundID m_doorSound;
	SystemSoundID m_gasSound;
	SystemSoundID m_hitwallSound;
	SystemSoundID m_inflateSound;
	SystemSoundID m_rewardSound;
	SystemSoundID m_scoreSound;
	SystemSoundID m_wrongSound;
//	SystemSoundID m_bonusSound;
	
	// Sound Play Function	
	void soundPlay(int nType);
	
	//Music Play Function
	void musicPlay(int nType);
	void musicStop();	
	void soundvolumeAdjust(float rVolume);
	void musicvolumeAdjust(float rVolume);
	void musicRewind();
	void setBackgroundMusicCompletionListener(id listener, SEL selector);	
};

//extern ResourceManager* shared;

#endif // _RESOURCE_MANAGER_H_