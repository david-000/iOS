//
//  Memory_LightsAppDelegate.h
//  Memory	Lights
//
//  Created by mgic on 11/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WelComeViewController.h"

enum {
    previewImageState,
    selectimageState
};
typedef int showState;

@interface Memory_LightsAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	WelComeViewController *viewController;
	UINavigationController* navigationController;
	
@public    
	
	int							levelIndex;
		int imagestate;
	

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet WelComeViewController *viewController;


-(void)initControllers;
-(void)showLevelSelectController;
//-(void)showPlayGameController:(NSInteger)imageIndex;
-(void)showMainMenuController;
-(void)showInstructionsController;
-(void)showVisitWebController;



@end

