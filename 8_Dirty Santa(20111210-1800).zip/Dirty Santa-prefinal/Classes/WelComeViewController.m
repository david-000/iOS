//
//  WelComeViewController.m
//  dirty santa
//
//  Created by ymhstar on 11/27/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "WelComeViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation WelComeViewController

@synthesize m_backImage;
@synthesize m_santaImage;
@synthesize m_startBtn;
@synthesize pView;
@synthesize pickerView;
@synthesize soundData;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    realSoundStr = @"intro";
    [self audioPlay];
//    [self.m_startBtn setUserInteractionEnabled:NO];
    if (timer != nil) {
        if ([timer isValid]) {
            [timer invalidate];
            timer = nil;
        }
    }
    //timer = [NSTimer scheduledTimerWithTimeInterval:0.12/0.13*13  target:self selector:@selector(onStartTimer:) userInfo:nil repeats:YES];
    
    pView.hidden = YES;
    pickerView.hidden = YES;
    touchFlag = NO;
    
//    soundData = [NSArray arrayWithObjects:@"Ahmed",@"Big Arnold",@"Bombing guy",@"Borat",@"Bush",@"China chef",@"Crazy Leno",@"Dirty Cowell",@"gey guy",@"Geylord Fucker",@"Haidi",@"Hilton girl",@"Japan girl",@"Lady GUGU",@"Miss Piggy",@"Mr. Bean",@"Putkin",@"Ragazzo Brelusconi",@"Sarko French",@"Sexy Pemela",@"Slovenian guy",@"Terorist",@"Tweety bird", @"USA ex president", @"X Krajcek", nil];
    
    soundData = [[NSMutableArray alloc] init];
	[soundData addObject:@"Ahmed"];
    [soundData addObject:@"Big Arnold"];
	[soundData addObject:@"Bombing guy"];
	[soundData addObject:@"Borat"];
    [soundData addObject:@"Bush"];
    [soundData addObject:@"China chef"];
    [soundData addObject:@"Crazy Leno"];
    [soundData addObject:@"Dirty Cowell"];
    [soundData addObject:@"gey guy"];
    [soundData addObject:@"Geylord Fucker"];
    [soundData addObject:@"Haidi"];
    [soundData addObject:@"Hilton girl"];
    [soundData addObject:@"Japan man"];
    [soundData addObject:@"Lady GUGU"];
    [soundData addObject:@"Miss Piggy"];
    [soundData addObject:@"Mr.Bean"];
    [soundData addObject:@"Putkin"];
    [soundData addObject:@"Ragazzo Brelusconi"];
    [soundData addObject:@"Sarko French"];
    [soundData addObject:@"Sexy Pemela"];
    [soundData addObject:@"Slovenian guy"];
    [soundData addObject:@"Terorist"];
    [soundData addObject:@"Tweety bird"];
	[soundData addObject:@"USA ex president"];
    [soundData addObject:@"X Krajcek"];
    
    soundTimerData = [[NSMutableArray alloc] init];
	[soundTimerData addObject:@"0.08"];
    [soundTimerData addObject:@"0.15"];
	[soundTimerData addObject:@"0.13"];
	[soundTimerData addObject:@"0.13"];
    [soundTimerData addObject:@"0.15"];
    [soundTimerData addObject:@"0.21"];
    [soundTimerData addObject:@"0.14"];
    [soundTimerData addObject:@"0.07"];
    [soundTimerData addObject:@"0.12"];
    [soundTimerData addObject:@"0.12"];
    [soundTimerData addObject:@"0.14"];
    [soundTimerData addObject:@"0.15"];
    [soundTimerData addObject:@"0.15"];
    [soundTimerData addObject:@"0.13"];
    [soundTimerData addObject:@"0.16"];
    [soundTimerData addObject:@"0.19"];
    [soundTimerData addObject:@"0.13"];
    [soundTimerData addObject:@"0.20"];
    [soundTimerData addObject:@"0.15"];
    [soundTimerData addObject:@"0.14"];
    [soundTimerData addObject:@"0.20"];
    [soundTimerData addObject:@"0.10"];
    [soundTimerData addObject:@"0.20"];
    [soundTimerData addObject:@"0.08"];
    [soundTimerData addObject:@"0.20"];
    
    
	[pickerView selectRow:1 inComponent:0 animated:NO];
    addFlag = YES;
    santanaIndex = 11;
    timerCount = 0.0;
     realTimer = 0.00;
    timer = nil;
}

-(void)onStartTimer:(id)sender
{
    [self.m_startBtn setUserInteractionEnabled:YES];
     [m_startBtn setImage:[UIImage imageNamed:@"godirty.png"] forState:UIControlStateNormal];
    if (timer != nil) {
        if ([timer isValid]) {
            [timer invalidate];
            timer = nil;
        }
    }
    [sound stop];
}

-(void)onSantanaTimer:(id)sender
{

    if (santanaIndex < 1 && !addFlag) {
        santanaIndex = 1;
        addFlag = YES;
    }
    else if(santanaIndex > 11 && addFlag)
    {
        santanaIndex = 11;
        addFlag = NO;
    }
        
   
    if (santanaIndex > 9) {
        [m_santaImage setImage:[UIImage imageNamed:[NSString stringWithFormat:@"anime%d.png",santanaIndex]]];
    }
    else
    {
        [m_santaImage setImage:[UIImage imageNamed:[NSString stringWithFormat:@"anime0%d.png",santanaIndex]]];
    }
    if (addFlag) {
        santanaIndex++;
    }
    else
    {
        santanaIndex--;
    }
    [self.m_santaImage setNeedsDisplay];
    [self timerFilter];
}

-(void)timerFilter
{
//    pView.hidden = YES;
//    pickerView.hidden = YES;
//    [self.m_startBtn setUserInteractionEnabled:NO];
//    [self.view setUserInteractionEnabled:NO];
    if (timerCount >= realTimer) {
        addFlag = YES;
        santanaIndex = 11;
        timerCount = 0.00;
        realTimer = 0.00;
        
        if (timer != nil) {
            if ([timer isValid]) {
                [timer invalidate];
                timer = nil;
            }
        }
//        [timer invalidate];
        [self.m_startBtn setUserInteractionEnabled:YES];
        [self.view setUserInteractionEnabled:YES];
        [m_santaImage setImage:[UIImage imageNamed:[NSString stringWithFormat:@"anime11.png",santanaIndex]]];
        
        [m_startBtn setImage:[UIImage imageNamed:@"godirty.png"] forState:UIControlStateNormal];
        pView.hidden = NO;
        pickerView.hidden = NO;
    }
    timerCount += 0.01;
//    [self.view addSubview:self.m_santaImage];
}

-(void)onSoundTimer:(id)sender
{
	[sound play];	
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView;
{
	return 1;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    [self audioStop];
    realSoundStr = [soundData objectAtIndex:row];
    realTimer = [[soundTimerData objectAtIndex:row] floatValue] * 22 * 0.05 / 0.09;
    [self transitionView:NO];
    pView.hidden = YES;
    [self.m_startBtn setUserInteractionEnabled:YES];
    [self.m_santaImage setUserInteractionEnabled:YES];
    [self.m_backImage setUserInteractionEnabled:YES];
    self.pickerView.hidden = YES;
    [self audioPlay];
    if (timer != nil) {
        if ([timer isValid]) {
            [timer invalidate];
            timer = nil;
        }
    }
    timer = [NSTimer scheduledTimerWithTimeInterval:0.09 target:self selector:@selector(onSantanaTimer:) userInfo:nil repeats:YES];
    
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component;
{
	return [soundData count];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component;
{
	return [soundData objectAtIndex:row];
}


#pragma mark Animation methods

- (void)transitionView:(BOOL)flag
{
	NSString *direction;
	if (flag) {
		direction = kCATransitionFromBottom;
			if (pickerView && ([pickerView superview] == nil)) {
				[pView insertSubview:pickerView atIndex:1];
        } else
				return;	
	} else {
		direction = kCATransitionFromBottom;
            [pickerView removeFromSuperview];
	}	
	CATransition *animation = [CATransition animation];
	
	[animation setType:kCATransitionPush];
	[animation setSubtype:direction];
	
	[animation setDuration:0.4];
	[animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
		[[pView layer] addAnimation:animation forKey:@"pickerViewAnimation"];	
}



-(void)audioPlay
{
	NSBundle *mainBundle = [NSBundle mainBundle];
    if (sound) {
        sound = nil;
    }
	sound = [[SoundFx alloc] initWithContentsOfFile:[mainBundle pathForResource:realSoundStr ofType:@"mp3"]];

    [sound play];
}

-(void)audioStop
{
	[sound stop];	
}

-(IBAction)btnClicked:(id)sender
{

    if (timer != nil) {
        if ([timer isValid]) {
            [timer invalidate];
            timer = nil;
        }
    }
    [m_santaImage setFrame:CGRectMake(100, 87, 143, 352)];
    [self.view addSubview:m_santaImage];
    [self audioStop];
    [m_santaImage setImage:[UIImage imageNamed:[NSString stringWithFormat:@"anime11.png"]]];
    pView.hidden = NO;
    pickerView.hidden = NO;
    [self transitionView:YES];

    [self.m_startBtn setUserInteractionEnabled:NO];
    [self.m_santaImage setUserInteractionEnabled:NO];
    [self.m_backImage setUserInteractionEnabled:NO];
        [self.view addSubview:pView];
        realSoundStr = @"picker";
        [m_startBtn setImage:[UIImage imageNamed:@"dirtysanta.png"] forState:UIControlStateNormal];
        [self audioPlay];

}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
  
    if (timer != nil) {
        if ([timer isValid]) {
            [timer invalidate];
            timer = nil;
        }
    }
		
        [m_santaImage setFrame:CGRectMake(100, 87, 143, 352)];
        [self.view addSubview:m_santaImage];
        [self audioStop];
        [m_santaImage setImage:[UIImage imageNamed:[NSString stringWithFormat:@"anime11.png"]]];
        pView.hidden = NO;
        pickerView.hidden = NO;
        [self transitionView:YES];
        
    [self.m_startBtn setUserInteractionEnabled:NO];
    [self.m_santaImage setUserInteractionEnabled:NO];
    [self.m_backImage setUserInteractionEnabled:NO];
    
        [self.view addSubview:pView];
        realSoundStr = @"picker";
        [m_startBtn setImage:[UIImage imageNamed:@"dirtysanta.png"] forState:UIControlStateNormal];
        [self audioPlay];
        touchFlag = YES;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
