//
//  ResourceManager.mm
//  StrikeKnight
//
//  Created by admin on 6/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ResourceManager.h"
#import "balloon_define.h"
#import "SoundDefine.h"

SimpleAudioEngine* soundEngine1;

ResourceManager* ResourceManager::shared = nil;

ResourceManager* ResourceManager::sharedInstance() 
{
	if (shared == NULL)
		shared = new ResourceManager;
	
	return shared;
}

void ResourceManager::releaseInstance()
{
	if (shared != NULL)
		delete shared;
	shared = NULL;
}

ResourceManager::ResourceManager()
{
	[[GameSoundManager sharedManager] setup];
	
	UIImage *frameImage;
	int i;
	NSString *pszImageName;
	NSString *str;

	for (i = 0; i < DART_ANI_NUM; i++) {
		pszImageName = [NSString stringWithFormat:res(@"dart%d.png"), i + 1];
		str = [[NSBundle mainBundle] pathForResource: pszImageName ofType: nil];
		frameImage = [[UIImage alloc] initWithContentsOfFile:str];
		dartCGImage[i] = CGImageCreateCopy(frameImage.CGImage);
		[frameImage release];
		frameImage = nil;
	}
	for (i = 0; i < BALLOON_ANI_NUM; i++) {
		pszImageName = [NSString stringWithFormat:res(@"%@0%d.png"), BALLOON_BLUE_POP_PREFIX, i + 1];
		str = [[NSBundle mainBundle] pathForResource: pszImageName ofType: nil];
		frameImage = [[UIImage alloc] initWithContentsOfFile:str];
		blueballoonCGImage[i] = CGImageCreateCopy(frameImage.CGImage);
		[frameImage release];
		frameImage = nil;
	}
	for (i = 0; i < BALLOON_ANI_NUM; i++) {
		pszImageName = [NSString stringWithFormat:res(@"%@0%d.png"), BALLOON_GREEN_POP_PREFIX, i + 1];
		str = [[NSBundle mainBundle] pathForResource: pszImageName ofType: nil];
		frameImage = [[UIImage alloc] initWithContentsOfFile:str];
		greenballoonCGImage[i] = CGImageCreateCopy(frameImage.CGImage);
		[frameImage release];
		frameImage = nil;
	}
	for (i = 0; i < BALLOON_ANI_NUM; i++) {
		pszImageName = [NSString stringWithFormat:res(@"%@0%d.png"), BALLOON_RED_POP_PREFIX, i + 1];
		str = [[NSBundle mainBundle] pathForResource: pszImageName ofType: nil];
		frameImage = [[UIImage alloc] initWithContentsOfFile:str];
		redballoonCGImage[i] = CGImageCreateCopy(frameImage.CGImage);
		[frameImage release];
		frameImage = nil;
	}
	for (i = 0; i < BALLOON_ANI_NUM; i++) {
		pszImageName = [NSString stringWithFormat:res(@"%@0%d.png"), BALLOON_YELLOW_POP_PREFIX, i + 1];
		str = [[NSBundle mainBundle] pathForResource: pszImageName ofType: nil];
		frameImage = [[UIImage alloc] initWithContentsOfFile:str];
		yellowballoonCGImage[i] = CGImageCreateCopy(frameImage.CGImage);
		[frameImage release];
		frameImage = nil;
	}
	for (i = 0; i < 16; i++) {
		pszImageName = [NSString stringWithFormat:res(@"gasballoon%02d.png"), i + 1];
		str = [[NSBundle mainBundle] pathForResource: pszImageName ofType: nil];
		frameImage = [[UIImage alloc] initWithContentsOfFile:str];
		gasballoonCGImage[i] = CGImageCreateCopy(frameImage.CGImage);
		[frameImage release];
		frameImage = nil;
	}
	for (i = 0; i < 30; i++) {
		pszImageName = [NSString stringWithFormat:res(@"reward%02d.png"), i + 1];
		str = [[NSBundle mainBundle] pathForResource: pszImageName ofType: nil];
		frameImage = [[UIImage alloc] initWithContentsOfFile:str];
		rewardCGImage[i] = CGImageCreateCopy(frameImage.CGImage);
		[frameImage release];
		frameImage = nil;
	}
	for (i = 0; i < 17; i++) {
		pszImageName = [NSString stringWithFormat:res(@"missLeft_%02d.png"), i + 2];
		str = [[NSBundle mainBundle] pathForResource: pszImageName ofType: nil];
		frameImage = [[UIImage alloc] initWithContentsOfFile:str];
		missLeftCGImage[i] = CGImageCreateCopy(frameImage.CGImage);
		[frameImage release];
		frameImage = nil;
	}
	for (i = 0; i < 17; i++) {
		pszImageName = [NSString stringWithFormat:res(@"missRight_%02d.png"), i + 2];
		str = [[NSBundle mainBundle] pathForResource: pszImageName ofType: nil];
		frameImage = [[UIImage alloc] initWithContentsOfFile:str];
		missRightCGImage[i] = CGImageCreateCopy(frameImage.CGImage);
		[frameImage release];
		frameImage = nil;
	}
	
	NSURL* urlSound;
	
	str = [[NSBundle mainBundle] pathForResource:SOUND_DARTFLY ofType:nil];
	urlSound = [NSURL fileURLWithPath:str];
	AudioServicesCreateSystemSoundID((CFURLRef)urlSound, &m_dartflySound);	
	
	str = [[NSBundle mainBundle] pathForResource:SOUND_DOOR ofType:nil];
	urlSound = [NSURL fileURLWithPath:str];
	AudioServicesCreateSystemSoundID((CFURLRef)urlSound, &m_doorSound);	
	
	str = [[NSBundle mainBundle] pathForResource:SOUND_GAS ofType:nil];
	urlSound = [NSURL fileURLWithPath:str];
	AudioServicesCreateSystemSoundID((CFURLRef)urlSound, &m_gasSound);	
	
	str = [[NSBundle mainBundle] pathForResource:SOUND_HITWALL ofType:nil];
	urlSound = [NSURL fileURLWithPath:str];
	AudioServicesCreateSystemSoundID((CFURLRef)urlSound, &m_hitwallSound);	
	
	str = [[NSBundle mainBundle] pathForResource:SOUND_INFLATE ofType:nil];
	urlSound = [NSURL fileURLWithPath:str];
	AudioServicesCreateSystemSoundID((CFURLRef)urlSound, &m_inflateSound);	
	
	str = [[NSBundle mainBundle] pathForResource:SOUND_REWARD ofType:nil];
	urlSound = [NSURL fileURLWithPath:str];
	AudioServicesCreateSystemSoundID((CFURLRef)urlSound, &m_rewardSound);
	
	str = [[NSBundle mainBundle] pathForResource:SOUND_SCORE ofType:nil];
	urlSound = [NSURL fileURLWithPath:str];
	AudioServicesCreateSystemSoundID((CFURLRef)urlSound, &m_scoreSound);
	
	str = [[NSBundle mainBundle] pathForResource:SOUND_WRONGSOUND ofType:nil];
	urlSound = [NSURL fileURLWithPath:str];
	AudioServicesCreateSystemSoundID((CFURLRef)urlSound, &m_wrongSound);
}

ResourceManager::~ResourceManager()
{
	int i;
	
	for (i = 0; i < DART_ANI_NUM; i ++)
	{
		if (dartCGImage[i] != nil)
			CGImageRelease(dartCGImage[i]);	
	}
	for (i = 0; i < BALLOON_ANI_NUM; i ++)
	{
		if (blueballoonCGImage[i] != nil)
			CGImageRelease(blueballoonCGImage[i]);	
	}
	for (i = 0; i < BALLOON_ANI_NUM; i ++)
	{
		if (greenballoonCGImage[i] != nil)
			CGImageRelease(greenballoonCGImage[i]);	
	}
	for (i = 0; i < BALLOON_ANI_NUM; i ++)
	{
		if (redballoonCGImage[i] != nil)
			CGImageRelease(redballoonCGImage[i]);	
	}
	for (i = 0; i < BALLOON_ANI_NUM; i ++)
	{
		if (yellowballoonCGImage[i] != nil)
			CGImageRelease(yellowballoonCGImage[i]);	
	}
	for (i = 0; i < 16; i ++)
	{
		if (gasballoonCGImage[i] != nil)
			CGImageRelease(gasballoonCGImage[i]);	
	}
	for (i = 0; i < 30; i ++)
	{
		if (rewardCGImage[i] != nil)
			CGImageRelease(rewardCGImage[i]);	
	}
	for (i = 0; i < 17; i ++)
	{
		if (missLeftCGImage[i] != nil)
			CGImageRelease(missLeftCGImage[i]);	
	}
	for (i = 0; i < 17; i ++)
	{
		if (missRightCGImage[i] != nil)
			CGImageRelease(missRightCGImage[i]);	
	}
	
//	SoundEngine_UnloadEffect(m_dartflySound);
//	SoundEngine_UnloadEffect(m_doorSound);
//	SoundEngine_UnloadEffect(m_gasSound);
//	SoundEngine_UnloadEffect(m_hitwallSound);
//	SoundEngine_UnloadEffect(m_inflateSound);
//	SoundEngine_UnloadEffect(m_rewardSound);
//	SoundEngine_UnloadEffect(m_scoreSound);
	
	AudioServicesDisposeSystemSoundID(m_dartflySound);
	AudioServicesDisposeSystemSoundID(m_doorSound);
	AudioServicesDisposeSystemSoundID(m_gasSound);
	AudioServicesDisposeSystemSoundID(m_hitwallSound);
	AudioServicesDisposeSystemSoundID(m_inflateSound);
	AudioServicesDisposeSystemSoundID(m_rewardSound);
	AudioServicesDisposeSystemSoundID(m_scoreSound);
	AudioServicesDisposeSystemSoundID(m_wrongSound);
	
	[[GameSoundManager sharedManager] release];
}

void ResourceManager::soundPlay(int nType)
{
	if (g_nSoundCheck == 0) {
		if (nType == DARTFLY_SOUND)
			AudioServicesPlaySystemSound(m_dartflySound);	
		else if (nType == DOOR_SOUND)
			AudioServicesPlaySystemSound(m_doorSound);	
		else if (nType == GAS_SOUND)
			AudioServicesPlaySystemSound(m_gasSound);	
		else if (nType == HITWALL_SOUND)
			AudioServicesPlaySystemSound(m_hitwallSound);	
		else if (nType == INFLATE_SOUND)
			AudioServicesPlaySystemSound(m_inflateSound);	
		else if (nType == REWARD_SOUND)
			AudioServicesPlaySystemSound(m_rewardSound);	
		else if (nType == SCORE_SOUND)
			AudioServicesPlaySystemSound(m_scoreSound);	
		else if (nType == WRONG_SOUND)
			AudioServicesPlaySystemSound(m_wrongSound);	
	}
}

void ResourceManager::musicPlay(int nType)
{
	if (nType == MUSICTYPE_HOW) {
		soundEngine1 = [GameSoundManager sharedManager].soundEngine;
		soundEngine1.backgroundMusicVolume = 1.0f;
		[soundEngine1 rewindBackgroundMusic];
		[soundEngine1 playBackgroundMusic:MUSIC_HOW loop:NO];
	}
	else if (nType == MUSICTYPE_FACE){
		soundEngine1 = [GameSoundManager sharedManager].soundEngine;
		soundEngine1.backgroundMusicVolume = 1.0f;
		[soundEngine1 rewindBackgroundMusic];
		[soundEngine1 playBackgroundMusic:MUSIC_FACE loop:NO];
	}
}

void ResourceManager::musicStop()
{
	[soundEngine1 stopBackgroundMusic];
}

void ResourceManager::setBackgroundMusicCompletionListener(id listener, SEL selector)
{
	[soundEngine1 setBackgroundMusicCompletionListener:listener selector:selector];
}

void ResourceManager::soundvolumeAdjust(float rVolume)
{
//	[soundEngine1 setBackgroundMusicVolume(rVolume)];
}

void ResourceManager::musicvolumeAdjust(float rVolume)
{
	[soundEngine1 setBackgroundMusicVolume:rVolume];
}

void ResourceManager::musicRewind()
{
	[soundEngine1 rewindBackgroundMusic];
}
