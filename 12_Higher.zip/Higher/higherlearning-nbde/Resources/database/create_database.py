#!/usr/bin/python
import getopt
import sys
import sqlite3
import csv
import os
import re

# A generator that loads utf-8 encoded .csv files and yields a list of
# unicode entries for each row.
def unicode_csv_reader(utf8_data, dialect=csv.excel, **kwargs):
    csv_reader = csv.reader(utf8_data, dialect=dialect, **kwargs)
    for row in csv_reader:
        yield [unicode(cell, 'utf-8') for cell in row] 

def getCategories(cursor):

	cursor.execute(
		"""
		SELECT	category.id, 
						category.name,
						category_type.name
		FROM		category, 
						category_type
		WHERE		category.category_type_id = category_type.id
		"""
	)
	rows = cursor.fetchall()
	categories = []
	for row in rows:
		category = {}
		category['id'] = row[0]
		category['name'] = row[1]
		category['category_type_name'] = row[2]
		categories.append(category)

	return categories

def getFlashcardStatus(cursor, name):
	
	cursor.execute(
		"""
		SELECT id 
		FROM flashcard_status
		WHERE name = ?
		""", (name,)
	)
	row = cursor.fetchone()
	if row is not None:
		flashcardStatus = {}
		flashcardStatus['id'] = row[0]
		flashcardStatus['name'] = name
		return flashcardStatus
	else:
		return None

def getAnswerStatus(cursor, name):
	
	cursor.execute(
		"""
		SELECT	id
		FROM		answer_status
		WHERE		name = ?
		""", (name,)
	)
	row = cursor.fetchone()
	if row is not None:
		answerStatus = {}
		answerStatus['id'] = row[0]
		answerStatus['name'] = name
		return answerStatus
	else:
		return None

def getAchievementType(cursor, name):

	cursor.execute(
		"""
		SELECT	id
		FROM		achievement_type
		WHERE		name = ?
		""", (name,)
	)
	
	row = cursor.fetchone()
	if row is not None:
		achievementType = {}
		achievementType['id'] = row[0]
		achievementType['name'] = name
		return achievementType
	else:
		return None	


def getCategoryType(cursor, name):

	cursor.execute(
		"""
		SELECT id 
		FROM category_type
		WHERE name = ?
		""", (name,)
	)
	row = cursor.fetchone()
	if row is not None:
		categoryType = {}
		categoryType['id'] = row[0]
		categoryType['name'] = name
		return categoryType
	else:
		return None

def getMnemonicType(cursor, name):
	
	cursor.execute(
		"""
		SELECT	id	
		FROM		mnemonic_type
		WHERE		name = ?
		""", (name,)
	)

	row = cursor.fetchone()
	if row is not None:
		mnemonicType = {}
		mnemonicType['id'] = row[0]
		mnemonicType['name'] = name
		return mnemonicType
	else:
		return None

def getRootCategoryForCategoryParts(cursor, categoryParts):
	#Get the id for the root category
	rootCategoryNumber = categoryParts[0]
	cursor.execute(
		"""
		SELECT 	category.id, 
						category.name,
						category.available, 
						category_type.id,
						category_type.name
		FROM 		category,
						category_type
		WHERE 	category.parent_category_id IS NULL
		AND			category.number = ?
		AND			category.category_type_id = category_type.id
		""", (rootCategoryNumber,)
	)
	row = cursor.fetchone()
	if row is not None:
		category = {}
		category['id'] = row[0]
		category['name'] = row[1]
		category['available'] = row[2]
		category['category_type_id'] = row[3]
		category['category_type_name'] = row[4]
		return  category
	else:
		return None

def getCategoryForCategoryParts(cursor, categoryParts):

	rootCategory = getRootCategoryForCategoryParts(cursor, categoryParts)

	if len(categoryParts) == 1:
		return rootCategory

	categories = []
	categories.append(rootCategory)
	lastCategory = rootCategory

	for index in range(1, len(categoryParts)):
		categoryNumber = categoryParts[index]
		cursor.execute(
										"""
										SELECT 	category.id, 
														category.name,
														category.available, 
														category_type.id,
														category_type.name
										FROM 		category,
														category_type
										WHERE 	category.parent_category_id = ?
										AND 		category.number = ?
										AND			category.category_type_id = category_type.id
										""", (lastCategory['id'], categoryNumber)
									)
		row = cursor.fetchone()
		if row is None:	
			return None
		category = {}
		category['id'] = row[0]
		category['name'] = row[1]
		category['available'] = row[2]
		category['category_type_id'] = row[3]
		category['category_type_name'] = row[4]
		categories.append(category)
		lastCategory = category
				
	return lastCategory


def createDatabase(databaseFile = "database.sqlite"):

	#If the database exists already, delete it
	if os.path.exists(databaseFile):
		os.unlink(databaseFile)

	database = sqlite3.connect(databaseFile)
	cursor = database.cursor()

	#Create the image table
	cursor.execute(	
		"""
		CREATE TABLE image(
			id INTEGER PRIMARY KEY,
			number INTEGER NOT NULL,
			name TEXT NOT NULL
		)
		"""
	)

	#Create the category type table
	cursor.execute(
		"""
			CREATE TABLE category_type( 
				id INTEGER PRIMARY KEY,
				name TEXT NOT NULL
			)
		"""
	)

	#Create the category table
	cursor.execute(	
		"""
			CREATE TABLE category(
				id INTEGER PRIMARY KEY,
				name TEXT NOT NULL,
				number INTEGER NOT NULL,
				parent_category_id INTEGER DEFAULT NULL,
				category_type_id INTEGER NOT NULL,
				available BOOL DEFAULT 1,
				enabled_by_default BOOL DEFAULT 1,
				FOREIGN KEY(parent_category_id) REFERENCES category(id),
				FOREIGN KEY(category_type_id) REFERENCES category_type(id),
				UNIQUE(number, parent_category_id)
			)
		"""
	)

	#Create the flashcard status table
	cursor.execute(
		"""
		CREATE TABLE flashcard_status(
			id INTEGER PRIMARY KEY,
			name TEXT NOT NULL
		)
		"""
	)

	#Create the answer status table
	cursor.execute(
		"""
		CREATE TABLE answer_status(
			id INTEGER PRIMARY KEY,
			name TEXT NOT NULL
		)
		"""
	)


	#Create the mnemonic type table
	cursor.execute(
		"""
		CREATE TABLE mnemonic_type(
			id INTEGER PRIMARY KEY,
			name TEXT NOT NULL	
		)
		"""
	)
						
	#Create the mnemonics table
	cursor.execute(
		"""	
		CREATE TABLE mnemonic(
			id INTEGER PRIMARY KEY,
			number INTEGER,
			title TEXT NOT NULL,
			text TEXT NOT NULL,
			mnemonic_type_id INTEGER NOT NULL,
			FOREIGN KEY(mnemonic_type_id) REFERENCES mnemonic_type(id)
		)
		"""
	)

	#Create the achievement type table
	cursor.execute(
		"""
		CREATE TABLE achievement_type(
			id INTEGER PRIMARY KEY,
			name TEXT NOT NULL
		)
		"""
	)

	#Create the achievement table
	cursor.execute(
		"""
		CREATE TABLE achievement(
			id INTEGER PRIMARY KEY,
			category_id INTEGER DEFAULT NULL,
			achievement_type_id INTEGER NOT NULL,
			FOREIGN KEY(category_id) REFERENCES category(id),
			FOREIGN KEY(achievement_type_id) REFERENCES achievement_type(id)
		)
		"""
	)

	#Create the flashcard table
	cursor.execute(	
		"""
		CREATE TABLE flashcard(
			id INTEGER PRIMARY KEY,
			question TEXT NOT NULL,
			choices TEXT NOT NULL,
			answers TEXT DEFAULT NULL,
			rationale TEXT DEFAULT NULL,
			rationale_preview TEXT DEFAULT NULL,
			category_id INTEGER NOT NULL,
			image_number INTEGER DEFAULT NULL,
			FOREIGN KEY(category_id) REFERENCES category(id),
			FOREIGN KEY(image_number) REFERENCES image(number)
		)
		"""
	)

	cursor.execute(
		"""
		CREATE TABLE flashcard_mnemonic_link(
			id INTEGER PRIMARY KEY,
			flashcard_id INTEGER NOT NULL,
			mnemonic_number INTEGER NOT NULL,
			FOREIGN KEY(flashcard_id) REFERENCES flashcard(id),
			FOREIGN KEY(mnemonic_number) REFERENCES mnemonic(number),
			UNIQUE(flashcard_id, mnemonic_number)
		)
		"""
	)

	database.commit()
	cursor.close()
	database.close()

def populateConstants(databaseFile):
	
	database = sqlite3.connect(databaseFile)
	cursor = database.cursor()
	
	#Insert stuff into the category_type table
	cursor.execute(
		"""
		INSERT INTO category_type(name)
		VALUES(?)
		""", ("multiple-choice",)
	)

	cursor.execute(
		"""
		INSERT INTO category_type(name)
		VALUES(?)
		""", ("terminology",)
	)

	cursor.execute(
		"""
		INSERT INTO category_type(name)
		VALUES(?)
		""", ("quiz",)
	)

	#Insert stuff into the flashcard_status table
	cursor.execute(
		"""
		INSERT INTO flashcard_status(name)
		VALUES(?)
		""", ("unanswered",)
	)

	cursor.execute(
		"""
		INSERT INTO flashcard_status(name)
		VALUES(?)
		""", ("green",)
	)
	
	cursor.execute(
		"""
		INSERT INTO flashcard_status(name)
		VALUES(?)
		""", ("yellow",)
	)
	
	cursor.execute(
		"""
		INSERT INTO flashcard_status(name)
		VALUES(?)
		""", ("red",)
	)

	#Insert stuff into the answer_status table
	cursor.execute(
		"""
		INSERT INTO answer_status(name)
		VALUES(?)
		""", ("unanswered",)
	)
	
	cursor.execute(
		"""
		INSERT INTO answer_status(name)
		VALUES(?)
		""", ("incorrect",)
	)
	
	cursor.execute(
		"""
		INSERT INTO answer_status(name)
		VALUES(?)
		""", ("correct",)
	)

	#Insert stuff into the mnemonic_type table
	cursor.execute(
		"""
		INSERT INTO mnemonic_type(name)
		VALUES(?)
		""",("normal",)
	)

	cursor.execute(
		"""
		INSERT INTO mnemonic_type(name)
		VALUES(?)
		""",("important",)
	)
	

	database.commit()
	cursor.close()
	database.close()


def populateImages(databaseFile, imagesFile):
	
	database = sqlite3.connect(databaseFile)
	cursor = database.cursor()

	csvReader = unicode_csv_reader(open(imagesFile, 'rb'), delimiter = ',')	

	#Loop through each row
	for row in csvReader:	

		#Get each column
		imageNumber = row[0].strip()
		imageName = row[1].strip()

		#Insert it into the database!
		if len(imageName) > 0 and len(imageNumber) > 0:
			cursor.execute(
				"""
				INSERT INTO image(number, name) 
				VALUES(?, ?)
				""", (imageNumber, imageName)
			)

	database.commit()
	cursor.close()
	database.close()

def populateMnemonics(databaseFile, mnemonicsFile):
	
	database = sqlite3.connect(databaseFile)
	cursor = database.cursor()

	csvReader = unicode_csv_reader(open(mnemonicsFile, 'rb'), delimiter = ',')	

	importantMnemonicType = getMnemonicType(cursor, "important")
	normalMnemonicType = getMnemonicType(cursor, "normal")

	#Loop through each row
	for row in csvReader:	

		mnemonicNumber = row[0].strip()
		mnemonicTitle = row[1].strip()
		mnemonicText = row[2].strip()
		mnemonicImportance = row[3].strip()

		if mnemonicImportance == '1':
			mnemonicType = importantMnemonicType
		else:
			mnemonicType = normalMnemonicType

		if len(mnemonicNumber) > 0 and len(mnemonicTitle) > 0 and len(mnemonicText) > 0:
			cursor.execute(
				"""
				INSERT INTO mnemonic(number, title, text, mnemonic_type_id)
				VALUES(?, ?, ?, ?)
				""", (mnemonicNumber, mnemonicTitle, mnemonicText, mnemonicType['id'])
			)

	database.commit()
	cursor.close()
	database.close()

def populateCategories(databaseFile, categoriesFile, isFreeVersion):

	database = sqlite3.connect(databaseFile)
	cursor = database.cursor()
	
	csvReader = unicode_csv_reader(open(categoriesFile, 'rb'), delimiter = ',') 

	#Loop through each row
	for row in csvReader:
	
		#Get each column
		categoryNumberString = row[0].strip()
		categoryName = row[1].strip()
		categoryTypeName = row[2].strip()
		available = row[3].strip()
		enabledByDefault = row[4].strip()

		if len(categoryNumberString) > 0 and len(categoryName) > 0 and len(categoryTypeName):
			categoryType = getCategoryType(cursor, categoryTypeName)
			if categoryType is None:
				print "Couldn't get category type for category type name = %s" % (categoryTypeName)


			#See if the categoryIdString contains a '.'
			categoryNumberParts = categoryNumberString.split('.')
			if len(categoryNumberParts) == 1:
				categoryNumber = categoryNumberParts[0]
				cursor.execute(
					"""
					INSERT INTO category(name, number, category_type_id, available, enabled_by_default)
					VALUES(?, ?, ?, ?, ?)
					""", (categoryName, categoryNumber, categoryType['id'], available, enabledByDefault)
				)
				database.commit()
			else:
				#Get the id for the root category
				rootCategoryNumber = categoryNumberParts[0]
				cursor.execute(
					"""
					SELECT id 
					FROM category 
					WHERE parent_category_id IS NULL
					AND	number = ?
					""", (rootCategoryNumber,)
				)
				row = cursor.fetchone()
				categoryId = row[0]
				categoryIds = []
				categoryIds.append(categoryId)
				lastCategoryId = categoryId

				for index in range(1, len(categoryNumberParts) - 1):
					categoryNumber = categoryNumberParts[index]
					cursor.execute(
						"""
						SELECT id
						FROM category
						WHERE parent_category_id = ?
						AND number = ?
						""", (lastCategoryId, categoryNumber)
					)
					row = cursor.fetchone()
					categoryId = row[0]
					categoryIds.append(categoryId)
					lastCategoryId = categoryId
				
				cursor.execute(
					"""
					INSERT INTO category(name, number, parent_category_id, category_type_id, available, enabled_by_default)
					VALUES(?, ?, ?, ?, ?, ?)
					""", (categoryName, categoryNumberParts[-1], lastCategoryId, categoryType['id'], \
								available, enabledByDefault)
				)
				database.commit()

	database.commit()
	cursor.close()
	database.close()


def populateQuestions(databaseFile, questionsFile):
		
	database = sqlite3.connect(databaseFile)
	cursor = database.cursor()
	
	csvReader = unicode_csv_reader(open(questionsFile, 'rb'), delimiter = ',') 

	for row in csvReader:
		if len(row) < 10:
			print "Can't add row, not enough columns: %s" % (row)
			continue
		categoryNumberString = row[0].strip()
		if(len(categoryNumberString) == 0):
			print "Can't add row, bad category string: %s" % (row)
			continue
		categoryParts = categoryNumberString.split('.')
		category = getCategoryForCategoryParts(cursor, categoryParts)
		if category is None:
			print "Can't add row, bad category id: %s" % (row)
			continue

		if not category['available']:
			continue

		rootCategory = getRootCategoryForCategoryParts(cursor, categoryParts)

		question = row[2].strip()
		choices = row[3].strip()
		answers = row[4].strip()
		rationale = row[5].strip()
		mnemonicField= row[6].strip()
		mnemonicNumbers = mnemonicField.split(';')
		imageNumber = row[7].strip()
		rationalePreview = row[9].strip()

		if len(rationalePreview) == 0 and category['category_type_name'] == 'multiple-choice':
			print "No rationale preview for row: %s" % (row)

		cursor.execute(
			"""
			INSERT INTO flashcard(question, choices, answers, rationale, image_number, rationale_preview, 
														category_id)
			VALUES(?, ?, ?, ?, ?, ?, ?)
			""", (question, choices, answers, rationale, imageNumber, rationalePreview, category['id'])
		)

		flashcardId = cursor.lastrowid

		#Insert the flashcard_mnemonic_link
		for mnemonicNumber in mnemonicNumbers:
			if len(mnemonicNumber):
				cursor.execute(
					"""
					INSERT INTO flashcard_mnemonic_link(flashcard_id, mnemonic_number)
					VALUES(?, ?)
					""", (flashcardId, mnemonicNumber)
				)

	database.commit()
	cursor.close()
	database.close()

	
def populateAchievements(databaseFile):

	database = sqlite3.connect(databaseFile)
	cursor = database.cursor()
	
	cursor.execute(
		"""
		INSERT INTO achievement_type(name)
		VALUES(?)
		""", ('category_completed',)
	)

	cursor.execute(
		"""
		INSERT INTO achievement_type(name)
		VALUES(?)
		""", ('all_flashcards_completed',)
	)

	database.commit()

	#Add the 'all flashcards completed' achievement
	allFlashcardsCompletedAchievementType = getAchievementType(cursor, 'all_flashcards_completed')
	cursor.execute(
		"""
		INSERT INTO achievement(achievement_type_id)
		VALUES(?)
		""", (allFlashcardsCompletedAchievementType['id'],)
	)

	#Add the category specific achievements
	categoryCompletedAchievementType = getAchievementType(cursor, 'category_completed')
	categories = getCategories(cursor)
	for category in categories:

		if category['category_type_name'] != 'quiz':
			cursor.execute(
				"""
				INSERT INTO achievement(achievement_type_id, category_id) 
				VALUES(?, ?)
				""", (categoryCompletedAchievementType['id'], category['id'])
			)

	database.commit()
	cursor.close()
	database.close()


def usage():

	print"Usage: ./create_database.py --database=foo.sql --images=images.csv --categories=categories.csv --mnemonics-mnemonics.csv" \
				"--questions=questions.csv"

def main(argv):

	#Extract the command-line parameters
	try:
		opts, args = getopt.getopt(argv, "", ["database=", "images=", "categories=", "questions=", "free"])
	except getopt.GetoptError:
		usage()
		sys.exit(1)	

	databaseFile = "nbde.sql"
	imagesFile = "images.csv"
	categoriesFile = "categories.csv"
	questionsFile = "questions.csv"
	mnemonicsFile = "mnemonics.csv"
	isFreeVersion = False
	for opt, arg in opts:
		if opt in ("--database"):
			databaseFile = arg
		elif opt in ("--images"):
			imagesFile = arg
		elif opt in ("--categories"):
			categoriesFile = arg
		elif opt in ("--questions"):
			questionsFile = arg
		elif opt in ("--mnemonics"):
			mnemonicsFile = arg
		elif opt in ("--free"):
			isFreeVersion = True

	createDatabase(databaseFile = databaseFile)
	populateConstants(databaseFile = databaseFile)
	populateImages(databaseFile = databaseFile, imagesFile = imagesFile)
	populateMnemonics(databaseFile = databaseFile, mnemonicsFile = mnemonicsFile)
	populateCategories(databaseFile = databaseFile, categoriesFile = categoriesFile, isFreeVersion = isFreeVersion)
	populateQuestions(databaseFile = databaseFile, questionsFile = questionsFile)
	populateAchievements(databaseFile = databaseFile)


if __name__ == '__main__':
	main(sys.argv[1:])


		
