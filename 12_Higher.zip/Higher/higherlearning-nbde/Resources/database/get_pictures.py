#!/usr/bin/python

import getopt
import sys
import sqlite3
import csv
import os
import re

def main(argv):

	#Extract the command-line parameters
	try:
		opts, args = getopt.getopt(argv, "", ["database=", "pictures=", "output="])
	except getopt.GetoptError:
		usage()
		sys.exit(1)

	databaseFile = "nbde.sql"
	picturesDirectory = "pictures"
	outputDirectory = "nbde-pictures"
	for opt, arg in opts:
		if opt in ("--database"):
			databaseFile = arg
		elif opt in ("--pictures"):
			picturesDirectory = arg
		elif opt in ("--output"):
			outputDirectory = arg
		
	#Create the directory if it doesn't exist
	try:
		os.mkdir(outputDirectory)
	except OSError, e:
		pass	
	
	#Delete all of the existing images in the directory
	images = os.listdir(outputDirectory)
	for image in images:
		os.unlink(image)

	
	database = sqlite3.connect(databaseFile)
	cursor = database.cursor()

	


	
	


if __name__ == '__main__':
	main(sys.argv[1:])


