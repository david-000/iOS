//
//  MnemonicsListVC.m
//  iPhoneProject
//
//  Created by MacBook on 7/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MnemonicsListVC.h"
#import "iPhoneProjectAppDelegate.h"
#import "FlashCard.h"
#import "MnemonicsDB.h"
#import "AddMnemonicVC.h"
#import "MnemonicCell.h"
#import "Mnemonic.h"
#import "GANTracker.h"
#import "MnemonicVC.h"

@implementation MnemonicsListVC

@synthesize myTableView;
@synthesize btnAdd;
@synthesize mnemonicTypeName;
@synthesize txtSearchBar;


- (id) initWithMnemonicTypeName:(NSString *)_mnemonicTypeName {
    
    NSString *nib = NibName(@"MnemonicsListVC");
    self = [super initWithNibName:nib bundle:nil];
    if(self) {
        self.mnemonicTypeName = _mnemonicTypeName;
        cells = [[NSMutableArray alloc] init];
        copyOfCells = [[NSMutableArray alloc] init];
        mnemonics = [[NSMutableArray alloc] init];
        copyOfMnemonics = [[NSMutableArray alloc] init];
    }
 
    return self;
}

- (void) dealloc{
    
    myTableView.delegate = nil;
    myTableView.dataSource = nil;
    [myTableView release];
    [btnAdd release];
    [cells release];
    [copyOfCells release];
    [mnemonics release];
    [copyOfMnemonics release];
    [txtSearchBar release];
    
    [super dealloc];
    
}

- (IBAction) doAddMnemonic:(id)sender
{
    AddMnemonicVC *addMnemonics;
    if ([Util isIPad])
        addMnemonics = [[AddMnemonicVC alloc] initWithNibName:@"AddMnemonicVC_IPad" bundle:nil];
    else
        addMnemonics = [[AddMnemonicVC alloc] initWithNibName:@"AddMnemonicVC" bundle:nil];
    
    [self.navigationController pushViewController:addMnemonics animated:YES];
    
    [addMnemonics release];
}

- (IBAction)searchBarTextDidBeginEditing:(id)sender {
    
    searching = YES;
    letUserSelectRow = NO;
    myTableView.scrollEnabled = NO;
    
}

- (IBAction)textDidChange:(id)sender {
    
    //Remove all objects first.
    [copyOfCells removeAllObjects];
    
    if([txtSearchBar.text length] != 0) {
        
        searching = YES;
        letUserSelectRow = YES;
        myTableView.scrollEnabled = YES;
        [self searchTableView];
    }
    else {
        searching = NO;
        letUserSelectRow = NO;
        myTableView.scrollEnabled = NO;
    }
    
    [myTableView reloadData];
}

- (IBAction)searchBarTextDidEndEditing:(id)sender
{
    [txtSearchBar resignFirstResponder];
}

- (IBAction)searchBarSearchButtonClicked:(id)sender{
    
    [self searchTableView];
    [txtSearchBar resignFirstResponder];
}
#pragma mark UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self searchTableView];
    [txtSearchBar resignFirstResponder];
    return YES;
}

- (void)searchTableView
{
    
    [copyOfCells removeAllObjects];
    [copyOfMnemonics removeAllObjects];
    
    for (Mnemonic *mnemonic in mnemonics) {
        if (txtSearchBar.text.length == 0) {
            [copyOfMnemonics addObject:mnemonic];
            
            NSInteger index = [mnemonics indexOfObject:mnemonic];
            MnemonicCell *cell = [cells objectAtIndex:index];
            [copyOfCells addObject:cell];
            
            continue;
        }
        
        NSRange titleResultsRange = [mnemonic.title rangeOfString:txtSearchBar.text options:NSCaseInsensitiveSearch];
        NSRange textResultsRange = [mnemonic.text rangeOfString:txtSearchBar.text options:NSCaseInsensitiveSearch];
        
        if (titleResultsRange.length || textResultsRange.length) {
            
            [copyOfMnemonics addObject:mnemonic];

            NSInteger index = [mnemonics indexOfObject:mnemonic];
            MnemonicCell *cell = [cells objectAtIndex:index];
            [copyOfCells addObject:cell];
    
        }
    }
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        [self initViewComponents];
                
    }
    return self;
}

- (void) initViewComponents
{
    
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    if (searching)
        return [copyOfCells count];
    else {
        return [cells count];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return 1;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
        
    if(searching) {
    
        MnemonicCell *cell = [copyOfCells objectAtIndex:indexPath.row];
        return cell;
        
    } else {
        MnemonicCell *cell = [cells objectAtIndex:indexPath.row];
        return cell;
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    [txtSearchBar resignFirstResponder];
    
    Mnemonic *mnemonic = searching ? [copyOfMnemonics objectAtIndex:indexPath.row] : [mnemonics objectAtIndex:indexPath.row];
    MnemonicVC *controller = [[MnemonicVC alloc] initWithDelegate:self mnemonic:mnemonic];
    /*
    [self presentViewController:controller
                       animated:YES
                     completion:^{
    }];
    */
    [self presentModalViewController:controller animated:YES];
    [controller release];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
 
    MnemonicCell *cell = searching ? [copyOfCells objectAtIndex:indexPath.row] : [cells objectAtIndex:indexPath.row];
    return cell.frame.size.height;
    
}

#if (mType == SAVEDMNEMONICS)

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        if(searching) {
            Mnemonic *mnemonic = [copyOfMnemonics objectAtIndex:indexPath.row];
            [[MnemonicsDB instance] removeMnemonic:mnemonic];
            [copyOfMnemonics removeObjectAtIndex:indexPath.row];
        } else {
            Mnemonic *mnemonic = [mnemonics objectAtIndex:indexPath.row];
            [[MnemonicsDB instance] removeMnemonic:mnemonic];
            [mnemonics removeObjectAtIndex:indexPath.row];
        }
        
        [myTableView reloadData];
        
    }
    
}

#endif

#pragma mark - View lifecycle

- (void)viewDidAppear:(BOOL)animated
{
    
    [super viewDidAppear:animated];
    
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Mnemonics List"
                                        withError:&error]) {
        NSLog(@"Could not track pageview: %@", error);
    }
    
    [mnemonics removeAllObjects];
    
    if([mnemonicTypeName isEqualToString:@"all"]) {
        [mnemonics addObjectsFromArray:[[MnemonicsDB instance] getAllMnemonics]];
        [btnAdd setHidden:YES];
    } else if([mnemonicTypeName isEqualToString:@"important"]) {
        [mnemonics addObjectsFromArray:[[MnemonicsDB instance] getMnemonicsForType:@"important"]];
        [btnAdd setHidden:YES];
    } else if([mnemonicTypeName isEqualToString:@"saved"]) {
        [mnemonics addObjectsFromArray:[[MnemonicsDB instance] getSavedMnemonics]];
        [mnemonics addObjectsFromArray:[[MnemonicsDB instance] getUserMnemonics]];
        [btnAdd setHidden:NO];
    }

 
    [cells removeAllObjects];
    [copyOfCells removeAllObjects];
    
    int index = 0;
    for(Mnemonic *mnemonic in mnemonics) {
        index ++;
        MnemonicCell *cell;
        if (index % 2 == 0) {
            cell = [[MnemonicCell alloc] initWithTitle:mnemonic.title
                                                               width:myTableView.frame.size.width
                                                           fillcolor:[UIColor lightGrayColor]];
        }
        else{
            cell = [[MnemonicCell alloc] initWithTitle:mnemonic.title
                                                               width:myTableView.frame.size.width
                                                           fillcolor:[UIColor whiteColor]];
        }
        
        [cells addObject:cell];
        [copyOfCells addObject:cell];
        
    }
    
    myTableView.dataSource = self;
    myTableView.delegate = self;
    
    [myTableView reloadData];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
     myTableView.dataSource = nil;
     myTableView.delegate = nil;
    // Do any additional setup after loading the view from its nib.
    
    mnemonics = [[NSMutableArray alloc] init];
    copyOfMnemonics = [[NSMutableArray alloc] init];
    cells = [[NSMutableArray alloc] init];
    copyOfCells = [[NSMutableArray alloc] init];
    
    //Add the search bar
    txtSearchBar.autocorrectionType = UITextAutocorrectionTypeNo;
    
    searching = NO;
    letUserSelectRow = YES;
    
    if([Util isFreeVersion]) {
        btnAdd.hidden = YES;
    }
    
        
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

#pragma mark MnemonicVCDelegate methods

- (void) dismissMnemonicVC {

    [self dismissViewControllerAnimated:YES
                             completion:^{}];
    
}

@end
