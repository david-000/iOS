//
//  StudyVC.m
//  iPhoneProject
//
//  Created by MacBook on 6/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "StudyVC.h"
#import "Util.h"
#import "CategoryVC.h"
#import "MnemonicMenuVC.h"
#import "ExamStrategiesVC.h"
#import "StudyStrategiesVC.h"
#import "GANTracker.h"

#define kFlashcardsCellIndex 0
#define kTerminologyCellIndex 1
#define kMnemonicsCellIndex 2
#define kStudyStrategiesCellIndex 3
#define kExamStrategiesCellIndex 4
#define kNumberOfCells 5

@interface StudyVC (Private)

- (void)onFlashcardsButton;
- (void)onTerminologyButton;
- (void)onMnemonicsButton;
- (void)onStudyButton;
- (void)onExamButton;

@end

@implementation StudyVC

#pragma mark -
#pragma mark UITableViewDelegate

- (id) init {
    
    NSString *nib = NibName(@"StudyVC");
    self = [super initWithNibName:nib bundle:nil];
    if(self) {
     
        UITableViewCell *flashcardsCell;
        UITableViewCell *terminologyCell;
        UITableViewCell *mnemonicsCell;
        UITableViewCell *studyCell;
        UITableViewCell *examCell;
        CGRect btnRect;
        //Create the cells
        if ([[UIDevice currentDevice] userInterfaceIdiom] != UIUserInterfaceIdiomPad) {
            btnRect = CGRectMake(0, 0, 287, 42);
            flashcardsCell = [self createCellWithImage:@"flashcards_0.png" highlight:@"flashcards_1.png" rect:btnRect selector:@selector(onFlashcardsButton)];
            terminologyCell = [self createCellWithImage:@"tenminology_0.png" highlight:@"tenminology_1.png" rect:btnRect selector:@selector(onTerminologyButton)];
            mnemonicsCell = [self createCellWithImage:@"mnemonics_0.png" highlight:@"mnemonics_1.png" rect:btnRect selector:@selector(onMnemonicsButton)];
            studyCell = [self createCellWithImage:@"study strategies_0.png" highlight:@"study strategies_1.png" rect:btnRect selector:@selector(onStudyButton)];
            examCell = [self createCellWithImage:@"exam strategies_0.png" highlight:@"exam strategies_1.png" rect:btnRect selector:@selector(onExamButton)];
        }
        else
        {
            btnRect = CGRectMake(0, 0, 686, 102);
            flashcardsCell = [self createCellWithImage:@"flashcards_0_ipad.png" highlight:@"flashcards_1_ipad.png" rect:btnRect selector:@selector(onFlashcardsButton)];
            terminologyCell = [self createCellWithImage:@"tenminology_0_ipad.png" highlight:@"tenminology_1_ipad.png" rect:btnRect selector:@selector(onTerminologyButton)];
            mnemonicsCell = [self createCellWithImage:@"mnemonics_0_ipad.png" highlight:@"mnemonics_1_ipad.png" rect:btnRect selector:@selector(onMnemonicsButton)];
            studyCell = [self createCellWithImage:@"study strategies_0_ipad.png" highlight:@"study strategies_1_ipad.png" rect:btnRect selector:@selector(onStudyButton)];
            examCell = [self createCellWithImage:@"exam strategies_0_ipad.png" highlight:@"exam strategies_1_ipad.png" rect:btnRect selector:@selector(onExamButton)];
        }
        //Add the cells to an array
        [cells addObject:flashcardsCell];
        [cells addObject:terminologyCell];
        [cells addObject:mnemonicsCell];
        [cells addObject:studyCell];
        [cells addObject:examCell];
        
    }
    
    return self;
}

- (void) dealloc {
    
    [super dealloc];
    
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewDidAppear:(BOOL)animated {
 
    [super viewDidAppear:animated];
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Study Menu"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

@end

@implementation StudyVC (Private)

- (void)onFlashcardsButton {
    
    CategoryVC *controller = [[CategoryVC alloc] initWithCategoryType:@"multiple-choice"];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

- (void)onTerminologyButton {
    
    CategoryVC *controller = [[CategoryVC alloc] initWithCategoryType:@"terminology"];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

- (void)onMnemonicsButton {
    
    MnemonicMenuVC *controller = [[MnemonicMenuVC alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

- (void)onStudyButton {
    
    StudyStrategiesVC *controller = [[StudyStrategiesVC alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

- (void)onExamButton {
    
    ExamStrategiesVC *controller = [[ExamStrategiesVC alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

@end
