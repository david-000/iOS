

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>
#import "MenuVC.h"

@interface MnemonicMenuVC : MenuVC<MFMailComposeViewControllerDelegate>{

    
}

//- (void) sendMailUs;

@end
