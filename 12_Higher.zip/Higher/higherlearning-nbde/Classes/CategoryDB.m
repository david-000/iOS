//
//  StudentsDB.m
//  MySQLiteProject
//


#import "CategoryDB.h"
#import <sqlite3.h>
#import "FlashCard.h"
#import "Category.h"

@implementation CategoryDB


- (id) init{
	if (self = [super init]) {

	}
	return self;
}

+ (CategoryDB *) instance {
 
    static CategoryDB *instance = nil;
    if(!instance) {
        instance = [[CategoryDB alloc] init];
    }
    
    return instance;

}

- (NSArray *)getAllCategoryIds {
 
    const char *query = "SELECT id "
                        "FROM category ";
    
    sqlite3_stmt *stmt = nil;
    NSMutableArray *categoryIds = [NSMutableArray array];
    
    if(sqlite3_prepare_v2(self.database, query, -1, &stmt, NULL) != SQLITE_OK) {
        NSLog(@"Unable to prepare statement in getAllCategoryIds: %s", sqlite3_errmsg(self.database));
        return nil;
    }
    
    while(sqlite3_step(stmt) == SQLITE_ROW) {
        
        const NSInteger categoryId = sqlite3_column_int(stmt, 0);
        [categoryIds addObject:[NSNumber numberWithInt:categoryId]];
        
    }
    
    sqlite3_finalize(stmt);
    
    return categoryIds;
    
}


- (NSMutableArray *)getRootCategoriesForCategoryType:(NSString *)categoryTypeName {
    
    sqlite3_stmt *stmt = nil;
    
    NSMutableArray *categories = [NSMutableArray array];
    
    const char *sql =   "select category.id, "
                        "       category.name, "
                        "       user.category_state.enabled, "
                        "       category.available, "
                        "       category.parent_category_id, "
                        "       category.category_type_id, "
                        "       category.enabled_by_default, "
                        "       category_type.name "
                        "from   category, "
                        "       category_type, "
                        "       user.category_state "
                        "where  category.parent_category_id is NULL "
                        "and    category_type.id = category.category_type_id "
                        "and    category_type.name = ? "
                        "and    user.category_state.category_id = category.id ";
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_text(stmt, 1, [categoryTypeName UTF8String], -1, SQLITE_TRANSIENT);
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            const NSInteger categoryId = sqlite3_column_int(stmt, 0);
            const char *categoryName = (const char *)sqlite3_column_text(stmt, 1);
            const BOOL enabled = sqlite3_column_int(stmt, 2) ? YES : NO;
            const BOOL available = sqlite3_column_int(stmt, 3) ? YES : NO;
            const NSInteger parentCategoryId = sqlite3_column_int(stmt, 4);
            const NSInteger categoryTypeId = sqlite3_column_int(stmt, 5);
            const BOOL enabledByDefault = sqlite3_column_int(stmt, 6) ? YES : NO;
            const char *categoryTypeName = (const char *)sqlite3_column_text(stmt, 7);
             
            Category *category = [[Category alloc] initWithCategoryID:categoryId
                                                     parentCategoryID:parentCategoryId
                                                         categoryName:categoryName
                                                              enabled:enabled
                                                            available:available
                                                       categoryTypeId:categoryTypeId
                                                     categoryTypeName:categoryTypeName
                                                     enabledByDefault:enabledByDefault];
            
            [categories addObject:category];
            [category release];
            
        }
    } else {
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return nil;
    }
    
	sqlite3_finalize(stmt);
    
	return categories;
    
}


- (Category *) getCategory:(NSInteger)categoryId {
    
    sqlite3_stmt *stmt = nil;
    
    const char *sql =   "select category.id, "
                        "       category.name, "
                        "       user.category_state.enabled, "
                        "       category.available, "
                        "       category.parent_category_id, "
                        "       category.category_type_id, "
                        "       category.enabled_by_default, "
                        "       category_type.name "
                        "from   category, "
                        "       category_type, "
                        "       user.category_state "
                        "where  category.id = ? "
                        "and    user.category_state.category_id = category.id ";
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_int(stmt, 1, categoryId);
        if(sqlite3_step(stmt) == SQLITE_ROW) {
            
            const NSInteger categoryId = sqlite3_column_int(stmt, 0);
            const char *categoryName = (const char *)sqlite3_column_text(stmt, 1);
            const BOOL enabled = sqlite3_column_int(stmt, 2) ? YES : NO;
            const BOOL available = sqlite3_column_int(stmt, 3) ? YES : NO;
            const NSInteger parentCategoryId = sqlite3_column_int(stmt, 4);
            const NSInteger categoryTypeId = sqlite3_column_int(stmt, 5);
            const BOOL enabledByDefault = sqlite3_column_int(stmt, 6) ? YES : NO;
            const char *categoryTypeName = (const char *)sqlite3_column_text(stmt, 7);
            
            Category *category = [[Category alloc] initWithCategoryID:categoryId
                                                     parentCategoryID:parentCategoryId
                                                         categoryName:categoryName
                                                              enabled:enabled
                                                            available:available
                                                       categoryTypeId:categoryTypeId
                                                     categoryTypeName:categoryTypeName
                                                     enabledByDefault:enabledByDefault];
            sqlite3_finalize(stmt);
            return [category autorelease];
        } else {
            return nil;
        }
    } else {
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return nil;
    }
    
}

- (NSMutableArray *) getCategoryHeirarchy:(NSInteger)categoryId {

    NSMutableArray *categories = [NSMutableArray array];

    Category *category = [self getCategory:categoryId];
    [categories addObject:category];
    
    Category *parent = category;
    
    while(parent) {

        parent = [self getCategory:parent.parentCategoryId];
        if(parent) {
            [categories addObject:parent];
        }
        
    }
     
    return categories;
    
}


- (NSMutableArray *) getChildCategoriesForCategory:(NSInteger)categoryId
                                         recursive:(BOOL)recursive {
 
    sqlite3_stmt *stmt = nil;
        
    const char *sql =   "select category.id, "
                        "       category.name, "
                        "       user.category_state.enabled, "
                        "       category.available, "
                        "       category.parent_category_id, "
                        "       category.category_type_id, "
                        "       category.enabled_by_default, "
                        "       category_type.name "
                        "from   category, "
                        "       category_type, "
                        "       user.category_state "
                        "where  category.parent_category_id = ? "
                        "and    category_type.id = category.category_type_id "
                        "and    user.category_state.category_id = category.id ";
    
    NSMutableArray *children = [NSMutableArray array];
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_int(stmt, 1, categoryId);
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            const NSInteger categoryId = sqlite3_column_int(stmt, 0);
            const char *categoryName = (const char *)sqlite3_column_text(stmt, 1);
            const BOOL enabled = sqlite3_column_int(stmt, 2) ? YES : NO;
            const BOOL available = sqlite3_column_int(stmt, 3) ? YES : NO;
            const NSInteger parentCategoryId = sqlite3_column_int(stmt, 4);
            const NSInteger categoryTypeId = sqlite3_column_int(stmt, 5);
            const BOOL enabledByDefault = sqlite3_column_int(stmt, 6) ? YES : NO;
            const char *categoryTypeName = (const char *)sqlite3_column_text(stmt, 6);
            
            Category *category = [[Category alloc] initWithCategoryID:categoryId
                                                     parentCategoryID:parentCategoryId
                                                         categoryName:categoryName
                                                              enabled:enabled
                                                            available:available
                                                       categoryTypeId:categoryTypeId
                                                     categoryTypeName:categoryTypeName
                                                     enabledByDefault:enabledByDefault];
            
            [children addObject:category];
            [category release];
            
        }
    } else {
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return nil;
    }
    
	sqlite3_finalize(stmt);
	
    
    if(recursive) {
     
        NSMutableArray *recursiveChildren = [NSMutableArray array];
        
        for(Category *childCategory in children) {
            [recursiveChildren addObjectsFromArray:[self getChildCategoriesForCategory:childCategory.categoryID
                                                                             recursive:YES]];
        }

        [children addObjectsFromArray:recursiveChildren];
        
    }
    
	return children;

}



- (BOOL) updateCategory:(NSInteger)categoryId
                enabled:(BOOL)enabled
              recursive:(BOOL)recursive {
    
    sqlite3_stmt *stmt = nil;
    
    const char *sql =   "UPDATE user.category_state "
                        "SET    enabled = ? "
                        "WHERE  user.category_state.category_id = ? ";
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {

        sqlite3_bind_int(stmt, 1, enabled ? 1 : 0);
        sqlite3_bind_int(stmt, 2, categoryId);
        
        if(sqlite3_step(stmt) != SQLITE_DONE) {
            sqlite3_finalize(stmt);
            return NO;
        }
        
    }  else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return NO;
        
    }
    
    sqlite3_finalize(stmt);
    
    if(recursive) {
        [self updateChildCategoriesForCategory:categoryId
                                       enabled:enabled
                                     recursive:recursive];
    }
    
    return YES;
    
}

- (BOOL) updateChildCategoriesForCategory:(NSInteger)categoryId
                                  enabled:(BOOL)enabled
                                recursive:(BOOL)recursive {
 
    sqlite3_stmt *stmt = nil;
    const char *sql =   "UPDATE user.category_state "
                        "SET    enabled = ? "
                        "WHERE  user.category_state.category_id IN "
                        "       (SELECT id "
                        "        FROM category "
                        "        WHERE parent_category_id = ?) ";

    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_int(stmt, 1, enabled ? 1 : 0);
        sqlite3_bind_int(stmt, 2, categoryId);
        
        if(sqlite3_step(stmt) != SQLITE_DONE) {
            sqlite3_finalize(stmt);
            return NO;
        }
        
    }  else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return NO;
        
    }

    sqlite3_finalize(stmt);
    
    if(recursive) {
        NSMutableArray *children = [self getChildCategoriesForCategory:categoryId
                                                             recursive:YES];
        for(Category *childCategory in children) {
            [self updateChildCategoriesForCategory:childCategory.categoryID
                                           enabled:enabled
                                         recursive:recursive];
        }
        
    }
    
    
    return YES;
    
}

- (BOOL)isCategoryEnabledByDefault:(NSInteger) categoryId {
    
    sqlite3_stmt *stmt = nil;
    const char *sql =   "SELECT enabled_by_default "
                        "FROM   category "
                        "WHERE  id = ? ";

    BOOL enabled = NO;
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_int(stmt, 1, categoryId);
        
        if(sqlite3_step(stmt) != SQLITE_DONE) {
            enabled = sqlite3_column_int(stmt, 0);
        }
        
    }  else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return NO;
        
    }
    
    sqlite3_finalize(stmt);
    
    return enabled;
    
}


- (void) dealloc {
    
	[super dealloc];
    
}


@end
