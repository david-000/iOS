//
//  QuestionVC.m

#import <QuartzCore/QuartzCore.h>
#import "AnswerVC.h"
#import "QuestionCell.h"
#import "FlashCardsDB.h"
#import "Util.h"
#import "Global.h"
#import "Mnemonic.h"
#import "Flashcard.h"
#import "Image.h"
#import "AnswerCell.h"
#import "Image.h"
#import "Mnemonic.h"
#import "iPhoneProjectAppDelegate.h"

#define kQuestionSection 0
#define kAnswerSection 1

@implementation AnswerVC

@synthesize flashCard;
@synthesize myTableView;
@synthesize footerHeight;

- (void)dealloc {
    
    myTableView.delegate = nil;
    myTableView.dataSource = nil;
    [myTableView release];
    [flashCard release];
	[cells release];
    [super dealloc];
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
		flashCard = nil;
        cells = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void) initComponentsWithFlashCard:(FlashCard*)card {
    
	self.flashCard = card;
    
    //Initialize the tableview cells
    [cells removeAllObjects];
    
    //Initialize the question cell
    QuestionCell *questionCell = [[QuestionCell alloc] initWithQuestionText:flashCard.question
                                                          extraQuestionText:flashCard.extraQuestionText
                                                        flashcardStatusName:flashCard.flashcardStatusName
                                                                      width:myTableView.bounds.size.width];
    [cells addObject:[NSArray arrayWithObject:questionCell]];
    [questionCell release];
    
    NSMutableArray *answerCells = [NSMutableArray array];
    for(Answer *answer in self.flashCard.answers) {
        AnswerCell *answerCell = [[AnswerCell alloc] initWithAnswer:answer
                                                              width:myTableView.bounds.size.width
                                                           delegate:nil
                                                      textAlignment:NSTextAlignmentLeft];
        answerCell.userInteractionEnabled = NO;
        [answerCell markCell];
        [answerCells addObject:answerCell];
        [answerCell release];
    }
    
    [cells addObject:answerCells];
    
    myTableView.backgroundColor = [UIColor clearColor];
    myTableView.backgroundView = nil;
    [myTableView scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:NO];
    [myTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [myTableView reloadData];
    
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [[cells objectAtIndex:section] count];
     
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return [cells count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [[cells objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    return cell.bounds.size.height;
    
}


- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
		    
    return [[cells objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    
    if(section == kQuestionSection) {
        return 0;
    } else {
        if(flashCard.rationalePreview) {
            return footerHeight;
        } else {
            return 0;
        }
    }
    
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
 
    return nil;
    
}

#pragma UITableViewDataSource

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {
    [super viewDidUnload];
}

@end
