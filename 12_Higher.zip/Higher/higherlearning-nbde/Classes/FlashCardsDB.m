//
//  StudentsDB.m
//  MySQLiteProject
//

#import "FlashCardsDB.h"
#import "FlashCard.h"
#import "Category.h"
#import "Mnemonic.h"
#import "CategoryDB.h"
#import "Image.h"
#import "MnemonicsDB.h"

@interface FlashCardsDB (Private)

- (NSMutableString *)getBaseFlashcardQuery;
- (FlashCard *)getFlashcardFromStatement:(sqlite3_stmt *)stmt;

@end

@implementation FlashCardsDB

- (id) init{
    
	if (self = [super init]) {
        
	}
	return self;
    
}

+ (FlashCardsDB *)instance {
    
    static FlashCardsDB *instance = nil;
    if(!instance) {
        instance = [[FlashCardsDB alloc] init];
    }
    
    return instance;
    
}

- (NSMutableArray*) getFlashCardsWithCategoryID:(int) categoryID
                            flashcardStatusName:(NSString *)flashcardStatusName {
    
	NSMutableArray* flashcards = [NSMutableArray array];
	
	sqlite3_stmt *stmt = nil;
	
    NSMutableString *sql = [self getBaseFlashcardQuery];
    [sql appendString:@"where category_id = ? "
                        "and flashcard_status_name = ? "];
    
    if(sqlite3_prepare_v2(self.database, [sql UTF8String], -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_int(stmt, 1, categoryID);
        sqlite3_bind_text(stmt, 2, [flashcardStatusName UTF8String], -1, SQLITE_TRANSIENT);
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            FlashCard *flashcard = [self getFlashcardFromStatement:stmt];
            [flashcards addObject:flashcard];
            [flashcard release];
            
        }
    }
	
	//Even though the open call failed, close the database connection to release all the memory.
	sqlite3_finalize(stmt);
    
	return flashcards;
}

- (FlashCard *) getFlashcardWithId:(NSInteger)flashcardId {
     
    NSMutableString *query = [self getBaseFlashcardQuery];
    [query appendString:@"WHERE flashcard.id = ? "];
    
    FlashCard *flashcard = nil;
    
    sqlite3_stmt *stmt = nil;
    
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &stmt, NULL) == SQLITE_OK) {
     
        sqlite3_bind_int(stmt, 1, flashcardId);
        
        if(sqlite3_step(stmt) == SQLITE_ROW) {
            
            flashcard = [self getFlashcardFromStatement:stmt];
            
        }
        
    } else {
        
        printf( "could not prepare statement in getFlashcardWithId: %s\n", sqlite3_errmsg(self.database) );
        return nil;
        
    }
    
	sqlite3_finalize(stmt);
    
    return flashcard;
    
}

- (NSMutableArray *)getAllFlashcardIds {
 
    const char *query = "SELECT id "
                        "FROM flashcard ";
    
    sqlite3_stmt *stmt = nil;
    NSMutableArray *flashcardIds = [NSMutableArray array];
    
    if(sqlite3_prepare_v2(self.database, query, -1, &stmt, NULL) == SQLITE_OK) {
                
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            const NSInteger flashcardId = sqlite3_column_int(stmt, 0);
            [flashcardIds addObject:[NSNumber numberWithInt:flashcardId]];
            
        }
        
    } else {
        
        printf( "could not prepare statemnt in getAllFlashcardIds: %s\n", sqlite3_errmsg(self.database) );
        return nil;
        
    }
    
    sqlite3_finalize(stmt);
    
    return flashcardIds;
}



- (NSMutableArray *)getEnabledFlashcardIdsWithStatus:(NSString *)flashcardStatusName
                                    categoryTypeName:(NSString *)categoryTypeName {
    
    const char *query = "SELECT flashcard.id "
                        "FROM   flashcard "
                        "JOIN   category ON category.id = flashcard.category_id "
                        "JOIN   category_type ON category_type.id = category.category_type_id "
                        "JOIN   user.flashcard_state ON user.flashcard_state.flashcard_id = flashcard.id "
                        "JOIN   flashcard_status ON flashcard_status.id = user.flashcard_state.flashcard_status_id "
                        "JOIN   user.category_state ON user.category_state.category_id = category.id "
                        "WHERE  user.category_state.enabled = 1 "
                        "AND    category_type.name = ? "
                        "AND    flashcard_status.name = ? ";
    
    sqlite3_stmt *stmt = nil;
    NSMutableArray *flashcardIds = [NSMutableArray array];
    
    if(sqlite3_prepare_v2(self.database, query, -1, &stmt, NULL) == SQLITE_OK) {

        sqlite3_bind_text(stmt, 1, [categoryTypeName UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 2, [flashcardStatusName UTF8String], -1, SQLITE_TRANSIENT);
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            const NSInteger flashcardId = sqlite3_column_int(stmt, 0);
            [flashcardIds addObject:[NSNumber numberWithInt:flashcardId]];
             
        }
        
    } else {
        
        printf( "could not prepare statemnt in getEnabledFlashcardIdsWithStatus: %s\n", sqlite3_errmsg(self.database) );
        return nil;
        
    }
    
    sqlite3_finalize(stmt);
    
    return flashcardIds;

}

- (NSMutableArray*) getFlashCardsWithStatus:(NSString *)flashcardStatusName
                          categoryTypeName:(NSString *)categoryTypeName {
    
	NSMutableArray* flashcards = [NSMutableArray array];

	sqlite3_stmt *stmt = nil;
    
    NSMutableString *query = [self getBaseFlashcardQuery];
    [query appendString:    @"where flashcard_status.name = ? "
                            "and    category_type.name = ? "];
    
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_text(stmt, 1, [flashcardStatusName UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 2, [categoryTypeName UTF8String], -1, SQLITE_TRANSIENT);

        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            FlashCard *flashcard = [self getFlashcardFromStatement:stmt];
            [flashcards addObject:flashcard];
            [flashcard release];
            
        }
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return nil;
        
    }
	
	sqlite3_finalize(stmt);
	
	return flashcards;
    
}

- (NSMutableArray*) getAllFlashCardsForCategoryType:(NSString *)categoryTypeName {
    
	NSMutableArray* flashcards = [NSMutableArray array];
    
	sqlite3_stmt *stmt = nil;
    
    NSMutableString *query = [self getBaseFlashcardQuery];
    [query appendString:    @"WHERE category_type.name = ? "];
    
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_text(stmt, 1, [categoryTypeName UTF8String], -1, SQLITE_TRANSIENT);
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            FlashCard *flashcard = [self getFlashcardFromStatement:stmt];
            [flashcards addObject:flashcard];
            [flashcard release];
            
        }
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return nil;
        
    }
	
	//Even though the open call failed, close the database connection to release all the memory.
	sqlite3_finalize(stmt);
	
	return flashcards;
}

- (NSMutableArray *) getFlashCardsWithCategoryID:(int)categoryID
                                       recursive:(BOOL)recursive {
 
    NSMutableArray* flashcards = [NSMutableArray array];
    
	sqlite3_stmt *stmt = nil;
    
    NSMutableString *query = [self getBaseFlashcardQuery];
    [query appendString:    @"WHERE category.id = ? "];
    
    if(sqlite3_prepare_v2(self.database, [query UTF8String], -1, &stmt, NULL) == SQLITE_OK) {
          
        sqlite3_bind_int(stmt, 1, categoryID);
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            FlashCard *flashcard = [self getFlashcardFromStatement:stmt];
            [flashcards addObject:flashcard];
            [flashcard release];
            
        }
        
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return nil;
        
    }
	
	//Even though the open call failed, close the database connection to release all the memory.
	sqlite3_finalize(stmt);
	
    
    NSArray *children = [[CategoryDB instance] getChildCategoriesForCategory:categoryID
                                                                   recursive:YES];
    for(Category *child in children) {
        
        NSArray *childFlashcards = [self getFlashCardsWithCategoryID:child.categoryID
                                                           recursive:YES];
        [flashcards addObjectsFromArray:childFlashcards];
        
    }
    
	return flashcards;
    
}
 


- (BOOL) updateFlashCardWithFlashcardStatus:(NSString *)flashcardStatusName
                                     cardID:(NSInteger) cardID {
	BOOL ret = YES;
	sqlite3_stmt *stmt = nil;
    const char *sql =   "update user.flashcard_state  "
                        "set    flashcard_status_id = "
                        "       (SELECT     id "
                        "       FROM        flashcard_status "
                        "       WHERE       name = ?) "
                        "where  flashcard_id = ? ";
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {	

        sqlite3_bind_text(stmt, 1, [flashcardStatusName UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_int(stmt, 2, cardID);

        if(SQLITE_DONE != sqlite3_step(stmt)){
            ret = NO;
        }
        
    } else {
        
        printf( "could not prepare statement in updateFlashCardWithNewStatus:cardID: %s\n", sqlite3_errmsg(self.database) );
        ret = NO;
    }

	
	//Even though the open call failed, close the database connection to release all the memory.
	sqlite3_finalize(stmt);
	
	return ret;
    
}

    
- (BOOL) updateFlashCardWithAnswerStatus:(NSString *)answerStatusName
                                  cardID:(NSInteger) cardID {
    
	BOOL ret = YES;
	
	sqlite3_stmt *stmt = nil;
    const char *sql =   "update user.flashcard_state "
                        "set    answer_status_id = "
                        "       (   SELECT  id "
                        "           FROM    answer_status "
                        "           WHERE   name = ? "
                        "       ) "
                        "where  flashcard_id = ?";
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {	
        
        sqlite3_bind_text(stmt, 1, [answerStatusName UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_int(stmt, 2, cardID);

        
        if(SQLITE_DONE != sqlite3_step(stmt)){
            printf("could not update flashcard answer status: %s\n", sqlite3_errmsg(self.database));
            ret = NO;
        }
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        ret = NO;
    }
	
	sqlite3_finalize(stmt);
	
	return ret;
}

- (BOOL) updateFlashCardWithNewTime:(double) time cardID:(NSInteger) cID{
	BOOL ret = YES;
	
	sqlite3_stmt *stmt = nil;	
    const char *sql = "update user.flashcard_state set time = ? where flashcard_id = ?";
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {	
        
        sqlite3_bind_double(stmt, 1, time);
        sqlite3_bind_int(stmt, 2, cID);
        
        if(SQLITE_DONE != sqlite3_step(stmt)){
            ret = NO;
        }
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        ret = NO;
    }
	
	//Even though the open call failed, close the database connection to release all the memory.
	sqlite3_finalize(stmt);
	
	return ret;
    
}

- (BOOL) resetFlashCardsWithCategoryID:(int) categoryID
                             recursive:(BOOL)recursive {
    
    BOOL ret = YES;
	
	sqlite3_stmt *stmt = nil;
    
    const char *sql =   "update user.flashcard_state "
                        "set    flashcard_status_id = "
                        "       (SELECT id "
                        "       FROM    flashcard_status "
                        "       WHERE   name = 'unanswered'), "
                        "       answer_status_id = "
                        "       (SELECT id "
                        "       FROM    answer_status "
                        "       WHERE name = 'unanswered'), "
                        "       time = 0 "
                        "where  flashcard_id IN "
                        "       (   SELECT  id "
                        "           FROM    flashcard "
                        "           WHERE   category_id = ? "
                        "       ) ";
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_int(stmt, 1, categoryID);
        
        if(SQLITE_DONE != sqlite3_step(stmt)){
            ret = NO;
        }
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        ret = NO;
    }
     
	sqlite3_finalize(stmt);
	
    if(recursive) {
     
        NSArray *children = [[CategoryDB instance] getChildCategoriesForCategory:categoryID
                                                                       recursive:YES];
        for(Category *child in children) {
            [self resetFlashCardsWithCategoryID:child.categoryID recursive:NO];
        }
        
        
    }
    
	return ret;
}

- (int) getCountOfFlashCardsWithCategoryID:(int) categoryID {
    
	int count = 0;
	
	sqlite3_stmt *stmt = nil;
    if (categoryID == 0) {
        const char *sql =   "select count(flashcard.id) as count "
                            "from   flashcard ";
        
        if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
                          
            if(sqlite3_step(stmt) == SQLITE_ROW) {
                count = sqlite3_column_int(stmt, 0);
            }
        } else {
            
            printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
            return 0;
        }
    }
    else {
        const char *sql =   "select count(flashcard.id) as count "
                            "from   flashcard "
                            "where  category_id = ? ";
        
        if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
            
            sqlite3_bind_int(stmt, 1, categoryID);

            if(sqlite3_step(stmt) == SQLITE_ROW) {
                count = sqlite3_column_int(stmt, 0);
            }
        } else {
            
            printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
            return 0;
        }
    }
	
	//Even though the open call failed, close the database connection to release all the memory.
	sqlite3_finalize(stmt);
	
	return count;
}

- (int) getCountOfFlashCardsWithCategoryID:(int)categoryID
                       flashcardStatusName:(NSString *)flashcardStatusName
                                 recursive:(BOOL)recursive {
    
    int count = 0;
	
	sqlite3_stmt *stmt = nil;
    if (categoryID == 0) {
        const char *sql =   "select count(flashcard.id) as count "
                            "from   flashcard "
                            "join   user.flashcard_state ON user.flashcard_state.flashcard_id = flashcard.id "
                            "join   flashcard_status ON user.flashcard_state.flashcard_status_id = flashcard_status.id "
                            "where  flashcard_status.name = ?";
        
        if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
            
            sqlite3_bind_text(stmt, 1, [flashcardStatusName UTF8String], -1, SQLITE_TRANSIENT);
            
            if(sqlite3_step(stmt) == SQLITE_ROW) {
                count = sqlite3_column_int(stmt, 0);
            }
        } else {
            
            printf( "could not prepare statemnt in getCountOfFlashCardsWithCategoryID:flashcardStatusName: %s\n", sqlite3_errmsg(self.database) );
            return 0;
        }
        
    }
    else {
        const char *sql =   "select count(flashcard.id) as count "
                            "from   flashcard "
                            "join   user.flashcard_state ON user.flashcard_state.flashcard_id = flashcard.id "
                            "join   flashcard_status ON user.flashcard_state.flashcard_status_id = flashcard_status.id "
                            "where  category_id = ? "
                            "and    flashcard_status.name = ? ";
        
        if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
            
            sqlite3_bind_int(stmt, 1, categoryID);
            sqlite3_bind_text(stmt, 2, [flashcardStatusName UTF8String], -1, SQLITE_TRANSIENT);
            
            if(sqlite3_step(stmt) == SQLITE_ROW) {
                count = sqlite3_column_int(stmt, 0);
            }
        } else {
            
            printf( "could not prepare statemnt in getCountOfFlashCardsWithCategoryID:flashcardStatusName:: %s\n", sqlite3_errmsg(self.database) );
            return 0;
        }
    }
	
	//Even though the open call failed, close the database connection to release all the memory.
	sqlite3_finalize(stmt);
    
    if(recursive) {
        count += [self getCountOfChildFlashCardsWithParentCategory:categoryID flashcardStatusName:flashcardStatusName recursive:recursive];
    }
        
	return count;
    
}

- (int) getCountOfChildFlashCardsWithParentCategory:(NSInteger)parentCategoryId
                                flashcardStatusName:(NSString *)flashcardStatusName
                                          recursive:(BOOL)recursive {
    
    NSMutableArray *categories = [[CategoryDB instance] getChildCategoriesForCategory:parentCategoryId
                                                                                 recursive:recursive];
    NSInteger count = 0;
    
    for(Category *category in categories) {
        
        count += [self getCountOfFlashCardsWithCategoryID:category.categoryID
                                      flashcardStatusName:flashcardStatusName
                                                recursive:recursive];
        
    }
    
    return count;
     
}

- (int) getCountOfFlashCardsWithCategoryID:(int) categoryID
                       flashcardStatusName:(NSString *)flashcardStatusName {
	int count = 0;
	
	sqlite3_stmt *stmt = nil;
		
    if (categoryID != 0) {
        const char *sql =   "select count(flashcard.id) as count "
                            "from   flashcard, "
                            "join   user.flashcard_state on user.flashcard_state.flashcard_id = flashcard.id "
                            "join   flashcard_status on flashcard_status.id = user.flashcard_state.flashcard_status_id "
                            "where  flashcard.category_id = ? "
                            "and    flashcard_status.name = ? ";
        
        if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
            
            sqlite3_bind_int(stmt, 1, categoryID);
            sqlite3_bind_text(stmt, 2, [flashcardStatusName UTF8String], -1, SQLITE_TRANSIENT);
            
            if(sqlite3_step(stmt) == SQLITE_ROW) {
                count = sqlite3_column_int(stmt, 0);
            }
        } else {
            
            printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
            return 0;
        }
    }
    else {
        const char *sql =   "select count(flashcard.id) as count "
                            "from   flashcard, "
                            "join   user.flashcard_state on user.flashcard_state.flashcard_id = flashcard.id "
                            "join   flashcard_status on flashcard_status.id = user.flashcard_state.flashcard_status_id "
                            "where  flashcard_status.name = ? ";
        
        if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
            
            sqlite3_bind_text(stmt, 1, [flashcardStatusName UTF8String], -1, SQLITE_TRANSIENT);

            if(sqlite3_step(stmt) == SQLITE_ROW) {
                count = sqlite3_column_int(stmt, 0);
            }
        } else {
            
            printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
            return 0;
        }
    }		
	
	
	//Even though the open call failed, close the database connection to release all the memory.
	sqlite3_finalize(stmt);
	
	return count;	
}

- (int) getCountOfAnsweredFlashCardsWithCategoryID:(int)categoryID {
    
	int count = 0;
	
	sqlite3_stmt *stmt = nil;
    if (categoryID == 0) {
        const char *sql =   "select count(flashcard.id) as count "
                            "from   flashcard "
                            "join   user.flashcard_state on user.flashcard_state.flashcard_id = flashcard.id "
                            "join   flashcard_status on flashcard_status.id = user.flashcard_state.flashcard_status_id "
                            "where    flashcard_status.name != 'unanswered' ";
        
        if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
                        
            if(sqlite3_step(stmt) == SQLITE_ROW) {
                count = sqlite3_column_int(stmt, 0);
            }
        } else {
            
            printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
            return 0;
        }
    }
    else {
        const char *sql =   "select count(flashcard.id) as count "
                            "from   flashcard, "
                            "join   user.flashcard_state on user.flashcard_state.flashcard_id = flashcard.id "
                            "join   flashcard_status on flashcard_status.id = user.flashcard_state.flashcard_status_id "
                            "where  flashcard.category_id = ? "
                            "and    flashcard_status.name != 'unanswered' ";
        
        if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
            
            sqlite3_bind_int(stmt, 1, categoryID);

            if(sqlite3_step(stmt) == SQLITE_ROW) {
                count = sqlite3_column_int(stmt, 0);
            }
        } else {
            
            printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
            return 0;
        }
    }
	
	
	//Even though the open call failed, close the database connection to release all the memory.
	sqlite3_finalize(stmt);
	
	return count;
}

- (int) getCountOfFlashCardsWithCategoryID:(int)categoryID
                              answerStatus:(NSString *)answerStatusName
                                 recursive:(BOOL)recursive {

    const char *sql =   "SELECT count(flashcard.id) as count "
                        "FROM   flashcard "
                        "JOIN   user.flashcard_state ON user.flashcard_state.flashcard_id = flashcard.id "
                        "JOIN   answer_status on answer_status.id = user.flashcard_state.answer_status_id "
                        "WHERE  flashcard.category_id = ? "
                        "AND    answer_status.name = ? ";
    
    sqlite3_stmt *stmt = nil;
    
    int count = 0;
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_int(stmt, 1, categoryID);
        sqlite3_bind_text(stmt, 2, [answerStatusName UTF8String], -1, SQLITE_TRANSIENT);
        
        if(sqlite3_step(stmt) == SQLITE_ROW) {
            
            count = sqlite3_column_int(stmt, 0);
            
        }
    } else {
        
        printf( "could not prepare statemnt in getCountOfFlashCardsWithCategoryID:answerStatusName:recursive %s\n", sqlite3_errmsg(self.database) );
        return 0;
        
    }
    
    sqlite3_finalize(stmt);
    
    if(recursive) {
     
        NSArray *children = [[CategoryDB instance] getChildCategoriesForCategory:categoryID
                                                                       recursive:YES];
                
        for(Category *child in children) {
            
            NSInteger childCount = [self getCountOfFlashCardsWithCategoryID:child.categoryID
                                                               answerStatus:answerStatusName
                                                                  recursive:NO];
                        
            count += childCount;
            
        }
    
    }
    
    return count;
}

- (int) getCountOfFlashCardsWithFlashcardStatusName:(NSString *)flashcardStatusName
                                       answerStatus:(NSString *)answerStatusName {
    
    const char *sql =   "SELECT count(flashcard.id) as count "
                        "FROM   flashcard "
                        "JOIN   user.flashcard_state on user.flashcard_state.flashcard_id = flashcard.id "
                        "JOIN   flashcard_status on flashcard_status.id = user.flashcard_state.flashcard_status_id "
                        "JOIN   answer_status ON answer_status.id = user.flashcard_state.answer_status_id "
                        "WHERE  answer_status.name = ? "
                        "AND    flashcard_status.name = ? ";
    
    sqlite3_stmt *stmt = nil;
    
    int count = 0;
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_text(stmt, 1, [answerStatusName UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 2, [flashcardStatusName UTF8String], -1, SQLITE_TRANSIENT);
        
        if(sqlite3_step(stmt) == SQLITE_ROW) {
            count = sqlite3_column_int(stmt, 0);
        }
        
    }

    sqlite3_finalize(stmt);
    
    return count;
    
}

- (int) getCountOfCorrectFlashCardsWithCategoryID:(int) categoryID {
    
	int count = 0;
	
	sqlite3_stmt *stmt = nil;
    if (categoryID == 0) {
        const char *sql =   "SELECT count(flashcard.id) "
                            "FROM   flashcard "
                            "JOIN   user.flashcard_state ON user.flashcard_state.flashcard_id = flashcard.id "
                            "JOIN   answer_status ON answer_status.id = user.flashcard_state.answer_status_id "
                            "WHERE  answer_status.name = 'correct' ";
        
        if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
            
            if(sqlite3_step(stmt) == SQLITE_ROW) {
                count = sqlite3_column_int(stmt, 0);
            }
        } else {
            
            printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
            return 0;
        }
    }
    else {
        const char *sql =   "SELECT count(flashcard.id) as count "
                            "FROM   flashcard "
                            "JOIN   user.flashcard_state ON user.flashcard_state.flashcard_id = flashcard.id "
                            "JOIN   answer_status ON answer_status.id = user.flashcard_state.answer_status_id "
                            "WHERE  flashcard.category_id = ? "
                            "AND    answer_status.name = 'correct' ";
        
        if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
            
            sqlite3_bind_int(stmt, 1, categoryID);

            if(sqlite3_step(stmt) == SQLITE_ROW) {
                count = sqlite3_column_int(stmt, 0);
            }
        } else {
            
            printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
            return 0;
        }
    }
		
	sqlite3_finalize(stmt);
	
	return count;
}


- (NSString *) getCategoryNameWithCategoryID:(int) categoryID{
	NSString *cateName = NULL;
	
	sqlite3_stmt *stmt = nil;
    const char *sql =   "select id, "
                        "       name "
                        "from   category "
                        "where  id = ?";
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_int(stmt, 1, categoryID);
        
        if(sqlite3_step(stmt) == SQLITE_ROW) {
            cateName = [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, 1)];
        }
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return 0;
    }
			
	//Even though the open call failed, close the database connection to release all the memory.
	sqlite3_finalize(stmt);
	
	return cateName;
}

- (double) getAverageTimeForEachQuestion{
	double avg = 0.0;
	
	sqlite3_stmt *stmt = nil;
    const char *sql =   "select avg(user.flashcard_state.time) as average "
                        "from   user.flashcard_state "
                        "join   flashcard_status on flashcard_status.id = user.flashcard_state.flashcard_status_id "
                        "and    flashcard_status.name != 'unanswered' ";
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        if(sqlite3_step(stmt) == SQLITE_ROW) {
            avg = sqlite3_column_double(stmt, 0);
        }
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return 0;
    }

	sqlite3_finalize(stmt);
	
	return avg;	
}

- (NSArray *) getTimesForEachQuestionWithCategoryID:(int) categoryID{
	
	sqlite3_stmt *stmt = nil;
    
    NSMutableArray *times = [NSMutableArray array];
    
    const char *sql =   "select user.flashcard_state.time "
                        "from   user.flashcard_state "
                        "join   flashcard on flashcard.id = user.flashcard_state.flashcard_id "
                        "join   flashcard_status on flashcard_status.id = user.flashcard_state.flashcard_status_id "
                        "and    flashcard_status.name != 'unanswered' "
                        "and    flashcard.category_id = ?";
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_int(stmt, 1, categoryID);
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            const double time = sqlite3_column_double(stmt, 0);
            [times addObject:[NSNumber numberWithDouble:time]];
        }
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return 0;
    }
		
	sqlite3_finalize(stmt);
	   
    NSArray *children = [[CategoryDB instance] getChildCategoriesForCategory:categoryID
                                                                   recursive:YES];
    for(Category *child in children) {
        NSArray *childTimes = [self getTimesForEachQuestionWithCategoryID:child.categoryID];
        [times addObjectsFromArray:childTimes];
    }
    
    
	return times;
}

- (NSInteger) getFlashcardStatusId:(NSString *)flashcardStatusName {
 
    sqlite3_stmt *stmt = nil;
    const char *sql =   "SELECT id "
                        "FROM   flashcard_status "
                        "WHERE  name = ? ";
    NSInteger flashcardStatusId = 0;
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {

        sqlite3_bind_text(stmt, 1, [flashcardStatusName UTF8String], -1, SQLITE_TRANSIENT);

        if(sqlite3_step(stmt) == SQLITE_ROW) {
            flashcardStatusId = sqlite3_column_int(stmt, 0);
        }
        
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return 0;
    }
    
    sqlite3_finalize(stmt);

    
    return flashcardStatusId;
}

- (NSInteger) getAnswerStatusId:(NSString *)answerStatusName {
 
    sqlite3_stmt *stmt = nil;
    const char *sql =   "SELECT id "
                        "FROM   answer_status "
                        "WHERE  name = ? ";

    NSInteger answerStatusId = 0;
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
     
        sqlite3_bind_text(stmt, 1, [answerStatusName UTF8String], -1, SQLITE_TRANSIENT);
        
        if(sqlite3_step(stmt) == SQLITE_ROW) {
            answerStatusId = sqlite3_column_int(stmt, 0);
        }
        
    } else {
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return 0;
    }
    
    sqlite3_finalize(stmt);
    
    return answerStatusId;
    
}


- (void) dealloc{
	
	[super dealloc];
}


- (void)checkImages {
    
    sqlite3_stmt *stmt = nil;
    const char *sql =   "SELECT id, "
                        "       name, "
                        "       number "
                        "FROM   image ";
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            //const NSInteger imageId = sqlite3_column_int(stmt, 0);
            const char *imageName = (const char *)sqlite3_column_text(stmt, 1);
            //const NSInteger imageNumber = sqlite3_column_int(stmt, 2);
            
            if(imageName) {
                
                NSString *path = [NSString stringWithUTF8String:imageName];
                UIImage *image = [UIImage imageNamed:path];
                if(!image) {
                    NSLog(@"Can't find image: %@", path);
                    
                }
                
            }
            
        }
        
    }
    
    sqlite3_finalize(stmt);
    
    [self checkForUnusedImages];
    
}

- (void)checkForUnusedImages {
 
    sqlite3_stmt *stmt = nil;
    const char *sql =   "SELECT image.name "
                        "FROM   image, "
                        "       flashcard "
                        "WHERE  flashcard.image_number = image.number ";
    
    NSMutableSet *images = [NSMutableSet set];
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            const char *imageName = (const char *)sqlite3_column_text(stmt, 0);
            
            if(imageName) {
             
                [images addObject:[NSString stringWithUTF8String:imageName]];
                
            }
            
        }
        
    }
    
    sqlite3_finalize(stmt);
    
    for(NSString *image in images) {
        NSLog(@"We need image: %@", image);
    }
    
}


@end

@implementation FlashCardsDB (Private)

- (NSMutableString *)getBaseFlashcardQuery {
    
    
    return [NSMutableString stringWithString:   @"select flashcard.id, "
                                                "       flashcard.question, "
                                                "       flashcard.choices, "
                                                "       flashcard.answers, "
                                                "       flashcard.category_id, "
                                                "       flashcard.image_number, "
                                                "       flashcard.rationale, "
                                                "       flashcard.rationale_preview, "
                                                "       user.flashcard_state.flashcard_status_id, "
                                                "       user.flashcard_state.time, "
                                                "       flashcard_status.name, "
                                                "       answer_status.id, "
                                                "       answer_status.name, "
                                                "       category.name, "
                                                "       category.parent_category_id, "
                                                "       user.category_state.enabled, "
                                                "       category.available, "
                                                "       category.enabled_by_default, "
                                                "       category_type.id, "
                                                "       category_type.name, "
                                                "       image.name "
                                                "from   flashcard "
                                                "join   user.flashcard_state on user.flashcard_state.flashcard_id = flashcard.id "
                                                "join   flashcard_status on flashcard_status.id = user.flashcard_state.flashcard_status_id "
                                                "join   answer_status on answer_status.id = user.flashcard_state.answer_status_id "
                                                "join   category on flashcard.category_id = category.id "
                                                "join   category_type on category.category_type_id = category_type.id "
                                                "join   user.category_state on user.category_state.category_id = category.id "
                                                "left join image on flashcard.image_number = image.number "
            ];
    
}


- (FlashCard *)getFlashcardFromStatement:(sqlite3_stmt *)stmt {
 
    NSInteger column = 0;
    
    const NSInteger cardID = sqlite3_column_int(stmt, column++);
    const char *question = (const char *)sqlite3_column_text(stmt, column++);
    const char *choices = (const char *)sqlite3_column_text(stmt, column++);
    const char *answers = (const char *)sqlite3_column_text(stmt, column++);
    const NSInteger categoryID = sqlite3_column_int(stmt, column++);
    const NSInteger imageID = sqlite3_column_int(stmt, column++);
    const char *rationale = (const char *)sqlite3_column_text(stmt, column++);
    const char *rationalePreview = (const char *)sqlite3_column_text(stmt, column++);
    const NSInteger flashcardStatusId = sqlite3_column_int(stmt, column++);
    const double time = sqlite3_column_double(stmt, column++);
    const char *flashcardStatusName = (const char *)sqlite3_column_text(stmt, column++);
    const NSInteger answerStatusId = sqlite3_column_int(stmt, column++);
    const char *answerStatusName = (const char *)sqlite3_column_text(stmt, column++);
    const char *categoryName = (const char *)sqlite3_column_text(stmt, column++);
    const NSInteger parentCategoryID = sqlite3_column_int(stmt, column++);
    const BOOL enabled = sqlite3_column_int(stmt, column++);
    const BOOL available = sqlite3_column_int(stmt, column++);
    const BOOL enabledByDefault = sqlite3_column_int(stmt, column++);
    const NSInteger categoryTypeId = sqlite3_column_int(stmt, column++);
    const char *categoryTypeName = (const char *)sqlite3_column_text(stmt, column++);
    const char *imageName = (const char *)sqlite3_column_text(stmt, column++);
    
    Category *category = [[Category alloc] initWithCategoryID:categoryID
                                             parentCategoryID:parentCategoryID
                                                 categoryName:categoryName
                                                      enabled:enabled
                                                    available:available
                                               categoryTypeId:categoryTypeId
                                             categoryTypeName:categoryTypeName
                                             enabledByDefault:enabledByDefault];
    
    
    Image *image = imageID > 0 ? [[Image alloc] initWithImageID:imageID
                                                      imageName:imageName] : nil;

    NSArray *mnemonics = [[MnemonicsDB instance] getMnemonicsForFlashcard:cardID];
    
    FlashCard *flashcard = [[FlashCard alloc] initWithCardID:cardID
                                                    question:question
                                               choicesString:choices
                                               answersString:answers
                                                    category:category
                                                       image:image
                                                   rationale:rationale
                                            rationalePreview:rationalePreview
                                                    mnemonics:mnemonics
                                           flashcardStatusId:flashcardStatusId
                                         flashcardStatusName:flashcardStatusName
                                                        time:time
                                              answerStatusId:answerStatusId
                                            answerStatusName:answerStatusName];

    
    [category release];
    [image release];
    
    return flashcard;
    
}




@end
