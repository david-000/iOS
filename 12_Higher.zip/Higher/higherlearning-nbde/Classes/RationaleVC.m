//
//  RationaleVC.m
//  iPhoneProject
//
//  Created by Componica on 9/26/12.
//
//

#import "RationaleVC.h"
#import "Util.h"
#import "FlashCard.h"
#import "iPhoneProjectAppDelegate.h"
#import "GANTracker.h"
#import "ScrollableImageView.h"

#define kPadding 10

@interface RationaleVC (Private)

- (void)showImageView;
- (void)dismissImageView;

- (void)showMnemonicView;
- (void)dismissMnemonicView;

@end

@implementation RationaleVC

@synthesize delegate;
@synthesize textView;
@synthesize mnemonicsButton;
@synthesize pictureButton;
@synthesize closeButton;
@synthesize titleLabel;


- (id)init {
 
    NSString *nib = NibName(@"RationaleVC");
    self = [super initWithNibName:nib bundle:nil];
    if(self) {
        
    }
    
    return self;
    
}

- (void)dealloc {
 
    [textView release];
    [mnemonicsButton release];
    [pictureButton release];
    [closeButton release];
    [titleLabel release];
    [flashcard release];
    [scrollableImageView release];
    [mnemonicView release];
    [super dealloc];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
    NSInteger x = self.view.frame.origin.x + kPadding;
    NSInteger y = titleLabel.frame.origin.y + titleLabel.frame.size.height + kPadding;
    NSInteger width = self.view.frame.size.width - kPadding * 2;
    NSInteger height = self.view.frame.size.height - y - kPadding * 2;
    scrollableImageView = [[ScrollableImageView alloc] initWithFrame:CGRectMake(x, y, width, height)];
    [self.view addSubview:scrollableImageView];
    scrollableImageView.hidden = YES;
    scrollableImageView.backgroundColor = self.view.backgroundColor;
    
    mnemonicView = [[UITextView alloc] initWithFrame:CGRectMake(x, y, width, height)];
    [self.view addSubview:mnemonicView];
    mnemonicView.hidden = YES;
    mnemonicView.backgroundColor = self.view.backgroundColor;
    mnemonicView.textColor = [UIColor whiteColor];
    mnemonicView.font = textView.font;
    mnemonicView.editable = NO;
    
    titleLabel.adjustsFontSizeToFitWidth = YES;
    
}

- (void) viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Rationale"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

- (IBAction)onCloseButton:(id)sender {
 
    if(scrollableImageView.hidden == NO) {
        [self dismissImageView];
    } else if(mnemonicView.hidden == NO) {
        [self dismissMnemonicView];
    } else {
        [delegate dismissRationaleVC];
    }
    
}


- (IBAction)onMnemonicsButton:(id)sender {
    
    [self showMnemonicView];
     
}

- (IBAction)onPictureButton:(id)sender {

    [self showImageView];
    
}


- (void)setFlashcard:(FlashCard *)flashcard_ {
 
    [flashcard release];
    flashcard = [flashcard_ retain];
    textView.text = flashcard.rationale;
    
    if(flashcard.mnemonics.count) {
        mnemonicsButton.enabled = YES;
    } else {
        mnemonicsButton.enabled = NO;
    }
    
    if(flashcard.image) {
        //Make sure we actually have the image!
        UIImage *image = [UIImage imageNamed:flashcard.image.imageName];
        if(image) {
            pictureButton.enabled = YES;
        } else {
            NSLog(@"Can't find image named %@!", flashcard.image.imageName);
        }
    } else {
        pictureButton.enabled = NO;
    }
    
    scrollableImageView.hidden = YES;
    mnemonicView.hidden = YES;
    
    titleLabel.text = @"Rationale";
    
}

- (BOOL)shouldAllowSwiping:(UITouch *)touch {
    
    if(scrollableImageView.hidden) {
        return YES;
    } else {
        CGPoint location = [touch locationInView:scrollableImageView];
        if(CGRectContainsPoint(scrollableImageView.bounds, location)) {
            return NO;
        } else {
            return YES;
        }
    }

}


@end

@implementation RationaleVC (Private)

- (void)showImageView {
    UIImage *image = [UIImage imageNamed:flashcard.image.imageName];
    if(image) {
        
        NSInteger x = self.view.frame.origin.x + kPadding;
        NSInteger y = titleLabel.frame.origin.y + titleLabel.frame.size.height + kPadding;
        NSInteger width = self.view.frame.size.width - 2 * kPadding;
        NSInteger height = self.view.frame.size.height - y - 2 * kPadding;
        scrollableImageView.frame = CGRectMake(x, y, width, height);
        
        [scrollableImageView setImage:image];

        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.view cache:YES];
        /*
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:)];
        */
        scrollableImageView.hidden = NO;
        [self.view bringSubviewToFront:closeButton];
        titleLabel.text = @"Picture";
        
        [UIView commitAnimations];
        

    } else {
        NSLog(@"Can't open image: %@", flashcard.image.imageName);
    }
    
}

- (void)dismissImageView {
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.view cache:YES];
    scrollableImageView.hidden = YES;
    titleLabel.text = @"Rationale";
    [UIView commitAnimations];
    
}

- (void)showMnemonicView {
    
    NSInteger x = self.view.frame.origin.x + kPadding;
    NSInteger y = titleLabel.frame.origin.y + titleLabel.frame.size.height + kPadding;
    NSInteger width = self.view.frame.size.width - 2 * kPadding;
    NSInteger height = self.view.frame.size.height - y - 2 * kPadding;
    mnemonicView.frame = CGRectMake(x, y, width, height);

    NSMutableString *mnemonicText = [NSMutableString string];
    for(Mnemonic *mnemonic in flashcard.mnemonics) {
        [mnemonicText appendFormat:@"%@\n", mnemonic.text];
    }
    
    mnemonicView.text = mnemonicText;
        
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.view cache:YES];
    [UIView setAnimationDelegate:self];
    //[UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:)];
    mnemonicView.hidden = NO;
    [self.view bringSubviewToFront:closeButton];
    titleLabel.text = @"Mnemonics";
    [UIView commitAnimations];

}

- (void)dismissMnemonicView {
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.view cache:YES];
    mnemonicView.hidden = YES;
    titleLabel.text = @"Rationale";
    [UIView commitAnimations];
    
}

@end

