//
//  Database.h
//  iPhoneProject
//
//  Created by Patrick Kellen on 8/30/12.
//
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>


@interface DatabaseConnection : NSObject {
 
    sqlite3 *database;
    
}

@property(nonatomic, assign) sqlite3 *database;

+ (DatabaseConnection *)instance;

+ (NSString*) getDatabasePath;

- (BOOL) connect;

- (BOOL) disconnect;

- (BOOL) userDatabaseDoesExist;

- (NSString *) userDatabasePath;

- (BOOL)beginTransaction;

- (BOOL)commitTransaction;

@end

@interface Database : NSObject {
    
}

@property(nonatomic, readonly) sqlite3 *database;

@end
