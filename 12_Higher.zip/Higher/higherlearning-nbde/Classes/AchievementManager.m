//
//  AchievementManager.m
//  iPhoneProject
//
//  Created by Componica on 10/3/12.
//
//

#import "AchievementManager.h"
#import "CategoryDB.h"
#import "Category.h"

@interface AchievementManager (Private)

- (NSMutableString *)getBaseAchievementQuery;
- (Achievement *)getAchievementFromStatement:(sqlite3_stmt *)stmt;
- (void)showAlertForAchievement:(Achievement *)achievement;
- (NSInteger)getNumberOfNonGreenCardsForCategory:(NSInteger)categoryId;

@end

@implementation AchievementManager

- (id) init {
 
    if(self = [super init]) {
        
    }
    
    return self;
    
}

+ (AchievementManager *)instance {
 
    static AchievementManager *instance = nil;
    if(!instance) {
        
        instance = [[AchievementManager alloc] init];
        
    }
    
    return instance;
    
}

- (NSArray *)getAllAchievementIds {
 
    const char *query = "SELECT id "
                        "FROM   achievement ";
    sqlite3_stmt *stmt = nil;
    NSMutableArray *achievementIds = [NSMutableArray array];
    
    if(sqlite3_prepare_v2(self.database, query, -1, &stmt, NULL) != SQLITE_OK) {
        NSLog(@"Unable to prepare statement in getAllAchievementIds: %s", sqlite3_errmsg(self.database));
        return nil;
    }
    
    while(sqlite3_step(stmt) == SQLITE_ROW) {
     
        const NSInteger achievementId = sqlite3_column_int(stmt, 0);
        [achievementIds addObject:[NSNumber numberWithInt:achievementId]];
        
    }
    
    sqlite3_finalize(stmt);
    
    return achievementIds;
    
}


- (NSArray *)checkCategoryCompletedAchievements:(Category *)category {
 
    NSMutableArray *achievements = [NSMutableArray array];
    
    //Get the number of non-green cards for this category
    NSInteger count = [self getNumberOfNonGreenCardsForCategory:category.categoryID];
    
    //Get the number of non-green cards for all of the children of this category
    NSArray *children = [[CategoryDB instance] getChildCategoriesForCategory:category.categoryID
                                                                   recursive:YES];
    for(Category *child in children)     {
        count += [self getNumberOfNonGreenCardsForCategory:child.categoryID];
    }
    
    
    if(count == 0) {
    
        //Get the parent category
        Category *parentCategory = category.parentCategoryId ? [[CategoryDB instance] getCategory:category.parentCategoryId] : nil;
        
        //Get the achievement
        Achievement *achievement = [self getCategoryCompletedAchievement:category.categoryID];
        if(!achievement.completed) {
            achievement.completed = YES;
            if(parentCategory) {
                achievement.message = [NSString stringWithFormat:@"Congrats! You've finished all of %@: %@!", parentCategory.categoryName, category.categoryName];
            } else {
                achievement.message = [NSString stringWithFormat:@"Wow, great work! You have finished %@!", category.categoryName];
            }
            
            //Update the achievement
            [self updateAchievement:achievement.achievementId completed:YES];

            [achievements addObject:achievement];
            
            //Show an alert
            [self showAlertForAchievement:achievement];
        }
        
        [achievement release];
        
        //If this category is completed, the parent category might be completed too, so check that
        if(parentCategory) {
            NSArray *parentAchievements = [self checkCategoryCompletedAchievements:parentCategory];
            if(parentAchievements) {
                [achievements addObjectsFromArray:parentAchievements];
                for(Achievement *parentAchievement in parentAchievements) {
                    [self showAlertForAchievement:parentAchievement];
                }
            }
        }
    
        
        
    }
    
    return achievements;
    
}

- (Achievement *)getCategoryCompletedAchievement:(NSInteger)categoryId {
    
    sqlite3_stmt *stmt = nil;
    NSMutableString *sql = [self getBaseAchievementQuery];
    
    [sql appendString:@"WHERE achievement.category_id = ? "];
    [sql appendString:@"AND achievement_type.name = 'category_completed' "];

    
    if(sqlite3_prepare_v2(self.database, [sql UTF8String], -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_int(stmt, 1, categoryId);
        
        if(sqlite3_step(stmt) == SQLITE_ROW) {
            
            Achievement *achievement = [self getAchievementFromStatement:stmt];
            sqlite3_finalize(stmt);
            return achievement;
        
        }
        
    } else {
        
        printf( "could not prepare statemnt in getCategoryCompletedAchievement: %s\n", sqlite3_errmsg(self.database) );
        NSLog(@"Query: %@", sql);
        return nil;
    
    }
    
    sqlite3_finalize(stmt);
    return nil;
}


- (BOOL)updateAchievement:(NSInteger)achievementId
                completed:(BOOL)completed{
    
    sqlite3_stmt *stmt = nil;	
    
    const char *sql =   "UPDATE user.achievement_state "
                        "SET    completed = ? "
                        "WHERE  achievement_id = ? ";
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
     
        sqlite3_bind_int(stmt, 1, completed ? 1 : 0);
        sqlite3_bind_int(stmt, 2, achievementId);
        
        if(sqlite3_step(stmt) != SQLITE_DONE) {
            sqlite3_finalize(stmt);
            return NO;
        }
        
    } else {
        
        printf( "could not prepare statement in updateAchievement: %s\n", sqlite3_errmsg(self.database) );
        return NO;
        
    }
    
    sqlite3_finalize(stmt);
    
    return YES;
}

- (BOOL)resetAchievementsForCategory:(NSInteger)categoryId {
    
    //Reset the achievements for this category AND it's children!!!
    Achievement *achievement = [self getCategoryCompletedAchievement:categoryId];
    [self updateAchievement:achievement.achievementId completed:NO];
    
    NSArray *children = [[CategoryDB instance] getChildCategoriesForCategory:categoryId
                                                                   recursive:YES];
    for(Category *child in children) {
        [self resetAchievementsForCategory:child.categoryID];
    }
    [achievement release];
    
    return YES;
}



- (Achievement *)checkAllFlashcardsCompletedAchievement {

    sqlite3_stmt *stmt = nil;
    NSInteger count = 0;
    
    const char *sql =   "SELECT count(flashcard.id) "
                        "FROM   flashcard "
                        "JOIN   category ON category.id = flashcard.category_id "
                        "JOIN   category_type on category_type.id = category.category_type_id "
                        "JOIN   user.flashcard_state ON user.flashcard_state.flashcard_id = flashcard.id "
                        "JOIN   flashcard_status ON flashcard_status.id = user.flashcard_state.flashcard_status_id "
                        "WHERE  (category_type.name = 'multiple-choice' OR category_type.name = 'terminology') "
                        "AND    flashcard_status.name != 'green' ";
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
    
        if(sqlite3_step(stmt) == SQLITE_ROW) {
            count = sqlite3_column_int(stmt, 0);
        }
        
    } else {
        printf( "could not prepare statemnt in checkAllFlashcardsCompletedAchievement: %s\n", sqlite3_errmsg(self.database) );
        return 0;
    }

    sqlite3_finalize(stmt);
        
    if(count == 0) {
        Achievement *achievement = [self getAllFlashcardsCompletedAchievement];
        [self showAlertForAchievement:achievement];
        return achievement;
    } else {
        return nil;
    }
    
     
}

- (Achievement *)getAllFlashcardsCompletedAchievement {
    
    sqlite3_stmt *stmt = nil;
    NSMutableString *sql = [self getBaseAchievementQuery];
    [sql appendString:@"WHERE achievement_type.name = 'all_flashcards_completed"];
    
    if(sqlite3_prepare_v2(self.database, [sql UTF8String], -1, &stmt, NULL) == SQLITE_OK) {

        if(sqlite3_step(stmt) == SQLITE_ROW) {
            
            Achievement *achievement = [self getAchievementFromStatement:stmt];
            achievement.message = @"You are finished!!! This is a testament to  your dedication and knowledge. Your changes of passing the board are extremely high. Good luck and don't forget to read our exam strategies section.";
            sqlite3_finalize(stmt);
            return achievement;
            
        }
        
    } else {
        
        printf( "could not prepare statemnt in getFlashcardsCompletedAchievement: %s\n", sqlite3_errmsg(self.database) );
        return nil;
        
    }
    
    return nil;
}

@end

@implementation AchievementManager (Private)

- (NSMutableString *)getBaseAchievementQuery {
    
    return [NSMutableString stringWithString:   @"SELECT    achievement.id, "
                                                "           user.achievement_state.completed, "
                                                "           achievement.category_id, "
                                                "           achievement_type.id, "
                                                "           achievement_type.name "
                                                "FROM       achievement "
                                                "JOIN       user.achievement_state ON user.achievement_state.achievement_id = achievement.id "
                                                "JOIN       achievement_type ON achievement_type.id = achievement.achievement_type_id "];
    
}

- (Achievement *)getAchievementFromStatement:(sqlite3_stmt *)stmt {
    
    NSInteger column = 0;
    
    const NSInteger achievementId = sqlite3_column_int(stmt, column++);
    const BOOL completed = sqlite3_column_int(stmt, column++) ? YES : NO;
    const NSInteger categoryId = sqlite3_column_int(stmt, column++);
    const NSInteger achievementTypeId = sqlite3_column_int(stmt, column++);
    const char *achievementTypeName = (const char *)sqlite3_column_text(stmt, column++);
    
    Achievement *achievement = [[Achievement alloc] initWithAchievementId:achievementId
                                                        achievementTypeId:achievementTypeId
                                                      achievementTypeName:achievementTypeName
                                                                completed:completed
                                                               categoryId:categoryId];
    return achievement;
    
}

- (void)showAlertForAchievement:(Achievement *)achievement {
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Achievement"
                                                    message:achievement.message
                                                   delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
    [alert release];
    
    
}

- (NSInteger)getNumberOfNonGreenCardsForCategory:(NSInteger)categoryId {
    
    //Get the number of non-green cards for this category
    sqlite3_stmt *stmt = nil;
    const char *sql =   "SELECT count(flashcard.id) "
                        "FROM   flashcard "
                        "JOIN   category ON category.id = flashcard.category_id "
                        "JOIN   user.flashcard_state ON user.flashcard_state.flashcard_id = flashcard.id "
                        "JOIN   flashcard_status ON flashcard_status.id = user.flashcard_state.flashcard_status_id "
                        "WHERE  category.id = ? "
                        "AND    flashcard_status.name != 'green'";
    
    NSInteger count = 0;
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_int(stmt, 1, categoryId);
        
        if(sqlite3_step(stmt) == SQLITE_ROW) {
            
            count = sqlite3_column_int(stmt, 0);
            
        }
        
    } else {
        
        printf( "could not prepare statement in getNumberOfNonGreenCardsForCategory: %s\n", sqlite3_errmsg(self.database) );
        return 0;
        
    }
    
    sqlite3_finalize(stmt);
    
    return count;
}



@end


