//
//  QuizFlashcardVC.m
//  iPhoneProject
//
//  Created by Componica on 9/13/12.
//
//

#import "QuizFlashcardVC.h"
#import "FlashCardsDB.h"
#import "Category.h"
#import <QuartzCore/QuartzCore.h>
#import "GANTracker.h"

@interface QuizFlashcardVC (Private)

- (void)loadFlashcards;

@end

@implementation QuizFlashcardVC

- (id)initWithCategory:(Category *)category_ {
    
    self = [super init];
    if (self) {
        // Custom initialization.
        category = [category_ retain];
        [self loadFlashcards];
        currentFlashcardIndex = 0;
    }
    return self;
    
}

- (void)dealloc {
    
    [flashcards release];
    [category release];
    [super dealloc];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    nextButton.hidden = YES;
    btnItemSubmit.hidden = NO;
    flashcardNumberLabel.hidden = NO;
    [self updateViews];
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:YES];
    NSString *pageName = [NSString stringWithFormat:@"Quiz Flashcards: %@", category.categoryName];
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:pageName
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

- (BOOL) getNextCard {
    
    if(currentFlashcardIndex > flashcards.count - 1) {
        
        return NO;
        
    } else {
        
        self.currentFlashCard = [flashcards objectAtIndex:currentFlashcardIndex];
        [self.currentFlashCard reset];
        currentFlashcardIndex++;
        
        return YES;
    }
    
}

- (void)leftSwiped:(UISwipeGestureRecognizer *)gesture
{
    
    //Don't do anything
    
}

- (void)rightSwiped:(UISwipeGestureRecognizer *)gesture {
    
    //Don't do anything
    
}



- (void) flipFooter {
    
    btnItemRed.hidden = YES;
    btnItemYellow.hidden = YES;
    btnItemGreen.hidden = YES;
    btnItemSubmit.hidden = YES;
    nextButton.hidden = NO;
    
}


- (void) gotoNextQuestion{
    
    self.view.userInteractionEnabled = NO;
    
    nextButton.hidden = YES;
    btnItemSubmit.hidden = NO;
    rationalePreviewView.hidden = YES;
    
    // set up the animation
    CATransition *animation = [CATransition animation];
    [animation setDuration:0.5];
    [animation setType:kCATransitionPush];
    [animation setSubtype:kCATransitionFromRight];
    [animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    [animation setDelegate:self];
    [[containView layer] addAnimation:animation forKey:@"PushNextFlashCardView"];
    [[footerView layer] addAnimation:animation forKey:@"PushNextFlashCardView"];
    
    if([self getNextCard]) {
        
        [self updateViews];
        
    } else {
        [answerVC.view removeFromSuperview];
        [questionVC.view removeFromSuperview];
        retryButton.hidden = NO;
        quitButton.hidden = NO;
        nextButton.hidden = YES;
        flashcardNumberLabel.hidden = YES;
        
        //Compute the score
        const NSInteger numberOfCorrectFlashcards = [[FlashCardsDB instance] getCountOfCorrectFlashCardsWithCategoryID:category.categoryID];
        const NSInteger totalNumberOfFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID];
        
        quizScoreLabel.text = [NSString stringWithFormat:@"%d/%d", numberOfCorrectFlashcards, totalNumberOfFlashcards];
        
        [containView addSubview:quizCompleteView];
        
    }
    
    
}

- (void)updateViews {
    
    [self updateTitle];
    
    flashcardNumberLabel.hidden = NO;
    
    flashcardNumberLabel.text = [NSString stringWithFormat:@"%d/%d", currentFlashcardIndex, flashcards.count];
    
    [questionVC.view removeFromSuperview];
    [answerVC.view removeFromSuperview];
    
    [answerVC initComponentsWithFlashCard:self.currentFlashCard];
    [answerVC.myTableView scrollRectToVisible:answerVC.myTableView.bounds
                                     animated:NO];
    
    [questionVC initComponentsWithFlashCard:self.currentFlashCard];
    [questionVC.myTableView scrollRectToVisible:questionVC.myTableView.bounds
                                       animated:NO];
    
    NSInteger containerX = 0;
    NSInteger containerY = topBarView.frame.size.height;
    NSInteger containerWidth = self.view.frame.size.width;
    NSInteger containerHeight = self.view.frame.size.height - topBarView.frame.size.height - footerView.frame.size.height;
    containView.frame = CGRectMake(containerX, containerY, containerWidth, containerHeight);
    
    NSInteger questionX = 0;
    NSInteger questionY = flashcardNumberLabel.frame.origin.y + flashcardNumberLabel.frame.size.height;
    NSInteger questionWidth = containView.bounds.size.width;
    NSInteger questionHeight = containView.bounds.size.height - flashcardNumberLabel.bounds.size.height;
    questionVC.view.frame = CGRectMake(questionX, questionY, questionWidth, questionHeight);
    questionVC.myTableView.frame = CGRectMake(0, 0, questionWidth, questionHeight);
    answerVC.view.frame = CGRectMake(questionX, questionY, questionWidth, questionHeight);
    answerVC.myTableView.frame = CGRectMake(0, 0, questionWidth, questionHeight);
    footerView.hidden = NO;
    [containView addSubview:questionVC.view];
    
}


- (IBAction)onRetryButton:(id)sender {
    
    //Reset
    [[FlashCardsDB instance] resetFlashCardsWithCategoryID:category.categoryID
                                                 recursive:YES];
    
    currentFlashcardIndex = 0;
    self.currentFlashCard = nil;
    retryButton.hidden = YES;
    quitButton.hidden = YES;
    [quizCompleteView removeFromSuperview];
    [self gotoNextQuestion];
    
}

- (IBAction)onQuitButton:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

@end

@implementation QuizFlashcardVC (Private)

- (void)loadFlashcards {
    
    flashcards = [[[FlashCardsDB instance] getFlashCardsWithCategoryID:category.categoryID
                                                             recursive:YES] retain];
    
}

@end
