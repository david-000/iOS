//
//  FlashCardVC.m

#import <QuartzCore/QuartzCore.h>
#import "FlashCardVC.h"
#import "FlashCardsDB.h"
#import "Flashcard.h"
#import "Global.h"
#import "Util.h"
#import "NSMutableArray+Shuffle.h"
#import "CategoryDB.h"
#import "Category.h"
#import "Image.h"
#import "iPhoneProjectAppDelegate.h"
#import "Mnemonic.h"
#import "RationaleVC.h"

@interface FlashCardVC (Private)

- (void)presentRationaleVC;

@end

@implementation FlashCardVC

@synthesize currentFlashCard;
@synthesize containView;
@synthesize btnItemRed;
@synthesize btnItemYellow;
@synthesize btnItemGreen;
@synthesize btnItemSubmit;
@synthesize footerView;
@synthesize nextButton;
@synthesize rationalePreviewView;
@synthesize rationalePreviewLabel;
@synthesize quizCompleteView;
@synthesize retryButton;
@synthesize quitButton;
@synthesize quizScoreLabel;
@synthesize flashcardNumberLabel;

- (void)dealloc {
    
    [[containView layer] removeAllAnimations];
    [[self.view layer] removeAllAnimations];
    [[footerView layer] removeAllAnimations];
    [[rationaleVC.view layer] removeAllAnimations];
    
    [currentFlashCard release];
    [questionVC release];
    [answerVC release];
    [rationaleVC release];
    [containView release];
    [btnItemRed release];
    [btnItemYellow release];
    [btnItemGreen release];
    [btnItemSubmit release];
    [footerView release];
    [nextButton release];
    [rationalePreviewView release];
    [rationalePreviewLabel release];
    [quizCompleteView release];
    [retryButton release];
    [quitButton release];
    [quizScoreLabel release];
    [flashcardNumberLabel release];
    [startTime release];
    [btnBack release];
    [leftSwipeGesture release];
    [rightSwipeGesture release];
	[flashcardHistory release];
    [super dealloc];
    
}

- (id) init {
    
    NSString *nib = NibName(@"FlashCardVC");
    
    self = [super initWithNibName:nib bundle:nil];
    
    if(self) {
        flashcardHistory = [[NSMutableArray alloc] init];
    }
    
    return self;
    
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
    [self setupViews];
    
    leftSwipeGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self
                                                                 action:@selector(leftSwiped:)];
    
    [leftSwipeGesture setDirection:UISwipeGestureRecognizerDirectionLeft];
    [self.view addGestureRecognizer:leftSwipeGesture];
    leftSwipeGesture.delegate = self;
    
    
    rightSwipeGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self
                                                                  action:@selector(rightSwiped:)];
    [rightSwipeGesture setDirection:UISwipeGestureRecognizerDirectionRight];
    rightSwipeGesture.delegate = self;
    [self.view addGestureRecognizer:rightSwipeGesture];
    
    //get the first flash card...
	[self getNextCard];
    
    [self updateViews];
    
    
}

- (void) viewDidAppear:(BOOL)animated{
    
	[super viewDidAppear:animated];
    
    if(self.currentFlashCard == NULL) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}

#pragma UISwipeGesture

- (void)leftSwiped:(UISwipeGestureRecognizer *)gesture
{
    
    [self gotoNextQuestion];
    
}

- (void)rightSwiped:(UISwipeGestureRecognizer *)gesture {
    
    
    NSInteger index = [flashcardHistory indexOfObject:self.currentFlashCard];
    if(index == NSNotFound) {
        if(flashcardHistory.count > 1) {
            
            [self gotoPreviousQuestion];
        }
    } else if(index > 0) {
        //If the index is greater than zero, than the flashcard is in the history and is not the first flashcard
        [self gotoPreviousQuestion];
    }
    
}


- (IBAction)doMoveNext:(id) sender
{
    [self gotoNextQuestion];
}


- (IBAction)onRationalePreviewButton:(id)sender {
    
    [self presentRationaleVC];
    
}

- (void) setupViews {
    
    btnItemRed.hidden = YES;
	btnItemYellow.hidden = YES;
	btnItemGreen.hidden = YES;
    nextButton.hidden = YES;
    rationalePreviewView.hidden = YES;
    retryButton.hidden = YES;
    quitButton.hidden = YES;
    
    NSString *quesNib = NibName(@"QuestionVC");
	questionVC = [[QuestionVC alloc] initWithNibName:quesNib bundle:nil];
	questionVC.delegate = self;
    questionVC.view.frame = CGRectMake(0, 0, containView.frame.size.width, containView.frame.size.height);
    questionVC.myTableView.frame = questionVC.view.frame;
    [questionVC.view setBackgroundColor:[UIColor clearColor]];
    
    NSString *nib = NibName(@"AnswerVC");
	answerVC = [[AnswerVC alloc] initWithNibName:nib bundle:nil];
    [answerVC.view setBackgroundColor:[UIColor clearColor]];
	answerVC.view.frame = CGRectMake(0, 0, containView.frame.size.width, containView.frame.size.height);
	answerVC.myTableView.frame = answerVC.view.frame;
    answerVC.footerHeight = rationalePreviewView.frame.size.height;
    
    rationaleVC = [[RationaleVC alloc] init];
    rationaleVC.delegate = self;
    rationaleVC.view.hidden = YES;
    rationalePreviewLabel.font = [UIFont systemFontOfSize:[Util fontSizeFlashCards] * 0.75];
}


- (void) gotoNextQuestion{
    
    self.view.userInteractionEnabled = NO;
    footerView.userInteractionEnabled = NO;
    
    NSInteger index = [flashcardHistory indexOfObject:self.currentFlashCard];
    
    //If the flashcard is the last object, get a new card, otherwise get the card from the history
    if(index == flashcardHistory.count - 1 || index == NSNotFound) {
        [self getNextCard];
    } else {
        self.currentFlashCard = [flashcardHistory objectAtIndex:index + 1];
    }
    
    
    [self updateViews];
    
    if(rationaleVC.view.hidden == NO) {
        [self dismissRationaleVC];
    }
    
    // set up the animation
    CATransition *animation = [CATransition animation];
    [animation setDuration:0.5];
    [animation setType:kCATransitionPush];
    [animation setSubtype:kCATransitionFromRight];
    [animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    [animation setDelegate:self];
    [[containView layer] addAnimation:animation forKey:@"PushNextFlashCardView"];
    [[footerView layer] addAnimation:animation forKey:@"PushNextFlashCardFooterView"];
    
}

- (void) gotoPreviousQuestion {
    
    self.view.userInteractionEnabled = NO;
    footerView.userInteractionEnabled = NO;
    
    if(rationaleVC.view.hidden == NO) {
        [self dismissRationaleVC];
    }
    
	[self getPreviousCard];
    
    [self updateViews];
    
    // set up the animation
    CATransition *animation = [CATransition animation];
    [animation setDuration:0.5];
    [animation setType:kCATransitionPush];
    [animation setSubtype:kCATransitionFromLeft];
    [animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    [animation setDelegate:self];
    [[containView layer] addAnimation:animation forKey:@"PushNextFlashCardView"];
    [[footerView layer] addAnimation:animation forKey:@"PushNextFlashCardView"];
    
}


- (IBAction) doSubmit:(id) sender{
    
    //Make sure we have at least one answer that was selected
    BOOL atLeastOneAnswerSelected = NO;
    NSString *answerStatus = @"correct";
    for(Answer *answer in currentFlashCard.answers) {
        if(answer.selected) {
            atLeastOneAnswerSelected = YES;
        }
        if(answer.selected != answer.correct) {
            answerStatus = @"incorrect";
        }
    }
	
    if(!atLeastOneAnswerSelected) {
        [Util displayAlertWithMessage:@"Please choose your answers!" tag:0];
		return;
    }
    
    rationalePreviewLabel.text = [NSString stringWithFormat:@"%@*", self.currentFlashCard.rationalePreview];
    
    
	//calculate answer time for this question...
	NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:startTime];
	[[FlashCardsDB instance] updateFlashCardWithNewTime:(double)interval cardID:self.currentFlashCard.cardID];
    [[FlashCardsDB instance] updateFlashCardWithAnswerStatus:answerStatus cardID:self.currentFlashCard.cardID];
    [startTime release];
    startTime = nil;
    
    [self.currentFlashCard setAnswerStatusName:answerStatus];
    self.currentFlashCard.answered = YES;
    
    [answerVC initComponentsWithFlashCard:self.currentFlashCard];
    [answerVC.myTableView scrollRectToVisible:questionVC.myTableView.bounds
                                     animated:NO];
    
    
    self.view.userInteractionEnabled = NO;
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.75];
	[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:containView cache:YES];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:)];
    
    
    [questionVC.view removeFromSuperview];
	[containView addSubview:answerVC.view];
    [containView bringSubviewToFront:rationalePreviewView];
    
    if(self.currentFlashCard.rationalePreview.length) {
        rationalePreviewView.hidden = NO;
    }
    
	[UIView commitAnimations];
    
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.75];
	[UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:footerView cache:YES];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:)];
    
    //This depends on the subclass
    [self flipFooter];
    
	[UIView commitAnimations];
    
    
}

- (IBAction)onRetryButton:(id)sender {
    //Subclasses should fill this in!
}

- (IBAction)onQuitButton:(id)sender {
    //Subclasses should fill this in!
}

- (IBAction)doGreen:(id)sender {
    //Subclasses should fill this in!
}

- (IBAction)doYellow:(id)sender {
    //Subclasses should fill this in!
}

- (IBAction)doRed:(id)sender {
    //Subclasses should fill this in!
}

- (void) flipFooter {
    //Subclasses should fill this in!
}


#pragma mark QuestionVCDelegate
- (void) QuestionVCOnStarting:(QuestionVC *)questionVC{
    [startTime release];
	startTime = [[NSDate date] retain];
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {
    [super viewDidUnload];
}

- (BOOL) getNextCard {
    
    //Subclasses should fill this in!
    return false;
    
}

- (void) getPreviousCard {
    
    NSInteger index = [flashcardHistory indexOfObject:self.currentFlashCard];
    if(index == NSNotFound) {
        index = flashcardHistory.count - 2;
    } else {
        index--;
    }
    
    if(index >= 0) {
        self.currentFlashCard = [flashcardHistory objectAtIndex:index];
    }
    
}


- (void) viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
    
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

#pragma mark CAAnimation delegate methods

- (void)animationDidStop:(CAAnimation *)theAnimation finished:(BOOL)flag {
    
    self.view.userInteractionEnabled = YES;
    footerView.userInteractionEnabled = YES;
    
}
#pragma mark RationaleVCDelegate methods
-(void)dismissRationaleVC {
    
    
    rationaleVC.view.userInteractionEnabled = NO;
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(dismissRationaleVCDidStop:finished:)];
    rationaleVC.view.frame = CGRectMake(0, self.view.bounds.size.height, rationaleVC.view.bounds.size.width, rationaleVC.view.bounds.size.height);
	[UIView commitAnimations];
    
    
}

- (void)dismissRationaleVCDidStop:(CAAnimation *)theAnimation finished:(BOOL)flag {
    
    rationaleVC.view.userInteractionEnabled = YES;
    
    
}

- (void)updateViews {
    
    [self updateTitle];
    
    [questionVC.view removeFromSuperview];
    [answerVC.view removeFromSuperview];
    
    [answerVC initComponentsWithFlashCard:self.currentFlashCard];
    [answerVC.myTableView scrollRectToVisible:answerVC.myTableView.bounds
                                     animated:NO];
    
    [questionVC initComponentsWithFlashCard:self.currentFlashCard];
    [questionVC.myTableView scrollRectToVisible:questionVC.myTableView.bounds
                                       animated:NO];
    
    NSInteger containerX = 0;
    NSInteger containerY = topBarView.frame.size.height;
    NSInteger containerWidth = self.view.frame.size.width;
    NSInteger containerHeight = self.view.frame.size.height - topBarView.frame.size.height - footerView.frame.size.height;
    containView.frame = CGRectMake(containerX, containerY, containerWidth, containerHeight);
    answerVC.view.frame = containView.bounds;
    answerVC.myTableView.frame = containView.bounds;
    questionVC.view.frame = containView.bounds;
    questionVC.myTableView.frame = containView.bounds;
    rationalePreviewView.frame = CGRectMake(0, answerVC.view.frame.size.height - rationalePreviewView.frame.size.height, rationalePreviewView.frame.size.width, rationalePreviewView.frame.size.height);
    rationalePreviewLabel.text = [NSString stringWithFormat:@"%@*", self.currentFlashCard.rationalePreview];
    
    if(self.currentFlashCard.answered) {
        
        if(self.currentFlashCard.rationalePreview.length) {
            rationalePreviewView.hidden = NO;
        }
        
        [containView addSubview:answerVC.view];
        [containView addSubview:rationalePreviewView];
        [containView bringSubviewToFront:rationalePreviewView];
        btnItemSubmit.hidden = YES;
        
    } else {
        rationalePreviewView.hidden = YES;
        [containView addSubview:questionVC.view];
    }
    
}

- (void)updateTitle {
    
    Category *category = [[CategoryDB instance] getCategory:self.currentFlashCard.category.categoryID];
    NSMutableArray *categories = [[CategoryDB instance] getCategoryHeirarchy:category.categoryID];
    Category *rootCategory = [categories lastObject];
    titleLabel.text = rootCategory.categoryName;
    
}


#pragma mark UIGestureRecognizerDelegate

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
       shouldReceiveTouch:(UITouch *)touch {
    
    if(rationaleVC.view.hidden) {
        return YES;
    } else {
        return [rationaleVC shouldAllowSwiping:touch];
    }
    
}

@end


@implementation FlashCardVC (Private)

- (void)presentRationaleVC {
    
    
    self.view.userInteractionEnabled = NO;
    //Add the rationale view and move it to the bottom of the screen
    [rationaleVC.view removeFromSuperview];
    [self.view insertSubview:rationaleVC.view belowSubview:footerView];
    
    rationaleVC.view.hidden = NO;
    if(footerView.hidden) {
        
        const NSInteger x = 0;
        const NSInteger y = self.view.bounds.size.height;
        const NSInteger width = self.view.bounds.size.width;
        const NSInteger height = self.view.bounds.size.height;
        rationaleVC.view.frame = CGRectMake(x, y, width, height);
        
    } else {
        const NSInteger x = 0;
        const NSInteger y = self.view.bounds.size.height;
        const NSInteger width = self.view.bounds.size.width;
        const NSInteger height = self.view.bounds.size.height - footerView.bounds.size.height;
        rationaleVC.view.frame = CGRectMake(x, y, width, height);
        
    }
    
    CGSize size = rationaleVC.view.bounds.size;
    
    //rationaleVC.view.frame = CGRectMake(0, self.view.bounds.size.height, size.width, size.height);
    [rationaleVC setFlashcard:self.currentFlashCard];
    
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(presentRationaleVCDidFinish)];
    
    rationaleVC.view.frame = CGRectMake(0, 0, size.width, size.height);
    
	[UIView commitAnimations];
    
}

- (void)presentRationaleVCDidFinish {
    
    self.view.userInteractionEnabled = YES;
    [rationaleVC.textView flashScrollIndicators];
    
}

- (void)dismissRationaleVCDidFinish {
    
    self.view.userInteractionEnabled = YES;
    [rationaleVC.view removeFromSuperview];
    rationaleVC.view.hidden = YES;
    
}


@end
