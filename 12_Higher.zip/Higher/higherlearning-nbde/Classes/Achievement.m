//
//  Achievement.m
//  iPhoneProject
//
//  Created by Componica on 10/3/12.
//
//

#import "Achievement.h"

@implementation Achievement

@synthesize achievementId;
@synthesize achievementTypeId;
@synthesize achievementTypeName;
@synthesize completed;
@synthesize categoryId;
@synthesize message;

- (id)initWithAchievementId:(NSInteger)achievementId_
          achievementTypeId:(NSInteger)achievementTypeId_
        achievementTypeName:(const char *)achievementTypeName_
                  completed:(BOOL)completed_
                 categoryId:(NSInteger)categoryId_ {
    
 
    self = [super init];
    if(self) {
        self.achievementId = achievementId_;
        self.achievementTypeId = achievementTypeId_;
        self.achievementTypeName = achievementTypeName_ ? [NSString stringWithUTF8String:achievementTypeName_] : nil;
        self.completed = completed_;
        self.categoryId = categoryId_;
    }
    
    
    return self;
}

- (void)dealloc {
    
    [achievementTypeName release];
    [super dealloc];
    
}

- (BOOL)didAchieve {
    
    //Subclasses should override this
    return NO;
    
}

@end
