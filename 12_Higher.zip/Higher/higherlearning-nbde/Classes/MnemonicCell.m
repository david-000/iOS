//
//  MnemonicCell.m
//  iPhoneProject
//
//  Created by Patrick Kellen on 8/31/12.
//
//

#import "MnemonicCell.h"
#import "Util.h"
#import "RoundedRectView.h"

#define kVerticalPadding 5
#define kBackgroundHorizontalPadding 10
#define kTextHorizontalPadding 15
#define kMinHeightPhone 60
#define kMinHeightPad 90
#define kCornerRadius 20
#define kOutlineStrokeWidth 6

@implementation MnemonicCell

@synthesize contentLabel;

- (id)initWithTitle:(NSString *)title
              width:(CGFloat)width
          fillcolor:(UIColor*)fillColor{
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    if(self) {
        
        const CGFloat availableWidth = width - 2 * kBackgroundHorizontalPadding - 2 * kTextHorizontalPadding;

        //Compute the height of the text
        UIFont *font = [UIFont boldSystemFontOfSize:[Util fontSizeMenus]];
        
        CGSize textSize = [title sizeWithFont:font
                            constrainedToSize:CGSizeMake(availableWidth, NSIntegerMax)
                                lineBreakMode:NSLineBreakByWordWrapping];
        
        CGFloat height = [Util isIPad] ? kMinHeightPad : kMinHeightPhone;
        height = fmax(height, textSize.height + kVerticalPadding * 4);

        [self setBackgroundColor:[UIColor clearColor]];
        [self setFrame:CGRectMake(0, 0, width, height)];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.accessoryType = UITableViewCellAccessoryNone;
        
        const NSInteger backgroundWidth = width - kBackgroundHorizontalPadding * 2;
        const NSInteger backgroundHeight = height - kVerticalPadding * 2;
        
        backgroundView = [[RoundedRectView alloc] initWithFrame:CGRectMake(0, 0, backgroundWidth, backgroundHeight)];
        backgroundView.cornerRadius = kCornerRadius;
        backgroundView.center = self.center;
        backgroundView.strokeWidth = kOutlineStrokeWidth;
        backgroundView.fillColor = fillColor;
        backgroundView.strokeColor = fillColor;
        
        NSInteger contentX = backgroundView.frame.origin.x + kTextHorizontalPadding;
        NSInteger contentY = backgroundView.frame.origin.y + kVerticalPadding;
        NSInteger contentWidth = backgroundView.frame.size.width - kTextHorizontalPadding * 2;
        NSInteger contentHeight = backgroundView.frame.size.height - kVerticalPadding * 2;
        
        contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(contentX, contentY, contentWidth, contentHeight)];
		[contentLabel setBackgroundColor:[UIColor clearColor]];
		[contentLabel setTextColor:[UIColor blackColor]];
		[contentLabel setFont:font];
		[contentLabel setTextAlignment:NSTextAlignmentLeft];
		contentLabel.lineBreakMode = NSLineBreakByWordWrapping;
		contentLabel.numberOfLines = 0;
        contentLabel.text = title;
        
        [self addSubview:backgroundView];
		[self addSubview:contentLabel];
        
    }
    
    return self;
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void) dealloc {
 
    [backgroundView release];
    [contentLabel release];
    
    [super dealloc];
    
}

@end
