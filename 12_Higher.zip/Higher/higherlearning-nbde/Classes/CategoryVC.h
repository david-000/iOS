//
//  CategoryVC.h
//  iPhoneProject
//
//  Created by MacBook on 6/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryCell.h"
#import "NavigationItemVC.h"

@interface CategoryVC : NavigationItemVC <UITableViewDataSource, UITableViewDelegate, CategoryCellDelegate>
{
    IBOutlet UITableView *myTableView;
    NSString *categoryTypeName;
    NSMutableArray *categories;
    NSMutableArray *cells;
    
}

@property(nonatomic, retain) UITableView *myTableView;

- (id)initWithCategoryType:(NSString *)_categoryTypeName;

- (IBAction) onGoButton:(id)sender;

@end
