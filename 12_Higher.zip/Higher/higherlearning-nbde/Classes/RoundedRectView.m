//
//  RoundedRectView.m
//  iPhoneProject
//
//  Created by Componica on 8/31/12.
//
//

#import "RoundedRectView.h"

@implementation RoundedRectView

#define kDefaultStrokeColor [UIColor whiteColor];
#define kDefaultRectColor [UIColor whiteColor]
#define kDefaultStrokeWidth 1.0
#define kDefaultCornerRadius 30.0

@synthesize strokeColor;
@synthesize fillColor;
@synthesize strokeWidth;
@synthesize cornerRadius;


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.opaque = NO;
        self.contentMode = UIViewContentModeRedraw;
        self.backgroundColor = [UIColor clearColor];
        self.strokeColor = kDefaultStrokeColor;
        self.fillColor = kDefaultRectColor;
        self.strokeWidth = kDefaultStrokeWidth;
        self.cornerRadius = kDefaultCornerRadius;
    }
    return self;
}

- (void)dealloc {
    
    [strokeColor release];
    [fillColor release];
    [super dealloc];
    
}

- (void)drawRect:(CGRect)rect {
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGRect localRect = CGRectInset(self.bounds, strokeWidth / 2, strokeWidth / 2);
    CGAffineTransform aff = CGAffineTransformMakeTranslation(strokeWidth / 2, strokeWidth / 2);
    
    // create the border path starting at the top left edge and moving around counter-clockwise
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathMoveToPoint(path, &aff, 0.0, cornerRadius);
    CGPathAddLineToPoint(path, &aff, 0.0, (localRect.size.height - cornerRadius));
    CGPathAddCurveToPoint(path, &aff, 0.0, localRect.size.height,
                          cornerRadius, localRect.size.height,
                          cornerRadius, localRect.size.height);
    
    CGPathAddLineToPoint(path, &aff, (localRect.size.width - cornerRadius), localRect.size.height);
    CGPathAddCurveToPoint(path, &aff, localRect.size.width, localRect.size.height,
                          localRect.size.width, (localRect.size.height - cornerRadius),
                          localRect.size.width, (localRect.size.height - cornerRadius));
    
    CGPathAddLineToPoint(path, &aff, localRect.size.width, cornerRadius);
    CGPathAddCurveToPoint(path, &aff, localRect.size.width, 0.0,
                          localRect.size.width - cornerRadius, 0.0,
                          localRect.size.width - cornerRadius, 0.0);
    
    CGPathAddLineToPoint(path, &aff, cornerRadius, 0.0);
    CGPathAddCurveToPoint(path, &aff, 0.0, 0.0,
                          0.0, cornerRadius,
                          0.0, cornerRadius);
    
    // draw path to screen
    CGContextSetLineWidth(ctx, strokeWidth);
    CGContextSetStrokeColorWithColor(ctx, strokeColor.CGColor);
    CGContextSetFillColorWithColor(ctx, fillColor.CGColor);
    
    CGContextAddPath(ctx, path);
    CGContextDrawPath(ctx, kCGPathFillStroke);
    
    CGContextAddPath(ctx, path);
    CGContextClip(ctx);
    
    /*
    // scale the image in "aspect fill" fashion
    CGFloat scale = fmax(self.bounds.size.width / image.size.width, self.bounds.size.height / image.size.height);
    CGContextScaleCTM(ctx, scale, scale);
    CGContextConcatCTM(ctx, aff);
    */
     
    CGPathRelease(path);
}



@end
