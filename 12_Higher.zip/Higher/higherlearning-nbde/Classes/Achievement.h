//
//  Achievement.h
//  iPhoneProject
//
//  Created by Componica on 10/3/12.
//
//

#import <Foundation/Foundation.h>

@interface Achievement : NSObject {
 
    NSInteger achievementId;
    NSInteger achievementTypeId;
    NSString *achievementTypeName;
    BOOL completed;
    NSInteger categoryId;
    NSString *message;
    
}

@property(nonatomic, assign) NSInteger achievementId;
@property(nonatomic, assign) NSInteger achievementTypeId;
@property(nonatomic, retain) NSString *achievementTypeName;
@property(nonatomic, assign) BOOL completed;
@property(nonatomic, assign) NSInteger categoryId;
@property(nonatomic, retain) NSString *message;

- (id)initWithAchievementId:(NSInteger)achievementId
          achievementTypeId:(NSInteger)achievementTypeId
        achievementTypeName:(const char *)achievementTypeName
                  completed:(BOOL)completed
                 categoryId:(NSInteger)categoryId;

- (BOOL)didAchieve;

@end
