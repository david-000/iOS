//
//  NavigationItemVC.m
//  iPhoneProject
//
//  Created by Patrick Kellen on 10/4/12.
//
//

#import "NavigationItemVC.h"
#import "Util.h"
#import "GANTracker.h"

#define kTitleLabelMargin 10
#define kRightNavigationBarMargin 10

@interface NavigationItemVC (Private)

- (void)onUpgradeButton:(id)sender;

@end

@implementation NavigationItemVC

@synthesize backButton;
@synthesize titleLabel;
@synthesize topBarView;
@synthesize backgroundView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        upgradeAlert = [[UIAlertView alloc] initWithTitle:@"Upgrade"
                                                  message:@"This category is not available in the free version, would you like to upgrade to the full version?"
                                                 delegate:self
                                        cancelButtonTitle:@"Close"
                                        otherButtonTitles:@"Full Version", nil];

    }
    return self;
}

- (void)dealloc {

    [backButton release];
    [titleLabel release];
    [topBarView release];
    [backgroundView release];
    [upgradeButton release];
    [upgradeAlert release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
 
    self.backButton.userInteractionEnabled = NO;
    
    titleLabel.adjustsFontSizeToFitWidth = YES;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    if([Util isFreeVersion]) {
#warning TODO: Temporary change here!
        UIImage *upgradeImage = [UIImage imageNamed:ResName(@"upgrade")];

        upgradeButton = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
        [upgradeButton setImage:upgradeImage forState:UIControlStateNormal];
        [upgradeButton setFrame:CGRectMake(0, 0, upgradeImage.size.width, upgradeImage.size.height)];
        [upgradeButton addTarget:self
                          action:@selector(onUpgradeButton:)
                forControlEvents:UIControlEventTouchUpInside];
        [self.view insertSubview:upgradeButton aboveSubview:topBarView];
        NSInteger x = topBarView.bounds.size.width - upgradeButton.bounds.size.width - kRightNavigationBarMargin;
        NSInteger y = (topBarView.bounds.size.height - upgradeButton.bounds.size.height) / 2.0f;
        NSInteger width = upgradeButton.bounds.size.width;
        NSInteger height = upgradeButton.bounds.size.height;
        upgradeButton.frame = CGRectMake(x, y, width, height);
        
        NSInteger titleLabelX = backButton.frame.origin.x + backButton.frame.size.width + kTitleLabelMargin;
        NSInteger titleLabelY = topBarView.frame.origin.y;
        NSInteger titleLabelWidth = upgradeButton.frame.origin.x - kTitleLabelMargin - titleLabelX;
        NSInteger titleLabelHeight = topBarView.frame.size.height;
        titleLabel.frame = CGRectMake(titleLabelX, titleLabelY, titleLabelWidth, titleLabelHeight);

        
    } else {
     
        //Figure out the size of the title
        CGSize titleSize = [titleLabel.text sizeWithFont:titleLabel.font
                                                forWidth:topBarView.frame.size.width
                                           lineBreakMode:NSLineBreakByWordWrapping];
        
        if(titleSize.width > topBarView.frame.size.width - 2 * kTitleLabelMargin - 2 * backButton.frame.size.width) {
            NSInteger titleLabelX = backButton.frame.origin.x + backButton.frame.size.width + kTitleLabelMargin;
            NSInteger titleLabelY = topBarView.frame.origin.y;
            NSInteger titleLabelWidth = topBarView.frame.size.width - kTitleLabelMargin - titleLabelX;
            NSInteger titleLabelHeight = topBarView.frame.size.height;
            titleLabel.frame = CGRectMake(titleLabelX, titleLabelY, titleLabelWidth, titleLabelHeight);
        } else {
            NSInteger titleLabelX = backButton.frame.origin.x + backButton.frame.size.width + kTitleLabelMargin;
            NSInteger titleLabelY = topBarView.frame.origin.y;
            NSInteger titleLabelWidth = topBarView.frame.size.width - kTitleLabelMargin - backButton.frame.size.width - titleLabelX;
            NSInteger titleLabelHeight = topBarView.frame.size.height;
            titleLabel.frame = CGRectMake(titleLabelX, titleLabelY, titleLabelWidth, titleLabelHeight);
        }
        
    }
    
}


- (void)viewDidAppear:(BOOL)animated {
 
    [super viewDidAppear:animated];
    self.backButton.userInteractionEnabled = YES;
    
}

- (void)viewWillDisappear:(BOOL)animated {
 
    self.backButton.userInteractionEnabled = NO;
    [super viewWillDisappear:animated];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onBackButton:(id)sender {
    
    self.backButton.userInteractionEnabled = NO;
    [self.navigationController popViewControllerAnimated:YES];
    
}

#pragma mark UIAlertViewDelegate methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if(alertView == upgradeAlert) {
        
        if(buttonIndex == 0) {
            //Don't do anything
        } else {
            [[UIApplication sharedApplication] openURL:[Util fullVersionURL]];
        }
        
    }
    
}


- (NSUInteger)supportedInterfaceOrientations
{
    return (UIInterfaceOrientationMaskPortrait);
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

- (BOOL)shouldAutorotate {
    return NO;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end

@implementation NavigationItemVC (Private)

- (void)onUpgradeButton:(id)sender {

    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Upgrade"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    [[UIApplication sharedApplication] openURL:[Util fullVersionURL]];
    
}

@end

