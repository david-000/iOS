//
//  OtherVC.m

#import "OtherVC.h"
#import "SAVPopupWindow.h"
#import "Util.h"
#import "MnemonicsVC.h"
#import "ExamStrategiesVC.h"
#import "StudyStrategiesVC.h"
#import "ScienceVC.h"
#import "iPhoneProjectAppDelegate.h"

static NSString * kAppId = @"374888099244448";

@implementation OtherVC

@synthesize wantShare;

- (void) dealloc{
    SAFE_RELEASE(myTableView);
    SAFE_RELEASE(btnBack);
	
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self initViewComponents];
}

- (IBAction) doGoBack:(id)sender {
	[self.navigationController popViewControllerAnimated:YES];
}

- (void) initViewComponents{
    myTableView.backgroundColor = [UIColor clearColor];
}

#pragma mark -
#pragma mark UITableViewDelegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    int height = 8 * [Util heightForMenuCell];
    
    int y = ([Util UIHeight])/2 - (height/2) + [Util heightForTopBar];
    
    int x = ([Util UIWidth])/2 - ([Util WidthForMenuCell]/2);
    
    [myTableView setFrame:CGRectMake(x, y, [Util WidthForMenuCell], height)];
    
	return 8;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return 1;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	/*
	static NSString* cellIdentifier=@"cellIdentifier";
	
	UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
	
	if(!cell){
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier] autorelease];
	}
	
    UIImageView *imageView;
    UIImage     *img;
    
    img = [UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/%@/blank_btn.png",[[NSBundle mainBundle] resourcePath],[Util imagesPath]]];
    
    imageView = [[UIImageView alloc] initWithImage:img];
    
    [imageView setFrame:CGRectMake(0, 0, img.size.width, img.size.height)];
	
    [cell addSubview:imageView];
    
    UILabel *content = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, img.size.width - 5, img.size.height)];
    [content setBackgroundColor:[UIColor clearColor]];
    [content setTextColor:[UIColor darkGrayColor]];
    [content setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [content setTextAlignment:UITextAlignmentCenter];
    content.lineBreakMode = UILineBreakModeWordWrap;
    content.numberOfLines = 0;
    
    [imageView addSubview:content];
    
    switch (indexPath.row) {
		case 0:
            [content setText:[@"EXAM STRATEGIES" uppercaseString]];
			break;
		case 1:
            [content setText:[@"study STRATEGIES" uppercaseString]];
			break;
		case 2:
            [content setText:[@"MNEMONICS" uppercaseString]];
			break;			
		case 3:
            [content setText:[@"SCIENCE BEHIND OUR APP" uppercaseString]];
			break;
		case 4:
            [content setText:[@"CONTACT US" uppercaseString]];
			break;
        case 5:
            [content setText:[@"Login with Facebook" uppercaseString]];
            if ([self checkFBValidity]) {
                [content setText:[@"Logout Facebook" uppercaseString]];
            }
			break;
		case 6:
            [content setText:[@"SHARE" uppercaseString]];
			break;
		case 7:
            [content setText:[@"RATE THIS APP" uppercaseString]];
			break;
		default:
			break;
	}
    
    SAFE_RELEASE(imageView);
    SAFE_RELEASE(content);
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
	return cell;	
     */
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{/*
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	
	switch (indexPath.row) {
		case 0: //Exam Strategies
		{
            ExamStrategiesVC* examStrategies;
            if ([Util isIPad])
                examStrategies = [[ExamStrategiesVC alloc] initWithNibName:@"ExamStrategiesVC_IPad" bundle:nil];
            else
                examStrategies = [[ExamStrategiesVC alloc] initWithNibName:@"ExamStrategiesVC" bundle:nil];
			[self.navigationController pushViewController:examStrategies animated:YES];
			[examStrategies release];
            
			break;
		}
		case 1: // Tutorial
		{
            StudyStrategiesVC* studyStrategies;
            if ([Util isIPad])
                studyStrategies = [[StudyStrategiesVC alloc] initWithNibName:@"StudyStrategiesVC_IPad" bundle:nil];
            else
                studyStrategies = [[StudyStrategiesVC alloc] initWithNibName:@"StudyStrategiesVC" bundle:nil];
			[self.navigationController pushViewController:studyStrategies animated:YES];
			[studyStrategies release];
			
			
			break;
		}
		case 2: //Mnemonics
		{
			MnemonicsVC* mnemonics;
            if ([Util isIPad])
                mnemonics = [[MnemonicsVC alloc] initWithNibName:@"MnemonicsVC_IPad" bundle:nil];
            else
                mnemonics = [[MnemonicsVC alloc] initWithNibName:@"MnemonicsVC" bundle:nil];
			[self.navigationController pushViewController:mnemonics animated:YES];
			[mnemonics release];
			
			break;
		}
		case 3:
		{
			AboutUsVC* aboutUs;
            if ([Util isIPad])
                aboutUs = [[AboutUsVC alloc] initWithNibName:@"AboutUsVC_IPad" bundle:nil];
            else
                aboutUs = [[AboutUsVC alloc] initWithNibName:@"AboutUsVC" bundle:nil];
			[self.navigationController pushViewController:aboutUs animated:YES];
			[aboutUs release];
			
			break;
		}
		case 4:
		{
            [self sendMailUs];
		
			break;
		}	
		case 5:
		{
            [self setWantShare:NO];
            if ([self checkFBValidity]) {
                [self logoutFacebook];
            }else {
                [self goFBShare];
            }
			
			break;
		}
        case 6:
		{
            [self setWantShare:YES];
			[self goFBShare];
            
            //FB SHARE
			break;
		}	
		case 7:
		{
			NSString* url = @"http://itunes.apple.com/app/id380886386?mt=8";
			[[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
			break;
		}
		default:
			break;
	}	
  */
}

- (void) sendMailUs{
    /*
	MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
	picker.navigationBar.barStyle = UIBarStyleBlackOpaque;
    picker.mailComposeDelegate = self;
    
    //set subject
    [picker setSubject:@"NBDE - Feedback"];
	
	//set Recipients
	[picker setToRecipients:[NSArray arrayWithObject:CUSTOMER_EMAIL]];
	
	//set body
    NSString *emailBody = @"What do you think of this application?";
    [picker setMessageBody:emailBody isHTML:YES];
	
    if (picker != nil) {
        [self presentModalViewController:picker animated:YES];
        [picker release];
    }
    */
}

#pragma -
#pragma MFMailComposeViewControllerDelegate
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    // Notifies users about errors associated with the interface
    switch (result)
    {
        case MFMailComposeResultCancelled:
			//[Util displayAlertWithMessage:@"Email is canceled." tag:0];
            break;
        case MFMailComposeResultSaved:
			//[Util displayAlertWithMessage:@"Email is saved." tag:0];
            break;
        case MFMailComposeResultSent:
			//[Util displayAlertWithMessage:@"Send email successfully." tag:0];
            break;
        case MFMailComposeResultFailed:
			//[Util displayAlertWithMessage:@"Send email fail." tag:0];
            break;
        default:
			//[Util displayAlertWithMessage:@"Email is not sent." tag:0];
            break;
    }
    
    [self dismissModalViewControllerAnimated:YES];
}

#pragma FBShare

- (BOOL)checkFBValidity {
    // Check and retrieve authorization information
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"] && [defaults objectForKey:@"FBExpirationDateKey"]) {
        return YES;
    }
    return NO;
}

-(void)logoutFacebook {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:@"FBAccessTokenKey"];
    [defaults removeObjectForKey:@"FBExpirationDateKey"];
    [defaults synchronize];
    
    iPhoneProjectAppDelegate *idelegate = (iPhoneProjectAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    SAFE_RELEASE(idelegate.facebook);
    
    [myTableView reloadData];
    
    [self setWantShare:NO];
}

- (void)shareONFB
{
    
    iPhoneProjectAppDelegate *idelegate = (iPhoneProjectAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    SBJSON *jsonWriter = [[SBJSON new] autorelease];
    
    // The action links to be shown with the post in the feed
    NSArray* actionLinks = [NSArray arrayWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:
                                                      @"NBDE Mastery",@"name",
                                                      @"http://itunes.apple.com/app/id380886386?mt=8",@"link", nil], nil];
    NSString *actionLinksStr = [jsonWriter stringWithObject:actionLinks];
    // Dialog parameters
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   @"NBDE Mastery - iOS Application", @"name",
                                   @"NBDE Mastery for iOS.", @"caption",
                                   @"Traditional textbook learning is highly inefficient because it treats information as all roughly equal.", @"description",
                                   @"http://itunes.apple.com/app/id380886386?mt=8", @"link",
                                   //@"http://www.facebookmobileweb.com/hackbook/img/facebook_icon_large.png", @"picture",
                                   actionLinksStr, @"actions",
                                   nil];
    
    
    [[idelegate facebook] dialog:@"feed"
                      andParams:params
                    andDelegate:self];
}

- (void)goFBShare
{
    iPhoneProjectAppDelegate *idelegate = (iPhoneProjectAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    SAFE_RELEASE(idelegate.facebook);
    if (idelegate.facebook == NULL) {
        // Initialize Facebook
        idelegate.facebook = [[Facebook alloc] initWithAppId:kAppId andDelegate:self];
    }
    else {
        idelegate.facebook.sessionDelegate = self;
    }
    
    
    
    // Check and retrieve authorization information
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"] && [defaults objectForKey:@"FBExpirationDateKey"]) {
        [idelegate facebook].accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
        [idelegate facebook].expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
    }
    
    NSArray *permissions = [[NSArray alloc] initWithObjects:
                            @"offline_access", 
                            @"photo_upload", 
                            @"publish_stream", 
                            @"friends_about_me", 
                            @"friends_likes",
                            @"email", nil];
    
    if (![[idelegate facebook] isSessionValid]) {
        [[idelegate facebook] authorize:permissions];
    }
    else {
        //ALREADY LOGIN
        if ([self wantShare]) {
            [self shareONFB];
        }
    }

    SAFE_RELEASE(permissions);
    
}
                 
                 

/**
 * Called when the user has logged in successfully.
 */
- (void)fbDidLogin {
    
    iPhoneProjectAppDelegate *idelegate = (iPhoneProjectAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NSLog(@"\n<><><>fbDidLogin : fbAccessToken: %@",[[idelegate facebook] accessToken]);
    
    [self storeAuthData:[[idelegate facebook] accessToken] expiresAt:[[idelegate facebook] expirationDate]];
    if ([self wantShare]) {
        [self shareONFB];
    }
    
    [myTableView reloadData];
}

-(void)fbDidExtendToken:(NSString *)accessToken expiresAt:(NSDate *)expiresAt {
    
}

/**
 * Called when the user canceled the authorization dialog.
 */
-(void)fbDidNotLogin:(BOOL)cancelled {
    //[pendingApiCallsController userDidNotGrantPermission];
    
    if(cancelled){
    }
}

/**
 * Called when the request logout has succeeded.
 */
- (void)fbDidLogout {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:@"FBAccessTokenKey"];
    [defaults removeObjectForKey:@"FBExpirationDateKey"];
    [defaults synchronize];
}

/**
 * Called when the session has expired.
 */
- (void)fbSessionInvalidated {
    UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:@"Auth Exception"
                              message:@"Your session has expired."
                              delegate:nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil,
                              nil];
    [alertView show];
    SAFE_RELEASE(alertView);
    
    [self fbDidLogout];
}

- (void)storeAuthData:(NSString *)accessToken expiresAt:(NSDate *)expiresAt {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:accessToken forKey:@"FBAccessTokenKey"];
    [defaults setObject:expiresAt forKey:@"FBExpirationDateKey"];
    [defaults synchronize];
}

/////////// ---/////////////////////
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void) viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
	
	UIInterfaceOrientation statusBarOrientation = [[UIApplication sharedApplication] statusBarOrientation];
    if(UIInterfaceOrientationIsPortrait(statusBarOrientation)){
		[self updatePortraitUI];
    }
    else {
		[self updateLandscapeUI];
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    
    return (interfaceOrientation == UIInterfaceOrientationPortrait);

}

- (void) updatePortraitUI{
	if ([Util isIPad]) {
		//iPad
	}
	else {
		//iPhone
		btnBack.frame = CGRectMake(0.0, 0.0, 50.0, 38.0 );
	}
}

- (void) updateLandscapeUI{
	if ([Util isIPad]) {
		//iPad
	}
	else {
		//iPhone
		btnBack.frame = CGRectMake(0.0, 0.0, 38.0, 28.0 );
	}	
}

@end
