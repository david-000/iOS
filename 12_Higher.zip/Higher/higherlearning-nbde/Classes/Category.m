//
//  Category.m
//  iPhoneProject
//
//  Created by Componica on 9/10/12.
//
//

#import "Category.h"

@interface Category (Private)


@end


@implementation Category

@synthesize categoryID;
@synthesize parentCategoryId;
@synthesize categoryName;
@synthesize numberOfUnansweredFlashcards;
@synthesize numberOfIncorrectFlashcards;
@synthesize numberOfCorrectFlashcards;
@synthesize numberOfRedFlashcards;
@synthesize numberOfYellowFlashcards;
@synthesize numberOfGreenFlashcards;
@synthesize subcategories;
@synthesize enabled;
@synthesize available;
@synthesize categoryTypeId;
@synthesize categoryTypeName;
@synthesize enabledByDefault;

- (id) initWithCategoryID:(NSInteger)_categoryID
         parentCategoryID:(NSInteger)_parentCategoryID
             categoryName:(const char *)_categoryName
                  enabled:(BOOL)_enabled
                available:(BOOL)_available
           categoryTypeId:(NSInteger)_categoryTypeId
         categoryTypeName:(const char *)_categoryTypeName
         enabledByDefault:(BOOL)_enabledByDefault { 
     
    self = [super init];
    if(self) {
        
        self.categoryID = _categoryID;
        self.parentCategoryId = _parentCategoryID;
        self.categoryName = _categoryName ? [NSString stringWithUTF8String:_categoryName] : nil;
        self.enabled = _enabled;
        self.available = _available;
        self.categoryTypeId = _categoryTypeId;
        self.categoryTypeName = _categoryTypeName ? [NSString stringWithUTF8String:_categoryTypeName] : nil;
        self.enabledByDefault = _enabledByDefault;
        
    }
    
    return self;
    
}

- (void) dealloc{
    
    [categoryName release];
    [categoryTypeName release];
    [subcategories release];
	[super dealloc];
    
}

- (id)copyWithZone:(NSZone *)zone {
 
    Category *category = [[Category alloc] init];
    
    category.categoryID = categoryID;
    category.parentCategoryId = parentCategoryId;
    category.categoryName = [categoryName copy];
    [category.categoryName release];
    category.enabled = enabled;
    category.available = available;
    category.categoryTypeId = categoryTypeId;
    category.categoryTypeName = [categoryTypeName copy];
    [category.categoryTypeName release];
    
    return category;
    
}

@end