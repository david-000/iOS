//
//  NavigationItemVC.h
//  iPhoneProject
//
//  Created by Patrick Kellen on 10/4/12.
//
//

#import <UIKit/UIKit.h>

@class BackgroundView;

@interface NavigationItemVC : UIViewController {
 
    IBOutlet UIButton *backButton;
    IBOutlet UILabel *titleLabel;
    IBOutlet UIImageView *topBarView;
    IBOutlet BackgroundView *backgroundView;
    UIButton *upgradeButton;
    UIAlertView *upgradeAlert;

}

@property(nonatomic, retain) UIButton *backButton;
@property(nonatomic, retain) UILabel *titleLabel;
@property(nonatomic, retain) UIImageView *topBarView;
@property(nonatomic, retain) BackgroundView *backgroundView;

- (IBAction)onBackButton:(id)sender;

@end
