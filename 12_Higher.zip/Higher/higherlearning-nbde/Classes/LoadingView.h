//
//  LoadingView.m


#import <Foundation/Foundation.h>


@interface LoadingView : UIAlertView {
    UIProgressView *progressView;
    UILabel *progressLabel;
    NSNumberFormatter *progressFormatter;
    BOOL isProgress;
}
+ (LoadingView *)defaultLoadingView;
- (id)initWithActivityIndicator:(NSString *)title
						message:(NSString *)message
					   delegate:(id)delegate
			  cancelButtonTitle:(NSString *)cancelButtonTitle 
			  otherButtonTitles:(NSString *)otherButtonTitles;	
- (id)initWithActivityIndicatorTitle:(NSString *)title;
- (id)initWithProgressViewTitle:(NSString *)title message:(NSString *)message;
- (void)close;
- (void)updateProgress:(float)progress;
@end
