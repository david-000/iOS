//
//  ScrollableImageView.h
//  iPhoneProject
//
//  Created by Componica on 10/2/12.
//
//

#import <UIKit/UIKit.h>

@interface ScrollableImageView : UIView<UIScrollViewDelegate> {
    
    UIScrollView *scrollView;
    UIImageView *imageView;
    UILabel *instructionLabel;
    
}

- (id)initWithFrame:(CGRect)frame;

- (void)setImage:(UIImage *)image;

@end
