//
//  RoundedRectView.h
//  iPhoneProject
//
//  Created by Componica on 8/31/12.
//
//

#import <UIKit/UIKit.h>

@interface RoundedRectView : UIView {
    
    UIColor *strokeColor;
    UIColor *fillColor;
    CGFloat strokeWidth;
    CGFloat cornerRadius;
    
    
}

@property(nonatomic, retain) UIColor *strokeColor;
@property(nonatomic, retain) UIColor *fillColor;
@property(nonatomic, assign) CGFloat strokeWidth;
@property(nonatomic, assign) CGFloat cornerRadius;

@end
