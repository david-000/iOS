//
//  ExamStrategiesVC.h
//  iPhoneProject
//
//  Created by MacBook on 7/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NavigationItemVC.h"

@interface ExamStrategiesVC : NavigationItemVC  


@end
