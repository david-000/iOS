//
//  Database.m
//  iPhoneProject
//
//  Created by Patrick Kellen on 8/30/12.
//
//

#import "Database.h"
#import "Util.h"
#import "FlashCardsDB.h"
#import "AchievementManager.h"
#import "CategoryDB.h"
#import "MnemonicsDB.h"

#define kUserDatabase @"user.sql"

@interface DatabaseConnection (Private)

- (BOOL)createUserDatabase;
- (BOOL)attachUserDatabase;
- (BOOL)populateUserDatabase;

- (BOOL)createFlashcardStateTable:(sqlite3 *)userDatabase;
- (BOOL)populateFlashcardStateTable;


- (BOOL)createAchievementStateTable:(sqlite3 *)userDatabase;
- (BOOL)populateAchievementStateTable;

- (BOOL)createCategoryStateTable:(sqlite3 *)userDatabase;
- (BOOL)populateCategoryStateTable;

- (BOOL)createMnemonicStateTable:(sqlite3 *)userDatabase;
- (BOOL)populateMnemonicsStateTable;

- (BOOL)createUserMnemonicTable:(sqlite3 *)userDatabase;

@end

@implementation DatabaseConnection

@synthesize database;

+ (DatabaseConnection *)instance {
    
    static DatabaseConnection *instance = nil;
    if(!instance) {
        instance = [[DatabaseConnection alloc] init];
        
    }
    
    return instance;
}

+ (NSString*) getDatabasePath{
    
    NSString *databaseName = [Util databaseName];
    return [[NSBundle mainBundle] pathForResource:databaseName ofType:@"sql"];
}

- (BOOL) connect {
    
    [self disconnect];
    
    NSString *dbPath = [DatabaseConnection getDatabasePath];
    if (sqlite3_open([dbPath UTF8String], &database) != SQLITE_OK) {
        NSLog(@"Unable to open database at: %@", dbPath);
        return NO;
    }
    
    sqlite3_config(SQLITE_CONFIG_SERIALIZED);
    
    //See if the user database exists, if not, create it!
    const bool userDatabaseDoesExist = [self userDatabaseDoesExist];
    if(!userDatabaseDoesExist) {
        NSLog(@"Creating user database...");
        [self createUserDatabase];
    }

    //Attach the user database
    [self attachUserDatabase];

    //Populate the user database based on the data from the other database
    if(!userDatabaseDoesExist) {
        NSLog(@"Populating user database...");
        [self populateUserDatabase];
        NSLog(@"Done populating user database!");
    }
    
    
    
    return YES;
}

- (BOOL) disconnect {
    
    if(database) {
        sqlite3_close(database);
        database = nil;
    }
    
    return YES;
}

- (BOOL) userDatabaseDoesExist {
 
    NSString *path = [self userDatabasePath];
    return [[NSFileManager defaultManager] fileExistsAtPath:path];
    
}

- (NSString *) userDatabasePath {
 
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
    return [documentsDirectory stringByAppendingPathComponent:kUserDatabase];
    
}

- (BOOL)beginTransaction {
 
    if(sqlite3_exec(database, "BEGIN", 0, 0, 0)) {
        NSLog(@"Unable to begin transaction");
        return NO;
    }
    
    return YES;
    
}

- (BOOL)commitTransaction {
 
    if(sqlite3_exec(database, "COMMIT", 0, 0, 0)) {
        NSLog(@"Unable to commit transaction");
        return NO;
    }
    
    return YES;
    
}

@end

@implementation Database

- (id) init {
 
    self = [super init];
    if(self) {
        
    }
    
    return self;
}

- (sqlite3 *)database {
 
    return [[DatabaseConnection instance] database];
    
}

@end

@implementation DatabaseConnection (Private)

- (BOOL) createUserDatabase {
    
    NSString *path = [self userDatabasePath];
    
    NSLog(@"Trying to create user database at %@", path);
    
    sqlite3 *userDatabase = NULL;
    
    if(sqlite3_open([path UTF8String], &userDatabase) != SQLITE_OK) {
        NSLog(@"Unable to open user database for creation!");
        return NO;
    } else {
        NSLog(@"Successfully created user database!");
    }
    
    //Create the tables
    [self createFlashcardStateTable:userDatabase];
    [self createAchievementStateTable:userDatabase];
    [self createCategoryStateTable:userDatabase];
    [self createMnemonicStateTable:userDatabase];
    [self createUserMnemonicTable:userDatabase];
    
    //Close it (we will attach it to the other database later)
    sqlite3_close(userDatabase);
    
    return YES;
}


- (BOOL)attachUserDatabase {
 
    NSString *path = [self userDatabasePath];
    NSString *query = [NSString stringWithFormat:@"ATTACH DATABASE '%@' AS user;", path];
    if(sqlite3_exec(database, [query UTF8String], NULL, NULL, NULL)) {
        NSString *message = [NSString stringWithFormat:@"Failed to execute query %@: %s", query, sqlite3_errmsg(database)];
        NSLog(@"%@", message);
        return NO;
    } else {
        NSLog(@"Successfully attached user database!");
        return YES;
    }
    
}

- (BOOL)populateUserDatabase {
 
    [self populateAchievementStateTable];
    [self populateCategoryStateTable];
    [self populateFlashcardStateTable];
    [self populateMnemonicsStateTable];
    
    return YES;
}


- (BOOL)createFlashcardStateTable:(sqlite3 *)userDatabase {
 
    const char *query = "CREATE TABLE flashcard_state ("
                        "   id INTEGER PRIMARY KEY, "
                        "   flashcard_id INTEGER NOT NULL, "
                        "   time DOUBLE DEFAULT 0, "
                        "   flashcard_status_id INTEGER NOT NULL, "
                        "   answer_status_id INTEGER NOT NULL "
                        " ) ";
 
    if(sqlite3_exec(userDatabase, query, NULL, NULL, NULL)) {
        printf("Unable to create flashcard_state table!");
        return NO;
    } else {
        NSLog(@"Successfully created flashcard_state table!");
    }
    
    return YES;
    
}

- (BOOL)populateFlashcardStateTable {
    
    
    NSInteger flashcardStatusId = [[FlashCardsDB instance] getFlashcardStatusId:@"unanswered"];
    NSInteger answerStatusId = [[FlashCardsDB instance] getAnswerStatusId:@"unanswered"];
    NSArray *flashcardIds = [[FlashCardsDB instance] getAllFlashcardIds];
    
    [self beginTransaction];
    
    sqlite3_stmt *stmt = nil;
    const char *query = "INSERT INTO user.flashcard_state(flashcard_id, flashcard_status_id, answer_status_id) "
                        "VALUES(?, ?, ?)";
    if(sqlite3_prepare_v2(database, query, -1, &stmt, NULL) != SQLITE_OK) {
        NSLog(@"Unable to prepare query in insertFlashcardState:flashcardStatusId:answerStatusId");
        return NO;
    }
    
    for(NSNumber *flashcardId in flashcardIds) {
        
        sqlite3_bind_int(stmt, 1, [flashcardId intValue]);
        sqlite3_bind_int(stmt, 2, flashcardStatusId);
        sqlite3_bind_int(stmt, 3, answerStatusId);
        
        if(sqlite3_step(stmt) != SQLITE_DONE) {
            NSLog(@"Unable to insert into flashcard_state");
            return NO;
        }
        
        sqlite3_reset(stmt);
        
    }
    
    sqlite3_finalize(stmt);
    
    [self commitTransaction];
    
    return YES;
}


- (BOOL)createAchievementStateTable:(sqlite3 *)userDatabase {
 
    const char *query = "CREATE TABLE achievement_state ("
                        "   id INTEGER PRIMARY KEY, "
                        "   achievement_id INTEGER NOT NULL, "
                        "   completed BOOL DEFAULT FALSE "
                        " ) ";
    
    if(sqlite3_exec(userDatabase, query, NULL, NULL, NULL)) {
        printf("Unable to create achievement_state table!");
        return NO;
    }
    
    return YES;
    
}

- (BOOL)populateAchievementStateTable {
    
    NSArray *achievementIds = [[AchievementManager instance] getAllAchievementIds];

    const char *query = "INSERT INTO user.achievement_state(achievement_id) "
                        "VALUES(?) ";
    
    [self beginTransaction];
    
    sqlite3_stmt *stmt = nil;
    if(sqlite3_prepare_v2(database, query, -1, &stmt, NULL) != SQLITE_OK) {
        NSLog(@"Unable to prepare query in insertAchievementState: %s", sqlite3_errmsg(database));
        return NO;
    }
    
    for(NSNumber *achievementId in achievementIds) {

        sqlite3_bind_int(stmt, 1, [achievementId intValue]);
        
        if(sqlite3_step(stmt) != SQLITE_DONE) {
            NSLog(@"Unable to insert into achievement_state");
            return NO;
        }

        sqlite3_reset(stmt);
        
    }
    
    sqlite3_finalize(stmt);

    [self commitTransaction];
    
    return YES;
}



- (BOOL)createCategoryStateTable:(sqlite3 *)userDatabase {
    
    const char *query = "CREATE TABLE category_state( "
                        "   id INTEGER PRIMARY KEY, "
                        "   category_id INTEGER NOT NULL, "
                        "   enabled BOOL DEFAULT 1 "
                        ") ";
    
    if(sqlite3_exec(userDatabase, query, NULL, NULL, NULL)) {
        printf("Unable to create category_state table!");
        return NO;
    }
    
    return YES;
}

- (BOOL)populateCategoryStateTable {
    
    NSArray *categoryIds = [[CategoryDB instance] getAllCategoryIds];
    
    NSMutableDictionary *enabledDictionary = [NSMutableDictionary dictionary];
    
    for(NSNumber *categoryId in categoryIds) {
        const BOOL enabled = [[CategoryDB instance] isCategoryEnabledByDefault:[categoryId intValue]];
        [enabledDictionary setValue:[NSNumber numberWithBool:enabled] forKey:[categoryId stringValue]];
    }
    
    const char *query = "INSERT INTO user.category_state(category_id, enabled) "
                        "VALUES(?, ?) ";

    [self beginTransaction];
    
    
    sqlite3_stmt *stmt = nil;
    if(sqlite3_prepare_v2(database, query, -1, &stmt, NULL) != SQLITE_OK) {
        NSLog(@"Unable to prepare query in insertCategoryState: %s", sqlite3_errmsg(database));
        return NO;
    }
    
    for(NSNumber *categoryId in categoryIds) {
    
        const BOOL enabledByDefault = [[enabledDictionary valueForKey:[categoryId stringValue]] boolValue];
        
        sqlite3_bind_int(stmt, 1, [categoryId intValue]);
        sqlite3_bind_int(stmt, 2, enabledByDefault ? 1 : 0);
        
        if(sqlite3_step(stmt) != SQLITE_DONE) {
            NSLog(@"Unable to insert into achievement_state");
            return NO;
        }
        
        sqlite3_reset(stmt);
        
    }
    
    sqlite3_finalize(stmt);

    [self commitTransaction];
    
    return YES;
}



- (BOOL)createMnemonicStateTable:(sqlite3 *)userDatabase {

    const char *query = "CREATE TABLE mnemonic_state ("
                        "   id INTEGER PRIMARY KEY, "
                        "   mnemonic_id INTEGER NOT NULL, "
                        "   saved BOOL DEFAULT FALSE "
                        ") ";
    
    if(sqlite3_exec(userDatabase, query, NULL, NULL, NULL)) {
        printf("Unable to create mnemonic_state table!");
        return NO;
    }
    
    return YES;
}

- (BOOL)populateMnemonicsStateTable {

    NSArray *mnemonicIds = [[MnemonicsDB instance] getAllMnemonicIds];
    
    const char *query = "INSERT INTO user.mnemonic_state(mnemonic_id) "
                        "VALUES(?) ";
    
    [self beginTransaction];
    
    sqlite3_stmt *stmt = nil;
    if(sqlite3_prepare_v2(database, query, -1, &stmt, NULL) != SQLITE_OK) {
        NSLog(@"Unable to prepare query in insertMnemonicsState: %s", sqlite3_errmsg(database));
        return NO;
    }
    
    
    for(NSNumber *mnemonicId in mnemonicIds) {
        
        sqlite3_bind_int(stmt, 1, [mnemonicId intValue]);
        
        if(sqlite3_step(stmt) != SQLITE_DONE) {
            NSLog(@"Unable to insert into achievement_state");
            return NO;
        }

        sqlite3_reset(stmt);
    }

    sqlite3_finalize(stmt);
    
    [self commitTransaction];
    
    return YES;
}


- (BOOL)createUserMnemonicTable:(sqlite3 *)userDatabase {

    const char *query = "CREATE TABLE user_mnemonic ( "
                        "   id INTEGER PRIMARY KEY, "
                        "   number INTEGER, "
                        "   title TEXT NOT NULL, "
                        "   text TEXT NOT NULL, "
                        "   mnemonic_type_id INTEGER NOT NULL "
                        ") ";
    
    if(sqlite3_exec(userDatabase, query, NULL, NULL, NULL)) {
        printf("Unable to create mnemonic_state table!");
        return NO;
    }
    
    return YES;
    
}


@end
