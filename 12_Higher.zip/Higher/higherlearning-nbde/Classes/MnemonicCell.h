//
//  MnemonicCell.h
//  iPhoneProject
//
//  Created by Patrick Kellen on 8/31/12.
//
//

#import <UIKit/UIKit.h>

@class RoundedRectView;

@interface MnemonicCell : UITableViewCell {
   
    RoundedRectView *backgroundView;
    UILabel *contentLabel;
    
}

@property(nonatomic, retain) UILabel *contentLabel;

//- (id)initWithTitle:(NSString *)title
//              width:(CGFloat)width;

- (id)initWithTitle:(NSString *)title
              width:(CGFloat)width
          fillcolor:(UIColor*)fillColor;

@end
