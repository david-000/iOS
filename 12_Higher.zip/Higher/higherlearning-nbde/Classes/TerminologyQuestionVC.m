//
//  TerminologyQuestionVC.m
//  iPhoneProject
//
//  Created by Componica on 10/1/12.
//
//

#import "TerminologyQuestionVC.h"
#import "QuestionCell.h"

@interface TerminologyQuestionVC ()

@end

@implementation TerminologyQuestionVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void) initComponentsWithFlashCard:(FlashCard*) card{
    
	self.flashCard = card;
    
    [cells removeAllObjects];
    QuestionCell *questionCell = [[QuestionCell alloc] initWithQuestionText:flashCard.question
                                                          extraQuestionText:flashCard.extraQuestionText
                                                        flashcardStatusName:flashCard.flashcardStatusName
                                                                      width:myTableView.bounds.size.width];
    questionCell.contentLabel.textAlignment = NSTextAlignmentCenter;
    [cells addObject:[NSArray arrayWithObject:questionCell]];
    [questionCell release];

    headerHeight = (myTableView.frame.size.height - questionCell.frame.size.height) / 2.0f;
    
    myTableView.backgroundColor = [UIColor clearColor];
    myTableView.backgroundView = nil;
    [myTableView scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:NO];
    [myTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [myTableView reloadData];
    
	//starting question....
	if (delegate && [delegate respondsToSelector:@selector(QuestionVCOnStarting:)]) {
		[delegate QuestionVCOnStarting:self];
	}
    
    
}
    
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIView *)tableView:(UITableView *)tv viewForHeaderInSection:(NSInteger)section{
	
    return nil;
    
}

-(CGFloat)tableView:(UITableView *)tv heightForHeaderInSection:(NSInteger)section{
    
    return headerHeight;
    
}

@end
