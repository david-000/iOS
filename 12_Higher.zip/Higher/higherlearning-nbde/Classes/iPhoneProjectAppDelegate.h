//
//  iPhoneProjectAppDelegate.h

#import <UIKit/UIKit.h>
#import "HomeVC.h"
#import "FBConnect.h"

@class RootVC;

@interface iPhoneProjectAppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
    RootVC *rootVC;
    HomeVC* homeVC;
    Facebook *facebook;
    
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) Facebook *facebook;

//- (void) createDatabaseIfNeeded;

@end

