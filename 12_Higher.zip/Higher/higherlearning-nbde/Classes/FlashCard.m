//
//  StudentObj.m
//  MySQLiteProject
//

#import "FlashCard.h"
#import "Util.h"

@implementation Answer

@synthesize text;
@synthesize correct;
@synthesize selected;
@synthesize crossed;

- (id) copyWithZone:(NSZone *)zone {
    
    Answer *answer = [[Answer alloc] init];
    answer.text = text;
    answer.correct = correct;
    answer.selected = selected;
    answer.crossed = crossed;
    return answer;
    
}

- (void)dealloc {
    [text release];
    [super dealloc];
}

@end

@implementation FlashCard

@synthesize question;
@synthesize answers;
@synthesize cardID;
@synthesize category;
@synthesize image;
@synthesize rationale;
@synthesize rationalePreview;
@synthesize mnemonics;
@synthesize flashcardStatusId;
@synthesize flashcardStatusName;
@synthesize answerStatusId;
@synthesize answerStatusName;
@synthesize time;
@synthesize extraQuestionText;
@synthesize numberOfCorrectAnswers;
@synthesize answered;

- (id)initWithCardID:(NSInteger)_cardID
            question:(const char *)_question
       choicesString:(const char *)_choicesString
       answersString:(const char *)_answersString
            category:(Category *)_category
               image:(Image *)_image
           rationale:(const char *)_rationale
    rationalePreview:(const char *)_rationalePreview
           mnemonics:(NSArray *)_mnemonics
   flashcardStatusId:(NSInteger)_flashcardStatusId
 flashcardStatusName:(const char *)_flashcardStatusName
                time:(double)_time
      answerStatusId:(NSInteger)_answerStatusId
    answerStatusName:(const char *)_answerStatusName {
    
    self = [super init];
    if(self) {
        
        
        self.cardID = _cardID;
        self.question = _question ? [NSString stringWithUTF8String:_question] : nil;
        self.category = _category;
        self.image = _image;
        self.rationale = _rationale ? [NSString stringWithUTF8String:_rationale] : nil;
        self.rationalePreview = _rationalePreview ? [NSString stringWithUTF8String:_rationalePreview] : nil;
        self.mnemonics = _mnemonics;
        self.flashcardStatusId = _flashcardStatusId;
        self.flashcardStatusName = _flashcardStatusName ? [NSString stringWithUTF8String:_flashcardStatusName] : nil;
        self.time = _time;
        self.answerStatusId = _answerStatusId;
        self.answerStatusName = _answerStatusName ? [NSString stringWithUTF8String:_answerStatusName] : nil;
        self.answers = [NSMutableArray array];
        self.answered = NO;
        
        NSArray *choices = _choicesString ? [[NSString stringWithUTF8String:_choicesString] componentsSeparatedByString:@";"] : nil;
        
        NSString *answersString = _answersString ? [NSString stringWithUTF8String:_answersString] : nil;
        
        numberOfCorrectAnswers = 0;
        for(NSInteger index = 0; index < choices.count; ++index) {
            
            Answer *answer = [[Answer alloc] init];
            NSString *choice = [choices objectAtIndex:index];
            answer.text = [Util trimString:choice];
            NSString *answerIndexString = [NSString stringWithFormat:@"%d", index + 1];
            answer.correct = [Util checkString:answersString containSubString:answerIndexString];
            if(answer.correct) {
                numberOfCorrectAnswers++;
            }
            [answers addObject:answer];
            [answer release];
            
        }
        
        //If there is more than one answer that is correct
        if(numberOfCorrectAnswers > 1) {
            self.extraQuestionText = @"Select all that apply.";
        } else {
            self.extraQuestionText = nil;
        }
        
    }
    
    return self;
}


- (void) dealloc{
    
    [question release];
    [answers release];
    [category release];
    [image release];
    [rationale release];
    [rationalePreview release];
    [mnemonics release];
    [flashcardStatusName release];
    [answerStatusName release];
    [extraQuestionText release];
	[super dealloc];
    
}

- (id) copyWithZone:(NSZone *)zone {
    
    FlashCard *flashcard = [[FlashCard alloc] init];
    flashcard.cardID = cardID;
    flashcard.question = [question copy];
    [flashcard.question release];
    flashcard.answers = [NSMutableArray array];
    for(Answer *answer in answers) {
        [flashcard.answers addObject:answer];
    }
    flashcard.category = [category copy];
    [flashcard.category release];
    flashcard.image = [image copy];
    [flashcard.image release];
    flashcard.rationale = [rationale copy];
    [flashcard.rationale release];
    flashcard.rationalePreview = [rationalePreview copy];
    [flashcard.rationalePreview release];
    flashcard.mnemonics = [mnemonics copy];
    [flashcard.mnemonics release];
    flashcard.flashcardStatusId = flashcardStatusId;
    flashcard.flashcardStatusName = [flashcardStatusName copy];
    [flashcard.flashcardStatusName release];
    flashcard.answerStatusId = answerStatusId;
    flashcard.answerStatusName = [answerStatusName copy];
    [flashcard.answerStatusName release];
    flashcard.time = time;
    flashcard.extraQuestionText = [extraQuestionText copy];
    [flashcard.extraQuestionText release];
    flashcard.numberOfCorrectAnswers = numberOfCorrectAnswers;
    flashcard.answered = answered;
    return flashcard;
    
}

- (void)setFlashcardStatusName:(NSString *)flashcardStatusName_ {
    
    if(flashcardStatusName_ != flashcardStatusName) {
        [flashcardStatusName release];
        flashcardStatusName = [flashcardStatusName_ retain];
        flashcardStatusId = [[FlashCardsDB instance] getFlashcardStatusId:flashcardStatusName];
    }
    
}

- (void)setAnswerStatusName:(NSString *)answerStatusName_ {
    
    if(answerStatusName_ != answerStatusName) {
        [answerStatusName release];
        answerStatusName = [answerStatusName_ retain];
        answerStatusId = [[FlashCardsDB instance] getAnswerStatusId:answerStatusName];
    }
    
}

- (void)reset {
    
    answered = NO;
    for(Answer *answer in answers) {
        answer.selected = NO;
    }
    
}


@end


