//
//  CategoryVC.m
//  iPhoneProject
//
//  Created by MacBook on 6/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CategoryVC.h"
#import "StudyFlashcardVC.h"
#import "TerminologyFlashcardVC.h"
#import "Util.h"
#import "Global.h"
#import "Category.h"
#import "FlashCardsDB.h"
#import "GANTracker.h"
#import "HelpFlashcard.h"

@interface CategoryVC (Private)

- (void)createCells;
- (void)updatePercentageViews;

@end

@implementation CategoryVC

@synthesize myTableView;

- (id)initWithCategoryType:(NSString *)_categoryTypeName {
    
    self = [super initWithNibName:NibName(@"CategoryVC") bundle:nil];
    
    if(self) {
        
        categoryTypeName = [_categoryTypeName retain];
        categories = [[[CategoryDB instance] getRootCategoriesForCategoryType:categoryTypeName] retain];
        
        for(Category *category in categories) {
            //Get the subcategories for each category
            category.subcategories = [[CategoryDB instance] getChildCategoriesForCategory:category.categoryID
                                                                                recursive:YES];
        }
        
        cells = [[NSMutableArray alloc] init];
        
    }
    
    return self;
    
}

- (void) dealloc{

    myTableView.delegate = nil;
    myTableView.dataSource = nil;
    [myTableView release];
    [categoryTypeName release];
	[cells release];
    [categories release];
    [super dealloc];
    
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}


- (IBAction) onGoButton:(id)sender {
     
    //Make sure we have at least one enabled category
    NSInteger numberOfEnabledCategories = 0;
    NSInteger numberOfAvailableCategories = 0;
    for(Category *category in categories) {
        if(category.enabled) {
            numberOfEnabledCategories += 1;
        }
        if(category.available) {
            numberOfAvailableCategories += 1;
        }
        for(Category *subcategory in category.subcategories) {
            if(subcategory.enabled) {
                numberOfEnabledCategories += 1;
            }
        }
    }
    
    if(numberOfAvailableCategories == 0) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil
                                                        message:@"No categories available!"
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    } else if(numberOfEnabledCategories == 0) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil
                                                        message:@"Must select at least one category!"
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    
    } else {
        
        if([categoryTypeName isEqualToString:@"terminology"]) {
            
            TerminologyFlashcardVC* controller = [[TerminologyFlashcardVC alloc] init];        
            [self.navigationController pushViewController:controller animated:YES];
            [controller release];
            
        } else if([categoryTypeName isEqualToString:@"multiple-choice"]) {
            /*
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            NSString *strFirstTime = [defaults objectForKey:@"FirstTry"];
            
            if (!strFirstTime || [strFirstTime isEqualToString:@"YES"]) {
                NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                [defaults setObject:@"NO" forKey:@"FirstTry"];
                [defaults synchronize];
                
                
                HelpFlashcard *controller;
                
                if(UI_USER_INTERFACE_IDIOM()==UIUserInterfaceIdiomPad){
                    controller = [[[HelpFlashcard alloc] initWithNibName:@"HelpFlashcard_IPad" bundle:nil] autorelease];
                }
                else{
                    controller = [[[HelpFlashcard alloc] initWithNibName:@"HelpFlashcard" bundle:nil] autorelease];
                }
                
                [self.navigationController pushViewController:controller animated:YES];
            }
            else{
             
             */
                StudyFlashcardVC *controller = [[StudyFlashcardVC alloc] init];
                [self.navigationController pushViewController:controller animated:YES];
                [controller release];
//            }
        }
   }
}


#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
        
	return [cells count];
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return 1;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
    CategoryCell *cell = [cells objectAtIndex:indexPath.row];
    Category *category = [categories objectAtIndex:indexPath.row];
    [cell setIsChecked:category.enabled];
    
//    [cell checkSubcategories];
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
 
    
}

#pragma UITableViewDataSource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
        
    CategoryCell *cell = [cells objectAtIndex:indexPath.row];
    return cell.bounds.size.height;
     
}

#pragma mark - View lifecycle

- (void)viewWillAppear:(BOOL)animated {
 
    [super viewWillAppear:animated];
    [self updatePercentageViews];
    
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Study Flashcard Categories"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self createCells];
    

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

#pragma mark CategoryCell delegate methods

- (void)categoryCellWillBeginAnimating:(CategoryCell *)cell {
 
    [myTableView reloadData];
    myTableView.userInteractionEnabled = NO;
    
}

- (void)categoryCellDidFinishAnimating:(CategoryCell *)cell {
    
    myTableView.userInteractionEnabled = YES;
    NSIndexPath *indexPath = [myTableView indexPathForCell:cell];
    [myTableView scrollToRowAtIndexPath:indexPath
                       atScrollPosition:UITableViewScrollPositionTop
                               animated:YES];
    
}

- (void)categoryCell:(CategoryCell *)cell
             checked:(BOOL)checked {
    
    [[CategoryDB instance] updateCategory:cell.category.categoryID
                                  enabled:checked
                                recursive:YES];
}


@end

@implementation CategoryVC (Private)

- (void)createCells {
         
    //Initialize the cells in an array
    [cells removeAllObjects];
    for(Category *category in categories) {
        BOOL expandable = category.subcategories.count > 0 ? YES : NO;
        CategoryCell *cell = [[CategoryCell alloc] initWithCategory:category
                                                           delegate:self
                                                              width:myTableView.frame.size.width
                                                         expandable:expandable
                                                             indent:YES];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cells addObject:cell];
        [cell release];
    }
    
}

- (void)updatePercentageViews {
 
    for(NSInteger categoryIndex = 0; categoryIndex < categories.count; categoryIndex++) {
 
        Category *category = [categories objectAtIndex:categoryIndex];
        CategoryCell *categoryCell = [cells objectAtIndex:categoryIndex];
        
        //Get the flashcard count for each type
        category.numberOfRedFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                 flashcardStatusName:@"red"
                                                                                           recursive:NO];
        
        category.numberOfYellowFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                    flashcardStatusName:@"yellow"
                                                                                              recursive:NO];
        
        category.numberOfGreenFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                   flashcardStatusName:@"green"
                                                                                             recursive:NO];
        
        category.numberOfUnansweredFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                        flashcardStatusName:@"unanswered"
                                                                                                  recursive:NO];
        categoryCell.category = category;
        
        for(NSInteger subcategoryIndex = 0; subcategoryIndex < category.subcategories.count; subcategoryIndex++) {
            
            Category *subcategory = [category.subcategories objectAtIndex:subcategoryIndex];
            CategoryCell *subcategoryCell = [categoryCell.childrenCells objectAtIndex:subcategoryIndex];
            
            
            //Get the flashcard count for each type
            subcategory.numberOfRedFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:subcategory.categoryID
                                                                                        flashcardStatusName:@"red"
                                                                                                  recursive:NO];
            
            subcategory.numberOfYellowFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:subcategory.categoryID
                                                                                           flashcardStatusName:@"yellow"
                                                                                                     recursive:NO];
            
            subcategory.numberOfGreenFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:subcategory.categoryID
                                                                                          flashcardStatusName:@"green"
                                                                                                    recursive:NO];
            
            subcategory.numberOfUnansweredFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:subcategory.categoryID
                                                                                               flashcardStatusName:@"unanswered"
                                                                                                         recursive:NO];
            subcategoryCell.category = subcategory;
            [subcategoryCell updatePercentageView];
        }
     
        [categoryCell updatePercentageView];
    }
    
}

@end
