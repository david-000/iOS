//
//  GuaranteeVC.h
//  iPhoneProject
//
//  Created by Componica on 8/29/12.
//
//

#import <UIKit/UIKit.h>
#import "NavigationItemVC.h"

@interface GuaranteeVC : NavigationItemVC {
    
}

@end
