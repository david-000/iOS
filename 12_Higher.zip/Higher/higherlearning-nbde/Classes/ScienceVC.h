//
//  ScienceVC.h
//  iPhoneProject
//
//  Created by MacBook on 7/6/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NavigationItemVC.h"

@interface ScienceVC : NavigationItemVC
{
    IBOutlet UIScrollView *myScollView;
}

@property(nonatomic, retain) UIScrollView *myScrollView;

@end
