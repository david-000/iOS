//
//  CategoryCell.m
//  iPhoneProject
//
//  Created by Componica on 8/29/12.
//
//

#import "CategoryCell.h"
#import "Util.h"
#import "FlashCard.h"
#import "Util.h"
#import "RoundedRectView.h"
#import "Category.h"

#define kHorizontalPadding 10
#define kVerticalPadding 5
#define kMinHeightPhone 75
#define kMinHeightPad 100

#define kPercentageViewHeight 6

@interface CategoryCell (Private)

- (void)onExpandButton;
- (void)onCheckboxButton;
- (void)expandView;
- (void)retractView;

@end

@implementation PercentageView

- (id)initWithFrame:(CGRect)frame
           category:(Category *)category {
 
    self = [super initWithFrame:frame];
    if(self) {
        self.backgroundColor = [UIColor blackColor];
        [self update:category];
    }
    
    return self;
}

- (void)update:(Category *)category {
    
    //Tally up the total number  cards for each stats
    NSInteger totalNumberOfRedCards = category.numberOfRedFlashcards;
    NSInteger totalNumberOfYellowCards = category.numberOfYellowFlashcards;
    NSInteger totalNumberOfGreenCards = category.numberOfGreenFlashcards;
    NSInteger totalNumberOfUnansweredCards = category.numberOfUnansweredFlashcards;
    for(Category *subcategory in category.subcategories) {
        
        totalNumberOfRedCards += subcategory.numberOfRedFlashcards;
        totalNumberOfYellowCards += subcategory.numberOfYellowFlashcards;
        totalNumberOfGreenCards += subcategory.numberOfGreenFlashcards;
        totalNumberOfUnansweredCards += subcategory.numberOfUnansweredFlashcards;
        
    }
    
    NSInteger totalNumberOfCards = totalNumberOfRedCards + totalNumberOfYellowCards + totalNumberOfGreenCards + totalNumberOfUnansweredCards;
    if(totalNumberOfCards == 0) {
        return;
    }
    
    //Calculate the percentages
    const float redPercentage = totalNumberOfRedCards / (float)(totalNumberOfCards);
    const float yellowPercentage = totalNumberOfYellowCards / (float)(totalNumberOfCards);
    const float greenPercentage = totalNumberOfGreenCards / (float)(totalNumberOfCards);
    
    //Create the green view
    [greenView removeFromSuperview];
    [greenView release];
    greenView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, greenPercentage * self.frame.size.width, self.frame.size.height)];
    greenView.backgroundColor = [UIColor greenColor];
    [self addSubview:greenView];
    
    //Create the yellow view
    [yellowView removeFromSuperview];
    [yellowView release];
    yellowView = [[UIView alloc] initWithFrame:CGRectMake(greenView.frame.origin.x + greenView.frame.size.width, 0, yellowPercentage * self.frame.size.width, self.frame.size.height)];
    yellowView.backgroundColor = [UIColor yellowColor];
    [self addSubview:yellowView];
    
    //Create the red view
    [redView removeFromSuperview];
    [redView release];
    redView = [[UIView alloc] initWithFrame:CGRectMake(yellowView.frame.origin.x + yellowView.frame.size.width, 0, redPercentage * self.frame.size.width, self.frame.size.height)];
    redView.backgroundColor = [UIColor redColor];
    [self addSubview:redView];
    
}

- (void)dealloc {
    
    [greenView release];
    [yellowView release];
    [redView release];

    [super dealloc];
}

@end


@implementation CategoryCell

@synthesize category;
@synthesize childrenCells;
@synthesize isChecked;
@synthesize parent;

- (id)initWithCategory:(Category *)_category
              delegate:(NSObject<CategoryCellDelegate> *)_delegate
                 width:(CGFloat)width
            expandable:(BOOL)expandable
                indent:(BOOL)indent

{
    self = [super initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    if (self) {
                
        isChecked = YES;
        isExpanded = NO;
        delegate = _delegate;
        self.category = _category;
        self.parent = nil;
        childrenCells = [[NSMutableArray alloc] init];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.accessoryType = UITableViewCellAccessoryNone;
        self.backgroundColor = [UIColor clearColor];
        
        const CGFloat horizontalMargin = expandable ? kHorizontalPadding : 0;
        
        UIImage *expandImage = [UIImage imageNamed:ResName(@"add")];
        UIImage *checkboxImage = [UIImage imageNamed:ResName(@"check")];
        
        //Figure out how big the text will be
        UIFont *font = [UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]];
        CGFloat availableTextWidth = width - checkboxImage.size.width - 2 * horizontalMargin;
        if(expandable) {
            availableTextWidth -= expandImage.size.width;
        }
        
        CGSize textSize = [self.category.categoryName sizeWithFont:font
                                                 constrainedToSize:CGSizeMake(availableTextWidth, NSIntegerMax)
                                                     lineBreakMode:NSLineBreakByWordWrapping];
        CGFloat height = [Util isIPad] ? kMinHeightPad : kMinHeightPhone;
        height = fmax(height, textSize.height + kVerticalPadding * 4);
        
        //Set up the background view
        const NSInteger backgroundWidth = width - horizontalMargin * 2;
        const NSInteger backgroundHeight = height - kVerticalPadding * 2;
        backgroundView = [[RoundedRectView alloc] initWithFrame:CGRectMake(horizontalMargin, 0, backgroundWidth, backgroundHeight)];
        [self addSubview:backgroundView];
        
        
        //Set up the expand button
        if(expandable) {
            expandButton = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
            [expandButton setBackgroundImage:expandImage forState:UIControlStateNormal];
            NSInteger expandButtonX = backgroundView.frame.origin.x+5;
            NSInteger expandButtonY = backgroundView.center.y - expandImage.size.height / 2.0f;
            [expandButton setFrame:CGRectMake(expandButtonX, expandButtonY, expandImage.size.width, expandImage.size.height)];
            [expandButton addTarget:self action:@selector(onExpandButton) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:expandButton];
        }
            
        //Set up the checkbox
        checkboxButton = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
        NSInteger checkboxX = backgroundView.frame.origin.x + backgroundView.frame.size.width - checkboxImage.size.width-5;
        NSInteger checkboxY = backgroundView.center.y - checkboxImage.size.height / 2.0f;
        [checkboxButton setFrame:CGRectMake(checkboxX, checkboxY, checkboxImage.size.width, checkboxImage.size.height)];
        [checkboxButton addTarget:self action:@selector(onCheckboxButton)
                 forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:checkboxButton];
        
        //Set up the percentage view
        const CGFloat percentageViewWidth = backgroundView.frame.size.width - backgroundView.cornerRadius * 2;
        percentageView = [[PercentageView alloc] initWithFrame:CGRectMake(0, 0, percentageViewWidth, kPercentageViewHeight)
                                                      category:category];
        [percentageView setFrame:CGRectMake(backgroundView.center.x - percentageView.frame.size.width / 2.0f,
                                            backgroundView.frame.origin.y + backgroundView.frame.size.height,
                                            percentageView.frame.size.width, percentageView.frame.size.height)];
        [self addSubview:percentageView];
        
        //Set up the content label
        NSInteger contentX = expandable ? expandButton.frame.origin.x + expandButton.frame.size.width + 5 : 10;
        NSInteger contentY = backgroundView.frame.origin.y;
        NSInteger contentWidth = checkboxButton.frame.origin.x - (expandButton.frame.size.width + expandButton.frame.origin.x) - 2 * kHorizontalPadding;
        NSInteger contentHeight = backgroundView.frame.size.height;
        
        UILabel *content = [[UILabel alloc] initWithFrame:CGRectMake(contentX, contentY, contentWidth, contentHeight)];
        [content setBackgroundColor:[UIColor clearColor]];
        [content setTextColor:[UIColor darkGrayColor]];
        [content setText:category.categoryName];
        [content setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
        [content setTextAlignment:NSTextAlignmentLeft];
        content.lineBreakMode = NSLineBreakByWordWrapping;
        content.numberOfLines = 0;
        [self addSubview:content];
        [content release];
        
        
        NSInteger subcategoryViewWidth = backgroundView.frame.origin.x + backgroundView.frame.size.width - expandButton.center.x;
        CGFloat subcategoryViewHeight = 0;
        for(Category *childCategory in category.subcategories) {
            
            CategoryCell *cell = [[CategoryCell alloc] initWithCategory:childCategory
                                                               delegate:delegate
                                                                  width:subcategoryViewWidth
                                                             expandable:NO
                                                                 indent:NO];
            cell.parent = self;
            [cell setIsChecked:childCategory.enabled];
            
            [childrenCells addObject:cell];
            [cell release];
            subcategoryViewHeight += cell.frame.size.height;
        
        }
        
        if (category.subcategories.count > 0) {
            [self checkSubcategories];
        }

        
        NSInteger subcategoryViewX = expandButton.center.x;
        NSInteger subcategoryViewY = percentageView.frame.origin.y + percentageView.frame.size.height + kVerticalPadding;
        subcategoryView = [[UIView alloc] initWithFrame:CGRectMake(subcategoryViewX, subcategoryViewY, subcategoryViewWidth, subcategoryViewHeight)];
        subcategoryView.backgroundColor = [UIColor clearColor];
        
        
        NSInteger subcategoryCellY = 0;
        
        for(CategoryCell *cell in childrenCells) {
         
            [subcategoryView addSubview:cell];
            [cell setFrame:CGRectMake(0, subcategoryCellY, cell.frame.size.width, cell.frame.size.height)];
            subcategoryCellY += cell.frame.size.height;
            
        }
        
        upgradeAlert = [[UIAlertView alloc] initWithTitle:@"Upgrade"
                                                  message:@"This category is not available in the free version, would you like to upgrade to the full version?"
                                                 delegate:self
                                        cancelButtonTitle:@"Close"
                                        otherButtonTitles:@"Full Version", nil];
        
         
        [self setFrame:CGRectMake(0, 0, width, height)];
    }
    return self;
}

- (void) dealloc {
 
    [expandButton release];
    [checkboxButton release];
    [percentageView release];
    [subcategoryView release];
    [backgroundView release];
    [childrenCells release];
    [upgradeAlert release];
    [parent release];
    
    [super dealloc];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


- (void)setIsChecked:(BOOL)_isChecked {
    isChecked = _isChecked;
    category.enabled = isChecked;
    if(isChecked) {
    
        UIImage *image = [UIImage imageNamed:ResName(@"check")];
        [checkboxButton setImage:image
                        forState:UIControlStateNormal];
        
    } else {
        
        UIImage *image = [UIImage imageNamed:ResName(@"check_box")];
        [checkboxButton setImage:image
                        forState:UIControlStateNormal];
        
    }

    
}


- (void)updatePercentageView {
    
    [percentageView update:category];
    
}
- (void)checkSubcategories{

    if (childrenCells.count == 0) {
        return;
    }
        NSLog(@"categorynaem : %@",self.category.categoryName);
    
    int checkedNum = 0;
    for(CategoryCell *childCell in childrenCells) {
        if (childCell.isChecked) {
            checkedNum ++;
        }
    }
    
    if (checkedNum == [childrenCells count]) {
        checkboxButton.alpha = 1.f;
        [self setIsChecked:YES];
        
        [delegate categoryCell:self
                       checked:isChecked];
    }
    else if(checkedNum > 0 && checkedNum < [childrenCells count]){
        checkboxButton.alpha = 0.5f;
        
        UIImage *image = [UIImage imageNamed:ResName(@"check")];
        [checkboxButton setImage:image
                        forState:UIControlStateNormal];
    }
    else if(checkedNum == 0){
        checkboxButton.alpha = 1.f;
        [self setIsChecked:NO];
    }
}
#pragma mark UIAlertViewDelegate methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if(alertView == upgradeAlert) {
        if(buttonIndex == 0) {
            //Don't do anything
        } else {
            [[UIApplication sharedApplication] openURL:[Util fullVersionURL]];
        }
    }
}



@end

@implementation CategoryCell (Private)

- (void)onExpandButton {
 
    isExpanded = !isExpanded;
    if(isExpanded) {
        [self expandView];
    } else {
        [self retractView];
    }
     
}

- (void)onCheckboxButton {
    [self setIsChecked:!isChecked];
    for(CategoryCell *childCell in childrenCells) {
        [childCell setIsChecked:isChecked];
    }
    
    if (parent) {
        [parent checkSubcategories];
    }
    
    [delegate categoryCell:self
                   checked:isChecked];

    
}


- (void)expandView {

    UIImage *image = [UIImage imageNamed:ResName(@"remove")];
    [expandButton setBackgroundImage:image forState:UIControlStateNormal];
    NSInteger totalHeight = self.frame.size.height + subcategoryView.frame.size.height;
    [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, totalHeight)];
    [delegate categoryCellWillBeginAnimating:self];
    [self addSubview:subcategoryView];
    [delegate categoryCellDidFinishAnimating:self];
    
}

- (void)retractView {
    
    UIImage *image = [UIImage imageNamed:ResName(@"add")];
    [expandButton setBackgroundImage:image forState:UIControlStateNormal];
    NSInteger totalHeight = self.frame.size.height - subcategoryView.frame.size.height;
    [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, totalHeight)];
    [delegate categoryCellWillBeginAnimating:self];
    [subcategoryView removeFromSuperview];
    [delegate categoryCellDidFinishAnimating:self];
    
}


@end
