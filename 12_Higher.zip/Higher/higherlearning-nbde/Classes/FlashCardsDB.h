//
//  StudentsDB.h
//  MySQLiteProject
//


#import <Foundation/Foundation.h>
#import "Database.h"

@class FlashCard;
@class Category;

@interface FlashCardsDB : Database {
    
}

+ (FlashCardsDB *)instance;

- (NSMutableArray*) getFlashCardsWithCategoryID:(int)categoryID
                            flashcardStatusName:(NSString *)flashcardStatusName;

- (FlashCard *) getFlashcardWithId:(NSInteger)flashcardId;

- (NSMutableArray *)getAllFlashcardIds;

- (NSMutableArray *)getEnabledFlashcardIdsWithStatus:(NSString *)flashcardStatusName
                                    categoryTypeName:(NSString *)categoryTypeName;

- (NSMutableArray*) getFlashCardsWithStatus:(NSString *)flashcardStatusName
                          categoryTypeName:(NSString *)categoryTypeName;

- (NSMutableArray*) getAllFlashCardsForCategoryType:(NSString *)categoryTypeName;

- (NSMutableArray *) getFlashCardsWithCategoryID:(int)categoryID
                                       recursive:(BOOL)recursive;

- (BOOL) updateFlashCardWithFlashcardStatus:(NSString *)flashcardStatusName cardID:(NSInteger) cID;

- (BOOL) updateFlashCardWithAnswerStatus:(NSString *)answerStatusName
                                  cardID:(NSInteger) cardID;

- (BOOL) updateFlashCardWithNewTime:(double) time cardID:(NSInteger) cID;

- (BOOL) resetFlashCardsWithCategoryID:(int)categoryID
                             recursive:(BOOL)recursive;

- (int) getCountOfFlashCardsWithCategoryID:(int) categoryID;

- (int) getCountOfFlashCardsWithCategoryID:(int) categoryID
                       flashcardStatusName:(NSString *)flashcardStatusName
                                 recursive:(BOOL)recursive;

- (int) getCountOfChildFlashCardsWithParentCategory:(NSInteger)parentCategoryId
                                flashcardStatusName:(NSString *)flashcardStatusName
                                          recursive:(BOOL)recursive;

- (int) getCountOfFlashCardsWithCategoryID:(int) categoryID 
                       flashcardStatusName:(NSString *)flashcardStatusName;

- (int) getCountOfAnsweredFlashCardsWithCategoryID:(int) categoryID;

- (int) getCountOfCorrectFlashCardsWithCategoryID:(int) categoryID;

- (int) getCountOfFlashCardsWithCategoryID:(int)categoryID
                              answerStatus:(NSString *)answerStatusName
                                 recursive:(BOOL)recursive;

- (int) getCountOfFlashCardsWithFlashcardStatusName:(NSString *)flashcardStatusName
                                       answerStatus:(NSString *)answerStatusName;

- (NSString *) getCategoryNameWithCategoryID:(int) categoryID;

- (double) getAverageTimeForEachQuestion;

- (NSArray *) getTimesForEachQuestionWithCategoryID:(int)categoryID;

- (NSInteger) getFlashcardStatusId:(NSString *)flashcardStatusName;

- (NSInteger) getAnswerStatusId:(NSString *)answerStatusName;

- (void)checkImages;

- (void)checkForUnusedImages;

@end