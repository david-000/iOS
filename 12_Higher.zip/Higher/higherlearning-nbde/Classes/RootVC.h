//
//  RootVC.h
//  iPhoneProject
//
//  Created by Componica on 9/21/12.
//
//

#import <UIKit/UIKit.h>

@interface RootVC : UINavigationController

@end
