//
//  ExamStrategiesVC.m
//  iPhoneProject
//
//  Created by MacBook on 7/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ExamStrategiesVC.h"
#import "Util.h"
#import "GANTracker.h"

@implementation ExamStrategiesVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (id) init {
 
    NSString *nib = NibName(@"ExamStrategiesVC");
    self = [super initWithNibName:nib bundle:nil];
    if(self) {
        
    }
    return self;
    
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidAppear:(BOOL)animated {
 
    [super viewDidAppear:animated];
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Exam Strategies"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

@end
