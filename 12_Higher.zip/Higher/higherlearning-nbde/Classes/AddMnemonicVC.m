//
//  AddMnemonicVC.m
//  iPhoneProject
//
//  Created by MacBook on 7/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AddMnemonicVC.h"
#import <QuartzCore/QuartzCore.h>
#import "MnemonicsDB.h"
#import "FlashCard.h"
#import "Mnemonic.h"
#import "GANTracker.h"

@implementation AddMnemonicVC

@synthesize myTextView;
@synthesize titleView;


- (void)dealloc {
 
    [myTextView release];
    [titleView release];
    [super dealloc];
    
}

#pragma UITextViewDelegate

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}


- (IBAction) doGoBack:(id)sender {
	[self.navigationController popViewControllerAnimated:YES];
}

- (void) initViewComponents {
    myTextView.layer.borderColor = [[UIColor grayColor] CGColor];
    
}

- (IBAction)saveMnemonic:(id)sender
{
    
    NSString *mnemonicTitle = [Util trimString:titleView.text];
    if(mnemonicTitle.length == 0) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil
                                                        message:@"Please enter a title."
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
        return;
    }

    NSString *mnemonicText = [Util trimString:myTextView.text];
    if(mnemonicText.length == 0) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil
                                                        message:@"Please enter a mnemonic."
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
        return;
    }
    
    [[MnemonicsDB instance] addMnemonic:mnemonicText title:mnemonicTitle];
    
    [Util displayAlertWithMessage:@"Mnemonics" andTitle:@"Your mnemonic is saved!" tag:1];
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)closeKB:(id)sender
{
    [myTextView resignFirstResponder];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        [self initViewComponents];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void) viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Add Mnemonic"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

@end
