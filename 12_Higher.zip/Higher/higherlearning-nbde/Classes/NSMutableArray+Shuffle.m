
#import "NSMutableArray+Shuffle.h"

// Unbiased random rounding thingy.
static NSUInteger random_below(NSUInteger n) {
	NSUInteger m = 1;

	do {
		m <<= 1;
	} while(m < n);

	NSUInteger ret;

	do {
		ret = random() % m;
	} while(ret >= n);

	return ret;
}

@implementation NSMutableArray (Shuffle)

- (void)shuffle {

	for(NSUInteger i = [self count]; i > 1; i--) {
		NSUInteger j = random_below(i);
		[self exchangeObjectAtIndex:i-1 withObjectAtIndex:j];
	}
    
}

@end
