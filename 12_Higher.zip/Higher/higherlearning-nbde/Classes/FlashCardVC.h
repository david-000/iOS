//
//  FlashCardVC.h

#import <UIKit/UIKit.h>
#import "QuestionVC.h"
#import "AnswerVC.h"
#import "LoadingView.h"
#import "RationaleVC.h"
#import "NavigationItemVC.h"


typedef enum {
    
    FlashcardModeStudy = 0,
    FlashcardModeQuiz
    
} FlashcardMode;

@interface FlashCardVC : NavigationItemVC <QuestionVCDelegate, RationaleVCDelegate, UIGestureRecognizerDelegate> {
    
	FlashCard* currentFlashCard;
	QuestionVC* questionVC;
	AnswerVC* answerVC;
	RationaleVC *rationaleVC;
    
	IBOutlet UIView* containView;
	IBOutlet UIButton* btnItemRed;
	IBOutlet UIButton* btnItemYellow;
	IBOutlet UIButton* btnItemGreen;
	IBOutlet UIButton* btnItemSubmit;
    IBOutlet UIView *footerView;
    IBOutlet UIButton *nextButton;
    IBOutlet UIView *rationalePreviewView;
    IBOutlet UILabel *rationalePreviewLabel;
    IBOutlet UIView *quizCompleteView;
    IBOutlet UIButton *retryButton;
    IBOutlet UIButton *quitButton;
    IBOutlet UILabel *quizScoreLabel;
    IBOutlet UILabel *flashcardNumberLabel;
    
    
	NSDate* startTime;
	UIButton* btnBack;
    
    UISwipeGestureRecognizer *leftSwipeGesture;
    UISwipeGestureRecognizer *rightSwipeGesture;
    
    NSMutableArray *flashcardHistory;
    
}

@property(nonatomic, retain) FlashCard* currentFlashCard;
@property(nonatomic, retain) UIView *containView;
@property(nonatomic, retain) UIButton* btnItemRed;
@property(nonatomic, retain) UIButton* btnItemYellow;
@property(nonatomic, retain) UIButton* btnItemGreen;
@property(nonatomic, retain) UIButton* btnItemSubmit;
@property(nonatomic, retain) UIView *footerView;
@property(nonatomic, retain) UIButton *nextButton;
@property(nonatomic, retain) UIView *rationalePreviewView;
@property(nonatomic, retain) UILabel *rationalePreviewLabel;
@property(nonatomic, retain) UIView *quizCompleteView;
@property(nonatomic, retain) UIButton *retryButton;
@property(nonatomic, retain) UIButton *quitButton;
@property(nonatomic, retain) UILabel *quizScoreLabel;
@property(nonatomic, retain) UILabel *flashcardNumberLabel;


- (IBAction)doSubmit:(id) sender;

- (IBAction)doMoveNext:(id) sender;

- (IBAction)onRationalePreviewButton:(id)sender;

- (IBAction)onRetryButton:(id)sender;

- (IBAction)onQuitButton:(id)sender;

- (IBAction)doGreen:(id)sender;

- (IBAction)doYellow:(id)sender;

- (IBAction)doRed:(id)sender;

- (void) setupViews;

- (void) gotoNextQuestion;

- (void) gotoPreviousQuestion;

- (BOOL) getNextCard;

- (void) getPreviousCard;

- (void) flipFooter;

- (void)leftSwiped:(UISwipeGestureRecognizer *)gesture;

- (void)updateViews;

- (void)updateTitle;


@end
