//
//  QuizCategoryVC.m
//  iPhoneProject
//
//  Created by Componica on 9/12/12.
//
//

#import "QuizCategoryVC.h"
#import "Util.h"
#import "CategoryDB.h"
#import "QuizCategoryCell.h"
#import "QuizSelectionVC.h"
#import "GANTracker.h"
#import "Category.h"

@interface QuizCategoryVC ()

@end

@implementation QuizCategoryVC

@synthesize myTableView;

- (id) init {

    NSString *nib = NibName(@"QuizCategoryVC");
    self = [super initWithNibName:nib bundle:nil];
    
    if(self) {
        categories = [[[CategoryDB instance] getRootCategoriesForCategoryType:@"quiz"] retain];
        cells = [[NSMutableArray alloc] init];
    }
    
    return self;
    
}

- (void) dealloc {
    
    myTableView.delegate = nil;
    myTableView.dataSource = nil;
    [myTableView release];
    [categories release];
    [cells release];
    [super dealloc];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Quiz Categories"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
	// Do any additional setup after loading the view.
    for(Category *category in categories) {
        if(category.available) {
            QuizCategoryCell *cell = [[QuizCategoryCell alloc] initWithCategory:category width:myTableView.frame.size.width];
            [cells addObject:cell];
            [cell release];
        }
            
    }
    
}

- (void)viewWillAppear:(BOOL)animated {
 
    [super viewWillAppear:animated];
    for(QuizCategoryCell *cell in cells) {
        [cell highlight:NO];
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
	return [cells count];
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return 1;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	    
    QuizCategoryCell *cell = [cells objectAtIndex:indexPath.row];
    return cell;
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    Category *category = [categories objectAtIndex:indexPath.row];
        
    QuizCategoryCell *cell = [cells objectAtIndex:indexPath.row];
    [cell highlight:YES];
     
    QuizSelectionVC *controller = [[QuizSelectionVC alloc] initWithCategory:category];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
}

#pragma UITableViewDataSource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CategoryCell *cell = [cells objectAtIndex:indexPath.row];
    return cell.bounds.size.height;
    
}

@end
