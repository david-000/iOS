//
//  StudyVC.h
//  iPhoneProject
//
//  Created by MacBook on 6/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuVC.h"

@interface StudyVC : MenuVC
{
    
}

@end
