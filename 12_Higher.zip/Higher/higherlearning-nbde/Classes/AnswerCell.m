//
//  TMTextfieldCell.m
//  MobileWorkforce
//
//  Created by Collin Ruffenach on 10/22/10.
//  Copyright 2010 ELC Tech. All rights reserved.
//

#import "AnswerCell.h"
#import "Util.h"
#import "RoundedRectView.h"
#import "FlashCard.h"

#define kTextHorizontalPadding 15
#define kVerticalPadding 5
#define kOutlineStrokeWidth 6
#define kMinHeightPhone 60
#define kMinHeightPad 90
#define kCornerRadius 20

@interface AnswerCell (Private)

- (void) pressCross:(id)sender;
- (void) pressSelectButton:(id)sender;
- (void) updateViews;

@end

@implementation AnswerCell

@synthesize contentLabel;
@synthesize answer;
@synthesize delegate;

- (id)initWithAnswer:(Answer *)_answer
                width:(CGFloat)width
            delegate:(NSObject<AnswerCellDelegate> *)_delegate
       textAlignment:(UITextAlignment)textAlignment {

	if ((self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil])) {

        self.answer = _answer;
        self.delegate = _delegate;
        self.accessoryType = UITableViewCellAccessoryNone;
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIImage *crossImage = [UIImage imageNamed:@"cross_unsel.png"];

        const CGFloat availableWidth = floor(width - 4 * kTextHorizontalPadding - crossImage.size.width * 0.75);
        
        UIFont *font = [UIFont systemFontOfSize:[Util fontSizeFlashCards]];
        CGSize textSize = [self.answer.text sizeWithFont:font
                                       constrainedToSize:CGSizeMake(availableWidth, NSIntegerMax)
                                           lineBreakMode:UILineBreakModeWordWrap];
        
        CGFloat height = [Util isIPad] ? kMinHeightPad : kMinHeightPhone;
        height = fmax(height, textSize.height + kVerticalPadding * 4);
        
        [self setBackgroundColor:[UIColor clearColor]];
        [self setFrame:CGRectMake(0, 0, width, height)];

        const NSInteger backgroundWidth = width - kTextHorizontalPadding * 2;
        const NSInteger backgroundHeight = height - kVerticalPadding * 2;
        backgroundView = [[RoundedRectView alloc] initWithFrame:CGRectMake(kTextHorizontalPadding, kVerticalPadding, backgroundWidth, backgroundHeight)];
        backgroundView.cornerRadius = kCornerRadius;
        
        selectButton = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
        selectButton.frame = backgroundView.frame;
        [selectButton addTarget:self action:@selector(pressSelectButton:) forControlEvents:UIControlEventTouchUpInside];
        
        crossButton = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
        [crossButton setBackgroundImage:crossImage forState:UIControlStateNormal];
        NSInteger crossButtonX = backgroundView.frame.origin.x + backgroundView.frame.size.width - crossImage.size.width * 0.75;
        NSInteger crossButtonY = backgroundView.frame.origin.y + backgroundView.frame.size.height / 2.0f - crossImage.size.height / 2.0f;
        [crossButton setFrame:CGRectMake(crossButtonX, crossButtonY, crossImage.size.width, crossImage.size.height)];
        [crossButton addTarget:self action:@selector(pressCross:) forControlEvents:UIControlEventTouchUpInside];
        
        NSInteger contentX = backgroundView.frame.origin.x + kTextHorizontalPadding;
        NSInteger contentY = backgroundView.frame.origin.y + kVerticalPadding;
        NSInteger contentWidth = crossButtonX - kTextHorizontalPadding - contentX;
        NSInteger contentHeight = backgroundView.frame.size.height - kVerticalPadding * 2;

        contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(contentX, contentY, contentWidth, contentHeight)];
		[contentLabel setBackgroundColor:[UIColor clearColor]];
		[contentLabel setTextColor:[UIColor blackColor]];
		[contentLabel setFont:font];
		[contentLabel setTextAlignment:textAlignment];
		contentLabel.lineBreakMode = UILineBreakModeWordWrap;
		contentLabel.numberOfLines = 0;
        contentLabel.text = self.answer.text;
        if(textAlignment == UITextAlignmentCenter) {
            contentLabel.center = self.center;
        }
        
        
        UIColor *gray = [UIColor colorWithWhite:0 alpha:1.0];
        grayedOutView = [[RoundedRectView alloc] initWithFrame:CGRectMake(0, 0, backgroundWidth, backgroundHeight)];
        grayedOutView.fillColor = gray;
        grayedOutView.strokeColor = gray;
        grayedOutView.cornerRadius = backgroundView.cornerRadius;
        grayedOutView.center = self.center;
        grayedOutView.hidden = YES;
        
        responseImageView = [[UIImageView alloc] init];
    
        
        [self addSubview:backgroundView];
        [self addSubview:contentLabel];
        [self addSubview:grayedOutView];
        [self addSubview:selectButton];
        [self addSubview:crossButton];
        [self addSubview:responseImageView];
        
        [self updateViews];
    }
	
    return self;
}




- (void)markCell {
        
    [crossButton setHidden:YES];
    [grayedOutView setHidden:YES];
    
    //Add an image to the left side which will either be a checkmark for a correct answer or a red x for an incorrect answer
    UIImage *responseImage = [UIImage imageNamed:ResName(@"yes")];
    
    if (answer.correct) {
        responseImage = [UIImage imageNamed:ResName(@"yes")];
    } else if(answer.selected) {
        responseImage = [UIImage imageNamed:ResName(@"no")];
    } else {
        responseImage = nil;
    }
    
    if(responseImage) {
        //We need to figure out the width of the response image even if it isn't being displayed so we can shift the text over
        NSInteger responseImageWidth = responseImage.size.width;
        
        [responseImageView setImage:responseImage];
        NSInteger responseImageX = backgroundView.frame.origin.x;
        NSInteger responseImageY = backgroundView.center.y - responseImage.size.height / 2.0f;
        [responseImageView setFrame:CGRectMake(responseImageX, responseImageY, responseImage.size.width, responseImage.size.height)];

        //Shift the content label over so it doesn't intersect with the response image
        NSInteger contentX = responseImageX + responseImageWidth + kTextHorizontalPadding;
        NSInteger contentY = backgroundView.frame.origin.y + kVerticalPadding;
        [contentLabel setFrame:CGRectMake(contentX, contentY, contentLabel.bounds.size.width, contentLabel.bounds.size.height)];
    }
        
}



- (void)dealloc {
	
    [backgroundView release];
    [grayedOutView release];
    [contentLabel release];
    [crossButton release];
    [selectButton release];
    [responseImageView release];
    [answer release];
    [super dealloc];
    
}

- (void)select:(BOOL)select {
 
    answer.selected = select;
    if(answer.selected) {
        answer.crossed = NO;
    }
    [self updateViews];
    
}


@end


@implementation AnswerCell (Private)

- (void)updateViews {
    
    [grayedOutView setHidden:!answer.crossed];
    
    if(answer.selected) {
        backgroundView.strokeColor = [UIColor cyanColor];
        backgroundView.strokeWidth = kOutlineStrokeWidth;
        [backgroundView setNeedsDisplay];
    } else {
        backgroundView.strokeColor = [UIColor whiteColor];
        backgroundView.strokeWidth = 1;
        [backgroundView setNeedsDisplay];
    }
    
}

- (void) pressSelectButton:(id)sender {
    
    if([delegate respondsToSelector:@selector(answerCellSelected:)]) {
        [delegate answerCellSelected:self];
    }
    
}


- (void)pressCross:(id)sender
{
    
    answer.crossed = !answer.crossed;
    if(answer.crossed) {
        answer.selected = NO;
    }
    [self updateViews];

}

@end
