//
//  MnemonicVC.h
//  iPhoneProject
//
//  Created by Componica on 10/8/12.
//
//

#import <UIKit/UIKit.h>

@class Mnemonic;

@protocol MnemonicVCDelegate<NSObject>

@required

- (void)dismissMnemonicVC;

@end

@interface MnemonicVC : UIViewController {
 
    NSObject<MnemonicVCDelegate> *delegate;
    Mnemonic *mnemonic;
    IBOutlet UITextView *textView;
    IBOutlet UIButton *closeButton;
    IBOutlet UILabel *titleLabel;
    
}

@property(nonatomic, assign) NSObject<MnemonicVCDelegate> *delegate;
@property(nonatomic, retain) UITextView *textView;
@property(nonatomic, retain) UIButton *closeButton;
@property(nonatomic, retain) UILabel *titleLabel;

- (IBAction)onCloseButton:(id)sender;

- (id)initWithDelegate:(NSObject<MnemonicVCDelegate> *)delegate
              mnemonic:(Mnemonic *)mnemonic;

@end
