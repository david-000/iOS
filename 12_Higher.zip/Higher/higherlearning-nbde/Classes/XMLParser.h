//
//  XMLParser.h
//  iPhoneProject
//
//  Created by MacBook on 7/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DDXML.h"
#import "FlashCard.h"

@interface XMLParser : NSObject
{
    NSMutableArray *flashCardArray;
    
}
- (void)parseXML:(NSString *)filePath;
- (void)copyFileToDocuments:(NSString *)fileName;

- (void)parseFlashCard:(DDXMLElement*)element;
- (void)parseTermCard:(DDXMLElement*)element;
- (void)parseImage:(DDXMLElement*)element;
- (void)parseMnemocis:(DDXMLElement*)element;

- (void)dumpDatabase;

@end
