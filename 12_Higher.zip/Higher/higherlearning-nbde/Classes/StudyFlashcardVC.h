//
//  StudyFlashcardVC.h
//  iPhoneProject
//
//  Created by Componica on 9/13/12.
//
//

#import <UIKit/UIKit.h>
#import "FlashCardVC.h"

@interface StudyFlashcardVC : FlashCardVC {
    
    NSMutableArray *unansweredFlashcardIds;
    NSMutableArray *redFlashcardIds;
    NSMutableArray *yellowFlashcardIds;
    NSMutableArray *greenFlashcardIds;
     
    int redFrequency;
    int yellowFrequency;
    int greenFrequency;
    
}

- (id)init;

- (IBAction) doRed:(id) sender;
- (IBAction) doYellow:(id) sender;
- (IBAction) doGreen:(id) sender;

- (void)loadFlashcards;
- (void)getCardFromBankType:(NSString *)flashcardStatusName;
- (void)checkForAchievements;

@end
