//
//  LoadingView.m


#import "LoadingView.h"

static LoadingView *__loadingViewInstance;
@implementation LoadingView

+ (LoadingView *)defaultLoadingView {
    if(__loadingViewInstance == nil) {
        @synchronized(self) {
            if(__loadingViewInstance == nil)
                __loadingViewInstance = [[self alloc] initWithActivityIndicatorTitle:NSLocalizedString(@"Loading...", nil)];
        }
    }
    return __loadingViewInstance;
}

- (id)initWithActivityIndicator:(NSString *)title
                        message:(NSString *)message
                       delegate:(id)delegate
              cancelButtonTitle:(NSString *)cancelButtonTitle 
              otherButtonTitles:(NSString *)otherButtonTitles {	
	if ((self = [super initWithTitle:title message:message delegate:delegate cancelButtonTitle:cancelButtonTitle otherButtonTitles:otherButtonTitles,nil])) {
        UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
        if(message != nil && ![message isEqualToString:@" "]) {
            indicator.frame = CGRectMake(139.0f - 10.0f, 120.0f, indicator.frame.size.width, indicator.frame.size.height);
        }else if([message isEqualToString:@" "]) {
            indicator.frame = CGRectMake(139.0f - 10.0f, 50.0f, indicator.frame.size.width, indicator.frame.size.height);
        }
        else {            
            indicator.frame = CGRectMake(139.0f - 10.0f, 50.0f, indicator.frame.size.width, indicator.frame.size.height);
        }
        [self addSubview:indicator];
        [indicator startAnimating];
        [indicator release];
	}
	return self;
}
- (id)initWithActivityIndicatorTitle:(NSString *)title {
    return [self initWithActivityIndicator:title message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:nil];
}
- (id)initWithProgressViewTitle:(NSString *)title message:(NSString *)message {
    self = [super initWithTitle:title message:message delegate:nil cancelButtonTitle:nil otherButtonTitles:nil];
    
    
    if(self) {
        isProgress = YES;
        progressFormatter = [[NSNumberFormatter alloc] init];
        [progressFormatter setNumberStyle:NSNumberFormatterPercentStyle];
        
        progressView = [[UIProgressView alloc] initWithProgressViewStyle:UIProgressViewStyleDefault];
        progressLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200.0f, 18)];
        progressLabel.textAlignment = NSTextAlignmentCenter;
        progressLabel.text = @"0%";
        progressLabel.backgroundColor = [UIColor clearColor];
        progressLabel.textColor = [UIColor whiteColor];
        progressLabel.font = [UIFont systemFontOfSize:13.0f];
        CGRect frame = progressView.frame;
        CGRect labelFrame = progressLabel.frame;
        frame.size.width = 200.0f;
        
        if(message != nil) {
            frame = CGRectMake((284.0f - frame.size.width)/2.0f, 120.0f, frame.size.width, frame.size.height);
            labelFrame = CGRectMake((284.0f - labelFrame.size.width)/2.0f, 120.0f, labelFrame.size.width, labelFrame.size.height);
        } else {            
            frame = CGRectMake((284.0f - frame.size.width)/2.0f, 50.0f, frame.size.width, frame.size.height);
            labelFrame = CGRectMake((284.0f - labelFrame.size.width)/2.0f, 50.0f, labelFrame.size.width, labelFrame.size.height);
        }
        progressLabel.frame = labelFrame;
        progressView.frame = frame;
        [self addSubview:progressView];
        [self addSubview:progressLabel];        
    }
    return self;
}
- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    if(isProgress) {
        CGRect frame = progressView.frame;
        frame.origin.y = rect.size.height - frame.size.height - 20.0f;
        
        CGRect labelFrame = progressLabel.frame;
        labelFrame.origin.y = frame.origin.y - labelFrame.size.height - 5.0f;
        progressView.frame = frame;
        progressLabel.frame = labelFrame;
    }
}
- (oneway void)release {
    if(self == __loadingViewInstance) return;
    
    [super release];
}
- (void)dealloc {
    [progressView release];
    progressView = nil;
    [progressLabel release];
    progressLabel = nil;
    [progressFormatter release];
    progressFormatter = nil;
    [super dealloc];
}
- (void)close {
	[self dismissWithClickedButtonIndex:0 animated:YES];
}

- (void)updateProgress:(float)progress {
    if(isProgress) {
        if(progressView != nil) {
            progressView.progress = progress;
            NSString *progressText = [progressFormatter stringFromNumber:[NSNumber numberWithFloat:progress]];
            progressLabel.text = progressText;
            [self setNeedsDisplay];
        }
    }
}

@end
