//
//  QuizSelectionCell.h
//  iPhoneProject
//
//  Created by Componica on 9/13/12.
//
//

#import <UIKit/UIKit.h>

@class RoundedRectView;
@class Category;

@interface QuizSelectionCell : UITableViewCell {
    
    RoundedRectView *backgroundView;
    UILabel *scoreLabel;
    UILabel *percentageLabel;
    UILabel *titleLabel;
    Category *category;
    
}

@property(nonatomic, retain) Category *category;

- (id)initWithCategory:(Category *)category
                 width:(CGFloat)width
            percentage:(float)percentage
             completed:(BOOL)completed;

- (void) highlight:(BOOL)highlight;

- (void) setPercentage:(CGFloat)percentage
             completed:(BOOL)completed;

@end
