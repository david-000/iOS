
#import <Foundation/Foundation.h>

@interface NSMutableArray (Shuffle)

- (void)shuffle;

@end
