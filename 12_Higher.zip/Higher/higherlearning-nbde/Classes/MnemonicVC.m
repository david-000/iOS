//
//  MnemonicVC.m
//  iPhoneProject
//
//  Created by Componica on 10/8/12.
//
//

#import "MnemonicVC.h"
#import "Util.h"
#import "Mnemonic.h"

@interface MnemonicVC ()

@end

@implementation MnemonicVC

@synthesize delegate;
@synthesize textView;
@synthesize closeButton;
@synthesize titleLabel;


- (id)initWithDelegate:(NSObject<MnemonicVCDelegate> *)delegate_
              mnemonic:(Mnemonic *)mnemonic_ {

    NSString *nib = NibName(@"MnemonicVC");
    self = [super initWithNibName:nib bundle:nil];
    if(self) {
        self.delegate = delegate_;
        mnemonic = [mnemonic_ retain];
    }
    
    
    return self;
    
}

- (void) dealloc {
 
    [textView release];
    [closeButton release];
    [titleLabel release];
    [mnemonic release];
    [super dealloc];
    
} 

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    textView.text = mnemonic.text;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onCloseButton:(id)sender {
    
    [delegate dismissMnemonicVC];
    
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

@end
