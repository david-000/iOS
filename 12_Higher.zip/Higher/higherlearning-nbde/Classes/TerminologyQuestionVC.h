//
//  TerminologyQuestionVC.h
//  iPhoneProject
//
//  Created by Componica on 10/1/12.
//
//

#import "QuestionVC.h"

@interface TerminologyQuestionVC : QuestionVC {

    NSInteger headerHeight;
    
}

@end
