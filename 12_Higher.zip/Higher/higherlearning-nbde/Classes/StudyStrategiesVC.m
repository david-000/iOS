//
//  StudyStrategiesVC.m
//  iPhoneProject
//
//  Created by MacBook on 7/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "StudyStrategiesVC.h"
#import "Util.h"
#import "GANTracker.h"

@implementation StudyStrategiesVC

@synthesize webView;

-(void)dealloc{
    [webView release];
    
    [super dealloc];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id) init {
 
    NSString *nib = NibName(@"StudyStrategiesVC");
    self = [super initWithNibName:nib bundle:nil];
    if(self) {
        
    }
    
    return self;
    
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSString *strContent = @"<U><B>Prioritize important content</B></U><BR>\
    -Not all content is created equal. The boards exams place a higher importance on anything head, neck and dental related material. With this in mind, don’t get caught up studying arm anatomy when there will probably just be a few questions on it. We are releasing a more comprehensive “high yield content” section soon to help maximize your study time.<BR>\
    <BR>\
    <U><B>Use retention techniques</B></U><BR>\
    -Use mnemonics to help memorize and retrieve large amounts of information. These techniques can be rhymes, phrases, acronyms etc. It helps the brain be efficient in grouping and condensing large amount of information into a smaller size.  Studying with mnemonics allow higher retention, better retrieval of important content, and reduce test anxiety.<BR>\
    <BR>\
    <U><B>Set specific goals</B></U><BR>\
    -Make a planned study guide with measurable, specific goals. Then, stick to a daily routine using the study goals for the day and week. It will allow you to monitor your time and stay on task. Additionally, it is less daunting and more encouraging when you cross off small goals from your list as you go, rather than facing it all at once.<BR>\
    <BR>\
    Example: \"I’ll go through this entire DBM app, then read some class notes, then take an ASDA practice test to check my progress. If I score above 75% I will know I only have to study a bit more. If not, I will keep studying until I get to at least 75%.\"<BR>\
    <BR>\
    <U><B>Planning helps stop procrastination</B></U><BR>\
    -With boards, it's easy to get overwhelmed by the enormity of the task ahead of you. One of the main reasons for procrastination is not having a clear idea of where to start or what to do next. To avoid this trap, we suggest you figure out what steps you need to take from the beginning.<BR>\
    <BR>\
    -Specifically, make a list of the major goals you need to accomplish.  Then, divide these goals into smaller, specific steps that will help you complete the larger tasks.  This individualized plan with measurable daily goals will help staying on task. It makes sure you are clear on where you are starting and ending your studying for that day.<BR>\
    <BR>\
    <U><B>Know your own strengths and weaknesses</B></U><BR>\
    -A good way to start studying for NBDE is to identify which subjects you know well and those areas that are your weakness.  It is highly recommended to take the practice board exam as a means to identify your areas of relative strength and weakness. Then, tackle the DBM flashcards for the the content areas that are more difficult for you. This approach sounds obvious but many people only like to study what they are good at.<BR>\
    <BR>\
    Nevertheless, it is ok to say: I don’t like studying biochemistry and I would rather focus on things like dental anatomy.  In being flexible and allowing yourself to study relatively easier topic can help you maintain sanity. You may gain confidence and motivation to tackle the harder subjects next.  This flexible approach could prove to be an important factor in preparing for the NBDE. Just make sure you have at least an adequate understanding of all categories.<BR>\
    <BR>\
    <U><B>Distracted studying is better than no studying</B></U><BR>\
    -When you have a few minutes on the go (riding the bus, waiting in line, during commercials) go over the DBM flashcards on the material that you already have a strong level of comprehension. This allows for a quick refresher that won’t require you to devote all of your attention.<BR>\
    <BR>\
    <U><B>Keep your mind and body healthy</B></U><BR>\
    -Get plenty of sleep, exercise regularly, eat a balanced diet, and drink plenty of water. It may be tough to find time to exercise but it really does help.  Various relaxing chemicals such as endorphins and enkephelins are released into the bloodstream when exercising.  You'll have higher retention of study material when in a relaxed state after exercising.  Exercise has many more positive benefits shown through studies such as increasing blood flow to the brain.<BR>\
    <BR>\
    <U><B>Keep your thoughts healthy</B></U><BR>\
    -Think and visualize success.   Try to avoid catastrophic thinking and a negative attitude towards the study material. Positive thinking and optimism can have a profound impact on your motivation and performance.<BR>\
    <BR>\
    <U><B>Know what to expect</B></U><BR>\
    -In order to study efficiently for the NBDE you need to know how in depth the questions are, what the scope of the test is, and how well you know the information already. Looking at old tests is the best way to understand these things. We recommend you review old board exams when you first start preparing and then again a week or so before boards. Try to take a full or half length practice test at some point.<BR>\
    <BR>\
    <U><B>Study information in groups</B></U><BR>\
    -Cluster information into groups of important concepts. It's easier to learn more about one topic at a time than to throw it all at yourself at once. This way you can connect similar concepts. For example, in dental anatomy if you are learning about the height of contour, try to study where height of contour appears for all teeth, not just for the individual tooth you are looking at.<BR>\
    <BR>\
    <U><B>Using visual or auditory cues</B></U><BR>\
    -For visual learners, draw or write concepts multiple times to help with memorization. Keep a notebook next to you as you use this app and write down quick notes to review. If you are an auditory learner, try saying the material out loud a couple times to reinforce the connections in your brain.  For combined learning style, use both visual and auditory prompts to aid recall and retention.<BR>\
    <BR>\
    <U><B>Stay organized</B></U><BR>\
    -Stay organized: Know what topics you have covered and what topics are your strengths and weaknesses. The worst mistake you can make is diving headfirst into the NBDE without an organized approach.<BR>\
    <BR>\
    <U><B>Avoid distractions at all cost</B></U><BR>\
    -Remove all distractions. Your brain works much better if it is focused on one thing. Every time you check facebook, look at your phone or have other interruptions it takes you out of deep thought. Then you have to spend 5-10 mins to get back in to that mindset.<BR>\
    <BR>\
    <U><B>Optimize your study environment</B></U><BR>\
    -Find a quiet, comfortable place with good lighting and few distractions.<BR>\
    <BR>\
    <U><B>Visualization to facilitate learning</B></U><BR>\
    -Visualize the concept as you are studying it. Visualization improves recall tremendously. Words are only symbols. Some people try to memorize the words. You should focus on the objects they describe and visualize such image. Such techniques enhance storage and retrieval of study material.<BR>\
    <BR>\
    <U><B>Take short breaks and you will learn more</B></U><BR>\
    -Take multiple short breaks during long study sessions. Your brain remembers more information at beginning and end of a study session. The material in the middle is less accessible so taking breaks enhances recall.  Also, move around or exercise briefly during a study break. It helps to get blood flowing, increases release of relaxing chemicals, and recharges your body. You will learn more material and be focused for the next study session.";
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
        strContent = [NSString stringWithFormat:@"<font size=\"5\" color=\"white\">%@", strContent];
    }
    else
        strContent = [NSString stringWithFormat:@"<font color=\"white\">%@", strContent];
    
    [webView loadHTMLString:strContent baseURL:nil];
}

- (void)viewDidAppear:(BOOL)animated {
 
    [super viewDidAppear:animated];
    
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Study Strategies"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}
@end
