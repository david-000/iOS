//
//  AboutVC.m
//  iPhoneProject
//
//  Created by Componica on 8/28/12.
//
//

#import "AboutVC.h"
#import "Util.h"
#import "Util.h"
#import "MnemonicMenuVC.h"
#import "ExamStrategiesVC.h"
#import "StudyStrategiesVC.h"
#import "ScienceVC.h"
#import "GuaranteeVC.h"
#import "AcknowledgementsVC.h"
#import "iPhoneProjectAppDelegate.h"
#import "GANTracker.h"

static NSString * kAppId = @"374888099244448";


@implementation AboutVC

@synthesize scienceButton;
@synthesize guaranteeButton;
@synthesize acknowledgementsButton;
@synthesize rateButton;
@synthesize wantShare;
@synthesize feedbackButton;


- (id) init {
 
    NSString *nib = NibName(@"AboutVC");
    self = [super initWithNibName:nib bundle:nil];
    if(self) {
        
    }
    
    return self;
}

- (void)dealloc {
 
    [scienceButton release];
    [guaranteeButton release];
    [acknowledgementsButton release];
    [rateButton release];
    [feedbackButton release];
    [super dealloc];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [scienceButton.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [scienceButton.titleLabel setTextColor:[UIColor darkGrayColor]];

    [guaranteeButton.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [guaranteeButton.titleLabel setTextColor:[UIColor darkGrayColor]];
    
    [acknowledgementsButton.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [acknowledgementsButton.titleLabel setTextColor:[UIColor darkGrayColor]];
    
    [rateButton.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [rateButton.titleLabel setTextColor:[UIColor darkGrayColor]];
    
    [feedbackButton.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [feedbackButton.titleLabel setTextColor:[UIColor darkGrayColor]];
    
}

- (void)viewDidAppear:(BOOL)animated {
 
    [super viewDidAppear:animated];
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"About Us"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
#pragma mark - Orientation
- (NSUInteger)supportedInterfaceOrientations
{
    return (UIInterfaceOrientationMaskPortrait);
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

- (BOOL)shouldAutorotate {
    return NO;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
#pragma mark - User Interaction Methods.



- (IBAction)onScienceButton:(id)sender {
 
    ScienceVC* controller = [[ScienceVC alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

- (IBAction)onGuaranteeButton:(id)sender {
    
    GuaranteeVC *controller = [[GuaranteeVC alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

- (IBAction)onAcknowledgementsButton:(id)sender {
    
    AcknowledgementsVC *controller = [[AcknowledgementsVC alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

- (IBAction)onRateButton:(id)sender {
    
    NSURL *url = [Util fullVersionURL];
    [[UIApplication sharedApplication] openURL:url];
    
}

- (IBAction)onShareButton:(id)sender {
    
    [self setWantShare:NO];
    if ([self checkFBValidity]) {
        [self logoutFacebook];
    }else {
        [self goFBShare];
    }
    
}

- (IBAction)onFeedbackButton:(id)sender {
    MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
    picker.mailComposeDelegate = self;
    picker.wantsFullScreenLayout = YES;
    
    [picker setSubject:@"Please give me your feedback"];
    NSArray *toRecipients = [NSArray arrayWithObject:@"info@hltcorp.com"];
    [picker setToRecipients:toRecipients];
    
    NSMutableString * htmlstring = [[[NSMutableString alloc] init] autorelease];
    [htmlstring appendString:@"<html><body>"];
    [htmlstring appendString:@"Please give me your feedback<br>"];
    [htmlstring appendString:@"</body></html>"];
    
    [picker setMessageBody:htmlstring isHTML:YES];
    
    [self presentModalViewController:picker animated:YES];
    [picker release];
}

#pragma FBShare

- (BOOL)checkFBValidity {
    // Check and retrieve authorization information
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"] && [defaults objectForKey:@"FBExpirationDateKey"]) {
        return YES;
    }
    return NO;
}

-(void)logoutFacebook {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:@"FBAccessTokenKey"];
    [defaults removeObjectForKey:@"FBExpirationDateKey"];
    [defaults synchronize];
    
    //iPhoneProjectAppDelegate *idelegate = (iPhoneProjectAppDelegate *)[[UIApplication sharedApplication] delegate];
        
    [self setWantShare:NO];
}

- (void)shareONFB
{
    /*
    iPhoneProjectAppDelegate *idelegate = (iPhoneProjectAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    SBJSON *jsonWriter = [[SBJSON new] autorelease];
    
    // The action links to be shown with the post in the feed
    NSArray* actionLinks = [NSArray arrayWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:
                                                      @"NBDE Mastery",@"name",
                                                      @"http://itunes.apple.com/app/id380886386?mt=8",@"link", nil], nil];
    NSString *actionLinksStr = [jsonWriter stringWithObject:actionLinks];
    // Dialog parameters
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   @"NBDE Mastery - iOS Application", @"name",
                                   @"NBDE Mastery for iOS.", @"caption",
                                   @"Traditional textbook learning is highly inefficient because it treats information as all roughly equal.", @"description",
                                   @"http://itunes.apple.com/app/id380886386?mt=8", @"link",
                                   //@"http://www.facebookmobileweb.com/hackbook/img/facebook_icon_large.png", @"picture",
                                   actionLinksStr, @"actions",
                                   nil];
    
    
    [[idelegate facebook] dialog:@"feed"
                       andParams:params
                     andDelegate:self];
    */
}

- (void)goFBShare
{
    iPhoneProjectAppDelegate *idelegate = (iPhoneProjectAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    if (idelegate.facebook == NULL) {
        // Initialize Facebook
        idelegate.facebook = [[Facebook alloc] initWithAppId:kAppId andDelegate:self];
    }
    else {
        idelegate.facebook.sessionDelegate = self;
    }
    
    
    
    // Check and retrieve authorization information
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"] && [defaults objectForKey:@"FBExpirationDateKey"]) {
        [idelegate facebook].accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
        [idelegate facebook].expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
    }
    
    NSArray *permissions = [[NSArray alloc] initWithObjects:
                            @"offline_access",
                            @"photo_upload",
                            @"publish_stream",
                            @"friends_about_me",
                            @"friends_likes",
                            @"email", nil];
    
    if (![[idelegate facebook] isSessionValid]) {
        [[idelegate facebook] authorize:permissions];
    }
    else {
        //ALREADY LOGIN
        if ([self wantShare]) {
            [self shareONFB];
        }
    }
    
    [permissions release];
    
}



/**
 * Called when the user has logged in successfully.
 */
- (void)fbDidLogin {
    
    iPhoneProjectAppDelegate *idelegate = (iPhoneProjectAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NSLog(@"\n<><><>fbDidLogin : fbAccessToken: %@",[[idelegate facebook] accessToken]);
    
    [self storeAuthData:[[idelegate facebook] accessToken] expiresAt:[[idelegate facebook] expirationDate]];
    if ([self wantShare]) {
        [self shareONFB];
    }
    
}

-(void)fbDidExtendToken:(NSString *)accessToken expiresAt:(NSDate *)expiresAt {
    
}

/**
 * Called when the user canceled the authorization dialog.
 */
-(void)fbDidNotLogin:(BOOL)cancelled {
    //[pendingApiCallsController userDidNotGrantPermission];
    
    if(cancelled){
    }
}

/**
 * Called when the request logout has succeeded.
 */
- (void)fbDidLogout {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:@"FBAccessTokenKey"];
    [defaults removeObjectForKey:@"FBExpirationDateKey"];
    [defaults synchronize];
}

/**
 * Called when the session has expired.
 */
- (void)fbSessionInvalidated {
    UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:@"Auth Exception"
                              message:@"Your session has expired."
                              delegate:nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil,
                              nil];
    [alertView show];
    [alertView release];
    
    [self fbDidLogout];
}

- (void)storeAuthData:(NSString *)accessToken expiresAt:(NSDate *)expiresAt {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:accessToken forKey:@"FBAccessTokenKey"];
    [defaults setObject:expiresAt forKey:@"FBExpirationDateKey"];
    [defaults synchronize];
}

#pragma mark MailComposerDelegate
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
        {
            break;
        }
            
        case MFMailComposeResultSaved:
        {
            UIAlertView *stop = [[UIAlertView alloc] initWithTitle:@"" message:@"Mail saved." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [stop show];
            [stop release];
            break;
        }
            
        case MFMailComposeResultSent:
        {
            UIAlertView *stop = [[UIAlertView alloc] initWithTitle:@"" message:@"Mail sent." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [stop show];
            [stop release];
            break;
        }
            
        case MFMailComposeResultFailed:
        {
            UIAlertView *stop = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Mail send failed." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [stop show];
            [stop release];
            break;
        }
            
        default:
        {
            UIAlertView *stop = [[UIAlertView alloc] initWithTitle:@"" message:@"Mail not sent." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [stop show];
            [stop release];
            break;
        }
    }
    
    [self dismissModalViewControllerAnimated:YES];
}
@end
