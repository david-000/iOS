//
//  MenuVC.h
//  iPhoneProject
//
//  Created by Componica on 9/20/12.
//
//

#import <UIKit/UIKit.h>
#import "NavigationItemVC.h"

@interface MenuVC : NavigationItemVC <UITableViewDataSource, UITableViewDelegate> {
 
    IBOutlet UITableView *myTableView;
    NSMutableArray *cells;
    
}

@property(nonatomic, retain) UITableView *myTableView;

- (UITableViewCell *)createCellWithTitle:(NSString *)title
                                selector:(SEL)selector;

- (UITableViewCell *)createCellWithTitleandRect:(NSString *)title rect:(CGRect)rect
                                       selector:(SEL)selector;
- (UITableViewCell *)createCellWithImage:(NSString *)normalName highlight:(NSString *)highlightName rect:(CGRect)rect
                                selector:(SEL)selector;
@end
