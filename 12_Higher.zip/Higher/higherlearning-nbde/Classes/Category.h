//
//  Category.h
//  iPhoneProject
//
//  Created by Componica on 9/10/12.
//
//

#import <UIKit/UIKit.h>

@interface Category : NSObject<NSCopying> {
    
	NSInteger categoryID;
    NSInteger parentCategoryId;
	NSString* categoryName;
    NSInteger numberOfUnansweredFlashcards;
    NSInteger numberOfIncorrectFlashcards;
    NSInteger numberOfCorrectFlashcards;
    NSInteger numberOfRedFlashcards;
    NSInteger numberOfYellowFlashcards;
    NSInteger numberOfGreenFlashcards;
    NSMutableArray *subcategories;
    BOOL enabled;
    BOOL available;
    NSInteger categoryTypeId;
    NSString *categoryTypeName;
    BOOL enabledByDefault;
    
}

@property(nonatomic, assign) NSInteger categoryID;
@property(nonatomic, assign) NSInteger parentCategoryId;
@property(nonatomic, retain) NSString* categoryName;
@property(nonatomic, assign) NSInteger numberOfUnansweredFlashcards;
@property(nonatomic, assign) NSInteger numberOfIncorrectFlashcards;
@property(nonatomic, assign) NSInteger numberOfCorrectFlashcards;
@property(nonatomic, assign) NSInteger numberOfRedFlashcards;
@property(nonatomic, assign) NSInteger numberOfYellowFlashcards;
@property(nonatomic, assign) NSInteger numberOfGreenFlashcards;
@property(nonatomic, retain) NSMutableArray *subcategories;
@property(nonatomic, assign) BOOL enabled;
@property(nonatomic, assign) BOOL available;
@property(nonatomic, assign) NSInteger categoryTypeId;
@property(nonatomic, retain) NSString *categoryTypeName;
@property(nonatomic, assign) BOOL enabledByDefault;


- (id) initWithCategoryID:(NSInteger)_categoryID
         parentCategoryID:(NSInteger)_parentCategoryID
             categoryName:(const char *)_categoryName
                  enabled:(BOOL)_enabled
                available:(BOOL)_available
           categoryTypeId:(NSInteger)_categoryTypeId
         categoryTypeName:(const char *)_categoryTypeName
         enabledByDefault:(BOOL)_enabledByDefault;

@end