//
//  TerminologyAnswerVC.m
//  iPhoneProject
//
//  Created by Componica on 10/1/12.
//
//

#import "TerminologyAnswerVC.h"
#import "AnswerCell.h"

@interface TerminologyAnswerVC ()

@end

@implementation TerminologyAnswerVC

- (void) initComponentsWithFlashCard:(FlashCard*)card {
    
	self.flashCard = card;
    
    //Initialize the tableview cells
    [cells removeAllObjects];
    
    NSMutableArray *answerCells = [NSMutableArray array];
    for(Answer *answer in self.flashCard.answers) {
        AnswerCell *answerCell = [[AnswerCell alloc] initWithAnswer:answer
                                                              width:myTableView.bounds.size.width
                                                           delegate:nil
                                                      textAlignment:NSTextAlignmentCenter];
        answerCell.userInteractionEnabled = NO;
        [answerCell markCell];
        [answerCells addObject:answerCell];
        [answerCell release];
        headerHeight = (myTableView.frame.size.height - answerCell.frame.size.height) / 2.0f;
    }
    
    [cells addObject:answerCells];
    
    myTableView.backgroundColor = [UIColor clearColor];
    myTableView.backgroundView = nil;
    [myTableView scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:NO];
    [myTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [myTableView reloadData];
    
}

- (UIView *)tableView:(UITableView *)tv viewForHeaderInSection:(NSInteger)section{
	
    return nil;
    
}

-(CGFloat)tableView:(UITableView *)tv heightForHeaderInSection:(NSInteger)section{
    
    return headerHeight;
    
}

@end
