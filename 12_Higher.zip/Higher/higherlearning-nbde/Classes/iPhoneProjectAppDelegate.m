//
//  iPhoneProjectAppDelegate.m


#import "iPhoneProjectAppDelegate.h"
#import "Util.h"
#import "Global.h"
#import "Tools.h"
#import "Database.h"
#import "TestFlight.h"
#import "RootVC.h"
#import "GANTracker.h"
#import "AchievementManager.h"
#import "FlashCardsDB.h"

@implementation iPhoneProjectAppDelegate

@synthesize window;
@synthesize facebook;


#pragma mark -
#pragma mark Application lifecycle 

- (NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window {
 
    return UIInterfaceOrientationMaskPortrait;
    
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
	//option for app
    
    //Sleep to show the splash screen
    sleep(1);
    
    [TestFlight takeOff:@"89819727608fd4a508458b2191371a7a_MTMyMzA4MjAxMi0wOS0xNCAxMzoyNTo0Ny45OTg3NDQ"];
    
    NSLog(@"Launching google analytics");
    [[GANTracker sharedTracker] startTrackerWithAccountID:@"UA-35132766-1"
                                           dispatchPeriod:10
                                                 delegate:nil];
    
    NSError *error = nil;    
    if(![[GANTracker sharedTracker] trackPageview:@"/app_entry_point"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
    //Establish a database connection. This MUST be done before making any queries!
    [[DatabaseConnection instance] connect];
    
    homeVC = [[HomeVC alloc] init];
    
    rootVC = [[RootVC alloc] initWithRootViewController:homeVC];
    self.window.rootViewController = rootVC;
    
    [self.window makeKeyAndVisible];
    
    
    NSString * kAppId = @"374888099244448";
    
    // Now check that the URL scheme fb[app_id]://authorize is in the .plist and can
    // be opened, doing a simple check without local app id factored in here
    NSString *url = [NSString stringWithFormat:@"fb%@://authorize",kAppId];
    BOOL bSchemeInPlist = NO; // find out if the sceme is in the plist file.
    NSArray* aBundleURLTypes = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleURLTypes"];
    if ([aBundleURLTypes isKindOfClass:[NSArray class]] &&
        ([aBundleURLTypes count] > 0)) {
        NSDictionary* aBundleURLTypes0 = [aBundleURLTypes objectAtIndex:0];
        if ([aBundleURLTypes0 isKindOfClass:[NSDictionary class]]) {
            NSArray* aBundleURLSchemes = [aBundleURLTypes0 objectForKey:@"CFBundleURLSchemes"];
            if ([aBundleURLSchemes isKindOfClass:[NSArray class]] &&
                ([aBundleURLSchemes count] > 0)) {
                NSString *scheme = [aBundleURLSchemes objectAtIndex:0];
                if ([scheme isKindOfClass:[NSString class]] &&
                    [url hasPrefix:scheme]) {
                    bSchemeInPlist = YES;
                }
            }
        }
    }

#warning TODO: This is just for testing!
    [[FlashCardsDB instance] checkImages];

 
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    [[DatabaseConnection instance] disconnect];
}

- (void)applicationDidEnterBackground:(UIApplication *)application {

}

- (void)applicationWillEnterForeground:(UIApplication *)application {

}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    
    if(![[DatabaseConnection instance] connect]) {
        NSLog(@"Unable to connect to database!");
    }

}

- (void)applicationWillTerminate:(UIApplication *)application {
    NSLog(@"applicationWillTerminate");
}


- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    return [self.facebook handleOpenURL:url];
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    return [self.facebook handleOpenURL:url];
}

#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
}


- (void)dealloc {
    
    [facebook release];
	[homeVC release];
    [rootVC release];
    [window release];
    [[GANTracker sharedTracker] stopTracker];
    [super dealloc];
    
}


@end
