//
//  TerminologyAnswerVC.h
//  iPhoneProject
//
//  Created by Componica on 10/1/12.
//
//

#import "AnswerVC.h"

@interface TerminologyAnswerVC : AnswerVC {
 
    NSInteger headerHeight;
    
}

@end
