//
//  HelpFlashcard.h
//  NBDE
//
//  Created by Yao Ming on 2/7/13.
//
//

#import <UIKit/UIKit.h>

@interface HelpFlashcard : UIViewController

@property (nonatomic, retain) IBOutlet UIButton *btnBottom;
@property (nonatomic, retain) IBOutlet UIScrollView *scrollView;

-(IBAction)clickBottomButton:(id)sender;
-(IBAction)clickBackButton:(id)sender;

@end

