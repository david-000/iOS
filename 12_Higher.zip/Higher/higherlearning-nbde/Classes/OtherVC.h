//
//  OtherVC.h

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>

#import "FBConnect.h"



@interface OtherVC : UIViewController 
<MFMailComposeViewControllerDelegate, 
FBRequestDelegate,
FBDialogDelegate,
FBSessionDelegate>
{
    IBOutlet UITableView* myTableView;
	UIButton* btnBack;
    
    BOOL wantShare;
}
@property (nonatomic, assign) BOOL wantShare;

- (void) initViewComponents;
- (void) sendMailUs;

- (IBAction)doGoBack:(id)sender;

- (void) updatePortraitUI;
- (void) updateLandscapeUI;

- (void)goFBShare;
- (void)storeAuthData:(NSString *)accessToken expiresAt:(NSDate *)expiresAt;
- (void)shareONFB;
- (BOOL)checkFBValidity;
- (void)logoutFacebook;

@end
