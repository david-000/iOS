//
//  Mnemonic.m
//  iPhoneProject
//
//  Created by Patrick Kellen on 9/11/12.
//
//

#import "Mnemonic.h"

@implementation Mnemonic

@synthesize mnemonicID;
@synthesize text;
@synthesize mnemonicTypeID;
@synthesize mnemonicTypeName;
@synthesize title;
@synthesize saved;
@synthesize mnemonicNumber;

- (id)initWithMnemonicID:(NSInteger)_mnemonicID
                    text:(const char *)_text
          mnemonicTypeID:(NSInteger)_mnemonicTypeID
        mnemonicTypeName:(const char *)_mnemonicTypeName
                   title:(const char *)_title
                   saved:(BOOL)_saved
          mnemonicNumber:(NSInteger)_mnemonicNumber {
 
    self = [super init];
    if(self) {
        
        self.mnemonicID = _mnemonicID;
        self.text = _text ? [NSString stringWithUTF8String:_text] : nil;
        self.mnemonicTypeID = _mnemonicTypeID;
        self.mnemonicTypeName = _mnemonicTypeName ? [NSString stringWithUTF8String:_mnemonicTypeName] : nil;
        self.title = _title ? [NSString stringWithUTF8String:_title] : nil;
        self.saved = _saved;
        self.mnemonicNumber = _mnemonicNumber;
        
    }
    
    return self;
    
}

- (void) dealloc{
    
	[text release];
    [mnemonicTypeName release];
    [title release];
	[super dealloc];
    
}

- (id)copyWithZone:(NSZone *)zone {
 
    Mnemonic *mnemonic = [[Mnemonic alloc] init];
    mnemonic.mnemonicID = mnemonicID;
    mnemonic.text = [text copy];
    [mnemonic.text release];
    mnemonic.mnemonicTypeID = mnemonicTypeID;
    mnemonic.mnemonicTypeName = [mnemonicTypeName copy];
    [mnemonic.mnemonicTypeName release];
    mnemonic.title = [title copy];
    [mnemonic.title release];
    mnemonic.saved = saved;
    
    return mnemonic;
    
}

@end