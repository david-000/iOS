//
//  QuizFlashcardVC.h
//  iPhoneProject
//
//  Created by Componica on 9/13/12.
//
//

#import <UIKit/UIKit.h>
#import "FlashCardVC.h"

@class Category;

@interface QuizFlashcardVC : FlashCardVC {

    NSMutableArray *flashcards;
    NSInteger currentFlashcardIndex;
    Category *category;
    
}

- (id)initWithCategory:(Category *)category;

@end
