//
//  QuizCategoryCell.h
//  iPhoneProject
//
//  Created by Componica on 9/12/12.
//
//

#import <UIKit/UIKit.h>

@class Category;
@class RoundedRectView;

@interface QuizCategoryCell : UITableViewCell {
    
    Category *category;
    RoundedRectView *backgroundView;
    
    
}

@property(nonatomic, retain) Category *category;

- (id)initWithCategory:(Category *)category
                 width:(CGFloat)width;

- (void) highlight:(BOOL)highlight;

@end
