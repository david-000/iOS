//
//  RationaleVC.h
//  iPhoneProject
//
//  Created by Componica on 9/26/12.
//
//

#import <UIKit/UIKit.h>

@class FlashCard;
@class ScrollableImageView;

@protocol RationaleVCDelegate <NSObject>

@required 

-(void)dismissRationaleVC;

@end

@interface RationaleVC : UIViewController {

    NSObject<RationaleVCDelegate> *delegate;
    IBOutlet UITextView *textView;
    IBOutlet UIButton *mnemonicsButton;
    IBOutlet UIButton *pictureButton;
    IBOutlet UIButton *closeButton;
    IBOutlet UILabel *titleLabel;
    FlashCard *flashcard;
    ScrollableImageView *scrollableImageView;
    UITextView *mnemonicView;
        
}

@property(nonatomic, assign) NSObject<RationaleVCDelegate> *delegate;
@property(nonatomic, retain) UITextView *textView;
@property(nonatomic, retain) UIButton *mnemonicsButton;
@property(nonatomic, retain) UIButton *pictureButton;
@property(nonatomic, retain) UIButton *closeButton;
@property(nonatomic, retain) UILabel *titleLabel;


- (IBAction)onCloseButton:(id)sender;

- (IBAction)onMnemonicsButton:(id)sender;

- (IBAction)onPictureButton:(id)sender;

- (void)setFlashcard:(FlashCard *)flashcard;

- (BOOL)shouldAllowSwiping:(UITouch *)touch;

@end
