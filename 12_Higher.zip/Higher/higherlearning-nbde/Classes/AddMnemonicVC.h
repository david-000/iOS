//
//  AddMnemonicVC.h
//  iPhoneProject
//
//  Created by MacBook on 7/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NavigationItemVC.h"

@interface AddMnemonicVC : NavigationItemVC
<UITextViewDelegate>
{
    IBOutlet UITextView *titleView;
    IBOutlet UITextView *myTextView;
    
}

@property(nonatomic, retain) UITextView *titleView;
@property(nonatomic, retain) UITextView *myTextView;

- (void) initViewComponents;
- (IBAction) doGoBack:(id)sender;
- (IBAction)saveMnemonic:(id)sender;
- (IBAction)closeKB:(id)sender;

@end
