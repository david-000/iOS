//
//  TMTextfieldCell.h
//  MobileWorkforce
//
//  Created by Collin Ruffenach on 10/22/10.
//  Copyright 2010 ELC Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RoundedRectView;


@interface QuestionCell : UITableViewCell {

	RoundedRectView *backgroundView;
    UILabel *contentLabel;
    UILabel *extraLabel;
    
}

@property (nonatomic, retain) UILabel *contentLabel;

- (id)initWithQuestionText:(NSString *)questionText
         extraQuestionText:(NSString *)extraQuestionText
       flashcardStatusName:(NSString *)flashcardStatusName
                     width:(CGFloat)width;

@end