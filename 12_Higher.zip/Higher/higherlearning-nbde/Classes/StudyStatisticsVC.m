//
//  StudyStatisticsVC.m
//  iPhoneProject
//
//  Created by Componica on 9/24/12.
//
//

#import "StudyStatisticsVC.h"
#import "Category.h"
#import "FlashCardsDB.h"

@interface StudyStatisticsVC ()

@end

@implementation StudyStatisticsVC

- (id)initWithCategory:(Category *)_category {
 
    self = [super initWithCategory:_category];
    
    if(self) {
        
    }
    
    return self;
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) loadStatisticsInformation {
    
    
    [super loadStatisticsInformation];
    
    
    category.numberOfUnansweredFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                    flashcardStatusName:@"unanswered"
                                                                                              recursive:YES];
    
    category.numberOfCorrectFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                        answerStatus:@"correct"
                                                                                           recursive:YES];
    
    category.numberOfIncorrectFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                          answerStatus:@"incorrect"
                                                                                             recursive:YES];
    
    category.numberOfRedFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                             flashcardStatusName:@"red"
                                                                                       recursive:YES];
    
    category.numberOfYellowFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                flashcardStatusName:@"yellow"
                                                                                          recursive:YES];
    
    category.numberOfGreenFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                               flashcardStatusName:@"green"
                                                                                         recursive:YES];
    
    const NSInteger totalNumberOfFlashcards = category.numberOfUnansweredFlashcards + category.numberOfRedFlashcards + category.numberOfYellowFlashcards + category.numberOfGreenFlashcards;
    
    
    if(totalNumberOfFlashcards > 0) {
        
        
        const float unansweredPercentage = category.numberOfUnansweredFlashcards / (float)(totalNumberOfFlashcards);
        const float redPercentage = category.numberOfRedFlashcards / (float)(totalNumberOfFlashcards);
        const float yellowPercentage = category.numberOfYellowFlashcards / (float)(totalNumberOfFlashcards);
        const float greenPercentage = category.numberOfGreenFlashcards / (float)(totalNumberOfFlashcards);

        [components removeAllObjects];
        
        if(category.numberOfUnansweredFlashcards) {
            
            PCPieComponent *unansweredComponent = [PCPieComponent pieComponentWithTitle:@"Unanswered"
                                                                                  value:unansweredPercentage];
            unansweredComponent.colour = [UIColor lightGrayColor];
            [components addObject:unansweredComponent];
        }
        
        
        if(category.numberOfRedFlashcards) {
            PCPieComponent *redComponent = [PCPieComponent pieComponentWithTitle:@"Red"
                                                                           value:redPercentage];
            [redComponent setColour:[UIColor redColor]];
            [components addObject:redComponent];
        }
        
        if(category.numberOfYellowFlashcards) {
            PCPieComponent *yellowComponent = [PCPieComponent pieComponentWithTitle:@"Yellow"
                                                                              value:yellowPercentage];
            [yellowComponent setColour:[UIColor yellowColor]];
            [components addObject:yellowComponent];
        }
        
        if(category.numberOfGreenFlashcards) {
            PCPieComponent *greenComponent = [PCPieComponent pieComponentWithTitle:@"Green"
                                                                             value:greenPercentage];
            [greenComponent setColour:[UIColor greenColor]];
            
            [components addObject:greenComponent];
        }
        
        [pieChart setComponents:components];
        
    }
    
}

@end
