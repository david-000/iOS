//
//  AboutVC.h
//  iPhoneProject
//
//  Created by Componica on 8/28/12.
//
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>
#import "FBConnect.h"
#import "NavigationItemVC.h"



@interface AboutVC : NavigationItemVC<UITableViewDataSource, UITableViewDelegate, FBRequestDelegate, FBDialogDelegate, FBSessionDelegate, MFMailComposeViewControllerDelegate> {
 
    BOOL wantShare;

    IBOutlet UIButton *scienceButton;
    IBOutlet UIButton *guaranteeButton;
    IBOutlet UIButton *acknowledgementsButton;
    IBOutlet UIButton *rateButton;
    
    
}

@property(nonatomic, retain) UIButton *scienceButton;
@property(nonatomic, retain) UIButton *guaranteeButton;
@property(nonatomic, retain) UIButton *acknowledgementsButton;
@property(nonatomic, retain) UIButton *rateButton;
@property(nonatomic, retain) IBOutlet UIButton *feedbackButton;
@property(nonatomic, assign) BOOL wantShare;

- (IBAction)onScienceButton:(id)sender;
- (IBAction)onGuaranteeButton:(id)sender;
- (IBAction)onAcknowledgementsButton:(id)sender;
- (IBAction)onRateButton:(id)sender;
- (IBAction)onShareButton:(id)sender;
- (IBAction)onFeedbackButton:(id)sender;

- (void)goFBShare;
- (void)storeAuthData:(NSString *)accessToken expiresAt:(NSDate *)expiresAt;
- (void)shareONFB;
- (BOOL)checkFBValidity;
- (void)logoutFacebook;

@end
