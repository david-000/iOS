//
//  StatisticsCell.m
//  iPhoneProject
//
//  Created by Componica on 9/21/12.
//
//

#import "StatisticsCell.h"
#import "RoundedRectView.h"

#define kHorizontalPadding 10
#define kVerticalPadding 5
#define kMinHeightPhone 75
#define kMinHeightPad 100

@implementation StatisticsCell

@synthesize textLabel;

- (id)initWithText:(NSString *)text
             width:(CGFloat)width {

    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    if(self) {
    
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        self.backgroundColor = [UIColor clearColor];
        
        //Figure out how big the text will be
        UIFont *font = [UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]];
        CGFloat availableTextWidth = (width - 4 * kHorizontalPadding) * 0.75;
        CGSize textSize = [text sizeWithFont:font
                           constrainedToSize:CGSizeMake(availableTextWidth, NSIntegerMax)];
        
        CGFloat height = [Util isIPad] ? kMinHeightPad : kMinHeightPhone;
        height = fmax(height, textSize.height + kVerticalPadding * 4);
        
        //Set up the background view
        const NSInteger backgroundWidth = width - kHorizontalPadding * 2;
        const NSInteger backgroundHeight = height - kVerticalPadding * 2;
        backgroundView = [[RoundedRectView alloc] initWithFrame:CGRectMake(kHorizontalPadding, kVerticalPadding, backgroundWidth, backgroundHeight)];
        [self addSubview:backgroundView];
     
        //Set up the label
        const NSInteger labelX = kHorizontalPadding;
        const NSInteger labelY = kVerticalPadding;
        const NSInteger labelWidth = (backgroundWidth - 2 * kHorizontalPadding);
        const NSInteger labelHeight = backgroundHeight - 2 * kVerticalPadding;
        textLabel = [[UILabel alloc] initWithFrame:CGRectMake(labelX, labelY, labelWidth, labelHeight)];
        [textLabel setBackgroundColor:[UIColor clearColor]];
        [textLabel setTextColor:[UIColor darkGrayColor]];
        [textLabel setText:text];
        [textLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
        [textLabel setTextAlignment:NSTextAlignmentLeft];
        textLabel.lineBreakMode = NSLineBreakByWordWrapping;
        textLabel.numberOfLines = 0;
        [backgroundView addSubview:textLabel];
        
        [self setFrame:CGRectMake(0, 0, width, height)];
        
    }
    
    return self;
    
}


- (void) dealloc {
    
    [textLabel release];
    [backgroundView release];
    [super dealloc];
    
}

- (void) highlight:(BOOL)highlight {
    
    if(highlight) {
        
        backgroundView.fillColor = backgroundView.strokeColor = [UIColor lightGrayColor];
        
    } else {
        
        backgroundView.fillColor = backgroundView.strokeColor = [UIColor whiteColor];
        
    }
    
    [backgroundView setNeedsDisplay];
    
}

@end
