//
//  Mnemonic.h
//  iPhoneProject
//
//  Created by Patrick Kellen on 9/11/12.
//
//

#import <Foundation/Foundation.h>

@interface Mnemonic : NSObject<NSCopying> {
	NSInteger mnemonicID;
	NSString* text;
    NSInteger mnemonicTypeID;
    NSString *mnemonicTypeName;
    NSString *title;
    BOOL saved;
    NSInteger mnemonicNumber;
}

@property(nonatomic, assign) NSInteger mnemonicID;
@property(nonatomic, retain) NSString* text;
@property(nonatomic, assign) NSInteger mnemonicTypeID;
@property(nonatomic, retain) NSString *mnemonicTypeName;
@property(nonatomic, retain) NSString *title;
@property(nonatomic, assign) BOOL saved;
@property(nonatomic, assign) NSInteger mnemonicNumber;

- (id)initWithMnemonicID:(NSInteger)_mnemonicID
                    text:(const char *)_text
          mnemonicTypeID:(NSInteger)_mnemonicTypeID
        mnemonicTypeName:(const char *)_mnemonicTypeName
                   title:(const char *)_title
                   saved:(BOOL)_saved
          mnemonicNumber:(NSInteger)_mnemonicNumber;

@end
