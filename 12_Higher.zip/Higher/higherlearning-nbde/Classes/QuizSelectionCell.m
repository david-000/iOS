//
//  QuizSelectionCell.m
//  iPhoneProject
//
//  Created by Componica on 9/13/12.
//
//

#import "QuizSelectionCell.h"
#import "RoundedRectView.h"
#import "Util.h"
#import "Category.h"

#define kHorizontalPadding 10
#define kVerticalPadding 5
#define kMinHeight 100
#define kIndentation 10

@implementation QuizSelectionCell

@synthesize category;

- (id)initWithCategory:(Category *)_category
                 width:(CGFloat)width
            percentage:(float)percentage
             completed:(BOOL)completed {
    
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    if(self) {
    
        category = [_category retain];
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        //Set up the frame
        const CGFloat height = kMinHeight;
  
        //Set up the background view
        const NSInteger backgroundWidth = width - 2 * kHorizontalPadding;
        const NSInteger backgroundHeight = height - 2 * kVerticalPadding;
        backgroundView = [[RoundedRectView alloc] initWithFrame:CGRectMake(kHorizontalPadding, kVerticalPadding, backgroundWidth, backgroundHeight)];
        [self addSubview:backgroundView];
        
        //Set up the title label
        NSInteger titleX = kHorizontalPadding;
        NSInteger titleY = kVerticalPadding;
        NSInteger titleWidth = backgroundWidth - 2 * kHorizontalPadding;
        NSInteger titleHeight = backgroundHeight / 2 - 2 * kVerticalPadding;
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(titleX, titleY, titleWidth, titleHeight)];
        [titleLabel setBackgroundColor:[UIColor clearColor]];
        [titleLabel setTextColor:[UIColor darkGrayColor]];
        [titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
        [titleLabel setTextAlignment:NSTextAlignmentLeft];
        titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        titleLabel.numberOfLines = 0;
        [titleLabel setText:category.categoryName];
        const NSInteger titleLabelX = kHorizontalPadding;
        const NSInteger titleLabelY = kVerticalPadding;
        titleLabel.frame = CGRectMake(titleLabelX, titleLabelY, titleLabel.frame.size.width, titleLabel.frame.size.height);
        [backgroundView addSubview:titleLabel];
        
        //Set up the score label
        scoreLabel = [[UILabel alloc] init];
        scoreLabel.text = @"Score: ";
        scoreLabel.textColor = [UIColor darkGrayColor];
        scoreLabel.backgroundColor = [UIColor clearColor];
        [scoreLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
        [scoreLabel sizeToFit];
        const NSInteger scoreLabelX = kHorizontalPadding + kIndentation;
        const NSInteger scoreLabelY = titleLabel.frame.origin.y + titleLabel.frame.size.height + kVerticalPadding;
        scoreLabel.frame = CGRectMake(scoreLabelX, scoreLabelY, scoreLabel.frame.size.width, scoreLabel.frame.size.height);
        [backgroundView addSubview:scoreLabel];
        
        //Set up the percentage label
        percentageLabel = [[UILabel alloc] init];
        percentageLabel.textColor = [UIColor blueColor];
        percentageLabel.backgroundColor = [UIColor clearColor];
        [percentageLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
        [self setPercentage:percentage completed:completed];
        [backgroundView addSubview:percentageLabel];
        
        self.frame = CGRectMake(0, 0, width, height);

        
    }
    return self;
    
}

- (void)dealloc {
    
    [backgroundView release];
    [scoreLabel release];
    [percentageLabel release];
    [titleLabel release];
    [category release];
    [super dealloc];
    
}


- (void) highlight:(BOOL)highlight {
    
    if(highlight) {
        
        backgroundView.fillColor = backgroundView.strokeColor = [UIColor lightGrayColor];
        
    } else {
        
        backgroundView.fillColor = backgroundView.strokeColor = [UIColor whiteColor];
        
    }
    
    [backgroundView setNeedsDisplay];
    
}

- (void) setPercentage:(CGFloat)percentage
             completed:(BOOL)completed {
    
    if(completed) {
        percentageLabel.text = [NSString stringWithFormat:@"%2.f\%%", round(percentage * 100)];
    } else {
        percentageLabel.text = @"Not completed";
    }

    
    [percentageLabel sizeToFit];
    const NSInteger percentageLabelX = scoreLabel.frame.origin.x + scoreLabel.frame.size.width;
    const NSInteger percentageLabelY = scoreLabel.frame.origin.y + scoreLabel.frame.size.height / 2.0f - percentageLabel.frame.size.height / 2.0f;
    percentageLabel.frame = CGRectMake(percentageLabelX, percentageLabelY, percentageLabel.frame.size.width, percentageLabel.frame.size.height);
    
}


@end
