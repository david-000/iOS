//
//  BackgroundView.h
//  iPhoneProject
//
//  Created by Componica on 10/1/12.
//
//

#import <UIKit/UIKit.h>

@interface BackgroundView : UIView {
 
    UIView *dimmerView;
    
}

- (void)setAlpha:(CGFloat)alpha;

@end
