//
//  Global.m
//  iPhoneProject
//


#import "Global.h"

BOOL g_is_showing_popup = NO;