//
//  MnemonicsListVC.h
//  iPhoneProject
//
//  Created by MacBook on 7/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NavigationItemVC.h"
#import "MnemonicVC.h"


@interface MnemonicsListVC : NavigationItemVC
<UISearchBarDelegate, UITableViewDelegate, UITableViewDataSource, MnemonicVCDelegate, UITextFieldDelegate>
{
    IBOutlet UITableView* myTableView;
    IBOutlet UISearchBar *mySearchBar;
    IBOutlet UIButton* btnAdd;
    
    NSMutableArray *cells;
    NSMutableArray *copyOfCells;
    
    NSMutableArray *mnemonics;
    NSMutableArray *copyOfMnemonics;
    
    BOOL searching;
    BOOL letUserSelectRow;
        
}

@property(nonatomic, retain) UITableView *myTableView;
@property(nonatomic, retain) UIButton *btnAdd;
@property (nonatomic, retain) NSString *mnemonicTypeName;
@property (nonatomic, retain) IBOutlet UITextField *txtSearchBar;

- (id) initWithMnemonicTypeName:(NSString *)_mnemonicTypeName;
- (void) initViewComponents;
- (IBAction) doAddMnemonic:(id)sender;

- (void)searchTableView;

@end
