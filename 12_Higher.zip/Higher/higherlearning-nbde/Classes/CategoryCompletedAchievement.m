//
//  CategoryCompletedAchievement.m
//  iPhoneProject
//
//  Created by Componica on 10/3/12.
//
//

#import "CategoryCompletedAchievement.h"
#import "CategoryDB.h"
#import "Category.h"
#import "FlashCardsDB.h"

@implementation CategoryCompletedAchievement


- (BOOL)didAchieve {

    NSInteger numberOfGreenCards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:categoryId
                                                                           flashcardStatusName:@"green"
                                                                                     recursive:YES];
    
    NSInteger numberOfRedCards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:categoryId
                                                                         flashcardStatusName:@"red"
                                                                                   recursive:YES];
    
    NSInteger numberOfYellowCards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:categoryId
                                                                            flashcardStatusName:@"yellow"
                                                                                      recursive:YES];
    
    NSInteger numberOfUnansweredCards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:categoryId
                                                                                flashcardStatusName:@"unanswered"
                                                                                          recursive:YES];
    
    NSInteger numberOfNonGreenCards = numberOfRedCards + numberOfYellowCards + numberOfUnansweredCards;

    NSLog(@"Number of non-green cards for category %d: %d", categoryId, numberOfNonGreenCards);
    
    if(numberOfNonGreenCards > 0 || numberOfGreenCards == 0) {
        
        return NO;
        
    } else {
    
        return YES;
        
    }
    
}

- (NSString *)message {
    
    Category *category = [[CategoryDB instance] getCategory:categoryId];
    if(category.parentCategoryId) {
     
        NSArray *heirarchy = [[CategoryDB instance] getCategoryHeirarchy:categoryId];
        Category * rootCategory = [heirarchy lastObject];
        NSString *messaage = [NSString stringWithFormat:@"Congrats! You've finished all of %@: %@!", rootCategory.categoryName, category.categoryName];
        return messaage;
        
    } else {
        
        NSString *message = [NSString stringWithFormat:@"Wow, great work! You have finished %@!", category.categoryName];
        return message;
        
    }
    
}

@end
