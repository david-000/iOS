//
//  QuizSelectionVC.h
//  iPhoneProject
//
//  Created by Componica on 9/13/12.
//
//

#import <UIKit/UIKit.h>
#import "NavigationItemVC.h"

@class Category;

@interface QuizSelectionVC : NavigationItemVC<UITableViewDataSource, UITableViewDelegate> {
    
    IBOutlet UITableView *myTableView;
    NSMutableArray *childCategories;
    NSMutableArray *cells;
    Category *category;
    
}


@property(nonatomic, retain) IBOutlet UITableView *myTableView;

- (id)initWithCategory:(Category *)_category;


@end
