//
//  ScienceVC.m
//  iPhoneProject
//
//  Created by MacBook on 7/6/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ScienceVC.h"
#import "Util.h"
#import "GANTracker.h"

@implementation ScienceVC

@synthesize myScrollView;

- (id) init {
    
    NSString *nib = NibName(@"ScienceVC");
    self = [super initWithNibName:nib bundle:nil];
    if(self) {
        
    }
    
    return self;
    
}

- (void)dealloc {
 
    [myScrollView release];
    [super dealloc];
    
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [myScollView setContentSize:CGSizeMake(300, 865)];
    if ([Util isIPad]) {
        [myScollView setContentSize:CGSizeMake(746, 865)];
    }
}

- (void) viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Science"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

@end
