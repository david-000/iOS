//
//  MenuVC.m
//  iPhoneProject
//
//  Created by Componica on 9/20/12.
//
//

#import "MenuVC.h"
#import "Util.h"

@interface MenuVC ()

@end

@implementation MenuVC

@synthesize myTableView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        cells = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void) dealloc {
    
    myTableView.delegate = nil;
    myTableView.dataSource = nil;
    [myTableView release];
    [cells release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    myTableView.scrollEnabled = NO;
    int height = cells.count * [Util heightForMenuCell];
    int y = self.view.center.y - height / 2;
    int x = ([Util UIWidth])/2 - ([Util WidthForMenuCell]/2);
    [myTableView setFrame:CGRectMake(x, y, [Util WidthForMenuCell], height)];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (UITableViewCell *)createCellWithTitle:(NSString *)title
                                selector:(SEL)selector {
    
    UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                                    reuseIdentifier:nil] autorelease];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    UIImage *image = [UIImage imageNamed:ResName(@"txt_box")];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 273, 44);
    //button.frame = CGRectMake(0, 0, image.size.width, image.size.height);
    [button setBackgroundImage:image forState:UIControlStateNormal];
    [button setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [button.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [button setTitle:title forState:UIControlStateNormal];
    [button addTarget:self action:selector forControlEvents:UIControlEventTouchUpInside];
    [cell addSubview:button];
    return cell;
}

- (UITableViewCell *)createCellWithTitleandRect:(NSString *)title rect:(CGRect)rect
                                selector:(SEL)selector {
    
    UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                                    reuseIdentifier:nil] autorelease];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    UIImage *image = [UIImage imageNamed:ResName(@"txt_box")];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = rect;
    //button.frame = CGRectMake(0, 0, image.size.width, image.size.height);
    [button setBackgroundImage:image forState:UIControlStateNormal];
    [button setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [button.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [button setTitle:title forState:UIControlStateNormal];
    [button addTarget:self action:selector forControlEvents:UIControlEventTouchUpInside];
    [cell addSubview:button];
    return cell;
}

- (UITableViewCell *)createCellWithImage:(NSString *)normalName highlight:(NSString *)highlightName rect:(CGRect)rect
                                selector:(SEL)selector {
    
    UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                                    reuseIdentifier:nil] autorelease];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    UIImage *normalImage = [UIImage imageNamed:normalName];
    UIImage *highlightImage = [UIImage imageNamed:highlightName];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = rect;
    //button.frame = CGRectMake(0, 0, image.size.width, image.size.height);
    [button setBackgroundImage:normalImage forState:UIControlStateNormal];
    if (highlightImage) {
        [button setBackgroundImage:highlightImage forState:UIControlStateHighlighted];
    }
    
    [button setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [button.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [button addTarget:self action:selector forControlEvents:UIControlEventTouchUpInside];
    [cell addSubview:button];
    return cell;
}

#pragma mark UITableViewDelegate / UITableViewDataSource delegate methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
	return cells.count;
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return 1;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return [cells objectAtIndex:indexPath.row];
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

@end
