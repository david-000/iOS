//
//  OtherVC.h

#import <UIKit/UIKit.h>
#import "PCPieChart.h"
#import "NavigationItemVC.h"

@class Category;

@interface StatisticsVC : NavigationItemVC <UIAlertViewDelegate>{
    
    IBOutlet UITableView* myTableView;
    
    UIView* headerView;
	double averageTime;
    Category *category;
    PCPieChart *pieChart;
    NSMutableArray *components;

    UIAlertView *resetAlert;
    BOOL    bOverall;
}

@property(nonatomic, retain) UITableView *myTableView;

- (id) initWithCategory:(Category *)_category;

- (void) loadStatisticsInformation;

- (IBAction)resetStats:(id)sender;

@end
