//
//  StudentObj.h
//  MySQLiteProject
//


#import <Foundation/Foundation.h>
#import "Category.h"
#import "Mnemonic.h"
#import "FlashCardsDB.h"
#import "Image.h"

@interface Answer : NSObject<NSCopying> {
 
    NSString *text;
    BOOL correct;
    BOOL selected;
    BOOL crossed;
    
}

@property(nonatomic, retain) NSString *text;
@property(nonatomic, assign) BOOL correct;
@property(nonatomic, assign) BOOL selected;
@property(nonatomic, assign) BOOL crossed;

@end

@interface FlashCard : NSObject <NSCopying> {
    
	NSInteger cardID;
	NSString* question;
	NSMutableArray* answers;
    Category *category;
    Image *image;
	NSString* rationale;
    NSString *rationalePreview;
    NSArray *mnemonics;
    NSInteger flashcardStatusId;
    NSString *flashcardStatusName;
    NSInteger answerStatusId;
    NSString *answerStatusName;
	double time;
    NSString *extraQuestionText;
    NSInteger numberOfCorrectAnswers;
    BOOL answered;
    
}

@property(nonatomic, assign) NSInteger cardID;
@property(nonatomic, retain) NSString* question;
@property(nonatomic, retain) NSMutableArray* answers;
@property(nonatomic, retain) Category *category;
@property(nonatomic, retain) Image *image;
@property(nonatomic, retain) NSString* rationale;
@property(nonatomic, retain) NSString *rationalePreview;
@property(nonatomic, retain) NSArray *mnemonics;
@property(nonatomic, assign) NSInteger flashcardStatusId;
@property(nonatomic, retain) NSString *flashcardStatusName;
@property(nonatomic, assign) NSInteger answerStatusId;
@property(nonatomic, retain) NSString *answerStatusName;
@property(nonatomic, assign) double time;
@property(nonatomic, retain) NSString *extraQuestionText;
@property(nonatomic, assign) NSInteger numberOfCorrectAnswers;
@property(nonatomic, assign) BOOL answered;

- (id)initWithCardID:(NSInteger)cardID
            question:(const char *)question
       choicesString:(const char *)choicesString
       answersString:(const char *)answersString
            category:(Category *)category
               image:(Image *)image
           rationale:(const char *)rationale
    rationalePreview:(const char *)rationalePreview
           mnemonics:(NSArray *)mnemonics
   flashcardStatusId:(NSInteger)flashcardStatusId
 flashcardStatusName:(const char *)flashcardStatusName
                time:(double)time
      answerStatusId:(NSInteger)answerStatusId
      answerStatusName:(const char *)answerStatusName;

- (void)setFlashcardStatusName:(NSString *)flashcardStatusName;

- (void)setAnswerStatusName:(NSString *)answerStatusName;

- (void)reset;

@end




