//
//  Global.h
//  TaskManager
//


#import <Foundation/Foundation.h>

//#define APP_NAME		@"NBDE Mastery"
#define CUSTOMER_EMAIL	@"nbdemastery@gmail.com"

//#define DATABASE_NAME	@"nbde.sql"


#define FREQ_RED	6
#define FREQ_YELLOW	12
#define FREQ_GREEN	20

 
extern BOOL g_is_showing_popup;

