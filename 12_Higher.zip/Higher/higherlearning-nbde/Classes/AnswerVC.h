//
//  QuestionVC.h

#import <UIKit/UIKit.h>
#import "FlashCard.h"


@interface AnswerVC : UIViewController <UITableViewDelegate, UITableViewDataSource> {

    IBOutlet UITableView* myTableView;
	FlashCard* flashCard;
	NSMutableArray *cells;
    NSInteger footerHeight;
    
}

@property(nonatomic, retain) UITableView* myTableView;
@property(nonatomic, retain) FlashCard* flashCard;
@property(nonatomic, assign) NSInteger footerHeight;

- (void) initComponentsWithFlashCard:(FlashCard*)card;


@end
