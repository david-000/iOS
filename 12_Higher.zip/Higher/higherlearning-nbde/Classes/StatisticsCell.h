//
//  StatisticsCell.h
//  iPhoneProject
//
//  Created by Componica on 9/21/12.
//
//

#import <UIKit/UIKit.h>

@class RoundedRectView;

@interface StatisticsCell : UITableViewCell {
    
    RoundedRectView *backgroundView;
    UILabel *textLabel;
    
}

@property(nonatomic, retain) UILabel *textLabel;

- (id)initWithText:(NSString *)text
             width:(CGFloat)width;

- (void) highlight:(BOOL)highlight;


@end
