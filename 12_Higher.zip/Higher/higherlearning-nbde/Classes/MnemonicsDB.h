//
//  MnemonicsDB.h
//  iPhoneProject
//
//  Created by Usman  Ali on 7/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Database.h"

@class Mnemonic;

@interface MnemonicsDB : Database {
    
}


+ (MnemonicsDB *)instance;

- (NSArray *)getAllMnemonicIds;

- (NSMutableArray*) getAllMnemonics;

- (NSMutableArray*) getMnemonicsForType:(NSString *)mnemonicTypeName;

- (NSMutableArray *) getSavedMnemonics;

- (NSMutableArray *) getUserMnemonics;

- (NSArray *) getMnemonicsForFlashcard:(NSInteger)flashcardId;

- (NSInteger)getMnemonicTypeId:(NSString *)mnemonicTypeName;

- (BOOL) addMnemonic:(NSString *)text
               title:(NSString *)title;

- (BOOL) updateMnemonic:(NSInteger)mnemonicId
                  saved:(BOOL)saved;

- (BOOL) removeMnemonic:(Mnemonic*)mnemonic;



@end
