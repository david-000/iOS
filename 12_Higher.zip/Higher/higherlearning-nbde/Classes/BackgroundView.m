//
//  BackgroundView.m
//  iPhoneProject
//
//  Created by Componica on 10/1/12.
//
//

#import "BackgroundView.h"
#import "Util.h"

#define kDefaultAlpha 1.0

@implementation BackgroundView

- (void)awakeFromNib {
 
    UIImage *image = [UIImage imageNamed:ResName(@"1_bg")];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
    imageView.autoresizingMask = 31;
    self.frame = CGRectMake(0, 0, image.size.width, image.size.height);
    [self insertSubview:imageView atIndex:0];
    [imageView release];
    
    dimmerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
    //dimmerView.backgroundColor = [UIColor colorWithWhite:0 alpha:kDefaultAlpha];
    dimmerView.autoresizingMask = 31;
    [self insertSubview:dimmerView aboveSubview:imageView];
}

- (void) dealloc {
 
    [dimmerView release];
    [super dealloc];
}

- (void)setAlpha:(CGFloat)alpha {
    
    dimmerView.backgroundColor = [UIColor colorWithWhite:0 alpha:alpha];

}


@end
