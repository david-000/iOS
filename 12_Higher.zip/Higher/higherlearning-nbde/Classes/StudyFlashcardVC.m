//
//  StudyFlashcardVC.m
//  iPhoneProject
//
//  Created by Componica on 9/13/12.
//

#import "StudyFlashcardVC.h"
#import "FlashCardsDB.h"
#import "NSMutableArray+Shuffle.h"
#import "StudyFlashcardVC.h"
#import "GANTracker.h"
#import "AchievementManager.h"

@interface StudyFlashcardVC (Private)



@end

@implementation StudyFlashcardVC

- (id)init {
        
    self = [super init];
    if (self) {
        // Custom initialization.
        [self loadFlashcards];
        
    }
    return self;
    
}

- (void) dealloc {
        
    [redFlashcardIds release];
    [unansweredFlashcardIds release];
    [yellowFlashcardIds release];
    [greenFlashcardIds release];
    
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    

    flashcardNumberLabel.hidden = YES;
}

- (void)viewDidAppear:(BOOL)animated {
 
    [super viewDidAppear:animated];
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Study Flashcards"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}
- (IBAction) doRed:(id) sender{
    
	[[FlashCardsDB instance] updateFlashCardWithFlashcardStatus:@"red" cardID:self.currentFlashCard.cardID];
    [self.currentFlashCard setFlashcardStatusName:@"red"];
	[redFlashcardIds addObject:[NSNumber numberWithInt:self.currentFlashCard.cardID]];
    [self checkForAchievements];
    [self gotoNextQuestion];
}

- (IBAction) doYellow:(id) sender{
    
	[[FlashCardsDB instance] updateFlashCardWithFlashcardStatus:@"yellow" cardID:self.currentFlashCard.cardID];
    [self.currentFlashCard setFlashcardStatusName:@"yellow"];
    [yellowFlashcardIds addObject:[NSNumber numberWithInt:self.currentFlashCard.cardID]];
    [self checkForAchievements];
    [self gotoNextQuestion];
}

- (IBAction) doGreen:(id) sender{
    
	[[FlashCardsDB instance] updateFlashCardWithFlashcardStatus:@"green" cardID:self.currentFlashCard.cardID];
    [self.currentFlashCard setFlashcardStatusName:@"green"];
    [greenFlashcardIds addObject:[NSNumber numberWithInt:self.currentFlashCard.cardID]];
    [self checkForAchievements];
    [self gotoNextQuestion];
}


- (BOOL) getNextCard {
    
    if(unansweredFlashcardIds.count == 0 && redFlashcardIds.count == 0 && yellowFlashcardIds.count == 0 && greenFlashcardIds.count == 0) {
        
        [self.navigationController popViewControllerAnimated:YES];
        return NO;
        
    }
    
    //Update the last flashcard in the history
    if(self.currentFlashCard) {
        [flashcardHistory removeLastObject];
        FlashCard *flashcardCopy = [currentFlashCard copy];
        [flashcardHistory addObject:flashcardCopy];
        [flashcardCopy release];
    }
    
    
	if (redFrequency < FREQ_RED){
		if (yellowFrequency < FREQ_YELLOW){
			if (greenFrequency < FREQ_GREEN){
				//xu ly theo thu tu uu tien la un-red-yellow-green
				if(unansweredFlashcardIds.count > 0){
					[self getCardFromBankType:@"unanswered"];
				}
				else if(redFlashcardIds.count > 0){
					[self getCardFromBankType:@"red"];
				}
				else if(yellowFlashcardIds.count > 0){
					[self getCardFromBankType:@"yellow"];
				}
				else if(greenFlashcardIds.count > 0){
					[self getCardFromBankType:@"green"];
				}
			}
			else{
				//xu ly tuong tu phan else cua if (freq_red < FREQ_RED) theo thu tu uu tien la un-red-yellow
				greenFrequency = 0;
				if (greenFlashcardIds.count > 0){
					[self getCardFromBankType:@"green"];
				}
				else if (unansweredFlashcardIds.count > 0){
					[self getCardFromBankType:@"unanswered"];
				}
				else if (redFlashcardIds.count > 0){
					[self getCardFromBankType:@"red"];
				}
				else if (yellowFlashcardIds.count > 0){
					[self getCardFromBankType:@"yellow"];
				}
			}
		}
		else{
			//xu ly tuong tu phan else cua if (freq_red < FREQ_RED) theo thu tu uu tien la un-red-green
			yellowFrequency = 0;
			if (yellowFlashcardIds.count > 0){
				[self getCardFromBankType:@"yellow"];
			}
			else if (unansweredFlashcardIds.count > 0){
				[self getCardFromBankType:@"unanswered"];
			}
			else if (redFlashcardIds.count > 0){
				[self getCardFromBankType:@"red"];
			}
			else if (greenFlashcardIds.count > 0){
				[self getCardFromBankType:@"green"];
			}
		}
	}
	else{
		//xu ly theo thu tu uu tien la un-yellow-green
		redFrequency = 0;
		if (redFlashcardIds.count > 0){
			[self getCardFromBankType:@"red"];
		}
		else if (unansweredFlashcardIds.count > 0){
			[self getCardFromBankType:@"unanswered"];
		}
		else if (yellowFlashcardIds.count > 0){
			[self getCardFromBankType:@"yellow"];
		}
		else if (greenFlashcardIds.count > 0){
			[self getCardFromBankType:@"green"];
		}
	}
    
    if(self.currentFlashCard) {
        FlashCard *flashcardCopy = [currentFlashCard copy];
        [flashcardHistory addObject:flashcardCopy];
        [flashcardCopy release];
        NSLog(@"Category: %@", self.currentFlashCard.category.categoryName);
    }

    return YES;
}

- (void) flipFooter {
    
    btnItemRed.hidden = NO;
	btnItemYellow.hidden = NO;
	btnItemGreen.hidden = NO;
	btnItemSubmit.hidden = YES;
    nextButton.hidden = YES;
     
}
     


- (void)loadFlashcards {
    
    
    unansweredFlashcardIds = [[[FlashCardsDB instance] getEnabledFlashcardIdsWithStatus:@"unanswered"
                                                                   categoryTypeName:@"multiple-choice"] retain];
    [unansweredFlashcardIds shuffle];
    
    redFlashcardIds = [[[FlashCardsDB instance] getEnabledFlashcardIdsWithStatus:@"red"
                                                            categoryTypeName:@"multiple-choice"] retain];
    [redFlashcardIds shuffle];
    
    yellowFlashcardIds = [[[FlashCardsDB instance] getEnabledFlashcardIdsWithStatus:@"yellow"
                                                               categoryTypeName:@"multiple-choice"] retain];
    [yellowFlashcardIds shuffle];
    
    greenFlashcardIds = [[[FlashCardsDB instance] getEnabledFlashcardIdsWithStatus:@"green"
                                                              categoryTypeName:@"multiple-choice"] retain];
    [greenFlashcardIds shuffle];

    
}

- (void) getCardFromBankType:(NSString *)flashcardStatusName {
    
    if([flashcardStatusName isEqualToString:@"unanswered"]) {
        NSNumber *flashcardId = [unansweredFlashcardIds objectAtIndex:0];
        self.currentFlashCard = [[FlashCardsDB instance] getFlashcardWithId:[flashcardId intValue]];
        [currentFlashCard release];
        [unansweredFlashcardIds removeObjectAtIndex:0];
        redFrequency++;
        yellowFrequency++;
        greenFrequency++;
    } else if([flashcardStatusName isEqualToString:@"red"]) {
        NSNumber *flashcardId = [redFlashcardIds objectAtIndex:0];
        self.currentFlashCard = [[FlashCardsDB instance] getFlashcardWithId:[flashcardId intValue]];
        [currentFlashCard release];
        [redFlashcardIds removeObjectAtIndex:0];
        yellowFrequency++;
        greenFrequency++;
        redFrequency = 0;
    } else if([flashcardStatusName isEqualToString:@"yellow"]) {
        NSNumber *flashcardId = [yellowFlashcardIds objectAtIndex:0];
        self.currentFlashCard = [[FlashCardsDB instance] getFlashcardWithId:[flashcardId intValue]];
        [currentFlashCard release];
        [yellowFlashcardIds removeObjectAtIndex:0];
        redFrequency++;
        yellowFrequency = 0;
        greenFrequency++;
    } else if([flashcardStatusName isEqualToString:@"green"]) {
        NSNumber *flashcardId = [greenFlashcardIds objectAtIndex:0];
        self.currentFlashCard = [[FlashCardsDB instance] getFlashcardWithId:[flashcardId intValue]];
        [currentFlashCard release];
        [greenFlashcardIds removeObjectAtIndex:0];
        redFrequency++;
        yellowFrequency++;
        greenFrequency = 0;
    } else {
        NSAssert(0, @"Unkown flashcard status name: %@", flashcardStatusName);
    }
    
    [self.currentFlashCard reset];
    
}

- (void)checkForAchievements {
 
    [[AchievementManager instance] checkCategoryCompletedAchievements:self.currentFlashCard.category];
    Achievement *achievement = [[AchievementManager instance] checkAllFlashcardsCompletedAchievement];
    [achievement release];
    
}

- (void)updateViews {
 
    [super updateViews];
    
    if(self.currentFlashCard.answered) {
        
        btnItemRed.hidden = NO;
        btnItemYellow.hidden = NO;
        btnItemGreen.hidden = NO;
        btnItemSubmit.hidden = YES;
         
    } else {
        
        btnItemRed.hidden = YES;
        btnItemYellow.hidden = YES;
        btnItemGreen.hidden = YES;
        btnItemSubmit.hidden = NO;
    }
}

@end


@implementation StudyFlashcardVC (Private)



@end