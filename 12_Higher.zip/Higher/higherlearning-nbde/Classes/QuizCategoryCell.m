//
//  QuizCategoryCell.m
//  iPhoneProject
//
//  Created by Componica on 9/12/12.
//
//

#import "QuizCategoryCell.h"
#import "Category.h"
#import "RoundedRectView.h"
#import "Util.h"

#define kHorizontalPadding 10
#define kVerticalPadding 5
#define kMinHeightPhone 75
#define kMinHeightPad 100


@implementation QuizCategoryCell

@synthesize category;

- (id)initWithCategory:(Category *)_category
                 width:(CGFloat)width {
    
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    if(self) {
        self.category = _category;
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        self.backgroundColor = [UIColor clearColor];
        
        
        //Figure out how big the text will be
        UIFont *font = [UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]];
        CGFloat availableTextWidth = width - 4 * kHorizontalPadding;
        CGSize textSize = [self.category.categoryName sizeWithFont:font
                                                 constrainedToSize:CGSizeMake(availableTextWidth, NSIntegerMax)];
        CGFloat height = [Util isIPad] ?  kMinHeightPad  : kMinHeightPhone;
        height = fmax(height, textSize.height + kVerticalPadding * 4);
        
        //Set up the background view
        const NSInteger backgroundWidth = width - kHorizontalPadding * 2;
        const NSInteger backgroundHeight = height - kVerticalPadding * 2;
        backgroundView = [[RoundedRectView alloc] initWithFrame:CGRectMake(kHorizontalPadding, kVerticalPadding, backgroundWidth, backgroundHeight)];
        [self addSubview:backgroundView];
        
        //Set up the label
        const NSInteger labelX = kHorizontalPadding;
        const NSInteger labelY = kVerticalPadding;
        const NSInteger labelWidth = backgroundWidth - 2 * kHorizontalPadding;
        const NSInteger labelHeight = backgroundHeight - 2 * kVerticalPadding;
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(labelX, labelY, labelWidth, labelHeight)];
        [label setBackgroundColor:[UIColor clearColor]];
        [label setTextColor:[UIColor darkGrayColor]];
        [label setText:category.categoryName];
        [label setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
        [label setTextAlignment:NSTextAlignmentLeft];
        label.lineBreakMode = NSLineBreakByWordWrapping;
        label.numberOfLines = 0;
        [backgroundView addSubview:label];
        [label release];
        
        [self setFrame:CGRectMake(0, 0, width, height)];
    }
    
    
    return self;
}


- (void)dealloc {
    
    [category release];
    [backgroundView release];
    [super dealloc];
    
}


- (void) highlight:(BOOL)highlight {
 
    if(highlight) {
        
        backgroundView.fillColor = backgroundView.strokeColor = [UIColor lightGrayColor];
        
    } else {
                
        backgroundView.fillColor = backgroundView.strokeColor = [UIColor whiteColor];
        
    }
    
    [backgroundView setNeedsDisplay];
    
}

 
@end
