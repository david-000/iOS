//
//  HelpFlashcard.m
//  NBDE
//
//  Created by Yao Ming on 2/7/13.
//
//

#import "HelpFlashcard.h"
#import "StudyFlashcardVC.h"

@implementation HelpFlashcard
@synthesize btnBottom;
@synthesize scrollView;

#pragma mark - User Interaction Methods
-(IBAction)clickBottomButton:(id)sender{
    int tag = btnBottom.tag;
    
    if (tag == 0) {
        btnBottom.tag = 1;
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.size.width, 0, scrollView.frame.size.width, scrollView.frame.size.height) animated:YES];
        
        [btnBottom setTitle:@"Try!!!" forState:UIControlStateNormal];
    }
    else{
        [self.navigationController popViewControllerAnimated:NO];
        
        
        StudyFlashcardVC *controller = [[StudyFlashcardVC alloc] init];
        [self.navigationController pushViewController:controller animated:YES];
        [controller release];
    }
}
-(IBAction)clickBackButton:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - View Life Cycle

-(void)dealloc{
    [btnBottom release];
    [scrollView release];
    
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (BOOL)shouldAutorotate {
    
    return NO;
    
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self.scrollView setContentSize:CGSizeMake(scrollView.frame.size.width * 2.0, scrollView.frame.size.height)];
    UIImageView *imgView1 = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"trial1.png"]] autorelease];
    [imgView1 setContentMode:UIViewContentModeScaleAspectFit];
    [imgView1 setFrame:CGRectMake(0, 0, scrollView.frame.size.width, scrollView.frame.size.height)];
    [scrollView addSubview:imgView1];
    
    UIImageView *imgView2 = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"trial2.png"]] autorelease];
    [imgView2 setFrame:CGRectMake(scrollView.frame.size.width, 0, scrollView.frame.size.width, scrollView.frame.size.height)];
    [imgView2 setContentMode:UIViewContentModeScaleAspectFit];
    [scrollView addSubview:imgView2];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
