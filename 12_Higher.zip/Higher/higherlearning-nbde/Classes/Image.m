//
//  Image.m
//  iPhoneProject
//
//  Created by Componica on 9/11/12.
//
//

#import "Image.h"

@implementation Image

@synthesize imageID, imageName;

- (id)initWithImageID:(NSInteger)_imageID
            imageName:(const char *)_imageName {
    
 
    self = [super init];
    if(self) {
        self.imageID = _imageID;
        self.imageName = _imageName ? [NSString stringWithUTF8String:_imageName] : nil;
    }
    
    return self;
    
}


- (void) dealloc{
	[imageName release];
	[super dealloc];
}

- (id) copyWithZone:(NSZone *)zone {
 
    Image *image = [[Image alloc] init];
    image.imageID = imageID;
    image.imageName = [imageName copy];
    [image.imageName release];
    return image;
    
}


@end