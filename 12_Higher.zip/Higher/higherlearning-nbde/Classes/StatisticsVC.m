//
//  OtherVC.m

#import "StatisticsVC.h"
#import "FlashCardsDB.h"
#import "Util.h"
#import "Category.h"
#import "GANTracker.h"
#import "AchievementManager.h"
#import "CategoryDB.h"

#define kTotalCellIndex 0
#define kCorrectCellIndex 1
#define kIncorrectCellIndex 2
#define kAverageCellIndex 3

#define kUnansweredSliceIndex 0
#define kRedSliceIndex 1
#define kYellowSliceIndex 2
#define kGreenSliceIndex 3
#define kNumberOfSlices 4

static inline float radians(double degrees) { return degrees * M_PI / 180; }

@implementation StatisticsVC

@synthesize myTableView;

- (void) dealloc{

    myTableView.delegate = nil;
    myTableView.dataSource = nil;
    [myTableView release];
    [headerView release];
    [category release];
    [pieChart release];
    [components release];
    [resetAlert release];
    [super dealloc];
}

- (id) initWithCategory:(Category *)_category {

    NSString *nib = NibName(@"StatisticsVC");
    self = [super initWithNibName:nib bundle:nil];
    bOverall = NO;
    
    if(self) {

        if (_category) {
            category = [_category retain];
            category.numberOfCorrectFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                                answerStatus:@"correct"
                                                                                                   recursive:YES];
            
            category.numberOfIncorrectFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                                  answerStatus:@"incorrect"
                                                                                                     recursive:YES];
            
            category.numberOfUnansweredFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                                   answerStatus:@"unanswered"
                                                                                                      recursive:YES];
            
            category.numberOfRedFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                     flashcardStatusName:@"red"
                                                                                               recursive:YES];
            
            category.numberOfYellowFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                        flashcardStatusName:@"yellow"
                                                                                                  recursive:YES];
            
            category.numberOfGreenFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                       flashcardStatusName:@"green"
                                                                                                 recursive:YES];
        }
        else
        {
            NSMutableArray *categories;
            categories = [[[CategoryDB instance] getRootCategoriesForCategoryType:@"multiple-choice"] retain];
            bOverall = YES;
            
            category = [[Category alloc] initWithCategoryID:0
                                parentCategoryID:0
                                    categoryName:"Overall statistics"
                                         enabled:YES
                                       available:YES
                                  categoryTypeId:0
                                categoryTypeName:"Overall statistics"
                                enabledByDefault:NO];
            
            for (Category *category_cell in categories) {
                
                category.numberOfCorrectFlashcards += [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category_cell.categoryID
                                                                                                    answerStatus:@"correct"
                                                                                                       recursive:YES];
                
                category.numberOfIncorrectFlashcards += [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category_cell.categoryID
                                                                                                      answerStatus:@"incorrect"
                                                                                                         recursive:YES];
                
                category.numberOfUnansweredFlashcards += [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category_cell.categoryID
                                                                                                       answerStatus:@"unanswered"
                                                                                                          recursive:YES];
                
                category.numberOfRedFlashcards += [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category_cell.categoryID
                                                                                         flashcardStatusName:@"red"
                                                                                                   recursive:YES];
                
                category.numberOfYellowFlashcards += [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category_cell.categoryID
                                                                                            flashcardStatusName:@"yellow"
                                                                                                      recursive:YES];
                
                category.numberOfGreenFlashcards += [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category_cell.categoryID
                                                                                           flashcardStatusName:@"green"
                                                                                                     recursive:YES];
                
                
            }

        }
        
		averageTime = 0;
        components = [[NSMutableArray alloc] init];
        resetAlert = [[UIAlertView alloc] initWithTitle:@"Reset"
                                                message:@"Reset all flashcards for this category? This operation can't be undone."
                                               delegate:self
                                      cancelButtonTitle:@"Cancel"
                                      otherButtonTitles:@"Reset", nil];
        
    }
    
    return self;
    
}
 

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    titleLabel.text = category.categoryName;
    
    NSInteger totalNumberOfFlashcards = category.numberOfCorrectFlashcards + category.numberOfIncorrectFlashcards + category.numberOfUnansweredFlashcards;
    
	if (totalNumberOfFlashcards == 0) {
		myTableView.hidden = YES;
		[Util displayAlertWithMessage:@"Don't have any question in this category." delegateObj:self tag:0];
	}
	else {
        myTableView.backgroundColor = [UIColor clearColor];
        
        if ([myTableView respondsToSelector:@selector(backgroundView)])
            myTableView.backgroundView = nil;
        
        [self loadStatisticsInformation];
    }
    
}

- (void)viewDidAppear:(BOOL)animated {
 
    [super viewDidAppear:animated];
    NSString *pageName = [NSString stringWithFormat:@"Statistics: %@", category.categoryName];
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:pageName
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}

- (IBAction)resetStats:(id)sender
{
    
    [resetAlert show];
    
}


- (void) loadStatisticsInformation {

    NSArray *times;
    double sum = 0;
    int count = 0;
    
    if (!bOverall) {
        times = [[FlashCardsDB instance] getTimesForEachQuestionWithCategoryID:category.categoryID];
        if(times.count) {
            for(NSNumber *time in times) {
                sum += [time doubleValue];
            }
            averageTime = sum / (double)(times.count);
        } else {
            averageTime = 0;
        }
    }
    else
    {
        NSMutableArray *categories;
        categories = [[[CategoryDB instance] getRootCategoriesForCategoryType:@"multiple-choice"] retain];
        
        for(Category *category_cell in categories) {
            times = [[FlashCardsDB instance] getTimesForEachQuestionWithCategoryID:category_cell.categoryID];
            if(times.count) {
                count += times.count;
                
                for(NSNumber *time in times) {
                    sum += [time doubleValue];
                }
            }
        }
        
        if (count) {
            averageTime = sum / (double)count;
        }
        else {
            averageTime = 0;
        }       

    }
    
    [pieChart removeFromSuperview];
    [pieChart release];
    pieChart = [[PCPieChart alloc] initWithFrame:CGRectMake(0, 0, myTableView.frame.size.width, myTableView.frame.size.width * 0.67)];
    [pieChart setDiameter:myTableView.frame.size.width * 0.45];
    [pieChart setSameColorLabel:YES];
    [pieChart setShowArrow:YES];
    
    [headerView removeFromSuperview];
    [headerView release];
    headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, myTableView.frame.size.width, pieChart.frame.size.height)];
    [headerView addSubview:pieChart];
    
    pieChart.center = CGPointMake(headerView.frame.size.width / 2.0f, headerView.frame.size.height / 2.0f);
    
}

#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	return 4;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return 1;
}

- (UIView *)tableView:(UITableView *)tv viewForHeaderInSection:(NSInteger)section{
	
    return headerView;		

}

-(CGFloat)tableView:(UITableView *)tv heightForHeaderInSection:(NSInteger)section{

    return headerView.frame.size.height;

}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
	static NSString* cellIdentifier=@"cellIdentifier";
	
	UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
	
	if(!cell){
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier] autorelease];
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
	}
	
	if (![Util isIPad]) {
		cell.textLabel.font = [UIFont boldSystemFontOfSize:16];
	}
	
    const int total = category.numberOfCorrectFlashcards + category.numberOfIncorrectFlashcards;
    
    if(indexPath.row == kTotalCellIndex) {
        cell.textLabel.text = [NSString stringWithFormat:@"%d Total Answered", category.numberOfCorrectFlashcards + category.numberOfIncorrectFlashcards];
    } else if(indexPath.row == kCorrectCellIndex) {
        const float percentage = total ? category.numberOfCorrectFlashcards / (float)(total) : 0;
        cell.textLabel.text = [NSString stringWithFormat:@"%.1f%% Correct", round(percentage * 100)];
    } else if(indexPath.row == kIncorrectCellIndex) {
        const float percentage = total ? category.numberOfIncorrectFlashcards / (float)(total) : 0;
        cell.textLabel.text = [NSString stringWithFormat:@"%.1f%% Incorrect", round(percentage * 100)];
    } else if(indexPath.row == kAverageCellIndex) {
        cell.textLabel.text = [NSString stringWithFormat:@"Average time/question: %.1f sec", averageTime];
    }

	return cell;	
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void) viewWillAppear:(BOOL)animated{
    
	[super viewWillAppear:animated];
    
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}


#pragma mark UIAlertViewDelegate methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if(alertView == resetAlert) {
        
        if(buttonIndex == 0) {
            //Don't do anything
        } else {
                        
            [[AchievementManager instance] resetAchievementsForCategory:category.categoryID];
            
            BOOL isReset = [[FlashCardsDB instance] resetFlashCardsWithCategoryID:category.categoryID
                                                                        recursive:YES];
            [self loadStatisticsInformation];
            
            [myTableView reloadData];
            
            if (isReset) {
                [Util displayAlertWithMessage:@"Statistics Reset Successfully." andTitle:@"Statitics" tag:0];
            }
            
        }
        
    } else {
      	if (buttonIndex == 0) {
            //[self.navigationController popViewControllerAnimated:YES];
        }
    }
    
}


@end
