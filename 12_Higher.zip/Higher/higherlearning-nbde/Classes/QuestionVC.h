//
//  QuestionVC.h

#import <UIKit/UIKit.h>
#import "FlashCard.h"
#import "AnswerCell.h"

@class QuestionVC;

@protocol QuestionVCDelegate <NSObject>
@optional
- (void)QuestionVCOnStarting:(QuestionVC *) questionVC;
@end

@interface QuestionVC : UIViewController <UITableViewDataSource, UITableViewDelegate, AnswerCellDelegate> {
	id<QuestionVCDelegate> delegate;
	
    UITableView* myTableView;
	
	FlashCard* flashCard;
	
    NSMutableArray *cells;

}


@property(nonatomic, assign) id<QuestionVCDelegate> delegate;
@property(nonatomic, retain) UITableView* myTableView;
@property(nonatomic, retain) FlashCard* flashCard;

- (void) initComponentsWithFlashCard:(FlashCard*) card;

@end
