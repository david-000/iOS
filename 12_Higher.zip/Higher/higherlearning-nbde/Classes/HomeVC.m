//
//  HomeVC.m

#import "HomeVC.h"
#import "OtherVC.h"
#import "FlashCardVC.h"
#import "StatusesVC.h"
#import "Util.h"
#import "StudyVC.h"
#import "QuizCategoryVC.h"
#import "AboutVC.h"
#import "BackgroundView.h"
#import "iPhoneProjectAppDelegate.h"
#import "GANTracker.h"

static NSString * kAppId = @"374888099244448";

@implementation HomeVC

@synthesize studyBtn;
@synthesize quizBtn;
@synthesize statsBtn;
@synthesize aboutBtn;
@synthesize upgradeButton;
@synthesize backgroundView;

#pragma FBShare

- (void)showFBLogin
{
    
    iPhoneProjectAppDelegate *idelegate = (iPhoneProjectAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    // Initialize Facebook
    idelegate.facebook = [[Facebook alloc] initWithAppId:kAppId andDelegate:self];
    
    // Check and retrieve authorization information
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"] && [defaults objectForKey:@"FBExpirationDateKey"]) {
        [idelegate facebook].accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
        [idelegate facebook].expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
    }
    
    NSArray *permissions = [NSArray arrayWithObjects:
                            @"offline_access", 
                            @"photo_upload", 
                            @"publish_stream", 
                            @"friends_about_me", 
                            @"friends_likes",
                            @"email", nil];
    
    if (![[idelegate facebook] isSessionValid]) {
        [[idelegate facebook] authorize:permissions];
    }
    else {
        //ALREADY LOGIN
    }
    
}

/**
 * Called when the user has logged in successfully.
 */
- (void)fbDidLogin {
    
    iPhoneProjectAppDelegate *idelegate = (iPhoneProjectAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NSLog(@"\n<><><>fbDidLogin : fbAccessToken: %@",[[idelegate facebook] accessToken]);
    
    [self storeAuthData:[[idelegate facebook] accessToken] expiresAt:[[idelegate facebook] expirationDate]];
    
}

-(void)fbDidExtendToken:(NSString *)accessToken expiresAt:(NSDate *)expiresAt {
    
}

/**
 * Called when the user canceled the authorization dialog.
 */
-(void)fbDidNotLogin:(BOOL)cancelled {
    //[pendingApiCallsController userDidNotGrantPermission];
    
    if(cancelled){
    }
}

/**
 * Called when the request logout has succeeded.
 */
- (void)fbDidLogout {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:@"FBAccessTokenKey"];
    [defaults removeObjectForKey:@"FBExpirationDateKey"];
    [defaults synchronize];
}

/**
 * Called when the session has expired.
 */
- (void)fbSessionInvalidated {
    UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:@"Auth Exception"
                              message:@"Your session has expired."
                              delegate:nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil,
                              nil];
    [alertView show];
    [alertView release];
    [self fbDidLogout];
}

- (void)storeAuthData:(NSString *)accessToken expiresAt:(NSDate *)expiresAt {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:accessToken forKey:@"FBAccessTokenKey"];
    [defaults setObject:expiresAt forKey:@"FBExpirationDateKey"];
    [defaults synchronize];
}

#pragma UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        [self showFBLogin];
    }
}

- (id)init {
 
    NSString *nib = NibName(@"HomeVC");
    self = [super initWithNibName:nib bundle:nil];
    if(self) {
        
    }
    
    return self;
    
}

- (void) dealloc{
    
    [studyBtn release];
    [quizBtn release];
    [statsBtn release];
    [aboutBtn release];
    [upgradeButton release];
     
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    [backgroundView setAlpha:1.0];
    
    //Set up fonts
    [studyBtn.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [studyBtn.titleLabel setTextColor:[UIColor darkGrayColor]];

    [quizBtn.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [quizBtn.titleLabel setTextColor:[UIColor darkGrayColor]];

    [statsBtn.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [statsBtn.titleLabel setTextColor:[UIColor darkGrayColor]];

    [aboutBtn.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
    [aboutBtn.titleLabel setTextColor:[UIColor darkGrayColor]];

    if([Util isFreeVersion]) {
        [upgradeButton.titleLabel setFont:[UIFont fontWithName:@"HelveticaRounded LT BoldCn" size:[Util fontSizeMenus]]];
        [upgradeButton.titleLabel setTextColor:[UIColor darkGrayColor]];
    } else {
        upgradeButton.hidden = YES;
    }
    
}

- (void)viewDidAppear:(BOOL)animated {
 
    [super viewDidAppear:animated];
    
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Main Menu"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
     
}

- (IBAction) pressOnStudy:(id)sender {
    
    StudyVC* studyVC = [[StudyVC alloc] init];
    [self.navigationController pushViewController:studyVC animated:YES];
    [studyVC release];
    
}

- (IBAction) pressOnQuiz:(id)sender{
    
    QuizCategoryVC *controller = [[QuizCategoryVC alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
     
}

- (IBAction) pressOnStats:(id)sender{
    
    StatusesVC *controller = [[StatusesVC alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

- (IBAction) pressOnAbout:(id)sender{
    
    AboutVC *controller = [[AboutVC alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

- (IBAction) onUpgradeButton:(id)sender {
     
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Upgrade"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }

    //Open iTunes
    [[UIApplication sharedApplication] openURL:[Util fullVersionURL]];
     
}


- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void) viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
	
}


- (BOOL)shouldAutorotate {
 
    return NO;
    
}


@end

