//
//  Image.h
//  iPhoneProject
//
//  Created by Componica on 9/11/12.
//
//

#import <Foundation/Foundation.h>

@interface Image : NSObject<NSCopying> {
	NSInteger imageID;
	NSString* imageName;
}

@property(nonatomic, assign) NSInteger imageID;
@property(nonatomic, retain) NSString* imageName;

- (id)initWithImageID:(NSInteger)_imageID
            imageName:(const char *)_imageName;

@end