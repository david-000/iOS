//
//  OtherVC.m

#import "StatusesVC.h"
#import "Util.h"
#import "FlashCardVC.h"
#import "CategoryDB.h"
#import "Category.h"
#import "StatisticsCell.h"
#import "FlashCardsDB.h"
#import "Flashcard.h"
#import "StudyStatisticsVC.h"
#import "GANTracker.h"

@interface StatusesVC (Private)

- (void)computeStatistics;

@end

@implementation StatusesVC

@synthesize myTableView;
@synthesize strongestSubjectLabel;
@synthesize weakestSubjectLabel;
@synthesize averageTimeLabel;

- (void) dealloc{

    myTableView.delegate = nil;
    myTableView.dataSource = nil;
    [myTableView release];
    [strongestSubjectLabel release];
    [weakestSubjectLabel release];
    [averageTimeLabel release];
    [categories release];
	[cells release];
    [metrics release];
    [super dealloc];
    
}

- (id) init {
 
    NSString *nib = NibName(@"StatusesVC");
    self = [super initWithNibName:nib bundle:nil];
    if(self) {
        
        titleLabel.text = @"Study Statistics";
        cells = [[NSMutableArray alloc] init];
        
        categories = [[[CategoryDB instance] getRootCategoriesForCategoryType:@"multiple-choice"] retain];
        [self computeStatistics];
        
    }
    
    return self;
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    Category *strongestCategory = [metrics objectForKey:@"strongest"];
    Category *weakestCategory = [metrics objectForKey:@"weakest"];
    NSNumber *averageTime = [metrics objectForKey:@"average_time"];

    strongestSubjectLabel.adjustsFontSizeToFitWidth = YES;
    if(strongestCategory) {
        strongestSubjectLabel.text = strongestCategory.categoryName;
    } else {
        strongestSubjectLabel.text = @"n/a";
    }
    
    weakestSubjectLabel.adjustsFontSizeToFitWidth = YES;
    if(weakestCategory) {
        weakestSubjectLabel.text = weakestCategory.categoryName;
    } else {
        weakestSubjectLabel.text = @"n/a";
    }
    
    averageTimeLabel.adjustsFontSizeToFitWidth = YES;
    
    if([averageTime floatValue]) {
        averageTimeLabel.text = [NSString stringWithFormat:@"%.1f seconds", [averageTime floatValue]];
    } else {
        averageTimeLabel.text = @"n/a";
    }
    
    for(Category *category in categories) {
    
        StatisticsCell *cell = [[StatisticsCell alloc] initWithText:category.categoryName
                                                              width:myTableView.frame.size.width];
        [cells addObject:cell];
        [cell release];
        
    }
    
    StatisticsCell *overallcell = [[StatisticsCell alloc] initWithText:@"Overall statistics"
                                                          width:myTableView.frame.size.width];
    [cells addObject:overallcell];
    [overallcell release];

}

- (void)viewDidAppear:(BOOL)animated {
 
    [super viewDidAppear:animated];
    
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Statistics Menu"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
    for(StatisticsCell *cell in cells) {
        [cell highlight:NO];
    }
 
    [myTableView flashScrollIndicators];
    
}

#pragma mark -
#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
	return [cells count];
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return 1;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    return [cells objectAtIndex:indexPath.row];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    StatisticsCell *cell = (StatisticsCell *)[myTableView cellForRowAtIndexPath:indexPath];
    [cell highlight:YES];

    Category *category;
    StudyStatisticsVC *controller;
    
    if ([categories count] <= indexPath.row) {
        category = nil;
        controller = [[StudyStatisticsVC alloc] initWithCategory:category];
    }
    else
    {
        category = [categories objectAtIndex:indexPath.row];
        controller = [[StudyStatisticsVC alloc] initWithCategory:category];
    }
    
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [cells objectAtIndex:indexPath.row];
    return cell.bounds.size.height;
    
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
 
    return @"Categories";
    
}

#pragma mark - View lifecycle

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
}

- (void) viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
	
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}


@end

@implementation StatusesVC (Private)

- (void)computeStatistics {
 
    //Verbatim From Alec:
    //Weakest category appears as N/a until a student has answered questions from 3 of the major categories (d. anatomy, Biochem/Phys, Micor/patho). After at least 3 major categories have answered questions in them base weakest as the one with the least percentage correct.
    
    
    Category *strongestCategory = nil;
    Category *weakestCategory = nil;
    float bestPercentage = 0;
    float worstPercentage = 1;

    const NSInteger requiredNumberOfValidCategories = 3;
    NSInteger numberOfValidCategories = 0;
    
    
    for(Category *category in categories) {
         
        category.numberOfCorrectFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                            answerStatus:@"correct"
                                                                                               recursive:YES];
        
        category.numberOfIncorrectFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                              answerStatus:@"incorrect"
                                                                                                 recursive:YES];
        
        category.numberOfUnansweredFlashcards = [[FlashCardsDB instance] getCountOfFlashCardsWithCategoryID:category.categoryID
                                                                                               answerStatus:@"unanswered"
                                                                                                  recursive:YES];

         
        const NSInteger totalNumberOfCards = category.numberOfCorrectFlashcards + category.numberOfIncorrectFlashcards + category.numberOfUnansweredFlashcards;
        const NSInteger totalNumberOfAnsweredCards = category.numberOfCorrectFlashcards + category.numberOfIncorrectFlashcards;
        const float percentage = totalNumberOfCards ? category.numberOfCorrectFlashcards / (float)(totalNumberOfCards) : 0;

        
        if(totalNumberOfAnsweredCards > 0) {

            numberOfValidCategories++;
            
            if(percentage >= bestPercentage) {
                bestPercentage = percentage;
                strongestCategory = category;
            }

            if(percentage <= worstPercentage) {
                worstPercentage = percentage;
                weakestCategory = category;
            }
        
        }
        
    }
        
    const float averageTime = [[FlashCardsDB instance] getAverageTimeForEachQuestion];
    
    [metrics release];
    metrics = [[NSMutableDictionary alloc] init];
    if(weakestCategory && numberOfValidCategories >= requiredNumberOfValidCategories) {
        [metrics setObject:weakestCategory forKey:@"weakest"];
    }
    
    if(strongestCategory && numberOfValidCategories >= 1) {
        [metrics setObject:strongestCategory forKey:@"strongest"];
    }
    
    [metrics setObject:[NSNumber numberWithFloat:averageTime] forKey:@"average_time"];

    
}




@end
