//
//  TMTextfieldCell.m
//  MobileWorkforce
//
//  Created by Collin Ruffenach on 10/22/10.
//  Copyright 2010 ELC Tech. All rights reserved.
//

#import "QuestionCell.h"
#import "Util.h"
#import "RoundedRectView.h"
#import "Global.h"

#define kVerticalPadding 5
#define kBackgroundHorizontalPadding 10
#define kTextHorizontalPadding 15
#define kMinHeightPhone 60
#define kMinHeightPad 90
#define kCornerRadius 20
#define kOutlineStrokeWidth 6

@implementation QuestionCell

@synthesize contentLabel;


- (id)initWithQuestionText:(NSString *)questionText
         extraQuestionText:(NSString *)extraQuestionText
       flashcardStatusName:(NSString *)flashcardStatusName
                     width:(CGFloat)width {
 
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    if(self) {
        
        const CGFloat availableWidth = width - 2 * kBackgroundHorizontalPadding - 2 * kTextHorizontalPadding;
        
        //Compute the height of the text
        UIFont *font = [UIFont boldSystemFontOfSize:[Util fontSizeFlashCards]];

        CGSize textSize = [questionText sizeWithFont:font
                                   constrainedToSize:CGSizeMake(availableWidth, NSIntegerMax)
                                       lineBreakMode:NSLineBreakByWordWrapping];
        
        CGSize extraTextSize = extraQuestionText ? [extraQuestionText sizeWithFont:font
                                                                 constrainedToSize:CGSizeMake(availableWidth, NSIntegerMax)
                                                                     lineBreakMode:NSLineBreakByWordWrapping] : CGSizeZero;
        
        CGFloat height = [Util isIPad] ? kMinHeightPad : kMinHeightPhone;
        height = fmax(height, extraTextSize.height + textSize.height + kVerticalPadding * 4);
        
        [self setBackgroundColor:[UIColor clearColor]];
        [self setFrame:CGRectMake(0, 0, width, height)];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.accessoryType = UITableViewCellAccessoryNone;
        
        const NSInteger backgroundWidth = width - kBackgroundHorizontalPadding * 2;
        const NSInteger backgroundHeight = height - kVerticalPadding * 2;
    
        backgroundView = [[RoundedRectView alloc] initWithFrame:CGRectMake(0, 0, backgroundWidth, backgroundHeight)];
        backgroundView.cornerRadius = kCornerRadius;
        backgroundView.center = self.center;
        backgroundView.strokeWidth = kOutlineStrokeWidth;
        
        NSInteger contentX = backgroundView.frame.origin.x + kTextHorizontalPadding;
        NSInteger contentY = backgroundView.frame.origin.y + kVerticalPadding;
        NSInteger contentWidth = backgroundView.frame.size.width - kTextHorizontalPadding * 2;
        NSInteger contentHeight = backgroundView.frame.size.height - kVerticalPadding * 2 - extraTextSize.height;
        
        contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(contentX, contentY, contentWidth, contentHeight)];
		[contentLabel setBackgroundColor:[UIColor clearColor]];
		[contentLabel setTextColor:[UIColor blackColor]];
		[contentLabel setFont:font];
		[contentLabel setTextAlignment:NSTextAlignmentLeft];
		contentLabel.lineBreakMode = NSLineBreakByWordWrapping;
		contentLabel.numberOfLines = 0;
        contentLabel.text = questionText;
        
        if(extraQuestionText) {
            NSInteger extraX = contentX;
            NSInteger extraY = contentY + contentHeight;
            NSInteger extraWidth = extraTextSize.width;
            NSInteger extraHeight = extraTextSize.height;
            extraLabel = [[UILabel alloc] initWithFrame:CGRectMake(extraX, extraY, extraWidth, extraHeight)];
            extraLabel.backgroundColor = [UIColor clearColor];
            extraLabel.textColor = [UIColor redColor];
            extraLabel.font = [UIFont italicSystemFontOfSize:[Util fontSizeFlashCards] - 1];
            extraLabel.textAlignment = NSTextAlignmentLeft;
            extraLabel.numberOfLines = 1;
            extraLabel.text = extraQuestionText;
        }
        
        if([flashcardStatusName isEqualToString:@"unanswered"]) {
            [backgroundView setStrokeColor:[UIColor whiteColor]];
        } else if([flashcardStatusName isEqualToString:@"red"]) {
            [backgroundView setStrokeColor:[UIColor redColor]];
        } else if([flashcardStatusName isEqualToString:@"yellow"]) {
            [backgroundView setStrokeColor:[UIColor yellowColor]];
        } else if([flashcardStatusName isEqualToString:@"green"]) {
            [backgroundView setStrokeColor:[UIColor greenColor]];
        }        
        
        [self addSubview:backgroundView];
		[self addSubview:contentLabel];
        [self addSubview:extraLabel];
        
    }

    return self;
}
 
- (void)layoutSubviews {
    
	[super layoutSubviews];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {

    [super setSelected:selected animated:animated];
    
}

- (void)dealloc {

    [contentLabel release];
    [extraLabel release];
    [backgroundView release];
    [super dealloc];
    
}

@end
