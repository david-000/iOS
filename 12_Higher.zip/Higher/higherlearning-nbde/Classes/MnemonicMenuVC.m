//
//  OtherVC.m

#import "MnemonicMenuVC.h"
#import "MnemonicsListVC.h"
#import "Util.h"
#import "GANTracker.h"

#define kImportantCellIndex 0
#define kAllCellIndex 1

@interface MnemonicMenuVC (Private)

- (void)onImportantButton;
- (void)onAllButton;
- (void)onSavedButton;

@end

@implementation MnemonicMenuVC

- (void) dealloc{
    [super dealloc];
}


- (id)init {
    
    NSString *nib = NibName(@"MnemonicMenuVC");
    self = [super initWithNibName:nib bundle:nil];
    if(self) {

        //Create the cells
        UITableViewCell *importantCell;
        UITableViewCell *allCell;
        
        CGRect btnRect;
        
        if ([[UIDevice currentDevice] userInterfaceIdiom] != UIUserInterfaceIdiomPad) {
            btnRect = CGRectMake(0, 0, 287, 42);
        }
        else
        {
            btnRect = CGRectMake(0, 0, 686, 102);
        }

        importantCell = [self createCellWithTitleandRect:@"Important Mnemonics" rect:btnRect selector:@selector(onImportantButton)];
        allCell = [self createCellWithTitleandRect:@"All Mnemonics" rect:btnRect selector:@selector(onAllButton)];
        //UITableViewCell *savedCell = [self createCellWithTitle:@"Saved Mnemonics" selector:@selector(onSavedButton)];
        
        //Add the cells to an array
        [cells addObject:importantCell];
        [cells addObject:allCell];
        //[cells addObject:savedCell];
        
    }
    
    return self;

}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewDidAppear:(BOOL)animated {
 
    [super viewDidAppear:animated];
    
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Mnemonics Menu"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}

#pragma mark -
#pragma mark UITableViewDelegate

/*
- (void) sendMailUs{
	MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
	picker.navigationBar.barStyle = UIBarStyleBlackOpaque;
    picker.mailComposeDelegate = self;
    
    //set subject
    [picker setSubject:@"Dental Decks - Suggest mnemonics"];
	
	//set Recipients
	[picker setToRecipients:[NSArray arrayWithObject:CUSTOMER_EMAIL]];
	
	//set body
    NSString *emailBody = @"What do you think of this application?";
    [picker setMessageBody:emailBody isHTML:YES];
	
    if (picker != nil) {
        [self presentModalViewController:picker animated:YES];
        [picker release];
    }
}
*/
 
#pragma -
#pragma MFMailComposeViewControllerDelegate
/*
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    // Notifies users about errors associated with the interface
    switch (result)
    {
        case MFMailComposeResultCancelled:
			//[Util displayAlertWithMessage:@"Email is canceled." tag:0];
            break;
        case MFMailComposeResultSaved:
			//[Util displayAlertWithMessage:@"Email is saved." tag:0];
            break;
        case MFMailComposeResultSent:
			//[Util displayAlertWithMessage:@"Send email successfully." tag:0];
            break;
        case MFMailComposeResultFailed:
			//[Util displayAlertWithMessage:@"Send email fail." tag:0];
            break;
        default:
			//[Util displayAlertWithMessage:@"Email is not sent." tag:0];
            break;
    }
    
    [self dismissModalViewControllerAnimated:YES];
}
*/
 
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void) viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

@end

@implementation MnemonicMenuVC (Private)

- (void)onImportantButton {
    
    MnemonicsListVC* controller = [[MnemonicsListVC alloc] initWithMnemonicTypeName:@"important"];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

- (void)onAllButton {
    
    MnemonicsListVC* controller = [[MnemonicsListVC alloc] initWithMnemonicTypeName:@"all"];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

- (void)onSavedButton {
    
    MnemonicsListVC* controller = [[MnemonicsListVC alloc] initWithMnemonicTypeName:@"saved"];
    [self.navigationController pushViewController:controller animated:YES];
    [controller release];
    
}

@end
