//
//  StudentsDB.h
//  MySQLiteProject
//


#import <Foundation/Foundation.h>
#import "Database.h"

@class Category;


@interface CategoryDB : Database {
    
    
}

+ (CategoryDB *) instance;

- (NSArray *)getAllCategoryIds;

- (NSMutableArray *)getRootCategoriesForCategoryType:(NSString *)categoryTypeName;
 
- (Category *) getCategory:(NSInteger)categoryId;

- (NSMutableArray *) getCategoryHeirarchy:(NSInteger)categoryId;

- (NSMutableArray *) getChildCategoriesForCategory:(NSInteger)catgoryId
                                         recursive:(BOOL)recursive;

- (BOOL) updateCategory:(NSInteger)categoryId
                enabled:(BOOL)enabled
              recursive:(BOOL)recursive;

- (BOOL) updateChildCategoriesForCategory:(NSInteger)categoryId
                                  enabled:(BOOL)enabled
                                recursive:(BOOL)recursive;

- (BOOL)isCategoryEnabledByDefault:(NSInteger) categoryId;


@end
