//
//  TerminologyFlashcardVC.m
//  iPhoneProject
//
//  Created by MacBook on 7/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
#import <QuartzCore/QuartzCore.h>
#import "TerminologyFlashcardVC.h"
#import "Global.h"
#import "Util.h"
#import "NSMutableArray+Shuffle.h"
#import "FlashCardsDB.h"
#import "TerminologyQuestionVC.h"
#import "TerminologyAnswerVC.h"
#import "GANTracker.h"

@implementation TerminologyFlashcardVC

- (void)dealloc {
    
    [[containView layer] removeAllAnimations];
    
    [super dealloc];
    
}


- (id)init {
 
    self = [super init];
    if(self) {
    }
    
    return self;
}
 


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    
    [super viewDidLoad];
	
}

- (void) viewDidAppear:(BOOL)animated{

	[super viewDidAppear:animated];
 
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Terminology Flashcards"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}


- (IBAction) doGoBack:(id)sender {
	[self.navigationController popViewControllerAnimated:YES];
}


- (IBAction) doSubmit:(id) sender{

    if(self.currentFlashCard.answered == NO) {
        
        //calculate answer time for this question...
        NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:startTime];
        [[FlashCardsDB instance] updateFlashCardWithNewTime:(double)interval cardID:self.currentFlashCard.cardID];
        [[FlashCardsDB instance] updateFlashCardWithAnswerStatus:@"correct" cardID:self.currentFlashCard.cardID];
        [startTime release];
        startTime = nil;
        
        [self.currentFlashCard setAnswerStatusName:@"correct"];
        self.currentFlashCard.answered = YES;
    }
    
    [answerVC initComponentsWithFlashCard:self.currentFlashCard];
    [answerVC.myTableView scrollRectToVisible:questionVC.myTableView.bounds
                                     animated:NO];
    
    
    self.view.userInteractionEnabled = NO;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.75];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:containView cache:YES];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:)];
    
    [questionVC.view removeFromSuperview];
    [containView addSubview:answerVC.view];
    
    [UIView commitAnimations];
    
    footerView.userInteractionEnabled = NO;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.75];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:footerView cache:YES];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:)];
    
    [self flipFooter];
    
    [UIView commitAnimations];
     
}

 
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {
    [super viewDidUnload];
}


- (void)setupViews {
    
    btnItemRed.hidden = YES;
	btnItemYellow.hidden = YES;
	btnItemGreen.hidden = YES;
    nextButton.hidden = YES;
    rationalePreviewView.hidden = YES;
    retryButton.hidden = YES;
    quitButton.hidden = YES;

    NSString* str = NibName(@"QuestionVC");
    questionVC = [[TerminologyQuestionVC alloc] initWithNibName:str
                                                         bundle:nil];
    questionVC.delegate = self;
    questionVC.view.frame = CGRectMake(0, 0, containView.frame.size.width, containView.frame.size.height);
    questionVC.myTableView.frame = questionVC.view.frame;
    [questionVC.view setBackgroundColor:[UIColor clearColor]];
    
    NSString* str2 = NibName(@"AnswerVC");
	answerVC = [[TerminologyAnswerVC alloc] initWithNibName:str2 bundle:nil];
    answerVC.view.frame = CGRectMake(0, 0, containView.frame.size.width, containView.frame.size.height);
	answerVC.myTableView.frame = answerVC.view.frame;
    [answerVC.view setBackgroundColor:[UIColor clearColor]];

}

- (void)loadFlashcards {
    
    unansweredFlashcardIds = [[[FlashCardsDB instance] getEnabledFlashcardIdsWithStatus:@"unanswered"
                                                                       categoryTypeName:@"terminology"] retain];
    [unansweredFlashcardIds shuffle];
    
    redFlashcardIds = [[[FlashCardsDB instance] getEnabledFlashcardIdsWithStatus:@"red"
                                                                categoryTypeName:@"terminology"] retain];
    [redFlashcardIds shuffle];
    
    yellowFlashcardIds = [[[FlashCardsDB instance] getEnabledFlashcardIdsWithStatus:@"yellow"
                                                                   categoryTypeName:@"terminology"] retain];
    [yellowFlashcardIds shuffle];
    
    greenFlashcardIds = [[[FlashCardsDB instance] getEnabledFlashcardIdsWithStatus:@"green"
                                                                categoryTypeName:@"terminology"] retain];
    [greenFlashcardIds shuffle];
    
}


- (void)updateViews {

    [self updateTitle];
    
    [questionVC.view removeFromSuperview];
    [answerVC.view removeFromSuperview];
    
    
    NSInteger containerX = 0;
    NSInteger containerY = topBarView.frame.size.height;
    NSInteger containerWidth = self.view.frame.size.width;
    NSInteger containerHeight = self.view.frame.size.height - topBarView.frame.size.height - footerView.frame.size.height;
    containView.frame = CGRectMake(containerX, containerY, containerWidth, containerHeight);
    answerVC.view.frame = containView.bounds;
    answerVC.myTableView.frame = containView.bounds;
    questionVC.view.frame = containView.bounds;
    questionVC.myTableView.frame = containView.bounds;

    footerView.hidden = NO;
    btnItemRed.hidden = YES;
    btnItemYellow.hidden = YES;
    btnItemGreen.hidden = YES;
    btnItemSubmit.hidden = NO;
    
    [containView addSubview:questionVC.view];
    
    [answerVC initComponentsWithFlashCard:self.currentFlashCard];
    [answerVC.myTableView scrollRectToVisible:answerVC.myTableView.bounds
                                     animated:NO];
    
    [questionVC initComponentsWithFlashCard:self.currentFlashCard];
    [questionVC.myTableView scrollRectToVisible:questionVC.myTableView.bounds
                                       animated:NO];
    
}


- (BOOL)shouldAutorotate {
    
    return NO;
    
}


#pragma mark CAAnimation delegate methods

- (void)animationDidStop:(CAAnimation *)theAnimation finished:(BOOL)flag {
    
    self.view.userInteractionEnabled = YES;
    footerView.userInteractionEnabled = YES;
    
}


@end
