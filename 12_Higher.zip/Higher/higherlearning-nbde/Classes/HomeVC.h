//
//  HomeVC.h

#import <UIKit/UIKit.h>
#import "FBConnect.h"
#import "NavigationItemVC.h"

@class BackgroundView;

@interface HomeVC : UIViewController <FBRequestDelegate, FBDialogDelegate, FBSessionDelegate, UIAlertViewDelegate>{
    
    IBOutlet UIButton* studyBtn;
	IBOutlet UIButton* quizBtn;
	IBOutlet UIButton* statsBtn;
	IBOutlet UIButton* aboutBtn;
    IBOutlet UIButton *upgradeButton;
    IBOutlet BackgroundView *backgroundView;
    
}

@property(nonatomic, retain) UIButton *studyBtn;
@property(nonatomic, retain) UIButton *quizBtn;
@property(nonatomic, retain) UIButton *statsBtn;
@property(nonatomic, retain) UIButton *aboutBtn;
@property(nonatomic, retain) UIButton *upgradeButton;
@property(nonatomic, retain) BackgroundView *backgroundView;

- (IBAction) pressOnStudy:(id)sender;
- (IBAction) pressOnQuiz:(id)sender;
- (IBAction) pressOnStats:(id)sender;
- (IBAction) pressOnAbout:(id)sender;
- (IBAction) onUpgradeButton:(id)sender;

@end
    