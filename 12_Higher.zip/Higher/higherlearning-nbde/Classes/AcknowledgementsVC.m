//
//  AcknowledgementsVC.m
//  iPhoneProject
//
//  Created by Componica on 8/29/12.
//
//

#import "AcknowledgementsVC.h"
#import "Util.h"
#import "GANTracker.h"

@interface AcknowledgementsVC ()

@end

@implementation AcknowledgementsVC


- (id) init {
 
    NSString *nib = NibName(@"AcknowledgementsVC");
    self = [super initWithNibName:nib bundle:nil];
    if(self) {
        
    }
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void) viewDidAppear:(BOOL)animated {
 
    [super viewDidAppear:animated];
    NSError *error = nil;
    if(![[GANTracker sharedTracker] trackPageview:@"Acknowledgements"
                                        withError:&error]) {
        
        NSLog(@"Could not track pageview: %@", error);
    }
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

- (IBAction)doGoBack:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

@end
