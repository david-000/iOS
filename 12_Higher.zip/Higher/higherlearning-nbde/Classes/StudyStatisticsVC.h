//
//  StudyStatisticsVC.h
//  iPhoneProject
//
//  Created by Componica on 9/24/12.
//
//

#import "StatisticsVC.h"

@interface StudyStatisticsVC : StatisticsVC {
    
}

- (id)initWithCategory:(Category *)_category;

@end
