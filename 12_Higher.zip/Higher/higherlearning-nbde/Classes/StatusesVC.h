//
//  OtherVC.h

#import <UIKit/UIKit.h>
#import "NavigationItemVC.h"

@class StatisticsCell;

@interface StatusesVC : NavigationItemVC {

    IBOutlet UITableView* myTableView;
    IBOutlet UILabel *strongestSubjectLabel;
    IBOutlet UILabel *weakestSubjectLabel;
    IBOutlet UILabel *averageTimeLabel;
    
    NSMutableArray *categories;
    NSMutableArray *cells;
    NSMutableDictionary *metrics;
    
}

@property(nonatomic, retain) UITableView *myTableView;
@property(nonatomic, retain) UILabel *strongestSubjectLabel;
@property(nonatomic, retain) UILabel *weakestSubjectLabel;
@property(nonatomic, retain) UILabel *averageTimeLabel;

@end
