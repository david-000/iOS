//
//  TMTextfieldCell.h
//  MobileWorkforce
//
//  Created by Collin Ruffenach on 10/22/10.
//  Copyright 2010 ELC Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RoundedRectView;
@class AnswerCell;
@class Answer;

@protocol AnswerCellDelegate

- (void)answerCellSelected:(AnswerCell *)cell;

@end

@interface AnswerCell : UITableViewCell {

    RoundedRectView *backgroundView;
    RoundedRectView *grayedOutView;
	UILabel *contentLabel;
    UIButton *crossButton;
    UIButton *selectButton;
    UIImageView *responseImageView;
    Answer *answer;
    NSObject<AnswerCellDelegate> *delegate;
    
}

@property (nonatomic, retain) UILabel *contentLabel;
@property(nonatomic, retain) Answer *answer;
@property(nonatomic, assign) NSObject<AnswerCellDelegate> *delegate;

- (id)initWithAnswer:(Answer *)_answer
               width:(CGFloat)width
            delegate:(NSObject<AnswerCellDelegate> *)_delegate
       textAlignment:(UITextAlignment)textAlignment;


- (void)markCell;

- (void)select:(BOOL)select;

@end