//
//  QuestionVC.m

#import <QuartzCore/QuartzCore.h>
#import "QuestionVC.h"
#import "QuestionCell.h"
#import "AnswerCell.h"
#import "Util.h"

@implementation QuestionVC

@synthesize flashCard, delegate, myTableView;

- (void)dealloc {

    myTableView.delegate = nil;
    myTableView.dataSource = nil;
    [myTableView release];
    [flashCard release];
	[cells release];
    [super dealloc];
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        // Custom initialization.
		flashCard = nil;
        cells = [[NSMutableArray alloc] init];
        
    }
    return self;
}

- (void) initComponentsWithFlashCard:(FlashCard*) card{
    
	self.flashCard = card;
	
    [cells removeAllObjects];
    QuestionCell *questionCell = [[QuestionCell alloc] initWithQuestionText:flashCard.question
                                                          extraQuestionText:flashCard.extraQuestionText
                                                        flashcardStatusName:flashCard.flashcardStatusName
                                                                      width:myTableView.bounds.size.width];
    [cells addObject:[NSArray arrayWithObject:questionCell]];
    [questionCell release];
    
    NSMutableArray *answerCells = [NSMutableArray array];
    for(Answer *answer in self.flashCard.answers) {
        AnswerCell *answerCell = [[AnswerCell alloc] initWithAnswer:answer
                                                              width:myTableView.bounds.size.width
                                                           delegate:self
                                                      textAlignment:NSTextAlignmentLeft];
        [answerCells addObject:answerCell];
        [answerCell release];
    }
    [cells addObject:answerCells];
        
    myTableView.backgroundColor = [UIColor clearColor];
    myTableView.backgroundView = nil;
    [myTableView scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:NO];
    [myTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [myTableView reloadData];
        
	//starting question....
	if (delegate && [delegate respondsToSelector:@selector(QuestionVCOnStarting:)]) {
		[delegate QuestionVCOnStarting:self];
	}
    
	
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    
    [super viewDidLoad];
}

- (BOOL)shouldAutorotate {
    
    return NO;
    
}

#pragma mark UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [[cells objectAtIndex:section] count];
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
	return [cells count];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [[cells objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    return cell.bounds.size.height;
     
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
   	return [[cells objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

#pragma mark AnswerCellDelegate methods
- (void)answerCellSelected:(AnswerCell *)cell {
    
    if(flashCard.numberOfCorrectAnswers > 1) {
        //If there is more than one answer to this flashcard, allow multiple selections
        [cell select:!cell.answer.selected];
    } else {
        //If there is only one answer to this flashcard, don't allow multiple selections
        if(cell.selected) {
            [cell select:NO];
        } else {
            //Deselect the rest of the cells and select this one
            NSArray *answerCells = [cells objectAtIndex:1];
            for(AnswerCell *answerCell in answerCells) {
                [answerCell select:NO];
            }
            [cell select:YES];
        }
        
    }
    
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {
    [super viewDidUnload];
}


@end
