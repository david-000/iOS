//
//  Util.h
//  TaskManager
//

#import <Foundation/Foundation.h>

@interface Util : NSObject {
    
}

//+ (void)removeDBs;

+ (void)displayAlertWithMessage:(NSString *)msg andTitle:(NSString *)title tag:(NSInteger) tag;

+ (void)displayAlertWithMessage:(NSString *)msg tag:(NSInteger) tag;

+ (void)displayAlertWithMessage:(NSString *)msg delegateObj:(id) obj tag:(NSInteger) tag;

+ (void)displayConfirmWithMessage:(NSString *)msg delegateObj:(id) obj tag:(NSInteger) tag;

+ (NSString*) genProjectPhotoName;

+ (BOOL) checkExistingOfDirectoryAtPath:(NSString*) path;

+ (BOOL) checkExistingOfFileAtPath:(NSString*) path;

+ (void) createDirectoryAtPath:(NSString*) path;

+ (void) closeDirectoryAtPath:(NSString*) path;

+ (void) closeFileAtPath:(NSString*) path;

+ (void) copyFileFromPath:(NSString*) fromFile to:(NSString*) toFile;

+ (BOOL) checkCameraAvailable;

+ (BOOL) checkIsIPadVersion;

+ (BOOL) compareDate:(NSDate*) date1 isSmaller:(NSDate*) date2;

+ (BOOL) compareDate:(NSDate*) date1 isEqualTo:(NSDate*) date2;

+ (BOOL) checkStartDateAndEndDate:(NSDate*) date1 andEndDate:(NSDate*) date2;

+ (BOOL)isIPad; 

+ (NSString*) trimString:(NSString*) string;

+ (NSString*) formatMnemonics:(NSString*) string;

+ (BOOL) checkiOSGreaterOrEqual5_0;

+ (NSString*) standardizeLinkString :(NSString *)strInput;

+ (BOOL) checkString:(NSString*) str containSubString:(NSString*) subStr;

+ (int)fontSizeMenus;

+ (int)fontSizeFlashCards;

+ (int)heightForMenuCell;

+ (int)heightForYieldMenuCell;

+ (int)WidthForMenuCell;

+ (int)heightForTopBar;

+ (int)UIHeight;

+ (int)UIWidth;

+ (BOOL)isFreeVersion;

+ (NSString *)databaseName;

+ (NSURL *)fullVersionURL;

NSString * ResName(NSString* fileName);
NSString * ResJpegName(NSString* fileName);
NSString * ResPngName(NSString* fileName);
NSString * ResPlistName(NSString* fileName);
NSString * NibName(NSString* fileName);
@end
