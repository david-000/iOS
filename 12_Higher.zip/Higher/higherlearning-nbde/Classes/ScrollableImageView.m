//
//  ScrollableImageView.m
//  iPhoneProject
//
//  Created by Componica on 10/2/12.
//
//

#import "ScrollableImageView.h"
#import "Util.h"

#define kInstructionLabelHeight 30

@interface ScrollableImageView (Private)

- (CGRect)centeredFrameForScrollView:(UIScrollView *)scroll andUIView:(UIView *)rView;

@end

@implementation ScrollableImageView

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if(self) {

        self.backgroundColor = [UIColor whiteColor];
        
        instructionLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        
        int nFontSize = 14;
        if( [Util isIPad] == true )
            nFontSize = 30;
        instructionLabel.font = [UIFont boldSystemFontOfSize:nFontSize];
        instructionLabel.text = @"Pinch to zoom - Drag to scroll";
        instructionLabel.backgroundColor = [UIColor clearColor];
        instructionLabel.textColor = [UIColor whiteColor];
        [instructionLabel sizeToFit];
        [self addSubview:instructionLabel];
        instructionLabel.center = CGPointMake(self.center.x, instructionLabel.frame.size.height / 2.0f);
        
    }
    
    return self;
    
}

- (void)setImage:(UIImage *)image {
    
    [scrollView removeFromSuperview];
    [scrollView release];
    [imageView removeFromSuperview];
    [imageView release];
    
    scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, instructionLabel.frame.size.height, self.frame.size.width, self.frame.size.height - instructionLabel.frame.size.height)];
    scrollView.contentMode = UIViewContentModeScaleAspectFit;
    scrollView.delegate = self;
    [self addSubview:scrollView];
    
    imageView = [[UIImageView alloc] init];
    [scrollView addSubview:imageView];
    [scrollView setContentSize:CGSizeMake(image.size.width, image.size.height)];
    const float xScale = scrollView.bounds.size.width / image.size.width;
    const float yScale = scrollView.bounds.size.height / image.size.height;
    scrollView.minimumZoomScale = fmin(xScale, yScale);
    scrollView.maximumZoomScale = 3 * scrollView.minimumZoomScale;
    imageView.image = image;
    imageView.frame = CGRectMake(0, 0, image.size.width, image.size.height);
    [scrollView setZoomScale:scrollView.minimumZoomScale animated:NO];
        
}


- (void) dealloc {
 
    [imageView release];
    [scrollView release];
    [instructionLabel release];
    [super dealloc];
    
}


- (BOOL)shouldAutorotate {
    
    return NO;
    
}

#pragma mark UIScrollViewDelegate methods

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
 
    return imageView;
    
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView_ {
     
    imageView.frame = [self centeredFrameForScrollView:scrollView andUIView:imageView];
    
}

@end


@implementation ScrollableImageView (Private)

- (CGRect)centeredFrameForScrollView:(UIScrollView *)scroll andUIView:(UIView *)rView {
    
    CGSize boundsSize = scroll.bounds.size;
    CGRect frameToCenter = rView.frame;
    // center horizontally
    if (frameToCenter.size.width < boundsSize.width) {
        frameToCenter.origin.x = (boundsSize.width - frameToCenter.size.width) / 2;
    }
    else {
        frameToCenter.origin.x = 0;
    }
    // center vertically
    if (frameToCenter.size.height < boundsSize.height) {
        frameToCenter.origin.y = (boundsSize.height - frameToCenter.size.height) / 2;
    }
    else {
        frameToCenter.origin.y = 0;
    }
    return frameToCenter;
    
}

@end
