//
//  XMLParser.m
//  iPhoneProject
//
//  Created by MacBook on 7/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "XMLParser.h"
#import "FlashCardsDB.h"

@implementation XMLParser


- (void)parseXML:(NSString *)filePath
{
    NSAutoreleasePool *autoReleasePool = [[NSAutoreleasePool alloc] init];

        
        flashCardArray = [[NSMutableArray alloc] init];
        
        [self copyFileToDocuments:filePath];
        
        NSLog(@"FilePath: %@",filePath);
        
        NSString *xmlStr = [[NSString alloc] initWithContentsOfFile:[NSString stringWithFormat:@"%@/%@", strDocumentPath, filePath]
                                                           encoding:NSUTF8StringEncoding
                                                              error:nil];
        
        NSLog(@"\n\n XML:\n >>>>>>>\n%@\n<<<<<<",xmlStr);
        
        DDXMLDocument *ddDoc = [[DDXMLDocument alloc] initWithXMLString:xmlStr options:0 error:nil];
        
        DDXMLElement *ddMenu = [ddDoc rootElement];
        
        
        for (DDXMLElement *rN in [ddMenu children]) {
            @try {
                
                if([[rN name] isEqualToString:@"Row"])
                {
                    NSLog(@"rN:  %@",rN);
                   [self parseFlashCard:rN];
                }

            }
            @catch (NSException *exception) {
                
            }
            @finally {
                
            }
            
        }
        [self dumpDatabase];
        
        [ddDoc release];
        ddDoc = nil;
    
    [autoReleasePool release];
    autoReleasePool = nil;
    
}

- (void)copyFileToDocuments:(NSString *)fileName {
    
	NSString* filePath = [NSString stringWithFormat:@"%@/%@", strDocumentPath, fileName];
	if (![Util checkExistingOfFileAtPath:filePath]) {
		//copy database
		NSString* sourcePath = [NSString stringWithFormat:@"%@/%@", strResourcePath, fileName];
		[Util copyFileFromPath:sourcePath to:filePath];
	}
}

- (void)dumpDatabase
{
    
    for (FlashCard *card in flashCardArray) {
        
        [[FlashCardsDB instance] addFlashCard:card];
        
    }
    
}

- (void)parseFlashCard:(DDXMLElement*)element
{
    FlashCard *card = [[FlashCard alloc] init];
    
    for (DDXMLElement *rN in [element children])
    {
        if([[rN name] isEqualToString:@"Column1"])
        {
            card.categoryID = [[rN stringValue] intValue];
        }
        if([[rN name] isEqualToString:@"Column2"])
        {
            card.question = [Util trimString:[rN stringValue]];
        }
        if([[rN name] isEqualToString:@"Column3"])
        {
            card.choices = [rN stringValue];
        }
        if([[rN name] isEqualToString:@"Column4"])
        {
            card.answers = [rN stringValue];
        }
        if([[rN name] isEqualToString:@"Column5"])
        {
            card.rationale = [Util trimString:[rN stringValue]];
        }
        if([[rN name] isEqualToString:@"Column6"])
        {
            card.mnemonics = [Util trimString:[rN stringValue]];
        }
        if([[rN name] isEqualToString:@"Column7"])
        {
            card.imageID = [[rN stringValue] intValue];
        }
    }
    
    card.status = 0;
    card.answerStatus = 0;
    card.wikipedia = @"";
    
    card.rationale = card.rationale == NULL ? @"" : card.rationale;
    card.mnemonics = card.mnemonics == NULL ? @"" : card.mnemonics;
    
    [flashCardArray addObject:card];
    
}

/*
 <Column1>Category </Column1>
 <Column2>Question</Column2>
 <Column3>choices seperated by ";"</Column3>
 <Column4>Answer</Column4>
 <Column5>Rationale</Column5>
 <Column6>Mnemonic </Column6>
 <Column7>Image # (corresponds to pictures from folder we sent, see second sheet of excel document)</Column7>
 
 */


- (void)parseTermCard:(DDXMLElement*)element
{
    TermCard *card = [[TermCard alloc] init];
    
    for (DDXMLElement *rN in [element children])
    {
        if([[rN name] isEqualToString:@"Column1"])
        {
            card.categoryID = [[rN stringValue] intValue];
        }
        if([[rN name] isEqualToString:@"Column2"])
        {
            card.termQuest = [rN stringValue];
        }
        if([[rN name] isEqualToString:@"Column3"])
        {
            card.termDef = [rN stringValue];
        }

    }
    
    card.status = 0;
    card.answerStatus = 0;
    card.wikipedia = @"";
    
    [flashCardArray addObject:card];
    
    [card release];
}

/*
 <Column1>Category </Column1>
 <Column2>Term</Column2>
 <Column3>Definition</Column3>

 
 */


- (void)parseImage:(DDXMLElement*)element
{
    FlashCard *card = [[FlashCard alloc] init];
    
    for (DDXMLElement *rN in [element children])
    {
        if([[rN name] isEqualToString:@"Column1"])
        {
            card.imageID = [[rN stringValue] intValue];
        }
        if([[rN name] isEqualToString:@"Column2"])
        {
            card.imageName = [Util trimString:[rN stringValue]];
        }
        
    }

    [flashCardArray addObject:card];
    
    [card release];
}

- (void)parseMnemocis:(DDXMLElement*)element
{
    Mnemonics *card = [[Mnemonics alloc] init];
    
    for (DDXMLElement *rN in [element children])
    {
        if([[rN name] isEqualToString:@"Column1"])
        {
            card.mnemonicText = [Util trimString:[rN stringValue]];
        }
        
    }
    
    card.mnemonicType = 1;
    
    [flashCardArray addObject:card];
    
    [card release];
}

@end
