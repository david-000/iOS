//
//  MnemonicsDB.m
//  iPhoneProject
//
//  Created by Usman  Ali on 7/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MnemonicsDB.h"
#import "FlashCard.h"
#import "Mnemonic.h"

@interface MnemonicsDB (Private)

- (NSMutableString *)getBaseMnemonicQuery;

- (Mnemonic *)getMnemonicFromStatement:(sqlite3_stmt *)stmt;

@end

@implementation MnemonicsDB

- (id) init{
	if (self = [super init]) {
        
	}
	return self;
}

+ (MnemonicsDB *)instance {
 
    static MnemonicsDB *instance = nil;
    if(!instance) {
        instance = [[MnemonicsDB alloc] init];
    }
    
    return instance;
}

- (NSArray *)getAllMnemonicIds {
 
    const char *query = "SELECT id "
                        "FROM mnemonic ";
    sqlite3_stmt *stmt = nil;
    NSMutableArray *mnemonicIds = [NSMutableArray array];
    
    if(sqlite3_prepare_v2(self.database, query, -1, &stmt, NULL) != SQLITE_OK) {
        NSLog(@"Unable to prepare statement in getAllMnemonicIds");
        return nil;
    }
    
    while(sqlite3_step(stmt) == SQLITE_ROW) {
        
        const NSInteger categoryId = sqlite3_column_int(stmt, 0);
        [mnemonicIds addObject:[NSNumber numberWithInt:categoryId]];
        
    }
    
    sqlite3_finalize(stmt);
    
    return mnemonicIds;

    
}


- (NSMutableArray*) getAllMnemonics
{
    NSMutableArray* mnemonics = [NSMutableArray array];
	
	sqlite3_stmt *stmt = nil;
    
    NSMutableString *sql = [self getBaseMnemonicQuery];
     
    if(sqlite3_prepare_v2(self.database, [sql UTF8String], -1, &stmt, NULL) == SQLITE_OK) {
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
                        
            Mnemonic *mnemonic = [self getMnemonicFromStatement:stmt];
            [mnemonics addObject:mnemonic];
            [mnemonic release];
            
        }
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return nil;
    }
		
	sqlite3_finalize(stmt);
	
    //Add the user mnemonics too!
    NSArray *userMnemonics = [self getUserMnemonics];
    [mnemonics addObjectsFromArray:userMnemonics];
    
	return mnemonics;
}

- (NSMutableArray*) getMnemonicsForType:(NSString *)mnemonicTypeName {
    
    NSMutableArray* mnemonics = [NSMutableArray array];
	
	sqlite3_stmt *stmt = nil;

    NSMutableString *sql = [self getBaseMnemonicQuery];
    [sql appendString:@"WHERE mnemonic_type.name = ?"];
     
    if(sqlite3_prepare_v2(self.database, [sql UTF8String], -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_text(stmt, 1, [mnemonicTypeName UTF8String], -1, SQLITE_TRANSIENT);
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            Mnemonic *mnemonic = [self getMnemonicFromStatement:stmt];
            [mnemonics addObject:mnemonic];
            [mnemonic release];
            
        }
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return nil;
    }
		
	//Even though the open call failed, close the database connection to release all the memory.
	sqlite3_finalize(stmt);
	
	return mnemonics;
}

- (NSMutableArray *) getSavedMnemonics {
 
    NSMutableArray* mnemonics = [NSMutableArray array];
	
	sqlite3_stmt *stmt = nil;
    
    NSMutableString *sql = [self getBaseMnemonicQuery];
    [sql appendString:@"WHERE user.mnemonic_state.saved = 1 "];
    
    if(sqlite3_prepare_v2(self.database, [sql UTF8String], -1, &stmt, NULL) == SQLITE_OK) {
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            Mnemonic *mnemonic = [self getMnemonicFromStatement:stmt];
            [mnemonics addObject:mnemonic];
            [mnemonic release];
            
        }
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return nil;
    }
    
	sqlite3_finalize(stmt);
	
	return mnemonics;
    
}

- (NSMutableArray *) getUserMnemonics {
 
    NSMutableArray *mnemonics = [NSMutableArray array];
    
    sqlite3_stmt *stmt = nil;
    
    NSMutableString *sql = [NSMutableString stringWithString:   @"SELECT    user.user_mnemonic.id, "
                                                                "           user.user_mnemonic.number, "
                                                                "           user.user_mnemonic.title, "
                                                                "           user.user_mnemonic.text, "
                                                                "           user.user_mnemonic.mnemonic_type_id, "
                                                                "           mnemonic_type.name "
                                                                "FROM       user.user_mnemonic "
                                                                "JOIN       mnemonic_type ON mnemonic_type.id = user.user_mnemonic.mnemonic_type_id "
                            ];
    
    if(sqlite3_prepare_v2(self.database, [sql UTF8String], -1, &stmt, NULL) == SQLITE_OK) {
        
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            NSInteger column = 0;
            const NSInteger mnemonicId = sqlite3_column_int(stmt, column++);
            const NSInteger mnemonicNumber = sqlite3_column_int(stmt, column++);
            const char *mnemonicTitle = (const char *)sqlite3_column_text(stmt, column++);
            const char *mnemonicText = (const char *)sqlite3_column_text(stmt, column++);
            const NSInteger mnemonicTypeId = sqlite3_column_int(stmt, column++);
            const char *mnemonicTypeName = (const char *)sqlite3_column_text(stmt, column++);
            
            
            Mnemonic *mnemonic = [[Mnemonic alloc] initWithMnemonicID:mnemonicId
                                                                 text:mnemonicText
                                                       mnemonicTypeID:mnemonicTypeId
                                                     mnemonicTypeName:mnemonicTypeName
                                                                title:mnemonicTitle
                                                                saved:YES
                                                       mnemonicNumber:mnemonicNumber];
            [mnemonics addObject:mnemonic];
            [mnemonic release];            
            
        }
    } else {
        
        printf( "could not prepare statemnt in getUserMnemonics: %s\n", sqlite3_errmsg(self.database) );
        return nil;
    }
    
	sqlite3_finalize(stmt);
	
	return mnemonics;

}


- (NSArray *) getMnemonicsForFlashcard:(NSInteger)flashcardId {
    
    NSMutableArray *mnemonics = [NSMutableArray array];
    
    sqlite3_stmt *stmt = nil;
    
    NSMutableString *sql = [self getBaseMnemonicQuery];
    [sql appendString:  @"JOIN flashcard_mnemonic_link ON flashcard_mnemonic_link.mnemonic_number = mnemonic.number "
                        "WHERE flashcard_mnemonic_link.flashcard_id = ?"];
    
    if(sqlite3_prepare_v2(self.database, [sql UTF8String], -1, &stmt, NULL) == SQLITE_OK) {
     
        sqlite3_bind_int(stmt, 1, flashcardId);
        while(sqlite3_step(stmt) == SQLITE_ROW) {
            
            Mnemonic *mnemonic = [self getMnemonicFromStatement:stmt];
            [mnemonics addObject:mnemonic];
            [mnemonic release];
            
        }
        
    } else {
        
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return nil;
    }
    
	sqlite3_finalize(stmt);
	
	return mnemonics;
        
}



- (NSInteger)getMnemonicTypeId:(NSString *)mnemonicTypeName {
 
    sqlite3_stmt *stmt = nil;
    
    const char *sql =   "SELECT id "
                        "FROM   mnemonic_type "
                        "WHERE  name = ? ";
    
    
    NSInteger mnemonicTypeId = 0;
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_text(stmt, 1, [mnemonicTypeName UTF8String], -1, SQLITE_TRANSIENT);
     
        if(sqlite3_step(stmt) == SQLITE_ROW) {
         
            mnemonicTypeId = sqlite3_column_int(stmt, 0);
            
        }
        
    }
    
    sqlite3_finalize(stmt);
    
    return mnemonicTypeId;
}


- (BOOL) addMnemonic:(NSString *)text
               title:(NSString *)title {
       
    NSInteger mnemonicTypeId = [self getMnemonicTypeId:@"normal"];

    NSLog(@"Adding mnemonic: %@ for type %d", text, mnemonicTypeId);
    
    BOOL ret = YES;
	
	sqlite3_stmt *addStmt = nil;	
    const char *sql =   "insert into user.user_mnemonic(text, mnemonic_type_id, title) "
                        "values(?, ?, ?)";
    if(sqlite3_prepare_v2(self.database, sql, -1, &addStmt, NULL) == SQLITE_OK) {			
        
        sqlite3_bind_text(addStmt, 1, [text UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_int(addStmt, 2, mnemonicTypeId);
        sqlite3_bind_text(addStmt, 3, [title UTF8String], -1, SQLITE_TRANSIENT);
        
        if(SQLITE_DONE != sqlite3_step(addStmt)){
            ret = NO;
            printf("Could not insert mnemonic!");
            printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );

        }
        
    } else {
        ret = NO;
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
    }
			
	sqlite3_finalize(addStmt);
	
	return ret;
}

- (BOOL) updateMnemonic:(NSInteger)mnemonicId
                  saved:(BOOL)saved {
 
    sqlite3_stmt *stmt = nil;
    
    const char *sql =   "UPDATE mnemonic "
                        "SET    saved = ? "
                        "WHERE  id = ? ";
    
    if(sqlite3_prepare_v2(self.database, sql, -1, &stmt, NULL) == SQLITE_OK) {
        
        sqlite3_bind_int(stmt, 1, saved ? 1 : 0);
        sqlite3_bind_int(stmt, 2, mnemonicId);
        
        if(sqlite3_step(stmt) != SQLITE_DONE) {
            sqlite3_finalize(stmt);
            return NO;
        }
        
    } else {
        printf( "could not prepare statemnt: %s\n", sqlite3_errmsg(self.database) );
        return NO;
    }
    
    sqlite3_finalize(stmt);
    
    return YES;
    
}

- (BOOL) removeMnemonic:(Mnemonic *)mnemonic
{
    BOOL ret = YES;
	sqlite3_stmt *delStmt = nil;
    const char *sql =   "delete from user.user_mnemonic "
                        "where  id = ?";
    if(sqlite3_prepare_v2(self.database, sql, -1, &delStmt, NULL) == SQLITE_OK) {			

        sqlite3_bind_int(delStmt, 1, mnemonic.mnemonicID);
        
        if(SQLITE_DONE != sqlite3_step(delStmt)){
            ret = NO;
        }

    }
    else {
        ret = NO;
    }
			
	//Even though the open call failed, close the database connection to release all the memory.
	sqlite3_finalize(delStmt);
	
	return ret;
}


 
@end

@implementation MnemonicsDB (Private)

- (NSMutableString *)getBaseMnemonicQuery {
    
    return [NSMutableString stringWithString:   @"select mnemonic.id, "
                                                "       mnemonic.text, "
                                                "       mnemonic.mnemonic_type_id, "
                                                "       mnemonic.title, "
                                                "       user.mnemonic_state.saved, "
                                                "       mnemonic.number, "
                                                "       mnemonic_type.name "
                                                "from   mnemonic "
                                                "join   mnemonic_type on mnemonic.mnemonic_type_id = mnemonic_type.id "
                                                "join   user.mnemonic_state on user.mnemonic_state.mnemonic_id = mnemonic.id "
            ];
    
}

- (Mnemonic *)getMnemonicFromStatement:(sqlite3_stmt *)stmt {

    NSInteger column = 0;
    
    const NSInteger mnemonicID = sqlite3_column_int(stmt, column++);
    const char *mnemonicText = (const char *)sqlite3_column_text(stmt, column++);
    const NSInteger mnemonicTypeID = sqlite3_column_int(stmt, column++);
    const char *mnemonicTitle = (const char *)sqlite3_column_text(stmt, column++);
    const bool mnemonicSaved = sqlite3_column_int(stmt, column++) == 0 ? false : true;
    const NSInteger mnemonicNumber = sqlite3_column_int(stmt, column++);
    const char *mnemonicTypeName = (const char *)sqlite3_column_text(stmt, column++);
    
    Mnemonic *mnemonic = [[Mnemonic alloc] initWithMnemonicID:mnemonicID
                                                         text:mnemonicText
                                               mnemonicTypeID:mnemonicTypeID
                                             mnemonicTypeName:mnemonicTypeName
                                                        title:mnemonicTitle
                                                        saved:mnemonicSaved
                                               mnemonicNumber:mnemonicNumber];

    return mnemonic;
    
}

@end

