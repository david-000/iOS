//
//  AchievementManager.h
//  iPhoneProject
//
//  Created by Componica on 10/3/12.
//
//

#import <Foundation/Foundation.h>
#import "Database.h"
#import "Achievement.h"

@class Category;

@interface AchievementManager : Database {
     
    
}

+ (AchievementManager *) instance;

- (NSArray *)getAllAchievementIds;

- (BOOL)updateAchievement:(NSInteger)achievementId
                completed:(BOOL)completed;

//Category completed achievements

- (NSArray *)checkCategoryCompletedAchievements:(Category *)category;

- (Achievement *)getCategoryCompletedAchievement:(NSInteger)categoryId;

- (BOOL)resetAchievementsForCategory:(NSInteger)categoryId;


//All flashcards completed achievement

- (Achievement *)checkAllFlashcardsCompletedAchievement;

- (Achievement *)getAllFlashcardsCompletedAchievement;


@end


