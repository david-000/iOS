//
//  CategoryCell.h
//  iPhoneProject
//
//  Created by Componica on 8/29/12.
//
//

#import <UIKit/UIKit.h>
#import "CategoryDB.h"

@class Category;
@class CategoryCell;
@class RoundedRectView;

@protocol CategoryCellDelegate <NSObject>

@required

- (void)categoryCellWillBeginAnimating:(CategoryCell *)cell;
- (void)categoryCellDidFinishAnimating:(CategoryCell *)cell;
- (void)categoryCell:(CategoryCell *)cell
             checked:(BOOL)checked;

@end


@interface PercentageView : UIView {
    
    UIView *greenView;
    UIView *yellowView;
    UIView *redView;
    
}

- (id)initWithFrame:(CGRect)frame
           category:(Category *)category;

- (void)update:(Category *)category;

@end

@interface CategoryCell : UITableViewCell<UIAlertViewDelegate> {

    BOOL isChecked;
    BOOL isExpanded;
    UIButton *expandButton;
    UIButton *checkboxButton;
    NSObject<CategoryCellDelegate> *delegate;
    PercentageView *percentageView;
    UIView *subcategoryView;
    RoundedRectView *backgroundView;
    Category *category;
    NSMutableArray *childrenCells;
    UIAlertView *upgradeAlert;
    
    CategoryCell *parent;
}

@property(nonatomic, retain) Category *category;
@property(nonatomic, retain) NSMutableArray *childrenCells;
@property(nonatomic, assign) BOOL isChecked;
@property (nonatomic, retain) CategoryCell *parent;

- (id)initWithCategory:(Category *)_category
              delegate:(NSObject<CategoryCellDelegate> *)_delegate
                 width:(CGFloat)width
            expandable:(BOOL)expandable
                indent:(BOOL)indent;

- (void)setIsChecked:(BOOL)_isChecked;

- (void)updatePercentageView;

- (void)checkSubcategories;

@end
