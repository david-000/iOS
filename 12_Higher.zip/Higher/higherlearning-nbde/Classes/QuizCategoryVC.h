//
//  QuizCategoryVC.h
//  iPhoneProject
//
//  Created by Componica on 9/12/12.
//
//

#import <UIKit/UIKit.h>
#import "CategoryVC.h"
#import "NavigationItemVC.h"

@interface QuizCategoryVC : NavigationItemVC<UITableViewDataSource, UITableViewDelegate> {
    
    IBOutlet UITableView *myTableView;
    NSMutableArray *categories;
    NSMutableArray *cells;
    
}

@property(nonatomic, retain) UITableView *myTableView;

@end
