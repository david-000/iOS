CREATE DATABASE quiz;

CREATE TABLE tbl_rank (
  name varchar(50) NOT NULL primary key,
  password varchar(50) default NULL,
  score int(11) default 0,
  location VARCHAR (70) DEFAULT NULL
);
