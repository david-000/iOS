//
//  UpgradeAnimationViewController.m
//  TalkingBaby
//
//  Created by le hung on 10/19/11.
//  Copyright (c) 2011 CNCSoft. All rights reserved.
//

#import "UpgradeAnimationViewController.h"
#import "MKStoreManager.h"
#import "TalkingBabyAppDelegate.h"
#import "MainViewController.h"

@implementation UpgradeAnimationViewController
@synthesize imgName;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    isLoading = NO;
    indicator.hidden = YES;
    appDelegate = (TalkingBabyAppDelegate*)[[UIApplication sharedApplication] delegate];
    [MKStoreManager setDelegate:self];
    imageView.image = [UIImage imageNamed:imgName];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    imageView = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
    [super dealloc];
    [imageView release];
    [imgName release];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark action
- (IBAction)upgradeAnimation:(id)sender {
    if (!isLoading) {
        isLoading = YES;
        indicator.hidden = NO;
        [indicator startAnimating];
        //[[MKStoreManager sharedManager] buyFeature:@"animation3"]; 
        [[MKStoreManager sharedManager] buyFeature:@"TALKING_BABY_UPGRADE_1"];
    }
    
}
- (IBAction)close:(id)sender {
    [self dismissModalViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark MKStoreManagerDelegate
- (void)productFetchComplete{
    NSLog(@"product fetch complete");
}

- (void)productPurchased:(NSString *)productId {
    isLoading = NO;
    if ([imgName isEqualToString:@"upgrade_water_ad.png"]) {
        [appDelegate.mainViewController.flowerButton setImage:[UIImage imageNamed:@"flower_water.png"] forState:UIControlStateNormal];
        [appDelegate.settingArray setObject:@"1" forKey:@"4"];
    }
    if ([imgName isEqualToString:@"upgrade_tounge_ad.png"]) {
        [appDelegate.mainViewController.toungeButton setImage:[UIImage imageNamed:@"tounge.png"] forState:UIControlStateNormal];
        [appDelegate.settingArray setObject:@"1" forKey:@"5"];
    }
    if ([imgName isEqualToString:@"upgrade_vomiting_ad.png"]) {
        [appDelegate.mainViewController.vomitButton setImage:[UIImage imageNamed:@"vomiting.png"] forState:UIControlStateNormal];
        [appDelegate.settingArray setObject:@"1" forKey:@"6"];
    }
    if ([imgName isEqualToString:@"upgrade_dancing_ad.png"]) {
        [appDelegate.mainViewController.danceButton setImage:[UIImage imageNamed:@"dancing.png"] forState:UIControlStateNormal];
        [appDelegate.settingArray setObject:@"1" forKey:@"7"];
    }
    
    NSMutableDictionary *settingArray = [[NSMutableDictionary alloc] initWithDictionary:appDelegate.settingArray];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES); 
    NSString *cacheDirectory = [paths objectAtIndex:0];
    NSString *filePath = [cacheDirectory stringByAppendingString:@"Setting.plist"];
    [settingArray writeToFile:filePath atomically:YES];
    [settingArray release];
    
    [self dismissModalViewControllerAnimated:YES];
	
}
- (void)transactionCanceled {
    isLoading = NO;
    indicator.hidden = YES;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message"
                                                    message:@"Purchase failed, please try again later!" 
                                                   delegate:nil 
                                          cancelButtonTitle:@"Ok" 
                                          otherButtonTitles:nil];
    
    [alert show];
    [alert release];
    NSLog(@"failed transaction");
}
@end
