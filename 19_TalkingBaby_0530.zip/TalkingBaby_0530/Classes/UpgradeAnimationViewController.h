//
//  UpgradeAnimationViewController.h
//  TalkingBaby
//
//  Created by le hung on 10/19/11.
//  Copyright (c) 2011 CNCSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TalkingBabyAppDelegate.h"

//@class TalkingBabyAppDelegate;
@interface UpgradeAnimationViewController : UIViewController
{
    IBOutlet UIImageView *imageView;
    NSString *imgName;
    TalkingBabyAppDelegate *appDelegate;
    IBOutlet UIActivityIndicatorView *indicator;
    
    BOOL isLoading;
}
@property (nonatomic,retain) NSString *imgName;

- (IBAction)upgradeAnimation:(id)sender;
- (IBAction)close:(id)sender;
@end
