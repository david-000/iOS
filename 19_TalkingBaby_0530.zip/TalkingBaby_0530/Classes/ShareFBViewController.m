//
//  ShareFBViewController.m
//  TalkingBaby
//
//  Created by hung le on 10/1/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import "ShareFBViewController.h"
#import "FBConnect.h"
#import "TalkingBabyAppDelegate.h"
#import "MainViewController.h"
#import "RecordVideo.h"

static NSString* kAppId = @"116235925150641";

@implementation ShareFBViewController

@synthesize facebook = _facebook;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        _permissions =  [[NSArray arrayWithObjects:
                          @"read_stream", @"publish_stream", @"offline_access",nil] retain];
        _facebook = [[Facebook alloc] initWithAppId:kAppId
                                        andDelegate:self];
    }
    return self;
}

- (void)dealloc
{
    [_facebook release];
    [_permissions release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    appDelegate = (TalkingBabyAppDelegate*)[[UIApplication sharedApplication] delegate];
    [super viewDidLoad];
    [self login];
    _fbButton.isLoggedIn = NO;
    [_fbButton updateImage];
    indicator.hidden = YES;
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)login {
    [_facebook authorize:_permissions];
}

/**
 * Invalidate the access token and clear the cookie.
 */
- (void)logout {
    [_facebook logout:self];
}
- (IBAction)fbButtonClick:(id)sender {
    if (_fbButton.isLoggedIn) {
        [self logout];
    } else {
        [self login];
    }
}
- (IBAction)close {
    //[self dismissModalViewControllerAnimated:YES];
    [self.view removeFromSuperview];
    [appDelegate.actionSheet showInView:appDelegate.window];
}
- (void)uploadVideo {
    NSString *str = appDelegate.mainViewController.recordVideo.videoLink;
    NSData* data = [NSData dataWithContentsOfFile:str];
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   data, @"video.mov",
                                   @"video/mov", @"contentType",
                                   @"Talking baby", @"TalkingBaby",
                                   nil];                                                      
    [_facebook requestWithGraphPath:@"me/videos"
                          andParams:params
                      andHttpMethod:@"POST"
                        andDelegate:self];
}
- (void)fbDidLogin {
    indicator.hidden = NO;
    [indicator startAnimating];
    _fbButton.isLoggedIn = YES;
    [_fbButton updateImage];
    [self performSelector:@selector(uploadVideo) withObject:nil afterDelay:0.5];
}
-(void)fbDidNotLogin:(BOOL)cancelled {
    NSLog(@"did not login");
}
- (void)fbDidLogout {
    _fbButton.isLoggedIn         = NO;
    [_fbButton updateImage];
}
- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response {
    NSLog(@"received response");
}
- (void)request:(FBRequest *)request didLoad:(id)result {
    if ([result isKindOfClass:[NSArray class]]) {
        result = [result objectAtIndex:0];
    }
    if ([result objectForKey:@"owner"]) {
        
    } else {
        indicator.hidden = YES;
        [self.view removeFromSuperview];
        [appDelegate.actionSheet showInView:appDelegate.window];
        [self release];
    }
}
- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
    indicator.hidden = YES;
    NSLog(@"%@",[error localizedDescription]);
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    [alert release];
}
- (void)dialogDidComplete:(FBDialog *)dialog {
}
@end
