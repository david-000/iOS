//
//  RecordVideo.h
//  TalkingBaby
//
//  Created by hung le on 9/9/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>
#import <CoreMedia/CMTime.h>

@class MainViewController;
@class TalkingBabyAppDelegate;

@protocol RecordVideoDelegate <NSObject>
@required 
-(void)finishPlayRecordVideo;
-(void)createVideoSuccessfully;

@end

@interface RecordVideo : NSObject <AVAudioRecorderDelegate, AVAudioPlayerDelegate>{
	NSURL *recordedTmpFile;
	AVAudioRecorder *recorder;
    AVAudioPlayer *audioPlayer;
	NSError *error;
	NSMutableDictionary* recordSetting;
	NSString *linkAudio;
	NSString *linkVideo; //link video without audio
    NSString *videoLink; //link video with audio
	
	NSTimer	*timer;
	NSMutableArray *captureImgArray;
	UIView *captureView;
    UIView *playView; 
    UIImageView *imgView;
    int recordTime;
    int count;
    int countImg;
    NSFileManager *fileManager;
    
    TalkingBabyAppDelegate *appDelegate;
    id <RecordVideoDelegate> delegate;
    MainViewController *mailViewController;
    
    BOOL capturingVideo;
    
    NSTimer *timerToCheckRecordAudio;
    NSTimer *timerToPlayRecordAudio;
    
    int countPause;
    NSMutableArray *pauseTimeArray;
    int index;
    float pauseTime;
    BOOL pausing;
    float durationPlayAudio;
    float startPause;
}
@property (nonatomic, retain) UIView *captureView;
@property (nonatomic, assign) int recordTime;
@property (nonatomic, retain) MainViewController *mailViewController;
@property (nonatomic, assign) id <RecordVideoDelegate> delegate;
@property (nonatomic, retain) NSString *linkVideo;
@property (nonatomic, retain) NSString *videoLink;

- (void)startRecordVideo;
- (void)stopRecordVideo;
- (void)createVideoFromFrames;
- (void)playRecordVideo;
- (CVPixelBufferRef) pixelBufferFromCGImage: (CGImageRef) image;
- (void) addAudioToFileAtPath:(NSString *) filePath toPath:(NSString *)outFilePath;
@end
