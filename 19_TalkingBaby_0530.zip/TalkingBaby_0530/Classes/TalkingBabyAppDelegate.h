//
//  TalkingBabyAppDelegate.h
//  TalkingBaby
//
//  Created by hung le on 8/24/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

#define kLAUGHINGHARD @"laughhard"
#define kGIGGLING @"giggle"
#define kCRYING @"cry"
#define kTOUNGUEOUT @"tongue"
#define kFLOWERWATER @"flowerwater"
#define kTWIRLINGVOMITING @"vomit"
#define kDANCING @"dance"
#define kBLINKINGFROG @"frogblink"
#define kCONFUSED @"confused"
#define kTALKING @"talking1"

@class MainViewController;
@class RecordAudio;
@class ShareFBViewController;
@interface TalkingBabyAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	IBOutlet MainViewController *mainViewController;
    ShareFBViewController *shareFBController;
	UIProgressView *progressView;
    
	BOOL animating;
    BOOL confused;
	UIViewController *shareViewController;
    
    AVAudioSession * audioSession;
    
    BOOL recordingAudio;
    BOOL showShareView;
    NSThread *recordVideThread;
    
    NSMutableDictionary *settingArray;
    UIActionSheet *actionSheet;
    NSString *currentAnimationImage;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) UIProgressView *progressView;
@property (nonatomic, assign) BOOL animating;
@property (nonatomic, retain) UIViewController *shareViewController;
@property (nonatomic, retain) MainViewController *mainViewController;
@property (nonatomic, retain) ShareFBViewController *shareFBController;
@property (nonatomic, retain) AVAudioSession * audioSession;
@property (nonatomic, assign) BOOL recordingAudio;
@property (nonatomic, assign) BOOL showShareView;
@property (nonatomic, retain)  NSThread *recordVideThread;
@property (nonatomic, retain) NSMutableDictionary *settingArray;
@property (nonatomic, retain) UIActionSheet *actionSheet;
@property (nonatomic, retain) NSString *currentAnimationImage;
@property (nonatomic, assign) BOOL confused;

@end

