//
//  ShareYoutubeViewController.m
//  TalkingBaby
//
//  Created by hung le on 10/1/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import "ShareYoutubeViewController.h"
#import "GDataServiceGoogleYouTube.h"
#import "GDataEntryYouTubeUpload.h"
#import "TalkingBabyAppDelegate.h"
#import "MainViewController.h"
#import "RecordVideo.h"
#import "TalkingBabyAppDelegate.h"


#define DEVELOPER_KEY @"AI39si4zTbIqeg7ckm6fUiF-V-_T4gh-ZjbEPlCvfKZF2GSOeo_hOOl-RMisCcYn2KJg82_TmW109_2yS5oplqQ6RcID2UUPRw"
#define CLIENT_ID @"TalkingBaby" 

@interface ShareYoutubeViewController (PrivateMethods)

- (GDataServiceTicket *)uploadTicket;
- (void)setUploadTicket:(GDataServiceTicket *)ticket;
- (GDataServiceGoogleYouTube *)youTubeService;

@end

@implementation ShareYoutubeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
    [mUploadTicket release];
    [usernameTextField release];
    [passwordTextField release];
    [titleTextField release];
    [descriptionTextView release];
    [scrollView release];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    appDelegate = (TalkingBabyAppDelegate*)[[UIApplication sharedApplication] delegate];
    indicator.hidden = YES;
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    usernameTextField = nil;
    passwordTextField = nil;
    titleTextField = nil;
    descriptionTextView = nil;
    scrollView = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - 
#pragma mark aciton

- (IBAction)uploadVideo {
    indicator.hidden = NO;
    if (!isUpload) {
        isUpload = YES;
        [indicator startAnimating];
        if ([usernameTextField.text isEqualToString:@""] || [passwordTextField.text isEqualToString:@""]) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message" message:@"Username or Password is blanked, please try again!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            [alert release];
            
        }
        else {
            NSString *devKey = [NSString stringWithString:DEVELOPER_KEY];
            NSString *username = usernameTextField.text;
            
            GDataServiceGoogleYouTube *service = [self youTubeService];
            [service setYouTubeDeveloperKey:devKey];
            
            NSString *clientID = [NSString stringWithString:CLIENT_ID];
            
            NSURL *url = [GDataServiceGoogleYouTube youTubeUploadURLForUserID:username
                                                                     clientID:clientID];
            // load the file data
            NSString *path = [NSString stringWithString:appDelegate.mainViewController.recordVideo.videoLink];
            
            NSData *data = [NSData dataWithContentsOfFile:path];
            NSString *filename = [path lastPathComponent];
            
            // gather all the metadata needed for the mediaGroup
            NSString *titleStr = titleTextField.text;
            if (titleStr == nil || [titleStr isEqualToString:@""]) {
                titleStr = @"BabyTalking Video";
            }
            GDataMediaTitle *title = [GDataMediaTitle textConstructWithString:titleStr];
            
            NSString *categoryStr = @"Entertainment";
            GDataMediaCategory *category = [GDataMediaCategory mediaCategoryWithString:categoryStr];
            [category setScheme:kGDataSchemeYouTubeCategory];
            
            NSString *descStr = descriptionTextView.text;
            if (descStr == nil || [descStr isEqualToString:@""]) {
                descStr = @"BabyTalking Video";
            }
            GDataMediaDescription *desc = [GDataMediaDescription textConstructWithString:descStr];
            
            NSString *keywordsStr = @"Talking Baby";
            GDataMediaKeywords *keywords = [GDataMediaKeywords keywordsWithString:keywordsStr];
            
            BOOL isPrivate = NO;
            
            GDataYouTubeMediaGroup *mediaGroup = [GDataYouTubeMediaGroup mediaGroup];
            [mediaGroup setMediaTitle:title];
            [mediaGroup setMediaDescription:desc];
            [mediaGroup addMediaCategory:category];
            [mediaGroup setMediaKeywords:keywords];
            [mediaGroup setIsPrivate:isPrivate];
            
            NSString *mimeType = [GDataUtilities MIMETypeForFileAtPath:path
                                                       defaultMIMEType:@"video/mp4"];
            
            // create the upload entry with the mediaGroup and the file data
            GDataEntryYouTubeUpload *entry;
            entry = [GDataEntryYouTubeUpload uploadEntryWithMediaGroup:mediaGroup
                                                                  data:data
                                                              MIMEType:mimeType
                                                                  slug:filename];
            
            SEL progressSel = @selector(ticket:hasDeliveredByteCount:ofTotalByteCount:);
            [service setServiceUploadProgressSelector:progressSel];
            
            GDataServiceTicket *ticket;
            ticket = [service fetchEntryByInsertingEntry:entry
                                              forFeedURL:url
                                                delegate:self
                                       didFinishSelector:@selector(uploadTicket:finishedWithEntry:error:)];
            
            [self setUploadTicket:ticket];
        } 
    }
}
- (IBAction)close {
    [self.view removeFromSuperview];
    [appDelegate.actionSheet showInView:appDelegate.window];
    [self release];
}
- (IBAction)hiddendKeyboard {
    [usernameTextField resignFirstResponder];
    [passwordTextField resignFirstResponder];
    [titleTextField resignFirstResponder];
    [descriptionTextView resignFirstResponder];
}
#pragma mark -


// get a YouTube service object with the current username/password
//
// A "service" object handles networking tasks.  Service objects
// contain user authentication information as well as networking
// state information (such as cookies and the "last modified" date for
// fetched data.)

- (GDataServiceGoogleYouTube *)youTubeService {
    
    static GDataServiceGoogleYouTube* service = nil;
    
    if (!service) {
        service = [[GDataServiceGoogleYouTube alloc] init];
        
        [service setShouldCacheDatedData:YES];
        [service setServiceShouldFollowNextLinks:YES];
        [service setIsServiceRetryEnabled:YES];
    }
    
    // update the username/password each time the service is requested
    NSString *username = usernameTextField.text;
    NSString *password = passwordTextField.text;
    
    if ([username length] > 0 && [password length] > 0) {
        [service setUserCredentialsWithUsername:username
                                       password:password];
    } else {
        // fetch unauthenticated
        [service setUserCredentialsWithUsername:nil
                                       password:nil];
    }
    
    NSString *devKey = [NSString stringWithString:DEVELOPER_KEY];
    [service setYouTubeDeveloperKey:devKey];
    
    return service;
}

// progress callback
- (void)ticket:(GDataServiceTicket *)ticket
hasDeliveredByteCount:(unsigned long long)numberOfBytesRead 
ofTotalByteCount:(unsigned long long)dataLength {

}

// upload callback
- (void)uploadTicket:(GDataServiceTicket *)ticket
   finishedWithEntry:(GDataEntryYouTubeVideo *)videoEntry
               error:(NSError *)error {
    indicator.hidden = YES;
    isUpload = NO;
    if (error == nil) {
        [self.view removeFromSuperview];
        [appDelegate.actionSheet showInView:appDelegate.window];
        [self release];
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!"
                                                        message:@"Upload failed, please try again!" 
                                                       delegate:nil 
                                              cancelButtonTitle:@"Ok" 
                                              otherButtonTitles:nil];
        
        [alert show];
        [alert release];
    }
 
    [self setUploadTicket:nil];
}

#pragma mark -
#pragma mark Setters

- (GDataServiceTicket *)uploadTicket {
    return mUploadTicket;
}

- (void)setUploadTicket:(GDataServiceTicket *)ticket {
    [mUploadTicket release];
    mUploadTicket = [ticket retain];
}
@end
