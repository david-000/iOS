//
//  CreateVideoProgressView.h
//  TalkingBaby
//
//  Created by hung le on 9/29/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CreateVideoProgressView : UIView {
    
}

@end
