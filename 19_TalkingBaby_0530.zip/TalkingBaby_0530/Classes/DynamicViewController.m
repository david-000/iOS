//
//  DynamicViewController.m
//  TalkingBaby
//
//  Created by le hung on 10/19/11.
//  Copyright (c) 2011 CNCSoft. All rights reserved.
//

#import "DynamicViewController.h"
#import "TalkingBabyAppDelegate.h"

@implementation DynamicViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [indicator startAnimating]; 
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.milkdrinkingcow.com"]]];
    webView.delegate = self;
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    webView = nil;
    indicator = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (void)dealloc {
    [webView release];
    [indicator release];
    [super dealloc];
}

#pragma mark - 
#pragma mark uiwebviewDelegat
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [indicator stopAnimating];
    indicator.hidden = YES;
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    [indicator stopAnimating];
    indicator.hidden = YES;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message"
                                                    message:@"Not connected to Internet, please check internet connection again!" 
                                                   delegate:nil 
                                          cancelButtonTitle:@"Ok" 
                                          otherButtonTitles:nil];
    
    //[alert show];
    [alert release];
}
#pragma mark -
#pragma mark action
- (IBAction)back:(id)sender {
    [self dismissModalViewControllerAnimated:YES];
    TalkingBabyAppDelegate *appDelegate = (TalkingBabyAppDelegate*)[[UIApplication sharedApplication] delegate];
    appDelegate.showShareView = NO;
}
@end
