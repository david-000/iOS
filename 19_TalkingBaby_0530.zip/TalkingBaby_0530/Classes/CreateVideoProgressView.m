//
//  CreateVideoProgressView.m
//  TalkingBaby
//
//  Created by hung le on 9/29/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import "CreateVideoProgressView.h"
#import "TalkingBabyAppDelegate.h"


@implementation CreateVideoProgressView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        UIProgressView *progressView = [[UIProgressView alloc] init];
        progressView.frame = CGRectMake(35, 252, 255, 20);
        [self addSubview:progressView];
        TalkingBabyAppDelegate *appDelegate = (TalkingBabyAppDelegate*)[[UIApplication sharedApplication] delegate];
        appDelegate.progressView = progressView;
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(110, 250, 150, 40)];
        label.text = @"Coverting...";
        label.font = [UIFont boldSystemFontOfSize:17];
        label.backgroundColor = [UIColor clearColor];
        [self addSubview:label];
        [label release];
        
        [progressView release];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc
{
    [super dealloc];
}

@end
