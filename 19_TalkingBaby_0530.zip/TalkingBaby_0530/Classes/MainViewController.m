//
//  MainViewController.m
//  TalkingBaby
//
//  Created by hung le on 8/24/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import "MainViewController.h"
#import "TalkingBabyAppDelegate.h"
#import "RecordVideo.h"
#import "ShareVideoView.h"
#import "MKStoreManager.h"
#import "DynamicViewController.h"
#import "UpgradeAnimationViewController.h"

@implementation MainViewController
@synthesize imgView, recordButton;
@synthesize recordVideo;
@synthesize isSharing;
@synthesize shareViewController;
@synthesize flowerButton,vomitButton,danceButton, toungeButton;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
 if (self) {
 // Custom initialization.
 }
 return self;
 }
 */


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    appDelegate = (TalkingBabyAppDelegate*)[[UIApplication sharedApplication] delegate];
    appDelegate.animating = NO;
    animationName = [[NSString alloc] init];
    inactiveTime = 0;
    isSharing = NO;
    
    if (checkInactiveTimer != nil) {
        [checkInactiveTimer invalidate];
        checkInactiveTimer = nil;
    }
    
    recordAudio = [[RecordAudio alloc] init];
    recordAudio.delegate = self;
    
	imgView.userInteractionEnabled = YES;
    progressView.hidden = YES;
    
    if ([[appDelegate.settingArray objectForKey:@"4"] isEqualToString:@"1"]) {
        [flowerButton setImage:[UIImage imageNamed:@"flower_water.png"] forState:UIControlStateNormal];
    }
    if ([[appDelegate.settingArray objectForKey:@"5"] isEqualToString:@"1"]) {
        [toungeButton setImage:[UIImage imageNamed:@"tounge.png"] forState:UIControlStateNormal];
    }
    if ([[appDelegate.settingArray objectForKey:@"6"] isEqualToString:@"1"]) {
        [vomitButton setImage:[UIImage imageNamed:@"vomiting.png"] forState:UIControlStateNormal];
    }
    if ([[appDelegate.settingArray objectForKey:@"7"] isEqualToString:@"1"]) {
        [danceButton setImage:[UIImage imageNamed:@"dancing.png"] forState:UIControlStateNormal];
    }
    
	//handle tap event
	UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapped:)];
	[tapRecognizer setNumberOfTapsRequired:1];
	[tapRecognizer setDelegate:self];
	[imgView addGestureRecognizer:tapRecognizer];
    [tapRecognizer release];
	//handle drag event
	UIPanGestureRecognizer *panRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(move:)];
	[panRecognizer setMinimumNumberOfTouches:1];
	[panRecognizer setDelegate:self];
	[imgView addGestureRecognizer:panRecognizer];
    [panRecognizer release];
    
    //start with laughing hard animaiton
    [self playAnimation:kLAUGHINGHARD withAmountImage:100 andTime:2];
    [super viewDidLoad];
}

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations.
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
	imgView = nil;
	recordButton = nil;
	backgroundView = nil;
    giglingButton = nil;
    cryButton = nil;
    blinkButton = nil;
    laughtButton = nil;
    flowerButton = nil;
    toungeButton = nil;
    vomitButton = nil;
    danceButton = nil;
    progressView = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[imgView release];
	[animationName release];
	[recordAudio release];
	[recordButton release];
	[audioPlayer release];
	[recordVideo release];
	[backgroundView release];
    [giglingButton release];
    [cryButton release];
    [blinkButton release];
    [laughtButton release];
    [flowerButton release];
    [toungeButton release];
    [vomitButton release];
    [danceButton release];
    [progressView release];
    [super dealloc];
}

#pragma mark -
#pragma mark Action
- (IBAction)buttonClick:(id)sender {
    //handle action of the 8 animation button
    [recordAudio stopPlayRecord];//stop record audio
	UIButton *button = (UIButton*)sender;
	switch (button.tag) {
		case 0:
			[self playAnimation:kGIGGLING withAmountImage:36 andTime:2.0];
			break;
		case 1:
			[self playAnimation:kCRYING withAmountImage:105 andTime:4.0];
			break;
		case 2:
            [self playAnimation:kBLINKINGFROG withAmountImage:11 andTime:0.3];
			break;
		case 3:
			[self playAnimation:kLAUGHINGHARD withAmountImage:100 andTime:2.0];
			break;
		case 4: 
            if ([[appDelegate.settingArray objectForKey:@"4"] isEqualToString:@"0"]) {
                btnIndex = 4;
                isBuying = YES;
                UpgradeAnimationViewController *upgradeViewController = [[UpgradeAnimationViewController alloc] init];
                upgradeViewController.imgName = [[NSString alloc] initWithString:@"upgrade_water_ad.png"];
                [self presentModalViewController:upgradeViewController animated:YES];
                [upgradeViewController release];
            }
            else {
                [self playAnimation:kFLOWERWATER withAmountImage:65 andTime:3.5];
            }
			break;
		case 5:
            if ([[appDelegate.settingArray objectForKey:@"5"] isEqualToString:@"0"]) {
                btnIndex = 5;
                isBuying = YES;
                UpgradeAnimationViewController *upgradeViewController = [[UpgradeAnimationViewController alloc] init];
                upgradeViewController.imgName = [[NSString alloc] initWithString:@"upgrade_tounge_ad.png"];
                [self presentModalViewController:upgradeViewController animated:YES];
                [upgradeViewController release];
            }
            else {
                [self playAnimation:kTOUNGUEOUT withAmountImage:70 andTime:3.0];
            }
			break;
		case 6:
            if ([[appDelegate.settingArray objectForKey:@"6"] isEqualToString:@"0"]) {
                btnIndex = 6;
                isBuying = YES;
                UpgradeAnimationViewController *upgradeViewController = [[UpgradeAnimationViewController alloc] init];
                upgradeViewController.imgName = [[NSString alloc] initWithString:@"upgrade_vomiting_ad.png"];
                [self presentModalViewController:upgradeViewController animated:YES];
                [upgradeViewController release];
            }
            else {
                [self playAnimation:kTWIRLINGVOMITING withAmountImage:57 andTime:3.0];
            }
			break;
		case 7:
            if ([[appDelegate.settingArray objectForKey:@"7"] isEqualToString:@"0"]) {
                btnIndex = 7;
                isBuying = YES;
                UpgradeAnimationViewController *upgradeViewController = [[UpgradeAnimationViewController alloc] init];
                upgradeViewController.imgName = [[NSString alloc] initWithString:@"upgrade_dancing_ad.png"];
                [self presentModalViewController:upgradeViewController animated:YES];
                [upgradeViewController release];
            }
            else {
                [self playAnimation:kDANCING withAmountImage:52 andTime:3.2];
            }
			break;	
		default:
			break;
	}
}
// handle action of record video button
- (IBAction)recordVideoButton {
    //cance inactive timer
    if (checkInactiveTimer != nil) {
        [checkInactiveTimer invalidate];
        checkInactiveTimer = nil;
    }
    
	if (!recordingVideo) {
        [recordButton setImage:[UIImage imageNamed:@"recordButton.png"] forState:UIControlStateNormal];
		flashing = YES;
        //timer for flashing button record
		recordTimer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(flashingRecordButton) userInfo:nil repeats:YES];
		[self startRecordVideo];
	}
	else {
		[recordTimer invalidate];
		[self stopRecordVideo];
	}
    recordingVideo = !recordingVideo;
}

- (void)flashingRecordButton {
    flashing = !flashing;
    [progressView setProgress:recordVideoTime/20.0];
	if (flashing) {
		[recordButton setImage:[UIImage imageNamed:@"recordButton.png"] forState:UIControlStateNormal];
	}
	else {
		[recordButton setImage:[UIImage imageNamed:@"recordButtonFlashing.png"] forState:UIControlStateNormal];
	}
    recordVideoTime += 0.5;
    if (recordVideoTime == 20) {
        [recordTimer invalidate];
        [self stopRecordVideo];
        recordingVideo = NO;
        recordVideoTime = 0;
    }
}

- (void)startRecordVideo {
    [progressView setProgress:0.0];
    progressView.hidden = NO;
    recordVideo = [[RecordVideo alloc] init];
	recordVideo.captureView = backgroundView;
    recordVideo.mailViewController = self;
    [recordVideo startRecordVideo];
}

- (void)stopRecordVideo {
    recordVideoTime = 0;
    progressView.hidden = YES;
    [self stopCheckInactiveTimer];
    isSharing = YES;
    [recordVideo stopRecordVideo];
    [recordButton setImage:[UIImage imageNamed:@"recordButtonFlashing.png"] forState:UIControlStateNormal];
    imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@_%d.jpg",@"vomit",1]];
    
    [audioPlayer stop];
    if (timer != nil) {
        [timer invalidate];
        timer = nil;
    }
	
    shareVideoView = [[ShareVideoView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    shareVideoView.mainViewController = self;
    appDelegate.showShareView = YES;
    [self.view addSubview:shareVideoView];
    [self stopConfusedAnimation];
    
    //show actionsheet to user select action for video
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:nil
                                  delegate:self
                                  cancelButtonTitle:@"Cancel"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"Play",@"Save to Library",@"Upload to Youtube",@"Upload to Facebook",@"Send via E-Mail",nil];
    appDelegate.actionSheet = [actionSheet retain];
    [actionSheet showInView:appDelegate.window];
    [actionSheet release];
    
}

//show webpage of http://www.milkdrinkingcow.com
- (IBAction)showInfo {
    appDelegate.showShareView = YES;
    DynamicViewController *dynamicViewController = [[DynamicViewController alloc] init];
    dynamicViewController.view.frame = CGRectMake(0, 0, 320, 480);
    [self presentModalViewController:dynamicViewController animated:YES];
    [dynamicViewController release];
}

- (void)playAnimation:(NSString*)animation withAmountImage:(int)amountImg andTime:(float)second {
    //play the animations
    if (!appDelegate.showShareView) { // only play animation when not share
        if (appDelegate.confused) { //stop timer of confused animation
            if (confusedTimer != nil) {
                [confusedTimer invalidate];
                confusedTimer = nil;
            }
        }
        
        //when play a animation Timer for check inactive will be reset.
        [self stopCheckInactiveTimer];
        if (checkInactiveTimer != nil) {
            [checkInactiveTimer invalidate];
            checkInactiveTimer = nil;
        }
        
        if (!appDelegate.animating) {// app don't playing any animation
            appDelegate.animating = YES;
            //start Animation timer
            timer = [NSTimer scheduledTimerWithTimeInterval:second/amountImg target:self selector:@selector(startAnimation) userInfo:nil repeats:YES];
            [animationName release];
            animationName = nil;
            animationName = [[NSString alloc] initWithString:animation];
            amountImage = amountImg;
            isFinishAudio = NO;
            isFinishAnimation = NO;
            count = 0;
            
            NSURL *url;
            if ([animation isEqualToString:kDANCING]) {// random audio for dancing animation
                int randomNumber = arc4random() % 6;
                
                switch (randomNumber) {
                    case 0:
                        url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@_0.mp3", [[NSBundle mainBundle] resourcePath],animation]];
                        break;
                    case 1:
                        url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@_1.mp3", [[NSBundle mainBundle] resourcePath],animation]];
                        break;
                    case 2:
                        url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@_2.mp3", [[NSBundle mainBundle] resourcePath],animation]];
                        break;
                    case 3:
                        url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@_3.mp3", [[NSBundle mainBundle] resourcePath],animation]];
                        break;    
                    case 4:
                        url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@_4.mp3", [[NSBundle mainBundle] resourcePath],animation]];
                        break; 
                    case 5:
                        url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@_5.mp3", [[NSBundle mainBundle] resourcePath],animation]];
                        break; 
                        
                    default:
                        url = nil;
                        break;
                }
            }
            else {
                url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@.mp3", [[NSBundle mainBundle] resourcePath],animation]];
            }
            
            audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
            audioPlayer.delegate = self;
            audioPlayer.numberOfLoops = 0;
            [audioPlayer prepareToPlay];
            
            if (audioPlayer == nil)
                NSLog([error description]);
            else
                [audioPlayer play];
        }
        else { //app playing a animation
            appDelegate.animating = YES;
            if (timer != nil) {
                [timer invalidate];
                timer = nil;
            }
            timer = [NSTimer scheduledTimerWithTimeInterval:second/amountImg target:self selector:@selector(startAnimation) userInfo:nil repeats:YES];
            [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
            if (animationName == nil) {
                animationName = [[NSString alloc] initWithString:animation];
            }
            else {
                [animationName release];
                animationName = nil;
                animationName = [[NSString alloc] initWithString:animation];
            }
            
            amountImage = amountImg;
            count = 0;
            isFinishAudio = NO;
            isFinishAnimation = NO;
            
            NSURL *url;
            if ([animation isEqualToString:kDANCING]) {
                int randomNumber = arc4random() % 6;
                
                switch (randomNumber) {
                    case 0:
                        url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@_0.mp3", [[NSBundle mainBundle] resourcePath],animation]];
                        break;
                    case 1:
                        url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@_1.mp3", [[NSBundle mainBundle] resourcePath],animation]];
                        break;
                    case 2:
                        url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@_2.mp3", [[NSBundle mainBundle] resourcePath],animation]];
                        break;
                    case 3:
                        url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@_3.mp3", [[NSBundle mainBundle] resourcePath],animation]];
                        break;    
                    case 4:
                        url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@_4.mp3", [[NSBundle mainBundle] resourcePath],animation]];
                        break; 
                    case 5:
                        url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@_5.mp3", [[NSBundle mainBundle] resourcePath],animation]];
                        break; 
                        
                    default:
                        url = nil;
                        break;
                }
            }
            else {
                url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@.mp3", [[NSBundle mainBundle] resourcePath],animation]];
            }
            if (audioPlayer != nil) {
                if ([audioPlayer isPlaying]) {
                    [audioPlayer stop];
                }
                [audioPlayer release];
                audioPlayer = nil;
            }
            
            audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
            
            audioPlayer.delegate = self;
            audioPlayer.numberOfLoops = 0;
            if (audioPlayer == nil)
                NSLog([error description]);
            else
                [audioPlayer play];
        }   
    }
}

- (void)startAnimation { //load image for the animations
    isFinishAnimation = YES;
	if (count == amountImage) {
        if (timer != nil) {
            [timer invalidate];
            timer = nil;      
        }
	}
	else {
		count++;
		imgView.image = [[[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@_%d",animationName,count] ofType:@"jpg"]] autorelease];
        if (appDelegate.currentAnimationImage != nil) {
            [appDelegate.currentAnimationImage release];
            appDelegate.currentAnimationImage = nil;
        }
        appDelegate.currentAnimationImage = [[NSString alloc] initWithFormat:@"%@_%d.jpg",animationName,count];
	}
}
- (void)endAnimation {
    //when animation end, timer check inactive will be run.
    if (!isSharing && !appDelegate.recordingAudio) {
        [self startCheckInactiveTimer]; 
    }
}

- (void)playConfusedAnimation { //start timer for confused animation
   
    [self stopCheckInactiveTimer]; //when play a animation Timer for check inactive will be reset.
    if (checkInactiveTimer != nil) {
        [checkInactiveTimer invalidate];
        checkInactiveTimer = nil;
    }
    //start confused timer to play confused animation
    confusedTimer = [NSTimer scheduledTimerWithTimeInterval:2.0/28.0 target:self selector:@selector(startConfusedAnimation) userInfo:nil repeats:YES];
    appDelegate.confused = YES;
    count = 0;
}

- (void)startConfusedAnimation { //load image for confused animation
	if (count == 28) {
        count = 0;
    }
    count++;
    if (appDelegate.currentAnimationImage != nil) {
        [appDelegate.currentAnimationImage release];
        appDelegate.currentAnimationImage = nil;
    }
    appDelegate.currentAnimationImage = [[NSString alloc] initWithFormat:@"%@_%d.jpg",kCONFUSED,count];
    
    imgView.image = [[[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@_%d",kCONFUSED,count] ofType:@"jpg"]] autorelease];
}
- (void)stopConfusedAnimation { //finish confused animation
    if (confusedTimer != nil) {
        [confusedTimer invalidate];
        confusedTimer = nil;
    }
    appDelegate.confused = NO;
    imgView.image = [[[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@_%d",kCONFUSED,1] ofType:@"jpg"]] autorelease];
}

//check inactive and play random animation
- (void)startCheckInactiveTimer {
    if (checkInactiveTimer == nil) {
        checkInactiveTimer = [NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(playRandomAnimation) userInfo:nil repeats:YES];    
    } 
}

- (void)stopCheckInactiveTimer {
    if (checkInactiveTimer != nil) {
        [checkInactiveTimer invalidate];
        checkInactiveTimer = nil;
    } 
}
- (void)playRandomAnimation {
    if (appDelegate.recordingAudio) {
        return;
    }
    inactiveTime += 3;
    if (inactiveTime == 21) {
        inactiveTime = 0;
        [self playAnimation:kCRYING withAmountImage:105 andTime:3.0];
    }
    else {
        int randomNumber = arc4random() %4;
        
        switch (randomNumber) {
            case 0:
                [self playAnimation:kTOUNGUEOUT withAmountImage:26 andTime:3.0];
                break;
            case 1:
                [self playAnimation:kFLOWERWATER withAmountImage:65 andTime:3.0];
                break;
            case 2:
                [self playAnimation:kGIGGLING withAmountImage:28 andTime:2.0];
                break;
            case 3:
                [self playAnimation:kBLINKINGFROG withAmountImage:11 andTime:0.5];
                break;    
                
            default:
                break;
        }
    }
}
#pragma mark -
#pragma mark AVAudioPlayerDelegate

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag {
    if (timer != nil) {
        [timer invalidate];
        timer = nil;      
    }
    isFinishAudio = YES;
    appDelegate.animating = NO;
	[audioPlayer release];
    audioPlayer = nil;
    // when audio finish playing ~~> finish animation ~~> the image will stop loaded
	[self performSelector:@selector(endAnimation) withObject:nil afterDelay:0.0];
}

#pragma mark -
#pragma mark UIGestureRecognizerDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
	
	return ![gestureRecognizer isKindOfClass:[UIPanGestureRecognizer class]];
}
-(void)tapped:(id)sender {
    [recordAudio stopPlayRecord];
    float x = [(UITapGestureRecognizer*)sender locationInView:nil].x;
    float y = [(UITapGestureRecognizer*)sender locationInView:nil].y;
    NSLog(@"%f   %f", x,y);
    //gigging
    if (x > 275 && x < 315 && y > 67 && y < 110) {
        [self playAnimation:kGIGGLING withAmountImage:36 andTime:2.0];
        return;
    }
    //crying
    if ((x > 108 && x < 150 && y > 120 && y < 145) || (x > 165 && x < 200 && y > 120 && y < 150)){
        [self playAnimation:kCRYING withAmountImage:105 andTime:3.0];
        return;
    }
    //toungue out
    if (x > 153 && x < 200 && y > 150 && y < 190){
        [self playAnimation:kTOUNGUEOUT withAmountImage:70 andTime:3.0];
        return;
    }
    //dancing
    if (x > 230 && x < 294 && y > 185 && y < 255){
        [self playAnimation:kDANCING withAmountImage:52
                    andTime:3.2];
        return;
    }
    //Flower water
    if (x > 20 && x < 80 && y > 210 && y < 275){
        [self playAnimation:kFLOWERWATER withAmountImage:65 andTime:3.0];
        return;
    }
    //blink frog
    if (x > 205 && x < 250 && y > 310 && y < 350){
        [self playAnimation:kBLINKINGFROG withAmountImage:11 andTime:0.3];
        return;
    }
}
- (void)move:(id)sender {
    [recordAudio stopPlayRecord];
    float x = [(UITapGestureRecognizer*)sender locationInView:nil].x;
    float y = [(UITapGestureRecognizer*)sender locationInView:nil].y;
    
    //laughinghard
    if (x > 140 && x < 180 && y > 260 && y < 280){
        [self playAnimation:kLAUGHINGHARD withAmountImage:100 andTime:2];
        return;
    }
    //twirling and vomiting
    if (x > 140 && x < 170 && y > 300 && y < 340){
        [self playAnimation:kTWIRLINGVOMITING withAmountImage:57 andTime:3.0];
        return;
    }
}

#pragma mark -
#pragma mark RecordAudioDelegate
- (void)startPlayRecordAudio { //called when start play record audio, this delegate has called from RecordAudio
    [self playAnimation:kTALKING withAmountImage:105 andTime:3.0];
}
- (void)finishPlayRecordAudio { //called when start finish play record audio, this delegate has called from RecordAudio
    if (timer != nil) {
        [timer invalidate];
        timer = nil;
    }
    
    imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@_1.jpg",kTALKING]];
    appDelegate.animating = NO;
    [self performSelector:@selector(endAnimation) withObject:nil afterDelay:0.0];
}


#pragma mark -
#pragma mark UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    switch (buttonIndex) {
        case 0:
            [recordVideo playRecordVideo];
            break;
        case 1:
            [shareVideoView saveVideoToGallery];
            break;
        case 2:
            [shareVideoView shareYoutube];
            break;
        case 3:
            [shareVideoView shareFacebook];
            break;
        case 4:
            [shareVideoView sendEmail];
            break;
        case 5:
            [shareVideoView removeFromSuperview];
            [shareVideoView release];
            [recordVideo release];
            recordVideo = nil;
            appDelegate.animating = NO;
            appDelegate.showShareView = NO;
            [self startCheckInactiveTimer];
            [appDelegate.actionSheet release];
        default:
            break;
    }
}

#pragma mark -
#pragma mark UIAlertviewDelegate

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    [appDelegate.actionSheet showInView:appDelegate.window];
}
@end
