//
//  RealtimeAudioController.h
//  DiracRealtimeExample
//
//  Created by Stephan on 20.03.11.
//  Copyright 2011 The DSP Dimension. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>

#import "EAFRead.h"



@interface RealtimeAudioController : NSObject 
{
	AudioComponentInstance mAudioUnit;

	EAFRead *mReader;
	void *mDirac;
	float mSampleRate;
	
	SInt16 **mAudioBuffer;
	long mAudioBufferReadPos;
	long mAudioBufferWritePos;
	
	float mTimeFactor, mPitchFactor;
	volatile BOOL mThreadShouldExit, mThreadHasExited;
    //NSString *audioPath;
	
}

@property (readonly) AudioComponentInstance mAudioUnit;
@property (readonly) EAFRead *mReader;
@property (readonly) SInt16 **mAudioBuffer;
@property (readonly) void *mDirac;
@property (readwrite) long mAudioBufferReadPos;
@property (readonly) long mAudioBufferWritePos;
//@property (nonatomic, retain) NSString *audioPath;

- (void) start;
- (void) stop;
-(void)changePitch:(float)pitch;
-(void)changeDuration:(float)duration;
- (id) initWithString:(NSString*)audioPath;

@end
