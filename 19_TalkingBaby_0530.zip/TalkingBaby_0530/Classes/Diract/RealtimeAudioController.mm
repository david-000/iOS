//
//  RealtimeAudioController.m
//  DiracRealtimeExample
//
//  Created by Stephan on 20.03.11.
//  Copyright 2011 The DSP Dimension. All rights reserved.
//

#import "RealtimeAudioController.h"
#import <AudioToolbox/AudioToolbox.h>
#include "Dirac.h"
#include "Utilities.h"

#define kOutputBus 0
#define kInputBus 1

#define kNumChannels			1			/* number of channels, LE supports only one */
#define kAudioBufferNumFrames	8192		/* number of frames in our cache */
#define kOversample				1			/* set to 2 if you want higher quality, 1 if you want best performance. Works only with PRO! */

#pragma mark Callbacks



// ---------------------------------------------------------------------------------------------------------------------------
/*
 This is the playback callback that our AudioUnit calls in order to get new data. In an iOS callback
 we're not allowed to use calls that can block, so we're using the callback to copy data from our internal
 cache (which is filled on a separate worker thread, see explanation at processAudioThread for more detail). 
 */
static OSStatus PlaybackCallback(void *inRefCon, 
								 AudioUnitRenderActionFlags *ioActionFlags, 
								 const AudioTimeStamp *inTimeStamp, 
								 UInt32 inBusNumber, 
								 UInt32 inNumberFrames, 
								 AudioBufferList *ioData) 
{    
	// this points to our class instance
	RealtimeAudioController *Self = (RealtimeAudioController *)inRefCon;
	
	// get the actual audio buffer from the ABL	
	AudioBuffer buffer = ioData->mBuffers[0];
	
	// this points to the buffer that is going to be filled with our data
	SInt16 *ioBuffer = (SInt16*)buffer.mData;
	
	// this is how much data will be in our buffer once we're done
	buffer.mDataByteSize = kNumChannels * inNumberFrames * sizeof(SInt16);

	// loop through all frames and channels to copy the data into our AudioBuffer
	long audioBufferReadPos = Self.mAudioBufferReadPos;		// store this in a temporary to avoid ObjC call overhead
	SInt16 **audioBuffer = Self.mAudioBuffer;
	for (long s = 0; s < inNumberFrames; s++) {
		for (long c = 0; c < kNumChannels; c++) {
			ioBuffer[kNumChannels*s+c] = audioBuffer[c][audioBufferReadPos];
		}
		
		// advance our read position and make sure we stay within limits
		audioBufferReadPos++;
		if (audioBufferReadPos > kAudioBufferNumFrames-1)
			audioBufferReadPos = 0;
	}
	Self.mAudioBufferReadPos = audioBufferReadPos;	// write back
	
    return noErr;
}


#pragma mark RealtimeAudioController Class


@implementation RealtimeAudioController

// ---------------------------------------------------------------------------------------------------------------------------

- (void)HandleDemoTimeout:(id)param
{
	[self stop];
	ClearAudioBuffer(mAudioBuffer, kNumChannels, kAudioBufferNumFrames);

	UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Demo Timeout" message:@"The demo timeout of this evaluation version has been reached. Please relaunch the app to continue with the evaluation" delegate:self cancelButtonTitle:@"Ok"
										   otherButtonTitles:nil] autorelease];
	[alert show];
}
// ---------------------------------------------------------------------------------------------------------------------------


@synthesize mAudioUnit, mReader, mAudioBufferReadPos, mAudioBuffer, mDirac, mAudioBufferWritePos;


// ---------------------------------------------------------------------------------------------------------------------------
/* 
 This is where the actual processing happens. We create a background thread that constantly reads from the file,
 processes audio data and writes it into a cache (mAudioBuffer). If there is enough data in the cache already we don't call
 Dirac on this pass and simply wait until we see that our PlaybackCallback has consumed enough frames.
 
 Note that you might need to change thread priority (via [NSthread setThreadPriority:XX]), cache size (via kAudioBufferNumFrames)
 and hi water mark (by changing the line "if (wd > 2*kAudioBufferNumFrames/3)" below) depending on what else is going on
 in your app. 
 */
-(void)processAudioThread:(id)param
{

	// Each thread needs its own AutoreleasePool
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

	mThreadShouldExit = mThreadHasExited = NO;
	
	// Before starting processing we set up our Dirac instance
	mDirac = DiracFxCreate(kDiracQualityBest, kOversample*mSampleRate, kNumChannels);
	if (!mDirac) {
		printf("!! ERROR !!\n\n\tCould not create DiracFx instance\n\tCheck sample rate and number of channels!\n");
		exit(-1);
	}
	printf("Dirac Version = %s\n", DiracVersion());
	
	// This is the number of frames each call to Dirac will add to the cache.
	long numFrames = 512;
	
	// Allocate buffer for Dirac output
	short **audioIn = AllocateAudioBufferSInt16(kNumChannels, numFrames);
	short **audioOut = AllocateAudioBufferSInt16(kNumChannels, DiracFxOutputBufferFramesRequired(2.0, 1.0, numFrames));

	long ret = 0;
	long framesOut = 0;
again:	
	// MAIN PROCESSING LOOP STARTS HERE
	for(;;) {
		
		if (mThreadShouldExit) 
			break;
		
		// first we determine if we actually need to add new data to the cache. If the distance
		// between read and write position in the cache is still larger than 2/3 the cache size 
		// we assume there is still enough data so we simply skip processing this time
		long wd = wrappedDiff(mAudioBufferReadPos, mAudioBufferWritePos, kAudioBufferNumFrames);
		if (wd > 2*kAudioBufferNumFrames/3) {
			long ms = 10;
			// if you're getting drop-outs decrease this value. We only use it to avoid hogging
			// the CPU with the above comparison
			struct timespec sleeptime = {0, ms * 1000000};
			nanosleep (&sleeptime, NULL);
			continue;
		}
		// call DiracProcess to produce new frames
		ret = [mReader readShortsConsecutive:numFrames intoArray:audioIn];
        framesOut = DiracFxProcess(mTimeFactor, mPitchFactor, audioIn, audioOut, numFrames, mDirac);

		// we exit if we hit EOF or an error
		if (ret <= 0 || framesOut <= 0) 
			break;

		
		// add them to the cache
		for (long v = 0; v < framesOut; v++) {
			for (long c = 0; c < kNumChannels; c++) {
				mAudioBuffer[c][mAudioBufferWritePos] = audioOut[c][v];
			}
			mAudioBufferWritePos++;
			if (mAudioBufferWritePos > kAudioBufferNumFrames-1)
				mAudioBufferWritePos = 0;
		}
	}
	
	[mReader seekToStart];
	
	if (framesOut == kDiracErrorDemoTimeoutReached) {
		[self performSelectorOnMainThread:@selector(HandleDemoTimeout:) withObject:self waitUntilDone:NO];
	} else {
		/* comment out the following two lines if you don't want playback to loop */
		if (ret >= 0)
			goto again;
	}
	
	// Free buffer for output
	DeallocateAudioBuffer(audioIn, kNumChannels);
	DeallocateAudioBuffer(audioOut, kNumChannels);

	// get rid of Dirac
	DiracFxDestroy(mDirac);
	mDirac = NULL;
	
	mThreadHasExited = YES;

	// release the pool
	[pool release];
	

}

// ---------------------------------------------------------------------------------------------------------------------------

-(void)changeDuration:(float)duration
{
	mTimeFactor = duration/kOversample;
}
// ---------------------------------------------------------------------------------------------------------------------------

-(void)changePitch:(float)pitch
{
	mPitchFactor = kOversample*pitch;
}
// ---------------------------------------------------------------------------------------------------------------------------

- (id) initWithString:(NSString*)audioPath 
{
	self = [super init];
	
	OSStatus status = noErr;
	mThreadShouldExit = mThreadHasExited = NO;
	mTimeFactor = 1./kOversample;
	mPitchFactor = kOversample;
	// This is boilerplate code to set up CoreAudio on iOS in order to play audio via its default output
	
	// Desired audio component
	AudioComponentDescription desc;
	desc.componentType = kAudioUnitType_Output;
	desc.componentSubType = kAudioUnitSubType_RemoteIO;
	desc.componentManufacturer = kAudioUnitManufacturer_Apple;
	desc.componentFlags = 0;
	desc.componentFlagsMask = 0;
	
	// Get ref to component
	AudioComponent defaultOutput = AudioComponentFindNext(NULL, &desc);
	
	// Get matching audio unit
	status = AudioComponentInstanceNew(defaultOutput, &mAudioUnit);
	checkStatus(status);
		
	// this is the format we want
	AudioStreamBasicDescription audioFormat;
	mSampleRate=audioFormat.mSampleRate			= 44100.00;
	audioFormat.mFormatID			= kAudioFormatLinearPCM;
	audioFormat.mFormatFlags		= kAudioFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked;
	audioFormat.mFramesPerPacket	= 1;
	audioFormat.mChannelsPerFrame	= kNumChannels;
	audioFormat.mBitsPerChannel		= 16;
	audioFormat.mBytesPerPacket		= sizeof(short)*kNumChannels;
	audioFormat.mBytesPerFrame		= sizeof(short)*kNumChannels;
	
	status = AudioUnitSetProperty(mAudioUnit, 
								  kAudioUnitProperty_StreamFormat, 
								  kAudioUnitScope_Input, 
								  kOutputBus, 
								  &audioFormat, 
								  sizeof(audioFormat));
	checkStatus(status);

	// here we set up CoreAudio in order to call our PlaybackCallback
	AURenderCallbackStruct callbackStruct;
	callbackStruct.inputProc = PlaybackCallback;
	callbackStruct.inputProcRefCon = self;
	status = AudioUnitSetProperty(mAudioUnit, 
								  kAudioUnitProperty_SetRenderCallback, 
								  kAudioUnitScope_Input, 
								  kOutputBus,
								  &callbackStruct, 
								  sizeof(callbackStruct));
	checkStatus(status);
	
	
	// Initialize unit
	status = AudioUnitInitialize(mAudioUnit);
	checkStatus(status);
	
	
	// This creates our reader instance that we use to read from our audio file
	//NSString *inputSound  = [[NSBundle mainBundle] pathForResource:  @"song2" ofType: @"caf"];
    NSString *inputSound = [NSTemporaryDirectory() stringByAppendingPathComponent: [NSString stringWithFormat: @"%@.%@",@"hung",@"caf"]];
	NSURL *inUrl = [NSURL URLWithString:inputSound];
    NSLog(@"%@",audioPath);
	mReader = [[EAFRead alloc] init];
	[mReader openFileForRead:inUrl sr:kOversample*mSampleRate channels:kNumChannels];

	// here we allocate our audio cache
	mAudioBuffer = AllocateAudioBufferSInt16(kNumChannels, kAudioBufferNumFrames);
	mAudioBufferReadPos = mAudioBufferWritePos = 0;
	
	// this kicks off our background worker thread that does the actual Dirac processing
	[NSThread detachNewThreadSelector:@selector(processAudioThread:) toTarget:self withObject:nil];
	
	return self;
}
// ---------------------------------------------------------------------------------------------------------------------------
/*
 This call starts processing. We also reset Dirac in case we hit start when processing is already underway
 */
- (void) start 
{
	NSLog(@"Starting");
	OSStatus status = AudioOutputUnitStart(mAudioUnit);
	checkStatus(status);
}
// ---------------------------------------------------------------------------------------------------------------------------

- (void) stop 
{
	NSLog(@"Stopping");
	OSStatus status = AudioOutputUnitStop(mAudioUnit);
	checkStatus(status);
}
// ---------------------------------------------------------------------------------------------------------------------------

- (void) dealloc 
{
	mThreadShouldExit = YES;
	for (;;) if (mThreadHasExited) break;

	AudioUnitUninitialize(mAudioUnit);
	[mReader release];
	DeallocateAudioBuffer(mAudioBuffer, kNumChannels);
    //[audioPath release];
	[super dealloc];
}

// ---------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------

@end

