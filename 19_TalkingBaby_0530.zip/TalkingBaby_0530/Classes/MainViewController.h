//
//  MainViewController.h
//  TalkingBaby
//
//  Created by hung le on 8/24/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "RecordAudio.h"


@class TalkingBabyAppDelegate;
@class RecordVideo;
@class ShareVideoView;
@interface MainViewController : UIViewController <AVAudioPlayerDelegate, UIGestureRecognizerDelegate, RecordAudioDelegate, UIActionSheetDelegate> {
	NSTimer *timer;
	NSTimer *recordTimer; //timer to flashing image of the record video button
    NSTimer *checkInactiveTimer; //timer to check inactive to play random animation
    NSTimer *confusedTimer; // timer to play confused animation when record audio
    
    UIImageView *imgView;
	UIButton *recordButton;
	IBOutlet UIView *backgroundView;
    IBOutlet UIButton *giglingButton;
    IBOutlet UIButton *cryButton;
    IBOutlet UIButton *blinkButton;
    IBOutlet UIButton *laughtButton;
    IBOutlet UIButton *flowerButton;
    IBOutlet UIButton *toungeButton;
    IBOutlet UIButton *vomitButton;
    IBOutlet UIButton *danceButton;
    IBOutlet UIProgressView *progressView;
    
    UIViewController *shareViewController;
    ShareVideoView *shareVideoView;
    
	RecordAudio *recordAudio;
    RecordVideo *recordVideo;
    
	AVAudioPlayer *audioPlayer;
    NSError *error;
	
	NSString *animationName;
	int amountImage;
	int count;
    int btnIndex;
    
    float recordVideoTime;
   
	BOOL recordingVideo;
	BOOL flashing;
    BOOL isSharing;
    BOOL isFinishAudio;
    BOOL isFinishAnimation;
    BOOL isBuying;
    BOOL isFinishRecordAudio;
    
    int inactiveTime;
	
	TalkingBabyAppDelegate *appDelegate;
}
@property (nonatomic, retain) IBOutlet UIImageView *imgView;
@property (nonatomic, retain) IBOutlet UIButton *recordButton;
@property (nonatomic, retain) UIButton *flowerButton;
@property (nonatomic, retain) UIButton *toungeButton;
@property (nonatomic, retain) UIButton *vomitButton;
@property (nonatomic, retain) UIButton *danceButton;
@property (nonatomic, retain) RecordVideo *recordVideo;
@property (nonatomic, assign) BOOL isSharing;
@property (nonatomic, retain) UIViewController *shareViewController;

- (void)startCheckInactiveTimer;
- (void)stopCheckInactiveTimer; 

- (IBAction)buttonClick:(id)sender;
- (IBAction)recordVideoButton;
- (IBAction)showInfo;
- (void)playAnimation:(NSString*)animation withAmountImage:(int)amountImg andTime:(float)second;
- (void)startRecordVideo;
- (void)stopRecordVideo;
- (void)startCheckInactiveTimer;
- (void)stopCheckInactiveTimer;
- (void)playConfusedAnimation;
- (void)stopConfusedAnimation;

@end
