//
//  RecordAudio.m
//  TalkingBaby
//
//  Created by hung le on 8/25/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import "RecordAudio.h"
#import "TalkingBabyAppDelegate.h"
#import "MainViewController.h"

@implementation RecordAudio
@synthesize delegate;
@synthesize trackRecorder;

- (id)init {
	appDelegate = (TalkingBabyAppDelegate*)[[UIApplication sharedApplication] delegate];
	playingRecordAudio = NO;
	[self startRecordToTrack];
	return self;
}
- (void)startRecordToTrack {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    //setup record setting
	recordSetting = [[NSMutableDictionary alloc] init];
	[recordSetting setValue :[NSNumber numberWithInt:kAudioFormatAppleIMA4] forKey:AVFormatIDKey];
	[recordSetting setValue:[NSNumber numberWithFloat:44100.0] forKey:AVSampleRateKey]; 
    [recordSetting setValue:[NSNumber numberWithInt:kAudioFormatAppleLossless] forKey:AVFormatIDKey];
	[recordSetting setValue:[NSNumber numberWithInt:1] forKey:AVNumberOfChannelsKey];
    [recordSetting setValue:[NSNumber numberWithInt:AVAudioQualityMax] forKey:AVEncoderAudioQualityKey];
    
    [recordSetting setValue :[NSNumber numberWithInt:16] forKey:AVLinearPCMBitDepthKey];
    [recordSetting setValue :[NSNumber numberWithBool:NO] forKey:AVLinearPCMIsBigEndianKey];
    [recordSetting setValue :[NSNumber numberWithBool:NO] forKey:AVLinearPCMIsFloatKey];
	//place to save track record
	trackRecordedTmpFile = [[NSURL alloc] initFileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent: [NSString stringWithFormat: @"%.0f.%@", [NSDate timeIntervalSinceReferenceDate] * 1000.0, @"caf"]]];
    //Track recorder : track has signal input micro --> user talking --> record
    trackRecorder = [[ AVAudioRecorder alloc] initWithURL:trackRecordedTmpFile settings:recordSetting error:&error];
	[trackRecorder setDelegate:self];
	[trackRecorder prepareToRecord];
	trackRecorder.meteringEnabled = YES;
	[trackRecorder record];
    
    peakRecord = -12;
    isLarger = NO;
    isEqualTen = NO;
    
    //laveTimer is timer check has signal input micro.
    levelTimer = [NSTimer scheduledTimerWithTimeInterval: 0.1 target:self selector: @selector(levelTimerCallback:) userInfo: nil repeats: YES];
    [[NSRunLoop mainRunLoop] addTimer:levelTimer forMode:NSRunLoopCommonModes];
    [pool release];
}

/*- (void)levelTimerCallback:(NSTimer *)timer { //check signal intensity
	[trackRecorder updateMeters];
	
	const double ALPHA = 0.05;
	double peakPowerForChannel = pow(10, (0.05 * [trackRecorder peakPowerForChannel:0]));
	lowPassResults = ALPHA * peakPowerForChannel + (1.0 - ALPHA) * lowPassResults;	
    
    NSLog(@"%d     %d",(int)[trackRecorder peakPowerForChannel:0],   (int)peakRecord);
    if ((int)[trackRecorder peakPowerForChannel:0] >= (int)peakRecord) {
        isLarger = YES;
        if ([trackRecorder peakPowerForChannel:0] > -10) {
            isEqualTen = YES;
        }
    }
    else {
        isLarger = NO;
    }
    peakRecord = [trackRecorder peakPowerForChannel:0];
    //check condition to start record audio
	if ([trackRecorder peakPowerForChannel:0] > -13 && !appDelegate.animating && !playingRecordAudio && !appDelegate.showShareView) {
        NSLog(@"-=----------------");
		if (!appDelegate.recordingAudio) {
            NSLog(@")))))))))))))))))))");
            countToStopRecord = 0;
            appDelegate.recordingAudio = YES;
            recordTime = 0;
			[self startRecord];
		}
	}
    
    countToStopRecord ++;
    
    if ([recorder isRecording]) {
        if (isEqualTen) {
            if (!isLarger) {
                NSLog(@"1111111");
                if ([trackRecorder peakPowerForChannel:0] < -10) {
                    if (!appDelegate.animating && [recorder isRecording] && countToStopRecord > 0) {
                        NSLog(@"2222222");
                        appDelegate.animating = NO;
                        peakRecord = -13;
                        isLarger = NO;
                        isEqualTen = NO;
                        recordTime = (countToStopRecord-1) * 0.1;
                        [NSThread detachNewThreadSelector:@selector(stopRecord) toTarget:self withObject:nil];
                    }
                }
            }
        }
        else {
            if ([trackRecorder peakPowerForChannel:0] < -13) {
                NSLog(@"33333");
                if (!appDelegate.animating && [recorder isRecording] && countToStopRecord > 0) {
                    NSLog(@"44444444");
                    appDelegate.animating = NO;
                    peakRecord = -13;
                    isLarger = NO;
                    isEqualTen = NO;
                    recordTime = (countToStopRecord-1) * 0.1;
                    [NSThread detachNewThreadSelector:@selector(stopRecord) toTarget:self withObject:nil];
                }
            }
        }
    }
    //beforeLowPass = [trackRecorder peakPowerForChannel:0];
}*/

- (void)levelTimerCallback:(NSTimer *)timer {
	[trackRecorder updateMeters];
	
	//const double ALPHA = 0.05;
	//double peakPowerForChannel = pow(10, (0.05 * [trackRecorder peakPowerForChannel:0]));
	//lowPassResults = ALPHA * peakPowerForChannel + (1.0 - ALPHA) * lowPassResults;	
    
    //NSLog(@"%f",[trackRecorder peakPowerForChannel:0]);
	if ([trackRecorder peakPowerForChannel:0] > peakRecord && !appDelegate.animating && !playingRecordAudio && !appDelegate.showShareView) {
		if (![recorder isRecording]) {
            NSLog(@"start record audio");
            countToStopRecord = 0;
            appDelegate.recordingAudio = YES;
			[self startRecord];
		}
	}
   
    countToStopRecord ++;
	if ([trackRecorder peakPowerForChannel:0] < peakRecord && !appDelegate.animating && [recorder isRecording] && countToStopRecord > 0) {
        NSLog(@"stop record audio --> play back");
        appDelegate.animating = YES;
        peakRecord = -12;
        recordTime = 0;
        recordTime = (countToStopRecord-1) * 0.1;
		[self stopRecord];
	}
}

- (void)startRecord {
    [appDelegate.mainViewController playConfusedAnimation];
	recordedTmpFile = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent: [NSString stringWithFormat: @"%.0f.%@", [NSDate timeIntervalSinceReferenceDate] * 1000.0, @"caf"]]];
	
	recorder = [[ AVAudioRecorder alloc] initWithURL:recordedTmpFile settings:recordSetting error:&error];
	[recorder setDelegate:self];
	[recorder prepareToRecord];
	recorder.meteringEnabled = YES;
	[recorder record];
}

- (void)stopRecord {
    appDelegate.recordingAudio = NO;
    [recorder stop];
}
- (void)stopTrackRecord {
    [trackRecorder stop];
}
- (void)playRecord {
    [appDelegate.mainViewController stopConfusedAnimation];
    if (self.delegate != nil && [self.delegate respondsToSelector:@selector(startPlayRecordAudio)]) {
        [self.delegate startPlayRecordAudio];
    }

	playingRecordAudio = YES;
    
    //play record file by Diract --> change pitch
    if (recordTime != 0) {
        mRealtimeController = [[RealtimeAudioController alloc] initWithString:@"hung.caf"];
        [mRealtimeController changePitch:1.5];
        [mRealtimeController start];
    }
    [NSTimer scheduledTimerWithTimeInterval:recordTime target:self selector:@selector(stopPlayRecord) userInfo:nil repeats:NO];
}
- (void)stopPlayRecord {
    if (playingRecordAudio) {
        if (self.delegate != nil && [self.delegate respondsToSelector:@selector(finishPlayRecordAudio)]) {
            [self.delegate finishPlayRecordAudio];
        }
    }
    playingRecordAudio = NO;
    appDelegate.recordingAudio = NO;
   
    if (mRealtimeController != nil) {
        [mRealtimeController stop];
        [mRealtimeController release];
        mRealtimeController = nil;
    }
    
	NSFileManager * fm = [NSFileManager defaultManager];
	[fm removeItemAtPath:[recordedTmpFile path] error:&error];
}

- (void)dealloc {
    NSLog(@"audio dealloc");
	NSFileManager * fm = [NSFileManager defaultManager];
	[fm removeItemAtPath:[trackRecordedTmpFile path] error:&error];
	[recordSetting release];
    [trackRecorder stop];
	[trackRecordedTmpFile release];
	[trackRecorder dealloc];
	trackRecorder = nil;
	[error release];
	[recorder dealloc];
	[recordedTmpFile release];
	recorder = nil;
	[levelTimer invalidate];
	[super dealloc];
}

#pragma mark -
#pragma mark AVAudioRecorderDelegate
- (void)audioRecorderDidFinishRecording:(AVAudioRecorder *)recorder successfully:(BOOL)flag {
     NSLog(@"record finish");
    NSFileManager *fileManager = [[[NSFileManager alloc] init] autorelease];
    NSData *data = [NSData dataWithContentsOfURL:recordedTmpFile];
    BOOL succ =[fileManager createFileAtPath:[NSTemporaryDirectory() stringByAppendingPathComponent: [NSString stringWithFormat: @"hung.%@", @"caf"]] contents:data attributes:nil];
    if (succ) {
        [self playRecord];
    }
}
- (void)audioRecorderEncodeErrorDidOccur:(AVAudioRecorder *)recorder error:(NSError *)error {
	NSLog(@"encode error");
}
- (void)audioRecorderBeginInterruption:(AVAudioRecorder *)recorder {
	NSLog(@"record begin interruption");
}

@end
