//
//  DynamicViewController.h
//  TalkingBaby
//
//  Created by le hung on 10/19/11.
//  Copyright (c) 2011 CNCSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DynamicViewController : UIViewController <UIWebViewDelegate>{
    IBOutlet UIWebView *webView;
    IBOutlet UIActivityIndicatorView *indicator;
}
- (IBAction)back:(id)sender;
@end
