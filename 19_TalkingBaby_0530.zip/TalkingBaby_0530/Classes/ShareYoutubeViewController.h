//
//  ShareYoutubeViewController.h
//  TalkingBaby
//
//  Created by hung le on 10/1/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GData.h"

@class TalkingBabyAppDelegate;
@interface ShareYoutubeViewController : UIViewController {
    GDataServiceTicket *mUploadTicket;
    IBOutlet UITextField *usernameTextField;
    IBOutlet UITextField *passwordTextField;
    IBOutlet UITextField *titleTextField;
    IBOutlet UITextView *descriptionTextView;
    
    IBOutlet UIScrollView *scrollView;
    IBOutlet UIActivityIndicatorView *indicator;
    
    BOOL isUpload;
    TalkingBabyAppDelegate *appDelegate;
}

- (IBAction)uploadVideo;
- (IBAction)close;
- (IBAction)hiddendKeyboard;
@end
