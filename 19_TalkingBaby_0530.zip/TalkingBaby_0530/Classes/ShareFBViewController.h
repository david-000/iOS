//
//  ShareFBViewController.h
//  TalkingBaby
//
//  Created by hung le on 10/1/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FBConnect.h"
#import "FBLoginButton.h"

@class TalkingBabyAppDelegate;
@interface ShareFBViewController : UIViewController <FBRequestDelegate,
FBDialogDelegate,
FBSessionDelegate>{
    IBOutlet UIActivityIndicatorView *indicator;
    IBOutlet FBLoginButton* _fbButton;
    Facebook* _facebook;
    NSArray* _permissions;
    TalkingBabyAppDelegate *appDelegate;
}
@property(readonly) Facebook *facebook;

- (IBAction)fbButtonClick:(id)sender;
- (IBAction)close;
- (void)uploadVideo;
- (void)login;
@end
