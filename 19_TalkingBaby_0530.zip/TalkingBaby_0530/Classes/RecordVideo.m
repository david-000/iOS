//
//  RecordVideo.m
//  TalkingBaby
//
//  Created by hung le on 9/9/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import <CoreVideo/CoreVideo.h>
#import "RecordVideo.h"
#import "MainViewController.h"
#import "TalkingBabyAppDelegate.h"


@implementation RecordVideo
@synthesize captureView;
@synthesize recordTime;
@synthesize mailViewController;
@synthesize delegate;
@synthesize linkVideo;
@synthesize videoLink;

int counter;

#define kFrameCaptureInterval   0.04

- (void)backgroundFrameCapture {

    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
 
    self->capturingVideo = YES; 

    NSRunLoop *runloop = [NSRunLoop currentRunLoop];
    
    timer = [NSTimer scheduledTimerWithTimeInterval:kFrameCaptureInterval target:self selector:@selector(captureFrameImages) userInfo:nil repeats:YES];
    [runloop addTimer:timer forMode:NSRunLoopCommonModes];
    
    while (self->capturingVideo && [runloop runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]]);
    
    [pool release];
}

- (void)startRecordVideo {
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    appDelegate = (TalkingBabyAppDelegate*)[[UIApplication sharedApplication] delegate];
    pauseTimeArray = [[NSMutableArray alloc] init];
    imgView = nil;
    playView = nil;
    captureImgArray = [[NSMutableArray alloc] init];

    [self performSelectorInBackground:@selector(recordAudio) withObject:nil];
	[NSThread detachNewThreadSelector:@selector(backgroundFrameCapture) toTarget: self withObject: nil];
    
    //timer for capture video
    fileManager = [[NSFileManager alloc] init];
    
    timerToCheckRecordAudio = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(checkRecordAudio) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:timerToCheckRecordAudio forMode:NSRunLoopCommonModes];
    
    [pool release];
}
- (void)recordAudio {
    //record audio
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    recordTime = 0;
	
	recordSetting = [[NSMutableDictionary alloc] init];
	[recordSetting setValue :[NSNumber numberWithInt:kAudioFormatAppleIMA4] forKey:AVFormatIDKey];
	[recordSetting setValue:[NSNumber numberWithFloat:44100.0] forKey:AVSampleRateKey]; 
	[recordSetting setValue:[NSNumber numberWithInt: 1] forKey:AVNumberOfChannelsKey];
	
    linkAudio = [[NSString alloc] initWithString:[NSTemporaryDirectory() stringByAppendingPathComponent: [NSString stringWithFormat: @"%.0f.%@", [NSDate timeIntervalSinceReferenceDate] * 1000.0, @"caf"]]];
    
	recordedTmpFile = [NSURL fileURLWithPath:linkAudio];
    
	recorder = [[ AVAudioRecorder alloc] initWithURL:recordedTmpFile settings:recordSetting error:&error];
	[recorder setDelegate:self];
	[recorder prepareToRecord];
	recorder.meteringEnabled = YES;
	[recorder record];
    [pool release];
}

//save time when record audio to not play when play captured video
- (void)checkRecordAudio {
    durationPlayAudio += 0.01;
    if (appDelegate.recordingAudio) {
        pauseTime += 0.01;
        if (!pausing) {
            pausing = YES;
            [recorder pause];
            startPause = durationPlayAudio;
        }
    }
    else {
        if (pausing) {
            pausing = NO;
            NSDictionary *dic = [[NSDictionary alloc] initWithObjects:[NSArray arrayWithObjects:[NSString stringWithFormat:@"%f",startPause],[NSString stringWithFormat:@"%f",pauseTime], nil] forKeys:[NSArray arrayWithObjects:@"start",@"duration", nil]]; 
            [pauseTimeArray addObject:dic];
            [dic release];
            [recorder record];
            pauseTime = 0;
            startPause = 0;
        }
    }
}

- (void)captureFrameImages { //save the frames of the animations into a Array  this Array
    //NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    recordTime = recordTime + kFrameCaptureInterval;
    [captureImgArray addObject:appDelegate.currentAnimationImage];
    //[pool release];
}
//- (void)captureFrameImages {
//    [self performSelectorInBackground:@selector(capture) withObject:nil];
//}

- (void)stopRecordVideo {
	[timer invalidate];
    [timerToCheckRecordAudio invalidate];
	[recorder stop];
    self->capturingVideo = NO;
}

- (void)playRecordVideo {
    count = 0;
    if (playView != nil) {
        [playView release];
        playView = nil;
        [imgView release];
        imgView = nil;
    }
    playView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    
    UIImageView *bgImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.jpg"]];
        
    [playView addSubview:bgImageView];
    [playView addSubview:imgView];
    [bgImageView release];

    [appDelegate.mainViewController.view addSubview:playView];
    
    timer = [NSTimer scheduledTimerWithTimeInterval:kFrameCaptureInterval target:self selector:@selector(startAnimation) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
    
    //play audio
    NSURL *url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@",linkAudio]];
    
    audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
    audioPlayer.delegate = self;
    audioPlayer.numberOfLoops = 0;
    
    if (audioPlayer == nil)
        NSLog(@"error when play audio");
    else
    {
        [audioPlayer play];
        timerToPlayRecordAudio = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(pausePlayAudio) userInfo:nil repeats:YES];
        countPause = 0;
        pauseTime = 0;
        pausing = NO;
    }
}

- (void)pausePlayAudio { //pause play audio when user's talking
    pauseTime += 0.01;
    if ([pauseTimeArray count] > 0 && countPause < [pauseTimeArray count]) {
        if (!pausing) {
            if (pauseTime >= [[[pauseTimeArray objectAtIndex:countPause] objectForKey:@"start"] floatValue]) {
                [audioPlayer pause];
                pausing = YES;
            }
        }
        else {
            if (pauseTime >= [[[pauseTimeArray objectAtIndex:countPause] objectForKey:@"duration"] floatValue] + [[[pauseTimeArray objectAtIndex:countPause] objectForKey:@"start"] floatValue]) {
                [audioPlayer play];
                pausing = NO;
                countPause += 1;
            }
        }   
    }
}
- (void)back {
    [playView removeFromSuperview];
    [appDelegate.actionSheet showInView:appDelegate.window];
}
- (void)startAnimation {
    if (count == [captureImgArray count]) {
		[timer invalidate];
		timer = nil;
        if (delegate != nil && [delegate respondsToSelector:@selector(finishPlayRecordVideo)]) {
            [delegate finishPlayRecordVideo];
        }
        [playView removeFromSuperview];
        [appDelegate.actionSheet showInView:appDelegate.window];
	}
	else {
        imgView.image = [[[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[[captureImgArray objectAtIndex:count] stringByReplacingOccurrencesOfString:@".jpg" withString:@""] ofType:@"jpg"]] autorelease];
        count++;
	}
}


//Create video file
-(BOOL)drawNextAnimationFrameInContext:(CGContextRef *)contextRef {
	counter++;
	if (counter == 100) {
		return NO;
	}
	CGContextRef context = *contextRef;
	
	CGContextSetRGBFillColor(context, 0,0,1,1); //RED
	CGContextFillRect(context, CGRectMake(0, 0, 320, 480));
	
	CGContextSetRGBFillColor(context, 1,0,0,0.5); //BLUE with alpha of 0.5
	CGContextFillEllipseInRect(context, CGRectMake(1*counter, 200, 1*counter, 1*counter));
	return YES;
}
- (void)createVideoFromFrames {
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES); 
    NSString *cacheDirectory = [paths objectAtIndex:0];
    linkVideo = [[NSString alloc] initWithFormat:@"%@/%0f.mov",cacheDirectory,[NSDate timeIntervalSinceReferenceDate] * 1000.0];
	AVAssetWriter *asset = [AVAssetWriter assetWriterWithURL:[NSURL fileURLWithPath:linkVideo] fileType:AVFileTypeQuickTimeMovie error:nil];
	
	//AVAssetWriter *asset = [AVAssetWriter assetWriterWithURL:[NSURL fileURLWithPath:linkVideo] fileType:AVFileTypeQuickTimeMovie error:nil];
	
	NSDictionary *videoSettings = [NSDictionary dictionaryWithObjectsAndKeys:
								   AVVideoCodecH264, AVVideoCodecKey,
								   [NSNumber numberWithInt:320], AVVideoWidthKey,
								   [NSNumber numberWithInt:480], AVVideoHeightKey,
								   nil];
	
	AVAssetWriterInput* writerInput = [[AVAssetWriterInput
										assetWriterInputWithMediaType:AVMediaTypeVideo
										outputSettings:videoSettings] retain];
	
	NSMutableDictionary *attributes = [[NSMutableDictionary alloc]init];
	[attributes setObject:[NSNumber numberWithUnsignedInt:kCVPixelFormatType_32ARGB] forKey:(NSString*)kCVPixelBufferPixelFormatTypeKey];
	[attributes setObject:[NSNumber numberWithUnsignedInt:320] forKey:(NSString*)kCVPixelBufferWidthKey];
	[attributes setObject:[NSNumber numberWithUnsignedInt:480] forKey:(NSString*)kCVPixelBufferHeightKey];
	
	AVAssetWriterInputPixelBufferAdaptor *adaptor = [AVAssetWriterInputPixelBufferAdaptor
													 assetWriterInputPixelBufferAdaptorWithAssetWriterInput:writerInput
													 sourcePixelBufferAttributes:attributes];
    [attributes release];
	
	[asset addInput:writerInput];
	
	// fixes all errors
	writerInput.expectsMediaDataInRealTime = YES;
	[asset startWriting];
	[asset startSessionAtSourceTime:kCMTimeZero];
	
	CVPixelBufferRef buffer = NULL;
	BOOL result;
	
    UIView *viewCapture = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    
    UIImageView *bgImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    bgImgView.image = [UIImage imageNamed:@"background.jpg"];
    [viewCapture addSubview:bgImgView];
    
    UIImageView *contentImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    contentImgView.image = [UIImage imageNamed:[captureImgArray objectAtIndex:0]];
    [viewCapture addSubview:contentImgView];
    
    UIGraphicsBeginImageContext(viewCapture.bounds.size);
    [viewCapture.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage * img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    [bgImgView release];
    [contentImgView release];
    [viewCapture release];
    
	buffer = [self pixelBufferFromCGImage:[img CGImage]];
	
	result = [adaptor appendPixelBuffer:buffer withPresentationTime:kCMTimeZero];
	if (result == NO) //failes on 3GS, but works on iphone 4
		NSLog(@"failed to append buffer");
	
	if(buffer)
		CVBufferRelease(buffer);
	
	[NSThread sleepForTimeInterval:0.1];
	for (int i = 1;i < [captureImgArray count]; i++)
	{
		if (adaptor.assetWriterInput.readyForMoreMediaData) 
		{
            [NSThread detachNewThreadSelector:@selector(setProgressForProgressBar) toTarget:self withObject:nil];
			NSLog(@"inside for loop %d",i);
			CMTime frameTime = CMTimeMake(1, 5);
			CMTime lastTime=CMTimeMake(i, 5); 
			CMTime presentTime=CMTimeAdd(lastTime, frameTime);
            
            UIView *viewCapture = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
            
            UIImageView *bgImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
            bgImgView.image = [UIImage imageNamed:@"background.jpg"];
            [viewCapture addSubview:bgImgView];
            
            UIImageView *contentImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
            contentImgView.image = [UIImage imageNamed:[captureImgArray objectAtIndex:i]];
            //contentImgView.image = [UIImage imageNamed:@"talking1_1.png"];
            [viewCapture addSubview:contentImgView];
            
            UIGraphicsBeginImageContext(viewCapture.bounds.size);
            [viewCapture.layer renderInContext:UIGraphicsGetCurrentContext()];
            UIImage * img1 = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
            
            [bgImgView release];
            [contentImgView release];
            [viewCapture release];
            
			buffer = [self pixelBufferFromCGImage:[img1 CGImage]];
			BOOL result = [adaptor appendPixelBuffer:buffer withPresentationTime:presentTime];
			
			if (result == NO) //failes on 3GS, but works on iphone 4
			{
				NSLog(@"failed to append buffer");
				NSLog(@"The error is %@", [asset error]);
			}
			if(buffer)
				CVBufferRelease(buffer);
			[NSThread sleepForTimeInterval:0.2];
		}
		else
		{
			NSLog(@"error");
			i--;
		}
	}
	
	//Finish the session:
	[writerInput markAsFinished];
	[asset finishWriting];
	CVPixelBufferPoolRelease(adaptor.pixelBufferPool);
	
	NSLog(@"Movie created successfully");
    videoLink = [[NSString alloc] initWithFormat:@"%@/%0f.mov",cacheDirectory,[NSDate timeIntervalSinceReferenceDate] * 1000.0];
    
    //complete create video --> add audio file into video file
	[self addAudioToFileAtPath:[NSString stringWithFormat:@"%@",linkVideo] toPath:[NSString stringWithString:videoLink]];
    [writerInput release];
}

- (void)setProgressForProgressBar { //set value for progress bar when create video
    countImg ++;
    [appDelegate.progressView setProgress:(float)countImg/(float)[captureImgArray count]];
}

-(void) addAudioToFileAtPath:(NSString *) filePath toPath:(NSString *)outFilePath
{
    NSError * error1 = nil;
	
    AVMutableComposition * composition = [AVMutableComposition composition];
	
	
    AVURLAsset * videoAsset = [AVURLAsset URLAssetWithURL:[NSURL fileURLWithPath:filePath] options:nil];
	
    AVAssetTrack * videoAssetTrack = [[videoAsset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
	
    AVMutableCompositionTrack *compositionVideoTrack = [composition addMutableTrackWithMediaType:AVMediaTypeVideo 
                                                                                preferredTrackID: kCMPersistentTrackID_Invalid];
	
    [compositionVideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero,videoAsset.duration) ofTrack:videoAssetTrack atTime:kCMTimeZero
                                     error:&error1];     
	
	NSString * pathString = linkAudio;
    //NSString *pathString = [[NSBundle mainBundle] pathForResource:@"abc" ofType:@"mp3"];
    NSLog(@"%@",linkAudio);
	AVURLAsset * urlAsset = [AVURLAsset URLAssetWithURL:[NSURL fileURLWithPath:pathString] options:nil];
	
	AVAssetTrack * audioAssetTrack = [[urlAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0];
	AVMutableCompositionTrack *compositionAudioTrack = [composition addMutableTrackWithMediaType:AVMediaTypeAudio 
																				preferredTrackID: kCMPersistentTrackID_Invalid];
	
	[compositionAudioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero,urlAsset.duration) ofTrack:audioAssetTrack atTime:kCMTimeZero error:&error];
	
	
    AVAssetExportSession* assetExport = [[AVAssetExportSession alloc] initWithAsset:composition presetName:AVAssetExportPresetHighestQuality];  
    //assetExport.videoComposition = compositionVideoTrack;
	
    assetExport.outputFileType = AVFileTypeQuickTimeMovie;
    assetExport.outputURL = [NSURL fileURLWithPath:outFilePath];
	
    [assetExport exportAsynchronouslyWithCompletionHandler:
     ^(void ) {
         switch (assetExport.status) 
         {
             case AVAssetExportSessionStatusCompleted:
				 //                export complete 
                 NSLog(@"Export Complete");
                 [appDelegate.progressView setProgress:1.0];
                 if (delegate != nil && [delegate respondsToSelector:@selector(createVideoSuccessfully)]) {
                     [delegate createVideoSuccessfully];
                 }
                 break;
             case AVAssetExportSessionStatusFailed:
                 NSLog(@"Export Failed");
                 NSLog(@"ExportSessionError: %@", [assetExport.error localizedDescription]);
				 //                export error (see exportSession.error)  
                 [appDelegate.progressView setProgress:1.0];
                 if (delegate != nil && [delegate respondsToSelector:@selector(createVideoSuccessfully)]) {
                     [delegate createVideoSuccessfully];
                 }
                 break;
             case AVAssetExportSessionStatusCancelled:
                 NSLog(@"Export Failed");
                 NSLog(@"ExportSessionError: %@", [assetExport.error localizedDescription]);
				 //                export cancelled  
                 break;
         }
     }];    
}

- (CVPixelBufferRef) pixelBufferFromCGImage: (CGImageRef) image {
    NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSNumber numberWithBool:YES], kCVPixelBufferCGImageCompatibilityKey,
                             [NSNumber numberWithBool:YES], kCVPixelBufferCGBitmapContextCompatibilityKey,
                             nil];
    CVPixelBufferRef pxbuffer = NULL;
	
    CVPixelBufferCreate(kCFAllocatorDefault, 320,
                        480, kCVPixelFormatType_32ARGB, (CFDictionaryRef) options, 
                        &pxbuffer);
	
    CVPixelBufferLockBaseAddress(pxbuffer, 0);
    void *pxdata = CVPixelBufferGetBaseAddress(pxbuffer);
	
    CGColorSpaceRef rgbColorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(pxdata, 320,
                                                 480, 8, 4*320, rgbColorSpace, 
                                                 kCGImageAlphaNoneSkipFirst);
	
    CGContextConcatCTM(context, CGAffineTransformMakeRotation(0));
    CGContextDrawImage(context, CGRectMake(0, 0, CGImageGetWidth(image), 
                                           CGImageGetHeight(image)), image);
    CGColorSpaceRelease(rgbColorSpace);
    CGContextRelease(context);
	
    CVPixelBufferUnlockBaseAddress(pxbuffer, 0);
	
    return pxbuffer;
}


- (void)dealloc {
    NSLog(@"record video dealloc");
	[recordedTmpFile release];
	[error release];
	[recordSetting release];
	[linkAudio release];
	[captureImgArray release];
    captureImgArray = nil;
    [playView release];
	[linkVideo release];
    [imgView release];
    [videoLink release];
    [fileManager release];
    [pauseTimeArray release];
    
    [super dealloc];
}

#pragma mark -
#pragma mark AVAudioPlayerDelegate

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag {
	[audioPlayer release];
    audioPlayer = nil;
}

#pragma mark -
#pragma mark AVAudioRecorderDelegate
- (void)audioRecorderDidFinishRecording:(AVAudioRecorder *)recorder successfully:(BOOL)flag {
	NSLog(@"finish record audio of Video");
    NSLog(@"%@",linkAudio);
}
- (void)audioRecorderEncodeErrorDidOccur:(AVAudioRecorder *)recorder error:(NSError *)error {
	NSLog(@"encode error");
}
- (void)audioRecorderBeginInterruption:(AVAudioRecorder *)recorder {
	NSLog(@"record begin interruption");
}


#pragma mark -
#pragma mark encode delegate
-(void)movieEncoderDidFinishAddingFrames {
    //all that's left is the remaining compression (very quick)
    NSLog(@"All frames added");
}

-(void)movieEncoderDidFinishEncoding {
    //it's actually finished now, you can release it, if you like you can ask for the fileURL first so you know where the movie went
    NSLog(@"Movie written to disk");
}

-(void)movieEncoderDidFailWithReason:(NSString *)reason {
    //it's failed.  It's in an unpredictable state, the movie may exist but it's probably garbage if it does.
    NSLog(@"%@", reason);
}

@end
