//
//  RecordAudio.h
//  TalkingBaby
//
//  Created by hung le on 8/25/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreAudio/CoreAudioTypes.h>
#import "RealtimeAudioController.h"

@class TalkingBabyAppDelegate;

@protocol RecordAudioDelegate <NSObject>
@required 
-(void)startPlayRecordAudio;
-(void)finishPlayRecordAudio;

@end

@interface RecordAudio : NSObject <AVAudioRecorderDelegate, AVAudioPlayerDelegate>{
	NSURL *trackRecordedTmpFile;
	AVAudioRecorder *trackRecorder; //recorder to record all audio to check when user talk
    
	NSError *error;
	NSTimer *levelTimer;
	
	NSURL *recordedTmpFile;
	AVAudioRecorder *recorder; //recorder to record audio when user talk
	NSMutableDictionary* recordSetting;
	
	TalkingBabyAppDelegate *appDelegate;
    id <RecordAudioDelegate> delegate;
    RealtimeAudioController *mRealtimeController;
    
    float recordTime;
    float beforeLowPass;
    float peakRecord;
    BOOL toggle;
	BOOL playingRecordAudio;
	double lowPassResults;
    int countToStopRecord;
    
    BOOL isLarger;
    BOOL isEqualTen;
}
@property (nonatomic, assign) id <RecordAudioDelegate> delegate;
@property (nonatomic, retain) AVAudioRecorder *trackRecorder;

- (void)startRecordToTrack;
- (void)startRecord;
- (void)playRecord;
- (void)stopRecord;
- (void)stopTrackRecord;
- (void)stopPlayRecord;
@end
