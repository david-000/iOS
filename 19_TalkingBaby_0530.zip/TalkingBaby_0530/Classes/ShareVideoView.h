//
//  ShareVideoView.h
//  TalkingBaby
//
//  Created by hung le on 9/9/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import "RecordVideo.h"

@protocol ShareVideoDelegate <NSObject>
@required 
- (void)replay;
@end


@class MainViewController;
@class TalkingBabyAppDelegate;
@class CreateVideoProgressView;
@interface ShareVideoView : UIView <MFMailComposeViewControllerDelegate, RecordVideoDelegate, UIAlertViewDelegate> {
	MainViewController *mainViewController;
    CreateVideoProgressView *createVideoProgressView;
    
    TalkingBabyAppDelegate *appDelegate;
    BOOL fileCreated;
    int index;
    id <ShareVideoDelegate> delegate;
    UIActivityIndicatorView *indicator;
}
@property (nonatomic, retain) MainViewController *mainViewController;
@property (nonatomic, assign) id <ShareVideoDelegate> delegate;
- (IBAction)shareYoutube;
- (IBAction)shareFacebook;
- (IBAction)sendEmail;
- (IBAction)replay;
- (IBAction)close;
- (void)createRecordVideoFile;
- (void)share;
- (void)saveVideoToGallery;
@end
