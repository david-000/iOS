//
//  ShareVideoView.m
//  TalkingBaby
//
//  Created by hung le on 9/9/11.
//  Copyright 2011 CNCSoft. All rights reserved.
//

#import "ShareVideoView.h"
#import "TalkingBabyAppDelegate.h"
#import "MainViewController.h"
#import "RecordVideo.h"
#import "CreateVideoProgressView.h"
#import "ShareFBViewController.h"
#import "ShareYoutubeViewController.h"

@implementation ShareVideoView
@synthesize mainViewController;
@synthesize delegate;


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code.
        appDelegate = (TalkingBabyAppDelegate*)[[UIApplication sharedApplication] delegate];
        fileCreated = NO;
        
        appDelegate.mainViewController.recordVideo.delegate = self;
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}
*/

- (void)dealloc {
    [createVideoProgressView release];
    [super dealloc];
}

#pragma mark -
#pragma mark action
- (IBAction)shareYoutube {
    index = 1;
    [self createRecordVideoFile];
}

- (IBAction)shareFacebook {
    index = 2;
     [self createRecordVideoFile];
}

- (IBAction)sendEmail {
    index = 3;
     [self createRecordVideoFile];
}

- (IBAction)replay {
    [mainViewController.recordVideo playRecordVideo];
}
- (void)saveVideoToGallery {
    index = 4;
    [self createRecordVideoFile];
}
- (IBAction)close {
	[appDelegate.shareViewController dismissModalViewControllerAnimated:YES];
    appDelegate.mainViewController.isSharing = NO;
    appDelegate.showShareView = NO;
    [appDelegate.mainViewController startCheckInactiveTimer];
	
}
- (void)createRecordVideoFile {
    if (!fileCreated) {
        fileCreated = !fileCreated;
        createVideoProgressView = [[CreateVideoProgressView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
        [self addSubview:createVideoProgressView];
        [self performSelector:@selector(createVideo) withObject:nil afterDelay:0.5];
    }
    else {
        [self share];
    }
}
- (void)createVideo {
    [appDelegate.mainViewController.recordVideo createVideoFromFrames];
}
- (void)createVideoSuccessfully {
    [createVideoProgressView removeFromSuperview];
    [self performSelectorOnMainThread:@selector(share) withObject:nil waitUntilDone:YES];
}
- (void)finishPlayRecordVideo {
    
}
- (void)share {
    switch (index) {
        case 1:
        {
            ShareYoutubeViewController *shareYT = [[ShareYoutubeViewController alloc] init];
            [self addSubview:shareYT.view];
        }
            break;
        case 2:
        {
            ShareFBViewController *shareFB = [[ShareFBViewController alloc] init];
            [self addSubview:shareFB.view];
            appDelegate.shareFBController = shareFB;
            [shareFB release];
        }
            break;
        case 3:
        {
            MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
			picker.mailComposeDelegate = self;
			
			NSString *emailBody = @"Talking Baby Video";
			
			[picker setSubject:@"Talking Baby Video"];
			[picker setMessageBody:emailBody isHTML:NO];
			
            NSData *data = [NSData dataWithContentsOfFile:appDelegate.mainViewController.recordVideo.videoLink];
            NSLog(@"%@",appDelegate.mainViewController.recordVideo.linkVideo);
            [picker addAttachmentData:data mimeType:@"video" fileName:@"baby.mov"];
            
			[picker becomeFirstResponder];
            if (picker != nil) {
                [appDelegate.mainViewController presentModalViewController:picker animated:YES]; 
            }
            else {
                [appDelegate.actionSheet showInView:appDelegate.window];
            }
			[picker release];
        }
            break;   
        case 4:
            UISaveVideoAtPathToSavedPhotosAlbum(appDelegate.mainViewController.recordVideo.videoLink, self,  @selector(video:didFinishSavingWithError:contextInfo:), nil);
            break;
        default:
            break;
    }
    
}

- (void)video:(NSString *) videoPath didFinishSavingWithError: (NSError *) error1 contextInfo: (void *) contextInfo {
    if(error1){
        [appDelegate.progressView setProgress:1.0];
        appDelegate.progressView.hidden = YES;
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message"
                                                        message:@"Save video to Gallery failed, please try again!" 
                                                       delegate:appDelegate.mainViewController 
                                              cancelButtonTitle:@"Ok" 
                                              otherButtonTitles:nil];
        
        [alert show];
        [alert release];
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message"
                                                        message:@"Video saved to Gallery successfully!" 
                                                       delegate:appDelegate.mainViewController 
                                              cancelButtonTitle:@"Ok" 
                                              otherButtonTitles:nil];
        
        [alert show];
        [alert release];
    }
}

#pragma mark -
#pragma mark MFMailComposeViewControllerDelegate
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error 
{	
    // Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
            //NSLog(@"Result: canceled");
			break;
		case MFMailComposeResultSaved:
            //NSLog(@"Result: saved");
			break;
		case MFMailComposeResultSent:
            //NSLog(@"Result: sent");
			break;
		case MFMailComposeResultFailed:
            //NSLog(@"Result: failed");
			break;
		default:
            //NSLog(@"Result: not sent");
			break;
	}
	[controller dismissModalViewControllerAnimated:YES];
    [appDelegate.actionSheet showInView:appDelegate.window];
}
@end
